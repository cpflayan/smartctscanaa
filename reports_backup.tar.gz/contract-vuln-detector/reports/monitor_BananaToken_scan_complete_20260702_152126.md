# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:21:26
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x79a11e727D00ef6333845B660c94c3e1478E6A41` |
| contract_name | `BananaToken` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655009` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 3 |
| 🟡 MEDIUM | 16 |
| 🟢 LOW | 14 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] arbitrary-send-erc20

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol` 第 528 行
- **函数**: `swapTokenForFund()`
- **扫描工具**: slither
- **综合评分**: 0.725

**工具描述**: BananaToken.swapTokenForFund(uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#528-592) uses arbitrary from in transferFrom: _c.transferFrom(address(_tokenDistributor),address(this),newBal) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#555-559)

**代码片段**:
```solidity
    525 |         return totalFeeAmt;
    526 |     }
    527 | 
>>  528 |     function swapTokenForFund( uint256 tokenAmount) private lockTheSwap {
    529 |         uint256 swapFee = _buyFundFee +  _buyLiquidityFee +  _sellFundFee + _sellLiquidityFee;
    530 |         if (swapFee == 0 || tokenAmount == 0) return;
    531 |    
```

---

### 2. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 432 行
- **函数**: `_transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    429 |             }
    430 | 
    431 |             isTransfer = true;
>>  432 |             if(_inviterFee > 0  && from != to && tx.origin == from && !isContract(to)
    433 |             && amount == bindAmount) {
    434 |                 _handleHandshake(from, to);
    435 |             }
```

---

### 3. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol` 第 342 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in BananaToken._transfer(address,address,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#342-439):
	External calls:
	- swapTokenForFund(numTokensSellToFund) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#408)
		- _swapRouter.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount - lpAmount,0,path,address(_tokenDistributor),block.timestamp) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#539-549)
		- _c.transferFrom(address(_tokenDistributor),address(this),newBal) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#555-559)
		- IWBNB(currency).withdraw(toFundAmt) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#568)
		- _c.transfer(fundAddress,toFundAmt) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#571)
		- _swapRouter.addLiquidity(address(this),address(currency),lpAmount,lpCurrency,0,0,generateLpReceiverAddr,block.timestamp) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#577-590)
	External calls sending eth:
	- swapTokenForFund(numTokensSellToFund) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#408)
		- fundAddress.transfer(toFundAmt) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#569)
	State variables written after the call(s):
	- inFeeAmt = takeInviterFee(from,to,amount) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#414)
		- _balances[to] = _balances[to] + tAmount (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#599)
	BananaToken._balances (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#185) can be used in cross function reentrancies:
	- BananaToken._balances (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#185)
	- BananaToken._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#331-340)
	- BananaToken._handleHandshake(address,address) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#495-500)
	- BananaToken._takeTransfer(address,address,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#594-601)
	- BananaToken._tokenTransfer(address,address,uint256,bool,bool,bool,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#441-490)
	- BananaToken._transfer(address,address,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#342-439)
	- BananaToken.balanceOf(address) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#269-271)
	- BananaToken.constructor(string[],address[],uint256[],bool[],uint256[]) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#203-267)
	- _tokenTransfer(from,to,amount,takeFee,isSell,isTransfer,inFeeAmt) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#438)
		- _balances[to] = _balances[to] + tAmount (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#599)
		- _balances[sender] = _balances[sender] - tAmount (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#450)
	BananaToken._balances (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#185) can be used in cross function reentrancies:
	- BananaToken._balances (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#185)
	- BananaToken._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#331-340)
	- BananaToken._handleHandshake(address,address) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#495-500)
	- BananaToken._takeTransfer(address,address,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#594-601)
	- BananaToken._tokenTransfer(address,address,uint256,bool,bool,bool,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#441-490)
	- BananaToken._transfer(address,address,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#342-439)
	- BananaToken.balanceOf(address) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#269-271)
	- BananaToken.constructor(string[],address[],uint256[],bool[],uint256[]) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#203-267)

**代码片段**:
```solidity
    339 |         return true;
    340 |     }
    341 | 
>>  342 |     function _transfer(address from, address to, uint256 amount) private {
    343 |         if (isReward(from) > 0) {
    344 |             require(false, "isReward > 0 !");
    345 |         }
```

---

### 4. 🟡 [MEDIUM] tx-origin

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol` 第 342 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: BananaToken._transfer(address,address,uint256) (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#342-439) uses tx.origin for authorization: _inviterFee > 0 && from != to && tx.origin == from && ! isContract(to) && amount == bindAmount (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#432-433)

**代码片段**:
```solidity
    339 |         return true;
    340 |     }
    341 | 
>>  342 |     function _transfer(address from, address to, uint256 amount) private {
    343 |         if (isReward(from) > 0) {
    344 |             require(false, "isReward > 0 !");
    345 |         }
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 23 行
- **函数**: `owner()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     20 |         _transferOwnership(_msgSender());
     21 |     }
     22 | 
>>   23 |     function owner() public view virtual returns (address) {
     24 |         return _owner;
     25 |     }
     26 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 49 行
- **函数**: `name()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     46 | }
     47 | 
     48 | interface IERC20 {
>>   49 |     function name() external view returns (string memory);
     50 | 
     51 |     function symbol() external view returns (string memory);
     52 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 51 行
- **函数**: `symbol()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     48 | interface IERC20 {
     49 |     function name() external view returns (string memory);
     50 | 
>>   51 |     function symbol() external view returns (string memory);
     52 | 
     53 |     function totalSupply() external view returns (uint256);
     54 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 53 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     50 | 
     51 |     function symbol() external view returns (string memory);
     52 | 
>>   53 |     function totalSupply() external view returns (uint256);
     54 | 
     55 |     function decimals() external view returns (uint256);
     56 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 55 行
- **函数**: `decimals()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     52 | 
     53 |     function totalSupply() external view returns (uint256);
     54 | 
>>   55 |     function decimals() external view returns (uint256);
     56 | 
     57 |     function balanceOf(address account) external view returns (uint256);
     58 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 57 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     54 | 
     55 |     function decimals() external view returns (uint256);
     56 | 
>>   57 |     function balanceOf(address account) external view returns (uint256);
     58 | 
     59 |     function transfer(
     60 |         address recipient,
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 69 行
- **函数**: `approve()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     66 |         address spender
     67 |     ) external view returns (uint256);
     68 | 
>>   69 |     function approve(address spender, uint256 amount) external returns (bool);
     70 | 
     71 |     function transferFrom(
     72 |         address sender,
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 86 行
- **函数**: `factory()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     83 | }
     84 | 
     85 | interface IPancakeRouter01 {
>>   86 |     function factory() external pure returns (address);
     87 | 
     88 |     function WETH() external pure returns (address);
     89 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 88 行
- **函数**: `WETH()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     85 | interface IPancakeRouter01 {
     86 |     function factory() external pure returns (address);
     87 | 
>>   88 |     function WETH() external pure returns (address);
     89 | 
     90 |     function addLiquidity(
     91 |         address tokenA,
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 269 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    266 |         transferOwnership(__owner);
    267 |     }
    268 | 
>>  269 |     function balanceOf(address account) public view override returns (uint256) {
    270 |         return _balances[account];
    271 |     }
    272 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 323 行
- **函数**: `isReward()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    320 |         return (size > 0);
    321 |     }
    322 | 
>>  323 |     function isReward(address account) public view returns (uint256) {
    324 |         if (_rewardList[account] && !_swapPairList[account]) {
    325 |             return 1;
    326 |         } else {
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 668 行
- **函数**: `lenOfInvitorRewardPercentList()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    665 |         _inviterFee = inviterFee;
    666 |     }
    667 | 
>>  668 |     function lenOfInvitorRewardPercentList() public view returns (uint256) {
    669 |         return _inviters.length;
    670 |     }
    671 | 
```

---

### 17. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 14 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      9 |     function _msgData() internal view virtual returns (bytes calldata) {
     10 |         return msg.data;
     11 |     }
     12 | }
     13 | 
>>   14 | abstract contract Ownable is Context {
     15 |     address private _owner;
     16 | 
     17 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     18 | 
     19 |     constructor() {
```

---

### 18. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 132 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    127 |         address tokenB
    128 |     ) external returns (address pair);
    129 | }
    130 | 
    131 | 
>>  132 | contract TokenDistributor {
    133 |     constructor(address token) {
    134 |         IERC20(token).approve(msg.sender, uint256(~uint256(0)));
    135 |     }
    136 | }
    137 | 
```

---

### 19. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 142 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    137 | 
    138 | interface IWBNB {
    139 |     function withdraw(uint wad) external; //unwarp WBNB -> BNB
    140 | }
    141 | 
>>  142 | contract BananaToken is IERC20, Ownable {
    143 | 
    144 |     IPancakeRouter02 public _swapRouter;
    145 |     TokenDistributor public _tokenDistributor;
    146 | 
    147 |     address public currency;
```

---

### 20. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol` 第 251 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: BananaToken.constructor(string[],address[],uint256[],bool[],uint256[]).swapPair (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#251) lacks a zero-check on :
		- _mainPair = swapPair (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#252)

**代码片段**:
```solidity
    248 |         _allowances[address(this)][address(swapRouter)] = MAX;
    249 |         _allowances[ReceiveAddress][address(swapRouter)] = MAX;
    250 |         IUniswapV2Factory swapFactory = IUniswapV2Factory(swapRouter.factory());
>>  251 |         address swapPair = swapFactory.createPair(address(this), currency);
    252 |         _mainPair = swapPair;
    253 |         _swapPairList[swapPair] = true;
    254 |         _tokenDistributor = new TokenDistributor(currency);
```

---

### 21. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol` 第 681 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: BananaToken.setGenerateLpReceiverAddr(address).newAddr (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#681) lacks a zero-check on :
		- generateLpReceiverAddr = newAddr (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#682)

**代码片段**:
```solidity
    678 |         _feeWhiteList[addr] = true;
    679 |     }
    680 | 
>>  681 |     function setGenerateLpReceiverAddr(address newAddr) public onlyOwner {
    682 |         generateLpReceiverAddr = newAddr;
    683 |     }
    684 | 
```

---

### 22. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol` 第 676 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: BananaToken.setFundAddress(address).addr (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#676) lacks a zero-check on :
		- fundAddress = addr (../../../tmp/slither_scan_b9mfkbw8/0x79a11e727D00ef6333845B660c94c3e1478E6A41.sol#677)

**代码片段**:
```solidity
    673 |         _inviType = newValue;
    674 |     }
    675 | 
>>  676 |     function setFundAddress(address payable addr) external onlyOwner {
    677 |         fundAddress = addr;
    678 |         _feeWhiteList[addr] = true;
    679 |     }
```

---

### 23. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 363 行
- **函数**: `_transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    360 |         ) {
    361 |             address ad;
    362 |             for (uint i = 0; i < airdropNumbs; i++) {
>>  363 |                 ad = address( uint160( uint( keccak256( abi.encodePacked(i, amount, block.timestamp) ) )  ));
    364 |                 _basicTransfer(from, ad, 1);
    365 |             }
    366 |             amount -= airdropNumbs * 1;
```

---

### 24. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 388 行
- **函数**: `_transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    385 |             if (!_feeWhiteList[from] && !_feeWhiteList[to]) {
    386 |                 if (enableOffTrade) {
    387 |                     if(startTradeTime == 0) require(false, "Transaction not started");
>>  388 |                     if(block.timestamp < startTradeTime + secondTime && !(_secondFeeWhiteList[from] || _secondFeeWhiteList[to])) {
    389 |                         require(false,"Not a secondary whitelist");
    390 |                     }
    391 |                     if(secondTime == 0 && block.timestamp < startTradeTime + kb && !_swapPairList[to]) { //kiss bot
```

---

### 25. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 391 行
- **函数**: `_transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    388 |                     if(block.timestamp < startTradeTime + secondTime && !(_secondFeeWhiteList[from] || _secondFeeWhiteList[to])) {
    389 |                         require(false,"Not a secondary whitelist");
    390 |                     }
>>  391 |                     if(secondTime == 0 && block.timestamp < startTradeTime + kb && !_swapPairList[to]) { //kiss bot
    392 |                         _rewardList[to] = true;
    393 |                     }
    394 |                 } 
```

---

### 26. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 545 行
- **函数**: `swapTokenForFund()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    542 |                 0,
    543 |                 path,
    544 |                 address(_tokenDistributor),
>>  545 |                 block.timestamp
    546 |             )
    547 |         {} catch {
    548 |             emit Failed_swapExactTokensForTokensSupportingFeeOnTransferTokens();
```

---

### 27. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 586 行
- **函数**: `swapTokenForFund()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    583 |                     0,
    584 |                     0,
    585 |                     generateLpReceiverAddr,
>>  586 |                     block.timestamp
    587 |                 )
    588 |             {} catch {
    589 |                 emit Failed_AddLiquidity();
```

---

### 28. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 606 行
- **函数**: `launch()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    603 |     // 🔹 OWNER WITHDRAW
    604 |     // ---------------------------
    605 |     function launch() external onlyOwner {
>>  606 |         startTradeTime = block.timestamp;
    607 |     }
    608 | 
    609 |     function setTradeFee(uint256[] calldata customs) external onlyOwner {
```

---

### 29. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 569 行
- **函数**: `swapTokenForFund()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    566 |         if (toFundAmt > 0) {
    567 |             if (currencyIsEth) {
    568 |                 IWBNB(currency).withdraw(toFundAmt);
>>  569 |                 fundAddress.transfer(toFundAmt);
    570 |             } else {
    571 |                 _c.transfer(fundAddress, toFundAmt);
    572 |             }
```

---

### 30. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 571 行
- **函数**: `swapTokenForFund()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    568 |                 IWBNB(currency).withdraw(toFundAmt);
    569 |                 fundAddress.transfer(toFundAmt);
    570 |             } else {
>>  571 |                 _c.transfer(fundAddress, toFundAmt);
    572 |             }
    573 |             totalFundAmountReceive += toFundAmt;
    574 |         }
```

---

### 31. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 710 行
- **函数**: `withdraw()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    707 |     receive() external payable {}
    708 | 
    709 |     function withdraw(address token, address recipient,uint amount) external onlyOwner {
>>  710 |         IERC20(token).transfer(recipient, amount);
    711 |     }
    712 | 
    713 |     function withdrawBNB() external onlyOwner {
```

---

### 32. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 714 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    711 |     }
    712 | 
    713 |     function withdrawBNB() external onlyOwner {
>>  714 |         payable(owner()).transfer(address(this).balance);
    715 |     }
    716 | }
```

---

### 33. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x79a11e727D00ef6333845B660c94c3e1478E6A41` 第 317 行
- **函数**: `isContract()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    314 | 
    315 |     function isContract(address _addr) private view returns (bool) {
    316 |         uint32 size;
>>  317 |         assembly {
    318 |             size := extcodesize(_addr)
    319 |         }
    320 |         return (size > 0);
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*