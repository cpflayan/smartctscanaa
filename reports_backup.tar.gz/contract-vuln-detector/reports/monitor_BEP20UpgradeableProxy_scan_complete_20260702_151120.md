# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:11:20
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` |
| contract_name | `BEP20UpgradeableProxy` |
| compiler_version | `v0.6.4+commit.1dca32f3` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `Apache-2.0` |
| proxy | `True` |
| implementation | `0xba5fe23f8a3a24bed3236f05f2fcf35fd0bf0b5c` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655008` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 3 |
| 🟡 MEDIUM | 7 |
| 🟢 LOW | 14 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 33 行
- **函数**: `_delegate()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
     30 | 
     31 |             // Call the implementation.
     32 |             // out and outsize are 0 because we don't know the size yet.
>>   33 |             let result := delegatecall(gas(), implementation, 0, calldatasize(), 0, 0)
     34 | 
     35 |             // Copy the returned data.
     36 |             returndatacopy(0, 0, returndatasize())
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 260 行
- **函数**: `_functionCallWithValue()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    257 |         _setImplementation(_logic);
    258 |         if(_data.length > 0) {
    259 |             // solhint-disable-next-line avoid-low-level-calls
>>  260 |             (bool success,) = _logic.delegatecall(_data);
    261 |             require(success);
    262 |         }
    263 |     }
```

---

### 3. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 432 行
- **函数**: `upgradeToAndCall()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    429 |     function upgradeToAndCall(address newImplementation, bytes calldata data) external payable ifAdmin {
    430 |         _upgradeTo(newImplementation);
    431 |         // solhint-disable-next-line avoid-low-level-calls
>>  432 |         (bool success,) = newImplementation.delegatecall(data);
    433 |         require(success);
    434 |     }
    435 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 383 行
- **函数**: `admin()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    380 |      * https://eth.wiki/json-rpc/API#eth_getstorageat[`eth_getStorageAt`] RPC call.
    381 |      * `0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103`
    382 |      */
>>  383 |     function admin() external ifAdmin returns (address) {
    384 |         return _admin();
    385 |     }
    386 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 396 行
- **函数**: `implementation()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    393 |      * https://eth.wiki/json-rpc/API#eth_getstorageat[`eth_getStorageAt`] RPC call.
    394 |      * `0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc`
    395 |      */
>>  396 |     function implementation() external ifAdmin returns (address) {
    397 |         return _implementation();
    398 |     }
    399 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 407 行
- **函数**: `changeAdmin()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    404 |      * 
    405 |      * NOTE: Only the admin can call this function. See {ProxyAdmin-changeProxyAdmin}.
    406 |      */
>>  407 |     function changeAdmin(address newAdmin) external ifAdmin {
    408 |         require(newAdmin != address(0), "TransparentUpgradeableProxy: new admin is the zero address");
    409 |         emit AdminChanged(_admin(), newAdmin);
    410 |         _setAdmin(newAdmin);
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 418 行
- **函数**: `upgradeTo()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    415 |      * 
    416 |      * NOTE: Only the admin can call this function. See {ProxyAdmin-upgrade}.
    417 |      */
>>  418 |     function upgradeTo(address newImplementation) external ifAdmin {
    419 |         _upgradeTo(newImplementation);
    420 |     }
    421 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 429 行
- **函数**: `upgradeToAndCall()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    426 |      * 
    427 |      * NOTE: Only the admin can call this function. See {ProxyAdmin-upgradeAndCall}.
    428 |      */
>>  429 |     function upgradeToAndCall(address newImplementation, bytes calldata data) external payable ifAdmin {
    430 |         _upgradeTo(newImplementation);
    431 |         // solhint-disable-next-line avoid-low-level-calls
    432 |         (bool success,) = newImplementation.delegatecall(data);
```

---

### 9. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 17 行
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     12 |  * Additionally, delegation to the implementation can be triggered manually through the {_fallback} function, or to a
     13 |  * different contract through the {_delegate} function.
     14 |  * 
     15 |  * The success and return data of the delegated call will be returned back to the caller of the proxy.
     16 |  */
>>   17 | abstract contract Proxy {
     18 |     /**
     19 |      * @dev Delegates the current call to `implementation`.
     20 |      * 
     21 |      * This function does not return to its internall call site, it will return directly to the external caller.
     22 |      */
```

---

### 10. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 248 行
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    243 |  * implementation behind the proxy.
    244 |  * 
    245 |  * Upgradeability is only provided internally through {_upgradeTo}. For an externally upgradeable proxy see
    246 |  * {TransparentUpgradeableProxy}.
    247 |  */
>>  248 | contract UpgradeableProxy is Proxy {
    249 |     /**
    250 |      * @dev Initializes the upgradeable proxy with an initial implementation specified by `_logic`.
    251 |      * 
    252 |      * If `_data` is nonempty, it's used as data in a delegate call to `_logic`. This will typically be an encoded
    253 |      * function call, and allows initializating the storage of the proxy like a Solidity constructor.
```

---

### 11. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 5 行
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
      2 | 
      3 | 
      4 | 
>>    5 | pragma solidity ^0.6.0;
      6 | 
      7 | /**
      8 |  * @dev This abstract contract provides a fallback function that delegates all calls to another contract using the EVM
```

---

### 12. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 91 行
- **函数**: `_beforeFallback()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
     88 | 
     89 | 
     90 | 
>>   91 | pragma solidity ^0.6.2;
     92 | 
     93 | /**
     94 |  * @dev Collection of functions related to the address type
```

---

### 13. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 235 行
- **函数**: `_functionCallWithValue()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    232 | 
    233 | 
    234 | 
>>  235 | pragma solidity ^0.6.0;
    236 | 
    237 | 
    238 | 
```

---

### 14. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 317 行
- **函数**: `_setImplementation()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    314 | 
    315 | 
    316 | 
>>  317 | pragma solidity ^0.6.0;
    318 | 
    319 | 
    320 | /**
```

---

### 15. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 470 行
- **函数**: `_beforeFallback()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    467 | 
    468 | // File: contracts/BEP20UpgradeableProxy.sol
    469 | 
>>  470 | pragma solidity ^0.6.0;
    471 | 
    472 | 
    473 | contract BEP20UpgradeableProxy is TransparentUpgradeableProxy {
```

---

### 16. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 275 行
- **函数**: `_functionCallWithValue()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    272 |      * This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1, and is
    273 |      * validated in the constructor.
    274 |      */
>>  275 |     bytes32 private constant _IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
    276 | 
    277 |     /**
    278 |      * @dev Returns the current implementation address.
```

---

### 17. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 361 行
- **函数**: `_setImplementation()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    358 |      * This is the keccak-256 hash of "eip1967.proxy.admin" subtracted by 1, and is
    359 |      * validated in the constructor.
    360 |      */
>>  361 |     bytes32 private constant _ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    362 | 
    363 |     /**
    364 |      * @dev Modifier used internally that will delegate the call to the implementation unless the sender is the admin.
```

---

### 18. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 25 行
- **函数**: `_delegate()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     22 |      */
     23 |     function _delegate(address implementation) internal {
     24 |         // solhint-disable-next-line no-inline-assembly
>>   25 |         assembly {
     26 |             // Copy msg.data. We take full control of memory in this inline assembly
     27 |             // block because it will not return to Solidity code. We overwrite the
     28 |             // Solidity scratch pad at memory position 0.
```

---

### 19. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 121 行
- **函数**: `isContract()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    118 | 
    119 |         uint256 size;
    120 |         // solhint-disable-next-line no-inline-assembly
>>  121 |         assembly { size := extcodesize(account) }
    122 |         return size > 0;
    123 |     }
    124 | 
```

---

### 20. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 220 行
- **函数**: `_functionCallWithValue()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    217 |                 // The easiest way to bubble the revert reason is using memory via assembly
    218 | 
    219 |                 // solhint-disable-next-line no-inline-assembly
>>  220 |                 assembly {
    221 |                     let returndata_size := mload(returndata)
    222 |                     revert(add(32, returndata), returndata_size)
    223 |                 }
```

---

### 21. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 283 行
- **函数**: `_implementation()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    280 |     function _implementation() internal override view returns (address impl) {
    281 |         bytes32 slot = _IMPLEMENTATION_SLOT;
    282 |         // solhint-disable-next-line no-inline-assembly
>>  283 |         assembly {
    284 |             impl := sload(slot)
    285 |         }
    286 |     }
```

---

### 22. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 307 行
- **函数**: `_setImplementation()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    304 |         bytes32 slot = _IMPLEMENTATION_SLOT;
    305 | 
    306 |         // solhint-disable-next-line no-inline-assembly
>>  307 |         assembly {
    308 |             sstore(slot, newImplementation)
    309 |         }
    310 |     }
```

---

### 23. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 442 行
- **函数**: `_admin()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    439 |     function _admin() internal view returns (address adm) {
    440 |         bytes32 slot = _ADMIN_SLOT;
    441 |         // solhint-disable-next-line no-inline-assembly
>>  442 |         assembly {
    443 |             adm := sload(slot)
    444 |         }
    445 |     }
```

---

### 24. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x570A5D26f7765Ecb712C0924E4De545B89fD43dF` 第 454 行
- **函数**: `_setAdmin()`
- **合约**: `provides`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    451 |         bytes32 slot = _ADMIN_SLOT;
    452 | 
    453 |         // solhint-disable-next-line no-inline-assembly
>>  454 |         assembly {
    455 |             sstore(slot, newAdmin)
    456 |         }
    457 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*