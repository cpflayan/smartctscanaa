# 智能合约安全审计报告

> 生成时间: 2026-07-02 12:45:03
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x10ED43C718714eb63d5aA57B78B54704E256024E` |
| contract_name | `PancakeRouter` |
| compiler_version | `v0.6.6+commit.6c089d02` |
| optimization_used | `True` |
| runs | `999999` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107638938` |

## 安全摘要

**整体风险等级**: UNKNOWN

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 56 |
| 🟢 LOW | 5 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 257 行
- **函数**: `getReserves()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    254 |     function factory() external view returns (address);
    255 |     function token0() external view returns (address);
    256 |     function token1() external view returns (address);
>>  257 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    258 |     function price0CumulativeLast() external view returns (uint);
    259 |     function price1CumulativeLast() external view returns (uint);
    260 |     function kLast() external view returns (uint);
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 302 行
- **函数**: `getReserves()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    299 |     function getReserves(address factory, address tokenA, address tokenB) internal view returns (uint reserveA, uint reserveB) {
    300 |         (address token0,) = sortTokens(tokenA, tokenB);
    301 |         pairFor(factory, tokenA, tokenB);
>>  302 |         (uint reserve0, uint reserve1,) = IPancakePair(pairFor(factory, tokenA, tokenB)).getReserves();
    303 |         (reserveA, reserveB) = tokenA == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
    304 |     }
    305 | 
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 712 行
- **函数**: `_swapSupportingFeeOnTransferTokens()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    709 |             uint amountInput;
    710 |             uint amountOutput;
    711 |             { // scope to avoid stack too deep errors
>>  712 |             (uint reserve0, uint reserve1,) = pair.getReserves();
    713 |             (uint reserveInput, uint reserveOutput) = input == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
    714 |             amountInput = IERC20(input).balanceOf(address(pair)).sub(reserveInput);
    715 |             amountOutput = PancakeLibrary.getAmountOut(amountInput, reserveInput, reserveOutput);
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 9 行
- **函数**: `safeApprove()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
      6 | library TransferHelper {
      7 |     function safeApprove(address token, address to, uint value) internal {
      8 |         // bytes4(keccak256(bytes('approve(address,uint256)')));
>>    9 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x095ea7b3, to, value));
     10 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: APPROVE_FAILED');
     11 |     }
     12 | 
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 15 行
- **函数**: `safeTransfer()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
     12 | 
     13 |     function safeTransfer(address token, address to, uint value) internal {
     14 |         // bytes4(keccak256(bytes('transfer(address,uint256)')));
>>   15 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
     16 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FAILED');
     17 |     }
     18 | 
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 21 行
- **函数**: `safeTransferFrom()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
     18 | 
     19 |     function safeTransferFrom(address token, address from, address to, uint value) internal {
     20 |         // bytes4(keccak256(bytes('transferFrom(address,address,uint256)')));
>>   21 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x23b872dd, from, to, value));
     22 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FROM_FAILED');
     23 |     }
     24 | 
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 26 行
- **函数**: `safeTransferETH()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     23 |     }
     24 | 
     25 |     function safeTransferETH(address to, uint value) internal {
>>   26 |         (bool success,) = to.call{value:value}(new bytes(0));
     27 |         require(success, 'TransferHelper: ETH_TRANSFER_FAILED');
     28 |     }
     29 | }
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 36 行
- **函数**: `factory()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     33 | pragma solidity >=0.6.2;
     34 | 
     35 | interface IPancakeRouter01 {
>>   36 |     function factory() external pure returns (address);
     37 |     function WETH() external pure returns (address);
     38 | 
     39 |     function addLiquidity(
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 37 行
- **函数**: `WETH()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     34 | 
     35 | interface IPancakeRouter01 {
     36 |     function factory() external pure returns (address);
>>   37 |     function WETH() external pure returns (address);
     38 | 
     39 |     function addLiquidity(
     40 |         address tokenA,
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 122 行
- **函数**: `quote()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    119 |         payable
    120 |         returns (uint[] memory amounts);
    121 | 
>>  122 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    123 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    124 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    125 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 123 行
- **函数**: `getAmountOut()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    120 |         returns (uint[] memory amounts);
    121 | 
    122 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
>>  123 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    124 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    125 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    126 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 124 行
- **函数**: `getAmountIn()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    121 | 
    122 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    123 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
>>  124 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    125 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    126 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
    127 | }
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 125 行
- **函数**: `getAmountsOut()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    122 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    123 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    124 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
>>  125 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    126 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
    127 | }
    128 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 126 行
- **函数**: `getAmountsIn()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    123 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    124 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    125 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
>>  126 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
    127 | }
    128 | 
    129 | // File: contracts\interfaces\IPancakeRouter02.sol
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 181 行
- **函数**: `feeTo()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    178 | interface IPancakeFactory {
    179 |     event PairCreated(address indexed token0, address indexed token1, address pair, uint);
    180 | 
>>  181 |     function feeTo() external view returns (address);
    182 |     function feeToSetter() external view returns (address);
    183 | 
    184 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 182 行
- **函数**: `feeToSetter()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    179 |     event PairCreated(address indexed token0, address indexed token1, address pair, uint);
    180 | 
    181 |     function feeTo() external view returns (address);
>>  182 |     function feeToSetter() external view returns (address);
    183 | 
    184 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    185 |     function allPairs(uint) external view returns (address pair);
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 184 行
- **函数**: `getPair()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    181 |     function feeTo() external view returns (address);
    182 |     function feeToSetter() external view returns (address);
    183 | 
>>  184 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    185 |     function allPairs(uint) external view returns (address pair);
    186 |     function allPairsLength() external view returns (uint);
    187 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 185 行
- **函数**: `allPairs()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    182 |     function feeToSetter() external view returns (address);
    183 | 
    184 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
>>  185 |     function allPairs(uint) external view returns (address pair);
    186 |     function allPairsLength() external view returns (uint);
    187 | 
    188 |     function createPair(address tokenA, address tokenB) external returns (address pair);
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 186 行
- **函数**: `allPairsLength()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    183 | 
    184 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    185 |     function allPairs(uint) external view returns (address pair);
>>  186 |     function allPairsLength() external view returns (uint);
    187 | 
    188 |     function createPair(address tokenA, address tokenB) external returns (address pair);
    189 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 188 行
- **函数**: `createPair()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    185 |     function allPairs(uint) external view returns (address pair);
    186 |     function allPairsLength() external view returns (uint);
    187 | 
>>  188 |     function createPair(address tokenA, address tokenB) external returns (address pair);
    189 | 
    190 |     function setFeeTo(address) external;
    191 |     function setFeeToSetter(address) external;
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 193 行
- **函数**: `INIT_CODE_PAIR_HASH()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    190 |     function setFeeTo(address) external;
    191 |     function setFeeToSetter(address) external;
    192 | 
>>  193 |     function INIT_CODE_PAIR_HASH() external view returns (bytes32);
    194 | }
    195 | 
    196 | // File: contracts\libraries\SafeMath.sol
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 224 行
- **函数**: `name()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    221 |     event Approval(address indexed owner, address indexed spender, uint value);
    222 |     event Transfer(address indexed from, address indexed to, uint value);
    223 | 
>>  224 |     function name() external pure returns (string memory);
    225 |     function symbol() external pure returns (string memory);
    226 |     function decimals() external pure returns (uint8);
    227 |     function totalSupply() external view returns (uint);
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 225 行
- **函数**: `symbol()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    222 |     event Transfer(address indexed from, address indexed to, uint value);
    223 | 
    224 |     function name() external pure returns (string memory);
>>  225 |     function symbol() external pure returns (string memory);
    226 |     function decimals() external pure returns (uint8);
    227 |     function totalSupply() external view returns (uint);
    228 |     function balanceOf(address owner) external view returns (uint);
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 226 行
- **函数**: `decimals()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    223 | 
    224 |     function name() external pure returns (string memory);
    225 |     function symbol() external pure returns (string memory);
>>  226 |     function decimals() external pure returns (uint8);
    227 |     function totalSupply() external view returns (uint);
    228 |     function balanceOf(address owner) external view returns (uint);
    229 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 227 行
- **函数**: `totalSupply()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    224 |     function name() external pure returns (string memory);
    225 |     function symbol() external pure returns (string memory);
    226 |     function decimals() external pure returns (uint8);
>>  227 |     function totalSupply() external view returns (uint);
    228 |     function balanceOf(address owner) external view returns (uint);
    229 |     function allowance(address owner, address spender) external view returns (uint);
    230 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 228 行
- **函数**: `balanceOf()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    225 |     function symbol() external pure returns (string memory);
    226 |     function decimals() external pure returns (uint8);
    227 |     function totalSupply() external view returns (uint);
>>  228 |     function balanceOf(address owner) external view returns (uint);
    229 |     function allowance(address owner, address spender) external view returns (uint);
    230 | 
    231 |     function approve(address spender, uint value) external returns (bool);
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 229 行
- **函数**: `allowance()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    226 |     function decimals() external pure returns (uint8);
    227 |     function totalSupply() external view returns (uint);
    228 |     function balanceOf(address owner) external view returns (uint);
>>  229 |     function allowance(address owner, address spender) external view returns (uint);
    230 | 
    231 |     function approve(address spender, uint value) external returns (bool);
    232 |     function transfer(address to, uint value) external returns (bool);
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 231 行
- **函数**: `approve()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    228 |     function balanceOf(address owner) external view returns (uint);
    229 |     function allowance(address owner, address spender) external view returns (uint);
    230 | 
>>  231 |     function approve(address spender, uint value) external returns (bool);
    232 |     function transfer(address to, uint value) external returns (bool);
    233 |     function transferFrom(address from, address to, uint value) external returns (bool);
    234 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 232 行
- **函数**: `transfer()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    229 |     function allowance(address owner, address spender) external view returns (uint);
    230 | 
    231 |     function approve(address spender, uint value) external returns (bool);
>>  232 |     function transfer(address to, uint value) external returns (bool);
    233 |     function transferFrom(address from, address to, uint value) external returns (bool);
    234 | 
    235 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 233 行
- **函数**: `transferFrom()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    230 | 
    231 |     function approve(address spender, uint value) external returns (bool);
    232 |     function transfer(address to, uint value) external returns (bool);
>>  233 |     function transferFrom(address from, address to, uint value) external returns (bool);
    234 | 
    235 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    236 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 235 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    232 |     function transfer(address to, uint value) external returns (bool);
    233 |     function transferFrom(address from, address to, uint value) external returns (bool);
    234 | 
>>  235 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    236 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
    237 |     function nonces(address owner) external view returns (uint);
    238 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 236 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    233 |     function transferFrom(address from, address to, uint value) external returns (bool);
    234 | 
    235 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>>  236 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
    237 |     function nonces(address owner) external view returns (uint);
    238 | 
    239 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 237 行
- **函数**: `nonces()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    234 | 
    235 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    236 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>>  237 |     function nonces(address owner) external view returns (uint);
    238 | 
    239 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
    240 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 253 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    250 |     );
    251 |     event Sync(uint112 reserve0, uint112 reserve1);
    252 | 
>>  253 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
    254 |     function factory() external view returns (address);
    255 |     function token0() external view returns (address);
    256 |     function token1() external view returns (address);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 254 行
- **函数**: `factory()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    251 |     event Sync(uint112 reserve0, uint112 reserve1);
    252 | 
    253 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
>>  254 |     function factory() external view returns (address);
    255 |     function token0() external view returns (address);
    256 |     function token1() external view returns (address);
    257 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 255 行
- **函数**: `token0()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    252 | 
    253 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
    254 |     function factory() external view returns (address);
>>  255 |     function token0() external view returns (address);
    256 |     function token1() external view returns (address);
    257 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    258 |     function price0CumulativeLast() external view returns (uint);
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 256 行
- **函数**: `token1()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    253 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
    254 |     function factory() external view returns (address);
    255 |     function token0() external view returns (address);
>>  256 |     function token1() external view returns (address);
    257 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    258 |     function price0CumulativeLast() external view returns (uint);
    259 |     function price1CumulativeLast() external view returns (uint);
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 257 行
- **函数**: `getReserves()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    254 |     function factory() external view returns (address);
    255 |     function token0() external view returns (address);
    256 |     function token1() external view returns (address);
>>  257 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    258 |     function price0CumulativeLast() external view returns (uint);
    259 |     function price1CumulativeLast() external view returns (uint);
    260 |     function kLast() external view returns (uint);
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 258 行
- **函数**: `price0CumulativeLast()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    255 |     function token0() external view returns (address);
    256 |     function token1() external view returns (address);
    257 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>>  258 |     function price0CumulativeLast() external view returns (uint);
    259 |     function price1CumulativeLast() external view returns (uint);
    260 |     function kLast() external view returns (uint);
    261 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 259 行
- **函数**: `price1CumulativeLast()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    256 |     function token1() external view returns (address);
    257 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    258 |     function price0CumulativeLast() external view returns (uint);
>>  259 |     function price1CumulativeLast() external view returns (uint);
    260 |     function kLast() external view returns (uint);
    261 | 
    262 |     function mint(address to) external returns (uint liquidity);
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 260 行
- **函数**: `kLast()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    257 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    258 |     function price0CumulativeLast() external view returns (uint);
    259 |     function price1CumulativeLast() external view returns (uint);
>>  260 |     function kLast() external view returns (uint);
    261 | 
    262 |     function mint(address to) external returns (uint liquidity);
    263 |     function burn(address to) external returns (uint amount0, uint amount1);
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 262 行
- **函数**: `mint()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    259 |     function price1CumulativeLast() external view returns (uint);
    260 |     function kLast() external view returns (uint);
    261 | 
>>  262 |     function mint(address to) external returns (uint liquidity);
    263 |     function burn(address to) external returns (uint amount0, uint amount1);
    264 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    265 |     function skim(address to) external;
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 263 行
- **函数**: `burn()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    260 |     function kLast() external view returns (uint);
    261 | 
    262 |     function mint(address to) external returns (uint liquidity);
>>  263 |     function burn(address to) external returns (uint amount0, uint amount1);
    264 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    265 |     function skim(address to) external;
    266 |     function sync() external;
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 363 行
- **函数**: `name()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    360 |     event Approval(address indexed owner, address indexed spender, uint value);
    361 |     event Transfer(address indexed from, address indexed to, uint value);
    362 | 
>>  363 |     function name() external view returns (string memory);
    364 |     function symbol() external view returns (string memory);
    365 |     function decimals() external view returns (uint8);
    366 |     function totalSupply() external view returns (uint);
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 364 行
- **函数**: `symbol()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    361 |     event Transfer(address indexed from, address indexed to, uint value);
    362 | 
    363 |     function name() external view returns (string memory);
>>  364 |     function symbol() external view returns (string memory);
    365 |     function decimals() external view returns (uint8);
    366 |     function totalSupply() external view returns (uint);
    367 |     function balanceOf(address owner) external view returns (uint);
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 365 行
- **函数**: `decimals()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    362 | 
    363 |     function name() external view returns (string memory);
    364 |     function symbol() external view returns (string memory);
>>  365 |     function decimals() external view returns (uint8);
    366 |     function totalSupply() external view returns (uint);
    367 |     function balanceOf(address owner) external view returns (uint);
    368 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 366 行
- **函数**: `totalSupply()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    363 |     function name() external view returns (string memory);
    364 |     function symbol() external view returns (string memory);
    365 |     function decimals() external view returns (uint8);
>>  366 |     function totalSupply() external view returns (uint);
    367 |     function balanceOf(address owner) external view returns (uint);
    368 |     function allowance(address owner, address spender) external view returns (uint);
    369 | 
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 367 行
- **函数**: `balanceOf()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    364 |     function symbol() external view returns (string memory);
    365 |     function decimals() external view returns (uint8);
    366 |     function totalSupply() external view returns (uint);
>>  367 |     function balanceOf(address owner) external view returns (uint);
    368 |     function allowance(address owner, address spender) external view returns (uint);
    369 | 
    370 |     function approve(address spender, uint value) external returns (bool);
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 368 行
- **函数**: `allowance()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    365 |     function decimals() external view returns (uint8);
    366 |     function totalSupply() external view returns (uint);
    367 |     function balanceOf(address owner) external view returns (uint);
>>  368 |     function allowance(address owner, address spender) external view returns (uint);
    369 | 
    370 |     function approve(address spender, uint value) external returns (bool);
    371 |     function transfer(address to, uint value) external returns (bool);
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 370 行
- **函数**: `approve()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    367 |     function balanceOf(address owner) external view returns (uint);
    368 |     function allowance(address owner, address spender) external view returns (uint);
    369 | 
>>  370 |     function approve(address spender, uint value) external returns (bool);
    371 |     function transfer(address to, uint value) external returns (bool);
    372 |     function transferFrom(address from, address to, uint value) external returns (bool);
    373 | }
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 371 行
- **函数**: `transfer()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    368 |     function allowance(address owner, address spender) external view returns (uint);
    369 | 
    370 |     function approve(address spender, uint value) external returns (bool);
>>  371 |     function transfer(address to, uint value) external returns (bool);
    372 |     function transferFrom(address from, address to, uint value) external returns (bool);
    373 | }
    374 | 
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 372 行
- **函数**: `transferFrom()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    369 | 
    370 |     function approve(address spender, uint value) external returns (bool);
    371 |     function transfer(address to, uint value) external returns (bool);
>>  372 |     function transferFrom(address from, address to, uint value) external returns (bool);
    373 | }
    374 | 
    375 | // File: contracts\interfaces\IWETH.sol
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 380 行
- **函数**: `deposit()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    377 | pragma solidity >=0.5.0;
    378 | 
    379 | interface IWETH {
>>  380 |     function deposit() external payable;
    381 |     function transfer(address to, uint value) external returns (bool);
    382 |     function withdraw(uint) external;
    383 | }
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 381 行
- **函数**: `transfer()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    378 | 
    379 | interface IWETH {
    380 |     function deposit() external payable;
>>  381 |     function transfer(address to, uint value) external returns (bool);
    382 |     function withdraw(uint) external;
    383 | }
    384 | 
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 786 行
- **函数**: `quote()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    783 |     }
    784 | 
    785 |     // **** LIBRARY FUNCTIONS ****
>>  786 |     function quote(uint amountA, uint reserveA, uint reserveB) public pure virtual override returns (uint amountB) {
    787 |         return PancakeLibrary.quote(amountA, reserveA, reserveB);
    788 |     }
    789 | 
```

---

### 56. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 395 行
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    390 | 
    391 | 
    392 | 
    393 | 
    394 | 
>>  395 | contract PancakeRouter is IPancakeRouter02 {
    396 |     using SafeMath for uint;
    397 | 
    398 |     address public immutable override factory;
    399 |     address public immutable override WETH;
    400 | 
```

---

### 57. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 402 行
- **函数**: `withdraw()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    399 |     address public immutable override WETH;
    400 | 
    401 |     modifier ensure(uint deadline) {
>>  402 |         require(deadline >= block.timestamp, 'PancakeRouter: EXPIRED');
    403 |         _;
    404 |     }
    405 | 
```

---

### 58. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 479 行
- **函数**: `addLiquidityETH()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    476 |         address pair = PancakeLibrary.pairFor(factory, token, WETH);
    477 |         TransferHelper.safeTransferFrom(token, msg.sender, pair, amountToken);
    478 |         IWETH(WETH).deposit{value: amountETH}();
>>  479 |         assert(IWETH(WETH).transfer(pair, amountETH));
    480 |         liquidity = IPancakePair(pair).mint(to);
    481 |         // refund dust eth, if any
    482 |         if (msg.value > amountETH) TransferHelper.safeTransferETH(msg.sender, msg.value - amountETH);
```

---

### 59. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 647 行
- **函数**: `swapExactETHForTokens()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    644 |         amounts = PancakeLibrary.getAmountsOut(factory, msg.value, path);
    645 |         require(amounts[amounts.length - 1] >= amountOutMin, 'PancakeRouter: INSUFFICIENT_OUTPUT_AMOUNT');
    646 |         IWETH(WETH).deposit{value: amounts[0]}();
>>  647 |         assert(IWETH(WETH).transfer(PancakeLibrary.pairFor(factory, path[0], path[1]), amounts[0]));
    648 |         _swap(amounts, path, to);
    649 |     }
    650 |     function swapTokensForExactETH(uint amountOut, uint amountInMax, address[] calldata path, address to, uint deadline)
```

---

### 60. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 696 行
- **函数**: `swapETHForExactTokens()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    693 |         amounts = PancakeLibrary.getAmountsIn(factory, amountOut, path);
    694 |         require(amounts[0] <= msg.value, 'PancakeRouter: EXCESSIVE_INPUT_AMOUNT');
    695 |         IWETH(WETH).deposit{value: amounts[0]}();
>>  696 |         assert(IWETH(WETH).transfer(PancakeLibrary.pairFor(factory, path[0], path[1]), amounts[0]));
    697 |         _swap(amounts, path, to);
    698 |         // refund dust eth, if any
    699 |         if (msg.value > amounts[0]) TransferHelper.safeTransferETH(msg.sender, msg.value - amounts[0]);
```

---

### 61. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x10ED43C718714eb63d5aA57B78B54704E256024E` 第 754 行
- **函数**: `swapExactETHForTokensSupportingFeeOnTransferTokens()`
- **合约**: `PancakeRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    751 |         require(path[0] == WETH, 'PancakeRouter: INVALID_PATH');
    752 |         uint amountIn = msg.value;
    753 |         IWETH(WETH).deposit{value: amountIn}();
>>  754 |         assert(IWETH(WETH).transfer(PancakeLibrary.pairFor(factory, path[0], path[1]), amountIn));
    755 |         uint balanceBefore = IERC20(path[path.length - 1]).balanceOf(to);
    756 |         _swapSupportingFeeOnTransferTokens(path, to);
    757 |         require(
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*