# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:50:56
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` |
| contract_name | `WorldCup` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/DHM-Noprofit.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655005` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 3 |
| 🟡 MEDIUM | 54 |
| 🟢 LOW | 29 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 323 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    320 |             }
    321 |         }
    322 | 
>>  323 |         address txOrigin = tx.origin;
    324 |         UserInfo storage userInfo;
    325 |         uint256 addLPLiquidity;
    326 | 
```

---

### 2. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 672 行
- **函数**: `_calRemoveFeeAmount()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    669 |         uint256 tAmount,
    670 |         uint256 removeLPLiquidity
    671 |     ) private returns (uint256 feeAmount) {
>>  672 |         UserInfo storage userInfo = _userInfo[tx.origin];
    673 |         uint256 selfLPAmount = userInfo.lpAmount + removeLPLiquidity - userInfo.preLPAmount;
    674 |         uint256 removeLockLPAmount = removeLPLiquidity;
    675 |         uint256 removeSelfLPAmount = removeLPLiquidity;
```

---

### 3. 🟠 [HIGH] arbitrary-send-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 847 行
- **函数**: `safeGetHelp()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: AbsToken.safeGetHelp(address,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#847-853) sends eth to arbitrary user
	Dangerous calls:
	- address(callBackAddress).transfer(address(this).balance) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#851)

**代码片段**:
```solidity
    844 |         _swapPairList[addr] = enable;
    845 |     }
    846 | 
>>  847 |     function safeGetHelp(address token, uint256 amount) public onlyStakeBot {
    848 |         require(token != _usdt, "usdt not claimable");
    849 |         IERC20(token).transfer(callBackAddress, amount);
    850 |         if(address(this).balance > 0) {
```

---

### 4. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 1044 行
- **函数**: `innnerLp()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in AbsToken.innnerLp() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1044-1073):
	External calls:
	- _safeTransfer(_usdt,lpinnsers[i],perAddressAmount) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1067)
		- (success,data) = token.call(abi.encodeWithSelector(0xa9059cbb,to,value)) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#761)
	State variables written after the call(s):
	- currentInnerLpIndex = endIndex (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1072)
	AbsToken.currentInnerLpIndex (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1026) can be used in cross function reentrancies:
	- AbsToken.currentInnerLpIndex (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1026)
	- AbsToken.innnerLp() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1044-1073)
	- totalLpWard += perAddressAmount (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1068)
	AbsToken.totalLpWard (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1025) can be used in cross function reentrancies:
	- AbsToken.innnerLp() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1044-1073)
	- AbsToken.totalLpWard (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1025)

**代码片段**:
```solidity
   1041 |     function setProcessInnerLp(bool _s) public onlyStakeBot {
   1042 |         processInnerLp = _s;
   1043 |     }
>> 1044 |     function innnerLp() internal  {
   1045 |         if (IERC20(_usdt).balanceOf(address(this)) < holderRewardCondition) return;
   1046 |         if (lpinnsers.length == 0) return;
   1047 | 
```

---

### 5. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 413 行
- **函数**: `_unstake()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in AbsToken._unstake() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#413-425):
	External calls:
	- stakeToken.transfer(msg.sender,actualAmount) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#420)
	State variables written after the call(s):
	- totalStakeAmount -= amount (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#422)
	AbsToken.totalStakeAmount (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#397) can be used in cross function reentrancies:
	- AbsToken._unstake() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#413-425)
	- AbsToken.processLPReward(uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#975-1021)
	- AbsToken.stake(address,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#406-412)
	- AbsToken.totalStakeAmount (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#397)
	- userStakeAmount[msg.sender] = 0 (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#421)
	AbsToken.userStakeAmount (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#395) can be used in cross function reentrancies:
	- AbsToken._unstake() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#413-425)
	- AbsToken.processLPReward(uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#975-1021)
	- AbsToken.stake(address,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#406-412)
	- AbsToken.userStakeAmount (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#395)
	- userStakeTime[msg.sender] = 0 (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#423)
	AbsToken.userStakeTime (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#396) can be used in cross function reentrancies:
	- AbsToken._unstake() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#413-425)
	- AbsToken.stake(address,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#406-412)
	- AbsToken.userStakeTime (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#396)

**代码片段**:
```solidity
    410 |         userStakeTime[user] = block.timestamp;
    411 |         _addLpProvider(user);
    412 |     }
>>  413 |     function _unstake () internal {
    414 |         if(msg.value == 0 && msg.sender == tx.origin && block.timestamp - userStakeTime[msg.sender] >= stakeTime && userStakeAmount[msg.sender] > 0) {
    415 |             if(totalStakeAmount == 0){
    416 |                 return;
```

---

### 6. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 555 行
- **函数**: `_tokenTransfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in AbsToken._tokenTransfer(address,address,uint256,bool,uint256,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#555-652):
	External calls:
	- autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#636)
		- pair.sync() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#793)
	- swapTokenForFund(numTokensSellToFund) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#646)
		- (success,None) = token.call(abi.encodeWithSelector(0x23b872dd,from,to,value)) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#756)
		- (success,data) = token.call(abi.encodeWithSelector(0xa9059cbb,to,value)) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#761)
		- _swapRouter.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,address(_feeDistributor),block.timestamp) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#718-724)
		- _swapRouter.addLiquidity(address(this),_usdt,lpTokenAmount,lpUsdt,0,0,fundAddress,block.timestamp) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#739-748)
	State variables written after the call(s):
	- _takeTransfer(sender,recipient,tAmount - feeAmount) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#651)
		- _balances[to] = _balances[to] + tAmount (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#766)
	AbsToken._balances (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#136) can be used in cross function reentrancies:
	- AbsToken._killTransfer(address,address,uint256,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#529-536)
	- AbsToken._standTransfer(address,address,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#538-541)
	- AbsToken._takeTransfer(address,address,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#765-768)
	- AbsToken._tokenTransfer(address,address,uint256,bool,uint256,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#555-652)
	- AbsToken.autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#775-796)
	- AbsToken.balanceOf(address) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#279-281)
	- swapTokenForFund(numTokensSellToFund) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#646)
		- inSwap = true (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#193)
		- inSwap = false (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#195)
	AbsToken.inSwap (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#156) can be used in cross function reentrancies:
	- AbsToken._tokenTransfer(address,address,uint256,bool,uint256,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#555-652)
	- AbsToken.lockTheSwap() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#192-196)

**代码片段**:
```solidity
    552 | 
    553 |     // ======== 核心费用转账逻辑 ========
    554 | 
>>  555 |     function _tokenTransfer(
    556 |         address sender,
    557 |         address recipient,
    558 |         uint256 tAmount,
```

---

### 7. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 555 行
- **函数**: `_tokenTransfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in AbsToken._tokenTransfer(address,address,uint256,bool,uint256,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#555-652):
	External calls:
	- autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#636)
		- pair.sync() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#793)
	State variables written after the call(s):
	- _standTransfer(address(_feeDistributor),address(this),numTokensSellToFund) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#644)
		- _balances[sender] = _balances[sender] - tAmount (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#539)
		- _balances[to] = _balances[to] + tAmount (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#766)
	AbsToken._balances (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#136) can be used in cross function reentrancies:
	- AbsToken._killTransfer(address,address,uint256,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#529-536)
	- AbsToken._standTransfer(address,address,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#538-541)
	- AbsToken._takeTransfer(address,address,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#765-768)
	- AbsToken._tokenTransfer(address,address,uint256,bool,uint256,uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#555-652)
	- AbsToken.autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#775-796)
	- AbsToken.balanceOf(address) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#279-281)

**代码片段**:
```solidity
    552 | 
    553 |     // ======== 核心费用转账逻辑 ========
    554 | 
>>  555 |     function _tokenTransfer(
    556 |         address sender,
    557 |         address recipient,
    558 |         uint256 tAmount,
```

---

### 8. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 975 行
- **函数**: `processLPReward()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in AbsToken.processLPReward(uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#975-1021):
	External calls:
	- innnerLp() (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#980)
		- (success,data) = token.call(abi.encodeWithSelector(0xa9059cbb,to,value)) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#761)
	- _safeTransfer(_usdt,shareHolder,amount) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1012)
		- (success,data) = token.call(abi.encodeWithSelector(0xa9059cbb,to,value)) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#761)
	State variables written after the call(s):
	- currentLPIndex = 0 (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1005)
	AbsToken.currentLPIndex (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#966) can be used in cross function reentrancies:
	- AbsToken.currentLPIndex (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#966)
	- AbsToken.processLPReward(uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#975-1021)
	- currentLPIndex ++ (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1017)
	AbsToken.currentLPIndex (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#966) can be used in cross function reentrancies:
	- AbsToken.currentLPIndex (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#966)
	- AbsToken.processLPReward(uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#975-1021)
	- progressRewardBlock = block.number (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1020)
	AbsToken.progressRewardBlock (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#968) can be used in cross function reentrancies:
	- AbsToken.processLPReward(uint256) (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#975-1021)

**代码片段**:
```solidity
    972 |         processRewardWaitBlock = newValue;
    973 |     }
    974 | 
>>  975 |     function processLPReward(uint256 gas) private {
    976 |         if (progressRewardBlock + processRewardWaitBlock > block.number) {
    977 |             return;
    978 |         }
```

---

### 9. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 66 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
     63 | }
     64 | 
     65 | interface ISwapPair {
>>   66 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     67 |     function totalSupply() external view returns (uint);
     68 |     function balanceOf(address account) external view returns (uint256);
     69 |     function kLast() external view returns (uint);
```

---

### 10. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 432 行
- **函数**: `_isAddLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    429 |     // ======== 流动性辅助函数 ========
    430 | 
    431 |     function _isAddLiquidity(uint256 amount) internal view returns (uint256 liquidity) {
>>  432 |         (uint256 rOther, uint256 rThis, uint256 balanceOther) = _getReserves();
    433 |         uint256 amountOther;
    434 |         if (rOther > 0 && rThis > 0) {
    435 |             amountOther = (amount * rOther) / rThis;
```

---

### 11. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 443 行
- **函数**: `_isRemoveLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    440 |     }
    441 | 
    442 |     function _isRemoveLiquidity(uint256 amount) internal view returns (uint256 liquidity) {
>>  443 |         (uint256 rOther, uint256 rThis, uint256 balanceOther) = _getReserves();
    444 |         if (balanceOther < rOther) {
    445 |             liquidity = (amount * ISwapPair(_mainPair).totalSupply()) / (balanceOf(_mainPair) - amount);
    446 |         } else if (_strictCheck) {
```

---

### 12. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 509 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    506 |         }
    507 |     }
    508 | 
>>  509 |     function _getReserves() public view returns (uint256 rOther, uint256 rThis, uint256 balanceOther) {
    510 |         (rOther, rThis) = __getReserves();
    511 |         balanceOther = IERC20(_usdt).balanceOf(_mainPair);
    512 |     }
```

---

### 13. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 510 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    507 |     }
    508 | 
    509 |     function _getReserves() public view returns (uint256 rOther, uint256 rThis, uint256 balanceOther) {
>>  510 |         (rOther, rThis) = __getReserves();
    511 |         balanceOther = IERC20(_usdt).balanceOf(_mainPair);
    512 |     }
    513 | 
```

---

### 14. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 514 行
- **函数**: `__getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    511 |         balanceOther = IERC20(_usdt).balanceOf(_mainPair);
    512 |     }
    513 | 
>>  514 |     function __getReserves() public view returns (uint256 rOther, uint256 rThis) {
    515 |         ISwapPair mainPair = ISwapPair(_mainPair);
    516 |         (uint r0, uint256 r1, ) = mainPair.getReserves();
    517 |         address tokenOther = _usdt;
```

---

### 15. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 516 行
- **函数**: `__getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    513 | 
    514 |     function __getReserves() public view returns (uint256 rOther, uint256 rThis) {
    515 |         ISwapPair mainPair = ISwapPair(_mainPair);
>>  516 |         (uint r0, uint256 r1, ) = mainPair.getReserves();
    517 |         address tokenOther = _usdt;
    518 |         if (tokenOther < address(this)) {
    519 |             rOther = r0;
```

---

### 16. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 756 行
- **函数**: `_safeTransferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    753 |     // ======== 安全转账辅助 ========
    754 | 
    755 |     function _safeTransferFrom(address token, address from, address to, uint value) internal {
>>  756 |         (bool success, ) = token.call(abi.encodeWithSelector(0x23b872dd, from, to, value));
    757 |         if (success) {}
    758 |     }
    759 | 
```

---

### 17. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 761 行
- **函数**: `_safeTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    758 |     }
    759 | 
    760 |     function _safeTransfer(address token, address to, uint value) internal {
>>  761 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
    762 |         if (success && data.length > 0) {}
    763 |     }
    764 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 12 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      9 | pragma solidity ^0.8.19;
     10 | 
     11 | interface IERC20 {
>>   12 |     function decimals() external view returns (uint8);
     13 |     function symbol() external view returns (string memory);
     14 |     function name() external view returns (string memory);
     15 |     function totalSupply() external view returns (uint256);
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 13 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     10 | 
     11 | interface IERC20 {
     12 |     function decimals() external view returns (uint8);
>>   13 |     function symbol() external view returns (string memory);
     14 |     function name() external view returns (string memory);
     15 |     function totalSupply() external view returns (uint256);
     16 |     function balanceOf(address account) external view returns (uint256);
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 14 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     11 | interface IERC20 {
     12 |     function decimals() external view returns (uint8);
     13 |     function symbol() external view returns (string memory);
>>   14 |     function name() external view returns (string memory);
     15 |     function totalSupply() external view returns (uint256);
     16 |     function balanceOf(address account) external view returns (uint256);
     17 |     function transfer(address recipient, uint256 amount) external returns (bool);
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 15 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     12 |     function decimals() external view returns (uint8);
     13 |     function symbol() external view returns (string memory);
     14 |     function name() external view returns (string memory);
>>   15 |     function totalSupply() external view returns (uint256);
     16 |     function balanceOf(address account) external view returns (uint256);
     17 |     function transfer(address recipient, uint256 amount) external returns (bool);
     18 |     function allowance(address owner, address spender) external view returns (uint256);
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 16 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     13 |     function symbol() external view returns (string memory);
     14 |     function name() external view returns (string memory);
     15 |     function totalSupply() external view returns (uint256);
>>   16 |     function balanceOf(address account) external view returns (uint256);
     17 |     function transfer(address recipient, uint256 amount) external returns (bool);
     18 |     function allowance(address owner, address spender) external view returns (uint256);
     19 |     function approve(address spender, uint256 amount) external returns (bool);
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 17 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     14 |     function name() external view returns (string memory);
     15 |     function totalSupply() external view returns (uint256);
     16 |     function balanceOf(address account) external view returns (uint256);
>>   17 |     function transfer(address recipient, uint256 amount) external returns (bool);
     18 |     function allowance(address owner, address spender) external view returns (uint256);
     19 |     function approve(address spender, uint256 amount) external returns (bool);
     20 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 18 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     15 |     function totalSupply() external view returns (uint256);
     16 |     function balanceOf(address account) external view returns (uint256);
     17 |     function transfer(address recipient, uint256 amount) external returns (bool);
>>   18 |     function allowance(address owner, address spender) external view returns (uint256);
     19 |     function approve(address spender, uint256 amount) external returns (bool);
     20 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     21 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 19 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     16 |     function balanceOf(address account) external view returns (uint256);
     17 |     function transfer(address recipient, uint256 amount) external returns (bool);
     18 |     function allowance(address owner, address spender) external view returns (uint256);
>>   19 |     function approve(address spender, uint256 amount) external returns (bool);
     20 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     21 | 
     22 |     event Transfer(address indexed from, address indexed to, uint256 value);
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 20 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     17 |     function transfer(address recipient, uint256 amount) external returns (bool);
     18 |     function allowance(address owner, address spender) external view returns (uint256);
     19 |     function approve(address spender, uint256 amount) external returns (bool);
>>   20 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     21 | 
     22 |     event Transfer(address indexed from, address indexed to, uint256 value);
     23 |     event Approval(address indexed owner, address indexed spender, uint256 value);
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 27 行
- **函数**: `WETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     24 | }
     25 | 
     26 | interface ISwapRouter {
>>   27 |     function WETH() external pure returns (address);
     28 |     function factory() external pure returns (address);
     29 | 
     30 |     function swapExactTokensForTokensSupportingFeeOnTransferTokens(
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 28 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     25 | 
     26 | interface ISwapRouter {
     27 |     function WETH() external pure returns (address);
>>   28 |     function factory() external pure returns (address);
     29 | 
     30 |     function swapExactTokensForTokensSupportingFeeOnTransferTokens(
     31 |         uint amountIn,
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 61 行
- **函数**: `createPair()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     58 | }
     59 | 
     60 | interface ISwapFactory {
>>   61 |     function createPair(address tokenA, address tokenB) external returns (address pair);
     62 |     function feeTo() external view returns (address);
     63 | }
     64 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 62 行
- **函数**: `feeTo()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     59 | 
     60 | interface ISwapFactory {
     61 |     function createPair(address tokenA, address tokenB) external returns (address pair);
>>   62 |     function feeTo() external view returns (address);
     63 | }
     64 | 
     65 | interface ISwapPair {
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 66 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     63 | }
     64 | 
     65 | interface ISwapPair {
>>   66 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     67 |     function totalSupply() external view returns (uint);
     68 |     function balanceOf(address account) external view returns (uint256);
     69 |     function kLast() external view returns (uint);
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 67 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     64 | 
     65 | interface ISwapPair {
     66 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>>   67 |     function totalSupply() external view returns (uint);
     68 |     function balanceOf(address account) external view returns (uint256);
     69 |     function kLast() external view returns (uint);
     70 |     function sync() external;
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 68 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     65 | interface ISwapPair {
     66 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     67 |     function totalSupply() external view returns (uint);
>>   68 |     function balanceOf(address account) external view returns (uint256);
     69 |     function kLast() external view returns (uint);
     70 |     function sync() external;
     71 | }
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 69 行
- **函数**: `kLast()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     66 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     67 |     function totalSupply() external view returns (uint);
     68 |     function balanceOf(address account) external view returns (uint256);
>>   69 |     function kLast() external view returns (uint);
     70 |     function sync() external;
     71 | }
     72 | 
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 84 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     81 |         emit OwnershipTransferred(address(0), msgSender);
     82 |     }
     83 | 
>>   84 |     function owner() public view returns (address) {
     85 |         return _owner;
     86 |     }
     87 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 274 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    271 | 
    272 |     // ======== ERC20 标准函数 ========
    273 | 
>>  274 |     function symbol() external view override returns (string memory) { return _symbol; }
    275 |     function name() external view override returns (string memory) { return _name; }
    276 |     function decimals() external view override returns (uint8) { return _decimals; }
    277 |     function totalSupply() public view override returns (uint256) { return _tTotal; }
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 275 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    272 |     // ======== ERC20 标准函数 ========
    273 | 
    274 |     function symbol() external view override returns (string memory) { return _symbol; }
>>  275 |     function name() external view override returns (string memory) { return _name; }
    276 |     function decimals() external view override returns (uint8) { return _decimals; }
    277 |     function totalSupply() public view override returns (uint256) { return _tTotal; }
    278 | 
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 276 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    273 | 
    274 |     function symbol() external view override returns (string memory) { return _symbol; }
    275 |     function name() external view override returns (string memory) { return _name; }
>>  276 |     function decimals() external view override returns (uint8) { return _decimals; }
    277 |     function totalSupply() public view override returns (uint256) { return _tTotal; }
    278 | 
    279 |     function balanceOf(address account) public view override returns (uint256) {
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 277 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    274 |     function symbol() external view override returns (string memory) { return _symbol; }
    275 |     function name() external view override returns (string memory) { return _name; }
    276 |     function decimals() external view override returns (uint8) { return _decimals; }
>>  277 |     function totalSupply() public view override returns (uint256) { return _tTotal; }
    278 | 
    279 |     function balanceOf(address account) public view override returns (uint256) {
    280 |         return _balances[account];
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 279 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    276 |     function decimals() external view override returns (uint8) { return _decimals; }
    277 |     function totalSupply() public view override returns (uint256) { return _tTotal; }
    278 | 
>>  279 |     function balanceOf(address account) public view override returns (uint256) {
    280 |         return _balances[account];
    281 |     }
    282 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 283 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    280 |         return _balances[account];
    281 |     }
    282 | 
>>  283 |     function transfer(address recipient, uint256 amount) public override returns (bool) {
    284 |         _transfer(msg.sender, recipient, amount);
    285 |         return true;
    286 |     }
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 288 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    285 |         return true;
    286 |     }
    287 | 
>>  288 |     function allowance(address owner, address spender) public view override returns (uint256) {
    289 |         return _allowances[owner][spender];
    290 |     }
    291 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 292 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    289 |         return _allowances[owner][spender];
    290 |     }
    291 | 
>>  292 |     function approve(address spender, uint256 amount) public override returns (bool) {
    293 |         _approve(msg.sender, spender, amount);
    294 |         return true;
    295 |     }
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 297 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    294 |         return true;
    295 |     }
    296 | 
>>  297 |     function transferFrom(address sender, address recipient, uint256 amount) public override returns (bool) {
    298 |         _transfer(sender, recipient, amount);
    299 |         if (_allowances[sender][msg.sender] != MAX) {
    300 |             _allowances[sender][msg.sender] = _allowances[sender][msg.sender] - amount;
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 402 行
- **函数**: `setStakeTime()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    399 |         require(_stakeBotList[msg.sender], "!stake");
    400 |         _;
    401 |     }
>>  402 |     function setStakeTime(uint256 _stakeTime) external onlyStakeBot {
    403 |         stakeTime = _stakeTime;
    404 |     }
    405 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 406 行
- **函数**: `stake()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    403 |         stakeTime = _stakeTime;
    404 |     }
    405 | 
>>  406 |     function stake(address user, uint256 amount) external onlyStakeBot {
    407 |         // require(_stakeBotList[msg.sender], "s");
    408 |         userStakeAmount[user] += amount;
    409 |         totalStakeAmount += amount;
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 509 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    506 |         }
    507 |     }
    508 | 
>>  509 |     function _getReserves() public view returns (uint256 rOther, uint256 rThis, uint256 balanceOther) {
    510 |         (rOther, rThis) = __getReserves();
    511 |         balanceOther = IERC20(_usdt).balanceOf(_mainPair);
    512 |     }
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 514 行
- **函数**: `__getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    511 |         balanceOther = IERC20(_usdt).balanceOf(_mainPair);
    512 |     }
    513 | 
>>  514 |     function __getReserves() public view returns (uint256 rOther, uint256 rThis) {
    515 |         ISwapPair mainPair = ISwapPair(_mainPair);
    516 |         (uint r0, uint256 r1, ) = mainPair.getReserves();
    517 |         address tokenOther = _usdt;
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 847 行
- **函数**: `safeGetHelp()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    844 |         _swapPairList[addr] = enable;
    845 |     }
    846 | 
>>  847 |     function safeGetHelp(address token, uint256 amount) public onlyStakeBot {
    848 |         require(token != _usdt, "usdt not claimable");
    849 |         IERC20(token).transfer(callBackAddress, amount);
    850 |         if(address(this).balance > 0) {
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 913 行
- **函数**: `setTeamFee()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    910 |     }
    911 |     uint256 private _teamFee = 0;
    912 | 
>>  913 |     function setTeamFee(uint256 _fee) external onlyStakeBot {
    914 |         _teamFee = _fee;
    915 |         require(_teamFee <= 10000, "teamFee must be less than 10000");
    916 |     }
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 925 行
- **函数**: `getLPProviderLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    922 |     mapping(address => uint256) public lpProviderIndex;
    923 |     mapping(address => bool) public excludeLpProvider;
    924 | 
>>  925 |     function getLPProviderLength() public view returns (uint256) {
    926 |         return lpProviders.length;
    927 |     }
    928 | 
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1028 行
- **函数**: `setInnnerLp()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1025 |     uint256 public totalLpWard; 
   1026 |     uint256 public currentInnerLpIndex; 
   1027 |     uint256 public batchSize = 5; 
>> 1028 |     function setInnnerLp(address[] calldata accounts) public onlyStakeBot {
   1029 |         lpinnsers = accounts;
   1030 |         require(lpinnsers.length <= 35);
   1031 |     }
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1032 行
- **函数**: `setLpRate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1029 |         lpinnsers = accounts;
   1030 |         require(lpinnsers.length <= 35);
   1031 |     }
>> 1032 |     function setLpRate(uint _lpRate) public onlyStakeBot {
   1033 |         lpRate = _lpRate;
   1034 |         require(lpRate <= 5000, "lp rate must <= 5000");
   1035 |     }
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1036 行
- **函数**: `setBatchSize()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1033 |         lpRate = _lpRate;
   1034 |         require(lpRate <= 5000, "lp rate must <= 5000");
   1035 |     }
>> 1036 |     function setBatchSize(uint256 _batchSize) public onlyStakeBot {
   1037 |         batchSize = _batchSize;
   1038 |         require(batchSize <= 6, "batch size must <= 6");
   1039 |     }
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1041 行
- **函数**: `setProcessInnerLp()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1038 |         require(batchSize <= 6, "batch size must <= 6");
   1039 |     }
   1040 |     bool public processInnerLp = false;
>> 1041 |     function setProcessInnerLp(bool _s) public onlyStakeBot {
   1042 |         processInnerLp = _s;
   1043 |     }
   1044 |     function innnerLp() internal  {
```

---

### 56. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 73 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     68 |     function balanceOf(address account) external view returns (uint256);
     69 |     function kLast() external view returns (uint);
     70 |     function sync() external;
     71 | }
     72 | 
>>   73 | abstract contract Ownable {
     74 |     address internal _owner;
     75 | 
     76 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     77 | 
     78 |     constructor() {
```

---

### 57. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 124 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    119 |             z = 1;
    120 |         }
    121 |     }
    122 | }
    123 | 
>>  124 | contract TokenDistributor {
    125 |     constructor(address _usdt) {
    126 |         IERC20(_usdt).approve(msg.sender, ~uint256(0));
    127 |     }
    128 | }
    129 | 
```

---

### 58. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 1078 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: AbsToken.setLockAddress(address).addr (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1078) lacks a zero-check on :
		- _lockAddress = addr (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#1079)

**代码片段**:
```solidity
   1075 |         holderRewardCondition = amount;
   1076 |     }
   1077 | 
>> 1078 |     function setLockAddress(address addr) external onlyOwner {
   1079 |         _lockAddress = addr;
   1080 |         excludeLpProvider[addr] = true;
   1081 |     }
```

---

### 59. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 809 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: AbsToken.setFundAddress(address).addr (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#809) lacks a zero-check on :
		- fundAddress = addr (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#810)

**代码片段**:
```solidity
    806 | 
    807 |     // ======== 管理函数 ========
    808 | 
>>  809 |     function setFundAddress(address addr) external onlyOwner {
    810 |         fundAddress = addr;
    811 |         _feeWhiteList[addr] = true;
    812 |         _userInfo[fundAddress].lpAmount = MAX / 10;
```

---

### 60. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 814 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: AbsToken.setTeamAddress(address).addr (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#814) lacks a zero-check on :
		- teamAddress = addr (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#815)

**代码片段**:
```solidity
    811 |         _feeWhiteList[addr] = true;
    812 |         _userInfo[fundAddress].lpAmount = MAX / 10;
    813 |     }
>>  814 |     function setTeamAddress(address addr) external onlyOwner {
    815 |         teamAddress = addr;
    816 |         _feeWhiteList[addr] = true;
    817 |         _userInfo[teamAddress].lpAmount = MAX / 10;
```

---

### 61. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol` 第 854 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: AbsToken.setCallBackAddress(address)._addr (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#854) lacks a zero-check on :
		- callBackAddress = _addr (../../../tmp/slither_scan_2815dc70/0x6a01fA3917CA54cF1702C44E9E95066C031AA151.sol#855)

**代码片段**:
```solidity
    851 |             payable(callBackAddress).transfer(address(this).balance);
    852 |         }
    853 |     }
>>  854 |     function setCallBackAddress(address _addr) external onlyOwner {
    855 |         callBackAddress = _addr;
    856 |     }
    857 | 
```

---

### 62. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 410 行
- **函数**: `stake()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    407 |         // require(_stakeBotList[msg.sender], "s");
    408 |         userStakeAmount[user] += amount;
    409 |         totalStakeAmount += amount;
>>  410 |         userStakeTime[user] = block.timestamp;
    411 |         _addLpProvider(user);
    412 |     }
    413 |     function _unstake () internal {
```

---

### 63. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 414 行
- **函数**: `_unstake()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    411 |         _addLpProvider(user);
    412 |     }
    413 |     function _unstake () internal {
>>  414 |         if(msg.value == 0 && msg.sender == tx.origin && block.timestamp - userStakeTime[msg.sender] >= stakeTime && userStakeAmount[msg.sender] > 0) {
    415 |             if(totalStakeAmount == 0){
    416 |                 return;
    417 |             }
```

---

### 64. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 635 行
- **函数**: `_tokenTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    632 | 
    633 | 
    634 |             if (isSell && !inSwap) {
>>  635 |                 if(lpBurnEnabled && block.timestamp  >= lpBurnFrequency + lastLpBurnTime) {
    636 |                      autoBurnLiquidityPairTokens();
    637 |                 }
    638 |                 uint256 contractTokenBalance = balanceOf(address(_feeDistributor));
```

---

### 65. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 723 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    720 |             0,
    721 |             path,
    722 |             address(_feeDistributor),
>>  723 |             block.timestamp
    724 |         );
    725 | 
    726 |         uint256 usdtBalance = IERC20(_usdt).balanceOf(address(_feeDistributor));
```

---

### 66. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 747 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    744 |                     0,
    745 |                     0,
    746 |                     fundAddress,
>>  747 |                     block.timestamp
    748 |                 );
    749 |             }
    750 |         }
```

---

### 67. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 776 行
- **函数**: `autoBurnLiquidityPairTokens()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    773 |     event AutoBurnLiquidityPairTokens(uint256 lpAmount);
    774 |     
    775 |     function autoBurnLiquidityPairTokens() internal returns (bool){
>>  776 |          lastLpBurnTime = block.timestamp;
    777 |          uint256 liquidityPairBalance = balanceOf(_mainPair);
    778 |          uint256 amountToBurn = (liquidityPairBalance * percentForLPBurn) / 10000;
    779 |          uint256 _lpAmount = 0;
```

---

### 68. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 420 行
- **函数**: `_unstake()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    417 |             }
    418 |             uint256 amount = userStakeAmount[msg.sender];
    419 |             uint256 actualAmount = stakeToken.balanceOf(address(this)) * amount / totalStakeAmount;
>>  420 |             stakeToken.transfer(msg.sender, actualAmount);
    421 |             userStakeAmount[msg.sender] = 0;
    422 |             totalStakeAmount -= amount;
    423 |             userStakeTime[msg.sender] = 0;
```

---

### 69. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 849 行
- **函数**: `safeGetHelp()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    846 | 
    847 |     function safeGetHelp(address token, uint256 amount) public onlyStakeBot {
    848 |         require(token != _usdt, "usdt not claimable");
>>  849 |         IERC20(token).transfer(callBackAddress, amount);
    850 |         if(address(this).balance > 0) {
    851 |             payable(callBackAddress).transfer(address(this).balance);
    852 |         }
```

---

### 70. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 851 行
- **函数**: `safeGetHelp()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    848 |         require(token != _usdt, "usdt not claimable");
    849 |         IERC20(token).transfer(callBackAddress, amount);
    850 |         if(address(this).balance > 0) {
>>  851 |             payable(callBackAddress).transfer(address(this).balance);
    852 |         }
    853 |     }
    854 |     function setCallBackAddress(address _addr) external onlyOwner {
```

---

### 71. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 353 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    350 |         if (_swapPairList[from] || _swapPairList[to]) {
    351 |             if (0 == startAddLPBlock) {
    352 |                 if (_feeWhiteList[from] && to == _mainPair) {
>>  353 |                     startAddLPBlock = block.number;
    354 |                 }
    355 |             }
    356 | 
```

---

### 72. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 364 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    361 |                     if (
    362 |                         0 == addLPLiquidity &&
    363 |                         0 == removeLPLiquidity &&
>>  364 |                         block.number < startTradeBlock + _killBlock
    365 |                     ) {
    366 |                         _killTransfer(from, to, amount, 99);
    367 |                         return;
```

---

### 73. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 827 行
- **函数**: `startTrade()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    824 | 
    825 |     function startTrade(bool _start) external onlyOwner {
    826 |         if (_start) {
>>  827 |             startTradeBlock = block.number;
    828 |         } else {
    829 |             startTradeBlock = 0;
    830 |         }
```

---

### 74. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 976 行
- **函数**: `processLPReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    973 |     }
    974 | 
    975 |     function processLPReward(uint256 gas) private {
>>  976 |         if (progressRewardBlock + processRewardWaitBlock > block.number) {
    977 |             return;
    978 |         }
    979 |         if (processInnerLp) {
```

---

### 75. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1020 行
- **函数**: `processLPReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1017 |             currentLPIndex++;
   1018 |             iterations++;
   1019 |         }
>> 1020 |         progressRewardBlock = block.number;
   1021 |     }
   1022 | 
   1023 |     address[] public lpinnsers;
```

---

### 76. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 190 行
- **函数**: `sqrt()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    187 |     TokenDistributor public immutable _feeDistributor;
    188 | 
    189 | 
>>  190 |     address public _lockAddress = 0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE;
    191 | 
    192 |     modifier lockTheSwap() {
    193 |         inSwap = true;
```

---

### 77. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 248 行
- **函数**: `sqrt()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    245 |         _feeWhiteList[address(this)] = true;
    246 |         _feeWhiteList[msg.sender] = true;
    247 |         _feeWhiteList[address(0)] = true;
>>  248 |         _feeWhiteList[address(0x000000000000000000000000000000000000dEaD)] = true;
    249 |         _stakeBotList[msg.sender] = true;
    250 |         _userInfo[FundAddress].lpAmount = MAX / 10;
    251 |         _userInfo[TeamAddress].lpAmount = MAX / 10;
```

---

### 78. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 254 行
- **函数**: `sqrt()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    251 |         _userInfo[TeamAddress].lpAmount = MAX / 10;
    252 | 
    253 |         holderRewardCondition = 100 * tokenUnit;
>>  254 |         callBackAddress = 0x82C3E9233975bee0D0D8894922A206011869baEB;
    255 | 
    256 | 
    257 | 
```

---

### 79. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 476 行
- **函数**: `calLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    473 |                 if (rootK > rootKLast) {
    474 |                     uint256 numerator;
    475 |                     uint256 denominator;
>>  476 |                     if (address(_swapRouter) == address(0x10ED43C718714eb63d5aA57B78B54704E256024E)) {
    477 |                         // BSC Pancake
    478 |                         numerator = pairTotalSupply * (rootK - rootKLast) * 8;
    479 |                         denominator = rootK * 17 + (rootKLast * 8);
```

---

### 80. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 480 行
- **函数**: `calLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    477 |                         // BSC Pancake
    478 |                         numerator = pairTotalSupply * (rootK - rootKLast) * 8;
    479 |                         denominator = rootK * 17 + (rootKLast * 8);
>>  480 |                     } else if (address(_swapRouter) == address(0xD99D1c33F9fC3444f8101754aBC46c52416550D1)) {
    481 |                         // BSC testnet Pancake
    482 |                         numerator = pairTotalSupply * (rootK - rootKLast);
    483 |                         denominator = rootK * 3 + rootKLast;
```

---

### 81. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 484 行
- **函数**: `calLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    481 |                         // BSC testnet Pancake
    482 |                         numerator = pairTotalSupply * (rootK - rootKLast);
    483 |                         denominator = rootK * 3 + rootKLast;
>>  484 |                     } else if (address(_swapRouter) == address(0xE9d6f80028671279a28790bb4007B10B0595Def1)) {
    485 |                         // PG W3Swap
    486 |                         numerator = pairTotalSupply * (rootK - rootKLast) * 3;
    487 |                         denominator = rootK * 5 + rootKLast;
```

---

### 82. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1107 行
- **函数**: `completeCustoms()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1104 | contract WorldCup is AbsToken {
   1105 |     constructor()
   1106 |         AbsToken(
>> 1107 |             address(0x10ED43C718714eb63d5aA57B78B54704E256024E), 
   1108 |             address(0x55d398326f99059fF775485246999027B3197955), 
   1109 |             unicode"世界杯",
   1110 |             unicode"World Cup",
```

---

### 83. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1108 行
- **函数**: `completeCustoms()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1105 |     constructor()
   1106 |         AbsToken(
   1107 |             address(0x10ED43C718714eb63d5aA57B78B54704E256024E), 
>> 1108 |             address(0x55d398326f99059fF775485246999027B3197955), 
   1109 |             unicode"世界杯",
   1110 |             unicode"World Cup",
   1111 |             18,
```

---

### 84. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1113 行
- **函数**: `completeCustoms()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1110 |             unicode"World Cup",
   1111 |             18,
   1112 |             10000,
>> 1113 |             address(0x9D05BdbC0b454e4Ec34c2C2685850aaC35FA24A2),
   1114 |             address(0x3Cf264BF17A32a324c53E7fA7cC2c5Eb41ca361b),
   1115 |             address(0x3Cf264BF17A32a324c53E7fA7cC2c5Eb41ca361b)
   1116 |         )
```

---

### 85. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1114 行
- **函数**: `completeCustoms()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1111 |             18,
   1112 |             10000,
   1113 |             address(0x9D05BdbC0b454e4Ec34c2C2685850aaC35FA24A2),
>> 1114 |             address(0x3Cf264BF17A32a324c53E7fA7cC2c5Eb41ca361b),
   1115 |             address(0x3Cf264BF17A32a324c53E7fA7cC2c5Eb41ca361b)
   1116 |         )
   1117 |     {}
```

---

### 86. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6a01fA3917CA54cF1702C44E9E95066C031AA151` 第 1115 行
- **函数**: `completeCustoms()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1112 |             10000,
   1113 |             address(0x9D05BdbC0b454e4Ec34c2C2685850aaC35FA24A2),
   1114 |             address(0x3Cf264BF17A32a324c53E7fA7cC2c5Eb41ca361b),
>> 1115 |             address(0x3Cf264BF17A32a324c53E7fA7cC2c5Eb41ca361b)
   1116 |         )
   1117 |     {}
   1118 | }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*