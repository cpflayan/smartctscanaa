# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:11:29
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` |
| contract_name | `BscUsdtProductionArbitrageEngine` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `True` |
| runs | `1000` |
| evm_version | `shanghai` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/BscUsdtProductionArbitrageEngine.sol', '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/interfaces/IERC1363.sol', '@openzeppelin/contracts/interfaces/IERC20.sol', '@openzeppelin/contracts/interfaces/IERC165.sol', '@openzeppelin/contracts/utils/introspection/IERC165.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol', '@openzeppelin/contracts/utils/ReentrancyGuard.sol', '@openzeppelin/contracts/utils/StorageSlot.sol', '@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/utils/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655008` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 28 |
| 🟢 LOW | 13 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 14 行
- **函数**: `factory()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     11 | 
     12 | interface IPancakeV3Pool {
     13 | function flash(address recipient, uint256 amount0, uint256 amount1, bytes calldata data) external;
>>   14 | function factory() external view returns (address);
     15 | function token0() external view returns (address);
     16 | function token1() external view returns (address);
     17 | function fee() external view returns (uint24);
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 15 行
- **函数**: `token0()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     12 | interface IPancakeV3Pool {
     13 | function flash(address recipient, uint256 amount0, uint256 amount1, bytes calldata data) external;
     14 | function factory() external view returns (address);
>>   15 | function token0() external view returns (address);
     16 | function token1() external view returns (address);
     17 | function fee() external view returns (uint24);
     18 | }
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 16 行
- **函数**: `token1()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     13 | function flash(address recipient, uint256 amount0, uint256 amount1, bytes calldata data) external;
     14 | function factory() external view returns (address);
     15 | function token0() external view returns (address);
>>   16 | function token1() external view returns (address);
     17 | function fee() external view returns (uint24);
     18 | }
     19 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 17 行
- **函数**: `fee()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     14 | function factory() external view returns (address);
     15 | function token0() external view returns (address);
     16 | function token1() external view returns (address);
>>   17 | function fee() external view returns (uint24);
     18 | }
     19 | 
     20 | interface IRouter {
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 21 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     18 | }
     19 | 
     20 | interface IRouter {
>>   21 | function swapExactTokensForTokens(uint256 amountIn, uint256 amountOutMin, address[] calldata path, address to, uint256 deadline) external returns (uint256[] memory amounts);
     22 | }
     23 | 
     24 | contract BscUsdtProductionArbitrageEngine is ReentrancyGuard, Ownable {
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 127 行
- **函数**: `pancakeV3FlashCallback()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    124 | }  
    125 | 
    126 | // --- Callback ---  
>>  127 | function pancakeV3FlashCallback(uint256 fee0, uint256 fee1, bytes calldata data) external {  
    128 |     require(!_callbackEntered, "Callback active");  
    129 |     _callbackEntered = true;  
    130 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 209 行
- **函数**: `computePoolAddress()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    206 |     delete _activeBorrowToken0; delete _activeTargetToken;  
    207 | }  
    208 | 
>>  209 | function computePoolAddress(address tA, address tB, uint24 fee) public pure returns (address) {  
    210 |     (address t0, address t1) = tA < tB ? (tA, tB) : (tB, tA);  
    211 |     return address(uint160(uint256(keccak256(abi.encodePacked(hex'ff', PANCAKE_FACTORY, keccak256(abi.encode(t0, t1, fee)), POOL_INIT_CODE_HASH)))));  
    212 | }
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 528 行
- **函数**: `totalSupply()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    525 |     /**
    526 |      * @dev Returns the value of tokens in existence.
    527 |      */
>>  528 |     function totalSupply() external view returns (uint256);
    529 | 
    530 |     /**
    531 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 533 行
- **函数**: `balanceOf()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    530 |     /**
    531 |      * @dev Returns the value of tokens owned by `account`.
    532 |      */
>>  533 |     function balanceOf(address account) external view returns (uint256);
    534 | 
    535 |     /**
    536 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 542 行
- **函数**: `transfer()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    539 |      *
    540 |      * Emits a {Transfer} event.
    541 |      */
>>  542 |     function transfer(address to, uint256 value) external returns (bool);
    543 | 
    544 |     /**
    545 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 551 行
- **函数**: `allowance()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    548 |      *
    549 |      * This value changes when {approve} or {transferFrom} are called.
    550 |      */
>>  551 |     function allowance(address owner, address spender) external view returns (uint256);
    552 | 
    553 |     /**
    554 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 568 行
- **函数**: `approve()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    565 |      *
    566 |      * Emits an {Approval} event.
    567 |      */
>>  568 |     function approve(address spender, uint256 value) external returns (bool);
    569 | 
    570 |     /**
    571 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 579 行
- **函数**: `transferFrom()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    576 |      *
    577 |      * Emits a {Transfer} event.
    578 |      */
>>  579 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    580 | }
    581 | 
    582 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 619 行
- **函数**: `transferAndCall()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    616 |      * @param value The amount of tokens to be transferred.
    617 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    618 |      */
>>  619 |     function transferAndCall(address to, uint256 value) external returns (bool);
    620 | 
    621 |     /**
    622 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 629 行
- **函数**: `transferAndCall()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    626 |      * @param data Additional data with no specified format, sent in call to `to`.
    627 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    628 |      */
>>  629 |     function transferAndCall(address to, uint256 value, bytes calldata data) external returns (bool);
    630 | 
    631 |     /**
    632 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 639 行
- **函数**: `transferFromAndCall()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    636 |      * @param value The amount of tokens to be transferred.
    637 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    638 |      */
>>  639 |     function transferFromAndCall(address from, address to, uint256 value) external returns (bool);
    640 | 
    641 |     /**
    642 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 650 行
- **函数**: `transferFromAndCall()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    647 |      * @param data Additional data with no specified format, sent in call to `to`.
    648 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    649 |      */
>>  650 |     function transferFromAndCall(address from, address to, uint256 value, bytes calldata data) external returns (bool);
    651 | 
    652 |     /**
    653 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 659 行
- **函数**: `approveAndCall()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    656 |      * @param value The amount of tokens to be spent.
    657 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    658 |      */
>>  659 |     function approveAndCall(address spender, uint256 value) external returns (bool);
    660 | 
    661 |     /**
    662 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 669 行
- **函数**: `approveAndCall()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    666 |      * @param data Additional data with no specified format, sent in call to `spender`.
    667 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    668 |      */
>>  669 |     function approveAndCall(address spender, uint256 value, bytes calldata data) external returns (bool);
    670 | }
    671 | 
    672 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 718 行
- **函数**: `supportsInterface()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    715 |      *
    716 |      * This function call must use less than 30 000 gas.
    717 |      */
>>  718 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
    719 | }
    720 | 
    721 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 738 行
- **函数**: `name()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    735 |     /**
    736 |      * @dev Returns the name of the token.
    737 |      */
>>  738 |     function name() external view returns (string memory);
    739 | 
    740 |     /**
    741 |      * @dev Returns the symbol of the token.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 743 行
- **函数**: `symbol()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    740 |     /**
    741 |      * @dev Returns the symbol of the token.
    742 |      */
>>  743 |     function symbol() external view returns (string memory);
    744 | 
    745 |     /**
    746 |      * @dev Returns the decimals places of the token.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 748 行
- **函数**: `decimals()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    745 |     /**
    746 |      * @dev Returns the decimals places of the token.
    747 |      */
>>  748 |     function decimals() external view returns (uint8);
    749 | }
    750 | 
    751 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 1079 行
- **函数**: `owner()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1076 |     /**
   1077 |      * @dev Returns the address of the current owner.
   1078 |      */
>> 1079 |     function owner() public view virtual returns (address) {
   1080 |         return _owner;
   1081 |     }
   1082 | 
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 24 行
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     19 | 
     20 | interface IRouter {
     21 | function swapExactTokensForTokens(uint256 amountIn, uint256 amountOutMin, address[] calldata path, address to, uint256 deadline) external returns (uint256[] memory amounts);
     22 | }
     23 | 
>>   24 | contract BscUsdtProductionArbitrageEngine is ReentrancyGuard, Ownable {
     25 | 
     26 |  event DebugLoan(uint256 loanAmount, uint256 maxFlashLoan);
     27 | 
     28 | using SafeERC20 for IERC20;
     29 | 
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 229 行
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    224 | import {IERC1363} from "../../../interfaces/IERC1363.sol";
    225 | 
    226 | /**
    227 |  * @title SafeERC20
    228 |  * @dev Wrappers around ERC-20 operations that throw on failure (when the token
>>  229 |  * contract returns false). Tokens that return no value (and instead revert or
    230 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    231 |  * successful.
    232 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    233 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    234 |  */
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 1043 行
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1038 |  *
   1039 |  * This module is used through inheritance. It will make available the modifier
   1040 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
   1041 |  * the owner.
   1042 |  */
>> 1043 | abstract contract Ownable is Context {
   1044 |     address private _owner;
   1045 | 
   1046 |     /**
   1047 |      * @dev The caller account is not authorized to perform an operation.
   1048 |      */
```

---

### 28. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 1115 行
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1110 |         }
   1111 |         _transferOwnership(newOwner);
   1112 |     }
   1113 | 
   1114 |     /**
>> 1115 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
   1116 |      * Internal function without access restriction.
   1117 |      */
   1118 |     function _transferOwnership(address newOwner) internal virtual {
   1119 |         address oldOwner = _owner;
   1120 |         _owner = newOwner;
```

---

### 29. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 101 行
- **函数**: `requestFlashLoan()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     98 |     require(params.loanAmount > 0 && params.loanAmount <= maxFlashLoan, "Invalid loan");
     99 |     require(!paused && !_flashActive, "System locked");  
    100 |     require(approvedRouters[params.rA] && approvedRouters[params.rB], "Router unapproved"); 
>>  101 |     require(params.deadline >= block.timestamp, "Deadline expired");  
    102 |     require(fee == params.poolFeeTier, "Fee mismatch");  
    103 |     require((amount0 == 0) != (amount1 == 0), "Single-sided flash only");  
    104 |     require(params.loanAmount == (amount0 > 0 ? amount0 : amount1), "Amount mismatch");  
```

---

### 30. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 142 行
- **函数**: `pancakeV3FlashCallback()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    139 |     // Explicit Invariants  
    140 |     require(trade.targetToken == _activeTargetToken, "Target mismatch");  
    141 |     require(trade.loanAmount == _activeFlashAmount, "Loan mismatch");  
>>  142 |     require(block.timestamp <= trade.deadline, "Deadline expired");  
    143 | 
    144 |     IPancakeV3Pool pool = IPancakeV3Pool(msg.sender);  
    145 |     require(pool.factory() == PANCAKE_FACTORY && pool.fee() == trade.poolFeeTier, "Pool config mismatch");  
```

---

### 31. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 31 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     28 | using SafeERC20 for IERC20;
     29 | 
     30 | // IMPORTANT: Verify constants against current PancakeSwap V3 BSC deployment  
>>   31 | address public constant PANCAKE_FACTORY = 0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865;  
     32 | bytes32 public constant POOL_INIT_CODE_HASH = 0x6ce3077cd1b5ca9a419be209340f1d39f286828b6d45ec000dbd0c7546fb1f6a;  
     33 | IERC20 public constant USDT = IERC20(0x55d398326f99059fF775485246999027B3197955);  
     34 |   
```

---

### 32. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 32 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     29 | 
     30 | // IMPORTANT: Verify constants against current PancakeSwap V3 BSC deployment  
     31 | address public constant PANCAKE_FACTORY = 0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865;  
>>   32 | bytes32 public constant POOL_INIT_CODE_HASH = 0x6ce3077cd1b5ca9a419be209340f1d39f286828b6d45ec000dbd0c7546fb1f6a;  
     33 | IERC20 public constant USDT = IERC20(0x55d398326f99059fF775485246999027B3197955);  
     34 |   
     35 | bool public paused;  
```

---

### 33. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 33 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     30 | // IMPORTANT: Verify constants against current PancakeSwap V3 BSC deployment  
     31 | address public constant PANCAKE_FACTORY = 0x0BFbCF9fa4f9C56B0F40a671Ad40E0805A091865;  
     32 | bytes32 public constant POOL_INIT_CODE_HASH = 0x6ce3077cd1b5ca9a419be209340f1d39f286828b6d45ec000dbd0c7546fb1f6a;  
>>   33 | IERC20 public constant USDT = IERC20(0x55d398326f99059fF775485246999027B3197955);  
     34 |   
     35 | bool public paused;  
     36 | uint256 public maxFlashLoan;  
```

---

### 34. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 790 行
- **函数**: `decimals()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    787 | 
    788 |     // keccak256(abi.encode(uint256(keccak256("openzeppelin.storage.ReentrancyGuard")) - 1)) & ~bytes32(uint256(0xff))
    789 |     bytes32 private constant REENTRANCY_GUARD_STORAGE =
>>  790 |         0x9b779b17422d0df92223018b32b4d1fa46e071723d6817e2486d003becc55f00;
    791 | 
    792 |     // Booleans are more expensive than uint256 or any type that takes up a full
    793 |     // word because each write operation emits an extra SLOAD to first read the
```

---

### 35. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 26 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
     23 | 
     24 | contract BscUsdtProductionArbitrageEngine is ReentrancyGuard, Ownable {
     25 | 
>>   26 |  event DebugLoan(uint256 loanAmount, uint256 maxFlashLoan);
     27 | 
     28 | using SafeERC20 for IERC20;
     29 | 
```

---

### 36. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 36 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
     33 | IERC20 public constant USDT = IERC20(0x55d398326f99059fF775485246999027B3197955);  
     34 |   
     35 | bool public paused;  
>>   36 | uint256 public maxFlashLoan;  
     37 | uint256 public operatingCapital;  
     38 | uint256 public claimableProfit;  
     39 |   
```

---

### 37. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 62 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
     59 | }  
     60 | 
     61 | constructor() Ownable(msg.sender) {  
>>   62 |     maxFlashLoan = 1_000_000 * (10 ** IERC20Metadata(address(USDT)).decimals());  
     63 | }  
     64 | 
     65 | // --- Administration ---  
```

---

### 38. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 67 行
- **函数**: `setMaxFlashLoan()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
     64 | 
     65 | // --- Administration ---  
     66 | function togglePause(bool _paused) external onlyOwner { paused = _paused; }  
>>   67 | function setMaxFlashLoan(uint256 _max) external onlyOwner { maxFlashLoan = _max; }  
     68 | function setRouter(address router, bool approved) external onlyOwner {   
     69 |     require(router != address(0), "Invalid router");  
     70 |     if (approved) require(router.code.length > 0, "Not a contract");  
```

---

### 39. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 95 行
- **函数**: `requestFlashLoan()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
     92 | }  
     93 | 
     94 | // --- Core Entry ---  
>>   95 | function requestFlashLoan(address pool, uint24 fee, uint256 amount0, uint256 amount1, TradeExecutionParams calldata params) external onlyOwner nonReentrant {  
     96 |     
     97 |     emit DebugLoan(params.loanAmount, maxFlashLoan);
     98 |     require(params.loanAmount > 0 && params.loanAmount <= maxFlashLoan, "Invalid loan");
```

---

### 40. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 97 行
- **函数**: `requestFlashLoan()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
     94 | // --- Core Entry ---  
     95 | function requestFlashLoan(address pool, uint24 fee, uint256 amount0, uint256 amount1, TradeExecutionParams calldata params) external onlyOwner nonReentrant {  
     96 |     
>>   97 |     emit DebugLoan(params.loanAmount, maxFlashLoan);
     98 |     require(params.loanAmount > 0 && params.loanAmount <= maxFlashLoan, "Invalid loan");
     99 |     require(!paused && !_flashActive, "System locked");  
    100 |     require(approvedRouters[params.rA] && approvedRouters[params.rB], "Router unapproved"); 
```

---

### 41. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0xe0F8243a20A4cCF22F6678A24CBdADB06424B9B7` 第 98 行
- **函数**: `requestFlashLoan()`
- **合约**: `BscUsdtProductionArbitrageEngine`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
     95 | function requestFlashLoan(address pool, uint24 fee, uint256 amount0, uint256 amount1, TradeExecutionParams calldata params) external onlyOwner nonReentrant {  
     96 |     
     97 |     emit DebugLoan(params.loanAmount, maxFlashLoan);
>>   98 |     require(params.loanAmount > 0 && params.loanAmount <= maxFlashLoan, "Invalid loan");
     99 |     require(!paused && !_flashActive, "System locked");  
    100 |     require(approvedRouters[params.rA] && approvedRouters[params.rB], "Router unapproved"); 
    101 |     require(params.deadline >= block.timestamp, "Deadline expired");  
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*