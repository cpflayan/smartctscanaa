# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:03:13
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` |
| contract_name | `ERC1967Proxy` |
| compiler_version | `v0.8.9+commit.e5eed63a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `True` |
| implementation | `0x47e1a0f88e6f509b5f391d2e0623acc33c616487` |
| multi_file | `True` |
| source_files | `['contracts/import.sol', '@openzeppelin/contracts/proxy/beacon/BeaconProxy.sol', '@openzeppelin/contracts/proxy/beacon/UpgradeableBeacon.sol', '@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol', '@openzeppelin/contracts/proxy/transparent/TransparentUpgradeableProxy.sol', '@openzeppelin/contracts/proxy/transparent/ProxyAdmin.sol', '@openzeppelin/contracts/proxy/beacon/IBeacon.sol', '@openzeppelin/contracts/proxy/Proxy.sol', '@openzeppelin/contracts/proxy/ERC1967/ERC1967Upgrade.sol', '@openzeppelin/contracts/utils/Address.sol', '@openzeppelin/contracts/utils/StorageSlot.sol', '@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/utils/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 18 |
| 🟢 LOW | 11 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 443 行
- **函数**: `_delegate()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    440 | 
    441 |             // Call the implementation.
    442 |             // out and outsize are 0 because we don't know the size yet.
>>  443 |             let result := delegatecall(gas(), implementation, 0, calldatasize(), 0, 0)
    444 | 
    445 |             // Copy the returned data.
    446 |             returndatacopy(0, 0, returndatasize())
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 859 行
- **函数**: `functionDelegateCall()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    856 |         require(isContract(target), "Address: delegate call to non-contract");
    857 | 
    858 |         // solhint-disable-next-line avoid-low-level-calls
>>  859 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    860 |         return _verifyCallResult(success, returndata, errorMessage);
    861 |     }
    862 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 118 行
- **函数**: `implementation()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    115 |     /**
    116 |      * @dev Returns the current implementation address.
    117 |      */
>>  118 |     function implementation() public view virtual override returns (address) {
    119 |         return _implementation;
    120 |     }
    121 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 246 行
- **函数**: `admin()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    243 |      * https://eth.wiki/json-rpc/API#eth_getstorageat[`eth_getStorageAt`] RPC call.
    244 |      * `0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103`
    245 |      */
>>  246 |     function admin() external ifAdmin returns (address admin_) {
    247 |         admin_ = _getAdmin();
    248 |     }
    249 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 259 行
- **函数**: `implementation()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    256 |      * https://eth.wiki/json-rpc/API#eth_getstorageat[`eth_getStorageAt`] RPC call.
    257 |      * `0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc`
    258 |      */
>>  259 |     function implementation() external ifAdmin returns (address implementation_) {
    260 |         implementation_ = _implementation();
    261 |     }
    262 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 270 行
- **函数**: `changeAdmin()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    267 |      *
    268 |      * NOTE: Only the admin can call this function. See {ProxyAdmin-changeProxyAdmin}.
    269 |      */
>>  270 |     function changeAdmin(address newAdmin) external virtual ifAdmin {
    271 |         _changeAdmin(newAdmin);
    272 |     }
    273 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 279 行
- **函数**: `upgradeTo()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    276 |      *
    277 |      * NOTE: Only the admin can call this function. See {ProxyAdmin-upgrade}.
    278 |      */
>>  279 |     function upgradeTo(address newImplementation) external ifAdmin {
    280 |         _upgradeToAndCall(newImplementation, bytes(""), false);
    281 |     }
    282 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 290 行
- **函数**: `upgradeToAndCall()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    287 |      *
    288 |      * NOTE: Only the admin can call this function. See {ProxyAdmin-upgradeAndCall}.
    289 |      */
>>  290 |     function upgradeToAndCall(address newImplementation, bytes calldata data) external payable ifAdmin {
    291 |         _upgradeToAndCall(newImplementation, data, true);
    292 |     }
    293 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 333 行
- **函数**: `getProxyImplementation()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    330 |      *
    331 |      * - This contract must be the admin of `proxy`.
    332 |      */
>>  333 |     function getProxyImplementation(TransparentUpgradeableProxy proxy) public view virtual returns (address) {
    334 |         // We need to manually run the static call since the getter cannot be flagged as view
    335 |         // bytes4(keccak256("implementation()")) == 0x5c60da1b
    336 |         (bool success, bytes memory returndata) = address(proxy).staticcall(hex"5c60da1b");
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 348 行
- **函数**: `getProxyAdmin()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    345 |      *
    346 |      * - This contract must be the admin of `proxy`.
    347 |      */
>>  348 |     function getProxyAdmin(TransparentUpgradeableProxy proxy) public view virtual returns (address) {
    349 |         // We need to manually run the static call since the getter cannot be flagged as view
    350 |         // bytes4(keccak256("admin()")) == 0xf851a440
    351 |         (bool success, bytes memory returndata) = address(proxy).staticcall(hex"f851a440");
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 407 行
- **函数**: `implementation()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    404 |      *
    405 |      * {BeaconProxy} will check that this address is a contract.
    406 |      */
>>  407 |     function implementation() external view returns (address);
    408 | }
    409 | 
    410 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 1007 行
- **函数**: `owner()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1004 |     /**
   1005 |      * @dev Returns the address of the current owner.
   1006 |      */
>> 1007 |     function owner() public view virtual returns (address) {
   1008 |         return _owner;
   1009 |     }
   1010 | 
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 13 行
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      8 | import "@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol";
      9 | import "@openzeppelin/contracts/proxy/transparent/TransparentUpgradeableProxy.sol";
     10 | import "@openzeppelin/contracts/proxy/transparent/ProxyAdmin.sol";
     11 | 
     12 | // Kept for backwards compatibility with older versions of Hardhat and Truffle plugins.
>>   13 | contract AdminUpgradeabilityProxy is TransparentUpgradeableProxy {
     14 |     constructor(address logic, address admin, bytes memory data) payable TransparentUpgradeableProxy(logic, admin, data) {}
     15 | }
     16 | 
     17 | 
     18 | // ── @openzeppelin/contracts/proxy/beacon/BeaconProxy.sol ──────────────────────────────
```

---

### 14. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 99 行
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     94 |  * @dev This contract is used in conjunction with one or more instances of {BeaconProxy} to determine their
     95 |  * implementation contract, which is where they will delegate all function calls.
     96 |  *
     97 |  * An owner is able to change the implementation the beacon points to, thus upgrading the proxies that use this beacon.
     98 |  */
>>   99 | contract UpgradeableBeacon is IBeacon, Ownable {
    100 |     address private _implementation;
    101 | 
    102 |     /**
    103 |      * @dev Emitted when the implementation returned by the beacon is changed.
    104 |      */
```

---

### 15. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 161 行
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    156 | 
    157 | import "../Proxy.sol";
    158 | import "./ERC1967Upgrade.sol";
    159 | 
    160 | /**
>>  161 |  * @dev This contract implements an upgradeable proxy. It is upgradeable because calls are delegated to an
    162 |  * implementation address that can be changed. This address is stored in storage in the location specified by
    163 |  * https://eips.ethereum.org/EIPS/eip-1967[EIP1967], so that it doesn't conflict with the storage layout of the
    164 |  * implementation behind the proxy.
    165 |  */
    166 | contract ERC1967Proxy is Proxy, ERC1967Upgrade {
```

---

### 16. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 324 行
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    319 | 
    320 | /**
    321 |  * @dev This is an auxiliary contract meant to be assigned as the admin of a {TransparentUpgradeableProxy}. For an
    322 |  * explanation of why you would want to use this see the documentation for {TransparentUpgradeableProxy}.
    323 |  */
>>  324 | contract ProxyAdmin is Ownable {
    325 | 
    326 |     /**
    327 |      * @dev Returns the current implementation of `proxy`.
    328 |      *
    329 |      * Requirements:
```

---

### 17. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 346 行
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    341 |     /**
    342 |      * @dev Returns the current admin of `proxy`.
    343 |      *
    344 |      * Requirements:
    345 |      *
>>  346 |      * - This contract must be the admin of `proxy`.
    347 |      */
    348 |     function getProxyAdmin(TransparentUpgradeableProxy proxy) public view virtual returns (address) {
    349 |         // We need to manually run the static call since the getter cannot be flagged as view
    350 |         // bytes4(keccak256("admin()")) == 0xf851a440
    351 |         (bool success, bytes memory returndata) = address(proxy).staticcall(hex"f851a440");
```

---

### 18. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 427 行
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    422 |  * Additionally, delegation to the implementation can be triggered manually through the {_fallback} function, or to a
    423 |  * different contract through the {_delegate} function.
    424 |  *
    425 |  * The success and return data of the delegated call will be returned back to the caller of the proxy.
    426 |  */
>>  427 | abstract contract Proxy {
    428 |     /**
    429 |      * @dev Delegates the current call to `implementation`.
    430 |      *
    431 |      * This function does not return to its internall call site, it will return directly to the external caller.
    432 |      */
```

---

### 19. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 509 行
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    504 | import "../beacon/IBeacon.sol";
    505 | import "../../utils/Address.sol";
    506 | import "../../utils/StorageSlot.sol";
    507 | 
    508 | /**
>>  509 |  * @dev This abstract contract provides getters and event emitting update functions for
    510 |  * https://eips.ethereum.org/EIPS/eip-1967[EIP1967] slots.
    511 |  *
    512 |  * _Available since v4.1._
    513 |  *
    514 |  * @custom:oz-upgrades-unsafe-allow delegatecall
```

---

### 20. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 990 行
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    985 |  *
    986 |  * This module is used through inheritance. It will make available the modifier
    987 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    988 |  * the owner.
    989 |  */
>>  990 | abstract contract Ownable is Context {
    991 |     address private _owner;
    992 | 
    993 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    994 | 
    995 |     /**
```

---

### 21. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 518 行
- **函数**: `_beforeFallback()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    515 |  */
    516 | abstract contract ERC1967Upgrade {
    517 |     // This is the keccak-256 hash of "eip1967.proxy.rollback" subtracted by 1
>>  518 |     bytes32 private constant _ROLLBACK_SLOT = 0x4910fdfa16fed3260ed0e7147f7cc6da11a60208b5b9406d12a635614ffd9143;
    519 | 
    520 |     /**
    521 |      * @dev Storage slot with the address of the current implementation.
```

---

### 22. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 525 行
- **函数**: `_beforeFallback()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    522 |      * This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1, and is
    523 |      * validated in the constructor.
    524 |      */
>>  525 |     bytes32 internal constant _IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
    526 | 
    527 |     /**
    528 |      * @dev Emitted when the implementation is upgraded.
```

---

### 23. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 624 行
- **函数**: `_upgradeBeaconToAndCall()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    621 |      * This is the keccak-256 hash of "eip1967.proxy.admin" subtracted by 1, and is
    622 |      * validated in the constructor.
    623 |      */
>>  624 |     bytes32 internal constant _ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    625 | 
    626 |     /**
    627 |      * @dev Emitted when the admin account has changed.
```

---

### 24. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 660 行
- **函数**: `_changeAdmin()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    657 |      * @dev The storage slot of the UpgradeableBeacon contract which defines the implementation for this proxy.
    658 |      * This is bytes32(uint256(keccak256('eip1967.proxy.beacon')) - 1)) and is validated in the constructor.
    659 |      */
>>  660 |     bytes32 internal constant _BEACON_SLOT = 0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50;
    661 | 
    662 |     /**
    663 |      * @dev Emitted when the beacon is upgraded.
```

---

### 25. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 435 行
- **函数**: `_delegate()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    432 |      */
    433 |     function _delegate(address implementation) internal virtual {
    434 |         // solhint-disable-next-line no-inline-assembly
>>  435 |         assembly {
    436 |             // Copy msg.data. We take full control of memory in this inline assembly
    437 |             // block because it will not return to Solidity code. We overwrite the
    438 |             // Solidity scratch pad at memory position 0.
```

---

### 26. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 725 行
- **函数**: `isContract()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    722 | 
    723 |         uint256 size;
    724 |         // solhint-disable-next-line no-inline-assembly
>>  725 |         assembly { size := extcodesize(account) }
    726 |         return size > 0;
    727 |     }
    728 | 
```

---

### 27. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 872 行
- **函数**: `_verifyCallResult()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    869 |                 // The easiest way to bubble the revert reason is using memory via assembly
    870 | 
    871 |                 // solhint-disable-next-line no-inline-assembly
>>  872 |                 assembly {
    873 |                     let returndata_size := mload(returndata)
    874 |                     revert(add(32, returndata), returndata_size)
    875 |                 }
```

---

### 28. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 937 行
- **函数**: `getAddressSlot()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    934 |      * @dev Returns an `AddressSlot` with member `value` located at `slot`.
    935 |      */
    936 |     function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
>>  937 |         assembly {
    938 |             r.slot := slot
    939 |         }
    940 |     }
```

---

### 29. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 946 行
- **函数**: `getBooleanSlot()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    943 |      * @dev Returns an `BooleanSlot` with member `value` located at `slot`.
    944 |      */
    945 |     function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
>>  946 |         assembly {
    947 |             r.slot := slot
    948 |         }
    949 |     }
```

---

### 30. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 955 行
- **函数**: `getBytes32Slot()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    952 |      * @dev Returns an `Bytes32Slot` with member `value` located at `slot`.
    953 |      */
    954 |     function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
>>  955 |         assembly {
    956 |             r.slot := slot
    957 |         }
    958 |     }
```

---

### 31. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x99660AE08BCE6f8Ff8599bd806A9f7362f636589` 第 964 行
- **函数**: `getUint256Slot()`
- **合约**: `AdminUpgradeabilityProxy`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    961 |      * @dev Returns an `Uint256Slot` with member `value` located at `slot`.
    962 |      */
    963 |     function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
>>  964 |         assembly {
    965 |             r.slot := slot
    966 |         }
    967 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*