# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:40:21
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` |
| contract_name | `PinkLock02` |
| compiler_version | `v0.8.4+commit.c7e474f2` |
| optimization_used | `True` |
| runs | `999999` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/PinkLock02.sol', '@openzeppelin/contracts/utils/Address.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', '@openzeppelin/contracts/utils/structs/EnumerableSet.sol', 'contracts/IPinkLock.sol', 'contracts/IUniswapV2Router02.sol', 'contracts/IUniswapV2Pair.sol', 'contracts/IUniswapV2Factory.sol', 'contracts/FullMath.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646139` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 44 |
| 🟢 LOW | 22 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1075 行
- **函数**: `functionDelegateCall()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1072 |     ) internal returns (bytes memory) {
   1073 |         require(isContract(target), "Address: delegate call to non-contract");
   1074 | 
>> 1075 |         (bool success, bytes memory returndata) = target.delegatecall(data);
   1076 |         return verifyCallResult(success, returndata, errorMessage);
   1077 |     }
   1078 | 
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1995 行
- **函数**: `getReserves()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1992 | 
   1993 |   function token1() external view returns (address);
   1994 | 
>> 1995 |   function getReserves()
   1996 |     external
   1997 |     view
   1998 |     returns (
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 947 行
- **函数**: `sendValue()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    944 |     function sendValue(address payable recipient, uint256 amount) internal {
    945 |         require(address(this).balance >= amount, "Address: insufficient balance");
    946 | 
>>  947 |         (bool success, ) = recipient.call{value: amount}("");
    948 |         require(success, "Address: unable to send value, recipient may have reverted");
    949 |     }
    950 | 
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1021 行
- **函数**: `functionCallWithValue()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1018 |         require(address(this).balance >= value, "Address: insufficient balance for call");
   1019 |         require(isContract(target), "Address: call to non-contract");
   1020 | 
>> 1021 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
   1022 |         return verifyCallResult(success, returndata, errorMessage);
   1023 |     }
   1024 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 391 行
- **函数**: `unlock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    388 |         _locks.push(newLock);
    389 |     }
    390 | 
>>  391 |     function unlock(uint256 lockId) external override validLock(lockId) {
    392 |         Lock storage userLock = _locks[_getActualIndex(lockId)];
    393 |         require(
    394 |             userLock.owner == msg.sender,
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 651 行
- **函数**: `renounceLockOwnership()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    648 |         emit LockOwnerChanged(lockId, currentOwner, newOwner);
    649 |     }
    650 | 
>>  651 |     function renounceLockOwnership(uint256 lockId) external {
    652 |         transferLockOwnership(lockId, address(0));
    653 |     }
    654 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 670 行
- **函数**: `getTotalLockCount()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    667 |         );
    668 |     }
    669 | 
>>  670 |     function getTotalLockCount() external view returns (uint256) {
    671 |         // Returns total lock count, regardless of whether it has been unlocked or not
    672 |         return _locks.length;
    673 |     }
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 675 行
- **函数**: `getLockAt()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    672 |         return _locks.length;
    673 |     }
    674 | 
>>  675 |     function getLockAt(uint256 index) external view returns (Lock memory) {
    676 |         return _locks[index];
    677 |     }
    678 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 679 行
- **函数**: `getLockById()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    676 |         return _locks[index];
    677 |     }
    678 | 
>>  679 |     function getLockById(uint256 lockId) public view returns (Lock memory) {
    680 |         return _locks[_getActualIndex(lockId)];
    681 |     }
    682 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 683 行
- **函数**: `allLpTokenLockedCount()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    680 |         return _locks[_getActualIndex(lockId)];
    681 |     }
    682 | 
>>  683 |     function allLpTokenLockedCount() public view returns (uint256) {
    684 |         return _lpLockedTokens.length();
    685 |     }
    686 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 687 行
- **函数**: `allNormalTokenLockedCount()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    684 |         return _lpLockedTokens.length();
    685 |     }
    686 | 
>>  687 |     function allNormalTokenLockedCount() public view returns (uint256) {
    688 |         return _normalLockedTokens.length();
    689 |     }
    690 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 745 行
- **函数**: `totalTokenLockedCount()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    742 |         return lockInfo;
    743 |     }
    744 | 
>>  745 |     function totalTokenLockedCount() external view returns (uint256) {
    746 |         return allLpTokenLockedCount() + allNormalTokenLockedCount();
    747 |     }
    748 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 749 行
- **函数**: `lpLockCountForUser()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    746 |         return allLpTokenLockedCount() + allNormalTokenLockedCount();
    747 |     }
    748 | 
>>  749 |     function lpLockCountForUser(address user) public view returns (uint256) {
    750 |         return _userLpLockIds[user].length();
    751 |     }
    752 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1123 行
- **函数**: `totalSupply()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1120 |     /**
   1121 |      * @dev Returns the amount of tokens in existence.
   1122 |      */
>> 1123 |     function totalSupply() external view returns (uint256);
   1124 | 
   1125 |     /**
   1126 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1128 行
- **函数**: `balanceOf()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1125 |     /**
   1126 |      * @dev Returns the amount of tokens owned by `account`.
   1127 |      */
>> 1128 |     function balanceOf(address account) external view returns (uint256);
   1129 | 
   1130 |     /**
   1131 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1137 行
- **函数**: `transfer()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1134 |      *
   1135 |      * Emits a {Transfer} event.
   1136 |      */
>> 1137 |     function transfer(address to, uint256 amount) external returns (bool);
   1138 | 
   1139 |     /**
   1140 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1146 行
- **函数**: `allowance()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1143 |      *
   1144 |      * This value changes when {approve} or {transferFrom} are called.
   1145 |      */
>> 1146 |     function allowance(address owner, address spender) external view returns (uint256);
   1147 | 
   1148 |     /**
   1149 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1162 行
- **函数**: `approve()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1159 |      *
   1160 |      * Emits an {Approval} event.
   1161 |      */
>> 1162 |     function approve(address spender, uint256 amount) external returns (bool);
   1163 | 
   1164 |     /**
   1165 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1714 行
- **函数**: `factory()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1711 | pragma solidity =0.8.4;
   1712 | 
   1713 | interface IUniswapV2Router01 {
>> 1714 |   function factory() external pure returns (address);
   1715 | 
   1716 |   function WETH() external pure returns (address);
   1717 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1716 行
- **函数**: `WETH()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1713 | interface IUniswapV2Router01 {
   1714 |   function factory() external pure returns (address);
   1715 | 
>> 1716 |   function WETH() external pure returns (address);
   1717 | 
   1718 |   function addLiquidity(
   1719 |     address tokenA,
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1929 行
- **函数**: `name()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1926 |   event Approval(address indexed owner, address indexed spender, uint256 value);
   1927 |   event Transfer(address indexed from, address indexed to, uint256 value);
   1928 | 
>> 1929 |   function name() external pure returns (string memory);
   1930 | 
   1931 |   function symbol() external pure returns (string memory);
   1932 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1931 行
- **函数**: `symbol()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1928 | 
   1929 |   function name() external pure returns (string memory);
   1930 | 
>> 1931 |   function symbol() external pure returns (string memory);
   1932 | 
   1933 |   function decimals() external pure returns (uint8);
   1934 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1933 行
- **函数**: `decimals()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1930 | 
   1931 |   function symbol() external pure returns (string memory);
   1932 | 
>> 1933 |   function decimals() external pure returns (uint8);
   1934 | 
   1935 |   function totalSupply() external view returns (uint256);
   1936 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1935 行
- **函数**: `totalSupply()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1932 | 
   1933 |   function decimals() external pure returns (uint8);
   1934 | 
>> 1935 |   function totalSupply() external view returns (uint256);
   1936 | 
   1937 |   function balanceOf(address owner) external view returns (uint256);
   1938 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1937 行
- **函数**: `balanceOf()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1934 | 
   1935 |   function totalSupply() external view returns (uint256);
   1936 | 
>> 1937 |   function balanceOf(address owner) external view returns (uint256);
   1938 | 
   1939 |   function allowance(address owner, address spender)
   1940 |     external
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1944 行
- **函数**: `approve()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1941 |     view
   1942 |     returns (uint256);
   1943 | 
>> 1944 |   function approve(address spender, uint256 value) external returns (bool);
   1945 | 
   1946 |   function transfer(address to, uint256 value) external returns (bool);
   1947 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1946 行
- **函数**: `transfer()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1943 | 
   1944 |   function approve(address spender, uint256 value) external returns (bool);
   1945 | 
>> 1946 |   function transfer(address to, uint256 value) external returns (bool);
   1947 | 
   1948 |   function transferFrom(
   1949 |     address from,
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1954 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1951 |     uint256 value
   1952 |   ) external returns (bool);
   1953 | 
>> 1954 |   function DOMAIN_SEPARATOR() external view returns (bytes32);
   1955 | 
   1956 |   function PERMIT_TYPEHASH() external pure returns (bytes32);
   1957 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1956 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1953 | 
   1954 |   function DOMAIN_SEPARATOR() external view returns (bytes32);
   1955 | 
>> 1956 |   function PERMIT_TYPEHASH() external pure returns (bytes32);
   1957 | 
   1958 |   function nonces(address owner) external view returns (uint256);
   1959 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1958 行
- **函数**: `nonces()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1955 | 
   1956 |   function PERMIT_TYPEHASH() external pure returns (bytes32);
   1957 | 
>> 1958 |   function nonces(address owner) external view returns (uint256);
   1959 | 
   1960 |   function permit(
   1961 |     address owner,
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1987 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1984 |   );
   1985 |   event Sync(uint112 reserve0, uint112 reserve1);
   1986 | 
>> 1987 |   function MINIMUM_LIQUIDITY() external pure returns (uint256);
   1988 | 
   1989 |   function factory() external view returns (address);
   1990 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1989 行
- **函数**: `factory()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1986 | 
   1987 |   function MINIMUM_LIQUIDITY() external pure returns (uint256);
   1988 | 
>> 1989 |   function factory() external view returns (address);
   1990 | 
   1991 |   function token0() external view returns (address);
   1992 | 
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1991 行
- **函数**: `token0()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1988 | 
   1989 |   function factory() external view returns (address);
   1990 | 
>> 1991 |   function token0() external view returns (address);
   1992 | 
   1993 |   function token1() external view returns (address);
   1994 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1993 行
- **函数**: `token1()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1990 | 
   1991 |   function token0() external view returns (address);
   1992 | 
>> 1993 |   function token1() external view returns (address);
   1994 | 
   1995 |   function getReserves()
   1996 |     external
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2004 行
- **函数**: `price0CumulativeLast()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2001 |       uint32 blockTimestampLast
   2002 |     );
   2003 | 
>> 2004 |   function price0CumulativeLast() external view returns (uint256);
   2005 | 
   2006 |   function price1CumulativeLast() external view returns (uint256);
   2007 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2006 行
- **函数**: `price1CumulativeLast()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2003 | 
   2004 |   function price0CumulativeLast() external view returns (uint256);
   2005 | 
>> 2006 |   function price1CumulativeLast() external view returns (uint256);
   2007 | 
   2008 |   function kLast() external view returns (uint256);
   2009 | 
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2008 行
- **函数**: `kLast()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2005 | 
   2006 |   function price1CumulativeLast() external view returns (uint256);
   2007 | 
>> 2008 |   function kLast() external view returns (uint256);
   2009 | 
   2010 |   function mint(address to) external returns (uint256 liquidity);
   2011 | 
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2010 行
- **函数**: `mint()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2007 | 
   2008 |   function kLast() external view returns (uint256);
   2009 | 
>> 2010 |   function mint(address to) external returns (uint256 liquidity);
   2011 | 
   2012 |   function burn(address to) external returns (uint256 amount0, uint256 amount1);
   2013 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2012 行
- **函数**: `burn()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2009 | 
   2010 |   function mint(address to) external returns (uint256 liquidity);
   2011 | 
>> 2012 |   function burn(address to) external returns (uint256 amount0, uint256 amount1);
   2013 | 
   2014 |   function swap(
   2015 |     uint256 amount0Out,
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2042 行
- **函数**: `feeTo()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2039 |     uint256
   2040 |   );
   2041 | 
>> 2042 |   function feeTo() external view returns (address);
   2043 | 
   2044 |   function feeToSetter() external view returns (address);
   2045 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2044 行
- **函数**: `feeToSetter()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2041 | 
   2042 |   function feeTo() external view returns (address);
   2043 | 
>> 2044 |   function feeToSetter() external view returns (address);
   2045 | 
   2046 |   function getPair(address tokenA, address tokenB)
   2047 |     external
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2051 行
- **函数**: `allPairs()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2048 |     view
   2049 |     returns (address pair);
   2050 | 
>> 2051 |   function allPairs(uint256) external view returns (address pair);
   2052 | 
   2053 |   function allPairsLength() external view returns (uint256);
   2054 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2053 行
- **函数**: `allPairsLength()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2050 | 
   2051 |   function allPairs(uint256) external view returns (address pair);
   2052 | 
>> 2053 |   function allPairsLength() external view returns (uint256);
   2054 | 
   2055 |   function createPair(address tokenA, address tokenB)
   2056 |     external
```

---

### 44. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 17 行
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     12 | import "./IUniswapV2Router02.sol";
     13 | import "./IUniswapV2Pair.sol";
     14 | import "./IUniswapV2Factory.sol";
     15 | import "./FullMath.sol";
     16 | 
>>   17 | contract PinkLock02 is IPinkLock {
     18 |     using Address for address payable;
     19 |     using EnumerableSet for EnumerableSet.AddressSet;
     20 |     using EnumerableSet for EnumerableSet.UintSet;
     21 |     using SafeERC20 for IERC20;
     22 | 
```

---

### 45. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1208 行
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1203 | import "../../../utils/Address.sol";
   1204 | 
   1205 | /**
   1206 |  * @title SafeERC20
   1207 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>> 1208 |  * contract returns false). Tokens that return no value (and instead revert or
   1209 |  * throw on failure) are also supported, non-reverting calls are assumed to be
   1210 |  * successful.
   1211 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
   1212 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
   1213 |  */
```

---

### 46. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 104 行
- **函数**: `lock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    101 |         require(token != address(0), "Invalid token");
    102 |         require(amount > 0, "Amount should be greater than 0");
    103 |         require(
>>  104 |             unlockDate > block.timestamp,
    105 |             "Unlock date should be in the future"
    106 |         );
    107 |         id = _createLock(
```

---

### 47. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 141 行
- **函数**: `vestingLock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    138 |     ) external override returns (uint256 id) {
    139 |         require(token != address(0), "Invalid token");
    140 |         require(amount > 0, "Amount should be greater than 0");
>>  141 |         require(tgeDate > block.timestamp, "TGE date should be in the future");
    142 |         require(cycle > 0, "Invalid cycle");
    143 |         require(tgeBps > 0 && tgeBps < 10_000, "Invalid bips for TGE");
    144 |         require(cycleBps > 0 && cycleBps < 10_000, "Invalid bips for cycle");
```

---

### 48. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 183 行
- **函数**: `multipleVestingLock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    180 |     ) external override returns (uint256[] memory) {
    181 |         require(token != address(0), "Invalid token");
    182 |         require(owners.length == amounts.length, "Length mismatched");
>>  183 |         require(tgeDate > block.timestamp, "TGE date should be in the future");
    184 |         require(cycle > 0, "Invalid cycle");
    185 |         require(tgeBps > 0 && tgeBps < 10_000, "Invalid bips for TGE");
    186 |         require(cycleBps > 0 && cycleBps < 10_000, "Invalid bips for cycle");
```

---

### 49. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 380 行
- **函数**: `_registerLock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    377 |             token: token,
    378 |             owner: owner,
    379 |             amount: amount,
>>  380 |             lockDate: block.timestamp,
    381 |             tgeDate: tgeDate,
    382 |             tgeBps: tgeBps,
    383 |             cycle: cycle,
```

---

### 50. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 407 行
- **函数**: `_normalUnlock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    404 | 
    405 |     function _normalUnlock(Lock storage userLock) internal {
    406 |         require(
>>  407 |             block.timestamp >= userLock.tgeDate,
    408 |             "It is not time to unlock"
    409 |         );
    410 |         require(userLock.unlockedAmount == 0, "Nothing to unlock");
```

---

### 51. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 450 行
- **函数**: `_normalUnlock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    447 |             userLock.token,
    448 |             msg.sender,
    449 |             unlockAmount,
>>  450 |             block.timestamp
    451 |         );
    452 |     }
    453 | 
```

---

### 52. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 479 行
- **函数**: `_vestingUnlock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    476 |                 userLock.token,
    477 |                 msg.sender,
    478 |                 newTotalUnlockAmount,
>>  479 |                 block.timestamp
    480 |             );
    481 |         }
    482 | 
```

---

### 53. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 506 行
- **函数**: `_vestingUnlock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    503 |             msg.sender,
    504 |             withdrawable,
    505 |             userLock.amount - userLock.unlockedAmount,
>>  506 |             block.timestamp
    507 |         );
    508 |     }
    509 | 
```

---

### 54. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 526 行
- **函数**: `_withdrawableTokens()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    523 |     {
    524 |         if (userLock.amount == 0) return 0;
    525 |         if (userLock.unlockedAmount >= userLock.amount) return 0;
>>  526 |         if (block.timestamp < userLock.tgeDate) return 0;
    527 |         if (userLock.cycle == 0) return 0;
    528 | 
    529 |         uint256 tgeReleaseAmount = FullMath.mulDiv(
```

---

### 55. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 540 行
- **函数**: `_withdrawableTokens()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    537 |             10_000
    538 |         );
    539 |         uint256 currentTotal = 0;
>>  540 |         if (block.timestamp >= userLock.tgeDate) {
    541 |             currentTotal =
    542 |                 (((block.timestamp - userLock.tgeDate) / userLock.cycle) *
    543 |                     cycleReleaseAmount) +
```

---

### 56. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 542 行
- **函数**: `_withdrawableTokens()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    539 |         uint256 currentTotal = 0;
    540 |         if (block.timestamp >= userLock.tgeDate) {
    541 |             currentTotal =
>>  542 |                 (((block.timestamp - userLock.tgeDate) / userLock.cycle) *
    543 |                     cycleReleaseAmount) +
    544 |                 tgeReleaseAmount; // Truncation is expected here
    545 |         }
```

---

### 57. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 570 行
- **函数**: `editLock()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    567 |         if (newUnlockDate > 0) {
    568 |             require(
    569 |                 newUnlockDate >= userLock.tgeDate &&
>>  570 |                     newUnlockDate > block.timestamp,
    571 |                 "New unlock time should not be before old unlock time or current time"
    572 |             );
    573 |             userLock.tgeDate = newUnlockDate;
```

---

### 58. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1097 行
- **函数**: `verifyCallResult()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1094 |             if (returndata.length > 0) {
   1095 |                 // The easiest way to bubble the revert reason is using memory via assembly
   1096 | 
>> 1097 |                 assembly {
   1098 |                     let returndata_size := mload(returndata)
   1099 |                     revert(add(32, returndata), returndata_size)
   1100 |                 }
```

---

### 59. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1577 行
- **函数**: `values()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1574 |         bytes32[] memory store = _values(set._inner);
   1575 |         address[] memory result;
   1576 | 
>> 1577 |         assembly {
   1578 |             result := store
   1579 |         }
   1580 | 
```

---

### 60. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 1650 行
- **函数**: `values()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1647 |         bytes32[] memory store = _values(set._inner);
   1648 |         uint256[] memory result;
   1649 | 
>> 1650 |         assembly {
   1651 |             result := store
   1652 |         }
   1653 | 
```

---

### 61. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2092 行
- **函数**: `mulDiv()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2089 |     // variables such that product = prod1 * 2**256 + prod0
   2090 |     uint256 prod0; // Least significant 256 bits of the product
   2091 |     uint256 prod1; // Most significant 256 bits of the product
>> 2092 |     assembly {
   2093 |       let mm := mulmod(a, b, not(0))
   2094 |       prod0 := mul(a, b)
   2095 |       prod1 := sub(sub(mm, prod0), lt(mm, prod0))
```

---

### 62. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2101 行
- **函数**: `mulDiv()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2098 |     // Handle non-overflow cases, 256 by 256 division
   2099 |     if (prod1 == 0) {
   2100 |       require(denominator > 0);
>> 2101 |       assembly {
   2102 |         result := div(prod0, denominator)
   2103 |       }
   2104 |       return result;
```

---

### 63. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2118 行
- **函数**: `mulDiv()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2115 |     // Make division exact by subtracting the remainder from [prod1 prod0]
   2116 |     // Compute remainder using mulmod
   2117 |     uint256 remainder;
>> 2118 |     assembly {
   2119 |       remainder := mulmod(a, b, denominator)
   2120 |     }
   2121 |     // Subtract 256 bit number from 512 bit number
```

---

### 64. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2122 行
- **函数**: `mulDiv()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2119 |       remainder := mulmod(a, b, denominator)
   2120 |     }
   2121 |     // Subtract 256 bit number from 512 bit number
>> 2122 |     assembly {
   2123 |       prod1 := sub(prod1, gt(remainder, prod0))
   2124 |       prod0 := sub(prod0, remainder)
   2125 |     }
```

---

### 65. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2133 行
- **函数**: `mulDiv()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2130 |     unchecked {
   2131 |       uint256 twos = (type(uint256).max - denominator + 1) & denominator;
   2132 |       // Divide denominator by power of two
>> 2133 |       assembly {
   2134 |         denominator := div(denominator, twos)
   2135 |       }
   2136 | 
```

---

### 66. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2138 行
- **函数**: `mulDiv()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2135 |       }
   2136 | 
   2137 |       // Divide [prod1 prod0] by the factors of two
>> 2138 |       assembly {
   2139 |         prod0 := div(prod0, twos)
   2140 |       }
   2141 |       // Shift in bits from prod1 into prod0. For this we need
```

---

### 67. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x407993575c91ce7643a4d4cCACc9A98c36eE1BBE` 第 2144 行
- **函数**: `mulDiv()`
- **合约**: `PinkLock02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2141 |       // Shift in bits from prod1 into prod0. For this we need
   2142 |       // to flip `twos` such that it is 2**256 / twos.
   2143 |       // If twos is zero, then it becomes one
>> 2144 |       assembly {
   2145 |         twos := add(div(sub(0, twos), twos), 1)
   2146 |       }
   2147 |       prod0 |= prod1 * twos;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*