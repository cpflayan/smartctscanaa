# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:42:41
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` |
| contract_name | `ZeroVirusT` |
| compiler_version | `v0.8.34+commit.80d5c536` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646139` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 34 |
| 🟢 LOW | 7 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 376 行
- **函数**: `_flushTaxSwaps()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    373 |         address[] memory pathSell = new address[](2);
    374 |         pathSell[0] = address(this);
    375 |         pathSell[1] = ISwapRouter(ROUTER).WETH();
>>  376 |         uint256 deadline = block.timestamp + SWAP_DEADLINE_SECONDS;
    377 | 
    378 |         if (sellM > 0) {
    379 |             r.swapExactTokensForETHSupportingFeeOnTransferTokens(sellM, _minOutSellTokens(sellM), pathSell, marketingWallet, deadline);
```

---

### 2. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol` 第 365 行
- **函数**: `_flushTaxSwaps()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in ZeroVirusT._flushTaxSwaps(uint256,uint256) (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#365-393):
	External calls:
	- r.swapExactTokensForETHSupportingFeeOnTransferTokens(sellM,_minOutSellTokens(sellM),pathSell,marketingWallet,deadline) (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#379)
	State variables written after the call(s):
	- pendingMarketingSwap -= sellM (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#380)
	ZeroVirusT.pendingMarketingSwap (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#94) can be used in cross function reentrancies:
	- ZeroVirusT._transfer(address,address,uint256) (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#231-290)
	- ZeroVirusT.pendingMarketingSwap (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#94)

**代码片段**:
```solidity
    362 |         _flushTaxSwaps(type(uint256).max, type(uint256).max);
    363 |     }
    364 | 
>>  365 |     function _flushTaxSwaps(uint256 maxMarketingSell, uint256 maxFissionWalletSell) private {
    366 |         uint256 sellM = pendingMarketingSwap <= maxMarketingSell ? pendingMarketingSwap : maxMarketingSell;
    367 |         uint256 sellF = pendingFissionWalletSwap <= maxFissionWalletSell ? pendingFissionWalletSwap : maxFissionWalletSell;
    368 |         if (sellM == 0 && sellF == 0) return;
```

---

### 3. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol` 第 365 行
- **函数**: `_flushTaxSwaps()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in ZeroVirusT._flushTaxSwaps(uint256,uint256) (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#365-393):
	External calls:
	- r.swapExactTokensForETHSupportingFeeOnTransferTokens(sellM,_minOutSellTokens(sellM),pathSell,marketingWallet,deadline) (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#379)
	- r.swapExactTokensForETHSupportingFeeOnTransferTokens(sellF,_minOutSellTokens(sellF),pathSell,FISSION_WALLET,deadline) (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#383)
	State variables written after the call(s):
	- inSwap = false (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#386)
	ZeroVirusT.inSwap (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#96) can be used in cross function reentrancies:
	- ZeroVirusT._transfer(address,address,uint256) (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#231-290)
	- pendingFissionWalletSwap -= sellF (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#384)
	ZeroVirusT.pendingFissionWalletSwap (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#95) can be used in cross function reentrancies:
	- ZeroVirusT._transfer(address,address,uint256) (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#231-290)
	- ZeroVirusT.pendingFissionWalletSwap (../../../tmp/slither_scan_bqa2h_oq/0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333.sol#95)

**代码片段**:
```solidity
    362 |         _flushTaxSwaps(type(uint256).max, type(uint256).max);
    363 |     }
    364 | 
>>  365 |     function _flushTaxSwaps(uint256 maxMarketingSell, uint256 maxFissionWalletSell) private {
    366 |         uint256 sellM = pendingMarketingSwap <= maxMarketingSell ? pendingMarketingSwap : maxMarketingSell;
    367 |         uint256 sellF = pendingFissionWalletSwap <= maxFissionWalletSell ? pendingFissionWalletSwap : maxFissionWalletSell;
    368 |         if (sellM == 0 && sellF == 0) return;
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 538 行
- **函数**: `withdrawBNB()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    535 |         uint256 bal = address(this).balance;
    536 |         uint256 v = amount == type(uint256).max ? bal : amount;
    537 |         require(v > 0 && v <= bal, "bal");
>>  538 |         (bool ok, ) = to.call{value: v}("");
    539 |         require(ok, "xfer");
    540 |         emit BNBWithdrawnByOwner(to, v);
    541 |     }
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 5 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      2 | pragma solidity ^0.8.19;
      3 | 
      4 | interface IERC20 {
>>    5 |     function decimals() external view returns (uint8);
      6 |     function symbol() external view returns (string memory);
      7 |     function name() external view returns (string memory);
      8 |     function totalSupply() external view returns (uint256);
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 6 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      3 | 
      4 | interface IERC20 {
      5 |     function decimals() external view returns (uint8);
>>    6 |     function symbol() external view returns (string memory);
      7 |     function name() external view returns (string memory);
      8 |     function totalSupply() external view returns (uint256);
      9 |     function balanceOf(address account) external view returns (uint256);
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 7 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      4 | interface IERC20 {
      5 |     function decimals() external view returns (uint8);
      6 |     function symbol() external view returns (string memory);
>>    7 |     function name() external view returns (string memory);
      8 |     function totalSupply() external view returns (uint256);
      9 |     function balanceOf(address account) external view returns (uint256);
     10 |     function transfer(address recipient, uint256 amount) external returns (bool);
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 8 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      5 |     function decimals() external view returns (uint8);
      6 |     function symbol() external view returns (string memory);
      7 |     function name() external view returns (string memory);
>>    8 |     function totalSupply() external view returns (uint256);
      9 |     function balanceOf(address account) external view returns (uint256);
     10 |     function transfer(address recipient, uint256 amount) external returns (bool);
     11 |     function allowance(address owner, address spender) external view returns (uint256);
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 9 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      6 |     function symbol() external view returns (string memory);
      7 |     function name() external view returns (string memory);
      8 |     function totalSupply() external view returns (uint256);
>>    9 |     function balanceOf(address account) external view returns (uint256);
     10 |     function transfer(address recipient, uint256 amount) external returns (bool);
     11 |     function allowance(address owner, address spender) external view returns (uint256);
     12 |     function approve(address spender, uint256 amount) external returns (bool);
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 10 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      7 |     function name() external view returns (string memory);
      8 |     function totalSupply() external view returns (uint256);
      9 |     function balanceOf(address account) external view returns (uint256);
>>   10 |     function transfer(address recipient, uint256 amount) external returns (bool);
     11 |     function allowance(address owner, address spender) external view returns (uint256);
     12 |     function approve(address spender, uint256 amount) external returns (bool);
     13 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 11 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      8 |     function totalSupply() external view returns (uint256);
      9 |     function balanceOf(address account) external view returns (uint256);
     10 |     function transfer(address recipient, uint256 amount) external returns (bool);
>>   11 |     function allowance(address owner, address spender) external view returns (uint256);
     12 |     function approve(address spender, uint256 amount) external returns (bool);
     13 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     14 |     event Transfer(address indexed from, address indexed to, uint256 value);
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 12 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      9 |     function balanceOf(address account) external view returns (uint256);
     10 |     function transfer(address recipient, uint256 amount) external returns (bool);
     11 |     function allowance(address owner, address spender) external view returns (uint256);
>>   12 |     function approve(address spender, uint256 amount) external returns (bool);
     13 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     14 |     event Transfer(address indexed from, address indexed to, uint256 value);
     15 |     event Approval(address indexed owner, address indexed spender, uint256 value);
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 13 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     10 |     function transfer(address recipient, uint256 amount) external returns (bool);
     11 |     function allowance(address owner, address spender) external view returns (uint256);
     12 |     function approve(address spender, uint256 amount) external returns (bool);
>>   13 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     14 |     event Transfer(address indexed from, address indexed to, uint256 value);
     15 |     event Approval(address indexed owner, address indexed spender, uint256 value);
     16 | }
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 19 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     16 | }
     17 | 
     18 | interface ISwapRouter {
>>   19 |     function factory() external pure returns (address);
     20 |     function WETH() external pure returns (address);
     21 | }
     22 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 20 行
- **函数**: `WETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     17 | 
     18 | interface ISwapRouter {
     19 |     function factory() external pure returns (address);
>>   20 |     function WETH() external pure returns (address);
     21 | }
     22 | 
     23 | interface IPancakeRouter02 is ISwapRouter {
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 34 行
- **函数**: `createPair()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     31 | }
     32 | 
     33 | interface ISwapFactory {
>>   34 |     function createPair(address tokenA, address tokenB) external returns (address pair);
     35 | }
     36 | 
     37 | abstract contract Ownable {
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 45 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     42 |         _owner = initialOwner;
     43 |         emit OwnershipTransferred(address(0), initialOwner);
     44 |     }
>>   45 |     function owner() public view returns (address) { return _owner; }
     46 |     modifier onlyOwner() {
     47 |         require(_owner == msg.sender, "!owner");
     48 |         _;
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 168 行
- **函数**: `swapRouter()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    165 |     }
    166 | 
    167 |     /// @notice 兼容旧读法：路由固定为 Pancake V2
>>  168 |     function swapRouter() external pure returns (address) {
    169 |         return ROUTER;
    170 |     }
    171 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 172 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    169 |         return ROUTER;
    170 |     }
    171 | 
>>  172 |     function name() external pure override returns (string memory) { return _name; }
    173 |     function symbol() external pure override returns (string memory) { return _symbol; }
    174 |     function decimals() external pure override returns (uint8) { return _decimals; }
    175 |     function totalSupply() public pure override returns (uint256) { return _tTotal; }
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 173 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    170 |     }
    171 | 
    172 |     function name() external pure override returns (string memory) { return _name; }
>>  173 |     function symbol() external pure override returns (string memory) { return _symbol; }
    174 |     function decimals() external pure override returns (uint8) { return _decimals; }
    175 |     function totalSupply() public pure override returns (uint256) { return _tTotal; }
    176 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 174 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    171 | 
    172 |     function name() external pure override returns (string memory) { return _name; }
    173 |     function symbol() external pure override returns (string memory) { return _symbol; }
>>  174 |     function decimals() external pure override returns (uint8) { return _decimals; }
    175 |     function totalSupply() public pure override returns (uint256) { return _tTotal; }
    176 | 
    177 |     /// @notice 当前总税率（基点）：为兼容旧读法，返回「卖出总税率」
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 175 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    172 |     function name() external pure override returns (string memory) { return _name; }
    173 |     function symbol() external pure override returns (string memory) { return _symbol; }
    174 |     function decimals() external pure override returns (uint8) { return _decimals; }
>>  175 |     function totalSupply() public pure override returns (uint256) { return _tTotal; }
    176 | 
    177 |     /// @notice 当前总税率（基点）：为兼容旧读法，返回「卖出总税率」
    178 |     function totalFeeBps() public view returns (uint256) {
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 178 行
- **函数**: `totalFeeBps()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    175 |     function totalSupply() public pure override returns (uint256) { return _tTotal; }
    176 | 
    177 |     /// @notice 当前总税率（基点）：为兼容旧读法，返回「卖出总税率」
>>  178 |     function totalFeeBps() public view returns (uint256) {
    179 |         return DIVIDEND_BPS + sellMarketingBps + FISSION_WALLET_BPS;
    180 |     }
    181 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 183 行
- **函数**: `buyTotalFeeBps()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    180 |     }
    181 | 
    182 |     /// @notice 买入总税率（基点）：分红 + 买入营销 + 裂变钱包
>>  183 |     function buyTotalFeeBps() public view returns (uint256) {
    184 |         return DIVIDEND_BPS + buyMarketingBps + FISSION_WALLET_BPS;
    185 |     }
    186 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 188 行
- **函数**: `sellTotalFeeBps()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    185 |     }
    186 | 
    187 |     /// @notice 卖出总税率（基点）：分红 + 卖出营销 + 裂变钱包
>>  188 |     function sellTotalFeeBps() public view returns (uint256) {
    189 |         return DIVIDEND_BPS + sellMarketingBps + FISSION_WALLET_BPS;
    190 |     }
    191 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 192 行
- **函数**: `validTotal()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    189 |         return DIVIDEND_BPS + sellMarketingBps + FISSION_WALLET_BPS;
    190 |     }
    191 | 
>>  192 |     function validTotal() public view returns (uint256) {
    193 |         return _tTotal - _balances[mainPair] - _balances[address(this)] - _balances[address(0)] - _balances[DEAD];
    194 |     }
    195 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 196 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    193 |         return _tTotal - _balances[mainPair] - _balances[address(this)] - _balances[address(0)] - _balances[DEAD];
    194 |     }
    195 | 
>>  196 |     function balanceOf(address account) public view override returns (uint256) {
    197 |         return _balances[account];
    198 |     }
    199 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 200 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    197 |         return _balances[account];
    198 |     }
    199 | 
>>  200 |     function transfer(address recipient, uint256 amount) public override returns (bool) {
    201 |         _transfer(msg.sender, recipient, amount);
    202 |         return true;
    203 |     }
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 205 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    202 |         return true;
    203 |     }
    204 | 
>>  205 |     function allowance(address owner, address spender) public view override returns (uint256) {
    206 |         return _allowances[owner][spender];
    207 |     }
    208 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 209 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    206 |         return _allowances[owner][spender];
    207 |     }
    208 | 
>>  209 |     function approve(address spender, uint256 amount) public override returns (bool) {
    210 |         _approve(msg.sender, spender, amount);
    211 |         return true;
    212 |     }
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 214 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    211 |         return true;
    212 |     }
    213 | 
>>  214 |     function transferFrom(address sender, address recipient, uint256 amount) public override returns (bool) {
    215 |         _transfer(sender, recipient, amount);
    216 |         if (_allowances[sender][msg.sender] != MAX_ALLOWANCE) {
    217 |             _allowances[sender][msg.sender] -= amount;
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 292 行
- **函数**: `getHolderLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    289 |         }
    290 |     }
    291 | 
>>  292 |     function getHolderLength() external view returns (uint256) { return holders.length; }
    293 | 
    294 |     function addHolder(address adr) private {
    295 |         if (holderIndex[adr] != 0 || (holders.length > 0 && holders[0] == adr)) return;
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 37 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     32 | 
     33 | interface ISwapFactory {
     34 |     function createPair(address tokenA, address tokenB) external returns (address pair);
     35 | }
     36 | 
>>   37 | abstract contract Ownable {
     38 |     address internal _owner;
     39 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     40 |     constructor(address initialOwner) {
     41 |         require(initialOwner != address(0), "owner 0");
     42 |         _owner = initialOwner;
```

---

### 34. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 72 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     67 |         _locked = 1;
     68 |     }
     69 | }
     70 | 
     71 | /// @title 零号病毒  — 持币分红 + 营销/裂变功能税；
>>   72 | contract ZeroVirusT is IERC20, Ownable, ReentrancyGuard {
     73 |     string private constant _name = unicode"零号病毒";
     74 |     string private constant _symbol = unicode"零号病毒";
     75 |     uint8 private constant _decimals = 0;
     76 |     uint256 private constant _tTotal = 10 * 10 ** 32 * 10 ** _decimals;
     77 | 
```

---

### 35. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 376 行
- **函数**: `_flushTaxSwaps()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    373 |         address[] memory pathSell = new address[](2);
    374 |         pathSell[0] = address(this);
    375 |         pathSell[1] = ISwapRouter(ROUTER).WETH();
>>  376 |         uint256 deadline = block.timestamp + SWAP_DEADLINE_SECONDS;
    377 | 
    378 |         if (sellM > 0) {
    379 |             r.swapExactTokensForETHSupportingFeeOnTransferTokens(sellM, _minOutSellTokens(sellM), pathSell, marketingWallet, deadline);
```

---

### 36. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 88 行
- **函数**: `transferOwnership()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     85 |     uint256 public constant FISSION_WALLET_BPS = 150;
     86 |     uint256 private constant BPS_DENOM = 10000;
     87 | 
>>   88 |     address public constant FISSION_WALLET = 0x51AD9e08C9665cF26A94c6F5D458660EF967d421;
     89 |     uint256 public constant SWAP_DEADLINE_SECONDS = 300;
     90 |     uint256 public constant SWAP_SLIPPAGE_BPS = 1000;
     91 |     uint256 public constant FLUSH_MAX_MEDIUM_PER_LEG = (_tTotal * 15 * 3) / (100 * 1000);
```

---

### 37. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 102 行
- **函数**: `transferOwnership()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     99 |     mapping(address => mapping(address => uint256)) private _allowances;
    100 | 
    101 |     /// @dev 全量代币、owner、dev 均归此地址；部署者无代币亦无管理权限
>>  102 |     address private constant INITIAL_OWNER = 0x758De9D468CBB23B55D30668D66e7d46E71b16Ef;
    103 | 
    104 |     address private constant MARKETING_DEFAULT = 0x422609d38201b029EF14814706fE701cB15ceE53;
    105 |     address public constant ROUTER = 0x10ED43C718714eb63d5aA57B78B54704E256024E;
```

---

### 38. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 104 行
- **函数**: `transferOwnership()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    101 |     /// @dev 全量代币、owner、dev 均归此地址；部署者无代币亦无管理权限
    102 |     address private constant INITIAL_OWNER = 0x758De9D468CBB23B55D30668D66e7d46E71b16Ef;
    103 | 
>>  104 |     address private constant MARKETING_DEFAULT = 0x422609d38201b029EF14814706fE701cB15ceE53;
    105 |     address public constant ROUTER = 0x10ED43C718714eb63d5aA57B78B54704E256024E;
    106 |     address public immutable mainPair;
    107 | 
```

---

### 39. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 105 行
- **函数**: `transferOwnership()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    102 |     address private constant INITIAL_OWNER = 0x758De9D468CBB23B55D30668D66e7d46E71b16Ef;
    103 | 
    104 |     address private constant MARKETING_DEFAULT = 0x422609d38201b029EF14814706fE701cB15ceE53;
>>  105 |     address public constant ROUTER = 0x10ED43C718714eb63d5aA57B78B54704E256024E;
    106 |     address public immutable mainPair;
    107 | 
    108 |     address public marketingWallet;
```

---

### 40. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 110 行
- **函数**: `transferOwnership()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    107 | 
    108 |     address public marketingWallet;
    109 |     address public devAddress;
>>  110 |     address private constant DEAD = 0x000000000000000000000000000000000000dEaD;
    111 |     uint256 public constant MAX_ALLOWANCE = type(uint256).max;
    112 | 
    113 |     mapping(address => bool) public feeWhiteList;
```

---

### 41. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x3348a84ba66cd5F9b36C2c3fD7aD1C31DD583333` 第 297 行
- **函数**: `addHolder()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    294 |     function addHolder(address adr) private {
    295 |         if (holderIndex[adr] != 0 || (holders.length > 0 && holders[0] == adr)) return;
    296 |         uint256 size;
>>  297 |         assembly { size := extcodesize(adr) }
    298 |         if (size > 0 || balanceOf(adr) < holderCondition) return;
    299 |         holderIndex[adr] = holders.length;
    300 |         holders.push(adr);
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*