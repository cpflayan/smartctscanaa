# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:20:40
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` |
| contract_name | `WrappedToken` |
| compiler_version | `v0.8.22+commit.4fc1097e` |
| optimization_used | `True` |
| runs | `1000` |
| evm_version | `shanghai` |
| license_type | `None` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/WrappedToken.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/ERC20.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/IERC20.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol', 'node_modules/@openzeppelin/contracts/utils/Context.sol', 'node_modules/@openzeppelin/contracts/interfaces/draft-IERC6093.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646143` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 25 |
| 🟢 LOW | 0 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 42 行
- **函数**: `name()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     39 |         bridge = bridge_;
     40 |     }
     41 | 
>>   42 |     function name() public view override returns (string memory) {
     43 |         return tokenName;
     44 |     }
     45 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 46 行
- **函数**: `symbol()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     43 |         return tokenName;
     44 |     }
     45 | 
>>   46 |     function symbol() public view override returns (string memory) {
     47 |         return tokenSymbol;
     48 |     }
     49 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 50 行
- **函数**: `decimals()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     47 |         return tokenSymbol;
     48 |     }
     49 | 
>>   50 |     function decimals() public view override returns (uint8) {
     51 |         return tokenDecimals;
     52 |     }
     53 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 54 行
- **函数**: `mint()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     51 |         return tokenDecimals;
     52 |     }
     53 | 
>>   54 |     function mint(address to, uint256 amount) external onlyBridge {
     55 |         _mint(to, amount);
     56 |     }
     57 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 58 行
- **函数**: `burnFrom()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     55 |         _mint(to, amount);
     56 |     }
     57 | 
>>   58 |     function burnFrom(address from, uint256 amount) external onlyBridge {
     59 |         _burn(from, amount);
     60 |     }
     61 | }
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 117 行
- **函数**: `name()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    114 |     /**
    115 |      * @dev Returns the name of the token.
    116 |      */
>>  117 |     function name() public view virtual returns (string memory) {
    118 |         return _name;
    119 |     }
    120 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 125 行
- **函数**: `symbol()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    122 |      * @dev Returns the symbol of the token, usually a shorter version of the
    123 |      * name.
    124 |      */
>>  125 |     function symbol() public view virtual returns (string memory) {
    126 |         return _symbol;
    127 |     }
    128 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 142 行
- **函数**: `decimals()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    139 |      * no way affects any of the arithmetic of the contract, including
    140 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    141 |      */
>>  142 |     function decimals() public view virtual returns (uint8) {
    143 |         return 18;
    144 |     }
    145 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 147 行
- **函数**: `totalSupply()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    144 |     }
    145 | 
    146 |     /// @inheritdoc IERC20
>>  147 |     function totalSupply() public view virtual returns (uint256) {
    148 |         return _totalSupply;
    149 |     }
    150 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 152 行
- **函数**: `balanceOf()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    149 |     }
    150 | 
    151 |     /// @inheritdoc IERC20
>>  152 |     function balanceOf(address account) public view virtual returns (uint256) {
    153 |         return _balances[account];
    154 |     }
    155 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 164 行
- **函数**: `transfer()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    161 |      * - `to` cannot be the zero address.
    162 |      * - the caller must have a balance of at least `value`.
    163 |      */
>>  164 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    165 |         address owner = _msgSender();
    166 |         _transfer(owner, to, value);
    167 |         return true;
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 171 行
- **函数**: `allowance()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    168 |     }
    169 | 
    170 |     /// @inheritdoc IERC20
>>  171 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    172 |         return _allowances[owner][spender];
    173 |     }
    174 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 185 行
- **函数**: `approve()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    182 |      *
    183 |      * - `spender` cannot be the zero address.
    184 |      */
>>  185 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    186 |         address owner = _msgSender();
    187 |         _approve(owner, spender, value);
    188 |         return true;
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 207 行
- **函数**: `transferFrom()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    204 |      * - the caller must have allowance for ``from``'s tokens of at least
    205 |      * `value`.
    206 |      */
>>  207 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    208 |         address spender = _msgSender();
    209 |         _spendAllowance(from, spender, value);
    210 |         _transfer(from, to, value);
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 401 行
- **函数**: `totalSupply()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    398 |     /**
    399 |      * @dev Returns the value of tokens in existence.
    400 |      */
>>  401 |     function totalSupply() external view returns (uint256);
    402 | 
    403 |     /**
    404 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 406 行
- **函数**: `balanceOf()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    403 |     /**
    404 |      * @dev Returns the value of tokens owned by `account`.
    405 |      */
>>  406 |     function balanceOf(address account) external view returns (uint256);
    407 | 
    408 |     /**
    409 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 415 行
- **函数**: `transfer()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    412 |      *
    413 |      * Emits a {Transfer} event.
    414 |      */
>>  415 |     function transfer(address to, uint256 value) external returns (bool);
    416 | 
    417 |     /**
    418 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 424 行
- **函数**: `allowance()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    421 |      *
    422 |      * This value changes when {approve} or {transferFrom} are called.
    423 |      */
>>  424 |     function allowance(address owner, address spender) external view returns (uint256);
    425 | 
    426 |     /**
    427 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 441 行
- **函数**: `approve()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    438 |      *
    439 |      * Emits an {Approval} event.
    440 |      */
>>  441 |     function approve(address spender, uint256 value) external returns (bool);
    442 | 
    443 |     /**
    444 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 452 行
- **函数**: `transferFrom()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    449 |      *
    450 |      * Emits a {Transfer} event.
    451 |      */
>>  452 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    453 | }
    454 | 
    455 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 472 行
- **函数**: `name()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    469 |     /**
    470 |      * @dev Returns the name of the token.
    471 |      */
>>  472 |     function name() external view returns (string memory);
    473 | 
    474 |     /**
    475 |      * @dev Returns the symbol of the token.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 477 行
- **函数**: `symbol()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    474 |     /**
    475 |      * @dev Returns the symbol of the token.
    476 |      */
>>  477 |     function symbol() external view returns (string memory);
    478 | 
    479 |     /**
    480 |      * @dev Returns the decimals places of the token.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 482 行
- **函数**: `decimals()`
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    479 |     /**
    480 |      * @dev Returns the decimals places of the token.
    481 |      */
>>  482 |     function decimals() external view returns (uint8);
    483 | }
    484 | 
    485 | 
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 8 行
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      3 | // SPDX-License-Identifier: MIT
      4 | pragma solidity ^0.8.20;
      5 | 
      6 | import { ERC20 } from "@openzeppelin/contracts/token/ERC20/ERC20.sol";
      7 | 
>>    8 | contract WrappedToken is ERC20 {
      9 |     address public bridge;
     10 |     bool public initialized;
     11 | 
     12 |     string private tokenName;
     13 |     string private tokenSymbol;
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xD98492fdc4b1853051dc251638ddA05FD2Ea0788` 第 94 行
- **合约**: `WrappedToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     89 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
     90 |  * instead returning `false` on failure. This behavior is nonetheless
     91 |  * conventional and does not conflict with the expectations of ERC-20
     92 |  * applications.
     93 |  */
>>   94 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
     95 |     mapping(address account => uint256) private _balances;
     96 | 
     97 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
     98 | 
     99 |     uint256 private _totalSupply;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*