# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:31:33
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` |
| contract_name | `FLOKI` |
| compiler_version | `v0.8.11+commit.d7f03943` |
| optimization_used | `True` |
| runs | `888` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/Floki.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/access/Ownable.sol', 'contracts/governance/IGovernanceToken.sol', 'contracts/tax/ITaxHandler.sol', 'contracts/treasury/ITreasuryHandler.sol', '@openzeppelin/contracts/utils/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655011` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 22 |
| 🟢 LOW | 3 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 89 行
- **函数**: `name()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     86 |      * @notice Get token name.
     87 |      * @return Name of the token.
     88 |      */
>>   89 |     function name() public view returns (string memory) {
     90 |         return _name;
     91 |     }
     92 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 97 行
- **函数**: `symbol()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     94 |      * @notice Get token symbol.
     95 |      * @return Symbol of the token.
     96 |      */
>>   97 |     function symbol() external view returns (string memory) {
     98 |         return _symbol;
     99 |     }
    100 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 105 行
- **函数**: `decimals()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    102 |      * @notice Get number of decimals used by the token.
    103 |      * @return Number of decimals used by the token.
    104 |      */
>>  105 |     function decimals() external pure returns (uint8) {
    106 |         return 9;
    107 |     }
    108 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 113 行
- **函数**: `totalSupply()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    110 |      * @notice Get the maximum number of tokens.
    111 |      * @return The maximum number of tokens that will ever be in existence.
    112 |      */
>>  113 |     function totalSupply() public pure override returns (uint256) {
    114 |         // Ten trillion, i.e., 10,000,000,000,000 tokens.
    115 |         return 1e13 * 1e9;
    116 |     }
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 123 行
- **函数**: `balanceOf()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    120 |      * @param account Address to retrieve balance for.
    121 |      * @return The number of tokens owned by `account`.
    122 |      */
>>  123 |     function balanceOf(address account) external view override returns (uint256) {
    124 |         return _balances[account];
    125 |     }
    126 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 133 行
- **函数**: `transfer()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    130 |      * @param amount The number of tokens to transfer to recipient.
    131 |      * @return True if transfer succeeds, else an error is raised.
    132 |      */
>>  133 |     function transfer(address recipient, uint256 amount) external override returns (bool) {
    134 |         _transfer(_msgSender(), recipient, amount);
    135 |         return true;
    136 |     }
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 144 行
- **函数**: `allowance()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    141 |      * @param spender The address authorized to spend tokens on behalf of `owner`.
    142 |      * @return The allowance `owner` has given `spender`.
    143 |      */
>>  144 |     function allowance(address owner, address spender) external view override returns (uint256) {
    145 |         return _allowances[owner][spender];
    146 |     }
    147 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 159 行
- **函数**: `approve()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    156 |      * @param amount The number of tokens `spender` is allowed to spend.
    157 |      * @return True if the approval succeeds, else an error is raised.
    158 |      */
>>  159 |     function approve(address spender, uint256 amount) external override returns (bool) {
    160 |         _approve(_msgSender(), spender, amount);
    161 |         return true;
    162 |     }
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 196 行
- **函数**: `increaseAllowance()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    193 |      * @param addedValue The number of tokens to add to `spender`'s allowance.
    194 |      * @return True if the allowance is successfully increased, else an error is raised.
    195 |      */
>>  196 |     function increaseAllowance(address spender, uint256 addedValue) external returns (bool) {
    197 |         _approve(_msgSender(), spender, _allowances[_msgSender()][spender] + addedValue);
    198 | 
    199 |         return true;
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 208 行
- **函数**: `decreaseAllowance()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    205 |      * @param subtractedValue The number of tokens to remove from `spender`'s allowance.
    206 |      * @return True if the allowance is successfully decreased, else an error is raised.
    207 |      */
>>  208 |     function decreaseAllowance(address spender, uint256 subtractedValue) external returns (bool) {
    209 |         uint256 currentAllowance = _allowances[_msgSender()][spender];
    210 |         require(
    211 |             currentAllowance >= subtractedValue,
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 227 行
- **函数**: `delegate()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    224 |      * own address.
    225 |      * @param delegatee Address to delegate votes to.
    226 |      */
>>  227 |     function delegate(address delegatee) external {
    228 |         return _delegate(msg.sender, delegatee);
    229 |     }
    230 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 269 行
- **函数**: `getVotesAtBlock()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    266 |      * @param blockNumber The block number to get the vote balance at.
    267 |      * @return The number of votes the account had as of the given block.
    268 |      */
>>  269 |     function getVotesAtBlock(address account, uint32 blockNumber) public view returns (uint224) {
    270 |         require(
    271 |             blockNumber < block.number,
    272 |             "FLOKI:getVotesAtBlock:FUTURE_BLOCK: Cannot get votes at a block in the future."
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 484 行
- **函数**: `totalSupply()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    481 |     /**
    482 |      * @dev Returns the amount of tokens in existence.
    483 |      */
>>  484 |     function totalSupply() external view returns (uint256);
    485 | 
    486 |     /**
    487 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 489 行
- **函数**: `balanceOf()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    486 |     /**
    487 |      * @dev Returns the amount of tokens owned by `account`.
    488 |      */
>>  489 |     function balanceOf(address account) external view returns (uint256);
    490 | 
    491 |     /**
    492 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 498 行
- **函数**: `transfer()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    495 |      *
    496 |      * Emits a {Transfer} event.
    497 |      */
>>  498 |     function transfer(address recipient, uint256 amount) external returns (bool);
    499 | 
    500 |     /**
    501 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 507 行
- **函数**: `allowance()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    504 |      *
    505 |      * This value changes when {approve} or {transferFrom} are called.
    506 |      */
>>  507 |     function allowance(address owner, address spender) external view returns (uint256);
    508 | 
    509 |     /**
    510 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 523 行
- **函数**: `approve()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    520 |      *
    521 |      * Emits an {Approval} event.
    522 |      */
>>  523 |     function approve(address spender, uint256 amount) external returns (bool);
    524 | 
    525 |     /**
    526 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 591 行
- **函数**: `owner()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    588 |     /**
    589 |      * @dev Returns the address of the current owner.
    590 |      */
>>  591 |     function owner() public view virtual returns (address) {
    592 |         return _owner;
    593 |     }
    594 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 660 行
- **函数**: `getVotesAtBlock()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    657 |      * @param blockNumber The block number to get the vote balance at.
    658 |      * @return The number of votes the account had as of the given block.
    659 |      */
>>  660 |     function getVotesAtBlock(address account, uint32 blockNumber) external view returns (uint224);
    661 | 
    662 |     /// @notice Emitted whenever a new delegate is set for an account.
    663 |     event DelegateChanged(address delegator, address currentDelegate, address newDelegate);
```

---

### 20. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 17 行
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     12 | 
     13 | /**
     14 |  * @title Floki token contract
     15 |  * @dev The Floki token has modular systems for tax and treasury handler as well as governance capabilities.
     16 |  */
>>   17 | contract FLOKI is IERC20, IGovernanceToken, Ownable {
     18 |     /// @dev Registry of user token balances.
     19 |     mapping(address => uint256) private _balances;
     20 | 
     21 |     /// @dev Registry of addresses users have given allowances to.
     22 |     mapping(address => mapping(address => uint256)) private _allowances;
```

---

### 21. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 234 行
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    229 |     }
    230 | 
    231 |     /**
    232 |      * @notice Delegate votes from signatory to `delegatee`.
    233 |      * @param delegatee The address to delegate votes to.
>>  234 |      * @param nonce The contract state required to match the signature.
    235 |      * @param expiry The time at which to expire the signature.
    236 |      * @param v The recovery byte of the signature.
    237 |      * @param r Half of the ECDSA signature pair.
    238 |      * @param s Half of the ECDSA signature pair.
    239 |      */
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 576 行
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    571 |  *
    572 |  * This module is used through inheritance. It will make available the modifier
    573 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    574 |  * the owner.
    575 |  */
>>  576 | abstract contract Ownable is Context {
    577 |     address private _owner;
    578 | 
    579 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    580 | 
    581 |     /**
```

---

### 23. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 256 行
- **函数**: `delegateBySig()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    253 |         address signatory = ecrecover(digest, v, r, s);
    254 | 
    255 |         require(signatory != address(0), "FLOKI:delegateBySig:INVALID_SIGNATURE: Received signature was invalid.");
>>  256 |         require(block.timestamp <= expiry, "FLOKI:delegateBySig:EXPIRED_SIGNATURE: Received signature has expired.");
    257 |         require(nonce == nonces[signatory]++, "FLOKI:delegateBySig:INVALID_NONCE: Received nonce was invalid.");
    258 | 
    259 |         return _delegate(signatory, delegatee);
```

---

### 24. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 271 行
- **函数**: `getVotesAtBlock()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    268 |      */
    269 |     function getVotesAtBlock(address account, uint32 blockNumber) public view returns (uint224) {
    270 |         require(
>>  271 |             blockNumber < block.number,
    272 |             "FLOKI:getVotesAtBlock:FUTURE_BLOCK: Cannot get votes at a block in the future."
    273 |         );
    274 | 
```

---

### 25. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xfb5B838b6cfEEdC2873aB27866079AC55363D37E` 第 400 行
- **函数**: `_writeCheckpoint()`
- **合约**: `FLOKI`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    397 |         uint224 oldVotes,
    398 |         uint224 newVotes
    399 |     ) private {
>>  400 |         uint32 blockNumber = uint32(block.number);
    401 | 
    402 |         if (nCheckpoints > 0 && checkpoints[delegatee][nCheckpoints - 1].blockNumber == blockNumber) {
    403 |             checkpoints[delegatee][nCheckpoints - 1].votes = newVotes;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*