# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:50:34
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` |
| contract_name | `FatTokenV5` |
| compiler_version | `v0.8.4+commit.c7e474f2` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655005` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 5 |
| 🟡 MEDIUM | 32 |
| 🟢 LOW | 21 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] arbitrary-send-erc20

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol` 第 945 行
- **函数**: `swapTokenForFund()`
- **扫描工具**: slither
- **综合评分**: 0.725

**工具描述**: FatTokenV5.swapTokenForFund(uint256,uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#945-1034) uses arbitrary from in transferFrom: _c.transferFrom(address(_tokenDistributor),address(this),newBal) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#977)

**代码片段**:
```solidity
    942 |         generateLpReceiverAddr = newAddr;
    943 |     }
    944 | 
>>  945 |     function swapTokenForFund(
    946 |         uint256 tokenAmount,
    947 |         uint256 swapFee
    948 |     ) private lockTheSwap {
```

---

### 2. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 658 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    655 |         bool isAdd;
    656 | 
    657 |         uint256 addLPLiquidity;
>>  658 |         if (to == _mainPair && _swapRouters[msg.sender] && tx.origin == from) {
    659 |             addLPLiquidity = _isAddLiquidity(amount);
    660 |             if (addLPLiquidity > 0 && !isContract(from)) {
    661 |                 isAdd = true;
```

---

### 3. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 746 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    743 |                     _swapPairList[from] &&
    744 |                     block.number < startTradeBlock + killBatchBlockNumber
    745 |                 ) {
>>  746 |                     if (block.number != user2blocks[tx.origin]) {
    747 |                         user2blocks[tx.origin] = block.number;
    748 |                     } else {
    749 |                         batchBots++;
```

---

### 4. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 747 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    744 |                     block.number < startTradeBlock + killBatchBlockNumber
    745 |                 ) {
    746 |                     if (block.number != user2blocks[tx.origin]) {
>>  747 |                         user2blocks[tx.origin] = block.number;
    748 |                     } else {
    749 |                         batchBots++;
    750 |                         _funTransfer(from, to, amount);
```

---

### 5. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol` 第 642 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in FatTokenV5._transfer(address,address,uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#642-802):
	External calls:
	- swapTokenForFund(numTokensSellToFund,swapFee) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#770)
		- _swapRouter.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount - lpAmount,0,toCurrencyPath,address(_tokenDistributor),block.timestamp) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#962-974)
		- _c.transferFrom(address(_tokenDistributor),address(this),newBal) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#977)
		- IWBNB(currency).withdraw(toFundAmt) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#987)
		- _c.transfer(fundAddress,toFundAmt) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#990)
		- _swapRouter.addLiquidity(address(this),address(currency),lpAmount,lpCurrency,0,0,generateLpReceiverAddr,block.timestamp) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#997-1010)
		- _swapRouter.swapExactTokensForTokensSupportingFeeOnTransferTokens(_c.balanceOf(address(this)),0,rewardPath,address(this),block.timestamp) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1021-1033)
	External calls sending eth:
	- swapTokenForFund(numTokensSellToFund,swapFee) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#770)
		- fundAddress.transfer(toFundAmt) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#988)
	State variables written after the call(s):
	- _tokenTransfer(from,to,amount,takeFee,isSell,isTransfer,isAdd,isRemove) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#785-794)
		- _balances[sender] = _balances[sender] - tAmount (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#854)
		- _balances[to] = _balances[to] + tAmount (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1041)
	FatTokenV5._balances (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#179) can be used in cross function reentrancies:
	- FatTokenV5._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#488-497)
	- FatTokenV5._funTransfer(address,address,uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#814-823)
	- FatTokenV5._takeTransfer(address,address,uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1036-1043)
	- FatTokenV5._tokenTransfer(address,address,uint256,bool,bool,bool,bool,bool) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#844-928)
	- FatTokenV5._transfer(address,address,uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#642-802)
	- FatTokenV5.balanceOf(address) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#417-422)
	- FatTokenV5.constructor(string[],address[],uint256[],bool[]) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#263-393)

**代码片段**:
```solidity
    639 |         }
    640 |     }
    641 | 
>>  642 |     function _transfer(address from, address to, uint256 amount) private {
    643 |         uint256 balance = _balances[from];
    644 |         require(balance >= amount, "balanceNotEnough");
    645 | 
```

---

### 6. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol` 第 1197 行
- **函数**: `processReward()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in FatTokenV5.processReward(uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1197-1261):
	External calls:
	- FIST.transfer(shareHolder,amount) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1250)
	State variables written after the call(s):
	- currentIndex = 0 (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1233)
	FatTokenV5.currentIndex (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1177) can be used in cross function reentrancies:
	- FatTokenV5.processReward(uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1197-1261)
	- currentIndex ++ (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1256)
	FatTokenV5.currentIndex (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1177) can be used in cross function reentrancies:
	- FatTokenV5.processReward(uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1197-1261)
	- progressRewardBlock = block.number (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1260)
	FatTokenV5.progressRewardBlock (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1179) can be used in cross function reentrancies:
	- FatTokenV5.processReward(uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1197-1261)

**代码片段**:
```solidity
   1194 |         uint256 minValue
   1195 |     );
   1196 | 
>> 1197 |     function processReward(uint256 gas) private {
   1198 |         if (progressRewardBlock + processRewardWaitBlock > block.number) {
   1199 |             return;
   1200 |         }
```

---

### 7. 🟡 [MEDIUM] tx-origin

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol` 第 642 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: FatTokenV5._transfer(address,address,uint256) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#642-802) uses tx.origin for authorization: block.number != user2blocks[tx.origin] (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#746)

**代码片段**:
```solidity
    639 |         }
    640 |     }
    641 | 
>>  642 |     function _transfer(address from, address to, uint256 amount) private {
    643 |         uint256 balance = _balances[from];
    644 |         require(balance >= amount, "balanceNotEnough");
    645 | 
```

---

### 8. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 160 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    157 | }
    158 | 
    159 | interface ISwapPair {
>>  160 |     function getReserves()
    161 |         external
    162 |         view
    163 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 9. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 524 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    521 |     bool public isAddV2;
    522 |     bool public isRemoveV2;
    523 | 
>>  524 |     function _getReserves()
    525 |         public
    526 |         view
    527 |         returns (uint256 rOther, uint256 rThis, uint256 balanceOther)
```

---

### 10. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 530 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    527 |         returns (uint256 rOther, uint256 rThis, uint256 balanceOther)
    528 |     {
    529 |         ISwapPair mainPair = ISwapPair(_mainPair);
>>  530 |         (uint r0, uint256 r1, ) = mainPair.getReserves();
    531 | 
    532 |         address tokenOther = currency;
    533 |         if (tokenOther < address(this)) {
```

---

### 11. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 547 行
- **函数**: `_isAddLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    544 |     function _isAddLiquidity(
    545 |         uint256 amount
    546 |     ) internal view returns (uint256 liquidity) {
>>  547 |         (uint256 rOther, uint256 rThis, uint256 balanceOther) = _getReserves();
    548 |         uint256 amountOther;
    549 |         if (rOther > 0 && rThis > 0) {
    550 |             amountOther = (amount * rOther) / rThis;
```

---

### 12. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 614 行
- **函数**: `_strictCheckBuy()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    611 |     function _strictCheckBuy(
    612 |         uint256 amount
    613 |     ) internal view returns (uint256 liquidity) {
>>  614 |         (uint256 rOther, uint256 rThis, uint256 balanceOther) = _getReserves();
    615 |         //isRemoveLP
    616 |         if (balanceOther < rOther) {
    617 |             liquidity =
```

---

### 13. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 633 行
- **函数**: `_isRemoveLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    630 |     function _isRemoveLiquidity(
    631 |         uint256 amount
    632 |     ) internal view returns (uint256 liquidity) {
>>  633 |         (uint256 rOther, , uint256 balanceOther) = _getReserves();
    634 |         //isRemoveLP
    635 |         if (balanceOther <= rOther) {
    636 |             liquidity =
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 24 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     21 | }
     22 | 
     23 | interface IERC20 {
>>   24 |     function decimals() external view returns (uint256);
     25 | 
     26 |     function symbol() external view returns (string memory);
     27 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 26 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     23 | interface IERC20 {
     24 |     function decimals() external view returns (uint256);
     25 | 
>>   26 |     function symbol() external view returns (string memory);
     27 | 
     28 |     function name() external view returns (string memory);
     29 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 28 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     25 | 
     26 |     function symbol() external view returns (string memory);
     27 | 
>>   28 |     function name() external view returns (string memory);
     29 | 
     30 |     function totalSupply() external view returns (uint256);
     31 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 30 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     27 | 
     28 |     function name() external view returns (string memory);
     29 | 
>>   30 |     function totalSupply() external view returns (uint256);
     31 | 
     32 |     function balanceOf(address account) external view returns (uint256);
     33 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 32 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     29 | 
     30 |     function totalSupply() external view returns (uint256);
     31 | 
>>   32 |     function balanceOf(address account) external view returns (uint256);
     33 | 
     34 |     function transfer(
     35 |         address recipient,
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 44 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     41 |         address spender
     42 |     ) external view returns (uint256);
     43 | 
>>   44 |     function approve(address spender, uint256 amount) external returns (bool);
     45 | 
     46 |     function transferFrom(
     47 |         address sender,
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 61 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     58 | }
     59 | 
     60 | interface ISwapRouter {
>>   61 |     function factory() external pure returns (address);
     62 | 
     63 |     function WETH() external pure returns (address);
     64 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 63 行
- **函数**: `WETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     60 | interface ISwapRouter {
     61 |     function factory() external pure returns (address);
     62 | 
>>   63 |     function WETH() external pure returns (address);
     64 | 
     65 |     function swapExactTokensForTokensSupportingFeeOnTransferTokens(
     66 |         uint256 amountIn,
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 115 行
- **函数**: `feeTo()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    112 |         address tokenA,
    113 |         address tokenB
    114 |     ) external view returns (address pair);
>>  115 |     function feeTo() external view returns (address);
    116 | }
    117 | 
    118 | abstract contract Ownable {
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 132 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    129 |         emit OwnershipTransferred(address(0), msgSender);
    130 |     }
    131 | 
>>  132 |     function owner() public view returns (address) {
    133 |         return _owner;
    134 |     }
    135 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 165 行
- **函数**: `token0()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    162 |         view
    163 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    164 | 
>>  165 |     function token0() external view returns (address);
    166 | 
    167 |     function balanceOf(address account) external view returns (uint256);
    168 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 167 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    164 | 
    165 |     function token0() external view returns (address);
    166 | 
>>  167 |     function balanceOf(address account) external view returns (uint256);
    168 | 
    169 |     function kLast() external view returns (uint);
    170 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 169 行
- **函数**: `kLast()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    166 | 
    167 |     function balanceOf(address account) external view returns (uint256);
    168 | 
>>  169 |     function kLast() external view returns (uint);
    170 | 
    171 |     function totalSupply() external view returns (uint256);
    172 | }
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 171 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    168 | 
    169 |     function kLast() external view returns (uint);
    170 | 
>>  171 |     function totalSupply() external view returns (uint256);
    172 | }
    173 | 
    174 | interface IWBNB {
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 395 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    392 |         // _rewardTokenDistributor = new TokenDistributor(ETH);
    393 |     }
    394 | 
>>  395 |     function symbol() external view override returns (string memory) {
    396 |         return _symbol;
    397 |     }
    398 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 399 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    396 |         return _symbol;
    397 |     }
    398 | 
>>  399 |     function name() external view override returns (string memory) {
    400 |         return _name;
    401 |     }
    402 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 403 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    400 |         return _name;
    401 |     }
    402 | 
>>  403 |     function decimals() external view override returns (uint256) {
    404 |         return _decimals;
    405 |     }
    406 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 407 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    404 |         return _decimals;
    405 |     }
    406 | 
>>  407 |     function totalSupply() public view override returns (uint256) {
    408 |         return _tTotal;
    409 |     }
    410 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 417 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    414 |         antiSYNC = s;
    415 |     }
    416 | 
>>  417 |     function balanceOf(address account) public view override returns (uint256) {
    418 |         if (account == _mainPair && msg.sender == _mainPair && antiSYNC) {
    419 |             require(_balances[_mainPair] > 0, "!sync");
    420 |         }
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 474 行
- **函数**: `isReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    471 |         kb = a;
    472 |     }
    473 | 
>>  474 |     function isReward(address account) public view returns (uint256) {
    475 |         if (_rewardList[account]) {
    476 |             return 1;
    477 |         } else {
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1186 行
- **函数**: `setMinValueToReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1183 |         processRewardWaitBlock = newValue;
   1184 |     }
   1185 | 
>> 1186 |     function setMinValueToReward(uint256 newValue) external {
   1187 |         require(fundAddress == msg.sender || _owner == msg.sender, "!Funder");
   1188 |         minValueToReward = newValue;
   1189 |     }
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 118 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    113 |         address tokenB
    114 |     ) external view returns (address pair);
    115 |     function feeTo() external view returns (address);
    116 | }
    117 | 
>>  118 | abstract contract Ownable {
    119 |     address internal _owner;
    120 | 
    121 |     event OwnershipTransferred(
    122 |         address indexed previousOwner,
    123 |         address indexed newOwner
```

---

### 36. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 153 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    148 |         emit OwnershipTransferred(_owner, newOwner);
    149 |         _owner = newOwner;
    150 |     }
    151 | }
    152 | 
>>  153 | contract TokenDistributor {
    154 |     constructor(address token) {
    155 |         IERC20(token).approve(msg.sender, uint256(~uint256(0)));
    156 |     }
    157 | }
    158 | 
```

---

### 37. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 178 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    173 | 
    174 | interface IWBNB {
    175 |     function withdraw(uint wad) external; //unwarp WBNB -> BNB
    176 | }
    177 | 
>>  178 | contract FatTokenV5 is IERC20, Ownable {
    179 |     mapping(address => uint256) private _balances;
    180 |     mapping(address => mapping(address => uint256)) private _allowances;
    181 | 
    182 |     address payable public fundAddress;
    183 | 
```

---

### 38. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol` 第 941 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: FatTokenV5.setGenerateLpReceiverAddr(address).newAddr (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#941) lacks a zero-check on :
		- generateLpReceiverAddr = newAddr (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#942)

**代码片段**:
```solidity
    938 | 
    939 |     address public generateLpReceiverAddr;
    940 | 
>>  941 |     function setGenerateLpReceiverAddr(address newAddr) public onlyOwner {
    942 |         generateLpReceiverAddr = newAddr;
    943 |     }
    944 | 
```

---

### 39. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol` 第 322 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: FatTokenV5.constructor(string[],address[],uint256[],bool[]).swapPair (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#322) lacks a zero-check on :
		- _mainPair = swapPair (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#323)

**代码片段**:
```solidity
    319 |         _swapRouters[address(swapRouter)] = true;
    320 | 
    321 |         ISwapFactory swapFactory = ISwapFactory(swapRouter.factory());
>>  322 |         address swapPair = swapFactory.createPair(address(this), currency);
    323 |         _mainPair = swapPair;
    324 |         _swapPairList[swapPair] = true;
    325 | 
```

---

### 40. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol` 第 1144 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: FatTokenV5.claimToken(address,uint256,address).to (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1144) lacks a zero-check on :
		- to.transfer(address(this).balance) (../../../tmp/slither_scan_2dse9cym/0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d.sol#1148)

**代码片段**:
```solidity
   1141 |     function claimToken(
   1142 |         address token,
   1143 |         uint256 amount,
>> 1144 |         address payable to
   1145 |     ) public {
   1146 |         require(fundAddress == msg.sender || _owner == msg.sender, "!Funder");
   1147 |         IERC20(token).transfer(to, amount);
```

---

### 41. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 701 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    698 |                     uint160(
    699 |                         uint256(
    700 |                             keccak256(
>>  701 |                                 abi.encodePacked(i, amount, block.timestamp)
    702 |                             )
    703 |                         )
    704 |                     )
```

---

### 42. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 968 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    965 |                 0,
    966 |                 toCurrencyPath,
    967 |                 address(_tokenDistributor),
>>  968 |                 block.timestamp
    969 |             )
    970 |         {} catch {
    971 |             emit Failed_swapExactTokensForTokensSupportingFeeOnTransferTokens(
```

---

### 43. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1006 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1003 |                     0,
   1004 |                     0,
   1005 |                     generateLpReceiverAddr,
>> 1006 |                     block.timestamp
   1007 |                 )
   1008 |             {} catch {
   1009 |                 emit Failed_AddLiquidity();
```

---

### 44. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1027 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1024 |                 0,
   1025 |                 rewardPath,
   1026 |                 address(this),
>> 1027 |                 block.timestamp
   1028 |             )
   1029 |         {} catch {
   1030 |             emit Failed_swapExactTokensForTokensSupportingFeeOnTransferTokens(
```

---

### 45. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 988 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    985 |         if (toFundAmt > 0) {
    986 |             if (currencyIsEth) {
    987 |                 IWBNB(currency).withdraw(toFundAmt);
>>  988 |                 fundAddress.transfer(toFundAmt);
    989 |             } else {
    990 |                 _c.transfer(fundAddress, toFundAmt);
    991 |             }
```

---

### 46. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 990 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    987 |                 IWBNB(currency).withdraw(toFundAmt);
    988 |                 fundAddress.transfer(toFundAmt);
    989 |             } else {
>>  990 |                 _c.transfer(fundAddress, toFundAmt);
    991 |             }
    992 |             totalFundAmountReceive += toFundAmt;
    993 |         }
```

---

### 47. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1147 行
- **函数**: `claimToken()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1144 |         address payable to
   1145 |     ) public {
   1146 |         require(fundAddress == msg.sender || _owner == msg.sender, "!Funder");
>> 1147 |         IERC20(token).transfer(to, amount);
   1148 |         to.transfer(address(this).balance);
   1149 |     }
   1150 | 
```

---

### 48. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1148 行
- **函数**: `claimToken()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1145 |     ) public {
   1146 |         require(fundAddress == msg.sender || _owner == msg.sender, "!Funder");
   1147 |         IERC20(token).transfer(to, amount);
>> 1148 |         to.transfer(address(this).balance);
   1149 |     }
   1150 | 
   1151 |     receive() external payable {}
```

---

### 49. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1250 行
- **函数**: `processReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1247 |                     );
   1248 |                 }
   1249 |                 if (amount > 0 && FIST.balanceOf(address(this)) > amount) {
>> 1250 |                     FIST.transfer(shareHolder, amount);
   1251 |                 }
   1252 |             }
   1253 | 
```

---

### 50. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 734 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    731 |                 if (
    732 |                     enableOffTrade &&
    733 |                     enableKillBlock &&
>>  734 |                     block.number < startTradeBlock + kb &&
    735 |                     !_swapPairList[to]
    736 |                 ) {
    737 |                     _rewardList[to] = true;
```

---

### 51. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 744 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    741 |                 if (
    742 |                     enableKillBatchBots &&
    743 |                     _swapPairList[from] &&
>>  744 |                     block.number < startTradeBlock + killBatchBlockNumber
    745 |                 ) {
    746 |                     if (block.number != user2blocks[tx.origin]) {
    747 |                         user2blocks[tx.origin] = block.number;
```

---

### 52. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 746 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    743 |                     _swapPairList[from] &&
    744 |                     block.number < startTradeBlock + killBatchBlockNumber
    745 |                 ) {
>>  746 |                     if (block.number != user2blocks[tx.origin]) {
    747 |                         user2blocks[tx.origin] = block.number;
    748 |                     } else {
    749 |                         batchBots++;
```

---

### 53. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 747 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    744 |                     block.number < startTradeBlock + killBatchBlockNumber
    745 |                 ) {
    746 |                     if (block.number != user2blocks[tx.origin]) {
>>  747 |                         user2blocks[tx.origin] = block.number;
    748 |                     } else {
    749 |                         batchBots++;
    750 |                         _funTransfer(from, to, amount);
```

---

### 54. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1059 行
- **函数**: `startLP()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1056 | 
   1057 |     function startLP() external onlyOwner {
   1058 |         require(0 == startLPBlock, "startedAddLP");
>> 1059 |         startLPBlock = block.number;
   1060 |     }
   1061 | 
   1062 |     function stopLP() external onlyOwner {
```

---

### 55. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1068 行
- **函数**: `launch()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1065 | 
   1066 |     function launch() external onlyOwner {
   1067 |         require(0 == startTradeBlock, "already open");
>> 1068 |         startTradeBlock = block.number;
   1069 |     }
   1070 | 
   1071 |     function setFeeWhiteList(
```

---

### 56. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1198 行
- **函数**: `processReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1195 |     );
   1196 | 
   1197 |     function processReward(uint256 gas) private {
>> 1198 |         if (progressRewardBlock + processRewardWaitBlock > block.number) {
   1199 |             return;
   1200 |         }
   1201 | 
```

---

### 57. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 1260 行
- **函数**: `processReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1257 |             iterations++;
   1258 |         }
   1259 | 
>> 1260 |         progressRewardBlock = block.number;
   1261 |     }
   1262 | 
   1263 |     function setHolderRewardCondition(uint256 amount) external onlyOwner {
```

---

### 58. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF46099b9a14a9767e398CD19FA996c23B2E9cB9d` 第 379 行
- **函数**: `setRewardPath()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    376 | 
    377 |         excludeHolder[address(0)] = true;
    378 |         excludeHolder[
>>  379 |             address(0x000000000000000000000000000000000000dEaD)
    380 |         ] = true;
    381 | 
    382 |         holderRewardCondition = 10 ** IERC20(ETH).decimals() / 10;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*