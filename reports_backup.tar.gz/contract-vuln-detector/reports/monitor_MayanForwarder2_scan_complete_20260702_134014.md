# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:40:14
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` |
| contract_name | `MayanForwarder2` |
| compiler_version | `v0.8.4+commit.c7e474f2` |
| optimization_used | `True` |
| runs | `800` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', '@openzeppelin/contracts/utils/Address.sol', 'src/libs/BytesLib.sol', 'src/MayanForwarder.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646139` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 26 |
| 🟢 LOW | 16 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 480 行
- **函数**: `functionDelegateCall()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    477 |         bytes memory data,
    478 |         string memory errorMessage
    479 |     ) internal returns (bytes memory) {
>>  480 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    481 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    482 |     }
    483 | 
```

---

### 2. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 287 行
- **函数**: `_callOptionalReturnBool()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    284 |         // we're implementing it ourselves. We cannot use {Address-functionCall} here since this should return false
    285 |         // and not revert is the subcall reverts.
    286 | 
>>  287 |         (bool success, bytes memory returndata) = address(token).call(data);
    288 |         return
    289 |             success && (returndata.length == 0 || abi.decode(returndata, (bool))) && Address.isContract(address(token));
    290 |     }
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 362 行
- **函数**: `sendValue()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    359 |     function sendValue(address payable recipient, uint256 amount) internal {
    360 |         require(address(this).balance >= amount, "Address: insufficient balance");
    361 | 
>>  362 |         (bool success, ) = recipient.call{value: amount}("");
    363 |         require(success, "Address: unable to send value, recipient may have reverted");
    364 |     }
    365 | 
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 430 行
- **函数**: `functionCallWithValue()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    427 |         string memory errorMessage
    428 |     ) internal returns (bytes memory) {
    429 |         require(address(this).balance >= value, "Address: insufficient balance for call");
>>  430 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    431 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    432 |     }
    433 | 
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1112 行
- **函数**: `forwardEth()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1109 | 		if (!mayanProtocols[mayanProtocol]) {
   1110 | 			revert UnsupportedProtocol();
   1111 | 		}
>> 1112 | 		(bool success, ) = mayanProtocol.call{value: msg.value}(protocolData);
   1113 | 		require(success, "mayan protocol call failed");
   1114 | 
   1115 | 		emit ForwardedEth(mayanProtocol, protocolData);
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1132 行
- **函数**: `forwardERC20()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1129 | 		pullTokenIn(tokenIn, amountIn, permitParams);
   1130 | 
   1131 | 		maxApproveIfNeeded(tokenIn, mayanProtocol, amountIn);
>> 1132 | 		(bool success, ) = mayanProtocol.call{value: msg.value}(protocolData);
   1133 | 		require(success, "mayan protocol call failed");
   1134 | 
   1135 | 		emit ForwardedERC20(tokenIn, amountIn, mayanProtocol, protocolData);
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1155 行
- **函数**: `swapAndForwardEth()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1152 | 		require(msg.value >= amountIn, "insufficient amountIn");
   1153 | 		uint256 middleAmount = IERC20(middleToken).balanceOf(address(this));
   1154 | 
>> 1155 | 		(bool success, ) = swapProtocol.call{value: amountIn}(swapData);
   1156 | 		require(success, "swap call failed");
   1157 | 
   1158 | 		middleAmount = IERC20(middleToken).balanceOf(address(this)) - middleAmount;
```

---

### 8. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1164 行
- **函数**: `swapAndForwardEth()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1161 | 		maxApproveIfNeeded(middleToken, mayanProtocol, middleAmount);
   1162 | 
   1163 | 		bytes memory modifiedData = replaceMiddleAmount(mayanData, middleAmount);
>> 1164 | 		(success, ) = mayanProtocol.call{value: msg.value - amountIn}(modifiedData);
   1165 | 		require(success, "mayan protocol call failed");
   1166 | 
   1167 | 		emit SwapAndForwardedEth(amountIn, swapProtocol, middleToken, middleAmount, mayanProtocol, mayanData);
```

---

### 9. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1196 行
- **函数**: `swapAndForwardERC20()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1193 | 		}
   1194 | 
   1195 | 		maxApproveIfNeeded(tokenIn, swapProtocol, amountIn);
>> 1196 | 		(bool success, ) = swapProtocol.call{value: 0}(swapData);
   1197 | 		require(success, "swap protocol call failed");
   1198 | 
   1199 | 		if (middleToken != address(0)) {
```

---

### 10. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1213 行
- **函数**: `swapAndForwardERC20()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1210 | 			maxApproveIfNeeded(middleToken, mayanProtocol, middleAmount);
   1211 | 		}
   1212 | 
>> 1213 | 		(success, ) = mayanProtocol.call{value: val}(middleToken == address(0) ? mayanData : replaceMiddleAmount(mayanData, middleAmount));
   1214 | 		require(success, "mayan protocol call failed");
   1215 | 
   1216 | 		transferBackRemaining(tokenIn, amountBefore);
```

---

### 11. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1298 行
- **函数**: `rescueEth()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1295 | 	function rescueEth(uint256 amount, address payable to) public {
   1296 | 		require(msg.sender == guardian, 'only guardian');
   1297 | 		require(to != address(0), 'transfer to the zero address');
>> 1298 | 		(bool success, ) = payable(to).call{value: amount}('');
   1299 | 		require(success, 'payment failed');
   1300 | 	}
   1301 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 55 行
- **函数**: `nonces()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     52 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
     53 |      * prevents a signature from being used multiple times.
     54 |      */
>>   55 |     function nonces(address owner) external view returns (uint256);
     56 | 
     57 |     /**
     58 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 61 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     58 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
     59 |      */
     60 |     // solhint-disable-next-line func-name-mixedcase
>>   61 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
     62 | }
     63 | 
     64 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 93 行
- **函数**: `totalSupply()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     90 |     /**
     91 |      * @dev Returns the amount of tokens in existence.
     92 |      */
>>   93 |     function totalSupply() external view returns (uint256);
     94 | 
     95 |     /**
     96 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 98 行
- **函数**: `balanceOf()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     95 |     /**
     96 |      * @dev Returns the amount of tokens owned by `account`.
     97 |      */
>>   98 |     function balanceOf(address account) external view returns (uint256);
     99 | 
    100 |     /**
    101 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 107 行
- **函数**: `transfer()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    104 |      *
    105 |      * Emits a {Transfer} event.
    106 |      */
>>  107 |     function transfer(address to, uint256 amount) external returns (bool);
    108 | 
    109 |     /**
    110 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 116 行
- **函数**: `allowance()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    113 |      *
    114 |      * This value changes when {approve} or {transferFrom} are called.
    115 |      */
>>  116 |     function allowance(address owner, address spender) external view returns (uint256);
    117 | 
    118 |     /**
    119 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 132 行
- **函数**: `approve()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    129 |      *
    130 |      * Emits an {Approval} event.
    131 |      */
>>  132 |     function approve(address spender, uint256 amount) external returns (bool);
    133 | 
    134 |     /**
    135 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 143 行
- **函数**: `transferFrom()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    140 |      *
    141 |      * Emits a {Transfer} event.
    142 |      */
>>  143 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
    144 | }
    145 | 
    146 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1290 行
- **函数**: `rescueToken()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1287 | 		}
   1288 | 	}
   1289 | 
>> 1290 | 	function rescueToken(address token, uint256 amount, address to) public {
   1291 | 		require(msg.sender == guardian, 'only guardian');
   1292 | 		IERC20(token).safeTransfer(to, amount);
   1293 | 	}
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1295 行
- **函数**: `rescueEth()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1292 | 		IERC20(token).safeTransfer(to, amount);
   1293 | 	}
   1294 | 
>> 1295 | 	function rescueEth(uint256 amount, address payable to) public {
   1296 | 		require(msg.sender == guardian, 'only guardian');
   1297 | 		require(to != address(0), 'transfer to the zero address');
   1298 | 		(bool success, ) = payable(to).call{value: amount}('');
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1302 行
- **函数**: `changeGuardian()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1299 | 		require(success, 'payment failed');
   1300 | 	}
   1301 | 
>> 1302 | 	function changeGuardian(address newGuardian) public {
   1303 | 		require(msg.sender == guardian, 'only guardian');
   1304 | 		nextGuardian = newGuardian;
   1305 | 	}
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1307 行
- **函数**: `claimGuardian()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1304 | 		nextGuardian = newGuardian;
   1305 | 	}
   1306 | 
>> 1307 | 	function claimGuardian() public {
   1308 | 		require(msg.sender == nextGuardian, 'only next guardian');
   1309 | 		guardian = nextGuardian;
   1310 | 	}
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1312 行
- **函数**: `setSwapProtocol()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1309 | 		guardian = nextGuardian;
   1310 | 	}
   1311 | 
>> 1312 | 	function setSwapProtocol(address swapProtocol, bool enabled) public {
   1313 | 		require(msg.sender == guardian, 'only guardian');
   1314 | 		swapProtocols[swapProtocol] = enabled;
   1315 | 	}
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1317 行
- **函数**: `setMayanProtocol()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1314 | 		swapProtocols[swapProtocol] = enabled;
   1315 | 	}
   1316 | 
>> 1317 | 	function setMayanProtocol(address mayanProtocol, bool enabled) public {
   1318 | 		require(msg.sender == guardian, 'only guardian');
   1319 | 		mayanProtocols[mayanProtocol] = enabled;
   1320 | 	}
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 161 行
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    156 | import "../../../utils/Address.sol";
    157 | 
    158 | /**
    159 |  * @title SafeERC20
    160 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>>  161 |  * contract returns false). Tokens that return no value (and instead revert or
    162 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    163 |  * successful.
    164 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    165 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    166 |  */
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 1068 行
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1063 | import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
   1064 | import "@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol";
   1065 | import "./libs/BytesLib.sol";
   1066 | 
   1067 | 
>> 1068 | contract MayanForwarder2 {
   1069 | 
   1070 | 	using SafeERC20 for IERC20;
   1071 | 	using BytesLib for bytes;
   1072 | 
   1073 | 	event SwapAndForwarded(uint256 amount);
```

---

### 28. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 714 行
- **函数**: `concatStorage()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    711 |                     add(
    712 |                         and(
    713 |                             fslot,
>>  714 |                             0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00
    715 |                         ),
    716 |                         and(mload(mc), mask)
    717 |                     )
```

---

### 29. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 531 行
- **函数**: `_revert()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    528 |         if (returndata.length > 0) {
    529 |             // The easiest way to bubble the revert reason is using memory via assembly
    530 |             /// @solidity memory-safe-assembly
>>  531 |             assembly {
    532 |                 let returndata_size := mload(returndata)
    533 |                 revert(add(32, returndata), returndata_size)
    534 |             }
```

---

### 30. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 566 行
- **函数**: `concat()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    563 |     {
    564 |         bytes memory tempBytes;
    565 | 
>>  566 |         assembly {
    567 |             // Get a location of some free memory and store it in tempBytes as
    568 |             // Solidity does for memory variables.
    569 |             tempBytes := mload(0x40)
```

---

### 31. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 635 行
- **函数**: `concatStorage()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    632 |     }
    633 | 
    634 |     function concatStorage(bytes storage _preBytes, bytes memory _postBytes) internal {
>>  635 |         assembly {
    636 |             // Read the first 32 bytes of _preBytes storage, which is the length
    637 |             // of the array. (We don't need to use the offset into the slot
    638 |             // because arrays use the entire slot.)
```

---

### 32. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 785 行
- **函数**: `slice()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    782 | 
    783 |         bytes memory tempBytes;
    784 | 
>>  785 |         assembly {
    786 |             switch iszero(_length)
    787 |             case 0 {
    788 |                 // Get a location of some free memory and store it in tempBytes as
```

---

### 33. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 844 行
- **函数**: `toAddress()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    841 |         require(_bytes.length >= _start + 20, "toAddress_outOfBounds");
    842 |         address tempAddress;
    843 | 
>>  844 |         assembly {
    845 |             tempAddress := div(mload(add(add(_bytes, 0x20), _start)), 0x1000000000000000000000000)
    846 |         }
    847 | 
```

---

### 34. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 855 行
- **函数**: `toUint8()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    852 |         require(_bytes.length >= _start + 1 , "toUint8_outOfBounds");
    853 |         uint8 tempUint;
    854 | 
>>  855 |         assembly {
    856 |             tempUint := mload(add(add(_bytes, 0x1), _start))
    857 |         }
    858 | 
```

---

### 35. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 866 行
- **函数**: `toUint16()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    863 |         require(_bytes.length >= _start + 2, "toUint16_outOfBounds");
    864 |         uint16 tempUint;
    865 | 
>>  866 |         assembly {
    867 |             tempUint := mload(add(add(_bytes, 0x2), _start))
    868 |         }
    869 | 
```

---

### 36. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 877 行
- **函数**: `toUint32()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    874 |         require(_bytes.length >= _start + 4, "toUint32_outOfBounds");
    875 |         uint32 tempUint;
    876 | 
>>  877 |         assembly {
    878 |             tempUint := mload(add(add(_bytes, 0x4), _start))
    879 |         }
    880 | 
```

---

### 37. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 888 行
- **函数**: `toUint64()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    885 |         require(_bytes.length >= _start + 8, "toUint64_outOfBounds");
    886 |         uint64 tempUint;
    887 | 
>>  888 |         assembly {
    889 |             tempUint := mload(add(add(_bytes, 0x8), _start))
    890 |         }
    891 | 
```

---

### 38. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 899 行
- **函数**: `toUint96()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    896 |         require(_bytes.length >= _start + 12, "toUint96_outOfBounds");
    897 |         uint96 tempUint;
    898 | 
>>  899 |         assembly {
    900 |             tempUint := mload(add(add(_bytes, 0xc), _start))
    901 |         }
    902 | 
```

---

### 39. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 910 行
- **函数**: `toUint128()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    907 |         require(_bytes.length >= _start + 16, "toUint128_outOfBounds");
    908 |         uint128 tempUint;
    909 | 
>>  910 |         assembly {
    911 |             tempUint := mload(add(add(_bytes, 0x10), _start))
    912 |         }
    913 | 
```

---

### 40. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 921 行
- **函数**: `toUint256()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    918 |         require(_bytes.length >= _start + 32, "toUint256_outOfBounds");
    919 |         uint256 tempUint;
    920 | 
>>  921 |         assembly {
    922 |             tempUint := mload(add(add(_bytes, 0x20), _start))
    923 |         }
    924 | 
```

---

### 41. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 932 行
- **函数**: `toBytes32()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    929 |         require(_bytes.length >= _start + 32, "toBytes32_outOfBounds");
    930 |         bytes32 tempBytes32;
    931 | 
>>  932 |         assembly {
    933 |             tempBytes32 := mload(add(add(_bytes, 0x20), _start))
    934 |         }
    935 | 
```

---

### 42. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 942 行
- **函数**: `equal()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    939 |     function equal(bytes memory _preBytes, bytes memory _postBytes) internal pure returns (bool) {
    940 |         bool success = true;
    941 | 
>>  942 |         assembly {
    943 |             let length := mload(_preBytes)
    944 | 
    945 |             // if lengths don't match the arrays are not equal
```

---

### 43. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x337685fdaB40D39bd02028545a4FfA7D287cC3E2` 第 992 行
- **函数**: `equalStorage()`
- **合约**: `returns`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    989 |     {
    990 |         bool success = true;
    991 | 
>>  992 |         assembly {
    993 |             // we know _preBytes_offset is 0
    994 |             let fslot := sload(_preBytes.slot)
    995 |             // Decode the length of the stored array like in concatStorage().
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*