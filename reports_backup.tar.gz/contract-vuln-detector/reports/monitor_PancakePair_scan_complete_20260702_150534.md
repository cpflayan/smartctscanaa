# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:05:34
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` |
| contract_name | `PancakePair` |
| compiler_version | `v0.5.16+commit.9c3226ce` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 71 |
| 🟢 LOW | 4 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 42 行
- **函数**: `getReserves()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
     39 |     function factory() external view returns (address);
     40 |     function token0() external view returns (address);
     41 |     function token1() external view returns (address);
>>   42 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     43 |     function price0CumulativeLast() external view returns (uint);
     44 |     function price1CumulativeLast() external view returns (uint);
     45 |     function kLast() external view returns (uint);
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 331 行
- **函数**: `getReserves()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    328 |         unlocked = 1;
    329 |     }
    330 | 
>>  331 |     function getReserves() public view returns (uint112 _reserve0, uint112 _reserve1, uint32 _blockTimestampLast) {
    332 |         _reserve0 = reserve0;
    333 |         _reserve1 = reserve1;
    334 |         _blockTimestampLast = blockTimestampLast;
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 404 行
- **函数**: `mint()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    401 | 
    402 |     // this low-level function should be called from a contract which performs important safety checks
    403 |     function mint(address to) external lock returns (uint liquidity) {
>>  404 |         (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
    405 |         uint balance0 = IERC20(token0).balanceOf(address(this));
    406 |         uint balance1 = IERC20(token1).balanceOf(address(this));
    407 |         uint amount0 = balance0.sub(_reserve0);
```

---

### 4. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 428 行
- **函数**: `burn()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    425 | 
    426 |     // this low-level function should be called from a contract which performs important safety checks
    427 |     function burn(address to) external lock returns (uint amount0, uint amount1) {
>>  428 |         (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
    429 |         address _token0 = token0;                                // gas savings
    430 |         address _token1 = token1;                                // gas savings
    431 |         uint balance0 = IERC20(_token0).balanceOf(address(this));
```

---

### 5. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 454 行
- **函数**: `swap()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    451 |     // this low-level function should be called from a contract which performs important safety checks
    452 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external lock {
    453 |         require(amount0Out > 0 || amount1Out > 0, 'Pancake: INSUFFICIENT_OUTPUT_AMOUNT');
>>  454 |         (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
    455 |         require(amount0Out < _reserve0 && amount1Out < _reserve1, 'Pancake: INSUFFICIENT_LIQUIDITY');
    456 | 
    457 |         uint balance0;
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 338 行
- **函数**: `_safeTransfer()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    335 |     }
    336 | 
    337 |     function _safeTransfer(address token, address to, uint value) private {
>>  338 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(SELECTOR, to, value));
    339 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'Pancake: TRANSFER_FAILED');
    340 |     }
    341 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 9 行
- **函数**: `name()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      6 |     event Approval(address indexed owner, address indexed spender, uint value);
      7 |     event Transfer(address indexed from, address indexed to, uint value);
      8 | 
>>    9 |     function name() external pure returns (string memory);
     10 |     function symbol() external pure returns (string memory);
     11 |     function decimals() external pure returns (uint8);
     12 |     function totalSupply() external view returns (uint);
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 10 行
- **函数**: `symbol()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      7 |     event Transfer(address indexed from, address indexed to, uint value);
      8 | 
      9 |     function name() external pure returns (string memory);
>>   10 |     function symbol() external pure returns (string memory);
     11 |     function decimals() external pure returns (uint8);
     12 |     function totalSupply() external view returns (uint);
     13 |     function balanceOf(address owner) external view returns (uint);
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 11 行
- **函数**: `decimals()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      8 | 
      9 |     function name() external pure returns (string memory);
     10 |     function symbol() external pure returns (string memory);
>>   11 |     function decimals() external pure returns (uint8);
     12 |     function totalSupply() external view returns (uint);
     13 |     function balanceOf(address owner) external view returns (uint);
     14 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 12 行
- **函数**: `totalSupply()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      9 |     function name() external pure returns (string memory);
     10 |     function symbol() external pure returns (string memory);
     11 |     function decimals() external pure returns (uint8);
>>   12 |     function totalSupply() external view returns (uint);
     13 |     function balanceOf(address owner) external view returns (uint);
     14 |     function allowance(address owner, address spender) external view returns (uint);
     15 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 13 行
- **函数**: `balanceOf()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     10 |     function symbol() external pure returns (string memory);
     11 |     function decimals() external pure returns (uint8);
     12 |     function totalSupply() external view returns (uint);
>>   13 |     function balanceOf(address owner) external view returns (uint);
     14 |     function allowance(address owner, address spender) external view returns (uint);
     15 | 
     16 |     function approve(address spender, uint value) external returns (bool);
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 14 行
- **函数**: `allowance()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     11 |     function decimals() external pure returns (uint8);
     12 |     function totalSupply() external view returns (uint);
     13 |     function balanceOf(address owner) external view returns (uint);
>>   14 |     function allowance(address owner, address spender) external view returns (uint);
     15 | 
     16 |     function approve(address spender, uint value) external returns (bool);
     17 |     function transfer(address to, uint value) external returns (bool);
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 16 行
- **函数**: `approve()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     13 |     function balanceOf(address owner) external view returns (uint);
     14 |     function allowance(address owner, address spender) external view returns (uint);
     15 | 
>>   16 |     function approve(address spender, uint value) external returns (bool);
     17 |     function transfer(address to, uint value) external returns (bool);
     18 |     function transferFrom(address from, address to, uint value) external returns (bool);
     19 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 17 行
- **函数**: `transfer()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     14 |     function allowance(address owner, address spender) external view returns (uint);
     15 | 
     16 |     function approve(address spender, uint value) external returns (bool);
>>   17 |     function transfer(address to, uint value) external returns (bool);
     18 |     function transferFrom(address from, address to, uint value) external returns (bool);
     19 | 
     20 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 18 行
- **函数**: `transferFrom()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     15 | 
     16 |     function approve(address spender, uint value) external returns (bool);
     17 |     function transfer(address to, uint value) external returns (bool);
>>   18 |     function transferFrom(address from, address to, uint value) external returns (bool);
     19 | 
     20 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
     21 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 20 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     17 |     function transfer(address to, uint value) external returns (bool);
     18 |     function transferFrom(address from, address to, uint value) external returns (bool);
     19 | 
>>   20 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
     21 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
     22 |     function nonces(address owner) external view returns (uint);
     23 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 21 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     18 |     function transferFrom(address from, address to, uint value) external returns (bool);
     19 | 
     20 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>>   21 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
     22 |     function nonces(address owner) external view returns (uint);
     23 | 
     24 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 22 行
- **函数**: `nonces()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     19 | 
     20 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
     21 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>>   22 |     function nonces(address owner) external view returns (uint);
     23 | 
     24 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
     25 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 38 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     35 |     );
     36 |     event Sync(uint112 reserve0, uint112 reserve1);
     37 | 
>>   38 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
     39 |     function factory() external view returns (address);
     40 |     function token0() external view returns (address);
     41 |     function token1() external view returns (address);
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 39 行
- **函数**: `factory()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     36 |     event Sync(uint112 reserve0, uint112 reserve1);
     37 | 
     38 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
>>   39 |     function factory() external view returns (address);
     40 |     function token0() external view returns (address);
     41 |     function token1() external view returns (address);
     42 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 40 行
- **函数**: `token0()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     37 | 
     38 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
     39 |     function factory() external view returns (address);
>>   40 |     function token0() external view returns (address);
     41 |     function token1() external view returns (address);
     42 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     43 |     function price0CumulativeLast() external view returns (uint);
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 41 行
- **函数**: `token1()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     38 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
     39 |     function factory() external view returns (address);
     40 |     function token0() external view returns (address);
>>   41 |     function token1() external view returns (address);
     42 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     43 |     function price0CumulativeLast() external view returns (uint);
     44 |     function price1CumulativeLast() external view returns (uint);
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 42 行
- **函数**: `getReserves()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     39 |     function factory() external view returns (address);
     40 |     function token0() external view returns (address);
     41 |     function token1() external view returns (address);
>>   42 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     43 |     function price0CumulativeLast() external view returns (uint);
     44 |     function price1CumulativeLast() external view returns (uint);
     45 |     function kLast() external view returns (uint);
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 43 行
- **函数**: `price0CumulativeLast()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     40 |     function token0() external view returns (address);
     41 |     function token1() external view returns (address);
     42 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>>   43 |     function price0CumulativeLast() external view returns (uint);
     44 |     function price1CumulativeLast() external view returns (uint);
     45 |     function kLast() external view returns (uint);
     46 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 44 行
- **函数**: `price1CumulativeLast()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     41 |     function token1() external view returns (address);
     42 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     43 |     function price0CumulativeLast() external view returns (uint);
>>   44 |     function price1CumulativeLast() external view returns (uint);
     45 |     function kLast() external view returns (uint);
     46 | 
     47 |     function mint(address to) external returns (uint liquidity);
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 45 行
- **函数**: `kLast()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     42 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     43 |     function price0CumulativeLast() external view returns (uint);
     44 |     function price1CumulativeLast() external view returns (uint);
>>   45 |     function kLast() external view returns (uint);
     46 | 
     47 |     function mint(address to) external returns (uint liquidity);
     48 |     function burn(address to) external returns (uint amount0, uint amount1);
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 47 行
- **函数**: `mint()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     44 |     function price1CumulativeLast() external view returns (uint);
     45 |     function kLast() external view returns (uint);
     46 | 
>>   47 |     function mint(address to) external returns (uint liquidity);
     48 |     function burn(address to) external returns (uint amount0, uint amount1);
     49 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
     50 |     function skim(address to) external;
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 48 行
- **函数**: `burn()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     45 |     function kLast() external view returns (uint);
     46 | 
     47 |     function mint(address to) external returns (uint liquidity);
>>   48 |     function burn(address to) external returns (uint amount0, uint amount1);
     49 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
     50 |     function skim(address to) external;
     51 |     function sync() external;
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 64 行
- **函数**: `name()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     61 |     event Approval(address indexed owner, address indexed spender, uint value);
     62 |     event Transfer(address indexed from, address indexed to, uint value);
     63 | 
>>   64 |     function name() external pure returns (string memory);
     65 |     function symbol() external pure returns (string memory);
     66 |     function decimals() external pure returns (uint8);
     67 |     function totalSupply() external view returns (uint);
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 65 行
- **函数**: `symbol()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     62 |     event Transfer(address indexed from, address indexed to, uint value);
     63 | 
     64 |     function name() external pure returns (string memory);
>>   65 |     function symbol() external pure returns (string memory);
     66 |     function decimals() external pure returns (uint8);
     67 |     function totalSupply() external view returns (uint);
     68 |     function balanceOf(address owner) external view returns (uint);
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 66 行
- **函数**: `decimals()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     63 | 
     64 |     function name() external pure returns (string memory);
     65 |     function symbol() external pure returns (string memory);
>>   66 |     function decimals() external pure returns (uint8);
     67 |     function totalSupply() external view returns (uint);
     68 |     function balanceOf(address owner) external view returns (uint);
     69 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 67 行
- **函数**: `totalSupply()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     64 |     function name() external pure returns (string memory);
     65 |     function symbol() external pure returns (string memory);
     66 |     function decimals() external pure returns (uint8);
>>   67 |     function totalSupply() external view returns (uint);
     68 |     function balanceOf(address owner) external view returns (uint);
     69 |     function allowance(address owner, address spender) external view returns (uint);
     70 | 
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 68 行
- **函数**: `balanceOf()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     65 |     function symbol() external pure returns (string memory);
     66 |     function decimals() external pure returns (uint8);
     67 |     function totalSupply() external view returns (uint);
>>   68 |     function balanceOf(address owner) external view returns (uint);
     69 |     function allowance(address owner, address spender) external view returns (uint);
     70 | 
     71 |     function approve(address spender, uint value) external returns (bool);
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 69 行
- **函数**: `allowance()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     66 |     function decimals() external pure returns (uint8);
     67 |     function totalSupply() external view returns (uint);
     68 |     function balanceOf(address owner) external view returns (uint);
>>   69 |     function allowance(address owner, address spender) external view returns (uint);
     70 | 
     71 |     function approve(address spender, uint value) external returns (bool);
     72 |     function transfer(address to, uint value) external returns (bool);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 71 行
- **函数**: `approve()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     68 |     function balanceOf(address owner) external view returns (uint);
     69 |     function allowance(address owner, address spender) external view returns (uint);
     70 | 
>>   71 |     function approve(address spender, uint value) external returns (bool);
     72 |     function transfer(address to, uint value) external returns (bool);
     73 |     function transferFrom(address from, address to, uint value) external returns (bool);
     74 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 72 行
- **函数**: `transfer()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     69 |     function allowance(address owner, address spender) external view returns (uint);
     70 | 
     71 |     function approve(address spender, uint value) external returns (bool);
>>   72 |     function transfer(address to, uint value) external returns (bool);
     73 |     function transferFrom(address from, address to, uint value) external returns (bool);
     74 | 
     75 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 73 行
- **函数**: `transferFrom()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     70 | 
     71 |     function approve(address spender, uint value) external returns (bool);
     72 |     function transfer(address to, uint value) external returns (bool);
>>   73 |     function transferFrom(address from, address to, uint value) external returns (bool);
     74 | 
     75 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
     76 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 75 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     72 |     function transfer(address to, uint value) external returns (bool);
     73 |     function transferFrom(address from, address to, uint value) external returns (bool);
     74 | 
>>   75 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
     76 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
     77 |     function nonces(address owner) external view returns (uint);
     78 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 76 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     73 |     function transferFrom(address from, address to, uint value) external returns (bool);
     74 | 
     75 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>>   76 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
     77 |     function nonces(address owner) external view returns (uint);
     78 | 
     79 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 77 行
- **函数**: `nonces()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     74 | 
     75 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
     76 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>>   77 |     function nonces(address owner) external view returns (uint);
     78 | 
     79 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
     80 | }
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 164 行
- **函数**: `approve()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    161 |         emit Transfer(from, to, value);
    162 |     }
    163 | 
>>  164 |     function approve(address spender, uint value) external returns (bool) {
    165 |         _approve(msg.sender, spender, value);
    166 |         return true;
    167 |     }
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 169 行
- **函数**: `transfer()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    166 |         return true;
    167 |     }
    168 | 
>>  169 |     function transfer(address to, uint value) external returns (bool) {
    170 |         _transfer(msg.sender, to, value);
    171 |         return true;
    172 |     }
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 174 行
- **函数**: `transferFrom()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    171 |         return true;
    172 |     }
    173 | 
>>  174 |     function transferFrom(address from, address to, uint value) external returns (bool) {
    175 |         if (allowance[from][msg.sender] != uint(-1)) {
    176 |             allowance[from][msg.sender] = allowance[from][msg.sender].sub(value);
    177 |         }
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 182 行
- **函数**: `permit()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    179 |         return true;
    180 |     }
    181 | 
>>  182 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external {
    183 |         require(deadline >= block.timestamp, 'Pancake: EXPIRED');
    184 |         bytes32 digest = keccak256(
    185 |             abi.encodePacked(
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 254 行
- **函数**: `name()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    251 |     event Approval(address indexed owner, address indexed spender, uint value);
    252 |     event Transfer(address indexed from, address indexed to, uint value);
    253 | 
>>  254 |     function name() external view returns (string memory);
    255 |     function symbol() external view returns (string memory);
    256 |     function decimals() external view returns (uint8);
    257 |     function totalSupply() external view returns (uint);
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 255 行
- **函数**: `symbol()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    252 |     event Transfer(address indexed from, address indexed to, uint value);
    253 | 
    254 |     function name() external view returns (string memory);
>>  255 |     function symbol() external view returns (string memory);
    256 |     function decimals() external view returns (uint8);
    257 |     function totalSupply() external view returns (uint);
    258 |     function balanceOf(address owner) external view returns (uint);
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 256 行
- **函数**: `decimals()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    253 | 
    254 |     function name() external view returns (string memory);
    255 |     function symbol() external view returns (string memory);
>>  256 |     function decimals() external view returns (uint8);
    257 |     function totalSupply() external view returns (uint);
    258 |     function balanceOf(address owner) external view returns (uint);
    259 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 257 行
- **函数**: `totalSupply()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    254 |     function name() external view returns (string memory);
    255 |     function symbol() external view returns (string memory);
    256 |     function decimals() external view returns (uint8);
>>  257 |     function totalSupply() external view returns (uint);
    258 |     function balanceOf(address owner) external view returns (uint);
    259 |     function allowance(address owner, address spender) external view returns (uint);
    260 | 
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 258 行
- **函数**: `balanceOf()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    255 |     function symbol() external view returns (string memory);
    256 |     function decimals() external view returns (uint8);
    257 |     function totalSupply() external view returns (uint);
>>  258 |     function balanceOf(address owner) external view returns (uint);
    259 |     function allowance(address owner, address spender) external view returns (uint);
    260 | 
    261 |     function approve(address spender, uint value) external returns (bool);
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 259 行
- **函数**: `allowance()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    256 |     function decimals() external view returns (uint8);
    257 |     function totalSupply() external view returns (uint);
    258 |     function balanceOf(address owner) external view returns (uint);
>>  259 |     function allowance(address owner, address spender) external view returns (uint);
    260 | 
    261 |     function approve(address spender, uint value) external returns (bool);
    262 |     function transfer(address to, uint value) external returns (bool);
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 261 行
- **函数**: `approve()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    258 |     function balanceOf(address owner) external view returns (uint);
    259 |     function allowance(address owner, address spender) external view returns (uint);
    260 | 
>>  261 |     function approve(address spender, uint value) external returns (bool);
    262 |     function transfer(address to, uint value) external returns (bool);
    263 |     function transferFrom(address from, address to, uint value) external returns (bool);
    264 | }
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 262 行
- **函数**: `transfer()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    259 |     function allowance(address owner, address spender) external view returns (uint);
    260 | 
    261 |     function approve(address spender, uint value) external returns (bool);
>>  262 |     function transfer(address to, uint value) external returns (bool);
    263 |     function transferFrom(address from, address to, uint value) external returns (bool);
    264 | }
    265 | 
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 263 行
- **函数**: `transferFrom()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    260 | 
    261 |     function approve(address spender, uint value) external returns (bool);
    262 |     function transfer(address to, uint value) external returns (bool);
>>  263 |     function transferFrom(address from, address to, uint value) external returns (bool);
    264 | }
    265 | 
    266 | // File: contracts\interfaces\IPancakeFactory.sol
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 273 行
- **函数**: `feeTo()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    270 | interface IPancakeFactory {
    271 |     event PairCreated(address indexed token0, address indexed token1, address pair, uint);
    272 | 
>>  273 |     function feeTo() external view returns (address);
    274 |     function feeToSetter() external view returns (address);
    275 | 
    276 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 274 行
- **函数**: `feeToSetter()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    271 |     event PairCreated(address indexed token0, address indexed token1, address pair, uint);
    272 | 
    273 |     function feeTo() external view returns (address);
>>  274 |     function feeToSetter() external view returns (address);
    275 | 
    276 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    277 |     function allPairs(uint) external view returns (address pair);
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 276 行
- **函数**: `getPair()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    273 |     function feeTo() external view returns (address);
    274 |     function feeToSetter() external view returns (address);
    275 | 
>>  276 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    277 |     function allPairs(uint) external view returns (address pair);
    278 |     function allPairsLength() external view returns (uint);
    279 | 
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 277 行
- **函数**: `allPairs()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    274 |     function feeToSetter() external view returns (address);
    275 | 
    276 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
>>  277 |     function allPairs(uint) external view returns (address pair);
    278 |     function allPairsLength() external view returns (uint);
    279 | 
    280 |     function createPair(address tokenA, address tokenB) external returns (address pair);
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 278 行
- **函数**: `allPairsLength()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    275 | 
    276 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    277 |     function allPairs(uint) external view returns (address pair);
>>  278 |     function allPairsLength() external view returns (uint);
    279 | 
    280 |     function createPair(address tokenA, address tokenB) external returns (address pair);
    281 | 
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 280 行
- **函数**: `createPair()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    277 |     function allPairs(uint) external view returns (address pair);
    278 |     function allPairsLength() external view returns (uint);
    279 | 
>>  280 |     function createPair(address tokenA, address tokenB) external returns (address pair);
    281 | 
    282 |     function setFeeTo(address) external;
    283 |     function setFeeToSetter(address) external;
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 331 行
- **函数**: `getReserves()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    328 |         unlocked = 1;
    329 |     }
    330 | 
>>  331 |     function getReserves() public view returns (uint112 _reserve0, uint112 _reserve1, uint32 _blockTimestampLast) {
    332 |         _reserve0 = reserve0;
    333 |         _reserve1 = reserve1;
    334 |         _blockTimestampLast = blockTimestampLast;
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 359 行
- **函数**: `initialize()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    356 |     }
    357 | 
    358 |     // called once by the factory at time of deployment
>>  359 |     function initialize(address _token0, address _token1) external {
    360 |         require(msg.sender == factory, 'Pancake: FORBIDDEN'); // sufficient check
    361 |         token0 = _token0;
    362 |         token1 = _token1;
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 403 行
- **函数**: `mint()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    400 |     }
    401 | 
    402 |     // this low-level function should be called from a contract which performs important safety checks
>>  403 |     function mint(address to) external lock returns (uint liquidity) {
    404 |         (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
    405 |         uint balance0 = IERC20(token0).balanceOf(address(this));
    406 |         uint balance1 = IERC20(token1).balanceOf(address(this));
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 427 行
- **函数**: `burn()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    424 |     }
    425 | 
    426 |     // this low-level function should be called from a contract which performs important safety checks
>>  427 |     function burn(address to) external lock returns (uint amount0, uint amount1) {
    428 |         (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
    429 |         address _token0 = token0;                                // gas savings
    430 |         address _token1 = token1;                                // gas savings
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 452 行
- **函数**: `swap()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    449 |     }
    450 | 
    451 |     // this low-level function should be called from a contract which performs important safety checks
>>  452 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external lock {
    453 |         require(amount0Out > 0 || amount1Out > 0, 'Pancake: INSUFFICIENT_OUTPUT_AMOUNT');
    454 |         (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
    455 |         require(amount0Out < _reserve0 && amount1Out < _reserve1, 'Pancake: INSUFFICIENT_LIQUIDITY');
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 483 行
- **函数**: `skim()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    480 |     }
    481 | 
    482 |     // force balances to match reserves
>>  483 |     function skim(address to) external lock {
    484 |         address _token0 = token0; // gas savings
    485 |         address _token1 = token1; // gas savings
    486 |         _safeTransfer(_token0, to, IERC20(_token0).balanceOf(address(this)).sub(reserve0));
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 491 行
- **函数**: `sync()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    488 |     }
    489 | 
    490 |     // force reserves to match balances
>>  491 |     function sync() external lock {
    492 |         _update(IERC20(token0).balanceOf(address(this)), IERC20(token1).balanceOf(address(this)), reserve0, reserve1);
    493 |     }
    494 | }
```

---

### 67. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 107 行
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    102 | // File: contracts\PancakeERC20.sol
    103 | 
    104 | pragma solidity =0.5.16;
    105 | 
    106 | 
>>  107 | contract PancakeERC20 is IPancakeERC20 {
    108 |     using SafeMath for uint;
    109 | 
    110 |     string public constant name = 'Pancake LPs';
    111 |     string public constant symbol = 'Cake-LP';
    112 |     uint8 public constant decimals = 18;
```

---

### 68. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 304 行
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    299 | 
    300 | 
    301 | 
    302 | 
    303 | 
>>  304 | contract PancakePair is IPancakePair, PancakeERC20 {
    305 |     using SafeMath  for uint;
    306 |     using UQ112x112 for uint224;
    307 | 
    308 |     uint public constant MINIMUM_LIQUIDITY = 10**3;
    309 |     bytes4 private constant SELECTOR = bytes4(keccak256(bytes('transfer(address,uint256)')));
```

---

### 69. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 402 行
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    397 |         } else if (_kLast != 0) {
    398 |             kLast = 0;
    399 |         }
    400 |     }
    401 | 
>>  402 |     // this low-level function should be called from a contract which performs important safety checks
    403 |     function mint(address to) external lock returns (uint liquidity) {
    404 |         (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
    405 |         uint balance0 = IERC20(token0).balanceOf(address(this));
    406 |         uint balance1 = IERC20(token1).balanceOf(address(this));
    407 |         uint amount0 = balance0.sub(_reserve0);
```

---

### 70. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 426 行
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    421 |         _update(balance0, balance1, _reserve0, _reserve1);
    422 |         if (feeOn) kLast = uint(reserve0).mul(reserve1); // reserve0 and reserve1 are up-to-date
    423 |         emit Mint(msg.sender, amount0, amount1);
    424 |     }
    425 | 
>>  426 |     // this low-level function should be called from a contract which performs important safety checks
    427 |     function burn(address to) external lock returns (uint amount0, uint amount1) {
    428 |         (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
    429 |         address _token0 = token0;                                // gas savings
    430 |         address _token1 = token1;                                // gas savings
    431 |         uint balance0 = IERC20(_token0).balanceOf(address(this));
```

---

### 71. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 451 行
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    446 |         _update(balance0, balance1, _reserve0, _reserve1);
    447 |         if (feeOn) kLast = uint(reserve0).mul(reserve1); // reserve0 and reserve1 are up-to-date
    448 |         emit Burn(msg.sender, amount0, amount1, to);
    449 |     }
    450 | 
>>  451 |     // this low-level function should be called from a contract which performs important safety checks
    452 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external lock {
    453 |         require(amount0Out > 0 || amount1Out > 0, 'Pancake: INSUFFICIENT_OUTPUT_AMOUNT');
    454 |         (uint112 _reserve0, uint112 _reserve1,) = getReserves(); // gas savings
    455 |         require(amount0Out < _reserve0 && amount1Out < _reserve1, 'Pancake: INSUFFICIENT_LIQUIDITY');
    456 | 
```

---

### 72. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 183 行
- **函数**: `permit()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    180 |     }
    181 | 
    182 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external {
>>  183 |         require(deadline >= block.timestamp, 'Pancake: EXPIRED');
    184 |         bytes32 digest = keccak256(
    185 |             abi.encodePacked(
    186 |                 '\x19\x01',
```

---

### 73. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 368 行
- **函数**: `_update()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    365 |     // update reserves and, on the first call per block, price accumulators
    366 |     function _update(uint balance0, uint balance1, uint112 _reserve0, uint112 _reserve1) private {
    367 |         require(balance0 <= uint112(-1) && balance1 <= uint112(-1), 'Pancake: OVERFLOW');
>>  368 |         uint32 blockTimestamp = uint32(block.timestamp % 2**32);
    369 |         uint32 timeElapsed = blockTimestamp - blockTimestampLast; // overflow is desired
    370 |         if (timeElapsed > 0 && _reserve0 != 0 && _reserve1 != 0) {
    371 |             // * never overflows, and + overflow is desired
```

---

### 74. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 119 行
- **函数**: `mul()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    116 | 
    117 |     bytes32 public DOMAIN_SEPARATOR;
    118 |     // keccak256("Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)");
>>  119 |     bytes32 public constant PERMIT_TYPEHASH = 0x6e71edae12b1b97f4d1f60370fef10105fa2faae0126114a169c64845d6126c9;
    120 |     mapping(address => uint) public nonces;
    121 | 
    122 |     event Approval(address indexed owner, address indexed spender, uint value);
```

---

### 75. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xBD937D8aeD1bc812D4234e0DBA6331675B343621` 第 127 行
- **函数**: `mul()`
- **合约**: `PancakeERC20`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    124 | 
    125 |     constructor() public {
    126 |         uint chainId;
>>  127 |         assembly {
    128 |             chainId := chainid
    129 |         }
    130 |         DOMAIN_SEPARATOR = keccak256(
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*