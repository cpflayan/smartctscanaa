# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:51:01
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x19Ed254efa5E061D28d84650891a3db2A9940C16` |
| contract_name | `SupMain` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `london` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/ILayerZeroEndpointV2.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/ILayerZeroReceiver.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessageLib.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessageLibManager.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessagingChannel.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessagingComposer.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessagingContext.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/ISendLib.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/libs/AddressCast.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/messagelib/libs/PacketV1Codec.sol', '@layerzerolabs/oapp-evm/contracts/oapp/interfaces/IOAppCore.sol', '@layerzerolabs/oapp-evm/contracts/oapp/interfaces/IOAppMsgInspector.sol', '@layerzerolabs/oapp-evm/contracts/oapp/interfaces/IOAppOptionsType3.sol', '@layerzerolabs/oapp-evm/contracts/oapp/interfaces/IOAppReceiver.sol', '@layerzerolabs/oapp-evm/contracts/oapp/libs/OAppOptionsType3.sol', '@layerzerolabs/oapp-evm/contracts/oapp/OApp.sol', '@layerzerolabs/oapp-evm/contracts/oapp/OAppCore.sol', '@layerzerolabs/oapp-evm/contracts/oapp/OAppReceiver.sol', '@layerzerolabs/oapp-evm/contracts/oapp/OAppSender.sol', '@layerzerolabs/oapp-evm/contracts/precrime/interfaces/IOAppPreCrimeSimulator.sol', '@layerzerolabs/oapp-evm/contracts/precrime/interfaces/IPreCrime.sol', '@layerzerolabs/oapp-evm/contracts/precrime/libs/Packet.sol', '@layerzerolabs/oapp-evm/contracts/precrime/OAppPreCrimeSimulator.sol', '@layerzerolabs/oft-evm/contracts/interfaces/IOFT.sol', '@layerzerolabs/oft-evm/contracts/libs/OFTComposeMsgCodec.sol', '@layerzerolabs/oft-evm/contracts/libs/OFTMsgCodec.sol', '@layerzerolabs/oft-evm/contracts/OFT.sol', '@layerzerolabs/oft-evm/contracts/OFTCore.sol', '@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/interfaces/draft-IERC6093.sol', '@openzeppelin/contracts/interfaces/IERC1363.sol', '@openzeppelin/contracts/interfaces/IERC165.sol', '@openzeppelin/contracts/interfaces/IERC20.sol', '@openzeppelin/contracts/token/ERC20/ERC20.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/utils/introspection/IERC165.sol', 'contracts/SupMain.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646140` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 96 |
| 🟢 LOW | 2 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 60 行
- **函数**: `quote()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     57 | 
     58 |     event DelegateSet(address sender, address delegate);
     59 | 
>>   60 |     function quote(MessagingParams calldata _params, address _sender) external view returns (MessagingFee memory);
     61 | 
     62 |     function send(
     63 |         MessagingParams calldata _params,
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 69 行
- **函数**: `verifiable()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     66 | 
     67 |     function verify(Origin calldata _origin, address _receiver, bytes32 _payloadHash) external;
     68 | 
>>   69 |     function verifiable(Origin calldata _origin, address _receiver) external view returns (bool);
     70 | 
     71 |     function initializable(Origin calldata _origin, address _receiver) external view returns (bool);
     72 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 71 行
- **函数**: `initializable()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     68 | 
     69 |     function verifiable(Origin calldata _origin, address _receiver) external view returns (bool);
     70 | 
>>   71 |     function initializable(Origin calldata _origin, address _receiver) external view returns (bool);
     72 | 
     73 |     function lzReceive(
     74 |         Origin calldata _origin,
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 86 行
- **函数**: `lzToken()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     83 | 
     84 |     function setLzToken(address _lzToken) external;
     85 | 
>>   86 |     function lzToken() external view returns (address);
     87 | 
     88 |     function nativeToken() external view returns (address);
     89 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 88 行
- **函数**: `nativeToken()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     85 | 
     86 |     function lzToken() external view returns (address);
     87 | 
>>   88 |     function nativeToken() external view returns (address);
     89 | 
     90 |     function setDelegate(address _delegate) external;
     91 | }
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 103 行
- **函数**: `allowInitializePath()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    100 | import { Origin } from "./ILayerZeroEndpointV2.sol";
    101 | 
    102 | interface ILayerZeroReceiver {
>>  103 |     function allowInitializePath(Origin calldata _origin) external view returns (bool);
    104 | 
    105 |     function nextNonce(uint32 _eid, bytes32 _sender) external view returns (uint64);
    106 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 105 行
- **函数**: `nextNonce()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    102 | interface ILayerZeroReceiver {
    103 |     function allowInitializePath(Origin calldata _origin) external view returns (bool);
    104 | 
>>  105 |     function nextNonce(uint32 _eid, bytes32 _sender) external view returns (uint64);
    106 | 
    107 |     function lzReceive(
    108 |         Origin calldata _origin,
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 136 行
- **函数**: `getConfig()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    133 | interface IMessageLib is IERC165 {
    134 |     function setConfig(address _oapp, SetConfigParam[] calldata _config) external;
    135 | 
>>  136 |     function getConfig(uint32 _eid, address _oapp, uint32 _configType) external view returns (bytes memory config);
    137 | 
    138 |     function isSupportedEid(uint32 _eid) external view returns (bool);
    139 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 138 行
- **函数**: `isSupportedEid()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    135 | 
    136 |     function getConfig(uint32 _eid, address _oapp, uint32 _configType) external view returns (bytes memory config);
    137 | 
>>  138 |     function isSupportedEid(uint32 _eid) external view returns (bool);
    139 | 
    140 |     // message libs of same major version are compatible
    141 |     function version() external view returns (uint64 major, uint8 minor, uint8 endpointVersion);
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 141 行
- **函数**: `version()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    138 |     function isSupportedEid(uint32 _eid) external view returns (bool);
    139 | 
    140 |     // message libs of same major version are compatible
>>  141 |     function version() external view returns (uint64 major, uint8 minor, uint8 endpointVersion);
    142 | 
    143 |     function messageLibType() external view returns (MessageLibType);
    144 | }
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 143 行
- **函数**: `messageLibType()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    140 |     // message libs of same major version are compatible
    141 |     function version() external view returns (uint64 major, uint8 minor, uint8 endpointVersion);
    142 | 
>>  143 |     function messageLibType() external view returns (MessageLibType);
    144 | }
    145 | 
    146 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 175 行
- **函数**: `isRegisteredLibrary()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    172 | 
    173 |     function registerLibrary(address _lib) external;
    174 | 
>>  175 |     function isRegisteredLibrary(address _lib) external view returns (bool);
    176 | 
    177 |     function getRegisteredLibraries() external view returns (address[] memory);
    178 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 177 行
- **函数**: `getRegisteredLibraries()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    174 | 
    175 |     function isRegisteredLibrary(address _lib) external view returns (bool);
    176 | 
>>  177 |     function getRegisteredLibraries() external view returns (address[] memory);
    178 | 
    179 |     function setDefaultSendLibrary(uint32 _eid, address _newLib) external;
    180 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 181 行
- **函数**: `defaultSendLibrary()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    178 | 
    179 |     function setDefaultSendLibrary(uint32 _eid, address _newLib) external;
    180 | 
>>  181 |     function defaultSendLibrary(uint32 _eid) external view returns (address);
    182 | 
    183 |     function setDefaultReceiveLibrary(uint32 _eid, address _newLib, uint256 _gracePeriod) external;
    184 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 185 行
- **函数**: `defaultReceiveLibrary()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    182 | 
    183 |     function setDefaultReceiveLibrary(uint32 _eid, address _newLib, uint256 _gracePeriod) external;
    184 | 
>>  185 |     function defaultReceiveLibrary(uint32 _eid) external view returns (address);
    186 | 
    187 |     function setDefaultReceiveLibraryTimeout(uint32 _eid, address _lib, uint256 _expiry) external;
    188 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 189 行
- **函数**: `defaultReceiveLibraryTimeout()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    186 | 
    187 |     function setDefaultReceiveLibraryTimeout(uint32 _eid, address _lib, uint256 _expiry) external;
    188 | 
>>  189 |     function defaultReceiveLibraryTimeout(uint32 _eid) external view returns (address lib, uint256 expiry);
    190 | 
    191 |     function isSupportedEid(uint32 _eid) external view returns (bool);
    192 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 191 行
- **函数**: `isSupportedEid()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    188 | 
    189 |     function defaultReceiveLibraryTimeout(uint32 _eid) external view returns (address lib, uint256 expiry);
    190 | 
>>  191 |     function isSupportedEid(uint32 _eid) external view returns (bool);
    192 | 
    193 |     function isValidReceiveLibrary(address _receiver, uint32 _eid, address _lib) external view returns (bool);
    194 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 193 行
- **函数**: `isValidReceiveLibrary()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    190 | 
    191 |     function isSupportedEid(uint32 _eid) external view returns (bool);
    192 | 
>>  193 |     function isValidReceiveLibrary(address _receiver, uint32 _eid, address _lib) external view returns (bool);
    194 | 
    195 |     /// ------------------- OApp interfaces -------------------
    196 |     function setSendLibrary(address _oapp, uint32 _eid, address _newLib) external;
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 198 行
- **函数**: `getSendLibrary()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    195 |     /// ------------------- OApp interfaces -------------------
    196 |     function setSendLibrary(address _oapp, uint32 _eid, address _newLib) external;
    197 | 
>>  198 |     function getSendLibrary(address _sender, uint32 _eid) external view returns (address lib);
    199 | 
    200 |     function isDefaultSendLibrary(address _sender, uint32 _eid) external view returns (bool);
    201 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 200 行
- **函数**: `isDefaultSendLibrary()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    197 | 
    198 |     function getSendLibrary(address _sender, uint32 _eid) external view returns (address lib);
    199 | 
>>  200 |     function isDefaultSendLibrary(address _sender, uint32 _eid) external view returns (bool);
    201 | 
    202 |     function setReceiveLibrary(address _oapp, uint32 _eid, address _newLib, uint256 _gracePeriod) external;
    203 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 204 行
- **函数**: `getReceiveLibrary()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    201 | 
    202 |     function setReceiveLibrary(address _oapp, uint32 _eid, address _newLib, uint256 _gracePeriod) external;
    203 | 
>>  204 |     function getReceiveLibrary(address _receiver, uint32 _eid) external view returns (address lib, bool isDefault);
    205 | 
    206 |     function setReceiveLibraryTimeout(address _oapp, uint32 _eid, address _lib, uint256 _expiry) external;
    207 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 208 行
- **函数**: `receiveLibraryTimeout()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    205 | 
    206 |     function setReceiveLibraryTimeout(address _oapp, uint32 _eid, address _lib, uint256 _expiry) external;
    207 | 
>>  208 |     function receiveLibraryTimeout(address _receiver, uint32 _eid) external view returns (address lib, uint256 expiry);
    209 | 
    210 |     function setConfig(address _oapp, address _lib, SetConfigParam[] calldata _params) external;
    211 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 232 行
- **函数**: `eid()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    229 |     event PacketNilified(uint32 srcEid, bytes32 sender, address receiver, uint64 nonce, bytes32 payloadHash);
    230 |     event PacketBurnt(uint32 srcEid, bytes32 sender, address receiver, uint64 nonce, bytes32 payloadHash);
    231 | 
>>  232 |     function eid() external view returns (uint32);
    233 | 
    234 |     // this is an emergency function if a message cannot be verified for some reasons
    235 |     // required to provide _nextNonce to avoid race condition
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 242 行
- **函数**: `nextGuid()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    239 | 
    240 |     function burn(address _oapp, uint32 _srcEid, bytes32 _sender, uint64 _nonce, bytes32 _payloadHash) external;
    241 | 
>>  242 |     function nextGuid(address _sender, uint32 _dstEid, bytes32 _receiver) external view returns (bytes32);
    243 | 
    244 |     function inboundNonce(address _receiver, uint32 _srcEid, bytes32 _sender) external view returns (uint64);
    245 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 244 行
- **函数**: `inboundNonce()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    241 | 
    242 |     function nextGuid(address _sender, uint32 _dstEid, bytes32 _receiver) external view returns (bytes32);
    243 | 
>>  244 |     function inboundNonce(address _receiver, uint32 _srcEid, bytes32 _sender) external view returns (uint64);
    245 | 
    246 |     function outboundNonce(address _sender, uint32 _dstEid, bytes32 _receiver) external view returns (uint64);
    247 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 246 行
- **函数**: `outboundNonce()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    243 | 
    244 |     function inboundNonce(address _receiver, uint32 _srcEid, bytes32 _sender) external view returns (uint64);
    245 | 
>>  246 |     function outboundNonce(address _sender, uint32 _dstEid, bytes32 _receiver) external view returns (uint64);
    247 | 
    248 |     function inboundPayloadHash(
    249 |         address _receiver,
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 255 行
- **函数**: `lazyInboundNonce()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    252 |         uint64 _nonce
    253 |     ) external view returns (bytes32);
    254 | 
>>  255 |     function lazyInboundNonce(address _receiver, uint32 _srcEid, bytes32 _sender) external view returns (uint64);
    256 | }
    257 | 
    258 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 308 行
- **函数**: `isSendingMessage()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    305 | pragma solidity >=0.8.0;
    306 | 
    307 | interface IMessagingContext {
>>  308 |     function isSendingMessage() external view returns (bool);
    309 | 
    310 |     function getSendContext() external view returns (uint32 dstEid, address sender);
    311 | }
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 310 行
- **函数**: `getSendContext()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    307 | interface IMessagingContext {
    308 |     function isSendingMessage() external view returns (bool);
    309 | 
>>  310 |     function getSendContext() external view returns (uint32 dstEid, address sender);
    311 | }
    312 | 
    313 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 537 行
- **函数**: `oAppVersion()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    534 |      * @return senderVersion The version of the OAppSender.sol contract.
    535 |      * @return receiverVersion The version of the OAppReceiver.sol contract.
    536 |      */
>>  537 |     function oAppVersion() external view returns (uint64 senderVersion, uint64 receiverVersion);
    538 | 
    539 |     /**
    540 |      * @notice Retrieves the LayerZero endpoint associated with the OApp.
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 543 行
- **函数**: `endpoint()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    540 |      * @notice Retrieves the LayerZero endpoint associated with the OApp.
    541 |      * @return iEndpoint The LayerZero endpoint as an interface.
    542 |      */
>>  543 |     function endpoint() external view returns (ILayerZeroEndpointV2 iEndpoint);
    544 | 
    545 |     /**
    546 |      * @notice Retrieves the peer (OApp) associated with a corresponding endpoint.
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 550 行
- **函数**: `peers()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    547 |      * @param _eid The endpoint ID.
    548 |      * @return peer The peer address (OApp instance) associated with the corresponding endpoint.
    549 |      */
>>  550 |     function peers(uint32 _eid) external view returns (bytes32 peer);
    551 | 
    552 |     /**
    553 |      * @notice Sets the peer address (OApp instance) for a corresponding endpoint.
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 589 行
- **函数**: `inspect()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    586 |      *
    587 |      * @dev Optionally done as a revert, OR use the boolean provided to handle the failure.
    588 |      */
>>  589 |     function inspect(bytes calldata _message, bytes calldata _options) external view returns (bool valid);
    590 | }
    591 | 
    592 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 931 行
- **函数**: `oAppVersion()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    928 |      * ie. this is a RECEIVE only OApp.
    929 |      * @dev If the OApp uses both OAppSender and OAppReceiver, then this needs to be override returning the correct versions.
    930 |      */
>>  931 |     function oAppVersion() public view virtual returns (uint64 senderVersion, uint64 receiverVersion) {
    932 |         return (0, RECEIVER_VERSION);
    933 |     }
    934 | 
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 965 行
- **函数**: `allowInitializePath()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    962 |      * @dev This defaults to assuming if a peer has been set, its initialized.
    963 |      * Can be overridden by the OApp if there is other logic to determine this.
    964 |      */
>>  965 |     function allowInitializePath(Origin calldata origin) public view virtual returns (bool) {
    966 |         return peers[origin.srcEid] == origin.sender;
    967 |     }
    968 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 980 行
- **函数**: `nextNonce()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    977 |      * @dev This is also enforced by the OApp.
    978 |      * @dev By default this is NOT enabled. ie. nextNonce is hardcoded to return 0.
    979 |      */
>>  980 |     function nextNonce(uint32 /*_srcEid*/, bytes32 /*_sender*/) public view virtual returns (uint64 nonce) {
    981 |         return 0;
    982 |     }
    983 | 
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1061 行
- **函数**: `oAppVersion()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1058 |      * ie. this is a SEND only OApp.
   1059 |      * @dev If the OApp uses both OAppSender and OAppReceiver, then this needs to be override returning the correct versions
   1060 |      */
>> 1061 |     function oAppVersion() public view virtual returns (uint64 senderVersion, uint64 receiverVersion) {
   1062 |         return (SENDER_VERSION, 0);
   1063 |     }
   1064 | 
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1184 行
- **函数**: `preCrime()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1181 |      * @dev Retrieves the address of the preCrime contract implementation.
   1182 |      * @return The address of the preCrime contract.
   1183 |      */
>> 1184 |     function preCrime() external view returns (address);
   1185 | 
   1186 |     /**
   1187 |      * @dev Retrieves the address of the OApp contract.
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1190 行
- **函数**: `oApp()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1187 |      * @dev Retrieves the address of the OApp contract.
   1188 |      * @return The address of the OApp contract.
   1189 |      */
>> 1190 |     function oApp() external view returns (address);
   1191 | 
   1192 |     /**
   1193 |      * @dev Sets the preCrime contract address.
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1202 行
- **函数**: `lzReceiveAndRevert()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1199 |      * @dev Mocks receiving a packet, then reverts with a series of data to infer the state/result.
   1200 |      * @param _packets An array of LayerZero InboundPacket objects representing received packets.
   1201 |      */
>> 1202 |     function lzReceiveAndRevert(InboundPacket[] calldata _packets) external payable;
   1203 | 
   1204 |     /**
   1205 |      * @dev checks if the specified peer is considered 'trusted' by the OApp.
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1210 行
- **函数**: `isPeer()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1207 |      * @param _peer The peer to check.
   1208 |      * @return Whether the peer passed is considered 'trusted' by the OApp.
   1209 |      */
>> 1210 |     function isPeer(uint32 _eid, bytes32 _peer) external view returns (bool);
   1211 | }
   1212 | 
   1213 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1239 行
- **函数**: `getConfig()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1236 |     error InvalidSimulationResult(uint32 eid, bytes reason);
   1237 |     error CrimeFound(bytes crime);
   1238 | 
>> 1239 |     function getConfig(bytes[] calldata _packets, uint256[] calldata _packetMsgValues) external returns (bytes memory);
   1240 | 
   1241 |     function simulate(
   1242 |         bytes[] calldata _packets,
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1246 行
- **函数**: `buildSimulationResult()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1243 |         uint256[] calldata _packetMsgValues
   1244 |     ) external payable returns (bytes memory);
   1245 | 
>> 1246 |     function buildSimulationResult() external view returns (bytes memory);
   1247 | 
   1248 |     function preCrime(
   1249 |         bytes[] calldata _packets,
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1254 行
- **函数**: `version()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1251 |         bytes[] calldata _simulations
   1252 |     ) external;
   1253 | 
>> 1254 |     function version() external view returns (uint64 major, uint8 minor);
   1255 | }
   1256 | 
   1257 | 
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1348 行
- **函数**: `oApp()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1345 |      * @dev The simulator contract is the base contract for the OApp by default.
   1346 |      * @dev If the simulator is a separate contract, override this function.
   1347 |      */
>> 1348 |     function oApp() external view virtual returns (address) {
   1349 |         return address(this);
   1350 |     }
   1351 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1369 行
- **函数**: `lzReceiveAndRevert()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1366 |      * @dev Gives the preCrime implementation the ability to mock sending packets to the lzReceive function,
   1367 |      * WITHOUT actually executing them.
   1368 |      */
>> 1369 |     function lzReceiveAndRevert(InboundPacket[] calldata _packets) public payable virtual {
   1370 |         for (uint256 i = 0; i < _packets.length; i++) {
   1371 |             InboundPacket calldata packet = _packets[i];
   1372 | 
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1448 行
- **函数**: `isPeer()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1445 |      * @param _peer The peer to check.
   1446 |      * @return Whether the peer passed is considered 'trusted' by the OApp.
   1447 |      */
>> 1448 |     function isPeer(uint32 _eid, bytes32 _peer) public view virtual returns (bool);
   1449 | }
   1450 | 
   1451 | 
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1537 行
- **函数**: `oftVersion()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1534 |      * @dev If a new feature is added to the OFT cross-chain msg encoding, the version will be incremented.
   1535 |      * ie. localOFT version(x,1) CAN send messages to remoteOFT version(x,1)
   1536 |      */
>> 1537 |     function oftVersion() external view returns (bytes4 interfaceId, uint64 version);
   1538 | 
   1539 |     /**
   1540 |      * @notice Retrieves the address of the token associated with the OFT.
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1543 行
- **函数**: `token()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1540 |      * @notice Retrieves the address of the token associated with the OFT.
   1541 |      * @return token The address of the ERC20 token implementation.
   1542 |      */
>> 1543 |     function token() external view returns (address);
   1544 | 
   1545 |     /**
   1546 |      * @notice Indicates whether the OFT contract requires approval of the 'token()' to send.
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1552 行
- **函数**: `approvalRequired()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1549 |      * @dev Allows things like wallet implementers to determine integration requirements,
   1550 |      * without understanding the underlying token implementation.
   1551 |      */
>> 1552 |     function approvalRequired() external view returns (bool);
   1553 | 
   1554 |     /**
   1555 |      * @notice Retrieves the shared decimals of the OFT.
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1558 行
- **函数**: `sharedDecimals()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1555 |      * @notice Retrieves the shared decimals of the OFT.
   1556 |      * @return sharedDecimals The shared decimals of the OFT.
   1557 |      */
>> 1558 |     function sharedDecimals() external view returns (uint8);
   1559 | 
   1560 |     /**
   1561 |      * @notice Provides the fee breakdown and settings data for an OFT. Unused in the default implementation.
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1581 行
- **函数**: `quoteSend()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1578 |      *  - nativeFee: The native fee.
   1579 |      *  - lzTokenFee: The lzToken fee.
   1580 |      */
>> 1581 |     function quoteSend(SendParam calldata _sendParam, bool _payInLzToken) external view returns (MessagingFee memory);
   1582 | 
   1583 |     /**
   1584 |      * @notice Executes the send() operation.
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1822 行
- **函数**: `token()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1819 |      *
   1820 |      * @dev In the case of OFT, address(this) and erc20 are the same contract.
   1821 |      */
>> 1822 |     function token() public view returns (address) {
   1823 |         return address(this);
   1824 |     }
   1825 | 
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1832 行
- **函数**: `approvalRequired()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1829 |      *
   1830 |      * @dev In the case of OFT where the contract IS the token, approval is NOT required.
   1831 |      */
>> 1832 |     function approvalRequired() external pure virtual returns (bool) {
   1833 |         return false;
   1834 |     }
   1835 | 
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1953 行
- **函数**: `oftVersion()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1950 |      * @dev If a new feature is added to the OFT cross-chain msg encoding, the version will be incremented.
   1951 |      * ie. localOFT version(x,1) CAN send messages to remoteOFT version(x,1)
   1952 |      */
>> 1953 |     function oftVersion() external pure virtual returns (bytes4 interfaceId, uint64 version) {
   1954 |         return (type(IOFT).interfaceId, 1);
   1955 |     }
   1956 | 
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1967 行
- **函数**: `sharedDecimals()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1964 |      * For tokens exceeding this totalSupply(), they will need to override the sharedDecimals function with something smaller.
   1965 |      * ie. 4 sharedDecimals would be 1,844,674,407,370,955.1615
   1966 |      */
>> 1967 |     function sharedDecimals() public view virtual returns (uint8) {
   1968 |         return 6;
   1969 |     }
   1970 | 
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2213 行
- **函数**: `isPeer()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2210 |      *
   2211 |      * @dev Enables OAppPreCrimeSimulator to check whether a potential Inbound Packet is from a trusted source.
   2212 |      */
>> 2213 |     function isPeer(uint32 _eid, bytes32 _peer) public view virtual override returns (bool) {
   2214 |         return peers[_eid] == _peer;
   2215 |     }
   2216 | 
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2372 行
- **函数**: `owner()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2369 |     /**
   2370 |      * @dev Returns the address of the current owner.
   2371 |      */
>> 2372 |     function owner() public view virtual returns (address) {
   2373 |         return _owner;
   2374 |     }
   2375 | 
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2620 行
- **函数**: `transferAndCall()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2617 |      * @param value The amount of tokens to be transferred.
   2618 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2619 |      */
>> 2620 |     function transferAndCall(address to, uint256 value) external returns (bool);
   2621 | 
   2622 |     /**
   2623 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2630 行
- **函数**: `transferAndCall()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2627 |      * @param data Additional data with no specified format, sent in call to `to`.
   2628 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2629 |      */
>> 2630 |     function transferAndCall(address to, uint256 value, bytes calldata data) external returns (bool);
   2631 | 
   2632 |     /**
   2633 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2640 行
- **函数**: `transferFromAndCall()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2637 |      * @param value The amount of tokens to be transferred.
   2638 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2639 |      */
>> 2640 |     function transferFromAndCall(address from, address to, uint256 value) external returns (bool);
   2641 | 
   2642 |     /**
   2643 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2651 行
- **函数**: `transferFromAndCall()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2648 |      * @param data Additional data with no specified format, sent in call to `to`.
   2649 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2650 |      */
>> 2651 |     function transferFromAndCall(address from, address to, uint256 value, bytes calldata data) external returns (bool);
   2652 | 
   2653 |     /**
   2654 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2660 行
- **函数**: `approveAndCall()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2657 |      * @param value The amount of tokens to be spent.
   2658 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2659 |      */
>> 2660 |     function approveAndCall(address spender, uint256 value) external returns (bool);
   2661 | 
   2662 |     /**
   2663 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2670 行
- **函数**: `approveAndCall()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2667 |      * @param data Additional data with no specified format, sent in call to `spender`.
   2668 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2669 |      */
>> 2670 |     function approveAndCall(address spender, uint256 value, bytes calldata data) external returns (bool);
   2671 | }
   2672 | 
   2673 | 
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2747 行
- **函数**: `name()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2744 |     /**
   2745 |      * @dev Returns the name of the token.
   2746 |      */
>> 2747 |     function name() public view virtual returns (string memory) {
   2748 |         return _name;
   2749 |     }
   2750 | 
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2755 行
- **函数**: `symbol()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2752 |      * @dev Returns the symbol of the token, usually a shorter version of the
   2753 |      * name.
   2754 |      */
>> 2755 |     function symbol() public view virtual returns (string memory) {
   2756 |         return _symbol;
   2757 |     }
   2758 | 
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2772 行
- **函数**: `decimals()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2769 |      * no way affects any of the arithmetic of the contract, including
   2770 |      * {IERC20-balanceOf} and {IERC20-transfer}.
   2771 |      */
>> 2772 |     function decimals() public view virtual returns (uint8) {
   2773 |         return 18;
   2774 |     }
   2775 | 
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2777 行
- **函数**: `totalSupply()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2774 |     }
   2775 | 
   2776 |     /// @inheritdoc IERC20
>> 2777 |     function totalSupply() public view virtual returns (uint256) {
   2778 |         return _totalSupply;
   2779 |     }
   2780 | 
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2782 行
- **函数**: `balanceOf()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2779 |     }
   2780 | 
   2781 |     /// @inheritdoc IERC20
>> 2782 |     function balanceOf(address account) public view virtual returns (uint256) {
   2783 |         return _balances[account];
   2784 |     }
   2785 | 
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2794 行
- **函数**: `transfer()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2791 |      * - `to` cannot be the zero address.
   2792 |      * - the caller must have a balance of at least `value`.
   2793 |      */
>> 2794 |     function transfer(address to, uint256 value) public virtual returns (bool) {
   2795 |         address owner = _msgSender();
   2796 |         _transfer(owner, to, value);
   2797 |         return true;
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2801 行
- **函数**: `allowance()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2798 |     }
   2799 | 
   2800 |     /// @inheritdoc IERC20
>> 2801 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
   2802 |         return _allowances[owner][spender];
   2803 |     }
   2804 | 
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2815 行
- **函数**: `approve()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2812 |      *
   2813 |      * - `spender` cannot be the zero address.
   2814 |      */
>> 2815 |     function approve(address spender, uint256 value) public virtual returns (bool) {
   2816 |         address owner = _msgSender();
   2817 |         _approve(owner, spender, value);
   2818 |         return true;
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2837 行
- **函数**: `transferFrom()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2834 |      * - the caller must have allowance for ``from``'s tokens of at least
   2835 |      * `value`.
   2836 |      */
>> 2837 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
   2838 |         address spender = _msgSender();
   2839 |         _spendAllowance(from, spender, value);
   2840 |         _transfer(from, to, value);
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3019 行
- **函数**: `name()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3016 |     /**
   3017 |      * @dev Returns the name of the token.
   3018 |      */
>> 3019 |     function name() external view returns (string memory);
   3020 | 
   3021 |     /**
   3022 |      * @dev Returns the symbol of the token.
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3024 行
- **函数**: `symbol()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3021 |     /**
   3022 |      * @dev Returns the symbol of the token.
   3023 |      */
>> 3024 |     function symbol() external view returns (string memory);
   3025 | 
   3026 |     /**
   3027 |      * @dev Returns the decimals places of the token.
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3029 行
- **函数**: `decimals()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3026 |     /**
   3027 |      * @dev Returns the decimals places of the token.
   3028 |      */
>> 3029 |     function decimals() external view returns (uint8);
   3030 | }
   3031 | 
   3032 | 
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3061 行
- **函数**: `totalSupply()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3058 |     /**
   3059 |      * @dev Returns the value of tokens in existence.
   3060 |      */
>> 3061 |     function totalSupply() external view returns (uint256);
   3062 | 
   3063 |     /**
   3064 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 78. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3066 行
- **函数**: `balanceOf()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3063 |     /**
   3064 |      * @dev Returns the value of tokens owned by `account`.
   3065 |      */
>> 3066 |     function balanceOf(address account) external view returns (uint256);
   3067 | 
   3068 |     /**
   3069 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 79. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3075 行
- **函数**: `transfer()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3072 |      *
   3073 |      * Emits a {Transfer} event.
   3074 |      */
>> 3075 |     function transfer(address to, uint256 value) external returns (bool);
   3076 | 
   3077 |     /**
   3078 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 80. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3084 行
- **函数**: `allowance()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3081 |      *
   3082 |      * This value changes when {approve} or {transferFrom} are called.
   3083 |      */
>> 3084 |     function allowance(address owner, address spender) external view returns (uint256);
   3085 | 
   3086 |     /**
   3087 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 81. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3101 行
- **函数**: `approve()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3098 |      *
   3099 |      * Emits an {Approval} event.
   3100 |      */
>> 3101 |     function approve(address spender, uint256 value) external returns (bool);
   3102 | 
   3103 |     /**
   3104 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 82. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3112 行
- **函数**: `transferFrom()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3109 |      *
   3110 |      * Emits a {Transfer} event.
   3111 |      */
>> 3112 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   3113 | }
   3114 | 
   3115 | 
```

---

### 83. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3389 行
- **函数**: `supportsInterface()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3386 |      *
   3387 |      * This function call must use less than 30 000 gas.
   3388 |      */
>> 3389 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   3390 | }
   3391 | 
   3392 | 
```

---

### 84. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 680 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    675 | import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";
    676 | import { IOAppOptionsType3, EnforcedOptionParam } from "../interfaces/IOAppOptionsType3.sol";
    677 | 
    678 | /**
    679 |  * @title OAppOptionsType3
>>  680 |  * @dev Abstract contract implementing the IOAppOptionsType3 interface with type 3 options.
    681 |  */
    682 | abstract contract OAppOptionsType3 is IOAppOptionsType3, Ownable {
    683 |     uint16 internal constant OPTION_TYPE_3 = 3;
    684 | 
    685 |     // @dev The "msgType" should be defined in the child contract.
```

---

### 85. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 787 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    782 | import { OAppReceiver, Origin } from "./OAppReceiver.sol";
    783 | import { OAppCore } from "./OAppCore.sol";
    784 | 
    785 | /**
    786 |  * @title OApp
>>  787 |  * @dev Abstract contract serving as the base for OApp implementation, combining OAppSender and OAppReceiver functionality.
    788 |  */
    789 | abstract contract OApp is OAppSender, OAppReceiver {
    790 |     /**
    791 |      * @dev Constructor to initialize the OApp with the provided endpoint and owner.
    792 |      * @param _endpoint The address of the LOCAL LayerZero endpoint.
```

---

### 86. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 825 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    820 | import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";
    821 | import { IOAppCore, ILayerZeroEndpointV2 } from "./interfaces/IOAppCore.sol";
    822 | 
    823 | /**
    824 |  * @title OAppCore
>>  825 |  * @dev Abstract contract implementing the IOAppCore interface with basic OApp configurations.
    826 |  */
    827 | abstract contract OAppCore is IOAppCore, Ownable {
    828 |     // The LayerZero endpoint associated with the given OApp
    829 |     ILayerZeroEndpointV2 public immutable endpoint;
    830 | 
```

---

### 87. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 912 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    907 | import { IOAppReceiver, Origin } from "./interfaces/IOAppReceiver.sol";
    908 | import { OAppCore } from "./OAppCore.sol";
    909 | 
    910 | /**
    911 |  * @title OAppReceiver
>>  912 |  * @dev Abstract contract implementing the ILayerZeroReceiver interface and extending OAppCore for OApp receivers.
    913 |  */
    914 | abstract contract OAppReceiver is IOAppReceiver, OAppCore {
    915 |     // Custom error message for when the caller is not the registered endpoint/
    916 |     error OnlyEndpoint(address addr);
    917 | 
```

---

### 88. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1335 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1330 | import { IPreCrime } from "./interfaces/IPreCrime.sol";
   1331 | import { IOAppPreCrimeSimulator, InboundPacket, Origin } from "./interfaces/IOAppPreCrimeSimulator.sol";
   1332 | 
   1333 | /**
   1334 |  * @title OAppPreCrimeSimulator
>> 1335 |  * @dev Abstract contract serving as the base for preCrime simulation functionality in an OApp.
   1336 |  */
   1337 | abstract contract OAppPreCrimeSimulator is IOAppPreCrimeSimulator, Ownable {
   1338 |     // The address of the preCrime implementation.
   1339 |     address public preCrime;
   1340 | 
```

---

### 89. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1546 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1541 |      * @return token The address of the ERC20 token implementation.
   1542 |      */
   1543 |     function token() external view returns (address);
   1544 | 
   1545 |     /**
>> 1546 |      * @notice Indicates whether the OFT contract requires approval of the 'token()' to send.
   1547 |      * @return requiresApproval Needs approval of the underlying token implementation.
   1548 |      *
   1549 |      * @dev Allows things like wallet implementers to determine integration requirements,
   1550 |      * without understanding the underlying token implementation.
   1551 |      */
```

---

### 90. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1801 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1796 | 
   1797 | /**
   1798 |  * @title OFT Contract
   1799 |  * @dev OFT is an ERC-20 token that extends the functionality of the OFTCore contract.
   1800 |  */
>> 1801 | abstract contract OFT is OFTCore, ERC20 {
   1802 |     /**
   1803 |      * @dev Constructor for the OFT contract.
   1804 |      * @param _name The name of the OFT.
   1805 |      * @param _symbol The symbol of the OFT.
   1806 |      * @param _lzEndpoint The LayerZero endpoint address.
```

---

### 91. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 1901 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1896 | import { OFTMsgCodec } from "./libs/OFTMsgCodec.sol";
   1897 | import { OFTComposeMsgCodec } from "./libs/OFTComposeMsgCodec.sol";
   1898 | 
   1899 | /**
   1900 |  * @title OFTCore
>> 1901 |  * @dev Abstract contract for the OftChain (OFT) token.
   1902 |  */
   1903 | abstract contract OFTCore is IOFT, OApp, OAppPreCrimeSimulator, OAppOptionsType3 {
   1904 |     using OFTMsgCodec for bytes;
   1905 |     using OFTMsgCodec for bytes32;
   1906 | 
```

---

### 92. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2336 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2331 |  *
   2332 |  * This module is used through inheritance. It will make available the modifier
   2333 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
   2334 |  * the owner.
   2335 |  */
>> 2336 | abstract contract Ownable is Context {
   2337 |     address private _owner;
   2338 | 
   2339 |     /**
   2340 |      * @dev The caller account is not authorized to perform an operation.
   2341 |      */
```

---

### 93. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2408 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2403 |         }
   2404 |         _transferOwnership(newOwner);
   2405 |     }
   2406 | 
   2407 |     /**
>> 2408 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
   2409 |      * Internal function without access restriction.
   2410 |      */
   2411 |     function _transferOwnership(address newOwner) internal virtual {
   2412 |         address oldOwner = _owner;
   2413 |         _owner = newOwner;
```

---

### 94. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 2724 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2719 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
   2720 |  * instead returning `false` on failure. This behavior is nonetheless
   2721 |  * conventional and does not conflict with the expectations of ERC-20
   2722 |  * applications.
   2723 |  */
>> 2724 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
   2725 |     mapping(address account => uint256) private _balances;
   2726 | 
   2727 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
   2728 | 
   2729 |     uint256 private _totalSupply;
```

---

### 95. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3129 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3124 | import {IERC1363} from "../../../interfaces/IERC1363.sol";
   3125 | 
   3126 | /**
   3127 |  * @title SafeERC20
   3128 |  * @dev Wrappers around ERC-20 operations that throw on failure (when the token
>> 3129 |  * contract returns false). Tokens that return no value (and instead revert or
   3130 |  * throw on failure) are also supported, non-reverting calls are assumed to be
   3131 |  * successful.
   3132 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
   3133 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
   3134 |  */
```

---

### 96. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 3401 行
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3396 | pragma solidity 0.8.28;
   3397 | 
   3398 | import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";
   3399 | import { OFT } from "@layerzerolabs/oft-evm/contracts/OFT.sol";
   3400 | 
>> 3401 | contract SupMain is OFT {
   3402 |     uint256 public immutable ALL_SUPPLY = 1_000_000_000 * 10 ** 18;
   3403 | 
   3404 |     constructor(
   3405 |         string memory _name,
   3406 |         string memory _symbol,
```

---

### 97. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 382 行
- **函数**: `toBytes()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    379 |         result = new bytes(_size);
    380 |         unchecked {
    381 |             uint256 offset = 256 - _size * 8;
>>  382 |             assembly {
    383 |                 mstore(add(result, 32), shl(offset, _addressBytes32))
    384 |             }
    385 |         }
```

---

### 98. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x19Ed254efa5E061D28d84650891a3db2A9940C16` 第 763 行
- **函数**: `_assertOptionsType3()`
- **合约**: `implementing`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    760 |      */
    761 |     function _assertOptionsType3(bytes memory _options) internal pure virtual {
    762 |         uint16 optionsType;
>>  763 |         assembly {
    764 |             optionsType := mload(add(_options, 2))
    765 |         }
    766 |         if (optionsType != OPTION_TYPE_3) revert InvalidOptions(_options);
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*