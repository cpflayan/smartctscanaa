# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:56:25
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` |
| contract_name | `SwapRouter02` |
| compiler_version | `v0.7.6+commit.7338295f` |
| optimization_used | `True` |
| runs | `1000000` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `True` |
| implementation | `0xb971ef87ede563556b2ed4b1c0b0019111dd85d2` |
| multi_file | `True` |
| source_files | `['contracts/SwapRouter02.sol', '@uniswap/v3-periphery/contracts/base/SelfPermit.sol', '@uniswap/v3-periphery/contracts/base/PeripheryImmutableState.sol', 'contracts/interfaces/ISwapRouter02.sol', 'contracts/V2SwapRouter.sol', 'contracts/V3SwapRouter.sol', 'contracts/base/ApproveAndCall.sol', 'contracts/base/MulticallExtended.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/drafts/IERC20Permit.sol', '@uniswap/v3-periphery/contracts/interfaces/ISelfPermit.sol', '@uniswap/v3-periphery/contracts/interfaces/external/IERC20PermitAllowed.sol', '@uniswap/v3-periphery/contracts/interfaces/IPeripheryImmutableState.sol', 'contracts/interfaces/IV2SwapRouter.sol', 'contracts/interfaces/IV3SwapRouter.sol', 'contracts/interfaces/IApproveAndCall.sol', 'contracts/interfaces/IMulticallExtended.sol', '@uniswap/v3-core/contracts/interfaces/callback/IUniswapV3SwapCallback.sol', '@uniswap/v3-periphery/contracts/interfaces/IMulticall.sol', '@uniswap/v3-core/contracts/libraries/LowGasSafeMath.sol', 'contracts/base/ImmutableState.sol', 'contracts/base/PeripheryPaymentsWithFeeExtended.sol', 'contracts/libraries/Constants.sol', 'contracts/libraries/UniswapV2Library.sol', 'contracts/interfaces/IImmutableState.sol', '@uniswap/v3-periphery/contracts/base/PeripheryPaymentsWithFee.sol', 'contracts/interfaces/IPeripheryPaymentsWithFeeExtended.sol', 'contracts/base/PeripheryPaymentsExtended.sol', '@uniswap/v3-periphery/contracts/base/PeripheryPayments.sol', '@uniswap/v3-periphery/contracts/interfaces/IPeripheryPaymentsWithFee.sol', '@uniswap/v3-periphery/contracts/interfaces/external/IWETH9.sol', '@uniswap/v3-periphery/contracts/libraries/TransferHelper.sol', '@uniswap/v3-periphery/contracts/interfaces/IPeripheryPayments.sol', 'contracts/interfaces/IPeripheryPaymentsExtended.sol', '@uniswap/v2-core/contracts/interfaces/IUniswapV2Pair.sol', '@uniswap/v3-core/contracts/libraries/SafeCast.sol', '@uniswap/v3-core/contracts/libraries/TickMath.sol', '@uniswap/v3-core/contracts/interfaces/IUniswapV3Pool.sol', '@uniswap/v3-periphery/contracts/libraries/Path.sol', '@uniswap/v3-periphery/contracts/libraries/PoolAddress.sol', '@uniswap/v3-periphery/contracts/libraries/CallbackValidation.sol', 'contracts/base/OracleSlippage.sol', '@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolImmutables.sol', '@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolState.sol', '@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolDerivedState.sol', '@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolActions.sol', '@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolOwnerActions.sol', '@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolEvents.sol', '@uniswap/v3-periphery/contracts/libraries/BytesLib.sol', 'contracts/interfaces/IOracleSlippage.sol', '@uniswap/v3-periphery/contracts/base/BlockTimestamp.sol', '@uniswap/v3-periphery/contracts/libraries/OracleLibrary.sol', '@uniswap/v3-core/contracts/libraries/FullMath.sol', '@uniswap/v3-periphery/contracts/interfaces/INonfungiblePositionManager.sol', '@openzeppelin/contracts/token/ERC721/IERC721Metadata.sol', '@openzeppelin/contracts/token/ERC721/IERC721Enumerable.sol', '@uniswap/v3-periphery/contracts/interfaces/IPoolInitializer.sol', '@uniswap/v3-periphery/contracts/interfaces/IERC721Permit.sol', '@openzeppelin/contracts/token/ERC721/IERC721.sol', '@openzeppelin/contracts/introspection/IERC165.sol', '@uniswap/v3-periphery/contracts/base/Multicall.sol', 'contracts/base/PeripheryValidationExtended.sol', '@uniswap/v3-periphery/contracts/base/PeripheryValidation.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646141` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 128 |
| 🟢 LOW | 46 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3859 行
- **函数**: `multicall()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   3856 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
   3857 |         results = new bytes[](data.length);
   3858 |         for (uint256 i = 0; i < data.length; i++) {
>> 3859 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
   3860 | 
   3861 |             if (!success) {
   3862 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 166 行
- **函数**: `_swap()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    163 |             uint256 amountOutput;
    164 |             // scope to avoid stack too deep errors
    165 |             {
>>  166 |                 (uint256 reserve0, uint256 reserve1, ) = pair.getReserves();
    167 |                 (uint256 reserveInput, uint256 reserveOutput) =
    168 |                     input == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
    169 |                 amountInput = IERC20(input).balanceOf(address(pair)).sub(reserveInput);
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1331 行
- **函数**: `getReserves()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1328 |         address tokenB
   1329 |     ) internal view returns (uint256 reserveA, uint256 reserveB) {
   1330 |         (address token0, ) = sortTokens(tokenA, tokenB);
>> 1331 |         (uint256 reserve0, uint256 reserve1, ) = IUniswapV2Pair(pairFor(factory, tokenA, tokenB)).getReserves();
   1332 |         (reserveA, reserveB) = tokenA == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
   1333 |     }
   1334 | 
```

---

### 4. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1814 行
- **函数**: `getReserves()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1811 |     function factory() external view returns (address);
   1812 |     function token0() external view returns (address);
   1813 |     function token1() external view returns (address);
>> 1814 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1815 |     function price0CumulativeLast() external view returns (uint);
   1816 |     function price1CumulativeLast() external view returns (uint);
   1817 |     function kLast() external view returns (uint);
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 493 行
- **函数**: `tryApprove()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    490 | abstract contract ApproveAndCall is IApproveAndCall, ImmutableState {
    491 |     function tryApprove(address token, uint256 amount) private returns (bool) {
    492 |         (bool success, bytes memory data) =
>>  493 |             token.call(abi.encodeWithSelector(IERC20.approve.selector, positionManager, amount));
    494 |         return success && (data.length == 0 || abi.decode(data, (bool)));
    495 |     }
    496 | 
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 541 行
- **函数**: `callPositionManager()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    538 |     /// @inheritdoc IApproveAndCall
    539 |     function callPositionManager(bytes memory data) public payable override returns (bytes memory result) {
    540 |         bool success;
>>  541 |         (success, result) = positionManager.call(data);
    542 | 
    543 |         if (!success) {
    544 |             // Next 5 lines from https://ethereum.stackexchange.com/a/83577
```

---

### 7. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1665 行
- **函数**: `safeTransferFrom()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1662 |         uint256 value
   1663 |     ) internal {
   1664 |         (bool success, bytes memory data) =
>> 1665 |             token.call(abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, value));
   1666 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'STF');
   1667 |     }
   1668 | 
```

---

### 8. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1679 行
- **函数**: `safeTransfer()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1676 |         address to,
   1677 |         uint256 value
   1678 |     ) internal {
>> 1679 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transfer.selector, to, value));
   1680 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'ST');
   1681 |     }
   1682 | 
```

---

### 9. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1693 行
- **函数**: `safeApprove()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1690 |         address to,
   1691 |         uint256 value
   1692 |     ) internal {
>> 1693 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.approve.selector, to, value));
   1694 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'SA');
   1695 |     }
   1696 | 
```

---

### 10. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1702 行
- **函数**: `safeTransferETH()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1699 |     /// @param to The destination of the transfer
   1700 |     /// @param value The value to be transferred
   1701 |     function safeTransferETH(address to, uint256 value) internal {
>> 1702 |         (bool success, ) = to.call{value: value}(new bytes(0));
   1703 |         require(success, 'STE');
   1704 |     }
   1705 | }
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 366 行
- **函数**: `exactInput()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    363 |     }
    364 | 
    365 |     /// @inheritdoc IV3SwapRouter
>>  366 |     function exactInput(ExactInputParams memory params) external payable override returns (uint256 amountOut) {
    367 |         // use amountIn == Constants.CONTRACT_BALANCE as a flag to swap the entire balance of the contract
    368 |         bool hasAlreadyPaid;
    369 |         if (params.amountIn == Constants.CONTRACT_BALANCE) {
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 460 行
- **函数**: `exactOutput()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    457 |     }
    458 | 
    459 |     /// @inheritdoc IV3SwapRouter
>>  460 |     function exactOutput(ExactOutputParams calldata params) external payable override returns (uint256 amountIn) {
    461 |         exactOutputInternal(
    462 |             params.amountOut,
    463 |             params.recipient,
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 498 行
- **函数**: `getApprovalType()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    495 |     }
    496 | 
    497 |     /// @inheritdoc IApproveAndCall
>>  498 |     function getApprovalType(address token, uint256 amount) external override returns (ApprovalType) {
    499 |         // check existing approval
    500 |         if (IERC20(token).allowance(address(this), positionManager) >= amount) return ApprovalType.NOT_REQUIRED;
    501 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 517 行
- **函数**: `approveMax()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    514 |     }
    515 | 
    516 |     /// @inheritdoc IApproveAndCall
>>  517 |     function approveMax(address token) external payable override {
    518 |         require(tryApprove(token, type(uint256).max));
    519 |     }
    520 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 522 行
- **函数**: `approveMaxMinusOne()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    519 |     }
    520 | 
    521 |     /// @inheritdoc IApproveAndCall
>>  522 |     function approveMaxMinusOne(address token) external payable override {
    523 |         require(tryApprove(token, type(uint256).max - 1));
    524 |     }
    525 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 527 行
- **函数**: `approveZeroThenMax()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    524 |     }
    525 | 
    526 |     /// @inheritdoc IApproveAndCall
>>  527 |     function approveZeroThenMax(address token) external payable override {
    528 |         require(tryApprove(token, 0));
    529 |         require(tryApprove(token, type(uint256).max));
    530 |     }
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 533 行
- **函数**: `approveZeroThenMaxMinusOne()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    530 |     }
    531 | 
    532 |     /// @inheritdoc IApproveAndCall
>>  533 |     function approveZeroThenMaxMinusOne(address token) external payable override {
    534 |         require(tryApprove(token, 0));
    535 |         require(tryApprove(token, type(uint256).max - 1));
    536 |     }
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 539 行
- **函数**: `callPositionManager()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    536 |     }
    537 | 
    538 |     /// @inheritdoc IApproveAndCall
>>  539 |     function callPositionManager(bytes memory data) public payable override returns (bytes memory result) {
    540 |         bool success;
    541 |         (success, result) = positionManager.call(data);
    542 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 558 行
- **函数**: `mint()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    555 |     }
    556 | 
    557 |     /// @inheritdoc IApproveAndCall
>>  558 |     function mint(MintParams calldata params) external payable override returns (bytes memory result) {
    559 |         return
    560 |             callPositionManager(
    561 |                 abi.encodeWithSelector(
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 656 行
- **函数**: `totalSupply()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    653 |     /**
    654 |      * @dev Returns the amount of tokens in existence.
    655 |      */
>>  656 |     function totalSupply() external view returns (uint256);
    657 | 
    658 |     /**
    659 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 661 行
- **函数**: `balanceOf()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    658 |     /**
    659 |      * @dev Returns the amount of tokens owned by `account`.
    660 |      */
>>  661 |     function balanceOf(address account) external view returns (uint256);
    662 | 
    663 |     /**
    664 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 670 行
- **函数**: `transfer()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    667 |      *
    668 |      * Emits a {Transfer} event.
    669 |      */
>>  670 |     function transfer(address recipient, uint256 amount) external returns (bool);
    671 | 
    672 |     /**
    673 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 679 行
- **函数**: `allowance()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    676 |      *
    677 |      * This value changes when {approve} or {transferFrom} are called.
    678 |      */
>>  679 |     function allowance(address owner, address spender) external view returns (uint256);
    680 | 
    681 |     /**
    682 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 695 行
- **函数**: `approve()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    692 |      *
    693 |      * Emits an {Approval} event.
    694 |      */
>>  695 |     function approve(address spender, uint256 amount) external returns (bool);
    696 | 
    697 |     /**
    698 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 706 行
- **函数**: `transferFrom()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    703 |      *
    704 |      * Emits a {Transfer} event.
    705 |      */
>>  706 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    707 | 
    708 |     /**
    709 |      * @dev Emitted when `value` tokens are moved from one account (`from`) to
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 769 行
- **函数**: `nonces()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    766 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
    767 |      * prevents a signature from being used multiple times.
    768 |      */
>>  769 |     function nonces(address owner) external view returns (uint256);
    770 | 
    771 |     /**
    772 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 775 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    772 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
    773 |      */
    774 |     // solhint-disable-next-line func-name-mixedcase
>>  775 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    776 | }
    777 | 
    778 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 899 行
- **函数**: `factory()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    896 | /// @notice Functions that return immutable state of the router
    897 | interface IPeripheryImmutableState {
    898 |     /// @return Returns the address of the Uniswap V3 factory
>>  899 |     function factory() external view returns (address);
    900 | 
    901 |     /// @return Returns the address of WETH9
    902 |     function WETH9() external view returns (address);
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 902 行
- **函数**: `WETH9()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    899 |     function factory() external view returns (address);
    900 | 
    901 |     /// @return Returns the address of WETH9
>>  902 |     function WETH9() external view returns (address);
    903 | }
    904 | 
    905 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 971 行
- **函数**: `exactInputSingle()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    968 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
    969 |     /// @param params The parameters necessary for the swap, encoded as `ExactInputSingleParams` in calldata
    970 |     /// @return amountOut The amount of the received token
>>  971 |     function exactInputSingle(ExactInputSingleParams calldata params) external payable returns (uint256 amountOut);
    972 | 
    973 |     struct ExactInputParams {
    974 |         bytes path;
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 985 行
- **函数**: `exactInput()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    982 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
    983 |     /// @param params The parameters necessary for the multi-hop swap, encoded as `ExactInputParams` in calldata
    984 |     /// @return amountOut The amount of the received token
>>  985 |     function exactInput(ExactInputParams calldata params) external payable returns (uint256 amountOut);
    986 | 
    987 |     struct ExactOutputSingleParams {
    988 |         address tokenIn;
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1001 行
- **函数**: `exactOutputSingle()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    998 |     /// that may remain in the router after the swap.
    999 |     /// @param params The parameters necessary for the swap, encoded as `ExactOutputSingleParams` in calldata
   1000 |     /// @return amountIn The amount of the input token
>> 1001 |     function exactOutputSingle(ExactOutputSingleParams calldata params) external payable returns (uint256 amountIn);
   1002 | 
   1003 |     struct ExactOutputParams {
   1004 |         bytes path;
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1014 行
- **函数**: `exactOutput()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1011 |     /// that may remain in the router after the swap.
   1012 |     /// @param params The parameters necessary for the multi-hop swap, encoded as `ExactOutputParams` in calldata
   1013 |     /// @return amountIn The amount of the input token
>> 1014 |     function exactOutput(ExactOutputParams calldata params) external payable returns (uint256 amountIn);
   1015 | }
   1016 | 
   1017 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1031 行
- **函数**: `getApprovalType()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1028 |     /// @param token The token to approve
   1029 |     /// @param amount The amount to approve
   1030 |     /// @return The required approval type
>> 1031 |     function getApprovalType(address token, uint256 amount) external returns (ApprovalType);
   1032 | 
   1033 |     /// @notice Approves a token for the maximum possible amount
   1034 |     /// @param token The token to approve
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1035 行
- **函数**: `approveMax()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1032 | 
   1033 |     /// @notice Approves a token for the maximum possible amount
   1034 |     /// @param token The token to approve
>> 1035 |     function approveMax(address token) external payable;
   1036 | 
   1037 |     /// @notice Approves a token for the maximum possible amount minus one
   1038 |     /// @param token The token to approve
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1039 行
- **函数**: `approveMaxMinusOne()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1036 | 
   1037 |     /// @notice Approves a token for the maximum possible amount minus one
   1038 |     /// @param token The token to approve
>> 1039 |     function approveMaxMinusOne(address token) external payable;
   1040 | 
   1041 |     /// @notice Approves a token for zero, then the maximum possible amount
   1042 |     /// @param token The token to approve
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1043 行
- **函数**: `approveZeroThenMax()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1040 | 
   1041 |     /// @notice Approves a token for zero, then the maximum possible amount
   1042 |     /// @param token The token to approve
>> 1043 |     function approveZeroThenMax(address token) external payable;
   1044 | 
   1045 |     /// @notice Approves a token for zero, then the maximum possible amount minus one
   1046 |     /// @param token The token to approve
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1047 行
- **函数**: `approveZeroThenMaxMinusOne()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1044 | 
   1045 |     /// @notice Approves a token for zero, then the maximum possible amount minus one
   1046 |     /// @param token The token to approve
>> 1047 |     function approveZeroThenMaxMinusOne(address token) external payable;
   1048 | 
   1049 |     /// @notice Calls the position manager with arbitrary calldata
   1050 |     /// @param data Calldata to pass along to the position manager
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1052 行
- **函数**: `callPositionManager()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1049 |     /// @notice Calls the position manager with arbitrary calldata
   1050 |     /// @param data Calldata to pass along to the position manager
   1051 |     /// @return result The result from the call
>> 1052 |     function callPositionManager(bytes memory data) external payable returns (bytes memory result);
   1053 | 
   1054 |     struct MintParams {
   1055 |         address token0;
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1068 行
- **函数**: `mint()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1065 |     /// @notice Calls the position manager's mint function
   1066 |     /// @param params Calldata to pass along to the position manager
   1067 |     /// @return result The result from the call
>> 1068 |     function mint(MintParams calldata params) external payable returns (bytes memory result);
   1069 | 
   1070 |     struct IncreaseLiquidityParams {
   1071 |         address token0;
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1081 行
- **函数**: `increaseLiquidity()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1078 |     /// @notice Calls the position manager's increaseLiquidity function
   1079 |     /// @param params Calldata to pass along to the position manager
   1080 |     /// @return result The result from the call
>> 1081 |     function increaseLiquidity(IncreaseLiquidityParams calldata params) external payable returns (bytes memory result);
   1082 | }
   1083 | 
   1084 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1101 行
- **函数**: `multicall()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1098 |     /// @param deadline The time by which this function must be called before failing
   1099 |     /// @param data The encoded function data for each of the calls to make to this contract
   1100 |     /// @return results The results from each of the calls passed in via data
>> 1101 |     function multicall(uint256 deadline, bytes[] calldata data) external payable returns (bytes[] memory results);
   1102 | 
   1103 |     /// @notice Call multiple functions in the current contract and return the data from all of them if they all succeed
   1104 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1153 行
- **函数**: `multicall()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1150 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   1151 |     /// @param data The encoded function data for each of the calls to make to this contract
   1152 |     /// @return results The results from each of the calls passed in via data
>> 1153 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results);
   1154 | }
   1155 | 
   1156 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1388 行
- **函数**: `factoryV2()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1385 | /// @notice Functions that return immutable state of the router
   1386 | interface IImmutableState {
   1387 |     /// @return Returns the address of the Uniswap V2 factory
>> 1388 |     function factoryV2() external view returns (address);
   1389 | 
   1390 |     /// @return Returns the address of Uniswap V3 NFT position manager
   1391 |     function positionManager() external view returns (address);
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1391 行
- **函数**: `positionManager()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1388 |     function factoryV2() external view returns (address);
   1389 | 
   1390 |     /// @return Returns the address of Uniswap V3 NFT position manager
>> 1391 |     function positionManager() external view returns (address);
   1392 | }
   1393 | 
   1394 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1499 行
- **函数**: `unwrapWETH9()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1496 | 
   1497 | abstract contract PeripheryPaymentsExtended is IPeripheryPaymentsExtended, PeripheryPayments {
   1498 |     /// @inheritdoc IPeripheryPaymentsExtended
>> 1499 |     function unwrapWETH9(uint256 amountMinimum) external payable override {
   1500 |         unwrapWETH9(amountMinimum, msg.sender);
   1501 |     }
   1502 | 
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1504 行
- **函数**: `wrapETH()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1501 |     }
   1502 | 
   1503 |     /// @inheritdoc IPeripheryPaymentsExtended
>> 1504 |     function wrapETH(uint256 value) external payable override {
   1505 |         IWETH9(WETH9).deposit{value: value}();
   1506 |     }
   1507 | 
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1509 行
- **函数**: `sweepToken()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1506 |     }
   1507 | 
   1508 |     /// @inheritdoc IPeripheryPaymentsExtended
>> 1509 |     function sweepToken(address token, uint256 amountMinimum) external payable override {
   1510 |         sweepToken(token, amountMinimum, msg.sender);
   1511 |     }
   1512 | 
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1514 行
- **函数**: `pull()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1511 |     }
   1512 | 
   1513 |     /// @inheritdoc IPeripheryPaymentsExtended
>> 1514 |     function pull(address token, uint256 value) external payable override {
   1515 |         TransferHelper.safeTransferFrom(token, msg.sender, address(this), value);
   1516 |     }
   1517 | }
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1540 行
- **函数**: `unwrapWETH9()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1537 |     }
   1538 | 
   1539 |     /// @inheritdoc IPeripheryPayments
>> 1540 |     function unwrapWETH9(uint256 amountMinimum, address recipient) public payable override {
   1541 |         uint256 balanceWETH9 = IWETH9(WETH9).balanceOf(address(this));
   1542 |         require(balanceWETH9 >= amountMinimum, 'Insufficient WETH9');
   1543 | 
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1565 行
- **函数**: `refundETH()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1562 |     }
   1563 | 
   1564 |     /// @inheritdoc IPeripheryPayments
>> 1565 |     function refundETH() external payable override {
   1566 |         if (address(this).balance > 0) TransferHelper.safeTransferETH(msg.sender, address(this).balance);
   1567 |     }
   1568 | 
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1637 行
- **函数**: `deposit()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1634 | /// @title Interface for WETH9
   1635 | interface IWETH9 is IERC20 {
   1636 |     /// @notice Deposit ether to get wrapped ether
>> 1637 |     function deposit() external payable;
   1638 | 
   1639 |     /// @notice Withdraw wrapped ether to get ether
   1640 |     function withdraw(uint256) external;
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1720 行
- **函数**: `unwrapWETH9()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1717 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   1718 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
   1719 |     /// @param recipient The address receiving ETH
>> 1720 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external payable;
   1721 | 
   1722 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   1723 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1725 行
- **函数**: `refundETH()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1722 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   1723 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
   1724 |     /// that use ether for the input amount
>> 1725 |     function refundETH() external payable;
   1726 | 
   1727 |     /// @notice Transfers the full amount of a token held by this contract to recipient
   1728 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1753 行
- **函数**: `unwrapWETH9()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1750 |     /// @notice Unwraps the contract's WETH9 balance and sends it to msg.sender as ETH.
   1751 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   1752 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
>> 1753 |     function unwrapWETH9(uint256 amountMinimum) external payable;
   1754 | 
   1755 |     /// @notice Wraps the contract's ETH balance into WETH9
   1756 |     /// @dev The resulting WETH9 is custodied by the router, thus will require further distribution
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1758 行
- **函数**: `wrapETH()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1755 |     /// @notice Wraps the contract's ETH balance into WETH9
   1756 |     /// @dev The resulting WETH9 is custodied by the router, thus will require further distribution
   1757 |     /// @param value The amount of ETH to wrap
>> 1758 |     function wrapETH(uint256 value) external payable;
   1759 | 
   1760 |     /// @notice Transfers the full amount of a token held by this contract to msg.sender
   1761 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1764 行
- **函数**: `sweepToken()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1761 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
   1762 |     /// @param token The contract address of the token which will be transferred to msg.sender
   1763 |     /// @param amountMinimum The minimum amount of token required for a transfer
>> 1764 |     function sweepToken(address token, uint256 amountMinimum) external payable;
   1765 | 
   1766 |     /// @notice Transfers the specified amount of a token from the msg.sender to address(this)
   1767 |     /// @param token The token to pull
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1769 行
- **函数**: `pull()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1766 |     /// @notice Transfers the specified amount of a token from the msg.sender to address(this)
   1767 |     /// @param token The token to pull
   1768 |     /// @param value The amount to pay
>> 1769 |     function pull(address token, uint256 value) external payable;
   1770 | }
   1771 | 
   1772 | 
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1781 行
- **函数**: `name()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1778 |     event Approval(address indexed owner, address indexed spender, uint value);
   1779 |     event Transfer(address indexed from, address indexed to, uint value);
   1780 | 
>> 1781 |     function name() external pure returns (string memory);
   1782 |     function symbol() external pure returns (string memory);
   1783 |     function decimals() external pure returns (uint8);
   1784 |     function totalSupply() external view returns (uint);
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1782 行
- **函数**: `symbol()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1779 |     event Transfer(address indexed from, address indexed to, uint value);
   1780 | 
   1781 |     function name() external pure returns (string memory);
>> 1782 |     function symbol() external pure returns (string memory);
   1783 |     function decimals() external pure returns (uint8);
   1784 |     function totalSupply() external view returns (uint);
   1785 |     function balanceOf(address owner) external view returns (uint);
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1783 行
- **函数**: `decimals()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1780 | 
   1781 |     function name() external pure returns (string memory);
   1782 |     function symbol() external pure returns (string memory);
>> 1783 |     function decimals() external pure returns (uint8);
   1784 |     function totalSupply() external view returns (uint);
   1785 |     function balanceOf(address owner) external view returns (uint);
   1786 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1784 行
- **函数**: `totalSupply()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1781 |     function name() external pure returns (string memory);
   1782 |     function symbol() external pure returns (string memory);
   1783 |     function decimals() external pure returns (uint8);
>> 1784 |     function totalSupply() external view returns (uint);
   1785 |     function balanceOf(address owner) external view returns (uint);
   1786 |     function allowance(address owner, address spender) external view returns (uint);
   1787 | 
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1785 行
- **函数**: `balanceOf()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1782 |     function symbol() external pure returns (string memory);
   1783 |     function decimals() external pure returns (uint8);
   1784 |     function totalSupply() external view returns (uint);
>> 1785 |     function balanceOf(address owner) external view returns (uint);
   1786 |     function allowance(address owner, address spender) external view returns (uint);
   1787 | 
   1788 |     function approve(address spender, uint value) external returns (bool);
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1786 行
- **函数**: `allowance()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1783 |     function decimals() external pure returns (uint8);
   1784 |     function totalSupply() external view returns (uint);
   1785 |     function balanceOf(address owner) external view returns (uint);
>> 1786 |     function allowance(address owner, address spender) external view returns (uint);
   1787 | 
   1788 |     function approve(address spender, uint value) external returns (bool);
   1789 |     function transfer(address to, uint value) external returns (bool);
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1788 行
- **函数**: `approve()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1785 |     function balanceOf(address owner) external view returns (uint);
   1786 |     function allowance(address owner, address spender) external view returns (uint);
   1787 | 
>> 1788 |     function approve(address spender, uint value) external returns (bool);
   1789 |     function transfer(address to, uint value) external returns (bool);
   1790 |     function transferFrom(address from, address to, uint value) external returns (bool);
   1791 | 
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1789 行
- **函数**: `transfer()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1786 |     function allowance(address owner, address spender) external view returns (uint);
   1787 | 
   1788 |     function approve(address spender, uint value) external returns (bool);
>> 1789 |     function transfer(address to, uint value) external returns (bool);
   1790 |     function transferFrom(address from, address to, uint value) external returns (bool);
   1791 | 
   1792 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1790 行
- **函数**: `transferFrom()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1787 | 
   1788 |     function approve(address spender, uint value) external returns (bool);
   1789 |     function transfer(address to, uint value) external returns (bool);
>> 1790 |     function transferFrom(address from, address to, uint value) external returns (bool);
   1791 | 
   1792 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1793 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1792 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1789 |     function transfer(address to, uint value) external returns (bool);
   1790 |     function transferFrom(address from, address to, uint value) external returns (bool);
   1791 | 
>> 1792 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1793 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   1794 |     function nonces(address owner) external view returns (uint);
   1795 | 
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1793 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1790 |     function transferFrom(address from, address to, uint value) external returns (bool);
   1791 | 
   1792 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>> 1793 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   1794 |     function nonces(address owner) external view returns (uint);
   1795 | 
   1796 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1794 行
- **函数**: `nonces()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1791 | 
   1792 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1793 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>> 1794 |     function nonces(address owner) external view returns (uint);
   1795 | 
   1796 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
   1797 | 
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1810 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1807 |     );
   1808 |     event Sync(uint112 reserve0, uint112 reserve1);
   1809 | 
>> 1810 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   1811 |     function factory() external view returns (address);
   1812 |     function token0() external view returns (address);
   1813 |     function token1() external view returns (address);
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1811 行
- **函数**: `factory()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1808 |     event Sync(uint112 reserve0, uint112 reserve1);
   1809 | 
   1810 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
>> 1811 |     function factory() external view returns (address);
   1812 |     function token0() external view returns (address);
   1813 |     function token1() external view returns (address);
   1814 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1812 行
- **函数**: `token0()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1809 | 
   1810 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   1811 |     function factory() external view returns (address);
>> 1812 |     function token0() external view returns (address);
   1813 |     function token1() external view returns (address);
   1814 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1815 |     function price0CumulativeLast() external view returns (uint);
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1813 行
- **函数**: `token1()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1810 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   1811 |     function factory() external view returns (address);
   1812 |     function token0() external view returns (address);
>> 1813 |     function token1() external view returns (address);
   1814 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1815 |     function price0CumulativeLast() external view returns (uint);
   1816 |     function price1CumulativeLast() external view returns (uint);
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1814 行
- **函数**: `getReserves()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1811 |     function factory() external view returns (address);
   1812 |     function token0() external view returns (address);
   1813 |     function token1() external view returns (address);
>> 1814 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1815 |     function price0CumulativeLast() external view returns (uint);
   1816 |     function price1CumulativeLast() external view returns (uint);
   1817 |     function kLast() external view returns (uint);
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1815 行
- **函数**: `price0CumulativeLast()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1812 |     function token0() external view returns (address);
   1813 |     function token1() external view returns (address);
   1814 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>> 1815 |     function price0CumulativeLast() external view returns (uint);
   1816 |     function price1CumulativeLast() external view returns (uint);
   1817 |     function kLast() external view returns (uint);
   1818 | 
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1816 行
- **函数**: `price1CumulativeLast()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1813 |     function token1() external view returns (address);
   1814 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1815 |     function price0CumulativeLast() external view returns (uint);
>> 1816 |     function price1CumulativeLast() external view returns (uint);
   1817 |     function kLast() external view returns (uint);
   1818 | 
   1819 |     function mint(address to) external returns (uint liquidity);
```

---

### 78. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1817 行
- **函数**: `kLast()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1814 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1815 |     function price0CumulativeLast() external view returns (uint);
   1816 |     function price1CumulativeLast() external view returns (uint);
>> 1817 |     function kLast() external view returns (uint);
   1818 | 
   1819 |     function mint(address to) external returns (uint liquidity);
   1820 |     function burn(address to) external returns (uint amount0, uint amount1);
```

---

### 79. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1819 行
- **函数**: `mint()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1816 |     function price1CumulativeLast() external view returns (uint);
   1817 |     function kLast() external view returns (uint);
   1818 | 
>> 1819 |     function mint(address to) external returns (uint liquidity);
   1820 |     function burn(address to) external returns (uint amount0, uint amount1);
   1821 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
   1822 |     function skim(address to) external;
```

---

### 80. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1820 行
- **函数**: `burn()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1817 |     function kLast() external view returns (uint);
   1818 | 
   1819 |     function mint(address to) external returns (uint liquidity);
>> 1820 |     function burn(address to) external returns (uint amount0, uint amount1);
   1821 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
   1822 |     function skim(address to) external;
   1823 |     function sync() external;
```

---

### 81. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2448 行
- **函数**: `factory()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2445 | interface IUniswapV3PoolImmutables {
   2446 |     /// @notice The contract that deployed the pool, which must adhere to the IUniswapV3Factory interface
   2447 |     /// @return The contract address
>> 2448 |     function factory() external view returns (address);
   2449 | 
   2450 |     /// @notice The first of the two tokens of the pool, sorted by address
   2451 |     /// @return The token contract address
```

---

### 82. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2452 行
- **函数**: `token0()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2449 | 
   2450 |     /// @notice The first of the two tokens of the pool, sorted by address
   2451 |     /// @return The token contract address
>> 2452 |     function token0() external view returns (address);
   2453 | 
   2454 |     /// @notice The second of the two tokens of the pool, sorted by address
   2455 |     /// @return The token contract address
```

---

### 83. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2456 行
- **函数**: `token1()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2453 | 
   2454 |     /// @notice The second of the two tokens of the pool, sorted by address
   2455 |     /// @return The token contract address
>> 2456 |     function token1() external view returns (address);
   2457 | 
   2458 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   2459 |     /// @return The fee
```

---

### 84. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2460 行
- **函数**: `fee()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2457 | 
   2458 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   2459 |     /// @return The fee
>> 2460 |     function fee() external view returns (uint24);
   2461 | 
   2462 |     /// @notice The pool tick spacing
   2463 |     /// @dev Ticks can only be used at multiples of this value, minimum of 1 and always positive
```

---

### 85. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2467 行
- **函数**: `tickSpacing()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2464 |     /// e.g.: a tickSpacing of 3 means ticks can be initialized every 3rd tick, i.e., ..., -6, -3, 0, 3, 6, ...
   2465 |     /// This value is an int24 to avoid casting even though it is always positive.
   2466 |     /// @return The tick spacing
>> 2467 |     function tickSpacing() external view returns (int24);
   2468 | 
   2469 |     /// @notice The maximum amount of position liquidity that can use any tick in the range
   2470 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
```

---

### 86. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2473 行
- **函数**: `maxLiquidityPerTick()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2470 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
   2471 |     /// also prevents out-of-range liquidity from being used to prevent adding in-range liquidity to a pool
   2472 |     /// @return The max amount of liquidity per tick
>> 2473 |     function maxLiquidityPerTick() external view returns (uint128);
   2474 | }
   2475 | 
   2476 | 
```

---

### 87. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2514 行
- **函数**: `feeGrowthGlobal0X128()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2511 | 
   2512 |     /// @notice The fee growth as a Q128.128 fees of token0 collected per unit of liquidity for the entire life of the pool
   2513 |     /// @dev This value can overflow the uint256
>> 2514 |     function feeGrowthGlobal0X128() external view returns (uint256);
   2515 | 
   2516 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   2517 |     /// @dev This value can overflow the uint256
```

---

### 88. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2518 行
- **函数**: `feeGrowthGlobal1X128()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2515 | 
   2516 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   2517 |     /// @dev This value can overflow the uint256
>> 2518 |     function feeGrowthGlobal1X128() external view returns (uint256);
   2519 | 
   2520 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   2521 |     /// @dev Protocol fees will never exceed uint128 max in either token
```

---

### 89. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2522 行
- **函数**: `protocolFees()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2519 | 
   2520 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   2521 |     /// @dev Protocol fees will never exceed uint128 max in either token
>> 2522 |     function protocolFees() external view returns (uint128 token0, uint128 token1);
   2523 | 
   2524 |     /// @notice The currently in range liquidity available to the pool
   2525 |     /// @dev This value has no relationship to the total liquidity across all ticks
```

---

### 90. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2526 行
- **函数**: `liquidity()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2523 | 
   2524 |     /// @notice The currently in range liquidity available to the pool
   2525 |     /// @dev This value has no relationship to the total liquidity across all ticks
>> 2526 |     function liquidity() external view returns (uint128);
   2527 | 
   2528 |     /// @notice Look up information about a specific tick in the pool
   2529 |     /// @param tick The tick to look up
```

---

### 91. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2557 行
- **函数**: `tickBitmap()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2554 |         );
   2555 | 
   2556 |     /// @notice Returns 256 packed tick initialized boolean values. See TickBitmap for more information
>> 2557 |     function tickBitmap(int16 wordPosition) external view returns (uint256);
   2558 | 
   2559 |     /// @notice Returns the information about a position by the position's key
   2560 |     /// @param key The position's key is a hash of a preimage composed by the owner, tickLower and tickUpper
```

---

### 92. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3544 行
- **函数**: `collect()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3541 |     /// amount1Max The maximum amount of token1 to collect
   3542 |     /// @return amount0 The amount of fees collected in token0
   3543 |     /// @return amount1 The amount of fees collected in token1
>> 3544 |     function collect(CollectParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
   3545 | 
   3546 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   3547 |     /// must be collected first.
```

---

### 93. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3549 行
- **函数**: `burn()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3546 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   3547 |     /// must be collected first.
   3548 |     /// @param tokenId The ID of the token that is being burned
>> 3549 |     function burn(uint256 tokenId) external payable;
   3550 | 
   3551 | //    function positionsWeights(uint tokenId) external view returns (uint, uint, uint);
   3552 | 
```

---

### 94. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3574 行
- **函数**: `name()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3571 |     /**
   3572 |      * @dev Returns the token collection name.
   3573 |      */
>> 3574 |     function name() external view returns (string memory);
   3575 | 
   3576 |     /**
   3577 |      * @dev Returns the token collection symbol.
```

---

### 95. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3579 行
- **函数**: `symbol()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3576 |     /**
   3577 |      * @dev Returns the token collection symbol.
   3578 |      */
>> 3579 |     function symbol() external view returns (string memory);
   3580 | 
   3581 |     /**
   3582 |      * @dev Returns the Uniform Resource Identifier (URI) for `tokenId` token.
```

---

### 96. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3584 行
- **函数**: `tokenURI()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3581 |     /**
   3582 |      * @dev Returns the Uniform Resource Identifier (URI) for `tokenId` token.
   3583 |      */
>> 3584 |     function tokenURI(uint256 tokenId) external view returns (string memory);
   3585 | }
   3586 | 
   3587 | 
```

---

### 97. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3605 行
- **函数**: `totalSupply()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3602 |     /**
   3603 |      * @dev Returns the total amount of tokens stored by the contract.
   3604 |      */
>> 3605 |     function totalSupply() external view returns (uint256);
   3606 | 
   3607 |     /**
   3608 |      * @dev Returns a token ID owned by `owner` at a given `index` of its token list.
```

---

### 98. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3611 行
- **函数**: `tokenOfOwnerByIndex()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3608 |      * @dev Returns a token ID owned by `owner` at a given `index` of its token list.
   3609 |      * Use along with {balanceOf} to enumerate all of ``owner``'s tokens.
   3610 |      */
>> 3611 |     function tokenOfOwnerByIndex(address owner, uint256 index) external view returns (uint256 tokenId);
   3612 | 
   3613 |     /**
   3614 |      * @dev Returns a token ID at a given `index` of all the tokens stored by the contract.
```

---

### 99. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3617 行
- **函数**: `tokenByIndex()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3614 |      * @dev Returns a token ID at a given `index` of all the tokens stored by the contract.
   3615 |      * Use along with {totalSupply} to enumerate all tokens.
   3616 |      */
>> 3617 |     function tokenByIndex(uint256 index) external view returns (uint256);
   3618 | }
   3619 | 
   3620 | 
```

---

### 100. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3659 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3656 | interface IERC721Permit is IERC721 {
   3657 |     /// @notice The permit typehash used in the permit signature
   3658 |     /// @return The typehash for the permit
>> 3659 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   3660 | 
   3661 |     /// @notice The domain separator used in the permit signature
   3662 |     /// @return The domain seperator used in encoding of permit signature
```

---

### 101. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3663 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3660 | 
   3661 |     /// @notice The domain separator used in the permit signature
   3662 |     /// @return The domain seperator used in encoding of permit signature
>> 3663 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   3664 | 
   3665 |     /// @notice Approve of a specific token ID for spending by spender via signature
   3666 |     /// @param spender The account that is being approved
```

---

### 102. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3713 行
- **函数**: `balanceOf()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3710 |     /**
   3711 |      * @dev Returns the number of tokens in ``owner``'s account.
   3712 |      */
>> 3713 |     function balanceOf(address owner) external view returns (uint256 balance);
   3714 | 
   3715 |     /**
   3716 |      * @dev Returns the owner of the `tokenId` token.
```

---

### 103. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3722 行
- **函数**: `ownerOf()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3719 |      *
   3720 |      * - `tokenId` must exist.
   3721 |      */
>> 3722 |     function ownerOf(uint256 tokenId) external view returns (address owner);
   3723 | 
   3724 |     /**
   3725 |      * @dev Safely transfers `tokenId` token from `from` to `to`, checking first that contract recipients
```

---

### 104. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3778 行
- **函数**: `getApproved()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3775 |      *
   3776 |      * - `tokenId` must exist.
   3777 |      */
>> 3778 |     function getApproved(uint256 tokenId) external view returns (address operator);
   3779 | 
   3780 |     /**
   3781 |      * @dev Approve or remove `operator` as an operator for the caller.
```

---

### 105. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3797 行
- **函数**: `isApprovedForAll()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3794 |      *
   3795 |      * See {setApprovalForAll}
   3796 |      */
>> 3797 |     function isApprovedForAll(address owner, address operator) external view returns (bool);
   3798 | 
   3799 |     /**
   3800 |       * @dev Safely transfers `tokenId` token from `from` to `to`.
```

---

### 106. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3840 行
- **函数**: `supportsInterface()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3837 |      *
   3838 |      * This function call must use less than 30 000 gas.
   3839 |      */
>> 3840 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   3841 | }
   3842 | 
   3843 | 
```

---

### 107. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3856 行
- **函数**: `multicall()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3853 | /// @notice Enables calling multiple methods in a single call to the contract
   3854 | abstract contract Multicall is IMulticall {
   3855 |     /// @inheritdoc IMulticall
>> 3856 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
   3857 |         results = new bytes[](data.length);
   3858 |         for (uint256 i = 0; i < data.length; i++) {
   3859 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
```

---

### 108. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 17 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     12 | import './V3SwapRouter.sol';
     13 | import './base/ApproveAndCall.sol';
     14 | import './base/MulticallExtended.sol';
     15 | 
     16 | /// @title Uniswap V2 and V3 Swap Router
>>   17 | contract SwapRouter02 is ISwapRouter02, V2SwapRouter, V3SwapRouter, ApproveAndCall, MulticallExtended, SelfPermit {
     18 |     constructor(
     19 |         address _factoryV2,
     20 |         address factoryV3,
     21 |         address _positionManager,
     22 |         address _WETH9
```

---

### 109. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 103 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     98 | 
     99 | import '../interfaces/IPeripheryImmutableState.sol';
    100 | 
    101 | /// @title Immutable state
    102 | /// @notice Immutable state used by periphery contracts
>>  103 | abstract contract PeripheryImmutableState is IPeripheryImmutableState {
    104 |     /// @inheritdoc IPeripheryImmutableState
    105 |     address public immutable override factory;
    106 |     /// @inheritdoc IPeripheryImmutableState
    107 |     address public immutable override WETH9;
    108 | 
```

---

### 110. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 152 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    147 | import './libraries/Constants.sol';
    148 | import './libraries/UniswapV2Library.sol';
    149 | 
    150 | /// @title Uniswap V2 Swap Router
    151 | /// @notice Router for stateless execution of swaps against Uniswap V2
>>  152 | abstract contract V2SwapRouter is IV2SwapRouter, ImmutableState, PeripheryPaymentsWithFeeExtended {
    153 |     using LowGasSafeMath for uint256;
    154 | 
    155 |     // supports fee-on-transfer tokens
    156 |     // requires the initial amount to have already been sent to the first pair
    157 |     function _swap(address[] memory path, address _to) private {
```

---

### 111. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 254 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    249 | import './base/OracleSlippage.sol';
    250 | import './libraries/Constants.sol';
    251 | 
    252 | /// @title Uniswap V3 Swap Router
    253 | /// @notice Router for stateless execution of swaps against Uniswap V3
>>  254 | abstract contract V3SwapRouter is IV3SwapRouter, PeripheryPaymentsWithFeeExtended, OracleSlippage {
    255 |     using Path for bytes;
    256 |     using SafeCast for uint256;
    257 | 
    258 |     /// @dev Used as the placeholder value for amountInCached, because the computed amount in for an exact output swap
    259 |     /// can never actually be this value
```

---

### 112. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 367 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    362 |         require(amountOut >= params.amountOutMinimum, 'Too little received');
    363 |     }
    364 | 
    365 |     /// @inheritdoc IV3SwapRouter
    366 |     function exactInput(ExactInputParams memory params) external payable override returns (uint256 amountOut) {
>>  367 |         // use amountIn == Constants.CONTRACT_BALANCE as a flag to swap the entire balance of the contract
    368 |         bool hasAlreadyPaid;
    369 |         if (params.amountIn == Constants.CONTRACT_BALANCE) {
    370 |             hasAlreadyPaid = true;
    371 |             (address tokenIn, , ) = params.path.decodeFirstPool();
    372 |             params.amountIn = IERC20(tokenIn).balanceOf(address(this));
```

---

### 113. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 490 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    485 | import './ImmutableState.sol';
    486 | 
    487 | /// @title Approve and Call
    488 | /// @notice Allows callers to approve the Uniswap V3 position manager from this contract,
    489 | /// for any token, and then make calls into the position manager
>>  490 | abstract contract ApproveAndCall is IApproveAndCall, ImmutableState {
    491 |     function tryApprove(address token, uint256 amount) private returns (bool) {
    492 |         (bool success, bytes memory data) =
    493 |             token.call(abi.encodeWithSelector(IERC20.approve.selector, positionManager, amount));
    494 |         return success && (data.length == 0 || abi.decode(data, (bool)));
    495 |     }
```

---

### 114. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 787 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    782 | pragma solidity >=0.7.5;
    783 | 
    784 | /// @title Self Permit
    785 | /// @notice Functionality to call permit on any EIP-2612-compliant token for use in the route
    786 | interface ISelfPermit {
>>  787 |     /// @notice Permits this contract to spend a given token from `msg.sender`
    788 |     /// @dev The `owner` is always msg.sender and the `spender` is always address(this).
    789 |     /// @param token The address of the token spent
    790 |     /// @param value The amount that can be spent of token
    791 |     /// @param deadline A timestamp, the current blocktime must be less than or equal to this timestamp
    792 |     /// @param v Must produce valid secp256k1 signature from the holder along with `r` and `s`
```

---

### 115. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 916 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    911 | 
    912 | /// @title Router token swapping functionality
    913 | /// @notice Functions for swapping tokens via Uniswap V2
    914 | interface IV2SwapRouter {
    915 |     /// @notice Swaps `amountIn` of one token for as much as possible of another token
>>  916 |     /// @dev Setting `amountIn` to 0 will cause the contract to look up its own balance,
    917 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
    918 |     /// @param amountIn The amount of token to swap
    919 |     /// @param amountOutMin The minimum amount of output that must be received
    920 |     /// @param path The ordered list of tokens to swap through
    921 |     /// @param to The recipient address
```

---

### 116. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 967 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    962 |         uint256 amountOutMinimum;
    963 |         uint160 sqrtPriceLimitX96;
    964 |     }
    965 | 
    966 |     /// @notice Swaps `amountIn` of one token for as much as possible of another token
>>  967 |     /// @dev Setting `amountIn` to 0 will cause the contract to look up its own balance,
    968 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
    969 |     /// @param params The parameters necessary for the swap, encoded as `ExactInputSingleParams` in calldata
    970 |     /// @return amountOut The amount of the received token
    971 |     function exactInputSingle(ExactInputSingleParams calldata params) external payable returns (uint256 amountOut);
    972 | 
```

---

### 117. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 981 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    976 |         uint256 amountIn;
    977 |         uint256 amountOutMinimum;
    978 |     }
    979 | 
    980 |     /// @notice Swaps `amountIn` of one token for as much as possible of another along the specified path
>>  981 |     /// @dev Setting `amountIn` to 0 will cause the contract to look up its own balance,
    982 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
    983 |     /// @param params The parameters necessary for the multi-hop swap, encoded as `ExactInputParams` in calldata
    984 |     /// @return amountOut The amount of the received token
    985 |     function exactInput(ExactInputParams calldata params) external payable returns (uint256 amountOut);
    986 | 
```

---

### 118. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1096 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1091 | import '@uniswap/v3-periphery/contracts/interfaces/IMulticall.sol';
   1092 | 
   1093 | /// @title MulticallExtended interface
   1094 | /// @notice Enables calling multiple methods in a single call to the contract with optional validation
   1095 | interface IMulticallExtended is IMulticall {
>> 1096 |     /// @notice Call multiple functions in the current contract and return the data from all of them if they all succeed
   1097 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   1098 |     /// @param deadline The time by which this function must be called before failing
   1099 |     /// @param data The encoded function data for each of the calls to make to this contract
   1100 |     /// @return results The results from each of the calls passed in via data
   1101 |     function multicall(uint256 deadline, bytes[] calldata data) external payable returns (bytes[] memory results);
```

---

### 119. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1217 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1212 | 
   1213 | import '../interfaces/IImmutableState.sol';
   1214 | 
   1215 | /// @title Immutable state
   1216 | /// @notice Immutable state used by the swap router
>> 1217 | abstract contract ImmutableState is IImmutableState {
   1218 |     /// @inheritdoc IImmutableState
   1219 |     address public immutable override factoryV2;
   1220 |     /// @inheritdoc IImmutableState
   1221 |     address public immutable override positionManager;
   1222 | 
```

---

### 120. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1240 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1235 | import '@uniswap/v3-periphery/contracts/base/PeripheryPaymentsWithFee.sol';
   1236 | 
   1237 | import '../interfaces/IPeripheryPaymentsWithFeeExtended.sol';
   1238 | import './PeripheryPaymentsExtended.sol';
   1239 | 
>> 1240 | abstract contract PeripheryPaymentsWithFeeExtended is
   1241 |     IPeripheryPaymentsWithFeeExtended,
   1242 |     PeripheryPaymentsExtended,
   1243 |     PeripheryPaymentsWithFee
   1244 | {
   1245 |     /// @inheritdoc IPeripheryPaymentsWithFeeExtended
```

---

### 121. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1409 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1404 | import '../interfaces/IPeripheryPaymentsWithFee.sol';
   1405 | 
   1406 | import '../interfaces/external/IWETH9.sol';
   1407 | import '../libraries/TransferHelper.sol';
   1408 | 
>> 1409 | abstract contract PeripheryPaymentsWithFee is PeripheryPayments, IPeripheryPaymentsWithFee {
   1410 |     using LowGasSafeMath for uint256;
   1411 | 
   1412 |     /// @inheritdoc IPeripheryPaymentsWithFee
   1413 |     function unwrapWETH9WithFee(
   1414 |         uint256 amountMinimum,
```

---

### 122. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1654 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1649 | import '@openzeppelin/contracts/token/ERC20/IERC20.sol';
   1650 | 
   1651 | library TransferHelper {
   1652 |     /// @notice Transfers tokens from the targeted address to the given destination
   1653 |     /// @notice Errors with 'STF' if transfer fails
>> 1654 |     /// @param token The contract address of the token to be transferred
   1655 |     /// @param from The originating address from which the tokens will be transferred
   1656 |     /// @param to The destination address of the transfer
   1657 |     /// @param value The amount to be transferred
   1658 |     function safeTransferFrom(
   1659 |         address token,
```

---

### 123. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1671 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1666 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'STF');
   1667 |     }
   1668 | 
   1669 |     /// @notice Transfers tokens from msg.sender to a recipient
   1670 |     /// @dev Errors with ST if transfer fails
>> 1671 |     /// @param token The contract address of the token which will be transferred
   1672 |     /// @param to The recipient of the transfer
   1673 |     /// @param value The value of the transfer
   1674 |     function safeTransfer(
   1675 |         address token,
   1676 |         address to,
```

---

### 124. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1683 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1678 |     ) internal {
   1679 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transfer.selector, to, value));
   1680 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'ST');
   1681 |     }
   1682 | 
>> 1683 |     /// @notice Approves the stipulated contract to spend the given allowance in the given token
   1684 |     /// @dev Errors with 'SA' if transfer fails
   1685 |     /// @param token The contract address of the token to be approved
   1686 |     /// @param to The target of the approval
   1687 |     /// @param value The amount of the given token the target will be allowed to spend
   1688 |     function safeApprove(
```

---

### 125. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1722 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1717 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   1718 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
   1719 |     /// @param recipient The address receiving ETH
   1720 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external payable;
   1721 | 
>> 1722 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   1723 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
   1724 |     /// that use ether for the input amount
   1725 |     function refundETH() external payable;
   1726 | 
   1727 |     /// @notice Transfers the full amount of a token held by this contract to recipient
```

---

### 126. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2446 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2441 | pragma solidity >=0.5.0;
   2442 | 
   2443 | /// @title Pool state that never changes
   2444 | /// @notice These parameters are fixed for a pool forever, i.e., the methods will always return the same values
   2445 | interface IUniswapV3PoolImmutables {
>> 2446 |     /// @notice The contract that deployed the pool, which must adhere to the IUniswapV3Factory interface
   2447 |     /// @return The contract address
   2448 |     function factory() external view returns (address);
   2449 | 
   2450 |     /// @notice The first of the two tokens of the pool, sorted by address
   2451 |     /// @return The token contract address
```

---

### 127. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3222 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3217 |     }
   3218 | 
   3219 |     /// @notice Returns the "synthetic" tick which represents the price of the first entry in `tokens` in terms of the last
   3220 |     /// @dev Useful for calculating relative prices along routes.
   3221 |     /// @dev There must be one tick for each pairwise set of tokens.
>> 3222 |     /// @param tokens The token contract addresses
   3223 |     /// @param ticks The ticks, representing the price of each token pair in `tokens`
   3224 |     /// @return syntheticTick The synthetic tick, representing the relative price of the outermost tokens in `tokens`
   3225 |     function getChainedPrice(address[] memory tokens, int24[] memory ticks)
   3226 |         internal
   3227 |         pure
```

---

### 128. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3633 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3628 | /// @notice Provides a method for creating and initializing a pool, if necessary, for bundling with other methods that
   3629 | /// require the pool to exist.
   3630 | interface IPoolInitializer {
   3631 |     /// @notice Creates a new pool if it does not exist, then initializes if not initialized
   3632 |     /// @dev This method can be bundled with others via IMulticall for the first action (e.g. mint) performed against a pool
>> 3633 |     /// @param token0 The contract address of token0 of the pool
   3634 |     /// @param token1 The contract address of token1 of the pool
   3635 |     /// @param fee The fee amount of the v3 pool for the specified token pair
   3636 |     /// @param sqrtPriceX96 The initial square root price of the pool as a Q64.96 value
   3637 |     /// @return pool Returns the pool address based on the pair of tokens and fee, will return the newly created pool address if necessary
   3638 |     function createAndInitializePoolIfNecessary(
```

---

### 129. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3833 行
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3828 |  *
   3829 |  * For an implementation, see {ERC165}.
   3830 |  */
   3831 | interface IERC165 {
   3832 |     /**
>> 3833 |      * @dev Returns true if this contract implements the interface defined by
   3834 |      * `interfaceId`. See the corresponding
   3835 |      * https://eips.ethereum.org/EIPS/eip-165#how-interfaces-are-identified[EIP section]
   3836 |      * to learn more about how these ids are created.
   3837 |      *
   3838 |      * This function call must use less than 30 000 gas.
```

---

### 130. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 647 行
- **函数**: `multicall()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    644 | 
    645 | // SPDX-License-Identifier: MIT
    646 | 
>>  647 | pragma solidity ^0.7.0;
    648 | 
    649 | /**
    650 |  * @dev Interface of the ERC20 standard as defined in the EIP.
```

---

### 131. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3561 行
- **函数**: `positionsWeights()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   3558 | 
   3559 | // SPDX-License-Identifier: MIT
   3560 | 
>> 3561 | pragma solidity ^0.7.0;
   3562 | 
   3563 | import "./IERC721.sol";
   3564 | 
```

---

### 132. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3592 行
- **函数**: `tokenURI()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   3589 | 
   3590 | // SPDX-License-Identifier: MIT
   3591 | 
>> 3592 | pragma solidity ^0.7.0;
   3593 | 
   3594 | import "./IERC721.sol";
   3595 | 
```

---

### 133. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3687 行
- **函数**: `permit()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   3684 | 
   3685 | // SPDX-License-Identifier: MIT
   3686 | 
>> 3687 | pragma solidity ^0.7.0;
   3688 | 
   3689 | import "../../introspection/IERC165.sol";
   3690 | 
```

---

### 134. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3820 行
- **函数**: `safeTransferFrom()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   3817 | 
   3818 | // SPDX-License-Identifier: MIT
   3819 | 
>> 3820 | pragma solidity ^0.7.0;
   3821 | 
   3822 | /**
   3823 |  * @dev Interface of the ERC165 standard, as defined in the
```

---

### 135. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3051 行
- **函数**: `_blockTimestamp()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   3048 |     /// @dev Method that exists purely to be overridden for tests
   3049 |     /// @return The current block timestamp
   3050 |     function _blockTimestamp() internal view virtual returns (uint256) {
>> 3051 |         return block.timestamp;
   3052 |     }
   3053 | }
   3054 | 
```

---

### 136. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3144 行
- **函数**: `getOldestObservationSecondsAgo()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   3141 |             (observationTimestamp, , , ) = IUniswapV3Pool(pool).observations(0);
   3142 |         }
   3143 | 
>> 3144 |         secondsAgo = uint32(block.timestamp) - observationTimestamp;
   3145 |     }
   3146 | 
   3147 |     /// @notice Given a pool, it returns the tick value as of the start of the current block
```

---

### 137. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3161 行
- **函数**: `getBlockStartingTickAndLiquidity()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   3158 |         // We don't need to check if this observation is initialized - it is guaranteed to be.
   3159 |         (uint32 observationTimestamp, int56 tickCumulative, uint160 secondsPerLiquidityCumulativeX128, ) =
   3160 |             IUniswapV3Pool(pool).observations(observationIndex);
>> 3161 |         if (observationTimestamp != uint32(block.timestamp)) {
   3162 |             return (tick, IUniswapV3Pool(pool).liquidity());
   3163 |         }
   3164 | 
```

---

### 138. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1582 行
- **函数**: `pay()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1579 |         if (token == WETH9 && address(this).balance >= value) {
   1580 |             // pay with WETH9
   1581 |             IWETH9(WETH9).deposit{value: value}(); // wrap only what is needed to pay
>> 1582 |             IWETH9(WETH9).transfer(recipient, value);
   1583 |         } else if (payer == address(this)) {
   1584 |             // pay with tokens already in the contract (for the exact input multihop case)
   1585 |             TransferHelper.safeTransfer(token, recipient, value);
```

---

### 139. 🟢 [LOW] blockhash-usage

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3885 行
- **函数**: `multicall()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: 使用 blockhash()，只能获取最近 256 个区块的哈希，超出范围返回 0。

**代码片段**:
```solidity
   3882 | 
   3883 | abstract contract PeripheryValidationExtended is PeripheryValidation {
   3884 |     modifier checkPreviousBlockhash(bytes32 previousBlockhash) {
>> 3885 |         require(blockhash(block.number - 1) == previousBlockhash, 'Blockhash');
   3886 |         _;
   3887 |     }
   3888 | }
```

---

### 140. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3885 行
- **函数**: `multicall()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   3882 | 
   3883 | abstract contract PeripheryValidationExtended is PeripheryValidation {
   3884 |     modifier checkPreviousBlockhash(bytes32 previousBlockhash) {
>> 3885 |         require(blockhash(block.number - 1) == previousBlockhash, 'Blockhash');
   3886 |         _;
   3887 |     }
   3888 | }
```

---

### 141. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2178 行
- **函数**: `skipToken()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2175 | 
   2176 | /// @title Provides functions for deriving a pool address from the factory, tokens, and the fee
   2177 | library PoolAddress {
>> 2178 |     bytes32 internal constant POOL_INIT_CODE_HASH = 0xe34f199b19b2b4f47f68442619d555527d244f78a3297ea89325f843f87b8b54;
   2179 | 
   2180 |     /// @notice The identifying key of the pool
   2181 |     struct PoolKey {
```

---

### 142. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 546 行
- **函数**: `callPositionManager()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    543 |         if (!success) {
    544 |             // Next 5 lines from https://ethereum.stackexchange.com/a/83577
    545 |             if (result.length < 68) revert();
>>  546 |             assembly {
    547 |                 result := add(result, 0x04)
    548 |             }
    549 |             revert(abi.decode(result, (string)));
```

---

### 143. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1931 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1928 |         uint256 r = ratio;
   1929 |         uint256 msb = 0;
   1930 | 
>> 1931 |         assembly {
   1932 |             let f := shl(7, gt(r, 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF))
   1933 |             msb := or(msb, f)
   1934 |             r := shr(f, r)
```

---

### 144. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1936 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1933 |             msb := or(msb, f)
   1934 |             r := shr(f, r)
   1935 |         }
>> 1936 |         assembly {
   1937 |             let f := shl(6, gt(r, 0xFFFFFFFFFFFFFFFF))
   1938 |             msb := or(msb, f)
   1939 |             r := shr(f, r)
```

---

### 145. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1941 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1938 |             msb := or(msb, f)
   1939 |             r := shr(f, r)
   1940 |         }
>> 1941 |         assembly {
   1942 |             let f := shl(5, gt(r, 0xFFFFFFFF))
   1943 |             msb := or(msb, f)
   1944 |             r := shr(f, r)
```

---

### 146. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1946 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1943 |             msb := or(msb, f)
   1944 |             r := shr(f, r)
   1945 |         }
>> 1946 |         assembly {
   1947 |             let f := shl(4, gt(r, 0xFFFF))
   1948 |             msb := or(msb, f)
   1949 |             r := shr(f, r)
```

---

### 147. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1951 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1948 |             msb := or(msb, f)
   1949 |             r := shr(f, r)
   1950 |         }
>> 1951 |         assembly {
   1952 |             let f := shl(3, gt(r, 0xFF))
   1953 |             msb := or(msb, f)
   1954 |             r := shr(f, r)
```

---

### 148. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1956 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1953 |             msb := or(msb, f)
   1954 |             r := shr(f, r)
   1955 |         }
>> 1956 |         assembly {
   1957 |             let f := shl(2, gt(r, 0xF))
   1958 |             msb := or(msb, f)
   1959 |             r := shr(f, r)
```

---

### 149. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1961 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1958 |             msb := or(msb, f)
   1959 |             r := shr(f, r)
   1960 |         }
>> 1961 |         assembly {
   1962 |             let f := shl(1, gt(r, 0x3))
   1963 |             msb := or(msb, f)
   1964 |             r := shr(f, r)
```

---

### 150. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1966 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1963 |             msb := or(msb, f)
   1964 |             r := shr(f, r)
   1965 |         }
>> 1966 |         assembly {
   1967 |             let f := gt(r, 0x1)
   1968 |             msb := or(msb, f)
   1969 |         }
```

---

### 151. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1976 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1973 | 
   1974 |         int256 log_2 = (int256(msb) - 128) << 64;
   1975 | 
>> 1976 |         assembly {
   1977 |             r := shr(127, mul(r, r))
   1978 |             let f := shr(128, r)
   1979 |             log_2 := or(log_2, shl(63, f))
```

---

### 152. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1982 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1979 |             log_2 := or(log_2, shl(63, f))
   1980 |             r := shr(f, r)
   1981 |         }
>> 1982 |         assembly {
   1983 |             r := shr(127, mul(r, r))
   1984 |             let f := shr(128, r)
   1985 |             log_2 := or(log_2, shl(62, f))
```

---

### 153. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1988 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1985 |             log_2 := or(log_2, shl(62, f))
   1986 |             r := shr(f, r)
   1987 |         }
>> 1988 |         assembly {
   1989 |             r := shr(127, mul(r, r))
   1990 |             let f := shr(128, r)
   1991 |             log_2 := or(log_2, shl(61, f))
```

---

### 154. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 1994 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1991 |             log_2 := or(log_2, shl(61, f))
   1992 |             r := shr(f, r)
   1993 |         }
>> 1994 |         assembly {
   1995 |             r := shr(127, mul(r, r))
   1996 |             let f := shr(128, r)
   1997 |             log_2 := or(log_2, shl(60, f))
```

---

### 155. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2000 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1997 |             log_2 := or(log_2, shl(60, f))
   1998 |             r := shr(f, r)
   1999 |         }
>> 2000 |         assembly {
   2001 |             r := shr(127, mul(r, r))
   2002 |             let f := shr(128, r)
   2003 |             log_2 := or(log_2, shl(59, f))
```

---

### 156. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2006 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2003 |             log_2 := or(log_2, shl(59, f))
   2004 |             r := shr(f, r)
   2005 |         }
>> 2006 |         assembly {
   2007 |             r := shr(127, mul(r, r))
   2008 |             let f := shr(128, r)
   2009 |             log_2 := or(log_2, shl(58, f))
```

---

### 157. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2012 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2009 |             log_2 := or(log_2, shl(58, f))
   2010 |             r := shr(f, r)
   2011 |         }
>> 2012 |         assembly {
   2013 |             r := shr(127, mul(r, r))
   2014 |             let f := shr(128, r)
   2015 |             log_2 := or(log_2, shl(57, f))
```

---

### 158. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2018 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2015 |             log_2 := or(log_2, shl(57, f))
   2016 |             r := shr(f, r)
   2017 |         }
>> 2018 |         assembly {
   2019 |             r := shr(127, mul(r, r))
   2020 |             let f := shr(128, r)
   2021 |             log_2 := or(log_2, shl(56, f))
```

---

### 159. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2024 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2021 |             log_2 := or(log_2, shl(56, f))
   2022 |             r := shr(f, r)
   2023 |         }
>> 2024 |         assembly {
   2025 |             r := shr(127, mul(r, r))
   2026 |             let f := shr(128, r)
   2027 |             log_2 := or(log_2, shl(55, f))
```

---

### 160. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2030 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2027 |             log_2 := or(log_2, shl(55, f))
   2028 |             r := shr(f, r)
   2029 |         }
>> 2030 |         assembly {
   2031 |             r := shr(127, mul(r, r))
   2032 |             let f := shr(128, r)
   2033 |             log_2 := or(log_2, shl(54, f))
```

---

### 161. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2036 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2033 |             log_2 := or(log_2, shl(54, f))
   2034 |             r := shr(f, r)
   2035 |         }
>> 2036 |         assembly {
   2037 |             r := shr(127, mul(r, r))
   2038 |             let f := shr(128, r)
   2039 |             log_2 := or(log_2, shl(53, f))
```

---

### 162. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2042 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2039 |             log_2 := or(log_2, shl(53, f))
   2040 |             r := shr(f, r)
   2041 |         }
>> 2042 |         assembly {
   2043 |             r := shr(127, mul(r, r))
   2044 |             let f := shr(128, r)
   2045 |             log_2 := or(log_2, shl(52, f))
```

---

### 163. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2048 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2045 |             log_2 := or(log_2, shl(52, f))
   2046 |             r := shr(f, r)
   2047 |         }
>> 2048 |         assembly {
   2049 |             r := shr(127, mul(r, r))
   2050 |             let f := shr(128, r)
   2051 |             log_2 := or(log_2, shl(51, f))
```

---

### 164. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2054 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2051 |             log_2 := or(log_2, shl(51, f))
   2052 |             r := shr(f, r)
   2053 |         }
>> 2054 |         assembly {
   2055 |             r := shr(127, mul(r, r))
   2056 |             let f := shr(128, r)
   2057 |             log_2 := or(log_2, shl(50, f))
```

---

### 165. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2924 行
- **函数**: `slice()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2921 | 
   2922 |         bytes memory tempBytes;
   2923 | 
>> 2924 |         assembly {
   2925 |             switch iszero(_length)
   2926 |                 case 0 {
   2927 |                     // Get a location of some free memory and store it in tempBytes as
```

---

### 166. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2984 行
- **函数**: `toAddress()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2981 |         require(_bytes.length >= _start + 20, 'toAddress_outOfBounds');
   2982 |         address tempAddress;
   2983 | 
>> 2984 |         assembly {
   2985 |             tempAddress := div(mload(add(add(_bytes, 0x20), _start)), 0x1000000000000000000000000)
   2986 |         }
   2987 | 
```

---

### 167. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 2996 行
- **函数**: `toUint24()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2993 |         require(_bytes.length >= _start + 3, 'toUint24_outOfBounds');
   2994 |         uint24 tempUint;
   2995 | 
>> 2996 |         assembly {
   2997 |             tempUint := mload(add(add(_bytes, 0x3), _start))
   2998 |         }
   2999 | 
```

---

### 168. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3267 行
- **函数**: `mulDiv()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3264 |         // variables such that product = prod1 * 2**256 + prod0
   3265 |         uint256 prod0; // Least significant 256 bits of the product
   3266 |         uint256 prod1; // Most significant 256 bits of the product
>> 3267 |         assembly {
   3268 |             let mm := mulmod(a, b, not(0))
   3269 |             prod0 := mul(a, b)
   3270 |             prod1 := sub(sub(mm, prod0), lt(mm, prod0))
```

---

### 169. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3276 行
- **函数**: `mulDiv()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3273 |         // Handle non-overflow cases, 256 by 256 division
   3274 |         if (prod1 == 0) {
   3275 |             require(denominator > 0);
>> 3276 |             assembly {
   3277 |                 result := div(prod0, denominator)
   3278 |             }
   3279 |             return result;
```

---

### 170. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3293 行
- **函数**: `mulDiv()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3290 |         // Make division exact by subtracting the remainder from [prod1 prod0]
   3291 |         // Compute remainder using mulmod
   3292 |         uint256 remainder;
>> 3293 |         assembly {
   3294 |             remainder := mulmod(a, b, denominator)
   3295 |         }
   3296 |         // Subtract 256 bit number from 512 bit number
```

---

### 171. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3297 行
- **函数**: `mulDiv()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3294 |             remainder := mulmod(a, b, denominator)
   3295 |         }
   3296 |         // Subtract 256 bit number from 512 bit number
>> 3297 |         assembly {
   3298 |             prod1 := sub(prod1, gt(remainder, prod0))
   3299 |             prod0 := sub(prod0, remainder)
   3300 |         }
```

---

### 172. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3307 行
- **函数**: `mulDiv()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3304 |         // Always >= 1.
   3305 |         uint256 twos = -denominator & denominator;
   3306 |         // Divide denominator by power of two
>> 3307 |         assembly {
   3308 |             denominator := div(denominator, twos)
   3309 |         }
   3310 | 
```

---

### 173. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3312 行
- **函数**: `mulDiv()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3309 |         }
   3310 | 
   3311 |         // Divide [prod1 prod0] by the factors of two
>> 3312 |         assembly {
   3313 |             prod0 := div(prod0, twos)
   3314 |         }
   3315 |         // Shift in bits from prod1 into prod0. For this we need
```

---

### 174. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3318 行
- **函数**: `mulDiv()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3315 |         // Shift in bits from prod1 into prod0. For this we need
   3316 |         // to flip `twos` such that it is 2**256 / twos.
   3317 |         // If twos is zero, then it becomes one
>> 3318 |         assembly {
   3319 |             twos := add(div(sub(0, twos), twos), 1)
   3320 |         }
   3321 |         prod0 |= prod1 * twos;
```

---

### 175. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB971eF87ede563556b2ED4b1C0b0019111Dd85d2` 第 3864 行
- **函数**: `multicall()`
- **合约**: `SwapRouter02`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3861 |             if (!success) {
   3862 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
   3863 |                 if (result.length < 68) revert();
>> 3864 |                 assembly {
   3865 |                     result := add(result, 0x04)
   3866 |                 }
   3867 |                 revert(abi.decode(result, (string)));
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*