# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:26:46
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` |
| contract_name | `TigerNFT` |
| compiler_version | `v0.8.7+commit.e28d00a7` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646144` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 22 |
| 🟢 LOW | 1 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 29 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     26 |     /**
     27 |      * @dev Returns the amount of tokens in existence.
     28 |      */
>>   29 |     function totalSupply() external view returns (uint256);
     30 | 
     31 |     /**
     32 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 34 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     31 |     /**
     32 |      * @dev Returns the amount of tokens owned by `account`.
     33 |      */
>>   34 |     function balanceOf(address account) external view returns (uint256);
     35 | 
     36 |     /**
     37 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 43 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     40 |      *
     41 |      * Emits a {Transfer} event.
     42 |      */
>>   43 |     function transfer(address to, uint256 amount) external returns (bool);
     44 | 
     45 |     /**
     46 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 52 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     49 |      *
     50 |      * This value changes when {approve} or {transferFrom} are called.
     51 |      */
>>   52 |     function allowance(address owner, address spender) external view returns (uint256);
     53 | 
     54 |     /**
     55 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 68 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     65 |      *
     66 |      * Emits an {Approval} event.
     67 |      */
>>   68 |     function approve(address spender, uint256 amount) external returns (bool);
     69 | 
     70 |     /**
     71 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 103 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    100 |     /**
    101 |      * @dev Returns the name of the token.
    102 |      */
>>  103 |     function name() external view returns (string memory);
    104 | 
    105 |     /**
    106 |      * @dev Returns the symbol of the token.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 108 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    105 |     /**
    106 |      * @dev Returns the symbol of the token.
    107 |      */
>>  108 |     function symbol() external view returns (string memory);
    109 | 
    110 |     /**
    111 |      * @dev Returns the decimals places of the token.
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 113 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    110 |     /**
    111 |      * @dev Returns the decimals places of the token.
    112 |      */
>>  113 |     function decimals() external view returns (uint8);
    114 | }
    115 | 
    116 | // File: @openzeppelin/contracts/utils/Context.sol
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 205 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    202 |     /**
    203 |      * @dev Returns the name of the token.
    204 |      */
>>  205 |     function name() public view virtual override returns (string memory) {
    206 |         return _name;
    207 |     }
    208 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 213 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    210 |      * @dev Returns the symbol of the token, usually a shorter version of the
    211 |      * name.
    212 |      */
>>  213 |     function symbol() public view virtual override returns (string memory) {
    214 |         return _symbol;
    215 |     }
    216 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 230 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    227 |      * no way affects any of the arithmetic of the contract, including
    228 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    229 |      */
>>  230 |     function decimals() public view virtual override returns (uint8) {
    231 |         return 18;
    232 |     }
    233 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 237 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    234 |     /**
    235 |      * @dev See {IERC20-totalSupply}.
    236 |      */
>>  237 |     function totalSupply() public view virtual override returns (uint256) {
    238 |         return _totalSupply;
    239 |     }
    240 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 244 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    241 |     /**
    242 |      * @dev See {IERC20-balanceOf}.
    243 |      */
>>  244 |     function balanceOf(address account) public view virtual override returns (uint256) {
    245 |         return _balances[account];
    246 |     }
    247 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 256 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    253 |      * - `to` cannot be the zero address.
    254 |      * - the caller must have a balance of at least `amount`.
    255 |      */
>>  256 |     function transfer(address to, uint256 amount) public virtual override returns (bool) {
    257 |         address owner = _msgSender();
    258 |         _transfer(owner, to, amount);
    259 |         return true;
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 265 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    262 |     /**
    263 |      * @dev See {IERC20-allowance}.
    264 |      */
>>  265 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    266 |         return _allowances[owner][spender];
    267 |     }
    268 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 279 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    276 |      *
    277 |      * - `spender` cannot be the zero address.
    278 |      */
>>  279 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    280 |         address owner = _msgSender();
    281 |         _approve(owner, spender, amount);
    282 |         return true;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 324 行
- **函数**: `increaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    321 |      *
    322 |      * - `spender` cannot be the zero address.
    323 |      */
>>  324 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    325 |         address owner = _msgSender();
    326 |         _approve(owner, spender, allowance(owner, spender) + addedValue);
    327 |         return true;
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 344 行
- **函数**: `decreaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    341 |      * - `spender` must have allowance for the caller of at least
    342 |      * `subtractedValue`.
    343 |      */
>>  344 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    345 |         address owner = _msgSender();
    346 |         uint256 currentAllowance = allowance(owner, spender);
    347 |         require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 571 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    568 |     /**
    569 |      * @dev Returns the address of the current owner.
    570 |      */
>>  571 |     function owner() public view virtual returns (address) {
    572 |         return _owner;
    573 |     }
    574 | 
```

---

### 20. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 178 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    173 |  *
    174 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    175 |  * functions have been added to mitigate the well-known issues around setting
    176 |  * allowances. See {IERC20-approve}.
    177 |  */
>>  178 | contract ERC20 is Context, IERC20, IERC20Metadata {
    179 |     mapping(address => uint256) private _balances;
    180 | 
    181 |     mapping(address => mapping(address => uint256)) private _allowances;
    182 | 
    183 |     uint256 private _totalSupply;
```

---

### 21. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 548 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    543 |  *
    544 |  * This module is used through inheritance. It will make available the modifier
    545 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    546 |  * the owner.
    547 |  */
>>  548 | abstract contract Ownable is Context {
    549 |     address private _owner;
    550 | 
    551 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    552 | 
    553 |     /**
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 603 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    598 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
    599 |         _transferOwnership(newOwner);
    600 |     }
    601 | 
    602 |     /**
>>  603 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    604 |      * Internal function without access restriction.
    605 |      */
    606 |     function _transferOwnership(address newOwner) internal virtual {
    607 |         address oldOwner = _owner;
    608 |         _owner = newOwner;
```

---

### 23. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xf35553305656ed6f9c9F2B09D1Da6976A1bDeD1c` 第 625 行
- **函数**: `transferOut()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    622 |         _mint(address(this), 1000 * 1e4 * 1e18);
    623 |     }
    624 |     function transferOut(address account, uint256 amount) public onlyOwner{
>>  625 |         IERC20(address(this)).transfer(account, amount);
    626 |     }
    627 | }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*