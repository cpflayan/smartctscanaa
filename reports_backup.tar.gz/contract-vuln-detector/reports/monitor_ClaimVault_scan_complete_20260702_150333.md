# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:03:33
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x150FE2f051eF40124388b4d798b1887882d103DA` |
| contract_name | `ClaimVault` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['ClaimVault.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/security/ReentrancyGuard.sol', '@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/utils/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655006` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 14 |
| 🟢 LOW | 6 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 93 行
- **函数**: `claimBNB()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     90 |         _userClaimIds[wallet].push(claimId);
     91 |         totalBNBClaimed += amount;
     92 | 
>>   93 |         (bool ok, ) = wallet.call{value: amount}("");
     94 |         require(ok, "ClaimVault: BNB transfer failed");
     95 | 
     96 |         emit Claimed(claimId, wallet, amount, TokenType.BNB, block.timestamp);
```

---

### 2. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 137 行
- **函数**: `emergencyWithdrawBNB()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    134 |         uint256 balance = address(this).balance;
    135 |         require(balance > 0, "ClaimVault: no BNB");
    136 |         uint256 withdrawAmt = (amount == 0 || amount > balance) ? balance : amount;
>>  137 |         (bool ok, ) = to.call{value: withdrawAmt}("");
    138 |         require(ok, "ClaimVault: BNB transfer failed");
    139 |         emit EmergencyWithdrawBNB(to, withdrawAmt);
    140 |     }
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 152 行
- **函数**: `getBalances()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    149 |         emit EmergencyWithdrawAllin(to, withdrawAmt);
    150 |     }
    151 |  
>>  152 |     function getBalances() external view returns (uint256 bnbBalance, uint256 allinBalance) {
    153 |         bnbBalance   = address(this).balance;
    154 |         allinBalance = IERC20(allinToken).balanceOf(address(this));
    155 |     }
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 158 行
- **函数**: `getClaimCount()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    155 |     }
    156 | 
    157 |  
>>  158 |     function getClaimCount() external view returns (uint256) {
    159 |         return claimHistory.length;
    160 |     }
    161 |  
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 176 行
- **函数**: `getUserClaimIds()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    173 |         }
    174 |     }
    175 |  
>>  176 |     function getUserClaimIds(address wallet) external view returns (uint256[] memory) {
    177 |         return _userClaimIds[wallet];
    178 |     }
    179 |  
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 251 行
- **函数**: `totalSupply()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    248 |     /**
    249 |      * @dev Returns the value of tokens in existence.
    250 |      */
>>  251 |     function totalSupply() external view returns (uint256);
    252 | 
    253 |     /**
    254 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 256 行
- **函数**: `balanceOf()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    253 |     /**
    254 |      * @dev Returns the value of tokens owned by `account`.
    255 |      */
>>  256 |     function balanceOf(address account) external view returns (uint256);
    257 | 
    258 |     /**
    259 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 265 行
- **函数**: `transfer()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    262 |      *
    263 |      * Emits a {Transfer} event.
    264 |      */
>>  265 |     function transfer(address to, uint256 value) external returns (bool);
    266 | 
    267 |     /**
    268 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 274 行
- **函数**: `allowance()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    271 |      *
    272 |      * This value changes when {approve} or {transferFrom} are called.
    273 |      */
>>  274 |     function allowance(address owner, address spender) external view returns (uint256);
    275 | 
    276 |     /**
    277 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 291 行
- **函数**: `approve()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    288 |      *
    289 |      * Emits an {Approval} event.
    290 |      */
>>  291 |     function approve(address spender, uint256 value) external returns (bool);
    292 | 
    293 |     /**
    294 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 302 行
- **函数**: `transferFrom()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    299 |      *
    300 |      * Emits a {Transfer} event.
    301 |      */
>>  302 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    303 | }
    304 | 
    305 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 444 行
- **函数**: `owner()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    441 |     /**
    442 |      * @dev Returns the address of the current owner.
    443 |      */
>>  444 |     function owner() public view virtual returns (address) {
    445 |         return _owner;
    446 |     }
    447 | 
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 408 行
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    403 |  *
    404 |  * This module is used through inheritance. It will make available the modifier
    405 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    406 |  * the owner.
    407 |  */
>>  408 | abstract contract Ownable is Context {
    409 |     address private _owner;
    410 | 
    411 |     /**
    412 |      * @dev The caller account is not authorized to perform an operation.
    413 |      */
```

---

### 14. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 480 行
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    475 |         }
    476 |         _transferOwnership(newOwner);
    477 |     }
    478 | 
    479 |     /**
>>  480 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    481 |      * Internal function without access restriction.
    482 |      */
    483 |     function _transferOwnership(address newOwner) internal virtual {
    484 |         address oldOwner = _owner;
    485 |         _owner = newOwner;
```

---

### 15. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 88 行
- **函数**: `claimBNB()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     85 |             wallet:    wallet,
     86 |             amount:    amount,
     87 |             tokenType: TokenType.BNB,
>>   88 |             timestamp: block.timestamp
     89 |         }));
     90 |         _userClaimIds[wallet].push(claimId);
     91 |         totalBNBClaimed += amount;
```

---

### 16. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 96 行
- **函数**: `claimBNB()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     93 |         (bool ok, ) = wallet.call{value: amount}("");
     94 |         require(ok, "ClaimVault: BNB transfer failed");
     95 | 
>>   96 |         emit Claimed(claimId, wallet, amount, TokenType.BNB, block.timestamp);
     97 |     }
     98 | 
     99 |     /**
```

---

### 17. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 121 行
- **函数**: `claimAllin()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    118 |             wallet:    wallet,
    119 |             amount:    amount,
    120 |             tokenType: TokenType.ALLIN,
>>  121 |             timestamp: block.timestamp
    122 |         }));
    123 |         _userClaimIds[wallet].push(claimId);
    124 |         totalAllinClaimed += amount;
```

---

### 18. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 129 行
- **函数**: `claimAllin()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    126 |         bool ok = IERC20(allinToken).transfer(wallet, amount);
    127 |         require(ok, "ClaimVault: Allin transfer failed");
    128 | 
>>  129 |         emit Claimed(claimId, wallet, amount, TokenType.ALLIN, block.timestamp);
    130 |     }
    131 |  
    132 |     function emergencyWithdrawBNB(address payable to, uint256 amount) external onlyOwner {
```

---

### 19. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 126 行
- **函数**: `claimAllin()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    123 |         _userClaimIds[wallet].push(claimId);
    124 |         totalAllinClaimed += amount;
    125 | 
>>  126 |         bool ok = IERC20(allinToken).transfer(wallet, amount);
    127 |         require(ok, "ClaimVault: Allin transfer failed");
    128 | 
    129 |         emit Claimed(claimId, wallet, amount, TokenType.ALLIN, block.timestamp);
```

---

### 20. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x150FE2f051eF40124388b4d798b1887882d103DA` 第 147 行
- **函数**: `emergencyWithdrawAllin()`
- **合约**: `ClaimVault`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    144 |         uint256 balance = IERC20(allinToken).balanceOf(address(this));
    145 |         require(balance > 0, "ClaimVault: no Allin");
    146 |         uint256 withdrawAmt = (amount == 0 || amount > balance) ? balance : amount;
>>  147 |         bool ok = IERC20(allinToken).transfer(to, withdrawAmt);
    148 |         require(ok, "ClaimVault: Allin transfer failed");
    149 |         emit EmergencyWithdrawAllin(to, withdrawAmt);
    150 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*