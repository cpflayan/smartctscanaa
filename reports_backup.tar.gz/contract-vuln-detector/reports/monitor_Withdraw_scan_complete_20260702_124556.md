# 智能合约安全审计报告

> 生成时间: 2026-07-02 12:45:56
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` |
| contract_name | `Withdraw` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107638938` |

## 安全摘要

**整体风险等级**: UNKNOWN

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 10 |
| 🟢 LOW | 6 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 210 行
- **函数**: `recover()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    207 |     error TransferFailed();
    208 | 
    209 |     modifier onlyEOA() {
>>  210 |         if (msg.sender != tx.origin) revert OnlyEOA();
    211 |         _;
    212 |     }
    213 | 
```

---

### 2. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 318 行
- **函数**: `emergencyWithdrawETH()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    315 |     function emergencyWithdrawETH(address payable to, uint256 amount) external onlyOwner {
    316 |         if (to == address(0)) revert InvalidAddress();
    317 |         
>>  318 |         (bool success, ) = to.call{value: amount}("");
    319 |         if (!success) revert TransferFailed();
    320 |     }
    321 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 5 行
- **函数**: `transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      2 | pragma solidity ^0.8.20;
      3 | 
      4 | interface IERC20 {
>>    5 |     function transfer(address to, uint256 value) external returns (bool);
      6 |     function balanceOf(address account) external view returns (uint256);
      7 | }
      8 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 6 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      3 | 
      4 | interface IERC20 {
      5 |     function transfer(address to, uint256 value) external returns (bool);
>>    6 |     function balanceOf(address account) external view returns (uint256);
      7 | }
      8 | 
      9 | abstract contract Context {
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 35 行
- **函数**: `owner()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     32 |         _;
     33 |     }
     34 | 
>>   35 |     function owner() public view virtual returns (address) {
     36 |         return _owner;
     37 |     }
     38 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 86 行
- **函数**: `paused()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     83 |         _;
     84 |     }
     85 | 
>>   86 |     function paused() public view virtual returns (bool) {
     87 |         return _paused;
     88 |     }
     89 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 271 行
- **函数**: `getUserNonce()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    268 |         emit TokenWithdrawn(msg.sender, orderId, userAmount, feeAmount, currentNonce);
    269 |     }
    270 | 
>>  271 |     function getUserNonce(address user) external view returns (uint256) {
    272 |         return _nonces[user];
    273 |     }
    274 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 275 行
- **函数**: `isOrderUsed()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    272 |         return _nonces[user];
    273 |     }
    274 | 
>>  275 |     function isOrderUsed(uint256 orderId) external view returns (bool) {
    276 |         return _usedOrderIds[orderId];
    277 |     }
    278 | 
```

---

### 9. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 15 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     10 |     function _msgSender() internal view virtual returns (address) {
     11 |         return msg.sender;
     12 |     }
     13 | }
     14 | 
>>   15 | abstract contract Ownable is Context {
     16 |     address private _owner;
     17 | 
     18 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     19 | 
     20 |     error OwnableInvalidOwner(address owner);
```

---

### 10. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 63 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     58 |         _owner = newOwner;
     59 |         emit OwnershipTransferred(oldOwner, newOwner);
     60 |     }
     61 | }
     62 | 
>>   63 | abstract contract Pausable is Context {
     64 |     bool private _paused;
     65 | 
     66 |     event Paused(address account);
     67 |     event Unpaused(address account);
     68 | 
```

---

### 11. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 180 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    175 |         return signer;
    176 |     }
    177 | }
    178 | 
    179 | 
>>  180 | contract Withdraw is Ownable, Pausable, ReentrancyGuard {
    181 |     using ECDSA for bytes32;
    182 | 
    183 |     bytes32 private constant WITHDRAW_TOKEN_TYPEHASH = 
    184 |         keccak256("WithdrawToken(uint256 chainId,address signer,address user,uint256 amount,uint256 orderId,uint256 nonce,uint256 deadline)");
    185 |     
```

---

### 12. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 236 行
- **函数**: `withdrawToken()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    233 |     ) external onlyEOA whenNotPaused nonReentrant {
    234 |         if (amount == 0) revert ZeroAmount();
    235 |         if (amount > maxTokenWithdraw) revert ExceededMaxLimit();
>>  236 |         if (block.timestamp > deadline) revert ExpiredDeadline();
    237 |         if (_usedOrderIds[orderId]) revert OrderAlreadyUsed();
    238 | 
    239 |         bytes32 structHash = keccak256(abi.encode(
```

---

### 13. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 265 行
- **函数**: `withdrawToken()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    262 |         uint256 feeAmount = (amount * 5) / 100;
    263 |         uint256 userAmount = amount - feeAmount;
    264 | 
>>  265 |         if (!token.transfer(receiveAddress, feeAmount)) revert TransferFailed();
    266 |         if (!token.transfer(msg.sender, userAmount)) revert TransferFailed();
    267 | 
    268 |         emit TokenWithdrawn(msg.sender, orderId, userAmount, feeAmount, currentNonce);
```

---

### 14. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 266 行
- **函数**: `withdrawToken()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    263 |         uint256 userAmount = amount - feeAmount;
    264 | 
    265 |         if (!token.transfer(receiveAddress, feeAmount)) revert TransferFailed();
>>  266 |         if (!token.transfer(msg.sender, userAmount)) revert TransferFailed();
    267 | 
    268 |         emit TokenWithdrawn(msg.sender, orderId, userAmount, feeAmount, currentNonce);
    269 |     }
```

---

### 15. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 311 行
- **函数**: `emergencyWithdraw()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    308 |     ) external onlyOwner {
    309 |         if (to == address(0)) revert InvalidAddress();
    310 |         
>>  311 |         bool success = IERC20(token).transfer(to, amount);
    312 |         if (!success) revert TransferFailed();
    313 |     }
    314 | 
```

---

### 16. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 166 行
- **函数**: `recover()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    163 |             v := byte(0, mload(add(signature, 0x60)))
    164 |         }
    165 | 
>>  166 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
    167 |             revert ECDSAInvalidSignature();
    168 |         }
    169 | 
```

---

### 17. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x578D99AcaEFFa1E6dE4750749F5dfd4a0DDB3024` 第 160 行
- **函数**: `recover()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    157 |         bytes32 s;
    158 |         uint8 v;
    159 | 
>>  160 |         assembly {
    161 |             r := mload(add(signature, 0x20))
    162 |             s := mload(add(signature, 0x40))
    163 |             v := byte(0, mload(add(signature, 0x60)))
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*