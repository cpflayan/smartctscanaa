# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:38:55
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` |
| contract_name | `DexRouter` |
| compiler_version | `v0.8.17+commit.8df45f5f` |
| optimization_used | `True` |
| runs | `1` |
| evm_version | `london` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/8/DexRouter.sol', 'contracts/8/UnxswapRouter.sol', 'contracts/8/UnxswapV3Router.sol', 'contracts/8/interfaces/IWETH.sol', 'contracts/8/interfaces/IApproveProxy.sol', 'contracts/8/interfaces/IWNativeRelayer.sol', 'contracts/8/libraries/PMMLib.sol', 'contracts/8/libraries/CommissionLib.sol', 'contracts/8/libraries/EthReceiver.sol', 'contracts/8/libraries/UniswapTokenInfoHelper.sol', 'contracts/8/libraries/CommonLib.sol', 'contracts/8/DagRouter.sol', 'contracts/8/interfaces/IUni.sol', 'contracts/8/libraries/UniversalERC20.sol', 'contracts/8/libraries/CommonUtils.sol', 'contracts/8/interfaces/IUniswapV3SwapCallback.sol', 'contracts/8/interfaces/IUniV3.sol', 'contracts/8/libraries/Address.sol', 'contracts/8/libraries/SafeCast.sol', 'contracts/8/interfaces/AbstractCommissionLib.sol', 'contracts/8/libraries/SafeERC20.sol', 'contracts/8/interfaces/IAdapter.sol', 'contracts/8/interfaces/IERC20.sol', 'contracts/8/libraries/SafeMath.sol', 'contracts/8/interfaces/IDexRouter.sol', 'contracts/8/libraries/CustomRevert.sol', 'contracts/8/libraries/RevertReasonForwarder.sol', 'contracts/8/interfaces/IERC20Permit.sol', 'contracts/8/interfaces/IDaiLikePermit.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646139` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 6 |
| 🟡 MEDIUM | 59 |
| 🟢 LOW | 153 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 367 行
- **函数**: `smartSwapByInvestWithRefund()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    364 |         emit OrderRecord(
    365 |             fromToken,
    366 |             baseRequest.toToken,
>>  367 |             tx.origin,
    368 |             baseRequest.fromTokenAmount,
    369 |             returnAmount
    370 |         );
```

---

### 2. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 438 行
- **函数**: `_uniswapV3SwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    435 |         emit OrderRecord(
    436 |             srcToken,
    437 |             toToken,
>>  438 |             tx.origin,
    439 |             amount,
    440 |             returnAmount
    441 |         );
```

---

### 3. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 579 行
- **函数**: `_smartSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    576 |         emit OrderRecord(
    577 |             _bytes32ToAddress(baseRequest.fromToken),
    578 |             baseRequest.toToken,
>>  579 |             tx.origin,
    580 |             baseRequest.fromTokenAmount,
    581 |             returnAmount
    582 |         );
```

---

### 4. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 652 行
- **函数**: `_unxswapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    649 |         emit OrderRecord(
    650 |             srcToken,
    651 |             toToken,
>>  652 |             tx.origin,
    653 |             amount,
    654 |             returnAmount
    655 |         );
```

---

### 5. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 851 行
- **函数**: `_swapWrap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    848 |         emit OrderRecord(
    849 |             srcToken,
    850 |             toToken,
>>  851 |             tx.origin,
    852 |             amount,
    853 |             amount - toTokenCommissionAndTrimAmount
    854 |         );
```

---

### 6. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 980 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    977 |         emit OrderRecord(
    978 |             _bytes32ToAddress(baseRequest.fromToken),
    979 |             baseRequest.toToken,
>>  980 |             tx.origin,
    981 |             baseRequest.fromTokenAmount,
    982 |             returnAmount
    983 |         );
```

---

### 7. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1045 行
- **函数**: `revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   1042 |         assembly {
   1043 |             // solhint-disable-line no-inline-assembly
   1044 | 
>> 1045 |             function revertWithReason(m, len) {
   1046 |                 mstore(
   1047 |                     0,
   1048 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
```

---

### 8. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1531 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   1528 |         uint256[] calldata pools
   1529 |     ) internal returns (uint256 returnAmount) {
   1530 |         assembly {
>> 1531 |             function _revertWithReason(m, len) {
   1532 |                 mstore(
   1533 |                     0,
   1534 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
```

---

### 9. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1618 行
- **函数**: `_wrapWeth()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   1615 |                 }
   1616 |                 _returnAmount := add(1, not(_returnAmount)) // -a = ~a + 1
   1617 |             }
>> 1618 |             function _wrapWeth(_amount) {
   1619 |                 // require callvalue() >= amount, lt: if x < y return 1，else return 0
   1620 |                 if eq(lt(callvalue(), _amount), 1) {
   1621 |                     mstore(
```

---

### 10. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1636 行
- **函数**: `_unWrapWeth()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   1633 |                     ) //WETH deposit failed
   1634 |                 }
   1635 |             }
>> 1636 |             function _unWrapWeth(_receiver, _amount) {
   1637 |                 let freePtr := mload(0x40)
   1638 |                 let transferPtr := add(freePtr, 4)
   1639 | 
```

---

### 11. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1783 行
- **函数**: `reRevert()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   1780 |     ) external override {
   1781 |         assembly {
   1782 |             // solhint-disable-line no-inline-assembly
>> 1783 |             function reRevert() {
   1784 |                 returndatacopy(0, 0, returndatasize())
   1785 |                 revert(0, returndatasize())
   1786 |             }
```

---

### 12. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1787 行
- **函数**: `getBalanceAndTransfer()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   1784 |                 returndatacopy(0, 0, returndatasize())
   1785 |                 revert(0, returndatasize())
   1786 |             }
>> 1787 |             function getBalanceAndTransfer(emptyPtr, token) {
   1788 |                 mstore(emptyPtr, _SELECTORS3)
   1789 |                 mstore(add(8, emptyPtr), address())
   1790 |                 if iszero(
```

---

### 13. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1806 行
- **函数**: `validateERC20Transfer()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   1803 |                 }
   1804 |             }
   1805 | 
>> 1806 |             function validateERC20Transfer(status) {
   1807 |                 if iszero(status) {
   1808 |                     reRevert()
   1809 |                 }
```

---

### 14. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2124 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2121 |         returns (CommissionInfo memory commissionInfo, TrimInfo memory trimInfo)
   2122 |     {
   2123 |         assembly ("memory-safe") {
>> 2124 |             function _revertWithReason(m, len) {
   2125 |                 mstore(
   2126 |                     0,
   2127 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
```

---

### 15. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2385 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2382 |         address user
   2383 |     ) internal returns (uint256 amount) {
   2384 |         assembly {
>> 2385 |             function _revertWithReason(m, len) {
   2386 |                 mstore(
   2387 |                     0,
   2388 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
```

---

### 16. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2464 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2461 |                 }
   2462 |                 z := sub(x, y)
   2463 |             }
>> 2464 |             function _revertWithReason(m, len) {
   2465 |                 mstore(
   2466 |                     0,
   2467 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
```

---

### 17. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2476 行
- **函数**: `_sendETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2473 |                 mstore(0x40, m)
   2474 |                 revert(0, len)
   2475 |             }
>> 2476 |             function _sendETH(to, amount) {
   2477 |                 if gt(amount, 0) {
   2478 |                     let success := call(gas(), to, amount, 0, 0, 0, 0)
   2479 |                     if eq(success, 0) {
```

---

### 18. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2487 行
- **函数**: `_claimToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2484 |                     }
   2485 |                 }
   2486 |             }
>> 2487 |             function _claimToken(token, _payer, to, amount) {
   2488 |                 if gt(amount, 0) {
   2489 |                     let freePtr := mload(0x40)
   2490 |                     mstore(0x40, add(freePtr, 0x84))
```

---

### 19. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2516 行
- **函数**: `_sendToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2513 |                     }
   2514 |                 }
   2515 |             }
>> 2516 |             function _sendToken(token, to, amount) {
   2517 |                 if gt(amount, 0) {
   2518 |                     let freePtr := mload(0x40)
   2519 |                     mstore(0x40, add(freePtr, 0x44))
```

---

### 20. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2604 行
- **函数**: `_emitCommissionFromToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2601 |                     _emitCommissionFromToken(token, amountScaled, referrer, rate)
   2602 |                 }
   2603 |             }
>> 2604 |             function _emitCommissionFromToken(token, amount, referrer, rate) {
   2605 |                 let freePtr := mload(0x40)
   2606 |                 mstore(0x40, add(freePtr, 0x80))
   2607 |                 mstore(freePtr, token)
```

---

### 21. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2701 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2698 |                 }
   2699 |                 z := sub(x, y)
   2700 |             }
>> 2701 |             function _revertWithReason(m, len) {
   2702 |                 mstore(
   2703 |                     0,
   2704 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
```

---

### 22. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2713 行
- **函数**: `_sendETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2710 |                 mstore(0x40, m)
   2711 |                 revert(0, len)
   2712 |             }
>> 2713 |             function _sendETH(to, amount) {
   2714 |                 if gt(amount, 0) {
   2715 |                     let success := call(gas(), to, amount, 0, 0, 0, 0)
   2716 |                     if eq(success, 0) {
```

---

### 23. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2724 行
- **函数**: `_sendToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2721 |                     }
   2722 |                 }
   2723 |             }
>> 2724 |             function _sendToken(token, to, amount) {
   2725 |                 if gt(amount, 0) {
   2726 |                     let freePtr := mload(0x40)
   2727 |                     mstore(0x40, add(freePtr, 0x44))
```

---

### 24. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2759 行
- **函数**: `_emitCommissionToToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2756 |                     }
   2757 |                 }
   2758 |             }
>> 2759 |             function _emitCommissionToToken(token, amount, referrer, rate) {
   2760 |                 let freePtr := mload(0x40)
   2761 |                 mstore(0x40, add(freePtr, 0x80))
   2762 |                 mstore(freePtr, token)
```

---

### 25. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2772 行
- **函数**: `_emitPositiveSlippageTrimRecord()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2769 |                     0x3cfb523a4c38d88561dd3bf04805a31715c8b5fc468a03b8d684356f360dea99
   2770 |                 ) //emit CommissionToTokenRecord(address,uint256,address,uint256)
   2771 |             }
>> 2772 |             function _emitPositiveSlippageTrimRecord(token, trimAmount, trimAddress) {
   2773 |                 let freePtr := mload(0x40)
   2774 |                 mstore(0x40, add(freePtr, 0x60))
   2775 |                 mstore(freePtr, token)
```

---

### 26. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2784 行
- **函数**: `_emitPositiveSlippageChargeRecord()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2781 |                     0x7bec7d55a62a7a7b8068f1533e2a3bbf727b3e2e57f30c576fe159da60e09a65
   2782 |                 ) // emit PositiveSlippageTrimRecord(address,uint256,address)
   2783 |             }
>> 2784 |             function _emitPositiveSlippageChargeRecord(token, chargeAmount, chargeAddress) {
   2785 |                 let freePtr := mload(0x40)
   2786 |                 mstore(0x40, add(freePtr, 0x60))
   2787 |                 mstore(freePtr, token)
```

---

### 27. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2929 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   2926 |         uint256 mode
   2927 |     ) internal pure override {
   2928 |         assembly ("memory-safe") {
>> 2929 |             function _revertWithReason(m, len) {
   2930 |                 mstore(
   2931 |                     0,
   2932 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
```

---

### 28. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3487 行
- **函数**: `getReserves()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   3484 |         bytes calldata data
   3485 |     ) external;
   3486 | 
>> 3487 |     function getReserves()
   3488 |         external
   3489 |         view
   3490 |         returns (
```

---

### 29. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3118 行
- **函数**: `_exeAdapter()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   3115 |         address refundTo
   3116 |     ) internal {
   3117 |         if (reverse) {
>> 3118 |             (bool s, bytes memory res) = address(adapter).call(
   3119 |                 abi.encodePacked(
   3120 |                     abi.encodeWithSelector(
   3121 |                         IAdapter.sellQuote.selector,
```

---

### 30. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3133 行
- **函数**: `_exeAdapter()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   3130 |                 _revert(res);
   3131 |             }
   3132 |         } else {
>> 3133 |             (bool s, bytes memory res) = address(adapter).call(
   3134 |                 abi.encodePacked(
   3135 |                     abi.encodeWithSelector(
   3136 |                         IAdapter.sellBase.selector,
```

---

### 31. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3217 行
- **函数**: `_transferTokenToUser()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   3214 |             if (to != address(this)) {
   3215 |                 uint256 ethBal = address(this).balance;
   3216 |                 if (ethBal > 0) {
>> 3217 |                     (bool success, ) = payable(to).call{value: ethBal}("");
   3218 |                     require(success, "transfer native token failed");
   3219 |                 }
   3220 |             }
```

---

### 32. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3817 行
- **函数**: `sendValue()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   3814 |         );
   3815 | 
   3816 |         // solhint-disable-next-line avoid-call-value
>> 3817 |         (bool success, ) = recipient.call{value: amount}("");
   3818 |         require(
   3819 |             success,
   3820 |             "Address: unable to send value, recipient may have reverted"
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 863 行
- **函数**: `swapWrap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    860 |     /// @dev This function supports bidirectional swaps between ETH and WETH with minimal gas overhead.
    861 |     /// The rawdata parameter encodes both the direction (reversed flag) and amount using bit operations.
    862 |     /// When reversed=false: ETH -> WETH, when reversed=true: WETH -> ETH.
>>  863 |     function swapWrap(uint256 orderId, uint256 rawdata) external payable {
    864 |         bool reversed;
    865 |         uint128 amount;
    866 |         assembly {
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1911 行
- **函数**: `totalSupply()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1908 | pragma abicoder v2;
   1909 | 
   1910 | interface IWETH {
>> 1911 |     function totalSupply() external view returns (uint256);
   1912 | 
   1913 |     function balanceOf(address account) external view returns (uint256);
   1914 | 
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1913 行
- **函数**: `balanceOf()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1910 | interface IWETH {
   1911 |     function totalSupply() external view returns (uint256);
   1912 | 
>> 1913 |     function balanceOf(address account) external view returns (uint256);
   1914 | 
   1915 |     function transfer(address recipient, uint256 amount)
   1916 |         external
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1924 行
- **函数**: `approve()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1921 |         view
   1922 |         returns (uint256);
   1923 | 
>> 1924 |     function approve(address spender, uint256 amount) external returns (bool);
   1925 | 
   1926 |     function transferFrom(
   1927 |         address src,
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1932 行
- **函数**: `deposit()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1929 |         uint256 wad
   1930 |     ) external returns (bool);
   1931 | 
>> 1932 |     function deposit() external payable;
   1933 | 
   1934 |     function withdraw(uint256 wad) external;
   1935 | }
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1944 行
- **函数**: `isAllowedProxy()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1941 | pragma solidity ^0.8.0;
   1942 | 
   1943 | interface IApproveProxy {
>> 1944 |     function isAllowedProxy(address _proxy) external view returns (bool);
   1945 | 
   1946 |     function claimTokens(
   1947 |         address token,
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1953 行
- **函数**: `tokenApprove()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1950 |         uint256 amount
   1951 |     ) external;
   1952 | 
>> 1953 |     function tokenApprove() external view returns (address);
   1954 |     function addProxy(address) external;
   1955 | }
   1956 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3496 行
- **函数**: `token0()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3493 |             uint32 blockTimestampLast
   3494 |         );
   3495 | 
>> 3496 |     function token0() external view returns (address);
   3497 | 
   3498 |     function token1() external view returns (address);
   3499 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3498 行
- **函数**: `token1()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3495 | 
   3496 |     function token0() external view returns (address);
   3497 | 
>> 3498 |     function token1() external view returns (address);
   3499 | 
   3500 |     function sync() external;
   3501 | }
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3729 行
- **函数**: `token0()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3726 |             bool unlocked
   3727 |         );
   3728 | 
>> 3729 |     function token0() external view returns (address);
   3730 | 
   3731 |     function token1() external view returns (address);
   3732 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3731 行
- **函数**: `token1()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3728 | 
   3729 |     function token0() external view returns (address);
   3730 | 
>> 3731 |     function token1() external view returns (address);
   3732 | 
   3733 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   3734 |     /// @return The fee
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3735 行
- **函数**: `fee()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3732 | 
   3733 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   3734 |     /// @return The fee
>> 3735 |     function fee() external view returns (uint24);
   3736 | }
   3737 | 
   3738 | 
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5217 行
- **函数**: `name()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5214 |     );
   5215 |     event Transfer(address indexed from, address indexed to, uint256 value);
   5216 | 
>> 5217 |     function name() external view returns (string memory);
   5218 | 
   5219 |     function symbol() external view returns (string memory);
   5220 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5219 行
- **函数**: `symbol()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5216 | 
   5217 |     function name() external view returns (string memory);
   5218 | 
>> 5219 |     function symbol() external view returns (string memory);
   5220 | 
   5221 |     function decimals() external view returns (uint8);
   5222 | 
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5221 行
- **函数**: `decimals()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5218 | 
   5219 |     function symbol() external view returns (string memory);
   5220 | 
>> 5221 |     function decimals() external view returns (uint8);
   5222 | 
   5223 |     function totalSupply() external view returns (uint256);
   5224 | 
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5223 行
- **函数**: `totalSupply()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5220 | 
   5221 |     function decimals() external view returns (uint8);
   5222 | 
>> 5223 |     function totalSupply() external view returns (uint256);
   5224 | 
   5225 |     function balanceOf(address owner) external view returns (uint256);
   5226 | 
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5225 行
- **函数**: `balanceOf()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5222 | 
   5223 |     function totalSupply() external view returns (uint256);
   5224 | 
>> 5225 |     function balanceOf(address owner) external view returns (uint256);
   5226 | 
   5227 |     function allowance(address owner, address spender)
   5228 |         external
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5232 行
- **函数**: `approve()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5229 |         view
   5230 |         returns (uint256);
   5231 | 
>> 5232 |     function approve(address spender, uint256 value) external returns (bool);
   5233 | 
   5234 |     function transfer(address to, uint256 value) external returns (bool);
   5235 | 
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5234 行
- **函数**: `transfer()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5231 | 
   5232 |     function approve(address spender, uint256 value) external returns (bool);
   5233 | 
>> 5234 |     function transfer(address to, uint256 value) external returns (bool);
   5235 | 
   5236 |     function transferFrom(
   5237 |         address from,
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5253 行
- **函数**: `wad()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5250 |     uint256 constant WAD = 10**18;
   5251 |     uint256 constant RAY = 10**27;
   5252 | 
>> 5253 |     function wad() public pure returns (uint256) {
   5254 |         return WAD;
   5255 |     }
   5256 | 
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5257 行
- **函数**: `ray()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5254 |         return WAD;
   5255 |     }
   5256 | 
>> 5257 |     function ray() public pure returns (uint256) {
   5258 |         return RAY;
   5259 |     }
   5260 | 
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5640 行
- **函数**: `nonces()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5637 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   5638 |      * prevents a signature from being used multiple times.
   5639 |      */
>> 5640 |     function nonces(address owner) external view returns (uint256);
   5641 | 
   5642 |     /**
   5643 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5646 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5643 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
   5644 |      */
   5645 |     // solhint-disable-next-line func-name-mixedcase
>> 5646 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   5647 | }
   5648 | 
   5649 | 
```

---

### 56. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 25 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     20 | 
     21 | 
     22 | /// @title DexRouterV1
     23 | /// @notice Entrance of Split trading in Dex platform
     24 | /// @dev Entrance of Split trading in Dex platform
>>   25 | contract DexRouter is
     26 |     EthReceiver,
     27 |     UnxswapRouter,
     28 |     UnxswapV3Router,
     29 |     CommissionLib,
     30 |     UniswapTokenInfoHelper,
```

---

### 57. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 997 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    992 | import "./interfaces/IUni.sol";
    993 | 
    994 | import "./libraries/UniversalERC20.sol";
    995 | import "./libraries/CommonUtils.sol";
    996 | 
>>  997 | contract UnxswapRouter is CommonUtils {
    998 |     uint256 private constant _IS_TOKEN0_TAX =
    999 |         0x1000000000000000000000000000000000000000000000000000000000000000;
   1000 |     uint256 private constant _IS_TOKEN1_TAX =
   1001 |         0x2000000000000000000000000000000000000000000000000000000000000000;
   1002 |     uint256 private constant _CLAIM_TOKENS_CALL_SELECTOR_32 =
```

---

### 58. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2031 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2026 | /// SPDX-License-Identifier: MIT
   2027 | pragma solidity ^0.8.0;
   2028 | 
   2029 | import "./CommonUtils.sol";
   2030 | import "../interfaces/AbstractCommissionLib.sol";
>> 2031 | /// @title Base contract with common permit handling logics
   2032 | 
   2033 | abstract contract CommissionLib is AbstractCommissionLib, CommonUtils {
   2034 |     uint256 internal constant _COMMISSION_RATE_MASK =
   2035 |         0x000000000000ffffffffffff0000000000000000000000000000000000000000;
   2036 |     uint256 internal constant _COMMISSION_FLAG_MASK =
```

---

### 59. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3032 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3027 | import {IUniV3} from "../interfaces/IUniV3.sol";
   3028 | 
   3029 | /// @title UniswapTokenInfoHelper
   3030 | /// @notice Helper functions for getting fromToken and toToken from
   3031 | /// encoded pools array of unxswap and uniswapV3Swap methods.
>> 3032 | /// @dev This contract will be used in DexRouter and DexRouterExactOut. So the
   3033 | /// masks are re-defined here and keep the same as in the original contracts.
   3034 | abstract contract UniswapTokenInfoHelper is CommonUtils {
   3035 |     function _getUnxswapTokenInfo(bool sendValue, bytes32[] calldata pools)
   3036 |         internal
   3037 |         view
```

---

### 60. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3105 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3100 | import "../interfaces/IWNativeRelayer.sol";
   3101 | import "../interfaces/IWETH.sol";
   3102 | import "../interfaces/IERC20.sol";
   3103 | 
   3104 | 
>> 3105 | /// @title Base contract with common permit handling logics
   3106 | abstract contract CommonLib is CommonUtils {
   3107 |     using UniversalERC20 for IERC20;
   3108 | 
   3109 |     function _exeAdapter(
   3110 |         bool reverse,
```

---

### 61. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3255 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3250 | 
   3251 | import "./libraries/CommonLib.sol";
   3252 | import "./libraries/UniversalERC20.sol";
   3253 | import "./interfaces/IERC20.sol";
   3254 | 
>> 3255 | abstract contract DagRouter is CommonLib {
   3256 | 
   3257 |     using UniversalERC20 for IERC20;
   3258 | 
   3259 |     /// @notice Core DAG algorithm data structure
   3260 |     /// @dev Maintains the state of the DAG during execution
```

---

### 62. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3587 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3582 | // ── contracts/8/libraries/CommonUtils.sol ──────────────────────────────
   3583 | 
   3584 | /// SPDX-License-Identifier: MIT
   3585 | pragma solidity ^0.8.0;
   3586 | import "../interfaces/IDexRouter.sol";
>> 3587 | /// @title Base contract with common permit handling logics
   3588 | abstract contract CommonUtils is IDexRouter {
   3589 |     address internal constant _ETH = 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;
   3590 | 
   3591 |     uint256 internal constant _ADDRESS_MASK =
   3592 |         0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
```

---

### 63. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3682 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3677 | 
   3678 | // SPDX-License-Identifier: MIT
   3679 | pragma solidity ^0.8.0;
   3680 | 
   3681 | /// @title Callback for IUniswapV3PoolActions#swap
>> 3682 | /// @notice Any contract that calls IUniswapV3PoolActions#swap must implement this interface
   3683 | interface IUniswapV3SwapCallback {
   3684 |     /// @notice Called to `msg.sender` after executing a swap via IUniswapV3Pool#swap.
   3685 |     /// @dev In the implementation you must pay the pool tokens owed for the swap.
   3686 |     /// The caller of this method must be checked to be a UniswapV3Pool deployed by the canonical UniswapV3Factory.
   3687 |     /// amount0Delta and amount1Delta can both be 0 if no tokens were swapped.
```

---

### 64. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 4981 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4976 | // ── contracts/8/interfaces/AbstractCommissionLib.sol ──────────────────────────────
   4977 | 
   4978 | // SPDX-License-Identifier: MIT
   4979 | pragma solidity ^0.8.0;
   4980 | 
>> 4981 | /// @title Abstract base contract with virtual functions
   4982 | abstract contract AbstractCommissionLib {
   4983 |     struct CommissionInfo {
   4984 |         bool isFromTokenCommission; //0x00
   4985 |         bool isToTokenCommission; //0x20
   4986 |         address token; // 0x40
```

---

### 65. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5075 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5070 |     error ForceApproveFailed();
   5071 |     error SafeIncreaseAllowanceFailed();
   5072 |     error SafeDecreaseAllowanceFailed();
   5073 |     error SafePermitBadLength();
   5074 | 
>> 5075 |     // Ensures method do not revert or return boolean `true`, admits call to non-smart-contract
   5076 |     function safeTransferFrom(IERC20 token, address from, address to, uint256 amount) internal {
   5077 |         bytes4 selector = token.transferFrom.selector;
   5078 |         bool success;
   5079 |         /// @solidity memory-safe-assembly
   5080 |         assembly { // solhint-disable-line no-inline-assembly
```

---

### 66. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 42 行
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     39 |     /// @notice Ensures a function is called before a specified deadline.
     40 |     /// @param deadLine The UNIX timestamp deadline.
     41 |     modifier isExpired(uint256 deadLine) {
>>   42 |         require(deadLine >= block.timestamp, "Route: expired");
     43 |         _;
     44 |     }
     45 | 
```

---

### 67. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3208 行
- **函数**: `_transferTokenToUser()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   3205 |                 address(this)
   3206 |             );
   3207 |             if (wethBal > 0) {
>> 3208 |                 IWETH(address(uint160(_WETH))).transfer(
   3209 |                     _WNATIVE_RELAY,
   3210 |                     wethBal
   3211 |                 );
```

---

### 68. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3527 行
- **函数**: `universalTransfer()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   3524 |     ) internal {
   3525 |         if (amount > 0) {
   3526 |             if (isETH(token)) {
>> 3527 |                 to.transfer(amount);
   3528 |             } else {
   3529 |                 token.safeTransfer(to, amount);
   3530 |             }
```

---

### 69. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 999 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    996 | 
    997 | contract UnxswapRouter is CommonUtils {
    998 |     uint256 private constant _IS_TOKEN0_TAX =
>>  999 |         0x1000000000000000000000000000000000000000000000000000000000000000;
   1000 |     uint256 private constant _IS_TOKEN1_TAX =
   1001 |         0x2000000000000000000000000000000000000000000000000000000000000000;
   1002 |     uint256 private constant _CLAIM_TOKENS_CALL_SELECTOR_32 =
```

---

### 70. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1001 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    998 |     uint256 private constant _IS_TOKEN0_TAX =
    999 |         0x1000000000000000000000000000000000000000000000000000000000000000;
   1000 |     uint256 private constant _IS_TOKEN1_TAX =
>> 1001 |         0x2000000000000000000000000000000000000000000000000000000000000000;
   1002 |     uint256 private constant _CLAIM_TOKENS_CALL_SELECTOR_32 =
   1003 |         0x0a5ea46600000000000000000000000000000000000000000000000000000000;
   1004 |     uint256 private constant _TRANSFER_DEPOSIT_SELECTOR =
```

---

### 71. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1003 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1000 |     uint256 private constant _IS_TOKEN1_TAX =
   1001 |         0x2000000000000000000000000000000000000000000000000000000000000000;
   1002 |     uint256 private constant _CLAIM_TOKENS_CALL_SELECTOR_32 =
>> 1003 |         0x0a5ea46600000000000000000000000000000000000000000000000000000000;
   1004 |     uint256 private constant _TRANSFER_DEPOSIT_SELECTOR =
   1005 |         0xa9059cbbd0e30db0000000000000000000000000000000000000000000000000;
   1006 |     uint256 private constant _SWAP_GETRESERVES_SELECTOR =
```

---

### 72. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1005 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1002 |     uint256 private constant _CLAIM_TOKENS_CALL_SELECTOR_32 =
   1003 |         0x0a5ea46600000000000000000000000000000000000000000000000000000000;
   1004 |     uint256 private constant _TRANSFER_DEPOSIT_SELECTOR =
>> 1005 |         0xa9059cbbd0e30db0000000000000000000000000000000000000000000000000;
   1006 |     uint256 private constant _SWAP_GETRESERVES_SELECTOR =
   1007 |         0x022c0d9f0902f1ac000000000000000000000000000000000000000000000000;
   1008 |     uint256 private constant _WITHDRAW_TRNASFER_SELECTOR =
```

---

### 73. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1007 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1004 |     uint256 private constant _TRANSFER_DEPOSIT_SELECTOR =
   1005 |         0xa9059cbbd0e30db0000000000000000000000000000000000000000000000000;
   1006 |     uint256 private constant _SWAP_GETRESERVES_SELECTOR =
>> 1007 |         0x022c0d9f0902f1ac000000000000000000000000000000000000000000000000;
   1008 |     uint256 private constant _WITHDRAW_TRNASFER_SELECTOR =
   1009 |         0x2e1a7d4da9059cbb000000000000000000000000000000000000000000000000;
   1010 |     uint256 private constant _BALANCEOF_TOKEN0_SELECTOR =
```

---

### 74. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1009 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1006 |     uint256 private constant _SWAP_GETRESERVES_SELECTOR =
   1007 |         0x022c0d9f0902f1ac000000000000000000000000000000000000000000000000;
   1008 |     uint256 private constant _WITHDRAW_TRNASFER_SELECTOR =
>> 1009 |         0x2e1a7d4da9059cbb000000000000000000000000000000000000000000000000;
   1010 |     uint256 private constant _BALANCEOF_TOKEN0_SELECTOR =
   1011 |         0x70a082310dfe1681000000000000000000000000000000000000000000000000;
   1012 |     uint256 private constant _BALANCEOF_TOKEN1_SELECTOR =
```

---

### 75. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1011 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1008 |     uint256 private constant _WITHDRAW_TRNASFER_SELECTOR =
   1009 |         0x2e1a7d4da9059cbb000000000000000000000000000000000000000000000000;
   1010 |     uint256 private constant _BALANCEOF_TOKEN0_SELECTOR =
>> 1011 |         0x70a082310dfe1681000000000000000000000000000000000000000000000000;
   1012 |     uint256 private constant _BALANCEOF_TOKEN1_SELECTOR =
   1013 |         0x70a08231d21220a7000000000000000000000000000000000000000000000000;
   1014 | 
```

---

### 76. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1013 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1010 |     uint256 private constant _BALANCEOF_TOKEN0_SELECTOR =
   1011 |         0x70a082310dfe1681000000000000000000000000000000000000000000000000;
   1012 |     uint256 private constant _BALANCEOF_TOKEN1_SELECTOR =
>> 1013 |         0x70a08231d21220a7000000000000000000000000000000000000000000000000;
   1014 | 
   1015 |     uint256 private constant _NUMERATOR_MASK =
   1016 |         0x0000000000000000ffffffff0000000000000000000000000000000000000000;
```

---

### 77. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1016 行
- **函数**: `dagSwapTo()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1013 |         0x70a08231d21220a7000000000000000000000000000000000000000000000000;
   1014 | 
   1015 |     uint256 private constant _NUMERATOR_MASK =
>> 1016 |         0x0000000000000000ffffffff0000000000000000000000000000000000000000;
   1017 | 
   1018 |     uint256 private constant _DENOMINATOR = 1_000_000_000;
   1019 |     uint256 private constant _NUMERATOR_OFFSET = 160;
```

---

### 78. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1048 行
- **函数**: `revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1045 |             function revertWithReason(m, len) {
   1046 |                 mstore(
   1047 |                     0,
>> 1048 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
   1049 |                 )
   1050 |                 mstore(
   1051 |                     0x20,
```

---

### 79. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1052 行
- **函数**: `revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1049 |                 )
   1050 |                 mstore(
   1051 |                     0x20,
>> 1052 |                     0x0000002000000000000000000000000000000000000000000000000000000000
   1053 |                 )
   1054 |                 mstore(0x40, m)
   1055 |                 revert(0, len)
```

---

### 80. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1070 行
- **函数**: `_getTokenAddr()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1067 |                     )
   1068 |                 ) {
   1069 |                     revertWithReason(
>> 1070 |                         0x0000001067657420746f6b656e206661696c6564000000000000000000000000,
   1071 |                         0x54
   1072 |                     ) // "get token failed"
   1073 |                 }
```

---

### 81. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1089 行
- **函数**: `_getBalanceOfToken0()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1086 |                     )
   1087 |                 ) {
   1088 |                     revertWithReason(
>> 1089 |                         0x00000012746f6b656e302063616c6c206661696c656400000000000000000000,
   1090 |                         0x56
   1091 |                     ) // "token0 call failed"
   1092 |                 }
```

---

### 82. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1099 行
- **函数**: `_getBalanceOfToken0()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1096 |                     staticcall(gas(), token0, emptyPtr, 0x24, 0x00, 0x20)
   1097 |                 ) {
   1098 |                     revertWithReason(
>> 1099 |                         0x0000001562616c616e63654f662063616c6c206661696c656400000000000000,
   1100 |                         0x59
   1101 |                     ) // "balanceOf call failed"
   1102 |                 }
```

---

### 83. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1118 行
- **函数**: `_getBalanceOfToken1()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1115 |                     )
   1116 |                 ) {
   1117 |                     revertWithReason(
>> 1118 |                         0x00000012746f6b656e312063616c6c206661696c656400000000000000000000,
   1119 |                         0x56
   1120 |                     ) // "token1 call failed"
   1121 |                 }
```

---

### 84. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1128 行
- **函数**: `_getBalanceOfToken1()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1125 |                     staticcall(gas(), token1, emptyPtr, 0x24, 0x00, 0x20)
   1126 |                 ) {
   1127 |                     revertWithReason(
>> 1128 |                         0x0000001562616c616e63654f662063616c6c206661696c656400000000000000,
   1129 |                         0x59
   1130 |                     ) // "balanceOf call failed"
   1131 |                 }
```

---

### 85. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1158 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1155 |                 ) {
   1156 |                     // we only need the first 0x40 bytes, no need timestamp info
   1157 |                     revertWithReason(
>> 1158 |                         0x0000001472657365727665732063616c6c206661696c65640000000000000000,
   1159 |                         0x58
   1160 |                     ) // "reserves call failed"
   1161 |                 }
```

---

### 86. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1210 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1207 |                 mstore(add(emptyPtr, 0x84), 0)
   1208 |                 if iszero(call(gas(), pair, 0, emptyPtr, 0xa4, 0, 0)) {
   1209 |                     revertWithReason(
>> 1210 |                         0x00000010737761702063616c6c206661696c6564000000000000000000000000,
   1211 |                         0x54
   1212 |                     ) // "swap call failed"
   1213 |                 }
```

---

### 87. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1225 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1222 | 
   1223 |                 if eq(len, 0) {
   1224 |                     revertWithReason(
>> 1225 |                         0x000000b656d70747920706f6f6c73000000000000000000000000000000000000,
   1226 |                         0x4e
   1227 |                     ) // "empty pools"
   1228 |                 }
```

---

### 88. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1237 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1234 |                 // require callvalue() >= amount, lt: if x < y return 1，else return 0
   1235 |                 if eq(lt(callvalue(), amount), 1) {
   1236 |                     revertWithReason(
>> 1237 |                         0x00000011696e76616c6964206d73672e76616c75650000000000000000000000,
   1238 |                         0x55
   1239 |                     ) // "invalid msg.value"
   1240 |                 }
```

---

### 89. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1247 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1244 |                     call(gas(), _WETH, amount, add(emptyPtr, 0x04), 0x4, 0, 0)
   1245 |                 ) {
   1246 |                     revertWithReason(
>> 1247 |                         0x000000126465706f73697420455448206661696c656400000000000000000000,
   1248 |                         0x56
   1249 |                     ) // "deposit ETH failed"
   1250 |                 }
```

---

### 90. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1255 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1252 |                 mstore(add(0x24, emptyPtr), amount)
   1253 |                 if iszero(call(gas(), _WETH, 0, emptyPtr, 0x44, 0, 0x20)) {
   1254 |                     revertWithReason(
>> 1255 |                         0x000000147472616e736665722057455448206661696c65640000000000000000,
   1256 |                         0x58
   1257 |                     ) // "transfer WETH failed"
   1258 |                 }
```

---

### 91. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1263 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1260 |             default {
   1261 |                 if callvalue() {
   1262 |                     revertWithReason(
>> 1263 |                         0x00000011696e76616c6964206d73672e76616c75650000000000000000000000,
   1264 |                         0x55
   1265 |                     ) // "invalid msg.value"
   1266 |                 }
```

---

### 92. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1277 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1274 |                     call(gas(), _APPROVE_PROXY, 0, emptyPtr, 0x84, 0, 0)
   1275 |                 ) {
   1276 |                     revertWithReason(
>> 1277 |                         0x00000012636c61696d20746f6b656e206661696c656400000000000000000000,
   1278 |                         0x56
   1279 |                     ) // "claim token failed"
   1280 |                 }
```

---

### 93. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1324 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1321 |                             )
   1322 |                         ) {
   1323 |                             revertWithReason(
>> 1324 |                                 0x00000012746f6b656e312063616c6c206661696c656400000000000000000000,
   1325 |                                 0x56
   1326 |                             ) // "token1 call failed"
   1327 |                         }
```

---

### 94. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1341 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1338 |                             )
   1339 |                         ) {
   1340 |                             revertWithReason(
>> 1341 |                                 0x00000015746f6b656e312062616c616e6365206661696c656400000000000000,
   1342 |                                 0x59
   1343 |                             ) // "token1 balance failed"
   1344 |                         }
```

---

### 95. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1362 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1359 |                             )
   1360 |                         ) {
   1361 |                             revertWithReason(
>> 1362 |                                 0x00000012746f6b656e302063616c6c206661696c656400000000000000000000,
   1363 |                                 0x56
   1364 |                             ) // "token0 call failed"
   1365 |                         }
```

---

### 96. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1379 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1376 |                             )
   1377 |                         ) {
   1378 |                             revertWithReason(
>> 1379 |                                 0x00000015746f6b656e302062616c616e6365206661696c656400000000000000,
   1380 |                                 0x56
   1381 |                             ) // "token0 balance failed"
   1382 |                         }
```

---

### 97. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1404 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1401 |                         staticcall(gas(), toToken, emptyPtr, 0x24, 0x00, 0x20)
   1402 |                     ) {
   1403 |                         revertWithReason(
>> 1404 |                             0x000000146765742062616c616e63654f66206661696c65640000000000000000,
   1405 |                             0x58
   1406 |                         ) // "get balanceOf failed"
   1407 |                     }
```

---

### 98. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1451 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1448 |                     call(gas(), _WETH, 0, add(0x04, emptyPtr), 0x44, 0, 0x20)
   1449 |                 ) {
   1450 |                     revertWithReason(
>> 1451 |                         0x000000147472616e736665722057455448206661696c65640000000000000000,
   1452 |                         0x58
   1453 |                     ) // "transfer WETH failed"
   1454 |                 }
```

---

### 99. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1460 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1457 |                     call(gas(), _WNATIVE_RELAY, 0, emptyPtr, 0x24, 0, 0x20)
   1458 |                 ) {
   1459 |                     revertWithReason(
>> 1460 |                         0x00000013776974686472617720455448206661696c6564000000000000000000,
   1461 |                         0x57
   1462 |                     ) // "withdraw ETH failed"
   1463 |                 }
```

---

### 100. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1466 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1463 |                 }
   1464 |                 if iszero(call(gas(), receiver, returnAmount, 0, 0, 0, 0)) {
   1465 |                     revertWithReason(
>> 1466 |                         0x000000137472616e7366657220455448206661696c6564000000000000000000,
   1467 |                         0x57
   1468 |                     ) // "transfer ETH failed"
   1469 |                 }
```

---

### 101. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1495 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1492 |     using Address for address payable;
   1493 | 
   1494 |     bytes32 private constant _POOL_INIT_CODE_HASH =
>> 1495 |         0xe34f199b19b2b4f47f68442619d555527d244f78a3297ea89325f843f87b8b54; // Pool init code hash
   1496 |     bytes32 private constant _FF_FACTORY = 0xffdB1d10011AD0Ff90774D0C6Bb92e5C5c8b4461F70000000000000000000000; // Factory address
   1497 |     // concatenation of token0(), token1() fee(), transfer() and claimTokens() selectors
   1498 |     bytes32 private constant _SELECTORS =
```

---

### 102. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1496 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1493 | 
   1494 |     bytes32 private constant _POOL_INIT_CODE_HASH =
   1495 |         0xe34f199b19b2b4f47f68442619d555527d244f78a3297ea89325f843f87b8b54; // Pool init code hash
>> 1496 |     bytes32 private constant _FF_FACTORY = 0xffdB1d10011AD0Ff90774D0C6Bb92e5C5c8b4461F70000000000000000000000; // Factory address
   1497 |     // concatenation of token0(), token1() fee(), transfer() and claimTokens() selectors
   1498 |     bytes32 private constant _SELECTORS =
   1499 |         0x0dfe1681d21220a7ddca3f43a9059cbb0a5ea466000000000000000000000000;
```

---

### 103. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1499 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1496 |     bytes32 private constant _FF_FACTORY = 0xffdB1d10011AD0Ff90774D0C6Bb92e5C5c8b4461F70000000000000000000000; // Factory address
   1497 |     // concatenation of token0(), token1() fee(), transfer() and claimTokens() selectors
   1498 |     bytes32 private constant _SELECTORS =
>> 1499 |         0x0dfe1681d21220a7ddca3f43a9059cbb0a5ea466000000000000000000000000;
   1500 |     // concatenation of withdraw(uint),transfer()
   1501 |     bytes32 private constant _SELECTORS2 =
   1502 |         0x2e1a7d4da9059cbb000000000000000000000000000000000000000000000000;
```

---

### 104. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1502 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1499 |         0x0dfe1681d21220a7ddca3f43a9059cbb0a5ea466000000000000000000000000;
   1500 |     // concatenation of withdraw(uint),transfer()
   1501 |     bytes32 private constant _SELECTORS2 =
>> 1502 |         0x2e1a7d4da9059cbb000000000000000000000000000000000000000000000000;
   1503 |     bytes32 private constant _SELECTORS3 =
   1504 |         0xa9059cbb70a08231000000000000000000000000000000000000000000000000;
   1505 |     uint160 private constant _MIN_SQRT_RATIO = 4_295_128_739 + 1;
```

---

### 105. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1504 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1501 |     bytes32 private constant _SELECTORS2 =
   1502 |         0x2e1a7d4da9059cbb000000000000000000000000000000000000000000000000;
   1503 |     bytes32 private constant _SELECTORS3 =
>> 1504 |         0xa9059cbb70a08231000000000000000000000000000000000000000000000000;
   1505 |     uint160 private constant _MIN_SQRT_RATIO = 4_295_128_739 + 1;
   1506 |     uint160 private constant _MAX_SQRT_RATIO =
   1507 |         1_461_446_703_485_210_103_287_273_052_203_988_822_378_723_970_342 - 1;
```

---

### 106. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1509 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1506 |     uint160 private constant _MAX_SQRT_RATIO =
   1507 |         1_461_446_703_485_210_103_287_273_052_203_988_822_378_723_970_342 - 1;
   1508 |     bytes32 private constant _SWAP_SELECTOR =
>> 1509 |         0x128acb0800000000000000000000000000000000000000000000000000000000; // Swap function selector
   1510 |     uint256 private constant _INT256_MAX =
   1511 |         0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff; // Maximum int256
   1512 |     uint256 private constant _INT256_MIN =
```

---

### 107. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1511 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1508 |     bytes32 private constant _SWAP_SELECTOR =
   1509 |         0x128acb0800000000000000000000000000000000000000000000000000000000; // Swap function selector
   1510 |     uint256 private constant _INT256_MAX =
>> 1511 |         0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff; // Maximum int256
   1512 |     uint256 private constant _INT256_MIN =
   1513 |         0x8000000000000000000000000000000000000000000000000000000000000000; // Minimum int256
   1514 | 
```

---

### 108. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1513 行
- **函数**: `swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1510 |     uint256 private constant _INT256_MAX =
   1511 |         0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff; // Maximum int256
   1512 |     uint256 private constant _INT256_MIN =
>> 1513 |         0x8000000000000000000000000000000000000000000000000000000000000000; // Minimum int256
   1514 | 
   1515 |     /// @notice Conducts a swap using the Uniswap V3 protocol internally within the contract.
   1516 |     /// @param payer The address of the account providing the tokens for the swap.
```

---

### 109. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1534 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1531 |             function _revertWithReason(m, len) {
   1532 |                 mstore(
   1533 |                     0,
>> 1534 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
   1535 |                 )
   1536 |                 mstore(
   1537 |                     0x20,
```

---

### 110. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1538 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1535 |                 )
   1536 |                 mstore(
   1537 |                     0x20,
>> 1538 |                     0x0000002000000000000000000000000000000000000000000000000000000000
   1539 |                 )
   1540 |                 mstore(0x40, m)
   1541 |                 revert(0, len)
```

---

### 111. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1549 行
- **函数**: `_makeSwap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1546 |                 if lt(_INT256_MAX, _amount) {
   1547 |                     mstore(
   1548 |                         0,
>> 1549 |                         0xb3f79fd000000000000000000000000000000000000000000000000000000000
   1550 |                     ) //SafeCastToInt256Failed()
   1551 |                     revert(0, 4)
   1552 |                 }
```

---

### 112. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1612 行
- **函数**: `_makeSwap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1609 |                 if lt(_returnAmount, _INT256_MIN) {
   1610 |                     mstore(
   1611 |                         0,
>> 1612 |                         0x88c8ee9c00000000000000000000000000000000000000000000000000000000
   1613 |                     ) //SafeCastToUint256Failed()
   1614 |                     revert(0, 4)
   1615 |                 }
```

---

### 113. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1623 行
- **函数**: `_wrapWeth()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1620 |                 if eq(lt(callvalue(), _amount), 1) {
   1621 |                     mstore(
   1622 |                         0,
>> 1623 |                         0x1841b4e100000000000000000000000000000000000000000000000000000000
   1624 |                     ) // InvalidMsgValue()
   1625 |                     revert(0, 4)
   1626 |                 }
```

---

### 114. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1631 行
- **函数**: `_wrapWeth()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1628 |                 let success := call(gas(), _WETH, _amount, 0, 0, 0, 0) //进入fallback逻辑
   1629 |                 if iszero(success) {
   1630 |                     _revertWithReason(
>> 1631 |                         0x0000001357455448206465706f736974206661696c6564000000000000000000,
   1632 |                         87
   1633 |                     ) //WETH deposit failed
   1634 |                 }
```

---

### 115. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1647 行
- **函数**: `_unWrapWeth()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1644 |                 let success := call(gas(), _WETH, 0, transferPtr, 68, 0, 0)
   1645 |                 if iszero(success) {
   1646 |                     _revertWithReason(
>> 1647 |                         0x000000147472616e736665722077657468206661696c65640000000000000000,
   1648 |                         88
   1649 |                     ) // transfer weth failed
   1650 |                 }
```

---

### 116. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1656 行
- **函数**: `_unWrapWeth()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1653 |                 success := call(gas(), _WNATIVE_RELAY, 0, freePtr, 36, 0, 0)
   1654 |                 if iszero(success) {
   1655 |                     _revertWithReason(
>> 1656 |                         0x0000001477697468647261772077657468206661696c65640000000000000000,
   1657 |                         88
   1658 |                     ) // withdraw weth failed
   1659 |                 }
```

---

### 117. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1664 行
- **函数**: `_unWrapWeth()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1661 |                 success := call(gas(), _receiver, _amount, 0, 0, 0, 0)
   1662 |                 if iszero(success) {
   1663 |                     _revertWithReason(
>> 1664 |                         0x0000001173656e64206574686572206661696c65640000000000000000000000,
   1665 |                         85
   1666 |                     ) // send ether failed
   1667 |                 }
```

---

### 118. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1675 行
- **函数**: `_token0()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1672 |                 let success := staticcall(gas(), _pool, freePtr, 0x4, 0, 0)
   1673 |                 if iszero(success) {
   1674 |                     _revertWithReason(
>> 1675 |                         0x0000001167657420746f6b656e30206661696c65640000000000000000000000,
   1676 |                         85
   1677 |                     ) // get token0 failed
   1678 |                 }
```

---

### 119. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1695 行
- **函数**: `_token1()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1692 |                 )
   1693 |                 if iszero(success) {
   1694 |                     _revertWithReason(
>> 1695 |                         0x0000001167657420746f6b656e31206661696c65640000000000000000000000,
   1696 |                         84
   1697 |                     ) // get token1 failed
   1698 |                 }
```

---

### 120. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1714 行
- **函数**: `_token1()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1711 |                 if eq(len, 0) {
   1712 |                     mstore(
   1713 |                         0,
>> 1714 |                         0x67e7c0f600000000000000000000000000000000000000000000000000000000
   1715 |                     ) // EmptyPools()
   1716 |                     revert(0, 4)
   1717 |                 }
```

---

### 121. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1817 行
- **函数**: `validateERC20Transfer()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1814 |                 if iszero(success) {
   1815 |                     mstore(
   1816 |                         0,
>> 1817 |                         0xf27f64e400000000000000000000000000000000000000000000000000000000
   1818 |                     ) // ERC20TransferFailed()
   1819 |                     revert(0, 4)
   1820 |                 }
```

---

### 122. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1864 行
- **函数**: `validateERC20Transfer()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1861 |                 // if xor(pool, caller()) {
   1862 |                 mstore(
   1863 |                     0,
>> 1864 |                     0xb2c0272200000000000000000000000000000000000000000000000000000000
   1865 |                 ) // BadPool()
   1866 |                 revert(0, 4)
   1867 |             }
```

---

### 123. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2035 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2032 | 
   2033 | abstract contract CommissionLib is AbstractCommissionLib, CommonUtils {
   2034 |     uint256 internal constant _COMMISSION_RATE_MASK =
>> 2035 |         0x000000000000ffffffffffff0000000000000000000000000000000000000000;
   2036 |     uint256 internal constant _COMMISSION_FLAG_MASK =
   2037 |         0xffffffffffff0000000000000000000000000000000000000000000000000000;
   2038 |     uint256 internal constant FROM_TOKEN_COMMISSION =
```

---

### 124. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2037 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2034 |     uint256 internal constant _COMMISSION_RATE_MASK =
   2035 |         0x000000000000ffffffffffff0000000000000000000000000000000000000000;
   2036 |     uint256 internal constant _COMMISSION_FLAG_MASK =
>> 2037 |         0xffffffffffff0000000000000000000000000000000000000000000000000000;
   2038 |     uint256 internal constant FROM_TOKEN_COMMISSION =
   2039 |         0x3ca20afc2aaa0000000000000000000000000000000000000000000000000000;
   2040 |     uint256 internal constant TO_TOKEN_COMMISSION =
```

---

### 125. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2039 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2036 |     uint256 internal constant _COMMISSION_FLAG_MASK =
   2037 |         0xffffffffffff0000000000000000000000000000000000000000000000000000;
   2038 |     uint256 internal constant FROM_TOKEN_COMMISSION =
>> 2039 |         0x3ca20afc2aaa0000000000000000000000000000000000000000000000000000;
   2040 |     uint256 internal constant TO_TOKEN_COMMISSION =
   2041 |         0x3ca20afc2bbb0000000000000000000000000000000000000000000000000000;
   2042 |     uint256 internal constant FROM_TOKEN_COMMISSION_DUAL =
```

---

### 126. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2041 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2038 |     uint256 internal constant FROM_TOKEN_COMMISSION =
   2039 |         0x3ca20afc2aaa0000000000000000000000000000000000000000000000000000;
   2040 |     uint256 internal constant TO_TOKEN_COMMISSION =
>> 2041 |         0x3ca20afc2bbb0000000000000000000000000000000000000000000000000000;
   2042 |     uint256 internal constant FROM_TOKEN_COMMISSION_DUAL =
   2043 |         0x22220afc2aaa0000000000000000000000000000000000000000000000000000;
   2044 |     uint256 internal constant TO_TOKEN_COMMISSION_DUAL =
```

---

### 127. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2043 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2040 |     uint256 internal constant TO_TOKEN_COMMISSION =
   2041 |         0x3ca20afc2bbb0000000000000000000000000000000000000000000000000000;
   2042 |     uint256 internal constant FROM_TOKEN_COMMISSION_DUAL =
>> 2043 |         0x22220afc2aaa0000000000000000000000000000000000000000000000000000;
   2044 |     uint256 internal constant TO_TOKEN_COMMISSION_DUAL =
   2045 |         0x22220afc2bbb0000000000000000000000000000000000000000000000000000;
   2046 |     uint256 internal constant FROM_TOKEN_COMMISSION_MULTIPLE =
```

---

### 128. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2045 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2042 |     uint256 internal constant FROM_TOKEN_COMMISSION_DUAL =
   2043 |         0x22220afc2aaa0000000000000000000000000000000000000000000000000000;
   2044 |     uint256 internal constant TO_TOKEN_COMMISSION_DUAL =
>> 2045 |         0x22220afc2bbb0000000000000000000000000000000000000000000000000000;
   2046 |     uint256 internal constant FROM_TOKEN_COMMISSION_MULTIPLE =
   2047 |         0x88880afc2aaa0000000000000000000000000000000000000000000000000000;
   2048 |     uint256 internal constant TO_TOKEN_COMMISSION_MULTIPLE =
```

---

### 129. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2047 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2044 |     uint256 internal constant TO_TOKEN_COMMISSION_DUAL =
   2045 |         0x22220afc2bbb0000000000000000000000000000000000000000000000000000;
   2046 |     uint256 internal constant FROM_TOKEN_COMMISSION_MULTIPLE =
>> 2047 |         0x88880afc2aaa0000000000000000000000000000000000000000000000000000;
   2048 |     uint256 internal constant TO_TOKEN_COMMISSION_MULTIPLE =
   2049 |         0x88880afc2bbb0000000000000000000000000000000000000000000000000000;
   2050 |     uint256 internal constant _COMMISSION_LENGTH_MASK =
```

---

### 130. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2049 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2046 |     uint256 internal constant FROM_TOKEN_COMMISSION_MULTIPLE =
   2047 |         0x88880afc2aaa0000000000000000000000000000000000000000000000000000;
   2048 |     uint256 internal constant TO_TOKEN_COMMISSION_MULTIPLE =
>> 2049 |         0x88880afc2bbb0000000000000000000000000000000000000000000000000000;
   2050 |     uint256 internal constant _COMMISSION_LENGTH_MASK =
   2051 |         0x00ff000000000000000000000000000000000000000000000000000000000000;
   2052 |     uint256 internal constant _TO_B_COMMISSION_MASK =
```

---

### 131. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2051 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2048 |     uint256 internal constant TO_TOKEN_COMMISSION_MULTIPLE =
   2049 |         0x88880afc2bbb0000000000000000000000000000000000000000000000000000;
   2050 |     uint256 internal constant _COMMISSION_LENGTH_MASK =
>> 2051 |         0x00ff000000000000000000000000000000000000000000000000000000000000;
   2052 |     uint256 internal constant _TO_B_COMMISSION_MASK =
   2053 |         0x8000000000000000000000000000000000000000000000000000000000000000;
   2054 | 
```

---

### 132. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2053 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2050 |     uint256 internal constant _COMMISSION_LENGTH_MASK =
   2051 |         0x00ff000000000000000000000000000000000000000000000000000000000000;
   2052 |     uint256 internal constant _TO_B_COMMISSION_MASK =
>> 2053 |         0x8000000000000000000000000000000000000000000000000000000000000000;
   2054 | 
   2055 | 
   2056 |     uint256 internal constant _TRIM_FLAG_MASK =
```

---

### 133. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2057 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2054 | 
   2055 | 
   2056 |     uint256 internal constant _TRIM_FLAG_MASK =
>> 2057 |         0xffffffffffff0000000000000000000000000000000000000000000000000000;
   2058 |     uint256 internal constant _TRIM_EXPECT_AMOUNT_OUT_OR_ADDRESS_MASK =
   2059 |         0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
   2060 |     uint256 internal constant _TRIM_RATE_MASK =
```

---

### 134. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2059 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2056 |     uint256 internal constant _TRIM_FLAG_MASK =
   2057 |         0xffffffffffff0000000000000000000000000000000000000000000000000000;
   2058 |     uint256 internal constant _TRIM_EXPECT_AMOUNT_OUT_OR_ADDRESS_MASK =
>> 2059 |         0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
   2060 |     uint256 internal constant _TRIM_RATE_MASK =
   2061 |         0x000000000000ffffffffffff0000000000000000000000000000000000000000;
   2062 |     uint256 internal constant _TO_B_TRIM_MASK =
```

---

### 135. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2061 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2058 |     uint256 internal constant _TRIM_EXPECT_AMOUNT_OUT_OR_ADDRESS_MASK =
   2059 |         0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
   2060 |     uint256 internal constant _TRIM_RATE_MASK =
>> 2061 |         0x000000000000ffffffffffff0000000000000000000000000000000000000000;
   2062 |     uint256 internal constant _TO_B_TRIM_MASK =
   2063 |         0x0000000000008000000000000000000000000000000000000000000000000000;
   2064 |     uint256 internal constant TRIM_FLAG =
```

---

### 136. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2063 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2060 |     uint256 internal constant _TRIM_RATE_MASK =
   2061 |         0x000000000000ffffffffffff0000000000000000000000000000000000000000;
   2062 |     uint256 internal constant _TO_B_TRIM_MASK =
>> 2063 |         0x0000000000008000000000000000000000000000000000000000000000000000;
   2064 |     uint256 internal constant TRIM_FLAG =
   2065 |         0x7777777711110000000000000000000000000000000000000000000000000000;
   2066 |     uint256 internal constant TRIM_DUAL_FLAG =
```

---

### 137. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2065 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2062 |     uint256 internal constant _TO_B_TRIM_MASK =
   2063 |         0x0000000000008000000000000000000000000000000000000000000000000000;
   2064 |     uint256 internal constant TRIM_FLAG =
>> 2065 |         0x7777777711110000000000000000000000000000000000000000000000000000;
   2066 |     uint256 internal constant TRIM_DUAL_FLAG =
   2067 |         0x7777777722220000000000000000000000000000000000000000000000000000;
   2068 | 
```

---

### 138. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2067 行
- **函数**: `withdraw()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2064 |     uint256 internal constant TRIM_FLAG =
   2065 |         0x7777777711110000000000000000000000000000000000000000000000000000;
   2066 |     uint256 internal constant TRIM_DUAL_FLAG =
>> 2067 |         0x7777777722220000000000000000000000000000000000000000000000000000;
   2068 | 
   2069 |     // @notice CommissionAndTrimInfo is emitted in assembly, commentted out for contract size saving
   2070 |     // event CommissionAndTrimInfo(
```

---

### 139. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2127 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2124 |             function _revertWithReason(m, len) {
   2125 |                 mstore(
   2126 |                     0,
>> 2127 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
   2128 |                 )
   2129 |                 mstore(
   2130 |                     0x20,
```

---

### 140. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2131 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2128 |                 )
   2129 |                 mstore(
   2130 |                     0x20,
>> 2131 |                     0x0000002000000000000000000000000000000000000000000000000000000000
   2132 |                 )
   2133 |                 mstore(0x40, m)
   2134 |                 revert(0, len)
```

---

### 141. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2239 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2236 |                     // require(referrerNum >= MIN_COMMISSION_MULTIPLE_NUM && referrerNum <= MAX_COMMISSION_MULTIPLE_NUM, "invalid referrer num")
   2237 |                     if or(lt(referrerNum, MIN_COMMISSION_MULTIPLE_NUM), gt(referrerNum, MAX_COMMISSION_MULTIPLE_NUM)) {
   2238 |                         _revertWithReason(
>> 2239 |                             0x00000014696e76616c6964207265666572726572206e756d0000000000000000,
   2240 |                             0x58
   2241 |                         ) // "invalid referrer num"
   2242 |                     }
```

---

### 142. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2260 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2257 |                         let flag2 := and(commissionData, _COMMISSION_FLAG_MASK)
   2258 |                         if iszero(eq(flag, flag2)) {
   2259 |                             _revertWithReason(
>> 2260 |                                 0x00000017696e76616c696420636f6d6d697373696f6e20666c61670000000000,
   2261 |                                 0x5b
   2262 |                             ) // "invalid commission flag"
   2263 |                         }
```

---

### 143. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2310 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2307 |                 let flag2 := and(trimData, _TRIM_FLAG_MASK)
   2308 |                 if iszero(eq(flag, flag2)) {
   2309 |                     _revertWithReason(
>> 2310 |                         0x00000011696e76616c6964207472696d20666c61670000000000000000000000,
   2311 |                         0x55
   2312 |                     ) // "invalid trim flag"
   2313 |                 }
```

---

### 144. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2340 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2337 |                 let flag2 := and(trimData, _TRIM_FLAG_MASK)
   2338 |                 if iszero(eq(flag, flag2)) {
   2339 |                     _revertWithReason(
>> 2340 |                         0x00000011696e76616c6964207472696d20666c61670000000000000000000000,
   2341 |                         0x55
   2342 |                     ) // "invalid trim flag"
   2343 |                 }
```

---

### 145. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2374 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2371 |                 mstore(add(ptr, 0x20), mload(add(trimInfo, 0x60)))   // toBTrim
   2372 |                 mstore(add(ptr, 0x40), mload(add(trimInfo, 0x20)))   // trimRate
   2373 |                 mstore(add(ptr, 0x60), mload(add(trimInfo, 0xa0)))   // chargeRate
>> 2374 |                 log1(ptr, 0x80, 0x7970b0744fdb6cf0b120e5e0a5f4da3ab8cbec6d5d9ec8a4f327ccc1d8a5eb8b)
   2375 |                 mstore(0x40, add(ptr, 0x80))
   2376 |             }
   2377 |         }
```

---

### 146. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2388 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2385 |             function _revertWithReason(m, len) {
   2386 |                 mstore(
   2387 |                     0,
>> 2388 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
   2389 |                 )
   2390 |                 mstore(
   2391 |                     0x20,
```

---

### 147. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2392 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2389 |                 )
   2390 |                 mstore(
   2391 |                     0x20,
>> 2392 |                     0x0000002000000000000000000000000000000000000000000000000000000000
   2393 |                 )
   2394 |                 mstore(0x40, m)
   2395 |                 revert(0, len)
```

---

### 148. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2406 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2403 |                 mstore(0x40, add(freePtr, 0x24))
   2404 |                 mstore(
   2405 |                     freePtr,
>> 2406 |                     0x70a0823100000000000000000000000000000000000000000000000000000000
   2407 |                 ) //balanceOf
   2408 |                 mstore(add(freePtr, 0x04), user)
   2409 |                 let success := staticcall(gas(), token, freePtr, 0x24, 0, 0x20)
```

---

### 149. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2412 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2409 |                 let success := staticcall(gas(), token, freePtr, 0x24, 0, 0x20)
   2410 |                 if eq(success, 0) {
   2411 |                     _revertWithReason(
>> 2412 |                         0x000000146765742062616c616e63654f66206661696c65640000000000000000,
   2413 |                         0x58
   2414 |                     ) // "get balanceOf failed"
   2415 |                 }
```

---

### 150. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2467 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2464 |             function _revertWithReason(m, len) {
   2465 |                 mstore(
   2466 |                     0,
>> 2467 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
   2468 |                 )
   2469 |                 mstore(
   2470 |                     0x20,
```

---

### 151. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2471 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2468 |                 )
   2469 |                 mstore(
   2470 |                     0x20,
>> 2471 |                     0x0000002000000000000000000000000000000000000000000000000000000000
   2472 |                 )
   2473 |                 mstore(0x40, m)
   2474 |                 revert(0, len)
```

---

### 152. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2481 行
- **函数**: `_sendETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2478 |                     let success := call(gas(), to, amount, 0, 0, 0, 0)
   2479 |                     if eq(success, 0) {
   2480 |                         _revertWithReason(
>> 2481 |                             0x0000001b636f6d6d697373696f6e2077697468206574686572206572726f7200,
   2482 |                             0x5f
   2483 |                         ) // "commission with ether error"
   2484 |                     }
```

---

### 153. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2493 行
- **函数**: `_claimToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2490 |                     mstore(0x40, add(freePtr, 0x84))
   2491 |                     mstore(
   2492 |                         freePtr,
>> 2493 |                         0x0a5ea46600000000000000000000000000000000000000000000000000000000
   2494 |                     ) // claimTokens
   2495 |                     mstore(add(freePtr, 0x04), token)
   2496 |                     mstore(add(freePtr, 0x24), _payer)
```

---

### 154. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2510 行
- **函数**: `_claimToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2507 |                     )
   2508 |                     if eq(success, 0) {
   2509 |                         _revertWithReason(
>> 2510 |                             0x00000013636c61696d20746f6b656e73206661696c6564000000000000000000,
   2511 |                             0x57
   2512 |                         ) // "claim tokens failed"
   2513 |                     }
```

---

### 155. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2522 行
- **函数**: `_sendToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2519 |                     mstore(0x40, add(freePtr, 0x44))
   2520 |                     mstore(
   2521 |                         freePtr,
>> 2522 |                         0xa9059cbb00000000000000000000000000000000000000000000000000000000
   2523 |                     ) // transfer
   2524 |                     mstore(add(freePtr, 0x04), to)
   2525 |                     mstore(add(freePtr, 0x24), amount)
```

---

### 156. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2545 行
- **函数**: `_sendToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2542 |                     }
   2543 |                     if eq(success, 0) {
   2544 |                         _revertWithReason(
>> 2545 |                             0x0000001b7472616e7366657220746f6b656e2072656665726572206661696c00,
   2546 |                             0x5f
   2547 |                         ) // "transfer token referer fail"
   2548 |                     }
```

---

### 157. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2558 行
- **函数**: `_sendTokenWithinBalanceAndEmitEvents()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2555 |                 mstore(0x40, add(freePtr, 0x24))
   2556 |                 mstore(
   2557 |                     freePtr,
>> 2558 |                     0x70a0823100000000000000000000000000000000000000000000000000000000
   2559 |                 ) // balanceOf
   2560 |                 // get token balance of address(this)
   2561 |                 mstore(add(freePtr, 0x4), address())
```

---

### 158. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2572 行
- **函数**: `_sendTokenWithinBalanceAndEmitEvents()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2569 |                 )
   2570 |                 if eq(success, 0) {
   2571 |                     _revertWithReason(
>> 2572 |                         0x000000146765742062616c616e63654f66206661696c65640000000000000000,
   2573 |                         0x58
   2574 |                     ) // "get balanceOf failed"
   2575 |                 }
```

---

### 159. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2593 行
- **函数**: `_sendTokenWithinBalanceAndEmitEvents()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2590 |                         )
   2591 |                         if gt(amountScaled, balanceAfter) {
   2592 |                             _revertWithReason(
>> 2593 |                                 0x00000014696e76616c696420616d6f756e745363616c65640000000000000000,
   2594 |                                 0x58
   2595 |                             ) // "invalid amountScaled"
   2596 |                         }
```

---

### 160. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2614 行
- **函数**: `_emitCommissionFromToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2611 |                 log1(
   2612 |                     freePtr,
   2613 |                     0x80,
>> 2614 |                     0xcd5eae9d9d0b96532bd1b7dbf6628ce436b2af735829087a03c548439f8bf850
   2615 |                 ) //emit CommissionFromTokenRecord(address,uint256,address,uint256)
   2616 |             }
   2617 | 
```

---

### 161. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2628 行
- **函数**: `_emitCommissionFromToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2625 |             }
   2626 |             if gt(totalRate, commissionRateLimit) {
   2627 |                 _revertWithReason(
>> 2628 |                     0x000000156572726f7220636f6d6d697373696f6e207261746500000000000000,
   2629 |                     0x59
   2630 |                 ) // "error commission rate"
   2631 |             }
```

---

### 162. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2704 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2701 |             function _revertWithReason(m, len) {
   2702 |                 mstore(
   2703 |                     0,
>> 2704 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
   2705 |                 )
   2706 |                 mstore(
   2707 |                     0x20,
```

---

### 163. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2708 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2705 |                 )
   2706 |                 mstore(
   2707 |                     0x20,
>> 2708 |                     0x0000002000000000000000000000000000000000000000000000000000000000
   2709 |                 )
   2710 |                 mstore(0x40, m)
   2711 |                 revert(0, len)
```

---

### 164. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2718 行
- **函数**: `_sendETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2715 |                     let success := call(gas(), to, amount, 0, 0, 0, 0)
   2716 |                     if eq(success, 0) {
   2717 |                         _revertWithReason(
>> 2718 |                             0x0000001173656e64206574686572206661696c65640000000000000000000000,
   2719 |                             0x55
   2720 |                         ) // "send ether failed"
   2721 |                     }
```

---

### 165. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2730 行
- **函数**: `_sendToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2727 |                     mstore(0x40, add(freePtr, 0x44))
   2728 |                     mstore(
   2729 |                         freePtr,
>> 2730 |                         0xa9059cbb00000000000000000000000000000000000000000000000000000000
   2731 |                     ) // transfer
   2732 |                     mstore(add(freePtr, 0x04), to)
   2733 |                     mstore(add(freePtr, 0x24), amount)
```

---

### 166. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2753 行
- **函数**: `_sendToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2750 |                     }
   2751 |                     if eq(success, 0) {
   2752 |                         _revertWithReason(
>> 2753 |                             0x000000157472616e7366657220746f6b656e206661696c656400000000000000,
   2754 |                             0x59
   2755 |                         ) // "transfer token failed"
   2756 |                     }
```

---

### 167. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2769 行
- **函数**: `_emitCommissionToToken()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2766 |                 log1(
   2767 |                     freePtr,
   2768 |                     0x80,
>> 2769 |                     0x3cfb523a4c38d88561dd3bf04805a31715c8b5fc468a03b8d684356f360dea99
   2770 |                 ) //emit CommissionToTokenRecord(address,uint256,address,uint256)
   2771 |             }
   2772 |             function _emitPositiveSlippageTrimRecord(token, trimAmount, trimAddress) {
```

---

### 168. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2781 行
- **函数**: `_emitPositiveSlippageTrimRecord()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2778 |                 log1(
   2779 |                     freePtr,
   2780 |                     0x60,
>> 2781 |                     0x7bec7d55a62a7a7b8068f1533e2a3bbf727b3e2e57f30c576fe159da60e09a65
   2782 |                 ) // emit PositiveSlippageTrimRecord(address,uint256,address)
   2783 |             }
   2784 |             function _emitPositiveSlippageChargeRecord(token, chargeAmount, chargeAddress) {
```

---

### 169. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2793 行
- **函数**: `_emitPositiveSlippageChargeRecord()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2790 |                 log1(
   2791 |                     freePtr,
   2792 |                     0x60,
>> 2793 |                     0xfd08115c8e43d2a49d95ee18d7f69b8bbac60bd368c73cf22d30664a22a0626d
   2794 |                 ) // emit PositiveSlippageChargeRecord(address,uint256,address)
   2795 |             }
   2796 |             function _processCommission(commissionInfo_, toToken_, inputAmount) -> commissionAmount {
```

---

### 170. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2805 行
- **函数**: `_processCommission()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2802 |                 }
   2803 |                 if gt(totalRate, commissionRateLimit) {
   2804 |                     _revertWithReason(
>> 2805 |                         0x000000156572726f7220636f6d6d697373696f6e207261746500000000000000,
   2806 |                         0x59
   2807 |                     ) // "error commission rate"
   2808 |                 }
```

---

### 171. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2838 行
- **函数**: `_processTrim()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2835 |                 // require(trimInfo.trimRate <= TRIM_RATE_LIMIT, "error trim rate");
   2836 |                 if gt(trimRate, TRIM_RATE_LIMIT) {
   2837 |                     _revertWithReason(
>> 2838 |                         0x0000000f6572726f72207472696d207261746500000000000000000000000000,
   2839 |                         0x53
   2840 |                     ) // "error trim rate"
   2841 |                 }
```

---

### 172. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2845 行
- **函数**: `_processTrim()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2842 |                 // require(trimInfo.chargeRate <= TRIM_DENOMINATOR, "error charge rate");
   2843 |                 if gt(chargeRate, TRIM_DENOMINATOR) {
   2844 |                     _revertWithReason(
>> 2845 |                         0x000000116572726f722063686172676520726174650000000000000000000000,
   2846 |                         0x55
   2847 |                     ) // "error charge rate"
   2848 |                 }
```

---

### 173. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2888 行
- **函数**: `_processTrim()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2885 |             // require(balanceAfter > balanceBefore, "invalid balance after");
   2886 |             if or(gt(balanceBefore, balanceAfter), eq(balanceAfter, balanceBefore)) {
   2887 |                 _revertWithReason(
>> 2888 |                     0x00000015696e76616c69642062616c616e636520616674657200000000000000,
   2889 |                     0x59
   2890 |                 ) // "invalid balance after"
   2891 |             }
```

---

### 174. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2932 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2929 |             function _revertWithReason(m, len) {
   2930 |                 mstore(
   2931 |                     0,
>> 2932 |                     0x08c379a000000000000000000000000000000000000000000000000000000000
   2933 |                 )
   2934 |                 mstore(
   2935 |                     0x20,
```

---

### 175. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2936 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2933 |                 )
   2934 |                 mstore(
   2935 |                     0x20,
>> 2936 |                     0x0000002000000000000000000000000000000000000000000000000000000000
   2937 |                 )
   2938 |                 mstore(0x40, m)
   2939 |                 revert(0, len)
```

---

### 176. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2960 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2957 |             let isFromTokenCommission := mload(add(commissionInfo, 0x00)) // commissionInfo.isFromTokenCommission
   2958 |             if and(flag, isFromTokenCommission) {
   2959 |                 _revertWithReason(
>> 2960 |                     0x0000001b46726f6d20636f6d6d697373696f6e206e6f7420737570706f727400,
   2961 |                     0x5f
   2962 |                 ) // "From commission not support"
   2963 |             }
```

---

### 177. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2970 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2967 |             // }
   2968 |             if eq(fromToken, toToken) {
   2969 |                 _revertWithReason(
>> 2970 |                     0x0000000e496e76616c696420746f6b656e730000000000000000000000000000,
   2971 |                     0x52
   2972 |                 ) // "Invalid tokens"
   2973 |             }
```

---

### 178. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2981 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2978 |             let isToTokenCommission := mload(add(commissionInfo, 0x20)) // commissionInfo.isToTokenCommission
   2979 |             if and(isToTokenCommission, isFromTokenCommission) {
   2980 |                 _revertWithReason(
>> 2981 |                     0x0000001c496e76616c696420636f6d6d697373696f6e20646972656374696f6e,
   2982 |                     0x60
   2983 |                 ) // "Invalid commission direction"
   2984 |             }
```

---

### 179. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2998 行
- **函数**: `_revertWithReason()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2995 |             flag := or(flag, and(iszero(isFromTokenCommission), iszero(isToTokenCommission)))
   2996 |             if iszero(flag) {
   2997 |                 _revertWithReason(
>> 2998 |                     0x00000017496e76616c696420636f6d6d697373696f6e20696e666f0000000000,
   2999 |                     0x5b
   3000 |                 ) // "Invalid commission info"
   3001 |             }
```

---

### 180. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3518 行
- **函数**: `sync()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3515 |     using SafeERC20 for IERC20;
   3516 | 
   3517 |     IERC20 private constant ETH_ADDRESS =
>> 3518 |         IERC20(0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE);
   3519 | 
   3520 |     function universalTransfer(
   3521 |         IERC20 token,
```

---

### 181. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3589 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3586 | import "../interfaces/IDexRouter.sol";
   3587 | /// @title Base contract with common permit handling logics
   3588 | abstract contract CommonUtils is IDexRouter {
>> 3589 |     address internal constant _ETH = 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;
   3590 | 
   3591 |     uint256 internal constant _ADDRESS_MASK =
   3592 |         0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
```

---

### 182. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3592 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3589 |     address internal constant _ETH = 0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE;
   3590 | 
   3591 |     uint256 internal constant _ADDRESS_MASK =
>> 3592 |         0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
   3593 |     uint256 internal constant _REVERSE_MASK =
   3594 |         0x8000000000000000000000000000000000000000000000000000000000000000;
   3595 |     uint256 internal constant _ORDER_ID_MASK =
```

---

### 183. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3594 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3591 |     uint256 internal constant _ADDRESS_MASK =
   3592 |         0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
   3593 |     uint256 internal constant _REVERSE_MASK =
>> 3594 |         0x8000000000000000000000000000000000000000000000000000000000000000;
   3595 |     uint256 internal constant _ORDER_ID_MASK =
   3596 |         0xffffffffffffffffffffffff0000000000000000000000000000000000000000;
   3597 |     uint256 internal constant _WEIGHT_MASK =
```

---

### 184. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3596 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3593 |     uint256 internal constant _REVERSE_MASK =
   3594 |         0x8000000000000000000000000000000000000000000000000000000000000000;
   3595 |     uint256 internal constant _ORDER_ID_MASK =
>> 3596 |         0xffffffffffffffffffffffff0000000000000000000000000000000000000000;
   3597 |     uint256 internal constant _WEIGHT_MASK =
   3598 |         0x00000000000000000000ffff0000000000000000000000000000000000000000;
   3599 |     uint256 internal constant _CALL_GAS_LIMIT = 5000;
```

---

### 185. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3598 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3595 |     uint256 internal constant _ORDER_ID_MASK =
   3596 |         0xffffffffffffffffffffffff0000000000000000000000000000000000000000;
   3597 |     uint256 internal constant _WEIGHT_MASK =
>> 3598 |         0x00000000000000000000ffff0000000000000000000000000000000000000000;
   3599 |     uint256 internal constant _CALL_GAS_LIMIT = 5000;
   3600 |     uint256 internal constant ORIGIN_PAYER =
   3601 |         0x3ca20afc2ccc0000000000000000000000000000000000000000000000000000;
```

---

### 186. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3601 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3598 |         0x00000000000000000000ffff0000000000000000000000000000000000000000;
   3599 |     uint256 internal constant _CALL_GAS_LIMIT = 5000;
   3600 |     uint256 internal constant ORIGIN_PAYER =
>> 3601 |         0x3ca20afc2ccc0000000000000000000000000000000000000000000000000000;
   3602 |     uint256 internal constant SWAP_AMOUNT =
   3603 |         0x00000000000000000000000000000000ffffffffffffffffffffffffffffffff;
   3604 |     uint256 internal constant _WETH_MASK =
```

---

### 187. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3603 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3600 |     uint256 internal constant ORIGIN_PAYER =
   3601 |         0x3ca20afc2ccc0000000000000000000000000000000000000000000000000000;
   3602 |     uint256 internal constant SWAP_AMOUNT =
>> 3603 |         0x00000000000000000000000000000000ffffffffffffffffffffffffffffffff;
   3604 |     uint256 internal constant _WETH_MASK =
   3605 |         0x4000000000000000000000000000000000000000000000000000000000000000;
   3606 |     uint256 internal constant _ONE_FOR_ZERO_MASK = 1 << 255; // Mask for identifying if the swap is one-for-zero
```

---

### 188. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3605 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3602 |     uint256 internal constant SWAP_AMOUNT =
   3603 |         0x00000000000000000000000000000000ffffffffffffffffffffffffffffffff;
   3604 |     uint256 internal constant _WETH_MASK =
>> 3605 |         0x4000000000000000000000000000000000000000000000000000000000000000;
   3606 |     uint256 internal constant _ONE_FOR_ZERO_MASK = 1 << 255; // Mask for identifying if the swap is one-for-zero
   3607 |     uint256 internal constant _WETH_UNWRAP_MASK = 1 << 253; // Mask for identifying if WETH should be unwrapped to ETH
   3608 | 
```

---

### 189. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3614 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3611 |     uint256 internal constant _MODE_BY_INVEST = 1 << 250;
   3612 |     uint256 internal constant _MODE_PERMIT2 = 1 << 249;
   3613 |     
>> 3614 |     uint256 internal constant _TRANSFER_MODE_MASK = 0x0E00000000000000000000000000000000000000000000000000000000000000;
   3615 |     uint256 internal constant _INPUT_INDEX_MASK =
   3616 |         0x0000000000000000ff0000000000000000000000000000000000000000000000;
   3617 |     uint256 internal constant _OUTPUT_INDEX_MASK =
```

---

### 190. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3616 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3613 |     
   3614 |     uint256 internal constant _TRANSFER_MODE_MASK = 0x0E00000000000000000000000000000000000000000000000000000000000000;
   3615 |     uint256 internal constant _INPUT_INDEX_MASK =
>> 3616 |         0x0000000000000000ff0000000000000000000000000000000000000000000000;
   3617 |     uint256 internal constant _OUTPUT_INDEX_MASK =
   3618 |         0x000000000000000000ff00000000000000000000000000000000000000000000;
   3619 | 
```

---

### 191. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3618 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3615 |     uint256 internal constant _INPUT_INDEX_MASK =
   3616 |         0x0000000000000000ff0000000000000000000000000000000000000000000000;
   3617 |     uint256 internal constant _OUTPUT_INDEX_MASK =
>> 3618 |         0x000000000000000000ff00000000000000000000000000000000000000000000;
   3619 | 
   3620 |     /// @dev WETH address is network-specific and needs to be changed before deployment.
   3621 |     /// It can not be moved to immutable as immutables are not supported in assembly
```

---

### 192. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3635 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3632 |     // CRO:     5C7F8A570d578ED84E63fdFA7b1eE72dEae1AE23
   3633 |     // CFX:     14b2D3bC65e74DAE1030EAFd8ac30c533c976A9b
   3634 |     // POLYZK   4F9A0e7FD2Bf6067db6994CF12E4495Df938E6e9
>> 3635 |     address public constant _WETH = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
   3636 |     // address public constant _WETH = 0x5FbDB2315678afecb367f032d93F642f64180aa3;    // hardhat1
   3637 |     // address public constant _WETH = 0x707531c9999AaeF9232C8FEfBA31FBa4cB78d84a;    // hardhat2
   3638 | 
```

---

### 193. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3653 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3650 |     // CRO:     E9BBD6eC0c9Ca71d3DcCD1282EE9de4F811E50aF
   3651 |     // CFX:     100F3f74125C8c724C7C0eE81E4dd5626830dD9a
   3652 |     // POLYZK   1b5d39419C268b76Db06DE49e38B010fbFB5e226
>> 3653 |     address public constant _APPROVE_PROXY = 0xd99cAE3FAC551f6b6Ba7B9f19bDD316951eeEE98;
   3654 |     // address public constant _APPROVE_PROXY = 0xe7f1725E7734CE288F8367e1Bb143E90bb3F0512;    // hardhat1
   3655 |     // address public constant _APPROVE_PROXY = 0x2538a10b7fFb1B78c890c870FC152b10be121f04;    // hardhat2
   3656 | 
```

---

### 194. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3670 行
- **函数**: `isETH()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3667 |     // CRO:     40aA958dd87FC8305b97f2BA922CDdCa374bcD7f
   3668 |     // CFX:     40aA958dd87FC8305b97f2BA922CDdCa374bcD7f
   3669 |     // POLYZK   d2F0aC2012C8433F235c8e5e97F2368197DD06C7
>> 3670 |     address public constant _WNATIVE_RELAY = 0x0B5f474ad0e3f7ef629BD10dbf9e4a8Fd60d9A48;
   3671 |     // address public constant _WNATIVE_RELAY = 0x0B306BF915C4d645ff596e518fAf3F9669b97016;   // hardhat1
   3672 |     // address public constant _WNATIVE_RELAY = 0x6A47346e722937B60Df7a1149168c0E76DD6520f;   // hardhat2
   3673 | }
```

---

### 195. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3770 行
- **函数**: `isContract()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3767 |         // and 0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470 is returned
   3768 |         // for accounts without code, i.e. `keccak256('')`
   3769 |         bytes32 codehash;
>> 3770 |         bytes32 accountHash = 0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470;
   3771 |         // solhint-disable-next-line no-inline-assembly
   3772 |         assembly {
   3773 |             codehash := extcodehash(account)
```

---

### 196. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5472 行
- **函数**: `revertWith()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5469 |     function revertWith(bytes4 selector, address addr) internal pure {
   5470 |         assembly ("memory-safe") {
   5471 |             mstore(0, selector)
>> 5472 |             mstore(0x04, and(addr, 0xffffffffffffffffffffffffffffffffffffffff))
   5473 |             revert(0, 0x24)
   5474 |         }
   5475 |     }
```

---

### 197. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5490 行
- **函数**: `revertWith()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5487 |     function revertWith(bytes4 selector, uint160 value) internal pure {
   5488 |         assembly ("memory-safe") {
   5489 |             mstore(0, selector)
>> 5490 |             mstore(0x04, and(value, 0xffffffffffffffffffffffffffffffffffffffff))
   5491 |             revert(0, 0x24)
   5492 |         }
   5493 |     }
```

---

### 198. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5511 行
- **函数**: `revertWith()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5508 |         assembly ("memory-safe") {
   5509 |             let fmp := mload(0x40)
   5510 |             mstore(fmp, selector)
>> 5511 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
   5512 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   5513 |             revert(fmp, 0x44)
   5514 |         }
```

---

### 199. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5512 行
- **函数**: `revertWith()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5509 |             let fmp := mload(0x40)
   5510 |             mstore(fmp, selector)
   5511 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
>> 5512 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   5513 |             revert(fmp, 0x44)
   5514 |         }
   5515 |     }
```

---

### 200. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5522 行
- **函数**: `revertWith()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5519 |         assembly ("memory-safe") {
   5520 |             let fmp := mload(0x40)
   5521 |             mstore(fmp, selector)
>> 5522 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
   5523 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   5524 |             revert(fmp, 0x44)
   5525 |         }
```

---

### 201. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5523 行
- **函数**: `revertWith()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5520 |             let fmp := mload(0x40)
   5521 |             mstore(fmp, selector)
   5522 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
>> 5523 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   5524 |             revert(fmp, 0x44)
   5525 |         }
   5526 |     }
```

---

### 202. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5544 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5541 | 
   5542 |             // Encode wrapped error selector, address, function selector, offset, additional context, size, revert reason
   5543 |             mstore(fmp, wrappedErrorSelector)
>> 5544 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   5545 |             mstore(
   5546 |                 add(fmp, 0x24),
   5547 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
```

---

### 203. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5547 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5544 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   5545 |             mstore(
   5546 |                 add(fmp, 0x24),
>> 5547 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   5548 |             )
   5549 |             // offset revert reason
   5550 |             mstore(add(fmp, 0x44), 0x80)
```

---

### 204. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5562 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5559 |             // additional context
   5560 |             mstore(
   5561 |                 add(fmp, add(0xc4, encodedDataSize)),
>> 5562 |                 and(additionalContext, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   5563 |             )
   5564 |             revert(fmp, add(0xe4, encodedDataSize))
   5565 |         }
```

---

### 205. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 71 行
- **函数**: `_exeForks()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     68 |             bool reverse;
     69 |             {
     70 |                 uint256 weight;
>>   71 |                 assembly {
     72 |                     poolAddress := and(rawData, _ADDRESS_MASK)
     73 |                     reverse := and(rawData, _REVERSE_MASK)
     74 |                     weight := shr(160, and(rawData, _WEIGHT_MASK))
```

---

### 206. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 866 行
- **函数**: `swapWrap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    863 |     function swapWrap(uint256 orderId, uint256 rawdata) external payable {
    864 |         bool reversed;
    865 |         uint128 amount;
>>  866 |         assembly {
    867 |             reversed := and(rawdata, _REVERSE_MASK)
    868 |             amount := and(rawdata, SWAP_AMOUNT)
    869 |         }
```

---

### 207. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1042 行
- **函数**: `_unxswapInternal()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1039 |         address payer,
   1040 |         address receiver
   1041 |     ) internal returns (uint256 returnAmount) {
>> 1042 |         assembly {
   1043 |             // solhint-disable-line no-inline-assembly
   1044 | 
   1045 |             function revertWithReason(m, len) {
```

---

### 208. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1530 行
- **函数**: `_uniswapV3Swap()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1527 |         uint256 minReturn,
   1528 |         uint256[] calldata pools
   1529 |     ) internal returns (uint256 returnAmount) {
>> 1530 |         assembly {
   1531 |             function _revertWithReason(m, len) {
   1532 |                 mstore(
   1533 |                     0,
```

---

### 209. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 1781 行
- **函数**: `uniswapV3SwapCallback()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1778 |         int256 amount1Delta,
   1779 |         bytes calldata /*data*/
   1780 |     ) external override {
>> 1781 |         assembly {
   1782 |             // solhint-disable-line no-inline-assembly
   1783 |             function reRevert() {
   1784 |                 returndatacopy(0, 0, returndatasize())
```

---

### 210. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 2384 行
- **函数**: `_getBalanceOf()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2381 |         address token,
   2382 |         address user
   2383 |     ) internal returns (uint256 amount) {
>> 2384 |         assembly {
   2385 |             function _revertWithReason(m, len) {
   2386 |                 mstore(
   2387 |                     0,
```

---

### 211. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3239 行
- **函数**: `_bytes32ToAddress()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3236 |     function _bytes32ToAddress(
   3237 |         uint256 param
   3238 |     ) internal pure returns (address result) {
>> 3239 |         assembly {
   3240 |             result := and(param, _ADDRESS_MASK)
   3241 |         }
   3242 |     }
```

---

### 212. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3382 行
- **函数**: `_exeNode()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3379 |             // 1. get inputIndex, outputIndex, weight and verify
   3380 |             {
   3381 |                 bytes32 rawData = bytes32(path.rawData[i]);
>> 3382 |                 assembly {
   3383 |                     weight := shr(160, and(rawData, _WEIGHT_MASK))
   3384 |                     inputIndex := shr(184, and(rawData, _INPUT_INDEX_MASK))
   3385 |                     outputIndex := shr(176, and(rawData, _OUTPUT_INDEX_MASK))
```

---

### 213. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3449 行
- **函数**: `_exeEdge()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3446 |     ) private {
   3447 |         bool reverse;
   3448 |         address poolAddress;
>> 3449 |         assembly {
   3450 |             poolAddress := and(rawData, _ADDRESS_MASK)
   3451 |             reverse := and(rawData, _REVERSE_MASK)
   3452 |         }
```

---

### 214. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 3772 行
- **函数**: `isContract()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3769 |         bytes32 codehash;
   3770 |         bytes32 accountHash = 0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470;
   3771 |         // solhint-disable-next-line no-inline-assembly
>> 3772 |         assembly {
   3773 |             codehash := extcodehash(account)
   3774 |         }
   3775 |         return (codehash != accountHash && codehash != 0x0);
```

---

### 215. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5080 行
- **函数**: `safeTransferFrom()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   5077 |         bytes4 selector = token.transferFrom.selector;
   5078 |         bool success;
   5079 |         /// @solidity memory-safe-assembly
>> 5080 |         assembly { // solhint-disable-line no-inline-assembly
   5081 |             let data := mload(0x40)
   5082 | 
   5083 |             mstore(data, selector)
```

---

### 216. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5147 行
- **函数**: `_makeCall()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   5144 | 
   5145 |     function _makeCall(IERC20 token, bytes4 selector, address to, uint256 amount) private returns(bool success) {
   5146 |         /// @solidity memory-safe-assembly
>> 5147 |         assembly { // solhint-disable-line no-inline-assembly
   5148 |             let data := mload(0x40)
   5149 | 
   5150 |             mstore(data, selector)
```

---

### 217. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5164 行
- **函数**: `_makeCalldataCall()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   5161 | 
   5162 |     function _makeCalldataCall(IERC20 token, bytes4 selector, bytes calldata args) private returns(bool success) {
   5163 |         /// @solidity memory-safe-assembly
>> 5164 |         assembly { // solhint-disable-line no-inline-assembly
   5165 |             let len := add(4, args.length)
   5166 |             let data := mload(0x40)
   5167 | 
```

---

### 218. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62cceF0b4545166f721cAa9fEe13c1d3767E27dc` 第 5580 行
- **函数**: `reRevert()`
- **合约**: `DexRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   5577 |     function reRevert() internal pure {
   5578 |         // bubble up revert reason from latest external call
   5579 |         /// @solidity memory-safe-assembly
>> 5580 |         assembly { // solhint-disable-line no-inline-assembly
   5581 |             let ptr := mload(0x40)
   5582 |             returndatacopy(ptr, 0, returndatasize())
   5583 |             revert(ptr, returndatasize())
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*