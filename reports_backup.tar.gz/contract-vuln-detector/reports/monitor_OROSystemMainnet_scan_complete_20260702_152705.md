# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:27:05
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` |
| contract_name | `OROSystemMainnet` |
| compiler_version | `v0.8.23+commit.f704f362` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655010` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 22 |
| 🟢 LOW | 16 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 71 行
- **函数**: `functionDelegateCall()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
     68 | 
     69 |     function functionDelegateCall(address target, bytes memory data, string memory errorMessage) internal returns (bytes memory) {
     70 |         require(isContract(target), "Address: delegate call to non-contract");
>>   71 |         (bool success, bytes memory returndata) = target.delegatecall(data);
     72 |         return verifyCallResult(success, returndata, errorMessage);
     73 |     }
     74 | 
```

---

### 2. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 501 行
- **函数**: `_updateReward()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    498 |             return;
    499 |         }
    500 | 
>>  501 |         uint256 timeDiff = block.timestamp - u.lastUpdate;
    502 |         uint256 rate = getROI(u.stakeDuration);
    503 |         uint256 rewardAmount = u.stakeAmount > 0 ? u.stakeAmount : u.staked;
    504 |         uint256 reward = (rewardAmount * rate * timeDiff) / 1 days / 1000;
```

---

### 3. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 590 行
- **函数**: `getUserInfo()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    587 |         uint256 pending = u.reward;
    588 | 
    589 |         if (u.staked > 0) {
>>  590 |             uint256 timeDiff = block.timestamp - u.lastUpdate;
    591 |             uint256 rate = getROI(u.stakeDuration);
    592 |             uint256 rewardAmount = u.stakeAmount > 0 ? u.stakeAmount : u.staked;
    593 |             pending += (rewardAmount * rate * timeDiff) / 1 days / 1000;
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 32 行
- **函数**: `sendValue()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     29 | 
     30 |     function sendValue(address payable recipient, uint256 amount) internal {
     31 |         require(address(this).balance >= amount, "Address: insufficient balance");
>>   32 |         (bool success, ) = recipient.call{value: amount}("");
     33 |         require(success, "Address: unable to send value, recipient may have reverted");
     34 |     }
     35 | 
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 51 行
- **函数**: `functionCallWithValue()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     48 |     function functionCallWithValue(address target, bytes memory data, uint256 value, string memory errorMessage) internal returns (bytes memory) {
     49 |         require(address(this).balance >= value, "Address: insufficient balance for call");
     50 |         require(isContract(target), "Address: call to non-contract");
>>   51 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
     52 |         return verifyCallResult(success, returndata, errorMessage);
     53 |     }
     54 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 9 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      6 | // ============================================
      7 | 
      8 | interface IERC20 {
>>    9 |     function totalSupply() external view returns (uint256);
     10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 10 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      7 | 
      8 | interface IERC20 {
      9 |     function totalSupply() external view returns (uint256);
>>   10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 11 行
- **函数**: `transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      8 | interface IERC20 {
      9 |     function totalSupply() external view returns (uint256);
     10 |     function balanceOf(address account) external view returns (uint256);
>>   11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
     14 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 12 行
- **函数**: `allowance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      9 |     function totalSupply() external view returns (uint256);
     10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
>>   12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
     14 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     15 |     event Transfer(address indexed from, address indexed to, uint256 value);
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 13 行
- **函数**: `approve()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
>>   13 |     function approve(address spender, uint256 amount) external returns (bool);
     14 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     15 |     event Transfer(address indexed from, address indexed to, uint256 value);
     16 |     event Approval(address indexed owner, address indexed spender, uint256 value);
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 14 行
- **函数**: `transferFrom()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
>>   14 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     15 |     event Transfer(address indexed from, address indexed to, uint256 value);
     16 |     event Approval(address indexed owner, address indexed spender, uint256 value);
     17 | }
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 163 行
- **函数**: `owner()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    160 |         _;
    161 |     }
    162 | 
>>  163 |     function owner() public view virtual returns (address) {
    164 |         return _owner;
    165 |     }
    166 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 347 行
- **函数**: `register()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    344 |         emit LiquidityAdded("USDT", amount);
    345 |     }
    346 | 
>>  347 |     function register(address ref) external {
    348 |         require(!registered[msg.sender], "ORO: Already registered");
    349 |         require(msg.sender != ref, "ORO: Cannot refer yourself");
    350 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 432 行
- **函数**: `getRank()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    429 |         }
    430 |     }
    431 | 
>>  432 |     function getRank(uint256 volume) public pure returns (uint256) {
    433 |         if (volume >= 1000000 ether) return 500;
    434 |         if (volume >= 400000 ether) return 300;
    435 |         if (volume >= 200000 ether) return 220;
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 451 行
- **函数**: `stake()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    448 |         }
    449 |     }
    450 | 
>>  451 |     function stake(uint256 amount, uint256 durationMonths) external onlyUser {
    452 |         require(users[msg.sender].oroBalance >= amount, "ORO: Insufficient ORO balance");
    453 |         require(amount > 0, "ORO: Amount must be greater than 0");
    454 |         require(durationMonths == 3 || durationMonths == 9 || durationMonths == 12, 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 470 行
- **函数**: `unstake()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    467 |         emit Stake(msg.sender, amount, durationMonths);
    468 |     }
    469 | 
>>  470 |     function unstake(uint256 amount) external onlyUser {
    471 |         User storage u = users[msg.sender];
    472 |         require(u.staked >= amount, "ORO: Insufficient staked amount");
    473 |         require(amount > 0, "ORO: Amount must be greater than 0");
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 510 行
- **函数**: `getROI()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    507 |         u.lastUpdate = block.timestamp;
    508 |     }
    509 | 
>>  510 |     function getROI(uint256 duration) public pure returns (uint256) {
    511 |         if (duration == 12 * 30 days) return 10;
    512 |         if (duration == 9 * 30 days) return 7;
    513 |         if (duration == 3 * 30 days) return 5;
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 569 行
- **函数**: `getPoolBalance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    566 |         emit WithdrawORO(msg.sender, amount);
    567 |     }
    568 | 
>>  569 |     function getPoolBalance() public view returns (uint256 usdtBalance, uint256 oroBalance) {
    570 |         return (usdt.balanceOf(address(this)), oroToken.balanceOf(address(this)));
    571 |     }
    572 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 607 行
- **函数**: `isRegistered()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    604 |         );
    605 |     }
    606 | 
>>  607 |     function isRegistered(address user) public view returns (bool) {
    608 |         return registered[user];
    609 |     }
    610 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 611 行
- **函数**: `isBlacklisted()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    608 |         return registered[user];
    609 |     }
    610 | 
>>  611 |     function isBlacklisted(address user) public view returns (bool) {
    612 |         return blacklisted[user];
    613 |     }
    614 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 615 行
- **函数**: `getReferrer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    612 |         return blacklisted[user];
    613 |     }
    614 | 
>>  615 |     function getReferrer(address user) public view returns (address) {
    616 |         return users[user].referrer;
    617 |     }
    618 | 
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 149 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    144 | 
    145 | // ============================================
    146 | // FILE: Ownable.sol
    147 | // ============================================
    148 | 
>>  149 | abstract contract Ownable is Context {
    150 |     address private _owner;
    151 | 
    152 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    153 | 
    154 |     constructor(address initialOwner) {
```

---

### 23. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 224 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    219 | 
    220 | // ============================================
    221 | // FILE: OROSystemMainnet.sol
    222 | // ============================================
    223 | 
>>  224 | contract OROSystemMainnet is Ownable, ReentrancyGuard {
    225 |     using SafeERC20 for IERC20;
    226 | 
    227 |     IERC20 public usdt;
    228 |     IERC20 public oroToken;
    229 | 
```

---

### 24. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 298 行
- **函数**: `_reentrancyGuardEntered()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    295 |     }
    296 | 
    297 |     modifier antiBot() {
>>  298 |         require(block.timestamp > users[msg.sender].lastAction + cooldown, "ORO: Cooldown active");
    299 |         _;
    300 |         users[msg.sender].lastAction = block.timestamp;
    301 |     }
```

---

### 25. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 300 行
- **函数**: `_reentrancyGuardEntered()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    297 |     modifier antiBot() {
    298 |         require(block.timestamp > users[msg.sender].lastAction + cooldown, "ORO: Cooldown active");
    299 |         _;
>>  300 |         users[msg.sender].lastAction = block.timestamp;
    301 |     }
    302 | 
    303 |     constructor(
```

---

### 26. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 326 行
- **函数**: `_reentrancyGuardEntered()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    323 |         treasury = _treasury;
    324 | 
    325 |         registered[DEFAULT_REFERRER] = true;
>>  326 |         users[DEFAULT_REFERRER].lastUpdate = block.timestamp;
    327 |     }
    328 | 
    329 |     function addOROLiquidity(uint256 amount) external onlyOwner {
```

---

### 27. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 356 行
- **函数**: `register()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    353 | 
    354 |         registered[msg.sender] = true;
    355 |         users[msg.sender].referrer = effectiveRef;
>>  356 |         users[msg.sender].lastUpdate = block.timestamp;
    357 |     }
    358 | 
    359 |     function deposit(uint256 amount)
```

---

### 28. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 465 行
- **函数**: `stake()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    462 |         users[msg.sender].staked += amount;
    463 |         users[msg.sender].stakeAmount = amount;
    464 |         users[msg.sender].stakeDuration = durationMonths * 30 days;
>>  465 |         users[msg.sender].stakeStartTime = block.timestamp;
    466 | 
    467 |         emit Stake(msg.sender, amount, durationMonths);
    468 |     }
```

---

### 29. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 477 行
- **函数**: `unstake()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    474 | 
    475 |         if (u.stakeAmount > 0) {
    476 |             require(amount <= u.stakeAmount, "ORO: Cannot unstake more than locked amount");
>>  477 |             require(block.timestamp >= u.stakeStartTime + u.stakeDuration, 
    478 |                     "ORO: Stake is still locked");
    479 | 
    480 |             u.stakeAmount = 0;
```

---

### 30. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 497 行
- **函数**: `_updateReward()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    494 |         User storage u = users[userAddr];
    495 | 
    496 |         if (u.staked == 0) {
>>  497 |             u.lastUpdate = block.timestamp;
    498 |             return;
    499 |         }
    500 | 
```

---

### 31. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 501 行
- **函数**: `_updateReward()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    498 |             return;
    499 |         }
    500 | 
>>  501 |         uint256 timeDiff = block.timestamp - u.lastUpdate;
    502 |         uint256 rate = getROI(u.stakeDuration);
    503 |         uint256 rewardAmount = u.stakeAmount > 0 ? u.stakeAmount : u.staked;
    504 |         uint256 reward = (rewardAmount * rate * timeDiff) / 1 days / 1000;
```

---

### 32. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 507 行
- **函数**: `_updateReward()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    504 |         uint256 reward = (rewardAmount * rate * timeDiff) / 1 days / 1000;
    505 | 
    506 |         u.reward += reward;
>>  507 |         u.lastUpdate = block.timestamp;
    508 |     }
    509 | 
    510 |     function getROI(uint256 duration) public pure returns (uint256) {
```

---

### 33. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 590 行
- **函数**: `getUserInfo()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    587 |         uint256 pending = u.reward;
    588 | 
    589 |         if (u.staked > 0) {
>>  590 |             uint256 timeDiff = block.timestamp - u.lastUpdate;
    591 |             uint256 rate = getROI(u.stakeDuration);
    592 |             uint256 rewardAmount = u.stakeAmount > 0 ? u.stakeAmount : u.staked;
    593 |             pending += (rewardAmount * rate * timeDiff) / 1 days / 1000;
```

---

### 34. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 638 行
- **函数**: `getStakingInfo()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    635 | 
    636 |         if (u.stakeAmount > 0 && u.stakeStartTime > 0) {
    637 |             uint256 endTime = u.stakeStartTime + u.stakeDuration;
>>  638 |             if (block.timestamp < endTime) {
    639 |                 remaining = endTime - block.timestamp;
    640 |                 locked = true;
    641 |             }
```

---

### 35. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 639 行
- **函数**: `getStakingInfo()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    636 |         if (u.stakeAmount > 0 && u.stakeStartTime > 0) {
    637 |             uint256 endTime = u.stakeStartTime + u.stakeDuration;
    638 |             if (block.timestamp < endTime) {
>>  639 |                 remaining = endTime - block.timestamp;
    640 |                 locked = true;
    641 |             }
    642 |         }
```

---

### 36. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 564 行
- **函数**: `withdrawORO()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    561 |         require(oroToken.balanceOf(address(this)) >= amount, "ORO: Insufficient ORO token liquidity");
    562 | 
    563 |         users[msg.sender].oroBalance -= amount;
>>  564 |         require(oroToken.transfer(msg.sender, amount), "ORO: Transfer failed");
    565 | 
    566 |         emit WithdrawORO(msg.sender, amount);
    567 |     }
```

---

### 37. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 246 行
- **函数**: `_reentrancyGuardEntered()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    243 |     uint256 public depositFeeDevLeader = 25;
    244 |     uint256 public depositFeeDevIT = 40;
    245 | 
>>  246 |     address public constant DEFAULT_REFERRER = 0xe2DEE8C1170BE78b4037Bad7B067dd8F6c160C98;
    247 |     address public devDeposit;
    248 |     address public devLeader;
    249 |     address public devIT;
```

---

### 38. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 26 行
- **函数**: `isContract()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     23 | library Address {
     24 |     function isContract(address account) internal view returns (bool) {
     25 |         uint256 size;
>>   26 |         assembly { size := extcodesize(account) }
     27 |         return size > 0;
     28 |     }
     29 | 
```

---

### 39. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xbB4EAd3db45FA9b7EF2C8B487B34fEcE6b6c6c97` 第 80 行
- **函数**: `verifyCallResult()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     77 |             return returndata;
     78 |         } else {
     79 |             if (returndata.length > 0) {
>>   80 |                 assembly {
     81 |                     let returndata_size := mload(returndata)
     82 |                     revert(add(32, returndata), returndata_size)
     83 |                 }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*