# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:03:03
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` |
| contract_name | `MJToken` |
| compiler_version | `v0.8.22+commit.4fc1097e` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `shanghai` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/MJ/MJToken.sol', 'dependencies/@openzeppelin-contracts-4.9.6/token/ERC20/ERC20.sol', 'dependencies/@openzeppelin-contracts-4.9.6/access/Ownable.sol', 'dependencies/@openzeppelin-contracts-4.9.6/token/ERC20/IERC20.sol', 'dependencies/@openzeppelin-contracts-4.9.6/token/ERC20/extensions/IERC20Metadata.sol', 'dependencies/@openzeppelin-contracts-4.9.6/utils/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646141` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 28 |
| 🟢 LOW | 5 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 21 行
- **函数**: `feeTo()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     18 |         address tokenB
     19 |     ) external view returns (address);
     20 | 
>>   21 |     function feeTo() external view returns (address);
     22 | }
     23 | 
     24 | interface IUniswapV2Router01 {
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 25 行
- **函数**: `factory()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     22 | }
     23 | 
     24 | interface IUniswapV2Router01 {
>>   25 |     function factory() external pure returns (address);
     26 | 
     27 |     function WETH() external pure returns (address);
     28 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 27 行
- **函数**: `WETH()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     24 | interface IUniswapV2Router01 {
     25 |     function factory() external pure returns (address);
     26 | 
>>   27 |     function WETH() external pure returns (address);
     28 | 
     29 |     function addLiquidity(
     30 |         address tokenA,
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 184 行
- **函数**: `name()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    181 |     /**
    182 |      * @dev Returns the name of the token.
    183 |      */
>>  184 |     function name() public view virtual override returns (string memory) {
    185 |         return _name;
    186 |     }
    187 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 192 行
- **函数**: `symbol()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    189 |      * @dev Returns the symbol of the token, usually a shorter version of the
    190 |      * name.
    191 |      */
>>  192 |     function symbol() public view virtual override returns (string memory) {
    193 |         return _symbol;
    194 |     }
    195 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 209 行
- **函数**: `decimals()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    206 |      * no way affects any of the arithmetic of the contract, including
    207 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    208 |      */
>>  209 |     function decimals() public view virtual override returns (uint8) {
    210 |         return 18;
    211 |     }
    212 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 216 行
- **函数**: `totalSupply()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    213 |     /**
    214 |      * @dev See {IERC20-totalSupply}.
    215 |      */
>>  216 |     function totalSupply() public view virtual override returns (uint256) {
    217 |         return _totalSupply;
    218 |     }
    219 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 223 行
- **函数**: `balanceOf()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    220 |     /**
    221 |      * @dev See {IERC20-balanceOf}.
    222 |      */
>>  223 |     function balanceOf(address account) public view virtual override returns (uint256) {
    224 |         return _balances[account];
    225 |     }
    226 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 235 行
- **函数**: `transfer()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    232 |      * - `to` cannot be the zero address.
    233 |      * - the caller must have a balance of at least `amount`.
    234 |      */
>>  235 |     function transfer(address to, uint256 amount) public virtual override returns (bool) {
    236 |         address owner = _msgSender();
    237 |         _transfer(owner, to, amount);
    238 |         return true;
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 244 行
- **函数**: `allowance()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    241 |     /**
    242 |      * @dev See {IERC20-allowance}.
    243 |      */
>>  244 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    245 |         return _allowances[owner][spender];
    246 |     }
    247 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 258 行
- **函数**: `approve()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    255 |      *
    256 |      * - `spender` cannot be the zero address.
    257 |      */
>>  258 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    259 |         address owner = _msgSender();
    260 |         _approve(owner, spender, amount);
    261 |         return true;
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 280 行
- **函数**: `transferFrom()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    277 |      * - the caller must have allowance for ``from``'s tokens of at least
    278 |      * `amount`.
    279 |      */
>>  280 |     function transferFrom(address from, address to, uint256 amount) public virtual override returns (bool) {
    281 |         address spender = _msgSender();
    282 |         _spendAllowance(from, spender, amount);
    283 |         _transfer(from, to, amount);
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 299 行
- **函数**: `increaseAllowance()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    296 |      *
    297 |      * - `spender` cannot be the zero address.
    298 |      */
>>  299 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    300 |         address owner = _msgSender();
    301 |         _approve(owner, spender, allowance(owner, spender) + addedValue);
    302 |         return true;
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 319 行
- **函数**: `decreaseAllowance()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    316 |      * - `spender` must have allowance for the caller of at least
    317 |      * `subtractedValue`.
    318 |      */
>>  319 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    320 |         address owner = _msgSender();
    321 |         uint256 currentAllowance = allowance(owner, spender);
    322 |         require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 534 行
- **函数**: `owner()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    531 |     /**
    532 |      * @dev Returns the address of the current owner.
    533 |      */
>>  534 |     function owner() public view virtual returns (address) {
    535 |         return _owner;
    536 |     }
    537 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 605 行
- **函数**: `totalSupply()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    602 |     /**
    603 |      * @dev Returns the amount of tokens in existence.
    604 |      */
>>  605 |     function totalSupply() external view returns (uint256);
    606 | 
    607 |     /**
    608 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 610 行
- **函数**: `balanceOf()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    607 |     /**
    608 |      * @dev Returns the amount of tokens owned by `account`.
    609 |      */
>>  610 |     function balanceOf(address account) external view returns (uint256);
    611 | 
    612 |     /**
    613 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 619 行
- **函数**: `transfer()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    616 |      *
    617 |      * Emits a {Transfer} event.
    618 |      */
>>  619 |     function transfer(address to, uint256 amount) external returns (bool);
    620 | 
    621 |     /**
    622 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 628 行
- **函数**: `allowance()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    625 |      *
    626 |      * This value changes when {approve} or {transferFrom} are called.
    627 |      */
>>  628 |     function allowance(address owner, address spender) external view returns (uint256);
    629 | 
    630 |     /**
    631 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 644 行
- **函数**: `approve()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    641 |      *
    642 |      * Emits an {Approval} event.
    643 |      */
>>  644 |     function approve(address spender, uint256 amount) external returns (bool);
    645 | 
    646 |     /**
    647 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 655 行
- **函数**: `transferFrom()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    652 |      *
    653 |      * Emits a {Transfer} event.
    654 |      */
>>  655 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
    656 | }
    657 | 
    658 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 677 行
- **函数**: `name()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    674 |     /**
    675 |      * @dev Returns the name of the token.
    676 |      */
>>  677 |     function name() external view returns (string memory);
    678 | 
    679 |     /**
    680 |      * @dev Returns the symbol of the token.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 682 行
- **函数**: `symbol()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    679 |     /**
    680 |      * @dev Returns the symbol of the token.
    681 |      */
>>  682 |     function symbol() external view returns (string memory);
    683 | 
    684 |     /**
    685 |      * @dev Returns the decimals places of the token.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 687 行
- **函数**: `decimals()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    684 |     /**
    685 |      * @dev Returns the decimals places of the token.
    686 |      */
>>  687 |     function decimals() external view returns (uint8);
    688 | }
    689 | 
    690 | 
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 64 行
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     59 |         address to,
     60 |         uint deadline
     61 |     ) external returns (uint[] memory amounts);
     62 | }
     63 | 
>>   64 | contract MJToken is ERC20, Ownable {
     65 |     mapping(address => bool) public _isExcludedFromFees;
     66 |     address public uniswapV2Pair;
     67 |     uint256 public sellFee = 500;
     68 |     address public usdtAddress;
     69 |     IUniswapV2Router02 public swapRouter;
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 160 行
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    155 |  *
    156 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    157 |  * functions have been added to mitigate the well-known issues around setting
    158 |  * allowances. See {IERC20-approve}.
    159 |  */
>>  160 | contract ERC20 is Context, IERC20, IERC20Metadata {
    161 |     mapping(address => uint256) private _balances;
    162 | 
    163 |     mapping(address => mapping(address => uint256)) private _allowances;
    164 | 
    165 |     uint256 private _totalSupply;
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 511 行
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    506 |  *
    507 |  * This module is used through inheritance. It will make available the modifier
    508 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    509 |  * the owner.
    510 |  */
>>  511 | abstract contract Ownable is Context {
    512 |     address private _owner;
    513 | 
    514 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    515 | 
    516 |     /**
```

---

### 28. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 566 行
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    561 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
    562 |         _transferOwnership(newOwner);
    563 |     }
    564 | 
    565 |     /**
>>  566 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    567 |      * Internal function without access restriction.
    568 |      */
    569 |     function _transferOwnership(address newOwner) internal virtual {
    570 |         address oldOwner = _owner;
    571 |         _owner = newOwner;
```

---

### 29. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 73 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     70 |     address public marketingAddress;
     71 | 
     72 |     constructor() ERC20("MJ", "MJ") Ownable() {
>>   73 |         usdtAddress = 0x55d398326f99059fF775485246999027B3197955;
     74 |         swapRouter = IUniswapV2Router02(
     75 |             0x10ED43C718714eb63d5aA57B78B54704E256024E
     76 |         );
```

---

### 30. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 75 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     72 |     constructor() ERC20("MJ", "MJ") Ownable() {
     73 |         usdtAddress = 0x55d398326f99059fF775485246999027B3197955;
     74 |         swapRouter = IUniswapV2Router02(
>>   75 |             0x10ED43C718714eb63d5aA57B78B54704E256024E
     76 |         );
     77 |         uniswapV2Pair = IUniswapV2Factory(swapRouter.factory()).createPair(
     78 |             address(this),
```

---

### 31. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 81 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     78 |             address(this),
     79 |             usdtAddress
     80 |         );
>>   81 |         marketingAddress = 0x4ceEBBe86729E12191D4B8a3Ef140f4e405A5BE8;
     82 |         _mint(0x5dc222E967472986517CAccAb5438C43b952cDf3, 100000000000e18);
     83 |         _isExcludedFromFees[address(this)] = true;
     84 |         _isExcludedFromFees[marketingAddress] = true;
```

---

### 32. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 82 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     79 |             usdtAddress
     80 |         );
     81 |         marketingAddress = 0x4ceEBBe86729E12191D4B8a3Ef140f4e405A5BE8;
>>   82 |         _mint(0x5dc222E967472986517CAccAb5438C43b952cDf3, 100000000000e18);
     83 |         _isExcludedFromFees[address(this)] = true;
     84 |         _isExcludedFromFees[marketingAddress] = true;
     85 |         _isExcludedFromFees[0x5dc222E967472986517CAccAb5438C43b952cDf3] = true;
```

---

### 33. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xA73175E92A68cd3f73D96f36AF3648883c8ABeD9` 第 85 行
- **函数**: `swapExactTokensForTokens()`
- **合约**: `MJToken`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     82 |         _mint(0x5dc222E967472986517CAccAb5438C43b952cDf3, 100000000000e18);
     83 |         _isExcludedFromFees[address(this)] = true;
     84 |         _isExcludedFromFees[marketingAddress] = true;
>>   85 |         _isExcludedFromFees[0x5dc222E967472986517CAccAb5438C43b952cDf3] = true;
     86 |         _isExcludedFromFees[msg.sender] = true;
     87 |     }
     88 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*