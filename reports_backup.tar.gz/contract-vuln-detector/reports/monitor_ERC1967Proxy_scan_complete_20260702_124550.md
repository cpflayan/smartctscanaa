# 智能合约安全审计报告

> 生成时间: 2026-07-02 12:45:50
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` |
| contract_name | `ERC1967Proxy` |
| compiler_version | `v0.8.21+commit.d9974bed` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `MIT` |
| proxy | `True` |
| implementation | `0xc287cf47ae5d644f52fb363be64e0b38182f9f0e` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107638938` |

## 安全摘要

**整体风险等级**: UNKNOWN

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 6 |
| 🟢 LOW | 13 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 246 行
- **函数**: `functionDelegateCall()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    243 |      * but performing a delegate call.
    244 |      */
    245 |     function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
>>  246 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    247 |         return verifyCallResultFromTarget(target, success, returndata);
    248 |     }
    249 | 
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 548 行
- **函数**: `_delegate()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    545 | 
    546 |             // Call the implementation.
    547 |             // out and outsize are 0 because we don't know the size yet.
>>  548 |             let result := delegatecall(gas(), implementation, 0, calldatasize(), 0, 0)
    549 | 
    550 |             // Copy the returned data.
    551 |             returndatacopy(0, 0, returndatasize())
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 187 行
- **函数**: `sendValue()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    184 |             revert AddressInsufficientBalance(address(this));
    185 |         }
    186 | 
>>  187 |         (bool success, ) = recipient.call{value: amount}("");
    188 |         if (!success) {
    189 |             revert FailedInnerCall();
    190 |         }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 228 行
- **函数**: `functionCallWithValue()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    225 |         if (address(this).balance < value) {
    226 |             revert AddressInsufficientBalance(address(this));
    227 |         }
>>  228 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    229 |         return verifyCallResultFromTarget(target, success, returndata);
    230 |     }
    231 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 318 行
- **函数**: `implementation()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    315 |      *
    316 |      * {UpgradeableBeacon} will check that this address is a contract.
    317 |      */
>>  318 |     function implementation() external view returns (address);
    319 | }
    320 | 
    321 | // File: .deps/github/OpenZeppelin/openzeppelin-contracts/contracts/proxy/ERC1967/ERC1967Utils.sol
```

---

### 6. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 332 行
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    327 | 
    328 | 
    329 | 
    330 | 
    331 | /**
>>  332 |  * @dev This abstract contract provides getters and event emitting update functions for
    333 |  * https://eips.ethereum.org/EIPS/eip-1967[EIP1967] slots.
    334 |  */
    335 | library ERC1967Utils {
    336 |     // We re-declare ERC-1967 events here because they can't be used directly from IERC1967.
    337 |     // This will be fixed in Solidity 0.8.21. At that point we should remove these events.
```

---

### 7. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 533 行
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    528 |  * Additionally, delegation to the implementation can be triggered manually through the {_fallback} function, or to a
    529 |  * different contract through the {_delegate} function.
    530 |  *
    531 |  * The success and return data of the delegated call will be returned back to the caller of the proxy.
    532 |  */
>>  533 | abstract contract Proxy {
    534 |     /**
    535 |      * @dev Delegates the current call to `implementation`.
    536 |      *
    537 |      * This function does not return to its internal call site, it will return directly to the external caller.
    538 |      */
```

---

### 8. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 598 行
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    593 | pragma solidity ^0.8.20;
    594 | 
    595 | 
    596 | 
    597 | /**
>>  598 |  * @dev This contract implements an upgradeable proxy. It is upgradeable because calls are delegated to an
    599 |  * implementation address that can be changed. This address is stored in storage in the location specified by
    600 |  * https://eips.ethereum.org/EIPS/eip-1967[EIP1967], so that it doesn't conflict with the storage layout of the
    601 |  * implementation behind the proxy.
    602 |  */
    603 | contract ERC1967Proxy is Proxy {
```

---

### 9. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 358 行
- **函数**: `implementation()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    355 |      * This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1.
    356 |      */
    357 |     // solhint-disable-next-line private-vars-leading-underscore
>>  358 |     bytes32 internal constant IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
    359 | 
    360 |     /**
    361 |      * @dev The `implementation` of the proxy is invalid.
```

---

### 10. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 420 行
- **函数**: `upgradeToAndCall()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    417 |      * This is the keccak-256 hash of "eip1967.proxy.admin" subtracted by 1.
    418 |      */
    419 |     // solhint-disable-next-line private-vars-leading-underscore
>>  420 |     bytes32 internal constant ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    421 | 
    422 |     /**
    423 |      * @dev Returns the current admin.
```

---

### 11. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 458 行
- **函数**: `changeAdmin()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    455 |      * This is the keccak-256 hash of "eip1967.proxy.beacon" subtracted by 1.
    456 |      */
    457 |     // solhint-disable-next-line private-vars-leading-underscore
>>  458 |     bytes32 internal constant BEACON_SLOT = 0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50;
    459 | 
    460 |     /**
    461 |      * @dev Returns the current beacon.
```

---

### 12. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 64 行
- **函数**: `getAddressSlot()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     61 |      */
     62 |     function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
     63 |         /// @solidity memory-safe-assembly
>>   64 |         assembly {
     65 |             r.slot := slot
     66 |         }
     67 |     }
```

---

### 13. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 74 行
- **函数**: `getBooleanSlot()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     71 |      */
     72 |     function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
     73 |         /// @solidity memory-safe-assembly
>>   74 |         assembly {
     75 |             r.slot := slot
     76 |         }
     77 |     }
```

---

### 14. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 84 行
- **函数**: `getBytes32Slot()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     81 |      */
     82 |     function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
     83 |         /// @solidity memory-safe-assembly
>>   84 |         assembly {
     85 |             r.slot := slot
     86 |         }
     87 |     }
```

---

### 15. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 94 行
- **函数**: `getUint256Slot()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     91 |      */
     92 |     function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
     93 |         /// @solidity memory-safe-assembly
>>   94 |         assembly {
     95 |             r.slot := slot
     96 |         }
     97 |     }
```

---

### 16. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 104 行
- **函数**: `getStringSlot()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    101 |      */
    102 |     function getStringSlot(bytes32 slot) internal pure returns (StringSlot storage r) {
    103 |         /// @solidity memory-safe-assembly
>>  104 |         assembly {
    105 |             r.slot := slot
    106 |         }
    107 |     }
```

---

### 17. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 114 行
- **函数**: `getStringSlot()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    111 |      */
    112 |     function getStringSlot(string storage store) internal pure returns (StringSlot storage r) {
    113 |         /// @solidity memory-safe-assembly
>>  114 |         assembly {
    115 |             r.slot := store.slot
    116 |         }
    117 |     }
```

---

### 18. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 124 行
- **函数**: `getBytesSlot()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    121 |      */
    122 |     function getBytesSlot(bytes32 slot) internal pure returns (BytesSlot storage r) {
    123 |         /// @solidity memory-safe-assembly
>>  124 |         assembly {
    125 |             r.slot := slot
    126 |         }
    127 |     }
```

---

### 19. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 134 行
- **函数**: `getBytesSlot()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    131 |      */
    132 |     function getBytesSlot(bytes storage store) internal pure returns (BytesSlot storage r) {
    133 |         /// @solidity memory-safe-assembly
>>  134 |         assembly {
    135 |             r.slot := store.slot
    136 |         }
    137 |     }
```

---

### 20. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 292 行
- **函数**: `_revert()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    289 |         if (returndata.length > 0) {
    290 |             // The easiest way to bubble the revert reason is using memory via assembly
    291 |             /// @solidity memory-safe-assembly
>>  292 |             assembly {
    293 |                 let returndata_size := mload(returndata)
    294 |                 revert(add(32, returndata), returndata_size)
    295 |             }
```

---

### 21. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x62FeF78D9ec47e85c79a7F47b50BDFf927f9809f` 第 540 行
- **函数**: `_delegate()`
- **合约**: `ERC1967`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    537 |      * This function does not return to its internal call site, it will return directly to the external caller.
    538 |      */
    539 |     function _delegate(address implementation) internal virtual {
>>  540 |         assembly {
    541 |             // Copy msg.data. We take full control of memory in this inline assembly
    542 |             // block because it will not return to Solidity code. We overwrite the
    543 |             // Solidity scratch pad at memory position 0.
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*