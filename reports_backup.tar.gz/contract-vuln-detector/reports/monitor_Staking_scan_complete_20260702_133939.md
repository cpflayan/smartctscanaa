# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:39:39
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` |
| contract_name | `Staking` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/security/ReentrancyGuard.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/utils/Context.sol', 'contracts/Staking.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646139` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 35 |
| 🟢 LOW | 24 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 490 行
- **函数**: `stake()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    487 |         _processStakingFunds(amount, address(0xdead));
    488 | 
    489 |         StakingPlan memory plan = plans[planId];
>>  490 |         uint256 startTime = block.timestamp;
    491 |         uint256 endTime = startTime + (plan.duration * plan.timeUnit);
    492 | 
    493 |         userOrders[msg.sender].push(StakingOrder({
```

---

### 2. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 606 行
- **函数**: `calculateReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    603 | 
    604 |         StakingPlan memory plan = plans[order.planId];
    605 | 
>>  606 |         uint256 currentTime = block.timestamp;
    607 |         uint256 timeElapsed = currentTime - order.lastClaimTime;
    608 | 
    609 |         if (timeElapsed == 0) return 0;
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 327 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    324 | }
    325 | 
    326 | interface IUniswapV2Pair {
>>  327 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    328 |     function token0() external view returns (address);
    329 |     function token1() external view returns (address);
    330 |     function sync() external;
```

---

### 4. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 588 行
- **函数**: `_getPoolUSDTReserve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    585 |         if (pair == address(0)) return 0;
    586 | 
    587 |         IUniswapV2Pair pairContract = IUniswapV2Pair(pair);
>>  588 |         (uint112 reserve0, uint112 reserve1, ) = pairContract.getReserves();
    589 | 
    590 |         address token0 = pairContract.token0();
    591 |         if (token0 == address(USDT)) {
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 45 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     42 |     /**
     43 |      * @dev Returns the address of the current owner.
     44 |      */
>>   45 |     function owner() public view virtual returns (address) {
     46 |         return _owner;
     47 |     }
     48 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 197 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    194 |     /**
    195 |      * @dev Returns the amount of tokens in existence.
    196 |      */
>>  197 |     function totalSupply() external view returns (uint256);
    198 | 
    199 |     /**
    200 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 202 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    199 |     /**
    200 |      * @dev Returns the amount of tokens owned by `account`.
    201 |      */
>>  202 |     function balanceOf(address account) external view returns (uint256);
    203 | 
    204 |     /**
    205 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 211 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    208 |      *
    209 |      * Emits a {Transfer} event.
    210 |      */
>>  211 |     function transfer(address to, uint256 amount) external returns (bool);
    212 | 
    213 |     /**
    214 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 220 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    217 |      *
    218 |      * This value changes when {approve} or {transferFrom} are called.
    219 |      */
>>  220 |     function allowance(address owner, address spender) external view returns (uint256);
    221 | 
    222 |     /**
    223 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 236 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    233 |      *
    234 |      * Emits an {Approval} event.
    235 |      */
>>  236 |     function approve(address spender, uint256 amount) external returns (bool);
    237 | 
    238 |     /**
    239 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 247 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    244 |      *
    245 |      * Emits a {Transfer} event.
    246 |      */
>>  247 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
    248 | }
    249 | 
    250 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 290 行
- **函数**: `getUserTotalBuyValue()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    287 | 
    288 | interface IXPLUSToken {
    289 |     function recycleLiquidity(uint256 amount) external;
>>  290 |     function getUserTotalBuyValue(address user) external view returns (uint256);
    291 |     function balanceOf(address account) external view returns (uint256);
    292 |     function uniswapV2Pair() external view returns (address);
    293 | }
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 291 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    288 | interface IXPLUSToken {
    289 |     function recycleLiquidity(uint256 amount) external;
    290 |     function getUserTotalBuyValue(address user) external view returns (uint256);
>>  291 |     function balanceOf(address account) external view returns (uint256);
    292 |     function uniswapV2Pair() external view returns (address);
    293 | }
    294 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 292 行
- **函数**: `uniswapV2Pair()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    289 |     function recycleLiquidity(uint256 amount) external;
    290 |     function getUserTotalBuyValue(address user) external view returns (uint256);
    291 |     function balanceOf(address account) external view returns (uint256);
>>  292 |     function uniswapV2Pair() external view returns (address);
    293 | }
    294 | 
    295 | interface IUniswapV2Router02 {
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 315 行
- **函数**: `getAmountsOut()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    312 |         uint deadline
    313 |     ) external returns (uint[] memory amounts);
    314 | 
>>  315 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    316 | 
    317 |     function swapExactTokensForTokensSupportingFeeOnTransferTokens(
    318 |         uint amountIn,
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 327 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    324 | }
    325 | 
    326 | interface IUniswapV2Pair {
>>  327 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    328 |     function token0() external view returns (address);
    329 |     function token1() external view returns (address);
    330 |     function sync() external;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 328 行
- **函数**: `token0()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    325 | 
    326 | interface IUniswapV2Pair {
    327 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>>  328 |     function token0() external view returns (address);
    329 |     function token1() external view returns (address);
    330 |     function sync() external;
    331 | }
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 329 行
- **函数**: `token1()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    326 | interface IUniswapV2Pair {
    327 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    328 |     function token0() external view returns (address);
>>  329 |     function token1() external view returns (address);
    330 |     function sync() external;
    331 | }
    332 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 334 行
- **函数**: `referrer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    331 | }
    332 | 
    333 | interface IReferral {
>>  334 |     function referrer(address user) external view returns (address);
    335 |     function getUpline(address user) external view returns (address[] memory);
    336 |     function getReferrals(address user, uint256 num) external view returns (address[] memory);
    337 |     function getDirectReferrals(address user) external view returns (address[] memory);
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 335 行
- **函数**: `getUpline()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    332 | 
    333 | interface IReferral {
    334 |     function referrer(address user) external view returns (address);
>>  335 |     function getUpline(address user) external view returns (address[] memory);
    336 |     function getReferrals(address user, uint256 num) external view returns (address[] memory);
    337 |     function getDirectReferrals(address user) external view returns (address[] memory);
    338 | }
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 336 行
- **函数**: `getReferrals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    333 | interface IReferral {
    334 |     function referrer(address user) external view returns (address);
    335 |     function getUpline(address user) external view returns (address[] memory);
>>  336 |     function getReferrals(address user, uint256 num) external view returns (address[] memory);
    337 |     function getDirectReferrals(address user) external view returns (address[] memory);
    338 | }
    339 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 337 行
- **函数**: `getDirectReferrals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    334 |     function referrer(address user) external view returns (address);
    335 |     function getUpline(address user) external view returns (address[] memory);
    336 |     function getReferrals(address user, uint256 num) external view returns (address[] memory);
>>  337 |     function getDirectReferrals(address user) external view returns (address[] memory);
    338 | }
    339 | 
    340 | interface IYPLUSSwap {
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 600 行
- **函数**: `calculateReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    597 |         return usdtReserve;
    598 |     }
    599 | 
>>  600 |     function calculateReward(address user, uint256 orderId) public view returns (uint256) {
    601 |         StakingOrder memory order = userOrders[user][orderId];
    602 |         if (order.isWithdrawn) return 0;
    603 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 996 行
- **函数**: `updateLevel()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    993 |         }
    994 |     }
    995 | 
>>  996 |     function updateLevel(address user) public {
    997 |         _checkAndUpdateLevel(user);
    998 |     }
    999 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1000 行
- **函数**: `getUserLevel()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    997 |         _checkAndUpdateLevel(user);
    998 |     }
    999 | 
>> 1000 |     function getUserLevel(address user) external view returns (uint256) {
   1001 |         return userLevel[user];
   1002 |     }
   1003 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1004 行
- **函数**: `getUserLevelInfo()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1001 |         return userLevel[user];
   1002 |     }
   1003 | 
>> 1004 |     function getUserLevelInfo(address user) external view returns (
   1005 |         uint256 level,
   1006 |         uint256 highestLevel,
   1007 |         string memory name,
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1031 行
- **函数**: `getLevelConfig()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1028 |         return (level, highestLevel, name, rewardRate, yplusBuyQuota, currentZonePerf, nextLevelRequired);
   1029 |     }
   1030 | 
>> 1031 |     function getLevelConfig(uint256 level) external view returns (Level memory) {
   1032 |         require(level <= 7, "Invalid level");
   1033 |         return levels[level];
   1034 |     }
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1036 行
- **函数**: `getAllLevelConfigs()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1033 |         return levels[level];
   1034 |     }
   1035 | 
>> 1036 |     function getAllLevelConfigs() external view returns (Level[8] memory) {
   1037 |         return levels;
   1038 |     }
   1039 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1040 行
- **函数**: `calculateUserLevel()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1037 |         return levels;
   1038 |     }
   1039 | 
>> 1040 |     function calculateUserLevel(address user) external view returns (uint256) {
   1041 |         uint256 zonePerf = zonePerformance[user];
   1042 |         return _calculateLevel(zonePerf);
   1043 |     }
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1068 行
- **函数**: `getUserOrders()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1065 |         }
   1066 |     }
   1067 | 
>> 1068 |     function getUserOrders(address user) external view returns (StakingOrder[] memory) {
   1069 |         return userOrders[user];
   1070 |     }
   1071 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1072 行
- **函数**: `getUserStats()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1069 |         return userOrders[user];
   1070 |     }
   1071 | 
>> 1072 |     function getUserStats(address user) external view returns (
   1073 |         uint256 totalStaked,
   1074 |         uint256 totalWithdrawn,
   1075 |         uint256 orderCount,
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1103 行
- **函数**: `getAvailableGlobalLimit()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1100 |         return rewards;
   1101 |     }
   1102 | 
>> 1103 |     function getAvailableGlobalLimit() external view returns (
   1104 |         uint256 maxPerMinute,
   1105 |         uint256 used,
   1106 |         bool windowReset,
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 22 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     17 |  *
     18 |  * This module is used through inheritance. It will make available the modifier
     19 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     20 |  * the owner.
     21 |  */
>>   22 | abstract contract Ownable is Context {
     23 |     address private _owner;
     24 | 
     25 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     26 | 
     27 |     /**
```

---

### 34. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 77 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     72 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
     73 |         _transferOwnership(newOwner);
     74 |     }
     75 | 
     76 |     /**
>>   77 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     78 |      * Internal function without access restriction.
     79 |      */
     80 |     function _transferOwnership(address newOwner) internal virtual {
     81 |         address oldOwner = _owner;
     82 |         _owner = newOwner;
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 345 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    340 | interface IYPLUSSwap {
    341 |     function addDailyBuyQuota(address user, uint256 amount) external;
    342 |     function addOneTimeBuyQuota(address user, uint256 amount) external;
    343 | }
    344 | 
>>  345 | contract Staking is Ownable, ReentrancyGuard {
    346 | 
    347 |     uint256 public constant DENOMINATOR = 10000;
    348 |     uint256 public constant SECONDS_PER_DAY = 86400;
    349 | 
    350 |     struct StakingPlan {
```

---

### 36. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 490 行
- **函数**: `stake()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    487 |         _processStakingFunds(amount, address(0xdead));
    488 | 
    489 |         StakingPlan memory plan = plans[planId];
>>  490 |         uint256 startTime = block.timestamp;
    491 |         uint256 endTime = startTime + (plan.duration * plan.timeUnit);
    492 | 
    493 |         userOrders[msg.sender].push(StakingOrder({
```

---

### 37. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 542 行
- **函数**: `_processStakingFunds()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    539 |             0,
    540 |             0,
    541 |             to,
>>  542 |             block.timestamp
    543 |         );
    544 |     }
    545 | 
```

---

### 38. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 555 行
- **函数**: `_getGlobalLimitData()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    552 |         uint256 poolBalance = _getPoolUSDTReserve();
    553 |         maxPerMinute = (poolBalance * globalRatePerMinute) / DENOMINATOR;
    554 | 
>>  555 |         windowReset = block.timestamp >= lastGlobalStakeTime + 60;
    556 | 
    557 |         if (windowReset) {
    558 |             used = 0;
```

---

### 39. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 562 行
- **函数**: `_getGlobalLimitData()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    559 |             timeUntilReset = 0;
    560 |         } else {
    561 |             used = globalStakedInMinute;
>>  562 |             timeUntilReset = (lastGlobalStakeTime + 60) - block.timestamp;
    563 |         }
    564 | 
    565 |         return (maxPerMinute, used, windowReset, timeUntilReset);
```

---

### 40. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 572 行
- **函数**: `_checkGlobalLimit()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    569 |         (uint256 maxPerMinute, uint256 used, bool windowReset, ) = _getGlobalLimitData();
    570 | 
    571 |         if (windowReset) {
>>  572 |             lastGlobalStakeTime = block.timestamp;
    573 |             globalStakedInMinute = 0;
    574 |             used = 0;
    575 |         }
```

---

### 41. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 606 行
- **函数**: `calculateReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    603 | 
    604 |         StakingPlan memory plan = plans[order.planId];
    605 | 
>>  606 |         uint256 currentTime = block.timestamp;
    607 |         uint256 timeElapsed = currentTime - order.lastClaimTime;
    608 | 
    609 |         if (timeElapsed == 0) return 0;
```

---

### 42. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 651 行
- **函数**: `claimReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    648 | 
    649 |         _checkTurboMechanism(msg.sender, (reward * 5000) / DENOMINATOR);
    650 | 
>>  651 |         order.lastClaimTime = block.timestamp;
    652 |         order.claimedReward += reward;
    653 | 
    654 |         uint256 usdtBefore = USDT.balanceOf(address(this));
```

---

### 43. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 666 行
- **函数**: `claimReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    663 |             xplusBefore,
    664 |             path,
    665 |             address(this),
>>  666 |             block.timestamp
    667 |         );
    668 | 
    669 |         uint256 xplusUsed = xplusBefore - XPLUS.balanceOf(address(this));
```

---

### 44. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 692 行
- **函数**: `withdraw()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    689 |         require(orderId < userOrders[msg.sender].length, "Invalid order");
    690 |         StakingOrder storage order = userOrders[msg.sender][orderId];
    691 |         require(!order.isWithdrawn, "Already withdrawn");
>>  692 |         require(block.timestamp >= order.endTime, "Not expired yet");
    693 | 
    694 |         uint256 currentReward = calculateReward(msg.sender, orderId);
    695 |         uint256 principal = order.amount;
```

---

### 45. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 712 行
- **函数**: `withdraw()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    709 |             xplusBefore,
    710 |             path,
    711 |             address(this),
>>  712 |             block.timestamp
    713 |         );
    714 | 
    715 |         uint256 xplusUsed = xplusBefore - XPLUS.balanceOf(address(this));
```

---

### 46. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 732 行
- **函数**: `withdraw()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    729 |         XPLUS.recycleLiquidity(xplusUsed);
    730 | 
    731 |         order.isWithdrawn = true;
>>  732 |         order.lastClaimTime = block.timestamp;
    733 |         order.claimedReward += actualReward;
    734 | 
    735 |         userTotalStaked[msg.sender] -= principal;
```

---

### 47. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 872 行
- **函数**: `_swapUsdtForTokens()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    869 |             minOutput,
    870 |             path,
    871 |             to,
>>  872 |             block.timestamp
    873 |         );
    874 |     }
    875 | 
```

---

### 48. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 675 行
- **函数**: `claimReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    672 |         uint256 actualReward = (usdtGot * 5000) / DENOMINATOR;
    673 |         uint256 distributePortion = usdtGot - actualReward;
    674 | 
>>  675 |         USDT.transfer(msg.sender, actualReward);
    676 | 
    677 |         if (distributePortion > 0) {
    678 |             _distributeRewards(msg.sender, distributePortion);
```

---

### 49. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 727 行
- **函数**: `withdraw()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    724 |             _distributeRewards(msg.sender, distributePortion);
    725 |         }
    726 | 
>>  727 |         USDT.transfer(msg.sender, principal + actualReward);
    728 | 
    729 |         XPLUS.recycleLiquidity(xplusUsed);
    730 | 
```

---

### 50. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 782 行
- **函数**: `_distributeGenerationRewards()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    779 |         for (uint256 i = 0; i < upline.length && i < 10; i++) {
    780 |             if (upline[i] == address(0)) break;
    781 | 
>>  782 |             USDT.transfer(upline[i], rewardPerGen);
    783 |             distributed += rewardPerGen;
    784 |             emit GenerationRewardPaid(upline[i], user, rewardPerGen, i + 1);
    785 |         }
```

---

### 51. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 788 行
- **函数**: `_distributeGenerationRewards()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    785 |         }
    786 | 
    787 |         if (distributed < totalAmount) {
>>  788 |             USDT.transfer(marketingAddress, totalAmount - distributed);
    789 |         }
    790 |     }
    791 | 
```

---

### 52. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 815 行
- **函数**: `_distributeTeamRewards()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    812 |                             _distributeS7Rewards();
    813 |                         }
    814 |                     } else {
>>  815 |                         USDT.transfer(upline[i], reward);
    816 |                         distributedAmount += reward;
    817 |                         emit TeamRewardPaid(upline[i], reward, currentLevel);
    818 |                     }
```

---

### 53. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 830 行
- **函数**: `_distributeTeamRewards()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    827 |         }
    828 | 
    829 |         if (distributedAmount < totalAmount) {
>>  830 |             USDT.transfer(marketingAddress, totalAmount - distributedAmount);
    831 |         }
    832 |     }
    833 | 
```

---

### 54. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 840 行
- **函数**: `_distributeS7Rewards()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    837 |         uint256 userCount = s7Users.length;
    838 | 
    839 |         if (userCount == 0) {
>>  840 |             USDT.transfer(marketingAddress, accumulatedS7Reward);
    841 |             accumulatedS7Reward = 0;
    842 |             return;
    843 |         }
```

---

### 55. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 849 行
- **函数**: `_distributeS7Rewards()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    846 |         uint256 totalDistributed = 0;
    847 | 
    848 |         for (uint256 i = 0; i < userCount; i++) {
>>  849 |             USDT.transfer(s7Users[i], rewardPerUser);
    850 |             emit TeamRewardPaid(s7Users[i], rewardPerUser, 7);
    851 |             totalDistributed += rewardPerUser;
    852 |         }
```

---

### 56. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1049 行
- **函数**: `manualAllocation()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1046 |         _distributeS7Rewards();
   1047 | 
   1048 |         if (accumulatedYplusFee > 0) {
>> 1049 |             USDT.transfer(address(yplusSwap), accumulatedYplusFee);
   1050 |             accumulatedYplusFee = 0;
   1051 |         }
   1052 | 
```

---

### 57. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1062 行
- **函数**: `manualAllocation()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1059 |         if (remainingUsdt > 0) {
   1060 |             address pair = XPLUS.uniswapV2Pair();
   1061 |             if (pair != address(0)) {
>> 1062 |                 USDT.transfer(pair, remainingUsdt);
   1063 |                 IUniswapV2Pair(pair).sync();
   1064 |             }
   1065 |         }
```

---

### 58. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1178 行
- **函数**: `emergencyWithdraw()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1175 | 
   1176 |     function emergencyWithdraw(address token, uint256 amount) external onlyOwner {
   1177 |         if (token == address(0)) {
>> 1178 |             payable(owner()).transfer(amount);
   1179 |         } else {
   1180 |             IERC20(token).transfer(owner(), amount);
   1181 |         }
```

---

### 59. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0Fb0De3Ec0be2f6EfB336d452b470a27B7c4a4d9` 第 1180 行
- **函数**: `emergencyWithdraw()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1177 |         if (token == address(0)) {
   1178 |             payable(owner()).transfer(amount);
   1179 |         } else {
>> 1180 |             IERC20(token).transfer(owner(), amount);
   1181 |         }
   1182 |     }
   1183 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*