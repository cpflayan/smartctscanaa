# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:27:44
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` |
| contract_name | `NTVAToken` |
| compiler_version | `v0.8.30+commit.73712a01` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646145` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 24 |
| 🟢 LOW | 0 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 29 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     26 |     /**
     27 |      * @dev Returns the value of tokens in existence.
     28 |      */
>>   29 |     function totalSupply() external view returns (uint256);
     30 | 
     31 |     /**
     32 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 34 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     31 |     /**
     32 |      * @dev Returns the value of tokens owned by `account`.
     33 |      */
>>   34 |     function balanceOf(address account) external view returns (uint256);
     35 | 
     36 |     /**
     37 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 43 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     40 |      *
     41 |      * Emits a {Transfer} event.
     42 |      */
>>   43 |     function transfer(address to, uint256 value) external returns (bool);
     44 | 
     45 |     /**
     46 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 52 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     49 |      *
     50 |      * This value changes when {approve} or {transferFrom} are called.
     51 |      */
>>   52 |     function allowance(address owner, address spender) external view returns (uint256);
     53 | 
     54 |     /**
     55 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 69 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     66 |      *
     67 |      * Emits an {Approval} event.
     68 |      */
>>   69 |     function approve(address spender, uint256 value) external returns (bool);
     70 | 
     71 |     /**
     72 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 80 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     77 |      *
     78 |      * Emits a {Transfer} event.
     79 |      */
>>   80 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
     81 | }
     82 | 
     83 | // File: @openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 98 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     95 |     /**
     96 |      * @dev Returns the name of the token.
     97 |      */
>>   98 |     function name() external view returns (string memory);
     99 | 
    100 |     /**
    101 |      * @dev Returns the symbol of the token.
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 103 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    100 |     /**
    101 |      * @dev Returns the symbol of the token.
    102 |      */
>>  103 |     function symbol() external view returns (string memory);
    104 | 
    105 |     /**
    106 |      * @dev Returns the decimals places of the token.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 108 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    105 |     /**
    106 |      * @dev Returns the decimals places of the token.
    107 |      */
>>  108 |     function decimals() external view returns (uint8);
    109 | }
    110 | 
    111 | // File: @openzeppelin/contracts/utils/Context.sol
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 358 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    355 |     /**
    356 |      * @dev Returns the name of the token.
    357 |      */
>>  358 |     function name() public view virtual returns (string memory) {
    359 |         return _name;
    360 |     }
    361 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 366 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    363 |      * @dev Returns the symbol of the token, usually a shorter version of the
    364 |      * name.
    365 |      */
>>  366 |     function symbol() public view virtual returns (string memory) {
    367 |         return _symbol;
    368 |     }
    369 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 383 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    380 |      * no way affects any of the arithmetic of the contract, including
    381 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    382 |      */
>>  383 |     function decimals() public view virtual returns (uint8) {
    384 |         return 18;
    385 |     }
    386 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 388 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    385 |     }
    386 | 
    387 |     /// @inheritdoc IERC20
>>  388 |     function totalSupply() public view virtual returns (uint256) {
    389 |         return _totalSupply;
    390 |     }
    391 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 393 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    390 |     }
    391 | 
    392 |     /// @inheritdoc IERC20
>>  393 |     function balanceOf(address account) public view virtual returns (uint256) {
    394 |         return _balances[account];
    395 |     }
    396 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 405 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    402 |      * - `to` cannot be the zero address.
    403 |      * - the caller must have a balance of at least `value`.
    404 |      */
>>  405 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    406 |         address owner = _msgSender();
    407 |         _transfer(owner, to, value);
    408 |         return true;
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 412 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    409 |     }
    410 | 
    411 |     /// @inheritdoc IERC20
>>  412 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    413 |         return _allowances[owner][spender];
    414 |     }
    415 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 426 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    423 |      *
    424 |      * - `spender` cannot be the zero address.
    425 |      */
>>  426 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    427 |         address owner = _msgSender();
    428 |         _approve(owner, spender, value);
    429 |         return true;
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 448 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    445 |      * - the caller must have allowance for ``from``'s tokens of at least
    446 |      * `value`.
    447 |      */
>>  448 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    449 |         address spender = _msgSender();
    450 |         _spendAllowance(from, spender, value);
    451 |         _transfer(from, to, value);
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 669 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    666 |     /**
    667 |      * @dev Returns the address of the current owner.
    668 |      */
>>  669 |     function owner() public view virtual returns (address) {
    670 |         return _owner;
    671 |     }
    672 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 771 行
- **函数**: `transferTiva()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    768 |         emit TreasuryUpdated(old, newTreasury);
    769 |     }
    770 | 
>>  771 |     function transferTiva(address to, uint256 value) public virtual returns(bool) {  
    772 |         address from = _msgSender();
    773 |         uint256 fee = (value * feeBps) / BPS_DENOM;
    774 |         if (fee == 0) {
```

---

### 21. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 335 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    330 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    331 |  * instead returning `false` on failure. This behavior is nonetheless
    332 |  * conventional and does not conflict with the expectations of ERC-20
    333 |  * applications.
    334 |  */
>>  335 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    336 |     mapping(address account => uint256) private _balances;
    337 | 
    338 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    339 | 
    340 |     uint256 private _totalSupply;
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 633 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    628 |  *
    629 |  * This module is used through inheritance. It will make available the modifier
    630 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    631 |  * the owner.
    632 |  */
>>  633 | abstract contract Ownable is Context {
    634 |     address private _owner;
    635 | 
    636 |     /**
    637 |      * @dev The caller account is not authorized to perform an operation.
    638 |      */
```

---

### 23. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 705 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    700 |         }
    701 |         _transferOwnership(newOwner);
    702 |     }
    703 | 
    704 |     /**
>>  705 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    706 |      * Internal function without access restriction.
    707 |      */
    708 |     function _transferOwnership(address newOwner) internal virtual {
    709 |         address oldOwner = _owner;
    710 |         _owner = newOwner;
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x57b13A7E18D7382f2CE754ff112b2f552230b83E` 第 729 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    724 |  * @dev ERC20 token with:
    725 |  *  - fixed total supply minted at deployment
    726 |  *  - no further minting/burning/pausing
    727 |  *  - transfer tax up to MAX_FEE_BPS
    728 |  */
>>  729 | contract NTVAToken is ERC20, Ownable {
    730 |     // Fee in basis points (bps). 10000 = 100%
    731 |     uint16 public feeBps;
    732 |     uint16 public constant MAX_FEE_BPS = 1000; // max 10%
    733 |     uint16 public constant BPS_DENOM = 10000;
    734 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*