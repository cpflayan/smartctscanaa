# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:13:49
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` |
| contract_name | `BcoinToken` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 4 |
| 🟡 MEDIUM | 63 |
| 🟢 LOW | 15 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1842 行
- **函数**: `_antiFlashloanGuard()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
   1839 |             oneTradePerBlock &&
   1840 |             from != stakingContractAddress &&
   1841 |             from != address(this) &&
>> 1842 |             !isExcludedFromFees[tx.origin]
   1843 |         ) {
   1844 |             require(lastTradeBlock[tx.origin] != block.number, "o");
   1845 |             lastTradeBlock[tx.origin] = uint32(block.number);
```

---

### 2. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1844 行
- **函数**: `_antiFlashloanGuard()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
   1841 |             from != address(this) &&
   1842 |             !isExcludedFromFees[tx.origin]
   1843 |         ) {
>> 1844 |             require(lastTradeBlock[tx.origin] != block.number, "o");
   1845 |             lastTradeBlock[tx.origin] = uint32(block.number);
   1846 |         }
   1847 | 
```

---

### 3. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1845 行
- **函数**: `_antiFlashloanGuard()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
   1842 |             !isExcludedFromFees[tx.origin]
   1843 |         ) {
   1844 |             require(lastTradeBlock[tx.origin] != block.number, "o");
>> 1845 |             lastTradeBlock[tx.origin] = uint32(block.number);
   1846 |         }
   1847 | 
   1848 |         if (isSell && !isExcludedFromFees[from]) {
```

---

### 4. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2315 行
- **函数**: `_twapEnforceCheck()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
   2312 |             isExcludedFromFees[from] ||
   2313 |             isExcludedFromFees[to] ||
   2314 |             isExcludedFromFees[msg.sender] ||
>> 2315 |             isExcludedFromFees[tx.origin]
   2316 |         ) {
   2317 |             return;
   2318 |         }
```

---

### 5. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 174 行
- **函数**: `getReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    171 | // src/interfaces/IUniswapV2Pair.sol
    172 | 
    173 | interface IUniswapV2Pair {
>>  174 |     function getReserves()
    175 |         external
    176 |         view
    177 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 6. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1737 行
- **函数**: `getReserveU()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1734 |     function getReserveU() external view returns (uint256) {
   1735 |         if (uniswapV2PairAddress == address(0)) return 0;
   1736 |         (uint112 r0, uint112 r1, ) = IUniswapV2Pair(uniswapV2PairAddress)
>> 1737 |             .getReserves();
   1738 |         address token0 = IUniswapV2Pair(uniswapV2PairAddress).token0();
   1739 |         return token0 == usdt ? uint256(r0) : uint256(r1);
   1740 |     }
```

---

### 7. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2169 行
- **函数**: `_getReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2166 |         }
   2167 |     }
   2168 | 
>> 2169 |     function _getReserves()
   2170 |         public
   2171 |         view
   2172 |         returns (uint256 rOther, uint256 rThis, uint256 balanceOther)
```

---

### 8. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2175 行
- **函数**: `_getReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2172 |         returns (uint256 rOther, uint256 rThis, uint256 balanceOther)
   2173 |     {
   2174 |         IUniswapV2Pair mainPair = IUniswapV2Pair(uniswapV2PairAddress);
>> 2175 |         (uint r0, uint256 r1, ) = mainPair.getReserves();
   2176 | 
   2177 |         address t0 = mainPair.token0();
   2178 |         address t1 = mainPair.token1();
```

---

### 9. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2226 行
- **函数**: `_isRemoveLiquidity()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2223 |     function _isRemoveLiquidity(
   2224 |         uint256 amount
   2225 |     ) internal view returns (uint256 liquidity) {
>> 2226 |         (uint256 rOther, , uint256 balanceOther) = _getReserves();
   2227 |         //isRemoveLP
   2228 |         if (balanceOther <= rOther) {
   2229 |             liquidity =
```

---

### 10. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2266 行
- **函数**: `_twapInit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2263 |     function _twapInit() internal {
   2264 |         address pair = uniswapV2PairAddress;
   2265 |         if (pair == address(0)) return;
>> 2266 |         (, , twapBlockTimestampLast) = IUniswapV2Pair(pair).getReserves();
   2267 |         price0CumulativeLast = IUniswapV2PairCumulative(pair)
   2268 |             .price0CumulativeLast();
   2269 |         price1CumulativeLast = IUniswapV2PairCumulative(pair)
```

---

### 11. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2277 行
- **函数**: `_twapMaybeUpdate()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2274 |     function _twapMaybeUpdate() internal {
   2275 |         if (!twapInitialized || uniswapV2PairAddress == address(0)) return;
   2276 |         address pair = uniswapV2PairAddress;
>> 2277 |         (, , uint32 ts) = IUniswapV2Pair(pair).getReserves();
   2278 |         if (ts < twapBlockTimestampLast) return;
   2279 |         uint32 timeElapsed = ts - twapBlockTimestampLast;
   2280 |         if (timeElapsed == 0) return;
```

---

### 12. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2331 行
- **函数**: `_twapEnforceCheck()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2328 |         uint256 twapU = this.consultBcoinToUsdt(1e18);
   2329 |         if (twapU == 0) return;
   2330 | 
>> 2331 |         (uint112 r0, uint112 r1, ) = IUniswapV2Pair(pair).getReserves();
   2332 |         address token0 = IUniswapV2Pair(pair).token0();
   2333 |         uint256 rBcoin = token0 == address(this) ? uint256(r0) : uint256(r1);
   2334 |         uint256 rUsdt = token0 == usdt ? uint256(r0) : uint256(r1);
```

---

### 13. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2423 行
- **函数**: `_isAddLiquidityV2()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2420 |             address t1 = IUniswapV2Pair(pair).token1();
   2421 |             if (t0 != address(this) && t1 != address(this)) return false;
   2422 |             address other = t0 == address(this) ? t1 : t0;
>> 2423 |             (uint112 r0, uint112 r1, ) = IUniswapV2Pair(pair).getReserves();
   2424 |             uint256 rThis = t0 == address(this) ? uint256(r0) : uint256(r1);
   2425 |             uint256 rOther = t0 == address(this) ? uint256(r1) : uint256(r0);
   2426 |             if (rThis == 0 || rOther == 0) return false;
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 54 行
- **函数**: `supportsInterface()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     51 |      *
     52 |      * This function call must use less than 30 000 gas.
     53 |      */
>>   54 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
     55 | }
     56 | 
     57 | // lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 82 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     79 |     /**
     80 |      * @dev Returns the value of tokens in existence.
     81 |      */
>>   82 |     function totalSupply() external view returns (uint256);
     83 | 
     84 |     /**
     85 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 87 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     84 |     /**
     85 |      * @dev Returns the value of tokens owned by `account`.
     86 |      */
>>   87 |     function balanceOf(address account) external view returns (uint256);
     88 | 
     89 |     /**
     90 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 96 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     93 |      *
     94 |      * Emits a {Transfer} event.
     95 |      */
>>   96 |     function transfer(address to, uint256 value) external returns (bool);
     97 | 
     98 |     /**
     99 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 105 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    102 |      *
    103 |      * This value changes when {approve} or {transferFrom} are called.
    104 |      */
>>  105 |     function allowance(address owner, address spender) external view returns (uint256);
    106 | 
    107 |     /**
    108 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 122 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    119 |      *
    120 |      * Emits an {Approval} event.
    121 |      */
>>  122 |     function approve(address spender, uint256 value) external returns (bool);
    123 | 
    124 |     /**
    125 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 133 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    130 |      *
    131 |      * Emits a {Transfer} event.
    132 |      */
>>  133 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    134 | }
    135 | 
    136 | // src/interfaces/IReferral.sol
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 139 行
- **函数**: `getReferral()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    136 | // src/interfaces/IReferral.sol
    137 | 
    138 | interface IReferral {
>>  139 |     function getReferral(address account) external view returns (address);
    140 |     // function getRootAddress() external view returns (address);
    141 |     function bindReferralFor(address user, address referrer) external;
    142 |     function bindReferralBatchToRoot(address[] calldata users) external;
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 143 行
- **函数**: `isBindReferral()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    140 |     // function getRootAddress() external view returns (address);
    141 |     function bindReferralFor(address user, address referrer) external;
    142 |     function bindReferralBatchToRoot(address[] calldata users) external;
>>  143 |     function isBindReferral(address account) external view returns (bool);
    144 |     function ROOT_ADDRESS() external pure returns (address);
    145 | 
    146 |     function getDirectReferralsCount(
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 144 行
- **函数**: `ROOT_ADDRESS()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    141 |     function bindReferralFor(address user, address referrer) external;
    142 |     function bindReferralBatchToRoot(address[] calldata users) external;
    143 |     function isBindReferral(address account) external view returns (bool);
>>  144 |     function ROOT_ADDRESS() external pure returns (address);
    145 | 
    146 |     function getDirectReferralsCount(
    147 |         address account
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 168 行
- **函数**: `getPair()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    165 |         address tokenB
    166 |     ) external returns (address pair);
    167 | 
>>  168 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    169 | }
    170 | 
    171 | // src/interfaces/IUniswapV2Pair.sol
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 179 行
- **函数**: `token0()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    176 |         view
    177 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    178 | 
>>  179 |     function token0() external view returns (address);
    180 | 
    181 |     function token1() external view returns (address);
    182 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 181 行
- **函数**: `token1()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    178 | 
    179 |     function token0() external view returns (address);
    180 | 
>>  181 |     function token1() external view returns (address);
    182 | 
    183 |     function sync() external;
    184 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 185 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    182 | 
    183 |     function sync() external;
    184 | 
>>  185 |     function totalSupply() external view returns (uint256);
    186 | 
    187 |     function factory() external view returns (address);
    188 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 187 行
- **函数**: `factory()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    184 | 
    185 |     function totalSupply() external view returns (uint256);
    186 | 
>>  187 |     function factory() external view returns (address);
    188 | 
    189 | }
    190 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 202 行
- **函数**: `factory()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    199 |         uint deadline
    200 |     ) external;
    201 | 
>>  202 |     function factory() external pure returns (address);
    203 | 
    204 |     function WETH() external pure returns (address);
    205 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 204 行
- **函数**: `WETH()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    201 | 
    202 |     function factory() external pure returns (address);
    203 | 
>>  204 |     function WETH() external pure returns (address);
    205 | 
    206 |     function getAmountsOut(
    207 |         uint amountIn,
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 435 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    432 |     /**
    433 |      * @dev Returns the name of the token.
    434 |      */
>>  435 |     function name() external view returns (string memory);
    436 | 
    437 |     /**
    438 |      * @dev Returns the symbol of the token.
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 440 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    437 |     /**
    438 |      * @dev Returns the symbol of the token.
    439 |      */
>>  440 |     function symbol() external view returns (string memory);
    441 | 
    442 |     /**
    443 |      * @dev Returns the decimals places of the token.
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 445 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    442 |     /**
    443 |      * @dev Returns the decimals places of the token.
    444 |      */
>>  445 |     function decimals() external view returns (uint8);
    446 | }
    447 | 
    448 | // lib/openzeppelin-contracts/contracts/access/Ownable.sol
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 500 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    497 |     /**
    498 |      * @dev Returns the address of the current owner.
    499 |      */
>>  500 |     function owner() public view virtual returns (address) {
    501 |         return _owner;
    502 |     }
    503 | 
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 591 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    588 |     /**
    589 |      * @dev Returns the name of the token.
    590 |      */
>>  591 |     function name() public view virtual returns (string memory) {
    592 |         return _name;
    593 |     }
    594 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 599 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    596 |      * @dev Returns the symbol of the token, usually a shorter version of the
    597 |      * name.
    598 |      */
>>  599 |     function symbol() public view virtual returns (string memory) {
    600 |         return _symbol;
    601 |     }
    602 | 
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 616 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    613 |      * no way affects any of the arithmetic of the contract, including
    614 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    615 |      */
>>  616 |     function decimals() public view virtual returns (uint8) {
    617 |         return 18;
    618 |     }
    619 | 
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 621 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    618 |     }
    619 | 
    620 |     /// @inheritdoc IERC20
>>  621 |     function totalSupply() public view virtual returns (uint256) {
    622 |         return _totalSupply;
    623 |     }
    624 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 626 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    623 |     }
    624 | 
    625 |     /// @inheritdoc IERC20
>>  626 |     function balanceOf(address account) public view virtual returns (uint256) {
    627 |         return _balances[account];
    628 |     }
    629 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 638 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    635 |      * - `to` cannot be the zero address.
    636 |      * - the caller must have a balance of at least `value`.
    637 |      */
>>  638 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    639 |         address owner = _msgSender();
    640 |         _transfer(owner, to, value);
    641 |         return true;
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 645 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    642 |     }
    643 | 
    644 |     /// @inheritdoc IERC20
>>  645 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    646 |         return _allowances[owner][spender];
    647 |     }
    648 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 659 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    656 |      *
    657 |      * - `spender` cannot be the zero address.
    658 |      */
>>  659 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    660 |         address owner = _msgSender();
    661 |         _approve(owner, spender, value);
    662 |         return true;
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 681 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    678 |      * - the caller must have allowance for ``from``'s tokens of at least
    679 |      * `value`.
    680 |      */
>>  681 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    682 |         address spender = _msgSender();
    683 |         _spendAllowance(from, spender, value);
    684 |         _transfer(from, to, value);
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 876 行
- **函数**: `transferAndCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    873 |      * @param value The amount of tokens to be transferred.
    874 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    875 |      */
>>  876 |     function transferAndCall(address to, uint256 value) external returns (bool);
    877 | 
    878 |     /**
    879 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 886 行
- **函数**: `transferAndCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    883 |      * @param data Additional data with no specified format, sent in call to `to`.
    884 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    885 |      */
>>  886 |     function transferAndCall(address to, uint256 value, bytes calldata data) external returns (bool);
    887 | 
    888 |     /**
    889 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 896 行
- **函数**: `transferFromAndCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    893 |      * @param value The amount of tokens to be transferred.
    894 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    895 |      */
>>  896 |     function transferFromAndCall(address from, address to, uint256 value) external returns (bool);
    897 | 
    898 |     /**
    899 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 907 行
- **函数**: `transferFromAndCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    904 |      * @param data Additional data with no specified format, sent in call to `to`.
    905 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    906 |      */
>>  907 |     function transferFromAndCall(address from, address to, uint256 value, bytes calldata data) external returns (bool);
    908 | 
    909 |     /**
    910 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 916 行
- **函数**: `approveAndCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    913 |      * @param value The amount of tokens to be spent.
    914 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    915 |      */
>>  916 |     function approveAndCall(address spender, uint256 value) external returns (bool);
    917 | 
    918 |     /**
    919 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 926 行
- **函数**: `approveAndCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    923 |      * @param data Additional data with no specified format, sent in call to `spender`.
    924 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    925 |      */
>>  926 |     function approveAndCall(address spender, uint256 value, bytes calldata data) external returns (bool);
    927 | }
    928 | 
    929 | // lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1244 行
- **函数**: `getCommunityValues()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1241 |         bool isDone
   1242 |     ) external;
   1243 | 
>> 1244 |     function getCommunityValues(address user) external view returns (uint256);
   1245 |     function stakeByBcoinDirectly(address user, uint256 bcoinAmount) external;
   1246 |     function depositAddresses(uint256 index) external view returns (address);
   1247 |     function getChannelTokenConfigByChannel(
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1246 行
- **函数**: `depositAddresses()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1243 | 
   1244 |     function getCommunityValues(address user) external view returns (uint256);
   1245 |     function stakeByBcoinDirectly(address user, uint256 bcoinAmount) external;
>> 1246 |     function depositAddresses(uint256 index) external view returns (address);
   1247 |     function getChannelTokenConfigByChannel(
   1248 |         uint8 channel
   1249 |     ) external view returns (address);
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1260 行
- **函数**: `deposit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1257 | }
   1258 | 
   1259 | interface IWBNBLike is IERC20 {
>> 1260 |     function deposit() external payable;
   1261 |     function withdraw(uint amount) external;
   1262 | }
   1263 | 
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1265 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1262 | }
   1263 | 
   1264 | interface IERC20Like {
>> 1265 |     function balanceOf(address) external view returns (uint256);
   1266 | }
   1267 | 
   1268 | /// @dev 为 TWAP 读取 Pancake/UniswapV2 Pair 的累计价格；真实 pair 合约具备这些方法
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1270 行
- **函数**: `price0CumulativeLast()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1267 | 
   1268 | /// @dev 为 TWAP 读取 Pancake/UniswapV2 Pair 的累计价格；真实 pair 合约具备这些方法
   1269 | interface IUniswapV2PairCumulative {
>> 1270 |     function price0CumulativeLast() external view returns (uint256);
   1271 |     function price1CumulativeLast() external view returns (uint256);
   1272 | }
   1273 | 
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1271 行
- **函数**: `price1CumulativeLast()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1268 | /// @dev 为 TWAP 读取 Pancake/UniswapV2 Pair 的累计价格；真实 pair 合约具备这些方法
   1269 | interface IUniswapV2PairCumulative {
   1270 |     function price0CumulativeLast() external view returns (uint256);
>> 1271 |     function price1CumulativeLast() external view returns (uint256);
   1272 | }
   1273 | 
   1274 | /// @title Bcoin 代币
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1425 行
- **函数**: `beginLiquidityOp()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1422 |         _;
   1423 |     }
   1424 | 
>> 1425 |     function beginLiquidityOp() external onlyStakingContract {
   1426 |         unchecked {
   1427 |             liquidityOpDepth += 1;
   1428 |         }
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1442 行
- **函数**: `endLiquidityOp()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1439 |         CHANNEL_BCOIN_DIRECT_SEND = channel;
   1440 |     }
   1441 | 
>> 1442 |     function endLiquidityOp() external onlyStakingContract {
   1443 |         require(liquidityOpDepth > 0, "no liquidity op");
   1444 |         unchecked {
   1445 |             liquidityOpDepth -= 1;
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1602 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1599 |     //     );
   1600 |     // }
   1601 | 
>> 1602 |     function decimals() public pure override returns (uint8) {
   1603 |         return _DECIMALS;
   1604 |     }
   1605 | 
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1734 行
- **函数**: `getReserveU()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1731 |     // }
   1732 | 
   1733 |     /// @notice LP 中 USDT 储备（18 位精度）
>> 1734 |     function getReserveU() external view returns (uint256) {
   1735 |         if (uniswapV2PairAddress == address(0)) return 0;
   1736 |         (uint112 r0, uint112 r1, ) = IUniswapV2Pair(uniswapV2PairAddress)
   1737 |             .getReserves();
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1781 行
- **函数**: `recycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1778 |     //     }
   1779 |     // }
   1780 | 
>> 1781 |     function recycle(uint256 amount, address to) external {
   1782 |         if (msg.sender != stakingContractAddress) revert NoPermissionCall();
   1783 |         _recycle(amount, to);
   1784 |     }
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1798 行
- **函数**: `getCommunityValues()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1795 |     }
   1796 | 
   1797 |     /// @notice 查询用户小区业绩
>> 1798 |     function getCommunityValues(address user) external view returns (uint256) {
   1799 |         return IStaking(stakingContractAddress).getCommunityValues(user);
   1800 |     }
   1801 | 
```

---

### 62. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 47 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     42 |  *
     43 |  * For an implementation, see {ERC165}.
     44 |  */
     45 | interface IERC165 {
     46 |     /**
>>   47 |      * @dev Returns true if this contract implements the interface defined by
     48 |      * `interfaceId`. See the corresponding
     49 |      * https://eips.ethereum.org/EIPS/eip-165#how-interfaces-are-identified[ERC section]
     50 |      * to learn more about how these ids are created.
     51 |      *
     52 |      * This function call must use less than 30 000 gas.
```

---

### 63. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 464 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    459 |  *
    460 |  * This module is used through inheritance. It will make available the modifier
    461 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    462 |  * the owner.
    463 |  */
>>  464 | abstract contract Ownable is Context {
    465 |     address private _owner;
    466 | 
    467 |     /**
    468 |      * @dev The caller account is not authorized to perform an operation.
    469 |      */
```

---

### 64. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 536 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    531 |         }
    532 |         _transferOwnership(newOwner);
    533 |     }
    534 | 
    535 |     /**
>>  536 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    537 |      * Internal function without access restriction.
    538 |      */
    539 |     function _transferOwnership(address newOwner) internal virtual {
    540 |         address oldOwner = _owner;
    541 |         _owner = newOwner;
```

---

### 65. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 568 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    563 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    564 |  * instead returning `false` on failure. This behavior is nonetheless
    565 |  * conventional and does not conflict with the expectations of ERC-20
    566 |  * applications.
    567 |  */
>>  568 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    569 |     mapping(address account => uint256) private _balances;
    570 | 
    571 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    572 | 
    573 |     uint256 private _totalSupply;
```

---

### 66. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 936 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    931 | // OpenZeppelin Contracts (last updated v5.5.0) (token/ERC20/utils/SafeERC20.sol)
    932 | 
    933 | /**
    934 |  * @title SafeERC20
    935 |  * @dev Wrappers around ERC-20 operations that throw on failure (when the token
>>  936 |  * contract returns false). Tokens that return no value (and instead revert or
    937 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    938 |  * successful.
    939 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    940 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    941 |  */
```

---

### 67. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1275 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1270 |     function price0CumulativeLast() external view returns (uint256);
   1271 |     function price1CumulativeLast() external view returns (uint256);
   1272 | }
   1273 | 
   1274 | /// @title Bcoin 代币
>> 1275 | contract BcoinToken is ERC20, Ownable {
   1276 |     using SafeERC20 for IERC20;
   1277 | 
   1278 |     uint8 private constant _DECIMALS = 18;
   1279 |     uint256 public constant TOTAL_SUPPLY = 21_000_000 * 1e18;
   1280 |     uint256 private constant BPS = 10000;
```

---

### 68. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1743 行
- **函数**: `_autoBurnLPTokens()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1740 |     }
   1741 | 
   1742 |     function _autoBurnLPTokens() internal {
>> 1743 |         lastLpBurnTime = block.timestamp;
   1744 |         uint256 pairTokenBalance = balanceOf(uniswapV2PairAddress);
   1745 |         uint256 amountToBurn = (pairTokenBalance * percentForLPBurn) / 10000;
   1746 | 
```

---

### 69. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2013 行
- **函数**: `_update()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2010 |             // 卖单触发：每 lpBurnFrequency 最多一次，从 Pair 抽走一定比例的 BCOIN 并 sync
   2011 |             if (
   2012 |                 lpBurnEnabled &&
>> 2013 |                 block.timestamp >= lastLpBurnTime + lpBurnFrequency &&
   2014 |                 !inSwap &&
   2015 |                 liquidityOpDepth == 0
   2016 |             ) {
```

---

### 70. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2386 行
- **函数**: `_twapEnforceCheck()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2383 |                 expectedOutAmount,
   2384 |                 path,
   2385 |                 address(this),
>> 2386 |                 block.timestamp + 15 minutes
   2387 |             );
   2388 | 
   2389 |         uint256 usdtAmount = amounts[1];
```

---

### 71. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2401 行
- **函数**: `_twapEnforceCheck()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   2398 |         // }
   2399 | 
   2400 |         // 将usdtAmount 转账给质押合约，然后请求质押合约handleBNBStake方法
>> 2401 |         IERC20(usdt).transfer(stakingContractAddress, usdtAmount);
   2402 |         IStaking(stakingContractAddress).handleBNBStake(
   2403 |             msg.sender,
   2404 |             msg.value,
```

---

### 72. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1844 行
- **函数**: `_antiFlashloanGuard()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1841 |             from != address(this) &&
   1842 |             !isExcludedFromFees[tx.origin]
   1843 |         ) {
>> 1844 |             require(lastTradeBlock[tx.origin] != block.number, "o");
   1845 |             lastTradeBlock[tx.origin] = uint32(block.number);
   1846 |         }
   1847 | 
```

---

### 73. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1845 行
- **函数**: `_antiFlashloanGuard()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1842 |             !isExcludedFromFees[tx.origin]
   1843 |         ) {
   1844 |             require(lastTradeBlock[tx.origin] != block.number, "o");
>> 1845 |             lastTradeBlock[tx.origin] = uint32(block.number);
   1846 |         }
   1847 | 
   1848 |         if (isSell && !isExcludedFromFees[from]) {
```

---

### 74. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1850 行
- **函数**: `_antiFlashloanGuard()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1847 | 
   1848 |         if (isSell && !isExcludedFromFees[from]) {
   1849 |             require(
>> 1850 |                 block.number > lastBuyBlock[from] + minBlocksBeforeSell,
   1851 |                 "s"
   1852 |             );
   1853 |         }
```

---

### 75. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1856 行
- **函数**: `_antiFlashloanGuard()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1853 |         }
   1854 | 
   1855 |         if (isBuy && !isExcludedFromFees[to]) {
>> 1856 |             lastBuyBlock[to] = uint32(block.number);
   1857 |         }
   1858 |     }
   1859 | 
```

---

### 76. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1286 行
- **函数**: `price1CumulativeLast()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1283 | 
   1284 |     address public stakingContractAddress;
   1285 |     // address public handleAddress;
>> 1286 |     address public constant wbnb = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
   1287 | 
   1288 |     // =========================
   1289 |     // Auto LP burn (sell-triggered, throttled)
```

---

### 77. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1298 行
- **函数**: `price1CumulativeLast()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1295 |     /// @dev Liquidity operation guard: when >0, skip auto LP burn in sell hook
   1296 |     uint256 public liquidityOpDepth;
   1297 | 
>> 1298 |     address public constant usdt = 0x55d398326f99059fF775485246999027B3197955;
   1299 |     address public constant uniswapV2RouterAddress =
   1300 |         0x10ED43C718714eb63d5aA57B78B54704E256024E;
   1301 |     address public immutable uniswapV2PairAddress;
```

---

### 78. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1300 行
- **函数**: `price1CumulativeLast()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1297 | 
   1298 |     address public constant usdt = 0x55d398326f99059fF775485246999027B3197955;
   1299 |     address public constant uniswapV2RouterAddress =
>> 1300 |         0x10ED43C718714eb63d5aA57B78B54704E256024E;
   1301 |     address public immutable uniswapV2PairAddress;
   1302 | 
   1303 |     uint256 public buyFeeBps = 300; // 买 3%，可调
```

---

### 79. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1320 行
- **函数**: `price1CumulativeLast()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
   1317 |     bool public oneTradePerBlock = true;
   1318 | 
   1319 |     // 防闪电贷开关
>> 1320 |     bool public antiFlashloanGuard = true;
   1321 | 
   1322 |     // 内部交易，闪电贷豁免锁
   1323 |     bool private inSwap = false;
```

---

### 80. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1829 行
- **函数**: `_antiFlashloanGuard()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
   1826 |         inSwap = false;
   1827 |     }
   1828 | 
>> 1829 |     function _antiFlashloanGuard(
   1830 |         address from,
   1831 |         address to,
   1832 |         bool isBuy,
```

---

### 81. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 1836 行
- **函数**: `_antiFlashloanGuard()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
   1833 |         bool isSell
   1834 |     ) internal {
   1835 |         if (inSwap) return;
>> 1836 |         if (!antiFlashloanGuard) return;
   1837 | 
   1838 |         if (
   1839 |             oneTradePerBlock &&
```

---

### 82. 🟢 [LOW] flash-loan-related

- **状态**: ❓ 待确认
- **位置**: `0x305465442Ca9450cd0d17bc7154a4E514e98eB65` 第 2060 行
- **函数**: `_update()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 代码涉及闪电贷，需确保价格预言机和回调逻辑安全。

**代码片段**:
```solidity
   2057 |             super._update(from, toAddress, amount);
   2058 |         }
   2059 | 
>> 2060 |         _antiFlashloanGuard(from, to, isBuy, isSell);
   2061 | 
   2062 |         if (twapEnabled) {
   2063 |             _twapEnforceCheck(from, to);
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*