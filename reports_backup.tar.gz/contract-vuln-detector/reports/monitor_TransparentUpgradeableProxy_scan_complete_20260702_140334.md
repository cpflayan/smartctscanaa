# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:03:34
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` |
| contract_name | `TransparentUpgradeableProxy` |
| compiler_version | `v0.8.30+commit.73712a01` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `prague` |
| license_type | `` |
| proxy | `True` |
| implementation | `0x198cd252d256ae1bdcf080d30191e2dfa042cba5` |
| multi_file | `True` |
| source_files | `['lib/openzeppelin-contracts/contracts/proxy/transparent/TransparentUpgradeableProxy.sol', 'lib/openzeppelin-contracts/contracts/proxy/ERC1967/ERC1967Utils.sol', 'lib/openzeppelin-contracts/contracts/proxy/ERC1967/ERC1967Proxy.sol', 'lib/openzeppelin-contracts/contracts/interfaces/IERC1967.sol', 'lib/openzeppelin-contracts/contracts/proxy/transparent/ProxyAdmin.sol', 'lib/openzeppelin-contracts/contracts/proxy/beacon/IBeacon.sol', 'lib/openzeppelin-contracts/contracts/utils/Address.sol', 'lib/openzeppelin-contracts/contracts/utils/StorageSlot.sol', 'lib/openzeppelin-contracts/contracts/proxy/Proxy.sol', 'lib/openzeppelin-contracts/contracts/access/Ownable.sol', 'lib/openzeppelin-contracts/contracts/utils/Errors.sol', 'lib/openzeppelin-contracts/contracts/utils/LowLevelCall.sol', 'lib/openzeppelin-contracts/contracts/utils/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 3 |
| 🟡 MEDIUM | 9 |
| 🟢 LOW | 4 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 795 行
- **函数**: `_delegate()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    792 | 
    793 |             // Call the implementation.
    794 |             // out and outsize are 0 because we don't know the size yet.
>>  795 |             let result := delegatecall(gas(), implementation, 0x00, calldatasize(), 0x00, 0x00)
    796 | 
    797 |             // Copy the returned data.
    798 |             returndatacopy(0x00, 0x00, returndatasize())
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 1055 行
- **函数**: `delegatecallNoReturn()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1052 |     /// @dev Performs a Solidity function call using a low level `delegatecall` and ignoring the return data.
   1053 |     function delegatecallNoReturn(address target, bytes memory data) internal returns (bool success) {
   1054 |         assembly ("memory-safe") {
>> 1055 |             success := delegatecall(gas(), target, add(data, 0x20), mload(data), 0x00, 0x00)
   1056 |         }
   1057 |     }
   1058 | 
```

---

### 3. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 1069 行
- **函数**: `delegatecallReturn64Bytes()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1066 |         bytes memory data
   1067 |     ) internal returns (bool success, bytes32 result1, bytes32 result2) {
   1068 |         assembly ("memory-safe") {
>> 1069 |             success := delegatecall(gas(), target, add(data, 0x20), mload(data), 0x00, 0x40)
   1070 |             result1 := mload(0x00)
   1071 |             result2 := mload(0x20)
   1072 |         }
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 21 行
- **函数**: `upgradeToAndCall()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     18 |  */
     19 | interface ITransparentUpgradeableProxy is IERC1967 {
     20 |     /// @dev See {UUPSUpgradeable-upgradeToAndCall}
>>   21 |     function upgradeToAndCall(address newImplementation, bytes calldata data) external payable;
     22 | }
     23 | 
     24 | /**
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 441 行
- **函数**: `implementation()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    438 |      *
    439 |      * {UpgradeableBeacon} will check that this address is a contract.
    440 |      */
>>  441 |     function implementation() external view returns (address);
    442 | }
    443 | 
    444 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 893 行
- **函数**: `owner()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    890 |     /**
    891 |      * @dev Returns the address of the current owner.
    892 |      */
>>  893 |     function owner() public view virtual returns (address) {
    894 |         return _owner;
    895 |     }
    896 | 
```

---

### 7. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 64 行
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     59 |  * WARNING: It is not recommended to extend this contract to add additional external functions. If you do so, the
     60 |  * compiler will not check that there are no selector conflicts, due to the note above. A selector clash between any new
     61 |  * function and the functions declared in {ITransparentUpgradeableProxy} will be resolved in favor of the new one. This
     62 |  * could render the `upgradeToAndCall` function inaccessible, preventing upgradeability and compromising transparency.
     63 |  */
>>   64 | contract TransparentUpgradeableProxy is ERC1967Proxy {
     65 |     // An immutable address for the admin to avoid unnecessary SLOADs before each call
     66 |     // at the expense of removing the ability to change the admin once it's set.
     67 |     // This is acceptable if the admin is always a ProxyAdmin instance or similar contract
     68 |     // with its own ability to transfer the permissions to another account.
     69 |     address private immutable _admin;
```

---

### 8. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 315 行
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    310 | 
    311 | import {Proxy} from "../Proxy.sol";
    312 | import {ERC1967Utils} from "./ERC1967Utils.sol";
    313 | 
    314 | /**
>>  315 |  * @dev This contract implements an upgradeable proxy. It is upgradeable because calls are delegated to an
    316 |  * implementation address that can be changed. This address is stored in storage in the location specified by
    317 |  * https://eips.ethereum.org/EIPS/eip-1967[ERC-1967], so that it doesn't conflict with the storage layout of the
    318 |  * implementation behind the proxy.
    319 |  */
    320 | contract ERC1967Proxy is Proxy {
```

---

### 9. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 390 行
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    385 | 
    386 | /**
    387 |  * @dev This is an auxiliary contract meant to be assigned as the admin of a {TransparentUpgradeableProxy}. For an
    388 |  * explanation of why you would want to use this see the documentation for {TransparentUpgradeableProxy}.
    389 |  */
>>  390 | contract ProxyAdmin is Ownable {
    391 |     /**
    392 |      * @dev The version of the upgrade interface of the contract. If this getter is missing, both `upgrade(address,address)`
    393 |      * and `upgradeAndCall(address,address,bytes)` are present, and `upgrade` must be used if no function should be called,
    394 |      * while `upgradeAndCall` will invoke the `receive` function if the third argument is the empty byte string.
    395 |      * If the getter returns `"5.0.0"`, only `upgradeAndCall(address,address,bytes)` is present, and the third argument must
```

---

### 10. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 780 行
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    775 |  * Additionally, delegation to the implementation can be triggered manually through the {_fallback} function, or to a
    776 |  * different contract through the {_delegate} function.
    777 |  *
    778 |  * The success and return data of the delegated call will be returned back to the caller of the proxy.
    779 |  */
>>  780 | abstract contract Proxy {
    781 |     /**
    782 |      * @dev Delegates the current call to `implementation`.
    783 |      *
    784 |      * This function does not return to its internal call site, it will return directly to the external caller.
    785 |      */
```

---

### 11. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 857 行
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    852 |  *
    853 |  * This module is used through inheritance. It will make available the modifier
    854 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    855 |  * the owner.
    856 |  */
>>  857 | abstract contract Ownable is Context {
    858 |     address private _owner;
    859 | 
    860 |     /**
    861 |      * @dev The caller account is not authorized to perform an operation.
    862 |      */
```

---

### 12. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 929 行
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    924 |         }
    925 |         _transferOwnership(newOwner);
    926 |     }
    927 | 
    928 |     /**
>>  929 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    930 |      * Internal function without access restriction.
    931 |      */
    932 |     function _transferOwnership(address newOwner) internal virtual {
    933 |         address oldOwner = _owner;
    934 |         _owner = newOwner;
```

---

### 13. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 145 行
- **函数**: `_dispatchUpgradeToAndCall()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    142 |      * This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1.
    143 |      */
    144 |     // solhint-disable-next-line private-vars-leading-underscore
>>  145 |     bytes32 internal constant IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
    146 | 
    147 |     /**
    148 |      * @dev The `implementation` of the proxy is invalid.
```

---

### 14. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 207 行
- **函数**: `upgradeToAndCall()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    204 |      * This is the keccak-256 hash of "eip1967.proxy.admin" subtracted by 1.
    205 |      */
    206 |     // solhint-disable-next-line private-vars-leading-underscore
>>  207 |     bytes32 internal constant ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    208 | 
    209 |     /**
    210 |      * @dev Returns the current admin.
```

---

### 15. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 245 行
- **函数**: `changeAdmin()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    242 |      * This is the keccak-256 hash of "eip1967.proxy.beacon" subtracted by 1.
    243 |      */
    244 |     // solhint-disable-next-line private-vars-leading-underscore
>>  245 |     bytes32 internal constant BEACON_SLOT = 0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50;
    246 | 
    247 |     /**
    248 |      * @dev Returns the current beacon.
```

---

### 16. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x56F516961Fd1ee2A166c9f4755743322a3ccE6BD` 第 787 行
- **函数**: `_delegate()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    784 |      * This function does not return to its internal call site, it will return directly to the external caller.
    785 |      */
    786 |     function _delegate(address implementation) internal virtual {
>>  787 |         assembly {
    788 |             // Copy msg.data. We take full control of memory in this inline assembly
    789 |             // block because it will not return to Solidity code. We overwrite the
    790 |             // Solidity scratch pad at memory position 0.
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*