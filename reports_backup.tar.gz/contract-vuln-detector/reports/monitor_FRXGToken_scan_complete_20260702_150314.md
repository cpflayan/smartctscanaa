# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:03:14
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` |
| contract_name | `FRXGToken` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `shanghai` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655006` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 47 |
| 🟢 LOW | 17 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1425 行
- **函数**: `_update()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1422 | 
   1423 |         if (isBuy && !toExcluded) {
   1424 |             if (to != recoveryContract && to != assuranceContract) {
>> 1425 |                 uint256 elapsed = block.timestamp - deploymentTime;
   1426 |                 require(elapsed >= TRADE_DELAY, "Trading not active yet");
   1427 | 
   1428 |                 if (elapsed < LIMIT_WINDOW) {
```

---

### 2. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1442 行
- **函数**: `_update()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1439 |         }
   1440 | 
   1441 |         if (isSell && !fromExcluded) {
>> 1442 |             uint256 elapsed = block.timestamp - deploymentTime;
   1443 |             require(elapsed >= SELL_DELAY, "Selling not active yet");
   1444 | 
   1445 |             _enforceSellLimit(from, amount);
```

---

### 3. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1582 行
- **函数**: `remainingSellAllowanceUSD()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1579 |     function remainingSellAllowanceUSD(address account) external view returns (uint256) {
   1580 |         if (isExcluded[account]) return type(uint256).max;
   1581 | 
>> 1582 |         uint256 elapsed = block.timestamp - deploymentTime;
   1583 |         if (elapsed < SELL_DELAY) return 0;
   1584 | 
   1585 |         uint sellLimit = type(uint256).max;
```

---

### 4. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1598 行
- **函数**: `remainingBuyAllowanceUSD()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1595 | 
   1596 |     function remainingBuyAllowanceUSD(address account) external view returns (uint256) {
   1597 |         if (account == recoveryContract || isExcluded[account]) return type(uint256).max;
>> 1598 |         uint256 elapsed = block.timestamp - deploymentTime;
   1599 |         if (elapsed < TRADE_DELAY) return 0;
   1600 |         if (elapsed >= LIMIT_WINDOW) return type(uint256).max;
   1601 |         uint256 used = cumulativeBoughtUSD[account];
```

---

### 5. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1630 行
- **函数**: `tradingInfo()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1627 |             uint256 secondsUntilPhase2End      
   1628 |         )
   1629 |     {
>> 1630 |         uint256 elapsed = block.timestamp - deploymentTime;
   1631 | 
   1632 |         tradingActive  = elapsed >= TRADE_DELAY;
   1633 |         sellingActive  = elapsed >= SELL_DELAY;
```

---

### 6. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1227 行
- **函数**: `getReserves()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1224 | }
   1225 | 
   1226 | interface IPancakeV2Pair {
>> 1227 |     function getReserves()
   1228 |         external
   1229 |         view
   1230 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 7. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1344 行
- **函数**: `setPancakeV2Pair()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1341 |         pancakeV2Pair = _pair;
   1342 | 
   1343 |         IPancakeV2Pair pair = IPancakeV2Pair(_pair);
>> 1344 |         (uint112 r0, uint112 r1, uint32 pairTs) = pair.getReserves();
   1345 | 
   1346 |         bool tokenIsToken0 = (pair.token0() == address(this));
   1347 | 
```

---

### 8. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1504 行
- **函数**: `_updateTWAP()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1501 |         if (_pair == address(0)) return;
   1502 | 
   1503 |         IPancakeV2Pair pair = IPancakeV2Pair(_pair);
>> 1504 |         (uint112 r0, uint112 r1, uint32 pairTs) = pair.getReserves();
   1505 |         if (r0 == 0 || r1 == 0) return;
   1506 | 
   1507 |         bool tokenIsToken0 = (pair.token0() == address(this));
```

---

### 9. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1557 行
- **函数**: `_spotUsdValue()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1554 | 
   1555 |     function _spotUsdValue(uint256 tokenAmount, address _pair) private view returns (uint256) {
   1556 |         IPancakeV2Pair pair = IPancakeV2Pair(_pair);
>> 1557 |         (uint112 reserve0, uint112 reserve1, ) = pair.getReserves();
   1558 | 
   1559 |         bool    tokenIsToken0 = (pair.token0() == address(this));
   1560 |         address quoteToken    = tokenIsToken0 ? pair.token1() : pair.token0();
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 40 行
- **函数**: `owner()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     37 |         _;
     38 |     }
     39 | 
>>   40 |     function owner() public view virtual returns (address) {
     41 |         return _owner;
     42 |     }
     43 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 113 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    110 | interface IERC20 {
    111 |     event Transfer(address indexed from, address indexed to, uint256 value);
    112 |     event Approval(address indexed owner, address indexed spender, uint256 value);
>>  113 |     function totalSupply() external view returns (uint256);
    114 |     function balanceOf(address account) external view returns (uint256);
    115 |     function transfer(address to, uint256 value) external returns (bool);
    116 |     function allowance(address owner, address spender) external view returns (uint256);
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 114 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    111 |     event Transfer(address indexed from, address indexed to, uint256 value);
    112 |     event Approval(address indexed owner, address indexed spender, uint256 value);
    113 |     function totalSupply() external view returns (uint256);
>>  114 |     function balanceOf(address account) external view returns (uint256);
    115 |     function transfer(address to, uint256 value) external returns (bool);
    116 |     function allowance(address owner, address spender) external view returns (uint256);
    117 |     function approve(address spender, uint256 value) external returns (bool);
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 115 行
- **函数**: `transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    112 |     event Approval(address indexed owner, address indexed spender, uint256 value);
    113 |     function totalSupply() external view returns (uint256);
    114 |     function balanceOf(address account) external view returns (uint256);
>>  115 |     function transfer(address to, uint256 value) external returns (bool);
    116 |     function allowance(address owner, address spender) external view returns (uint256);
    117 |     function approve(address spender, uint256 value) external returns (bool);
    118 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 116 行
- **函数**: `allowance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    113 |     function totalSupply() external view returns (uint256);
    114 |     function balanceOf(address account) external view returns (uint256);
    115 |     function transfer(address to, uint256 value) external returns (bool);
>>  116 |     function allowance(address owner, address spender) external view returns (uint256);
    117 |     function approve(address spender, uint256 value) external returns (bool);
    118 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    119 | }
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 117 行
- **函数**: `approve()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    114 |     function balanceOf(address account) external view returns (uint256);
    115 |     function transfer(address to, uint256 value) external returns (bool);
    116 |     function allowance(address owner, address spender) external view returns (uint256);
>>  117 |     function approve(address spender, uint256 value) external returns (bool);
    118 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    119 | }
    120 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 118 行
- **函数**: `transferFrom()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    115 |     function transfer(address to, uint256 value) external returns (bool);
    116 |     function allowance(address owner, address spender) external view returns (uint256);
    117 |     function approve(address spender, uint256 value) external returns (bool);
>>  118 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    119 | }
    120 | 
    121 | interface IERC20Metadata is IERC20 {
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 122 行
- **函数**: `name()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    119 | }
    120 | 
    121 | interface IERC20Metadata is IERC20 {
>>  122 |     function name() external view returns (string memory);
    123 |     function symbol() external view returns (string memory);
    124 |     function decimals() external view returns (uint8);
    125 | }
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 123 行
- **函数**: `symbol()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    120 | 
    121 | interface IERC20Metadata is IERC20 {
    122 |     function name() external view returns (string memory);
>>  123 |     function symbol() external view returns (string memory);
    124 |     function decimals() external view returns (uint8);
    125 | }
    126 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 124 行
- **函数**: `decimals()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    121 | interface IERC20Metadata is IERC20 {
    122 |     function name() external view returns (string memory);
    123 |     function symbol() external view returns (string memory);
>>  124 |     function decimals() external view returns (uint8);
    125 | }
    126 | 
    127 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 142 行
- **函数**: `name()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    139 |         _symbol = symbol_;
    140 |     }
    141 | 
>>  142 |     function name() public view virtual returns (string memory) {
    143 |         return _name;
    144 |     }
    145 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 146 行
- **函数**: `symbol()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    143 |         return _name;
    144 |     }
    145 | 
>>  146 |     function symbol() public view virtual returns (string memory) {
    147 |         return _symbol;
    148 |     }
    149 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 150 行
- **函数**: `decimals()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    147 |         return _symbol;
    148 |     }
    149 | 
>>  150 |     function decimals() public view virtual returns (uint8) {
    151 |         return 18;
    152 |     }
    153 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 154 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    151 |         return 18;
    152 |     }
    153 | 
>>  154 |     function totalSupply() public view virtual returns (uint256) {
    155 |         return _totalSupply;
    156 |     }
    157 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 158 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    155 |         return _totalSupply;
    156 |     }
    157 | 
>>  158 |     function balanceOf(address account) public view virtual returns (uint256) {
    159 |         return _balances[account];
    160 |     }
    161 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 162 行
- **函数**: `transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    159 |         return _balances[account];
    160 |     }
    161 | 
>>  162 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    163 |         address owner = _msgSender();
    164 |         _transfer(owner, to, value);
    165 |         return true;
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 168 行
- **函数**: `allowance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    165 |         return true;
    166 |     }
    167 | 
>>  168 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    169 |         return _allowances[owner][spender];
    170 |     }
    171 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 172 行
- **函数**: `approve()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    169 |         return _allowances[owner][spender];
    170 |     }
    171 | 
>>  172 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    173 |         address owner = _msgSender();
    174 |         _approve(owner, spender, value);
    175 |         return true;
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 178 行
- **函数**: `transferFrom()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    175 |         return true;
    176 |     }
    177 | 
>>  178 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    179 |         address spender = _msgSender();
    180 |         _spendAllowance(from, spender, value);
    181 |         _transfer(from, to, value);
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 271 行
- **函数**: `burn()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    268 | 
    269 | abstract contract ERC20Burnable is Context, ERC20 {
    270 | 
>>  271 |     function burn(uint256 value) public virtual {
    272 |         _burn(_msgSender(), value);
    273 |     }
    274 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 275 行
- **函数**: `burnFrom()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    272 |         _burn(_msgSender(), value);
    273 |     }
    274 | 
>>  275 |     function burnFrom(address account, uint256 value) public virtual {
    276 |         _spendAllowance(account, _msgSender(), value);
    277 |         _burn(account, value);
    278 |     }
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1232 行
- **函数**: `token0()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1229 |         view
   1230 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1231 | 
>> 1232 |     function token0() external view returns (address);
   1233 |     function token1() external view returns (address);
   1234 | 
   1235 |     function price0CumulativeLast() external view returns (uint256);
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1233 行
- **函数**: `token1()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1230 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1231 | 
   1232 |     function token0() external view returns (address);
>> 1233 |     function token1() external view returns (address);
   1234 | 
   1235 |     function price0CumulativeLast() external view returns (uint256);
   1236 |     function price1CumulativeLast() external view returns (uint256);
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1235 行
- **函数**: `price0CumulativeLast()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1232 |     function token0() external view returns (address);
   1233 |     function token1() external view returns (address);
   1234 | 
>> 1235 |     function price0CumulativeLast() external view returns (uint256);
   1236 |     function price1CumulativeLast() external view returns (uint256);
   1237 | }
   1238 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1236 行
- **函数**: `price1CumulativeLast()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1233 |     function token1() external view returns (address);
   1234 | 
   1235 |     function price0CumulativeLast() external view returns (uint256);
>> 1236 |     function price1CumulativeLast() external view returns (uint256);
   1237 | }
   1238 | 
   1239 | interface IERC20Decimals {
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1240 行
- **函数**: `decimals()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1237 | }
   1238 | 
   1239 | interface IERC20Decimals {
>> 1240 |     function decimals() external view returns (uint8);
   1241 | }
   1242 | 
   1243 | contract FRXGToken is ERC20, ERC20Burnable, Ownable {
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1336 行
- **函数**: `setPancakeV2Pair()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1333 |         _mint(_recoveryContract, tenPercent);
   1334 |     }
   1335 | 
>> 1336 |     function setPancakeV2Pair(address _pair) external {
   1337 |         require(_pair != address(0), "Zero: pair");
   1338 |         require(msg.sender == owner(), "Not authorized");
   1339 |         require(pancakeV2Pair == address(0), "Pair already Set");
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1368 行
- **函数**: `setExcluded()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1365 |         emit setPair(msg.sender, _pair, block.timestamp);
   1366 |     }
   1367 | 
>> 1368 |     function setExcluded(address account, bool excluded, uint _type) external {
   1369 |         require(account != address(0) && msg.sender == owner(), "Zero: account");
   1370 |         if(_type == 0) {
   1371 |             isExcluded[account] = excluded;
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1384 行
- **函数**: `mint()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1381 |         emit Excluded(msg.sender, account, _type, block.timestamp);
   1382 |     }
   1383 | 
>> 1384 |     function mint(address to, uint256 amount) external {
   1385 |         bool isOwner    = (msg.sender == owner());
   1386 | 
   1387 |         require(isOwner, "Not authorized to mint");
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1575 行
- **函数**: `getTokenPrice()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1572 |         return (fixedDec * tokenAmount) / 1e18;
   1573 |     }
   1574 | 
>> 1575 |     function getTokenPrice(uint256 tokenAmount) external view returns (uint256) {
   1576 |         return _usdValue(tokenAmount);
   1577 |     }
   1578 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1579 行
- **函数**: `remainingSellAllowanceUSD()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1576 |         return _usdValue(tokenAmount);
   1577 |     }
   1578 | 
>> 1579 |     function remainingSellAllowanceUSD(address account) external view returns (uint256) {
   1580 |         if (isExcluded[account]) return type(uint256).max;
   1581 | 
   1582 |         uint256 elapsed = block.timestamp - deploymentTime;
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1596 行
- **函数**: `remainingBuyAllowanceUSD()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1593 |         return used >= sellLimit ? 0 : sellLimit - used;
   1594 |     }
   1595 | 
>> 1596 |     function remainingBuyAllowanceUSD(address account) external view returns (uint256) {
   1597 |         if (account == recoveryContract || isExcluded[account]) return type(uint256).max;
   1598 |         uint256 elapsed = block.timestamp - deploymentTime;
   1599 |         if (elapsed < TRADE_DELAY) return 0;
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1605 行
- **函数**: `getCurDay()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1602 |         return used >= MAX_BUY_USD ? 0 : MAX_BUY_USD - used;
   1603 |     }
   1604 | 
>> 1605 |     function getCurDay() public view returns (uint256) {
   1606 |         return (block.timestamp - deploymentTime) / DAY_TIME_WINDOW;
   1607 |     }
   1608 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1609 行
- **函数**: `getCurMonth()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1606 |         return (block.timestamp - deploymentTime) / DAY_TIME_WINDOW;
   1607 |     }
   1608 | 
>> 1609 |     function getCurMonth() public view returns(uint) {
   1610 |         return (block.timestamp - deploymentTime) / MONTH_TIME_WINDOW;
   1611 |     }
   1612 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1613 行
- **函数**: `tradingInfo()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1610 |         return (block.timestamp - deploymentTime) / MONTH_TIME_WINDOW;
   1611 |     }
   1612 | 
>> 1613 |     function tradingInfo() external view returns (
   1614 |             bool    tradingActive,
   1615 |             bool    sellingActive,
   1616 |             bool    buyLimitActive,
```

---

### 45. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 19 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     14 |     function _contextSuffixLength() internal view virtual returns (uint256) {
     15 |         return 0;
     16 |     }
     17 | }
     18 | 
>>   19 | abstract contract Ownable is Context {
     20 |     address private _owner;
     21 | 
     22 |     error OwnableUnauthorizedAccount(address account);
     23 | 
     24 |     error OwnableInvalidOwner(address owner);
```

---

### 46. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 127 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    122 |     function name() external view returns (string memory);
    123 |     function symbol() external view returns (string memory);
    124 |     function decimals() external view returns (uint8);
    125 | }
    126 | 
>>  127 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    128 |     mapping(address account => uint256) private _balances;
    129 | 
    130 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    131 | 
    132 |     uint256 private _totalSupply;
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1243 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1238 | 
   1239 | interface IERC20Decimals {
   1240 |     function decimals() external view returns (uint8);
   1241 | }
   1242 | 
>> 1243 | contract FRXGToken is ERC20, ERC20Burnable, Ownable {
   1244 |     uint256 private constant MAX_SUPPLY = 11_400_000 * 1e18;
   1245 |     uint256 private constant MAX_BUY_USD  = 500 * 1e18;
   1246 |     uint256 private constant DAILY_SELL_USD_90_DAYS = 10 * 1e18;
   1247 |     uint256 private constant DAILY_SELL_USD_180_DAYS = 100 * 1e18;
   1248 | 
```

---

### 48. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1352 行
- **函数**: `setPancakeV2Pair()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1349 |             ? pair.price0CumulativeLast()
   1350 |             : pair.price1CumulativeLast();
   1351 | 
>> 1352 |         uint32 currentTs    = uint32(block.timestamp);
   1353 |         uint32 sincePairUpd = currentTs - pairTs;
   1354 |         if (sincePairUpd > 0 && r0 > 0 && r1 > 0) {
   1355 |             uint256 spotUQ = tokenIsToken0
```

---

### 49. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1365 行
- **函数**: `setPancakeV2Pair()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1362 |         _twapTimestampLast = currentTs;    
   1363 | 
   1364 |         tradingEnabled = true;
>> 1365 |         emit setPair(msg.sender, _pair, block.timestamp);
   1366 |     }
   1367 | 
   1368 |     function setExcluded(address account, bool excluded, uint _type) external {
```

---

### 50. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1381 行
- **函数**: `setExcluded()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1378 |             assuranceContract = account;
   1379 |             isExcluded[account] = excluded;
   1380 |         }
>> 1381 |         emit Excluded(msg.sender, account, _type, block.timestamp);
   1382 |     }
   1383 | 
   1384 |     function mint(address to, uint256 amount) external {
```

---

### 51. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1390 行
- **函数**: `mint()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1387 |         require(isOwner, "Not authorized to mint");
   1388 | 
   1389 |         require(
>> 1390 |             block.timestamp >= deploymentTime + MINT_UNLOCK,
   1391 |             "Owner minting locked"
   1392 |         );
   1393 | 
```

---

### 52. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1425 行
- **函数**: `_update()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1422 | 
   1423 |         if (isBuy && !toExcluded) {
   1424 |             if (to != recoveryContract && to != assuranceContract) {
>> 1425 |                 uint256 elapsed = block.timestamp - deploymentTime;
   1426 |                 require(elapsed >= TRADE_DELAY, "Trading not active yet");
   1427 | 
   1428 |                 if (elapsed < LIMIT_WINDOW) {
```

---

### 53. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1442 行
- **函数**: `_update()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1439 |         }
   1440 | 
   1441 |         if (isSell && !fromExcluded) {
>> 1442 |             uint256 elapsed = block.timestamp - deploymentTime;
   1443 |             require(elapsed >= SELL_DELAY, "Selling not active yet");
   1444 | 
   1445 |             _enforceSellLimit(from, amount);
```

---

### 54. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1474 行
- **函数**: `_enforceSellLimit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1471 |         uint256 newCum  = cumulativeSoldUSD[seller][bucket] + usdVal;
   1472 | 
   1473 |         uint sellLimit = type(uint256).max;
>> 1474 |         if(block.timestamp - deploymentTime <= LIMIT_WINDOW) {
   1475 |             sellLimit = DAILY_SELL_USD_90_DAYS;
   1476 |         } else if(block.timestamp - deploymentTime <= SELL_LIMIT_WINDOW) {
   1477 |             sellLimit = DAILY_SELL_USD_180_DAYS;
```

---

### 55. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1476 行
- **函数**: `_enforceSellLimit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1473 |         uint sellLimit = type(uint256).max;
   1474 |         if(block.timestamp - deploymentTime <= LIMIT_WINDOW) {
   1475 |             sellLimit = DAILY_SELL_USD_90_DAYS;
>> 1476 |         } else if(block.timestamp - deploymentTime <= SELL_LIMIT_WINDOW) {
   1477 |             sellLimit = DAILY_SELL_USD_180_DAYS;
   1478 |         }
   1479 | 
```

---

### 56. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1513 行
- **函数**: `_updateTWAP()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1510 |             ? pair.price0CumulativeLast()
   1511 |             : pair.price1CumulativeLast();
   1512 | 
>> 1513 |         uint32 currentTs    = uint32(block.timestamp);          
   1514 |         uint32 sincePairUpd = currentTs - pairTs;               
   1515 |         if (sincePairUpd > 0) {
   1516 |             uint256 spotUQ = tokenIsToken0
```

---

### 57. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1582 行
- **函数**: `remainingSellAllowanceUSD()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1579 |     function remainingSellAllowanceUSD(address account) external view returns (uint256) {
   1580 |         if (isExcluded[account]) return type(uint256).max;
   1581 | 
>> 1582 |         uint256 elapsed = block.timestamp - deploymentTime;
   1583 |         if (elapsed < SELL_DELAY) return 0;
   1584 | 
   1585 |         uint sellLimit = type(uint256).max;
```

---

### 58. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1586 行
- **函数**: `remainingSellAllowanceUSD()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1583 |         if (elapsed < SELL_DELAY) return 0;
   1584 | 
   1585 |         uint sellLimit = type(uint256).max;
>> 1586 |         if(block.timestamp - deploymentTime <= LIMIT_WINDOW) {
   1587 |             sellLimit = DAILY_SELL_USD_90_DAYS;
   1588 |         } else if(block.timestamp - deploymentTime <= SELL_LIMIT_WINDOW) {
   1589 |             sellLimit = DAILY_SELL_USD_180_DAYS;
```

---

### 59. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1588 行
- **函数**: `remainingSellAllowanceUSD()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1585 |         uint sellLimit = type(uint256).max;
   1586 |         if(block.timestamp - deploymentTime <= LIMIT_WINDOW) {
   1587 |             sellLimit = DAILY_SELL_USD_90_DAYS;
>> 1588 |         } else if(block.timestamp - deploymentTime <= SELL_LIMIT_WINDOW) {
   1589 |             sellLimit = DAILY_SELL_USD_180_DAYS;
   1590 |         }
   1591 | 
```

---

### 60. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1598 行
- **函数**: `remainingBuyAllowanceUSD()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1595 | 
   1596 |     function remainingBuyAllowanceUSD(address account) external view returns (uint256) {
   1597 |         if (account == recoveryContract || isExcluded[account]) return type(uint256).max;
>> 1598 |         uint256 elapsed = block.timestamp - deploymentTime;
   1599 |         if (elapsed < TRADE_DELAY) return 0;
   1600 |         if (elapsed >= LIMIT_WINDOW) return type(uint256).max;
   1601 |         uint256 used = cumulativeBoughtUSD[account];
```

---

### 61. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1606 行
- **函数**: `getCurDay()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1603 |     }
   1604 | 
   1605 |     function getCurDay() public view returns (uint256) {
>> 1606 |         return (block.timestamp - deploymentTime) / DAY_TIME_WINDOW;
   1607 |     }
   1608 | 
   1609 |     function getCurMonth() public view returns(uint) {
```

---

### 62. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1610 行
- **函数**: `getCurMonth()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1607 |     }
   1608 | 
   1609 |     function getCurMonth() public view returns(uint) {
>> 1610 |         return (block.timestamp - deploymentTime) / MONTH_TIME_WINDOW;
   1611 |     }
   1612 | 
   1613 |     function tradingInfo() external view returns (
```

---

### 63. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1630 行
- **函数**: `tradingInfo()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1627 |             uint256 secondsUntilPhase2End      
   1628 |         )
   1629 |     {
>> 1630 |         uint256 elapsed = block.timestamp - deploymentTime;
   1631 | 
   1632 |         tradingActive  = elapsed >= TRADE_DELAY;
   1633 |         sellingActive  = elapsed >= SELL_DELAY;
```

---

### 64. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x61D19D71F8c6AB88902c9BBF3F712a03C5B20529` 第 1145 行
- **函数**: `log2()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1142 |         r |= SafeCast.toUint((x >> r) > 0xf) << 2;
   1143 | 
   1144 |         assembly ("memory-safe") {
>> 1145 |             r := or(r, byte(shr(r, x), 0x0000010102020202030303030303030300000000000000000000000000000000))
   1146 |         }
   1147 |     }
   1148 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*