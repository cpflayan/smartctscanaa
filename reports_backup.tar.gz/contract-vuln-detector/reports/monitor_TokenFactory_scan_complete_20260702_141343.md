# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:13:43
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xEECa71A751AB52F25A371065d168E0FCc3c8b00D` |
| contract_name | `TokenFactory` |
| compiler_version | `v0.4.19+commit.c4cbbb05` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `None` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 6 |
| 🟢 LOW | 1 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0xEECa71A751AB52F25A371065d168E0FCc3c8b00D` 第 99 行
- **函数**: `TokenFactory()`
- **合约**: `ERC20Basic`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
     96 |   uint256 public decimals;
     97 | 
     98 | 
>>   99 |   function TokenFactory(uint256 _initialAmount, string _tokenName, uint8 _decimalUnits, string _tokenSymbol) {
    100 |     balances[msg.sender] = _initialAmount;
    101 |     totalSupply = _initialAmount;
    102 |     name = _tokenName;
```

---

### 2. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xEECa71A751AB52F25A371065d168E0FCc3c8b00D` 第 4 行
- **合约**: `ERC20Basic`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      1 | pragma solidity ^0.4.11;
      2 | 
      3 | 
>>    4 | contract ERC20Basic {
      5 |   uint256 public totalSupply;
      6 |   function balanceOf(address who) constant returns (uint256);
      7 |   function transfer(address to, uint256 value) returns (bool);
      8 |   event Transfer(address indexed from, address indexed to, uint256 value);
      9 | }
```

---

### 3. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xEECa71A751AB52F25A371065d168E0FCc3c8b00D` 第 12 行
- **合约**: `ERC20Basic`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      7 |   function transfer(address to, uint256 value) returns (bool);
      8 |   event Transfer(address indexed from, address indexed to, uint256 value);
      9 | }
     10 | 
     11 | 
>>   12 | contract ERC20 is ERC20Basic {
     13 |   function allowance(address owner, address spender) constant returns (uint256);
     14 |   function transferFrom(address from, address to, uint256 value) returns (bool);
     15 |   function approve(address spender, uint256 value) returns (bool);
     16 |   event Approval(address indexed owner, address indexed spender, uint256 value);
     17 | }
```

---

### 4. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xEECa71A751AB52F25A371065d168E0FCc3c8b00D` 第 45 行
- **合约**: `ERC20Basic`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     40 |     return c;
     41 |   }
     42 | }
     43 | 
     44 | 
>>   45 | contract BasicToken is ERC20Basic {
     46 |   using SafeMath for uint256;
     47 | 
     48 |   mapping(address => uint256) balances;
     49 | 
     50 |   function transfer(address _to, uint256 _value) returns (bool) {
```

---

### 5. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xEECa71A751AB52F25A371065d168E0FCc3c8b00D` 第 63 行
- **合约**: `ERC20Basic`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     58 |     return balances[_owner];
     59 |   }
     60 | 
     61 | }
     62 | 
>>   63 | contract StandardToken is ERC20, BasicToken {
     64 | 
     65 |   mapping (address => mapping (address => uint256)) allowed;
     66 | 
     67 |   function transferFrom(address _from, address _to, uint256 _value) returns (bool) {
     68 |     var _allowance = allowed[_from][msg.sender];
```

---

### 6. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xEECa71A751AB52F25A371065d168E0FCc3c8b00D` 第 92 行
- **合约**: `ERC20Basic`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     87 |   }
     88 | 
     89 | }
     90 | 
     91 | 
>>   92 | contract TokenFactory is StandardToken {
     93 | 
     94 |   string public name;
     95 |   string public symbol;
     96 |   uint256 public decimals;
     97 | 
```

---

### 7. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0xEECa71A751AB52F25A371065d168E0FCc3c8b00D` 第 1 行
- **合约**: `ERC20Basic`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
>>    1 | pragma solidity ^0.4.11;
      2 | 
      3 | 
      4 | contract ERC20Basic {
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*