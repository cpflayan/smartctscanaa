# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:51:27
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` |
| contract_name | `BurnableTeamToken` |
| compiler_version | `v0.6.12+commit.27d51765` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655005` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 26 |
| 🟢 LOW | 0 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 41 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     38 |     /**
     39 |      * @dev Returns the amount of tokens in existence.
     40 |      */
>>   41 |     function totalSupply() external view returns (uint256);
     42 | 
     43 |     /**
     44 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 46 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     43 |     /**
     44 |      * @dev Returns the amount of tokens owned by `account`.
     45 |      */
>>   46 |     function balanceOf(address account) external view returns (uint256);
     47 | 
     48 |     /**
     49 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 55 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     52 |      *
     53 |      * Emits a {Transfer} event.
     54 |      */
>>   55 |     function transfer(address recipient, uint256 amount) external returns (bool);
     56 | 
     57 |     /**
     58 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 64 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     61 |      *
     62 |      * This value changes when {approve} or {transferFrom} are called.
     63 |      */
>>   64 |     function allowance(address owner, address spender) external view returns (uint256);
     65 | 
     66 |     /**
     67 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 80 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     77 |      *
     78 |      * Emits an {Approval} event.
     79 |      */
>>   80 |     function approve(address spender, uint256 amount) external returns (bool);
     81 | 
     82 |     /**
     83 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 91 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     88 |      *
     89 |      * Emits a {Transfer} event.
     90 |      */
>>   91 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     92 | 
     93 |     /**
     94 |      * @dev Emitted when `value` tokens are moved from one account (`from`) to
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 388 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    385 |     /**
    386 |      * @dev Returns the name of the token.
    387 |      */
>>  388 |     function name() public view virtual returns (string memory) {
    389 |         return _name;
    390 |     }
    391 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 396 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    393 |      * @dev Returns the symbol of the token, usually a shorter version of the
    394 |      * name.
    395 |      */
>>  396 |     function symbol() public view virtual returns (string memory) {
    397 |         return _symbol;
    398 |     }
    399 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 413 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    410 |      * no way affects any of the arithmetic of the contract, including
    411 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    412 |      */
>>  413 |     function decimals() public view virtual returns (uint8) {
    414 |         return _decimals;
    415 |     }
    416 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 420 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    417 |     /**
    418 |      * @dev See {IERC20-totalSupply}.
    419 |      */
>>  420 |     function totalSupply() public view virtual override returns (uint256) {
    421 |         return _totalSupply;
    422 |     }
    423 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 427 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    424 |     /**
    425 |      * @dev See {IERC20-balanceOf}.
    426 |      */
>>  427 |     function balanceOf(address account) public view virtual override returns (uint256) {
    428 |         return _balances[account];
    429 |     }
    430 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 439 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    436 |      * - `recipient` cannot be the zero address.
    437 |      * - the caller must have a balance of at least `amount`.
    438 |      */
>>  439 |     function transfer(address recipient, uint256 amount) public virtual override returns (bool) {
    440 |         _transfer(_msgSender(), recipient, amount);
    441 |         return true;
    442 |     }
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 447 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    444 |     /**
    445 |      * @dev See {IERC20-allowance}.
    446 |      */
>>  447 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    448 |         return _allowances[owner][spender];
    449 |     }
    450 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 458 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    455 |      *
    456 |      * - `spender` cannot be the zero address.
    457 |      */
>>  458 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    459 |         _approve(_msgSender(), spender, amount);
    460 |         return true;
    461 |     }
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 476 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    473 |      * - the caller must have allowance for ``sender``'s tokens of at least
    474 |      * `amount`.
    475 |      */
>>  476 |     function transferFrom(address sender, address recipient, uint256 amount) public virtual override returns (bool) {
    477 |         _transfer(sender, recipient, amount);
    478 |         _approve(sender, _msgSender(), _allowances[sender][_msgSender()].sub(amount, "ERC20: transfer amount exceeds allowance"));
    479 |         return true;
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 494 行
- **函数**: `increaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    491 |      *
    492 |      * - `spender` cannot be the zero address.
    493 |      */
>>  494 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    495 |         _approve(_msgSender(), spender, _allowances[_msgSender()][spender].add(addedValue));
    496 |         return true;
    497 |     }
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 513 行
- **函数**: `decreaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    510 |      * - `spender` must have allowance for the caller of at least
    511 |      * `subtractedValue`.
    512 |      */
>>  513 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    514 |         _approve(_msgSender(), spender, _allowances[_msgSender()][spender].sub(subtractedValue, "ERC20: decreased allowance below zero"));
    515 |         return true;
    516 |     }
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 676 行
- **函数**: `metadata()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    673 |     /**
    674 |      * @dev Returns the metadata of the token, as IPFS hash
    675 |      */
>>  676 |     function metadata() public view virtual returns (string memory) {
    677 |         return metadata_ipfs_hash;
    678 |     }
    679 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 709 行
- **函数**: `burn()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    706 |      *
    707 |      * See {ERC20-_burn}.
    708 |      */
>>  709 |     function burn(uint256 amount) public virtual {
    710 |         _burn(_msgSender(), amount);
    711 |     }
    712 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 724 行
- **函数**: `burnFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    721 |      * - the caller must have allowance for ``accounts``'s tokens of at least
    722 |      * `amount`.
    723 |      */
>>  724 |     function burnFrom(address account, uint256 amount) public virtual {
    725 |         uint256 decreasedAllowance = allowance(account, _msgSender()).sub(amount, "ERC20: burn amount exceeds allowance");
    726 | 
    727 |         _approve(account, _msgSender(), decreasedAllowance);
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 767 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    764 |     /**
    765 |      * @dev Returns the address of the current owner.
    766 |      */
>>  767 |     function owner() public view virtual returns (address) {
    768 |         return _owner;
    769 |     }
    770 | 
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 16 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     11 |  * via msg.sender and msg.data, they should not be accessed in such a direct
     12 |  * manner, since when dealing with GSN meta-transactions the account sending and
     13 |  * paying for execution may not be the actual sender (as far as an application
     14 |  * is concerned).
     15 |  *
>>   16 |  * This contract is only required for intermediate, library-like contracts.
     17 |  */
     18 | abstract contract Context {
     19 |     function _msgSender() internal view virtual returns (address payable) {
     20 |         return msg.sender;
     21 |     }
```

---

### 23. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 357 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    352 |  *
    353 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    354 |  * functions have been added to mitigate the well-known issues around setting
    355 |  * allowances. See {IERC20-approve}.
    356 |  */
>>  357 | contract ERC20 is Context, IERC20 {
    358 |     using SafeMath for uint256;
    359 | 
    360 |     mapping (address => uint256) private _balances;
    361 | 
    362 |     mapping (address => mapping (address => uint256)) private _allowances;
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 640 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    635 | 
    636 | pragma solidity >=0.6.2 <0.8.0;
    637 | 
    638 | 
    639 | 
>>  640 | contract TeamToken is ERC20 {
    641 |     event TeamFinanceTokenMint(address owner);
    642 |     event MetadataUpdated(string metadata_ipfs_hash);
    643 | 
    644 |     modifier checkIsAddressValid(address ethAddress)
    645 |     {
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 750 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    745 |  *
    746 |  * This module is used through inheritance. It will make available the modifier
    747 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    748 |  * the owner.
    749 |  */
>>  750 | abstract contract Ownable is Context {
    751 |     address private _owner;
    752 | 
    753 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    754 | 
    755 |     /**
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf9A2e332B1ecD3D6AB51618432D68C8D5995C992` 第 810 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    805 | pragma solidity >=0.6.2 <0.8.0;
    806 | 
    807 | 
    808 | 
    809 | 
>>  810 | contract BurnableTeamToken is TeamToken, ERC20Burnable, Ownable {
    811 |     constructor(
    812 |         string memory name,
    813 |         string memory symbol,
    814 |         uint8 decimals,
    815 |         uint256 supply,
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*