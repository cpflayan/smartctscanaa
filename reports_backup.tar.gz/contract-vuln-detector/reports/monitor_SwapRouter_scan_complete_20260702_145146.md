# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:51:46
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x1b81D678ffb9C0263b24A97847620C99d213eB14` |
| contract_name | `SwapRouter` |
| compiler_version | `v0.7.6+commit.7338295f` |
| optimization_used | `True` |
| runs | `1000000` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `True` |
| implementation | `0x1b81d678ffb9c0263b24a97847620c99d213eb14` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/drafts/IERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@pancakeswap/v3-core/contracts/interfaces/callback/IPancakeV3SwapCallback.sol', '@pancakeswap/v3-core/contracts/interfaces/IPancakeV3Pool.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolActions.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolDerivedState.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolEvents.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolImmutables.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolOwnerActions.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolState.sol', '@pancakeswap/v3-core/contracts/libraries/LowGasSafeMath.sol', '@pancakeswap/v3-core/contracts/libraries/SafeCast.sol', '@pancakeswap/v3-core/contracts/libraries/TickMath.sol', 'contracts/base/BlockTimestamp.sol', 'contracts/base/Multicall.sol', 'contracts/base/PeripheryImmutableState.sol', 'contracts/base/PeripheryPayments.sol', 'contracts/base/PeripheryPaymentsWithFee.sol', 'contracts/base/PeripheryValidation.sol', 'contracts/base/SelfPermit.sol', 'contracts/interfaces/external/IERC20PermitAllowed.sol', 'contracts/interfaces/external/IWETH9.sol', 'contracts/interfaces/IMulticall.sol', 'contracts/interfaces/IPeripheryImmutableState.sol', 'contracts/interfaces/IPeripheryPayments.sol', 'contracts/interfaces/IPeripheryPaymentsWithFee.sol', 'contracts/interfaces/ISelfPermit.sol', 'contracts/interfaces/ISwapRouter.sol', 'contracts/libraries/BytesLib.sol', 'contracts/libraries/CallbackValidation.sol', 'contracts/libraries/Path.sol', 'contracts/libraries/PoolAddress.sol', 'contracts/libraries/TransferHelper.sol', 'contracts/SwapRouter.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655005` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 50 |
| 🟢 LOW | 30 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 986 行
- **函数**: `multicall()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    983 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
    984 |         results = new bytes[](data.length);
    985 |         for (uint256 i = 0; i < data.length; i++) {
>>  986 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
    987 | 
    988 |             if (!success) {
    989 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
```

---

### 2. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1835 行
- **函数**: `safeTransferFrom()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1832 |         uint256 value
   1833 |     ) internal {
   1834 |         (bool success, bytes memory data) =
>> 1835 |             token.call(abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, value));
   1836 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'STF');
   1837 |     }
   1838 | 
```

---

### 3. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1849 行
- **函数**: `safeTransfer()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1846 |         address to,
   1847 |         uint256 value
   1848 |     ) internal {
>> 1849 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transfer.selector, to, value));
   1850 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'ST');
   1851 |     }
   1852 | 
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1863 行
- **函数**: `safeApprove()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1860 |         address to,
   1861 |         uint256 value
   1862 |     ) internal {
>> 1863 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.approve.selector, to, value));
   1864 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'SA');
   1865 |     }
   1866 | 
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1872 行
- **函数**: `safeTransferETH()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1869 |     /// @param to The destination of the transfer
   1870 |     /// @param value The value to be transferred
   1871 |     function safeTransferETH(address to, uint256 value) internal {
>> 1872 |         (bool success, ) = to.call{value: value}(new bytes(0));
   1873 |         require(success, 'STE');
   1874 |     }
   1875 | }
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 46 行
- **函数**: `nonces()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     43 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
     44 |      * prevents a signature from being used multiple times.
     45 |      */
>>   46 |     function nonces(address owner) external view returns (uint256);
     47 | 
     48 |     /**
     49 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 52 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     49 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
     50 |      */
     51 |     // solhint-disable-next-line func-name-mixedcase
>>   52 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
     53 | }
     54 | 
     55 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 69 行
- **函数**: `totalSupply()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     66 |     /**
     67 |      * @dev Returns the amount of tokens in existence.
     68 |      */
>>   69 |     function totalSupply() external view returns (uint256);
     70 | 
     71 |     /**
     72 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 74 行
- **函数**: `balanceOf()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     71 |     /**
     72 |      * @dev Returns the amount of tokens owned by `account`.
     73 |      */
>>   74 |     function balanceOf(address account) external view returns (uint256);
     75 | 
     76 |     /**
     77 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 83 行
- **函数**: `transfer()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     80 |      *
     81 |      * Emits a {Transfer} event.
     82 |      */
>>   83 |     function transfer(address recipient, uint256 amount) external returns (bool);
     84 | 
     85 |     /**
     86 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 92 行
- **函数**: `allowance()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     89 |      *
     90 |      * This value changes when {approve} or {transferFrom} are called.
     91 |      */
>>   92 |     function allowance(address owner, address spender) external view returns (uint256);
     93 | 
     94 |     /**
     95 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 108 行
- **函数**: `approve()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    105 |      *
    106 |      * Emits an {Approval} event.
    107 |      */
>>  108 |     function approve(address spender, uint256 amount) external returns (bool);
    109 | 
    110 |     /**
    111 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 119 行
- **函数**: `transferFrom()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    116 |      *
    117 |      * Emits a {Transfer} event.
    118 |      */
>>  119 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    120 | 
    121 |     /**
    122 |      * @dev Emitted when `value` tokens are moved from one account (`from`) to
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 485 行
- **函数**: `factory()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    482 | interface IPancakeV3PoolImmutables {
    483 |     /// @notice The contract that deployed the pool, which must adhere to the IPancakeV3Factory interface
    484 |     /// @return The contract address
>>  485 |     function factory() external view returns (address);
    486 | 
    487 |     /// @notice The first of the two tokens of the pool, sorted by address
    488 |     /// @return The token contract address
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 489 行
- **函数**: `token0()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    486 | 
    487 |     /// @notice The first of the two tokens of the pool, sorted by address
    488 |     /// @return The token contract address
>>  489 |     function token0() external view returns (address);
    490 | 
    491 |     /// @notice The second of the two tokens of the pool, sorted by address
    492 |     /// @return The token contract address
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 493 行
- **函数**: `token1()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    490 | 
    491 |     /// @notice The second of the two tokens of the pool, sorted by address
    492 |     /// @return The token contract address
>>  493 |     function token1() external view returns (address);
    494 | 
    495 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
    496 |     /// @return The fee
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 497 行
- **函数**: `fee()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    494 | 
    495 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
    496 |     /// @return The fee
>>  497 |     function fee() external view returns (uint24);
    498 | 
    499 |     /// @notice The pool tick spacing
    500 |     /// @dev Ticks can only be used at multiples of this value, minimum of 1 and always positive
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 504 行
- **函数**: `tickSpacing()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    501 |     /// e.g.: a tickSpacing of 3 means ticks can be initialized every 3rd tick, i.e., ..., -6, -3, 0, 3, 6, ...
    502 |     /// This value is an int24 to avoid casting even though it is always positive.
    503 |     /// @return The tick spacing
>>  504 |     function tickSpacing() external view returns (int24);
    505 | 
    506 |     /// @notice The maximum amount of position liquidity that can use any tick in the range
    507 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 510 行
- **函数**: `maxLiquidityPerTick()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    507 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
    508 |     /// also prevents out-of-range liquidity from being used to prevent adding in-range liquidity to a pool
    509 |     /// @return The max amount of liquidity per tick
>>  510 |     function maxLiquidityPerTick() external view returns (uint128);
    511 | }
    512 | 
    513 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 581 行
- **函数**: `feeGrowthGlobal0X128()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    578 | 
    579 |     /// @notice The fee growth as a Q128.128 fees of token0 collected per unit of liquidity for the entire life of the pool
    580 |     /// @dev This value can overflow the uint256
>>  581 |     function feeGrowthGlobal0X128() external view returns (uint256);
    582 | 
    583 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
    584 |     /// @dev This value can overflow the uint256
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 585 行
- **函数**: `feeGrowthGlobal1X128()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    582 | 
    583 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
    584 |     /// @dev This value can overflow the uint256
>>  585 |     function feeGrowthGlobal1X128() external view returns (uint256);
    586 | 
    587 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
    588 |     /// @dev Protocol fees will never exceed uint128 max in either token
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 589 行
- **函数**: `protocolFees()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    586 | 
    587 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
    588 |     /// @dev Protocol fees will never exceed uint128 max in either token
>>  589 |     function protocolFees() external view returns (uint128 token0, uint128 token1);
    590 | 
    591 |     /// @notice The currently in range liquidity available to the pool
    592 |     /// @dev This value has no relationship to the total liquidity across all ticks
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 593 行
- **函数**: `liquidity()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    590 | 
    591 |     /// @notice The currently in range liquidity available to the pool
    592 |     /// @dev This value has no relationship to the total liquidity across all ticks
>>  593 |     function liquidity() external view returns (uint128);
    594 | 
    595 |     /// @notice Look up information about a specific tick in the pool
    596 |     /// @param tick The tick to look up
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 624 行
- **函数**: `tickBitmap()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    621 |         );
    622 | 
    623 |     /// @notice Returns 256 packed tick initialized boolean values. See TickBitmap for more information
>>  624 |     function tickBitmap(int16 wordPosition) external view returns (uint256);
    625 | 
    626 |     /// @notice Returns the information about a position by the position's key
    627 |     /// @param key The position's key is a hash of a preimage composed by the owner, tickLower and tickUpper
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 983 行
- **函数**: `multicall()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    980 | /// @notice Enables calling multiple methods in a single call to the contract
    981 | abstract contract Multicall is IMulticall {
    982 |     /// @inheritdoc IMulticall
>>  983 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
    984 |         results = new bytes[](data.length);
    985 |         for (uint256 i = 0; i < data.length; i++) {
    986 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1048 行
- **函数**: `unwrapWETH9()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1045 |     }
   1046 | 
   1047 |     /// @inheritdoc IPeripheryPayments
>> 1048 |     function unwrapWETH9(uint256 amountMinimum, address recipient) public payable override {
   1049 |         uint256 balanceWETH9 = IWETH9(WETH9).balanceOf(address(this));
   1050 |         require(balanceWETH9 >= amountMinimum, 'Insufficient WETH9');
   1051 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1073 行
- **函数**: `refundETH()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1070 |     }
   1071 | 
   1072 |     /// @inheritdoc IPeripheryPayments
>> 1073 |     function refundETH() external payable override {
   1074 |         if (address(this).balance > 0) TransferHelper.safeTransferETH(msg.sender, address(this).balance);
   1075 |     }
   1076 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1284 行
- **函数**: `deposit()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1281 | /// @title Interface for WETH9
   1282 | interface IWETH9 is IERC20 {
   1283 |     /// @notice Deposit ether to get wrapped ether
>> 1284 |     function deposit() external payable;
   1285 | 
   1286 |     /// @notice Withdraw wrapped ether to get ether
   1287 |     function withdraw(uint256) external;
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1304 行
- **函数**: `multicall()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1301 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   1302 |     /// @param data The encoded function data for each of the calls to make to this contract
   1303 |     /// @return results The results from each of the calls passed in via data
>> 1304 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results);
   1305 | }
   1306 | 
   1307 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1317 行
- **函数**: `deployer()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1314 | /// @notice Functions that return immutable state of the router
   1315 | interface IPeripheryImmutableState {
   1316 |     /// @return Returns the address of the PancakeSwap V3 deployer
>> 1317 |     function deployer() external view returns (address);
   1318 | 
   1319 |     /// @return Returns the address of the PancakeSwap V3 factory
   1320 |     function factory() external view returns (address);
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1320 行
- **函数**: `factory()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1317 |     function deployer() external view returns (address);
   1318 | 
   1319 |     /// @return Returns the address of the PancakeSwap V3 factory
>> 1320 |     function factory() external view returns (address);
   1321 | 
   1322 |     /// @return Returns the address of WETH9
   1323 |     function WETH9() external view returns (address);
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1323 行
- **函数**: `WETH9()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1320 |     function factory() external view returns (address);
   1321 | 
   1322 |     /// @return Returns the address of WETH9
>> 1323 |     function WETH9() external view returns (address);
   1324 | }
   1325 | 
   1326 | 
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1339 行
- **函数**: `unwrapWETH9()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1336 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   1337 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
   1338 |     /// @param recipient The address receiving ETH
>> 1339 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external payable;
   1340 | 
   1341 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   1342 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1345 行
- **函数**: `refundETH()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1342 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
   1343 |     /// that use ether for the input amount. And in PancakeSwap Router, this would be called 
   1344 |     /// at the very end of swap
>> 1345 |     function refundETH() external payable;
   1346 | 
   1347 |     /// @notice Transfers the full amount of a token held by this contract to recipient
   1348 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1498 行
- **函数**: `exactInputSingle()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1495 |     /// @notice Swaps `amountIn` of one token for as much as possible of another token
   1496 |     /// @param params The parameters necessary for the swap, encoded as `ExactInputSingleParams` in calldata
   1497 |     /// @return amountOut The amount of the received token
>> 1498 |     function exactInputSingle(ExactInputSingleParams calldata params) external payable returns (uint256 amountOut);
   1499 | 
   1500 |     struct ExactInputParams {
   1501 |         bytes path;
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1511 行
- **函数**: `exactInput()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1508 |     /// @notice Swaps `amountIn` of one token for as much as possible of another along the specified path
   1509 |     /// @param params The parameters necessary for the multi-hop swap, encoded as `ExactInputParams` in calldata
   1510 |     /// @return amountOut The amount of the received token
>> 1511 |     function exactInput(ExactInputParams calldata params) external payable returns (uint256 amountOut);
   1512 | 
   1513 |     struct ExactOutputSingleParams {
   1514 |         address tokenIn;
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1527 行
- **函数**: `exactOutputSingle()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1524 |     /// @notice Swaps as little as possible of one token for `amountOut` of another token
   1525 |     /// @param params The parameters necessary for the swap, encoded as `ExactOutputSingleParams` in calldata
   1526 |     /// @return amountIn The amount of the input token
>> 1527 |     function exactOutputSingle(ExactOutputSingleParams calldata params) external payable returns (uint256 amountIn);
   1528 | 
   1529 |     struct ExactOutputParams {
   1530 |         bytes path;
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1540 行
- **函数**: `exactOutput()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1537 |     /// @notice Swaps as little as possible of one token for `amountOut` of another along the specified path (reversed)
   1538 |     /// @param params The parameters necessary for the multi-hop swap, encoded as `ExactOutputParams` in calldata
   1539 |     /// @return amountIn The amount of the input token
>> 1540 |     function exactOutput(ExactOutputParams calldata params) external payable returns (uint256 amountIn);
   1541 | }
   1542 | 
   1543 | 
```

---

### 39. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 143 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    138 | 
    139 | // SPDX-License-Identifier: GPL-2.0-or-later
    140 | pragma solidity >=0.5.0;
    141 | 
    142 | /// @title Callback for IPancakeV3PoolActions#swap
>>  143 | /// @notice Any contract that calls IPancakeV3PoolActions#swap must implement this interface
    144 | interface IPancakeV3SwapCallback {
    145 |     /// @notice Called to `msg.sender` after executing a swap via IPancakeV3Pool#swap.
    146 |     /// @dev In the implementation you must pay the pool tokens owed for the swap.
    147 |     /// The caller of this method must be checked to be a PancakeV3Pool deployed by the canonical PancakeV3Factory.
    148 |     /// amount0Delta and amount1Delta can both be 0 if no tokens were swapped.
```

---

### 40. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 483 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    478 | pragma solidity >=0.5.0;
    479 | 
    480 | /// @title Pool state that never changes
    481 | /// @notice These parameters are fixed for a pool forever, i.e., the methods will always return the same values
    482 | interface IPancakeV3PoolImmutables {
>>  483 |     /// @notice The contract that deployed the pool, which must adhere to the IPancakeV3Factory interface
    484 |     /// @return The contract address
    485 |     function factory() external view returns (address);
    486 | 
    487 |     /// @notice The first of the two tokens of the pool, sorted by address
    488 |     /// @return The token contract address
```

---

### 41. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 980 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    975 | pragma abicoder v2;
    976 | 
    977 | import '../interfaces/IMulticall.sol';
    978 | 
    979 | /// @title Multicall
>>  980 | /// @notice Enables calling multiple methods in a single call to the contract
    981 | abstract contract Multicall is IMulticall {
    982 |     /// @inheritdoc IMulticall
    983 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
    984 |         results = new bytes[](data.length);
    985 |         for (uint256 i = 0; i < data.length; i++) {
```

---

### 42. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1012 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1007 | 
   1008 | import '../interfaces/IPeripheryImmutableState.sol';
   1009 | 
   1010 | /// @title Immutable state
   1011 | /// @notice Immutable state used by periphery contracts
>> 1012 | abstract contract PeripheryImmutableState is IPeripheryImmutableState {
   1013 |     /// @inheritdoc IPeripheryImmutableState
   1014 |     address public immutable override deployer;
   1015 |     /// @inheritdoc IPeripheryImmutableState
   1016 |     address public immutable override factory;
   1017 |     /// @inheritdoc IPeripheryImmutableState
```

---

### 43. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1116 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1111 | import '../interfaces/IPeripheryPaymentsWithFee.sol';
   1112 | 
   1113 | import '../interfaces/external/IWETH9.sol';
   1114 | import '../libraries/TransferHelper.sol';
   1115 | 
>> 1116 | abstract contract PeripheryPaymentsWithFee is PeripheryPayments, IPeripheryPaymentsWithFee {
   1117 |     using LowGasSafeMath for uint256;
   1118 | 
   1119 |     /// @inheritdoc IPeripheryPaymentsWithFee
   1120 |     function unwrapWETH9WithFee(
   1121 |         uint256 amountMinimum,
```

---

### 44. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1189 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1184 | import '../interfaces/ISelfPermit.sol';
   1185 | import '../interfaces/external/IERC20PermitAllowed.sol';
   1186 | 
   1187 | /// @title Self Permit
   1188 | /// @notice Functionality to call permit on any EIP-2612-compliant token for use in the route
>> 1189 | /// @dev These functions are expected to be embedded in multicalls to allow EOAs to approve a contract and call a function
   1190 | /// that requires an approval in a single transaction.
   1191 | abstract contract SelfPermit is ISelfPermit {
   1192 |     /// @inheritdoc ISelfPermit
   1193 |     function selfPermit(
   1194 |         address token,
```

---

### 45. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1300 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1295 | pragma abicoder v2;
   1296 | 
   1297 | /// @title Multicall interface
   1298 | /// @notice Enables calling multiple methods in a single call to the contract
   1299 | interface IMulticall {
>> 1300 |     /// @notice Call multiple functions in the current contract and return the data from all of them if they all succeed
   1301 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   1302 |     /// @param data The encoded function data for each of the calls to make to this contract
   1303 |     /// @return results The results from each of the calls passed in via data
   1304 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results);
   1305 | }
```

---

### 46. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1341 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1336 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   1337 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
   1338 |     /// @param recipient The address receiving ETH
   1339 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external payable;
   1340 | 
>> 1341 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   1342 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
   1343 |     /// that use ether for the input amount. And in PancakeSwap Router, this would be called 
   1344 |     /// at the very end of swap
   1345 |     function refundETH() external payable;
   1346 | 
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1401 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1396 | pragma solidity >=0.7.5;
   1397 | 
   1398 | /// @title Self Permit
   1399 | /// @notice Functionality to call permit on any EIP-2612-compliant token for use in the route
   1400 | interface ISelfPermit {
>> 1401 |     /// @notice Permits this contract to spend a given token from `msg.sender`
   1402 |     /// @dev The `owner` is always msg.sender and the `spender` is always address(this).
   1403 |     /// @param token The address of the token spent
   1404 |     /// @param value The amount that can be spent of token
   1405 |     /// @param deadline A timestamp, the current blocktime must be less than or equal to this timestamp
   1406 |     /// @param v Must produce valid secp256k1 signature from the holder along with `r` and `s`
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1824 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1819 | import '@openzeppelin/contracts/token/ERC20/IERC20.sol';
   1820 | 
   1821 | library TransferHelper {
   1822 |     /// @notice Transfers tokens from the targeted address to the given destination
   1823 |     /// @notice Errors with 'STF' if transfer fails
>> 1824 |     /// @param token The contract address of the token to be transferred
   1825 |     /// @param from The originating address from which the tokens will be transferred
   1826 |     /// @param to The destination address of the transfer
   1827 |     /// @param value The amount to be transferred
   1828 |     function safeTransferFrom(
   1829 |         address token,
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1841 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1836 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'STF');
   1837 |     }
   1838 | 
   1839 |     /// @notice Transfers tokens from msg.sender to a recipient
   1840 |     /// @dev Errors with ST if transfer fails
>> 1841 |     /// @param token The contract address of the token which will be transferred
   1842 |     /// @param to The recipient of the transfer
   1843 |     /// @param value The value of the transfer
   1844 |     function safeTransfer(
   1845 |         address token,
   1846 |         address to,
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1853 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1848 |     ) internal {
   1849 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transfer.selector, to, value));
   1850 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'ST');
   1851 |     }
   1852 | 
>> 1853 |     /// @notice Approves the stipulated contract to spend the given allowance in the given token
   1854 |     /// @dev Errors with 'SA' if transfer fails
   1855 |     /// @param token The contract address of the token to be approved
   1856 |     /// @param to The target of the approval
   1857 |     /// @param value The amount of the given token the target will be allowed to spend
   1858 |     function safeApprove(
```

---

### 51. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1901 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1896 | import './libraries/CallbackValidation.sol';
   1897 | import './interfaces/external/IWETH9.sol';
   1898 | 
   1899 | /// @title Pancake V3 Swap Router
   1900 | /// @notice Router for stateless execution of swaps against Pancake V3
>> 1901 | contract SwapRouter is
   1902 |     ISwapRouter,
   1903 |     PeripheryImmutableState,
   1904 |     PeripheryValidation,
   1905 |     PeripheryPaymentsWithFee,
   1906 |     Multicall,
```

---

### 52. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 60 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
     57 | 
     58 | // SPDX-License-Identifier: MIT
     59 | 
>>   60 | pragma solidity ^0.7.0;
     61 | 
     62 | /**
     63 |  * @dev Interface of the ERC20 standard as defined in the EIP.
```

---

### 53. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 966 行
- **函数**: `_blockTimestamp()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    963 |     /// @dev Method that exists purely to be overridden for tests
    964 |     /// @return The current block timestamp
    965 |     function _blockTimestamp() internal view virtual returns (uint256) {
>>  966 |         return block.timestamp;
    967 |     }
    968 | }
    969 | 
```

---

### 54. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1090 行
- **函数**: `pay()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1087 |         if (token == WETH9 && address(this).balance >= value) {
   1088 |             // pay with WETH9
   1089 |             IWETH9(WETH9).deposit{value: value}(); // wrap only what is needed to pay
>> 1090 |             IWETH9(WETH9).transfer(recipient, value);
   1091 |         } else if (payer == address(this)) {
   1092 |             // pay with tokens already in the contract (for the exact input multihop case)
   1093 |             TransferHelper.safeTransfer(token, recipient, value);
```

---

### 55. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1769 行
- **函数**: `skipToken()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1766 | 
   1767 | /// @title Provides functions for deriving a pool address from the factory, tokens, and the fee
   1768 | library PoolAddress {
>> 1769 |     bytes32 internal constant POOL_INIT_CODE_HASH = 0x6ce8eb472fa82df5469c6ab6d485f17c3ad13c8cd7af59b3d4a8026c5ce0f7e2;
   1770 | 
   1771 |     /// @notice The identifying key of the pool
   1772 |     struct PoolKey {
```

---

### 56. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 816 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    813 |         uint256 r = ratio;
    814 |         uint256 msb = 0;
    815 | 
>>  816 |         assembly {
    817 |             let f := shl(7, gt(r, 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF))
    818 |             msb := or(msb, f)
    819 |             r := shr(f, r)
```

---

### 57. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 821 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    818 |             msb := or(msb, f)
    819 |             r := shr(f, r)
    820 |         }
>>  821 |         assembly {
    822 |             let f := shl(6, gt(r, 0xFFFFFFFFFFFFFFFF))
    823 |             msb := or(msb, f)
    824 |             r := shr(f, r)
```

---

### 58. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 826 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    823 |             msb := or(msb, f)
    824 |             r := shr(f, r)
    825 |         }
>>  826 |         assembly {
    827 |             let f := shl(5, gt(r, 0xFFFFFFFF))
    828 |             msb := or(msb, f)
    829 |             r := shr(f, r)
```

---

### 59. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 831 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    828 |             msb := or(msb, f)
    829 |             r := shr(f, r)
    830 |         }
>>  831 |         assembly {
    832 |             let f := shl(4, gt(r, 0xFFFF))
    833 |             msb := or(msb, f)
    834 |             r := shr(f, r)
```

---

### 60. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 836 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    833 |             msb := or(msb, f)
    834 |             r := shr(f, r)
    835 |         }
>>  836 |         assembly {
    837 |             let f := shl(3, gt(r, 0xFF))
    838 |             msb := or(msb, f)
    839 |             r := shr(f, r)
```

---

### 61. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 841 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    838 |             msb := or(msb, f)
    839 |             r := shr(f, r)
    840 |         }
>>  841 |         assembly {
    842 |             let f := shl(2, gt(r, 0xF))
    843 |             msb := or(msb, f)
    844 |             r := shr(f, r)
```

---

### 62. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 846 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    843 |             msb := or(msb, f)
    844 |             r := shr(f, r)
    845 |         }
>>  846 |         assembly {
    847 |             let f := shl(1, gt(r, 0x3))
    848 |             msb := or(msb, f)
    849 |             r := shr(f, r)
```

---

### 63. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 851 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    848 |             msb := or(msb, f)
    849 |             r := shr(f, r)
    850 |         }
>>  851 |         assembly {
    852 |             let f := gt(r, 0x1)
    853 |             msb := or(msb, f)
    854 |         }
```

---

### 64. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 861 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    858 | 
    859 |         int256 log_2 = (int256(msb) - 128) << 64;
    860 | 
>>  861 |         assembly {
    862 |             r := shr(127, mul(r, r))
    863 |             let f := shr(128, r)
    864 |             log_2 := or(log_2, shl(63, f))
```

---

### 65. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 867 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    864 |             log_2 := or(log_2, shl(63, f))
    865 |             r := shr(f, r)
    866 |         }
>>  867 |         assembly {
    868 |             r := shr(127, mul(r, r))
    869 |             let f := shr(128, r)
    870 |             log_2 := or(log_2, shl(62, f))
```

---

### 66. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 873 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    870 |             log_2 := or(log_2, shl(62, f))
    871 |             r := shr(f, r)
    872 |         }
>>  873 |         assembly {
    874 |             r := shr(127, mul(r, r))
    875 |             let f := shr(128, r)
    876 |             log_2 := or(log_2, shl(61, f))
```

---

### 67. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 879 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    876 |             log_2 := or(log_2, shl(61, f))
    877 |             r := shr(f, r)
    878 |         }
>>  879 |         assembly {
    880 |             r := shr(127, mul(r, r))
    881 |             let f := shr(128, r)
    882 |             log_2 := or(log_2, shl(60, f))
```

---

### 68. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 885 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    882 |             log_2 := or(log_2, shl(60, f))
    883 |             r := shr(f, r)
    884 |         }
>>  885 |         assembly {
    886 |             r := shr(127, mul(r, r))
    887 |             let f := shr(128, r)
    888 |             log_2 := or(log_2, shl(59, f))
```

---

### 69. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 891 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    888 |             log_2 := or(log_2, shl(59, f))
    889 |             r := shr(f, r)
    890 |         }
>>  891 |         assembly {
    892 |             r := shr(127, mul(r, r))
    893 |             let f := shr(128, r)
    894 |             log_2 := or(log_2, shl(58, f))
```

---

### 70. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 897 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    894 |             log_2 := or(log_2, shl(58, f))
    895 |             r := shr(f, r)
    896 |         }
>>  897 |         assembly {
    898 |             r := shr(127, mul(r, r))
    899 |             let f := shr(128, r)
    900 |             log_2 := or(log_2, shl(57, f))
```

---

### 71. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 903 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    900 |             log_2 := or(log_2, shl(57, f))
    901 |             r := shr(f, r)
    902 |         }
>>  903 |         assembly {
    904 |             r := shr(127, mul(r, r))
    905 |             let f := shr(128, r)
    906 |             log_2 := or(log_2, shl(56, f))
```

---

### 72. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 909 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    906 |             log_2 := or(log_2, shl(56, f))
    907 |             r := shr(f, r)
    908 |         }
>>  909 |         assembly {
    910 |             r := shr(127, mul(r, r))
    911 |             let f := shr(128, r)
    912 |             log_2 := or(log_2, shl(55, f))
```

---

### 73. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 915 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    912 |             log_2 := or(log_2, shl(55, f))
    913 |             r := shr(f, r)
    914 |         }
>>  915 |         assembly {
    916 |             r := shr(127, mul(r, r))
    917 |             let f := shr(128, r)
    918 |             log_2 := or(log_2, shl(54, f))
```

---

### 74. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 921 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    918 |             log_2 := or(log_2, shl(54, f))
    919 |             r := shr(f, r)
    920 |         }
>>  921 |         assembly {
    922 |             r := shr(127, mul(r, r))
    923 |             let f := shr(128, r)
    924 |             log_2 := or(log_2, shl(53, f))
```

---

### 75. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 927 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    924 |             log_2 := or(log_2, shl(53, f))
    925 |             r := shr(f, r)
    926 |         }
>>  927 |         assembly {
    928 |             r := shr(127, mul(r, r))
    929 |             let f := shr(128, r)
    930 |             log_2 := or(log_2, shl(52, f))
```

---

### 76. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 933 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    930 |             log_2 := or(log_2, shl(52, f))
    931 |             r := shr(f, r)
    932 |         }
>>  933 |         assembly {
    934 |             r := shr(127, mul(r, r))
    935 |             let f := shr(128, r)
    936 |             log_2 := or(log_2, shl(51, f))
```

---

### 77. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 939 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    936 |             log_2 := or(log_2, shl(51, f))
    937 |             r := shr(f, r)
    938 |         }
>>  939 |         assembly {
    940 |             r := shr(127, mul(r, r))
    941 |             let f := shr(128, r)
    942 |             log_2 := or(log_2, shl(50, f))
```

---

### 78. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 991 行
- **函数**: `multicall()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    988 |             if (!success) {
    989 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
    990 |                 if (result.length < 68) revert();
>>  991 |                 assembly {
    992 |                     result := add(result, 0x04)
    993 |                 }
    994 |                 revert(abi.decode(result, (string)));
```

---

### 79. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1568 行
- **函数**: `slice()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1565 | 
   1566 |         bytes memory tempBytes;
   1567 | 
>> 1568 |         assembly {
   1569 |             switch iszero(_length)
   1570 |                 case 0 {
   1571 |                     // Get a location of some free memory and store it in tempBytes as
```

---

### 80. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1628 行
- **函数**: `toAddress()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1625 |         require(_bytes.length >= _start + 20, 'toAddress_outOfBounds');
   1626 |         address tempAddress;
   1627 | 
>> 1628 |         assembly {
   1629 |             tempAddress := div(mload(add(add(_bytes, 0x20), _start)), 0x1000000000000000000000000)
   1630 |         }
   1631 | 
```

---

### 81. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1b81D678ffb9C0263b24A97847620C99d213eB14` 第 1640 行
- **函数**: `toUint24()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1637 |         require(_bytes.length >= _start + 3, 'toUint24_outOfBounds');
   1638 |         uint24 tempUint;
   1639 | 
>> 1640 |         assembly {
   1641 |             tempUint := mload(add(add(_bytes, 0x3), _start))
   1642 |         }
   1643 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*