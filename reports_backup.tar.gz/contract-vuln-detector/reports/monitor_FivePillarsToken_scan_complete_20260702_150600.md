# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:06:00
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` |
| contract_name | `FivePillarsToken` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 28 |
| 🟢 LOW | 0 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 30 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     27 |     /**
     28 |      * @dev Returns the value of tokens in existence.
     29 |      */
>>   30 |     function totalSupply() external view returns (uint256);
     31 | 
     32 |     /**
     33 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 35 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     32 |     /**
     33 |      * @dev Returns the value of tokens owned by `account`.
     34 |      */
>>   35 |     function balanceOf(address account) external view returns (uint256);
     36 | 
     37 |     /**
     38 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 44 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     41 |      *
     42 |      * Emits a {Transfer} event.
     43 |      */
>>   44 |     function transfer(address to, uint256 value) external returns (bool);
     45 | 
     46 |     /**
     47 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 53 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     50 |      *
     51 |      * This value changes when {approve} or {transferFrom} are called.
     52 |      */
>>   53 |     function allowance(address owner, address spender) external view returns (uint256);
     54 | 
     55 |     /**
     56 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 70 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     67 |      *
     68 |      * Emits an {Approval} event.
     69 |      */
>>   70 |     function approve(address spender, uint256 value) external returns (bool);
     71 | 
     72 |     /**
     73 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 81 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     78 |      *
     79 |      * Emits a {Transfer} event.
     80 |      */
>>   81 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
     82 | }
     83 | 
     84 | // File: @openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 99 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     96 |     /**
     97 |      * @dev Returns the name of the token.
     98 |      */
>>   99 |     function name() external view returns (string memory);
    100 | 
    101 |     /**
    102 |      * @dev Returns the symbol of the token.
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 104 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    101 |     /**
    102 |      * @dev Returns the symbol of the token.
    103 |      */
>>  104 |     function symbol() external view returns (string memory);
    105 | 
    106 |     /**
    107 |      * @dev Returns the decimals places of the token.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 109 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    106 |     /**
    107 |      * @dev Returns the decimals places of the token.
    108 |      */
>>  109 |     function decimals() external view returns (uint8);
    110 | }
    111 | 
    112 | // File: @openzeppelin/contracts/utils/Context.sol
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 359 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    356 |     /**
    357 |      * @dev Returns the name of the token.
    358 |      */
>>  359 |     function name() public view virtual returns (string memory) {
    360 |         return _name;
    361 |     }
    362 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 367 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    364 |      * @dev Returns the symbol of the token, usually a shorter version of the
    365 |      * name.
    366 |      */
>>  367 |     function symbol() public view virtual returns (string memory) {
    368 |         return _symbol;
    369 |     }
    370 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 384 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    381 |      * no way affects any of the arithmetic of the contract, including
    382 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    383 |      */
>>  384 |     function decimals() public view virtual returns (uint8) {
    385 |         return 18;
    386 |     }
    387 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 389 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    386 |     }
    387 | 
    388 |     /// @inheritdoc IERC20
>>  389 |     function totalSupply() public view virtual returns (uint256) {
    390 |         return _totalSupply;
    391 |     }
    392 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 394 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    391 |     }
    392 | 
    393 |     /// @inheritdoc IERC20
>>  394 |     function balanceOf(address account) public view virtual returns (uint256) {
    395 |         return _balances[account];
    396 |     }
    397 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 406 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    403 |      * - `to` cannot be the zero address.
    404 |      * - the caller must have a balance of at least `value`.
    405 |      */
>>  406 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    407 |         address owner = _msgSender();
    408 |         _transfer(owner, to, value);
    409 |         return true;
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 413 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    410 |     }
    411 | 
    412 |     /// @inheritdoc IERC20
>>  413 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    414 |         return _allowances[owner][spender];
    415 |     }
    416 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 427 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    424 |      *
    425 |      * - `spender` cannot be the zero address.
    426 |      */
>>  427 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    428 |         address owner = _msgSender();
    429 |         _approve(owner, spender, value);
    430 |         return true;
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 449 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    446 |      * - the caller must have allowance for ``from``'s tokens of at least
    447 |      * `value`.
    448 |      */
>>  449 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    450 |         address spender = _msgSender();
    451 |         _spendAllowance(from, spender, value);
    452 |         _transfer(from, to, value);
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 670 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    667 |     /**
    668 |      * @dev Returns the address of the current owner.
    669 |      */
>>  670 |     function owner() public view virtual returns (address) {
    671 |         return _owner;
    672 |     }
    673 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 749 行
- **函数**: `pendingOwner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    746 |     /**
    747 |      * @dev Returns the address of the pending owner.
    748 |      */
>>  749 |     function pendingOwner() public view virtual returns (address) {
    750 |         return _pendingOwner;
    751 |     }
    752 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 776 行
- **函数**: `acceptOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    773 |     /**
    774 |      * @dev The new owner accepts the ownership transfer.
    775 |      */
>>  776 |     function acceptOwnership() public virtual {
    777 |         address sender = _msgSender();
    778 |         if (pendingOwner() != sender) {
    779 |             revert OwnableUnauthorizedAccount(sender);
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 829 行
- **函数**: `mint()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    826 |     /**
    827 |      * @dev Mint tokens
    828 |      */
>>  829 |     function mint(address account, uint256 amount) external onlyInvestmentManager {
    830 |         _mint(account, amount);
    831 |     }
    832 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 836 行
- **函数**: `burnFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    833 |     /**
    834 |      * @dev Burn tokens
    835 |      */
>>  836 |     function burnFrom(address account, uint256 amount) external onlyInvestmentManager {
    837 |         _spendAllowance(account, _msgSender(), amount);
    838 |         _burn(account, amount);
    839 |     }
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 336 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    331 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    332 |  * instead returning `false` on failure. This behavior is nonetheless
    333 |  * conventional and does not conflict with the expectations of ERC-20
    334 |  * applications.
    335 |  */
>>  336 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    337 |     mapping(address account => uint256) private _balances;
    338 | 
    339 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    340 | 
    341 |     uint256 private _totalSupply;
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 634 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    629 |  *
    630 |  * This module is used through inheritance. It will make available the modifier
    631 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    632 |  * the owner.
    633 |  */
>>  634 | abstract contract Ownable is Context {
    635 |     address private _owner;
    636 | 
    637 |     /**
    638 |      * @dev The caller account is not authorized to perform an operation.
    639 |      */
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 706 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    701 |         }
    702 |         _transferOwnership(newOwner);
    703 |     }
    704 | 
    705 |     /**
>>  706 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    707 |      * Internal function without access restriction.
    708 |      */
    709 |     function _transferOwnership(address newOwner) internal virtual {
    710 |         address oldOwner = _owner;
    711 |         _owner = newOwner;
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 741 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    736 |  * can later be changed with {transferOwnership} and {acceptOwnership}.
    737 |  *
    738 |  * This module is used through inheritance. It will make available all functions
    739 |  * from parent (Ownable).
    740 |  */
>>  741 | abstract contract Ownable2Step is Ownable {
    742 |     address private _pendingOwner;
    743 | 
    744 |     event OwnershipTransferStarted(address indexed previousOwner, address indexed newOwner);
    745 | 
    746 |     /**
```

---

### 28. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6cae4094352a670c3eb0fcbDa17c898b71c7F2A` 第 792 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    787 | 
    788 | pragma solidity ^0.8.28;
    789 | 
    790 | 
    791 | 
>>  792 | contract FivePillarsToken is ERC20, Ownable2Step {
    793 |     error ManagerAlreadySetted();
    794 |     error ZeroAddress();
    795 |     error OnlyInvestmentManager();
    796 | 
    797 |     /// @notice The address of the InvestmentManager contract
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*