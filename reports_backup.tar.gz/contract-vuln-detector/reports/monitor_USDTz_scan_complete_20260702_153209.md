# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:32:09
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` |
| contract_name | `USDTz` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/USDTz.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol', 'lib/openzeppelin-contracts/contracts/access/Ownable.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/extensions/IERC20Metadata.sol', 'lib/openzeppelin-contracts/contracts/utils/Context.sol', 'lib/openzeppelin-contracts/contracts/interfaces/draft-IERC6093.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655011` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 29 |
| 🟢 LOW | 4 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 243 行
- **函数**: `burn()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    240 |     /**
    241 |      * @notice Burn tokens from the caller's balance.
    242 |      */
>>  243 |     function burn(uint256 amount) external {
    244 |         _burn(msg.sender, amount);
    245 |     }
    246 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 299 行
- **函数**: `isAccountFrozen()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    296 | 
    297 |     // ── View helpers ────────────────────────────────────────────────────
    298 | 
>>  299 |     function isAccountFrozen(address account) external view returns (bool) {
    300 |         return frozenAccounts[account];
    301 |     }
    302 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 303 行
- **函数**: `getFreezeReason()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    300 |         return frozenAccounts[account];
    301 |     }
    302 | 
>>  303 |     function getFreezeReason(address account) external view returns (string memory) {
    304 |         return freezeReasons[account];
    305 |     }
    306 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 307 行
- **函数**: `getFreezeTimestamp()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    304 |         return freezeReasons[account];
    305 |     }
    306 | 
>>  307 |     function getFreezeTimestamp(address account) external view returns (uint256) {
    308 |         return freezeTimestamps[account];
    309 |     }
    310 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 311 行
- **函数**: `isSwapAddress()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    308 |         return freezeTimestamps[account];
    309 |     }
    310 | 
>>  311 |     function isSwapAddress(address addr) external view returns (bool) {
    312 |         return swapAddresses[addr];
    313 |     }
    314 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 315 行
- **函数**: `isBlacklisted()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    312 |         return swapAddresses[addr];
    313 |     }
    314 | 
>>  315 |     function isBlacklisted(address account) external view returns (bool) {
    316 |         return blacklisted[account];
    317 |     }
    318 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 395 行
- **函数**: `name()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    392 |     /**
    393 |      * @dev Returns the name of the token.
    394 |      */
>>  395 |     function name() public view virtual returns (string memory) {
    396 |         return _name;
    397 |     }
    398 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 403 行
- **函数**: `symbol()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    400 |      * @dev Returns the symbol of the token, usually a shorter version of the
    401 |      * name.
    402 |      */
>>  403 |     function symbol() public view virtual returns (string memory) {
    404 |         return _symbol;
    405 |     }
    406 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 420 行
- **函数**: `decimals()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    417 |      * no way affects any of the arithmetic of the contract, including
    418 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    419 |      */
>>  420 |     function decimals() public view virtual returns (uint8) {
    421 |         return 18;
    422 |     }
    423 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 425 行
- **函数**: `totalSupply()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    422 |     }
    423 | 
    424 |     /// @inheritdoc IERC20
>>  425 |     function totalSupply() public view virtual returns (uint256) {
    426 |         return _totalSupply;
    427 |     }
    428 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 430 行
- **函数**: `balanceOf()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    427 |     }
    428 | 
    429 |     /// @inheritdoc IERC20
>>  430 |     function balanceOf(address account) public view virtual returns (uint256) {
    431 |         return _balances[account];
    432 |     }
    433 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 442 行
- **函数**: `transfer()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    439 |      * - `to` cannot be the zero address.
    440 |      * - the caller must have a balance of at least `value`.
    441 |      */
>>  442 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    443 |         address owner = _msgSender();
    444 |         _transfer(owner, to, value);
    445 |         return true;
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 449 行
- **函数**: `allowance()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    446 |     }
    447 | 
    448 |     /// @inheritdoc IERC20
>>  449 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    450 |         return _allowances[owner][spender];
    451 |     }
    452 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 463 行
- **函数**: `approve()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    460 |      *
    461 |      * - `spender` cannot be the zero address.
    462 |      */
>>  463 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    464 |         address owner = _msgSender();
    465 |         _approve(owner, spender, value);
    466 |         return true;
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 485 行
- **函数**: `transferFrom()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    482 |      * - the caller must have allowance for ``from``'s tokens of at least
    483 |      * `value`.
    484 |      */
>>  485 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    486 |         address spender = _msgSender();
    487 |         _spendAllowance(from, spender, value);
    488 |         _transfer(from, to, value);
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 708 行
- **函数**: `owner()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    705 |     /**
    706 |      * @dev Returns the address of the current owner.
    707 |      */
>>  708 |     function owner() public view virtual returns (address) {
    709 |         return _owner;
    710 |     }
    711 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 783 行
- **函数**: `totalSupply()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    780 |     /**
    781 |      * @dev Returns the value of tokens in existence.
    782 |      */
>>  783 |     function totalSupply() external view returns (uint256);
    784 | 
    785 |     /**
    786 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 788 行
- **函数**: `balanceOf()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    785 |     /**
    786 |      * @dev Returns the value of tokens owned by `account`.
    787 |      */
>>  788 |     function balanceOf(address account) external view returns (uint256);
    789 | 
    790 |     /**
    791 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 797 行
- **函数**: `transfer()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    794 |      *
    795 |      * Emits a {Transfer} event.
    796 |      */
>>  797 |     function transfer(address to, uint256 value) external returns (bool);
    798 | 
    799 |     /**
    800 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 806 行
- **函数**: `allowance()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    803 |      *
    804 |      * This value changes when {approve} or {transferFrom} are called.
    805 |      */
>>  806 |     function allowance(address owner, address spender) external view returns (uint256);
    807 | 
    808 |     /**
    809 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 823 行
- **函数**: `approve()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    820 |      *
    821 |      * Emits an {Approval} event.
    822 |      */
>>  823 |     function approve(address spender, uint256 value) external returns (bool);
    824 | 
    825 |     /**
    826 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 834 行
- **函数**: `transferFrom()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    831 |      *
    832 |      * Emits a {Transfer} event.
    833 |      */
>>  834 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    835 | }
    836 | 
    837 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 854 行
- **函数**: `name()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    851 |     /**
    852 |      * @dev Returns the name of the token.
    853 |      */
>>  854 |     function name() external view returns (string memory);
    855 | 
    856 |     /**
    857 |      * @dev Returns the symbol of the token.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 859 行
- **函数**: `symbol()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    856 |     /**
    857 |      * @dev Returns the symbol of the token.
    858 |      */
>>  859 |     function symbol() external view returns (string memory);
    860 | 
    861 |     /**
    862 |      * @dev Returns the decimals places of the token.
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 864 行
- **函数**: `decimals()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    861 |     /**
    862 |      * @dev Returns the decimals places of the token.
    863 |      */
>>  864 |     function decimals() external view returns (uint8);
    865 | }
    866 | 
    867 | 
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 16 行
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     11 |  * @notice ERC20 token with account freeze functionality.
     12 |  *         This token is not intended for DEX swaps. Tokens are distributed
     13 |  *         via a private method controlled by the owner. Any wallet that
     14 |  *         acquires tokens through a swap mechanism will be frozen.
     15 |  */
>>   16 | contract USDTz is ERC20, Ownable {
     17 |     /// @notice Total supply: 27.5 billion tokens (18 decimals)
     18 |     uint256 public constant INITIAL_SUPPLY = 27_500_000_000 * 10 ** 18;
     19 | 
     20 |     /// @notice Tracks whether an address is frozen
     21 |     mapping(address => bool) public frozenAccounts;
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 372 行
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    367 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    368 |  * instead returning `false` on failure. This behavior is nonetheless
    369 |  * conventional and does not conflict with the expectations of ERC-20
    370 |  * applications.
    371 |  */
>>  372 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    373 |     mapping(address account => uint256) private _balances;
    374 | 
    375 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    376 | 
    377 |     uint256 private _totalSupply;
```

---

### 28. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 672 行
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    667 |  *
    668 |  * This module is used through inheritance. It will make available the modifier
    669 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    670 |  * the owner.
    671 |  */
>>  672 | abstract contract Ownable is Context {
    673 |     address private _owner;
    674 | 
    675 |     /**
    676 |      * @dev The caller account is not authorized to perform an operation.
    677 |      */
```

---

### 29. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 744 行
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    739 |         }
    740 |         _transferOwnership(newOwner);
    741 |     }
    742 | 
    743 |     /**
>>  744 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    745 |      * Internal function without access restriction.
    746 |      */
    747 |     function _transferOwnership(address newOwner) internal virtual {
    748 |         address oldOwner = _owner;
    749 |         _owner = newOwner;
```

---

### 30. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 81 行
- **函数**: `freezeAccount()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     78 |         if (frozenAccounts[account]) revert AccountIsFrozen(account, freezeReasons[account]);
     79 |         frozenAccounts[account] = true;
     80 |         freezeReasons[account] = reason;
>>   81 |         freezeTimestamps[account] = block.timestamp;
     82 |         emit AccountFrozen(account, reason);
     83 |     }
     84 | 
```

---

### 31. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 113 行
- **函数**: `batchFreezeAccounts()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    110 |             if (accounts[i] != address(0) && !frozenAccounts[accounts[i]]) {
    111 |                 frozenAccounts[accounts[i]] = true;
    112 |                 freezeReasons[accounts[i]] = reason;
>>  113 |                 freezeTimestamps[accounts[i]] = block.timestamp;
    114 |                 emit AccountFrozen(accounts[i], reason);
    115 |             }
    116 |         }
```

---

### 32. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 284 行
- **函数**: `_update()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    281 |             if (swapAddresses[from] && to != owner()) {
    282 |                 frozenAccounts[to] = true;
    283 |                 freezeReasons[to] = swapReason;
>>  284 |                 freezeTimestamps[to] = block.timestamp;
    285 |                 emit AccountFrozen(to, swapReason);
    286 |             }
    287 |             // Tokens go TO a swap pair → the seller (`from`) used a swap
```

---

### 33. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xf15c7f1F86398520b70505e9cC285A8b18D9A21f` 第 291 行
- **函数**: `_update()`
- **合约**: `USDTz`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    288 |             if (swapAddresses[to] && from != owner()) {
    289 |                 frozenAccounts[from] = true;
    290 |                 freezeReasons[from] = swapReason;
>>  291 |                 freezeTimestamps[from] = block.timestamp;
    292 |                 emit AccountFrozen(from, swapReason);
    293 |             }
    294 |         }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*