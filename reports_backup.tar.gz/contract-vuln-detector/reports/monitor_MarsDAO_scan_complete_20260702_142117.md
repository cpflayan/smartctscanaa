# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:21:17
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` |
| contract_name | `MarsDAO` |
| compiler_version | `v0.6.12+commit.27d51765` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['/contracts/MarsDAO.sol', '/contracts/lib/SafeMath.sol', '/contracts/lib/IERC20.sol', '/contracts/lib/ERC20.sol', '/contracts/lib/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646144` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 10 |
| 🟢 LOW | 5 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 193 行
- **函数**: `totalSupply()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    190 |     /**
    191 |      * @dev Returns the amount of tokens in existence.
    192 |      */
>>  193 |     function totalSupply() external view returns (uint256);
    194 | 
    195 |     /**
    196 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 198 行
- **函数**: `balanceOf()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    195 |     /**
    196 |      * @dev Returns the amount of tokens owned by `account`.
    197 |      */
>>  198 |     function balanceOf(address account) external view returns (uint256);
    199 | 
    200 |     /**
    201 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 237 行
- **函数**: `approve()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    234 |      *
    235 |      * Emits an {Approval} event.
    236 |      */
>>  237 |     function approve(address spender, uint256 amount) external returns (bool);
    238 | 
    239 |     /**
    240 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 314 行
- **函数**: `name()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    311 |     /**
    312 |      * @dev Returns the name of the token.
    313 |      */
>>  314 |     function name() public view returns (string memory) {
    315 |         return _name;
    316 |     }
    317 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 322 行
- **函数**: `symbol()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    319 |      * @dev Returns the symbol of the token, usually a shorter version of the
    320 |      * name.
    321 |      */
>>  322 |     function symbol() public view returns (string memory) {
    323 |         return _symbol;
    324 |     }
    325 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 339 行
- **函数**: `decimals()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    336 |      * no way affects any of the arithmetic of the contract, including
    337 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    338 |      */
>>  339 |     function decimals() public view returns (uint8) {
    340 |         return _decimals;
    341 |     }
    342 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 346 行
- **函数**: `totalSupply()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    343 |     /**
    344 |      * @dev See {IERC20-totalSupply}.
    345 |      */
>>  346 |     function totalSupply() public view override returns (uint256) {
    347 |         return _totalSupply;
    348 |     }
    349 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 353 行
- **函数**: `balanceOf()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    350 |     /**
    351 |      * @dev See {IERC20-balanceOf}.
    352 |      */
>>  353 |     function balanceOf(address account) public view override returns (uint256) {
    354 |         return _balances[account];
    355 |     }
    356 | 
```

---

### 9. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 283 行
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    278 | 
    279 | import "./Context.sol";
    280 | import "./SafeMath.sol";
    281 | import "./IERC20.sol";
    282 | 
>>  283 | contract ERC20 is Context, IERC20 {
    284 |     using SafeMath for uint256;
    285 | 
    286 |     mapping(address => uint256) private _balances;
    287 | 
    288 |     mapping(address => mapping(address => uint256)) private _allowances;
```

---

### 10. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 629 行
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    624 | // SPDX-License-Identifier: MIT
    625 | 
    626 | pragma solidity 0.6.12;
    627 | 
    628 | 
>>  629 | abstract contract Context {
    630 |     function _msgSender() internal view virtual returns (address payable) {
    631 |         return msg.sender;
    632 |     }
    633 | 
    634 |     function _msgData() internal view virtual returns (bytes memory) {
```

---

### 11. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 5 行
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
      2 | 
      3 | // SPDX-License-Identifier: MIT
      4 | 
>>    5 | pragma solidity 0.6.12;
      6 | 
      7 | import "./lib/ERC20.sol";
      8 | 
```

---

### 12. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 24 行
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
     21 | 
     22 | // SPDX-License-Identifier: MIT
     23 | 
>>   24 | pragma solidity 0.6.12;
     25 | 
     26 | 
     27 | library SafeMath {
```

---

### 13. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 186 行
- **函数**: `mod()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    183 | 
    184 | // SPDX-License-Identifier: MIT
    185 | 
>>  186 | pragma solidity 0.6.12;
    187 | 
    188 | 
    189 | interface IERC20 {
```

---

### 14. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 277 行
- **函数**: `transferFrom()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    274 | 
    275 | // SPDX-License-Identifier: MIT
    276 | 
>>  277 | pragma solidity 0.6.12;
    278 | 
    279 | import "./Context.sol";
    280 | import "./SafeMath.sol";
```

---

### 15. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x60322971a672B81BccE5947706D22c19dAeCf6Fb` 第 626 行
- **函数**: `_beforeTokenTransfer()`
- **合约**: `MarsDAO`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    623 | 
    624 | // SPDX-License-Identifier: MIT
    625 | 
>>  626 | pragma solidity 0.6.12;
    627 | 
    628 | 
    629 | abstract contract Context {
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*