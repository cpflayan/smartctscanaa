# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:14:42
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x6413734f92248D4B29ae35883290BD93212654Dc` |
| contract_name | `ConditionalTokens` |
| compiler_version | `v0.8.26+commit.8a97fa7a` |
| optimization_used | `True` |
| runs | `1` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/ConditionalTokens.sol', 'lib/openzeppelin-contracts/contracts/utils/ReentrancyGuard.sol', 'lib/openzeppelin-contracts/contracts/token/ERC1155/ERC1155.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol', 'contracts/AdminRegistry.sol', 'contracts/IMyriadMarketManager.sol', 'contracts/Outcomes.sol', 'lib/openzeppelin-contracts/contracts/token/ERC1155/IERC1155.sol', 'lib/openzeppelin-contracts/contracts/token/ERC1155/extensions/IERC1155MetadataURI.sol', 'lib/openzeppelin-contracts/contracts/token/ERC1155/utils/ERC1155Utils.sol', 'lib/openzeppelin-contracts/contracts/utils/Context.sol', 'lib/openzeppelin-contracts/contracts/utils/introspection/ERC165.sol', 'lib/openzeppelin-contracts/contracts/utils/Arrays.sol', 'lib/openzeppelin-contracts/contracts/interfaces/draft-IERC6093.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'lib/openzeppelin-contracts/contracts/interfaces/IERC1363.sol', 'lib/openzeppelin-contracts/contracts/access/AccessControl.sol', 'lib/openzeppelin-contracts/contracts/utils/introspection/IERC165.sol', 'lib/openzeppelin-contracts/contracts/token/ERC1155/IERC1155Receiver.sol', 'lib/openzeppelin-contracts/contracts/utils/Comparators.sol', 'lib/openzeppelin-contracts/contracts/utils/SlotDerivation.sol', 'lib/openzeppelin-contracts/contracts/utils/StorageSlot.sol', 'lib/openzeppelin-contracts/contracts/utils/math/Math.sol', 'lib/openzeppelin-contracts/contracts/interfaces/IERC20.sol', 'lib/openzeppelin-contracts/contracts/interfaces/IERC165.sol', 'lib/openzeppelin-contracts/contracts/access/IAccessControl.sol', 'lib/openzeppelin-contracts/contracts/utils/Panic.sol', 'lib/openzeppelin-contracts/contracts/utils/math/SafeCast.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 50 |
| 🟢 LOW | 12 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 128 行
- **函数**: `getTokenId()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    125 |     emit PositionPruned(msg.sender, marketId, address(collateral), losingOutcomeId, amount);
    126 |   }
    127 | 
>>  128 |   function getTokenId(uint256 marketId, uint256 outcome) public pure returns (uint256) {
    129 |     return (marketId << 1) | outcome;
    130 |   }
    131 | }
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 264 行
- **函数**: `supportsInterface()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    261 |     }
    262 | 
    263 |     /// @inheritdoc IERC165
>>  264 |     function supportsInterface(bytes4 interfaceId) public view virtual override(ERC165, IERC165) returns (bool) {
    265 |         return
    266 |             interfaceId == type(IERC1155).interfaceId ||
    267 |             interfaceId == type(IERC1155MetadataURI).interfaceId ||
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 281 行
- **函数**: `uri()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    278 |      * Clients calling this function must replace the `\{id\}` substring with the
    279 |      * actual token type ID.
    280 |      */
>>  281 |     function uri(uint256 /* id */) public view virtual returns (string memory) {
    282 |         return _uri;
    283 |     }
    284 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 286 行
- **函数**: `balanceOf()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    283 |     }
    284 | 
    285 |     /// @inheritdoc IERC1155
>>  286 |     function balanceOf(address account, uint256 id) public view virtual returns (uint256) {
    287 |         return _balances[id][account];
    288 |     }
    289 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 315 行
- **函数**: `setApprovalForAll()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    312 |     }
    313 | 
    314 |     /// @inheritdoc IERC1155
>>  315 |     function setApprovalForAll(address operator, bool approved) public virtual {
    316 |         _setApprovalForAll(_msgSender(), operator, approved);
    317 |     }
    318 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 320 行
- **函数**: `isApprovedForAll()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    317 |     }
    318 | 
    319 |     /// @inheritdoc IERC1155
>>  320 |     function isApprovedForAll(address account, address operator) public view virtual returns (bool) {
    321 |         return _operatorApprovals[account][operator];
    322 |     }
    323 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 325 行
- **函数**: `safeTransferFrom()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    322 |     }
    323 | 
    324 |     /// @inheritdoc IERC1155
>>  325 |     function safeTransferFrom(address from, address to, uint256 id, uint256 value, bytes memory data) public virtual {
    326 |         address sender = _msgSender();
    327 |         if (from != sender && !isApprovedForAll(from, sender)) {
    328 |             revert ERC1155MissingApprovalForAll(sender, from);
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 936 行
- **函数**: `proposeAdmin()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    933 | 
    934 |   /// @notice Initiate an admin transfer. The current admin proposes a successor;
    935 |   ///         the successor must call acceptAdmin() to complete the transfer.
>>  936 |   function proposeAdmin(address newAdmin) external {
    937 |     require(hasRole(DEFAULT_ADMIN_ROLE, msg.sender), "not admin");
    938 |     require(newAdmin != address(0), "zero address");
    939 |     require(newAdmin != admin, "cannot self-propose");
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 946 行
- **函数**: `acceptAdmin()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    943 | 
    944 |   /// @notice Complete the admin transfer. Only callable by the pending admin.
    945 |   ///         Revokes DEFAULT_ADMIN_ROLE from the previous admin atomically.
>>  946 |   function acceptAdmin() external {
    947 |     require(msg.sender == pendingAdmin, "not pending admin");
    948 |     address oldAdmin = admin;
    949 |     _grantRole(DEFAULT_ADMIN_ROLE, pendingAdmin);
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 963 行
- **函数**: `grantRole()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    960 |   // Block inherited AccessControl functions for DEFAULT_ADMIN_ROLE so that
    961 |   // all admin transfers are forced through the two-step proposeAdmin/acceptAdmin path.
    962 | 
>>  963 |   function grantRole(bytes32 role, address account) public override {
    964 |     require(role != DEFAULT_ADMIN_ROLE, "use proposeAdmin/acceptAdmin");
    965 |     super.grantRole(role, account);
    966 |   }
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 968 行
- **函数**: `revokeRole()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    965 |     super.grantRole(role, account);
    966 |   }
    967 | 
>>  968 |   function revokeRole(bytes32 role, address account) public override {
    969 |     require(role != DEFAULT_ADMIN_ROLE, "use proposeAdmin/acceptAdmin");
    970 |     super.revokeRole(role, account);
    971 |   }
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 973 行
- **函数**: `renounceRole()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    970 |     super.revokeRole(role, account);
    971 |   }
    972 | 
>>  973 |   function renounceRole(bytes32 role, address callerConfirmation) public override {
    974 |     require(role != DEFAULT_ADMIN_ROLE, "use proposeAdmin/acceptAdmin");
    975 |     super.renounceRole(role, callerConfirmation);
    976 |   }
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 994 行
- **函数**: `getMarketCollateral()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    991 |     resolved
    992 |   }
    993 | 
>>  994 |   function getMarketCollateral(uint256 marketId) external view returns (IERC20);
    995 | 
    996 |   function getMarketResolvedOutcome(uint256 marketId) external view returns (int256);
    997 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 996 行
- **函数**: `getMarketResolvedOutcome()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    993 | 
    994 |   function getMarketCollateral(uint256 marketId) external view returns (IERC20);
    995 | 
>>  996 |   function getMarketResolvedOutcome(uint256 marketId) external view returns (int256);
    997 | 
    998 |   function getMarketState(uint256 marketId) external view returns (MarketState);
    999 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 998 行
- **函数**: `getMarketState()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    995 | 
    996 |   function getMarketResolvedOutcome(uint256 marketId) external view returns (int256);
    997 | 
>>  998 |   function getMarketState(uint256 marketId) external view returns (MarketState);
    999 | 
   1000 |   function isMarketPaused(uint256 marketId) external view returns (bool);
   1001 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1000 行
- **函数**: `isMarketPaused()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    997 | 
    998 |   function getMarketState(uint256 marketId) external view returns (MarketState);
    999 | 
>> 1000 |   function isMarketPaused(uint256 marketId) external view returns (bool);
   1001 | 
   1002 |   function isMarketTradeable(uint256 marketId) external view returns (bool);
   1003 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1002 行
- **函数**: `isMarketTradeable()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    999 | 
   1000 |   function isMarketPaused(uint256 marketId) external view returns (bool);
   1001 | 
>> 1002 |   function isMarketTradeable(uint256 marketId) external view returns (bool);
   1003 | 
   1004 |   function getVoidedPayouts(uint256 marketId) external view returns (uint256 outcome0Payout, uint256 outcome1Payout);
   1005 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1004 行
- **函数**: `getVoidedPayouts()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1001 | 
   1002 |   function isMarketTradeable(uint256 marketId) external view returns (bool);
   1003 | 
>> 1004 |   function getVoidedPayouts(uint256 marketId) external view returns (uint256 outcome0Payout, uint256 outcome1Payout);
   1005 | 
   1006 |   function isNegRisk(uint256 marketId) external view returns (bool);
   1007 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1006 行
- **函数**: `isNegRisk()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1003 | 
   1004 |   function getVoidedPayouts(uint256 marketId) external view returns (uint256 outcome0Payout, uint256 outcome1Payout);
   1005 | 
>> 1006 |   function isNegRisk(uint256 marketId) external view returns (bool);
   1007 | 
   1008 |   function getEventId(uint256 marketId) external view returns (bytes32);
   1009 | }
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1008 行
- **函数**: `getEventId()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1005 | 
   1006 |   function isNegRisk(uint256 marketId) external view returns (bool);
   1007 | 
>> 1008 |   function getEventId(uint256 marketId) external view returns (bytes32);
   1009 | }
   1010 | 
   1011 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1075 行
- **函数**: `balanceOf()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1072 |     /**
   1073 |      * @dev Returns the value of tokens of token type `id` owned by `account`.
   1074 |      */
>> 1075 |     function balanceOf(address account, uint256 id) external view returns (uint256);
   1076 | 
   1077 |     /**
   1078 |      * @dev xref:ROOT:erc1155.adoc#batch-operations[Batched] version of {balanceOf}.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1105 行
- **函数**: `isApprovedForAll()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1102 |      *
   1103 |      * See {setApprovalForAll}.
   1104 |      */
>> 1105 |     function isApprovedForAll(address account, address operator) external view returns (bool);
   1106 | 
   1107 |     /**
   1108 |      * @dev Transfers a `value` amount of tokens of type `id` from `from` to `to`.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1173 行
- **函数**: `uri()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1170 |      * If the `\{id\}` substring is present in the URI, it must be replaced by
   1171 |      * clients with the actual token type ID.
   1172 |      */
>> 1173 |     function uri(uint256 id) external view returns (string memory);
   1174 | }
   1175 | 
   1176 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1324 行
- **函数**: `supportsInterface()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1321 |  */
   1322 | abstract contract ERC165 is IERC165 {
   1323 |     /// @inheritdoc IERC165
>> 1324 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   1325 |         return interfaceId == type(IERC165).interfaceId;
   1326 |     }
   1327 | }
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2079 行
- **函数**: `totalSupply()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2076 |     /**
   2077 |      * @dev Returns the value of tokens in existence.
   2078 |      */
>> 2079 |     function totalSupply() external view returns (uint256);
   2080 | 
   2081 |     /**
   2082 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2084 行
- **函数**: `balanceOf()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2081 |     /**
   2082 |      * @dev Returns the value of tokens owned by `account`.
   2083 |      */
>> 2084 |     function balanceOf(address account) external view returns (uint256);
   2085 | 
   2086 |     /**
   2087 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2093 行
- **函数**: `transfer()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2090 |      *
   2091 |      * Emits a {Transfer} event.
   2092 |      */
>> 2093 |     function transfer(address to, uint256 value) external returns (bool);
   2094 | 
   2095 |     /**
   2096 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2102 行
- **函数**: `allowance()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2099 |      *
   2100 |      * This value changes when {approve} or {transferFrom} are called.
   2101 |      */
>> 2102 |     function allowance(address owner, address spender) external view returns (uint256);
   2103 | 
   2104 |     /**
   2105 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2119 行
- **函数**: `approve()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2116 |      *
   2117 |      * Emits an {Approval} event.
   2118 |      */
>> 2119 |     function approve(address spender, uint256 value) external returns (bool);
   2120 | 
   2121 |     /**
   2122 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2130 行
- **函数**: `transferFrom()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2127 |      *
   2128 |      * Emits a {Transfer} event.
   2129 |      */
>> 2130 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   2131 | }
   2132 | 
   2133 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2170 行
- **函数**: `transferAndCall()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2167 |      * @param value The amount of tokens to be transferred.
   2168 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2169 |      */
>> 2170 |     function transferAndCall(address to, uint256 value) external returns (bool);
   2171 | 
   2172 |     /**
   2173 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2180 行
- **函数**: `transferAndCall()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2177 |      * @param data Additional data with no specified format, sent in call to `to`.
   2178 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2179 |      */
>> 2180 |     function transferAndCall(address to, uint256 value, bytes calldata data) external returns (bool);
   2181 | 
   2182 |     /**
   2183 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2190 行
- **函数**: `transferFromAndCall()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2187 |      * @param value The amount of tokens to be transferred.
   2188 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2189 |      */
>> 2190 |     function transferFromAndCall(address from, address to, uint256 value) external returns (bool);
   2191 | 
   2192 |     /**
   2193 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2201 行
- **函数**: `transferFromAndCall()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2198 |      * @param data Additional data with no specified format, sent in call to `to`.
   2199 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2200 |      */
>> 2201 |     function transferFromAndCall(address from, address to, uint256 value, bytes calldata data) external returns (bool);
   2202 | 
   2203 |     /**
   2204 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2210 行
- **函数**: `approveAndCall()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2207 |      * @param value The amount of tokens to be spent.
   2208 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2209 |      */
>> 2210 |     function approveAndCall(address spender, uint256 value) external returns (bool);
   2211 | 
   2212 |     /**
   2213 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2220 行
- **函数**: `approveAndCall()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2217 |      * @param data Additional data with no specified format, sent in call to `spender`.
   2218 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
   2219 |      */
>> 2220 |     function approveAndCall(address spender, uint256 value, bytes calldata data) external returns (bool);
   2221 | }
   2222 | 
   2223 | 
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2294 行
- **函数**: `supportsInterface()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2291 |     }
   2292 | 
   2293 |     /// @inheritdoc IERC165
>> 2294 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
   2295 |         return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
   2296 |     }
   2297 | 
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2301 行
- **函数**: `hasRole()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2298 |     /**
   2299 |      * @dev Returns `true` if `account` has been granted `role`.
   2300 |      */
>> 2301 |     function hasRole(bytes32 role, address account) public view virtual returns (bool) {
   2302 |         return _roles[role].hasRole[account];
   2303 |     }
   2304 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2329 行
- **函数**: `getRoleAdmin()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2326 |      *
   2327 |      * To change a role's admin, use {_setRoleAdmin}.
   2328 |      */
>> 2329 |     function getRoleAdmin(bytes32 role) public view virtual returns (bytes32) {
   2330 |         return _roles[role].adminRole;
   2331 |     }
   2332 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2380 行
- **函数**: `renounceRole()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2377 |      *
   2378 |      * May emit a {RoleRevoked} event.
   2379 |      */
>> 2380 |     function renounceRole(bytes32 role, address callerConfirmation) public virtual {
   2381 |         if (callerConfirmation != _msgSender()) {
   2382 |             revert AccessControlBadConfirmation();
   2383 |         }
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2460 行
- **函数**: `supportsInterface()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2457 |      *
   2458 |      * This function call must use less than 30 000 gas.
   2459 |      */
>> 2460 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   2461 | }
   2462 | 
   2463 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 3680 行
- **函数**: `hasRole()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3677 |     /**
   3678 |      * @dev Returns `true` if `account` has been granted `role`.
   3679 |      */
>> 3680 |     function hasRole(bytes32 role, address account) external view returns (bool);
   3681 | 
   3682 |     /**
   3683 |      * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 3688 行
- **函数**: `getRoleAdmin()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3685 |      *
   3686 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
   3687 |      */
>> 3688 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
   3689 | 
   3690 |     /**
   3691 |      * @dev Grants `role` to `account`.
```

---

### 44. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 17 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     12 | import "./Outcomes.sol";
     13 | 
     14 | /// @title ConditionalTokens
     15 | /// @notice ERC1155 outcome positions for binary (outcome 0 / outcome 1) markets.
     16 | ///         No privileged minting path — all position creation goes through splitPosition.
>>   17 | contract ConditionalTokens is ERC1155, ReentrancyGuard {
     18 |   using SafeERC20 for IERC20;
     19 | 
     20 |   AdminRegistry public immutable registry;
     21 |   IMyriadMarketManager public immutable manager;
     22 | 
```

---

### 45. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 245 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    240 | /**
    241 |  * @dev Implementation of the basic standard multi-token.
    242 |  * See https://eips.ethereum.org/EIPS/eip-1155
    243 |  * Originally based on code by Enjin: https://github.com/enjin/erc-1155
    244 |  */
>>  245 | abstract contract ERC1155 is Context, ERC165, IERC1155, IERC1155MetadataURI, IERC1155Errors {
    246 |     using Arrays for uint256[];
    247 |     using Arrays for address[];
    248 | 
    249 |     mapping(uint256 id => mapping(address account => uint256)) private _balances;
    250 | 
```

---

### 46. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 631 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    626 | import {IERC1363} from "../../../interfaces/IERC1363.sol";
    627 | 
    628 | /**
    629 |  * @title SafeERC20
    630 |  * @dev Wrappers around ERC-20 operations that throw on failure (when the token
>>  631 |  * contract returns false). Tokens that return no value (and instead revert or
    632 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    633 |  * successful.
    634 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    635 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    636 |  */
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 913 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    908 | 
    909 | /// @title AdminRegistry
    910 | /// @notice Centralized role registry for protocol governance and operations.
    911 | ///         Supports a two-step admin transfer to reduce the risk of an accidental
    912 | ///         or malicious one-step hand-off of DEFAULT_ADMIN_ROLE.
>>  913 | contract AdminRegistry is AccessControl {
    914 |   bytes32 public constant MARKET_ADMIN_ROLE = keccak256("MARKET_ADMIN_ROLE");
    915 |   bytes32 public constant OPERATOR_ROLE = keccak256("OPERATOR_ROLE");
    916 |   bytes32 public constant FEE_ADMIN_ROLE = keccak256("FEE_ADMIN_ROLE");
    917 |   bytes32 public constant RESOLUTION_ADMIN_ROLE = keccak256("RESOLUTION_ADMIN_ROLE");
    918 | 
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2274 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2269 |  * WARNING: The `DEFAULT_ADMIN_ROLE` is also its own admin: it has permission to
   2270 |  * grant and revoke this role. Extra precautions should be taken to secure
   2271 |  * accounts that have been granted it. We recommend using {AccessControlDefaultAdminRules}
   2272 |  * to enforce additional security measures for this role.
   2273 |  */
>> 2274 | abstract contract AccessControl is Context, IAccessControl, ERC165 {
   2275 |     struct RoleData {
   2276 |         mapping(address account => bool) hasRole;
   2277 |         bytes32 adminRole;
   2278 |     }
   2279 | 
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 2567 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2562 |  *
   2563 |  * See https://docs.soliditylang.org/en/v0.8.20/internals/layout_in_storage.html#mappings-and-dynamic-arrays[Solidity docs for mappings and dynamic arrays.].
   2564 |  *
   2565 |  * Example usage:
   2566 |  * ```solidity
>> 2567 |  * contract Example {
   2568 |  *     // Add the library methods
   2569 |  *     using StorageSlot for bytes32;
   2570 |  *     using SlotDerivation for bytes32;
   2571 |  *
   2572 |  *     // Declare a namespace
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 3243 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3238 |      * Requirements:
   3239 |      * - modulus can't be zero
   3240 |      * - underlying staticcall to precompile must succeed
   3241 |      *
   3242 |      * IMPORTANT: The result is only valid if the underlying call succeeds. When using this function, make
>> 3243 |      * sure the chain you're using it on supports the precompiled contract for modular exponentiation
   3244 |      * at address 0x05 as specified in https://eips.ethereum.org/EIPS/eip-198[EIP-198]. Otherwise,
   3245 |      * the underlying function will succeed given the lack of a revert, but the result may be incorrectly
   3246 |      * interpreted as 0.
   3247 |      */
   3248 |     function modExp(uint256 b, uint256 e, uint256 m) internal view returns (uint256) {
```

---

### 51. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 3506 行
- **函数**: `log2()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3503 |         //
   3504 |         // The lookup table is represented as a 32-byte value with the MSB positions for 0-15 in the last 16 bytes.
   3505 |         assembly ("memory-safe") {
>> 3506 |             r := or(r, byte(shr(r, x), 0x0000010102020202030303030303030300000000000000000000000000000000))
   3507 |         }
   3508 |     }
   3509 | 
```

---

### 52. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1493 行
- **函数**: `_mload()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1490 |      * @dev Load memory word (as a uint256) at location `ptr`.
   1491 |      */
   1492 |     function _mload(uint256 ptr) private pure returns (uint256 value) {
>> 1493 |         assembly {
   1494 |             value := mload(ptr)
   1495 |         }
   1496 |     }
```

---

### 53. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1502 行
- **函数**: `_swap()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1499 |      * @dev Swaps the elements memory location `ptr1` and `ptr2`.
   1500 |      */
   1501 |     function _swap(uint256 ptr1, uint256 ptr2) private pure {
>> 1502 |         assembly {
   1503 |             let value1 := mload(ptr1)
   1504 |             let value2 := mload(ptr2)
   1505 |             mstore(ptr1, value2)
```

---

### 54. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1512 行
- **函数**: `_castToUint256Array()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1509 | 
   1510 |     /// @dev Helper: low level cast address memory array to uint256 memory array
   1511 |     function _castToUint256Array(address[] memory input) private pure returns (uint256[] memory output) {
>> 1512 |         assembly {
   1513 |             output := input
   1514 |         }
   1515 |     }
```

---

### 55. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1519 行
- **函数**: `_castToUint256Array()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1516 | 
   1517 |     /// @dev Helper: low level cast bytes32 memory array to uint256 memory array
   1518 |     function _castToUint256Array(bytes32[] memory input) private pure returns (uint256[] memory output) {
>> 1519 |         assembly {
   1520 |             output := input
   1521 |         }
   1522 |     }
```

---

### 56. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1528 行
- **函数**: `_castToUint256Comp()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1525 |     function _castToUint256Comp(
   1526 |         function(address, address) pure returns (bool) input
   1527 |     ) private pure returns (function(uint256, uint256) pure returns (bool) output) {
>> 1528 |         assembly {
   1529 |             output := input
   1530 |         }
   1531 |     }
```

---

### 57. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1537 行
- **函数**: `_castToUint256Comp()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1534 |     function _castToUint256Comp(
   1535 |         function(bytes32, bytes32) pure returns (bool) input
   1536 |     ) private pure returns (function(uint256, uint256) pure returns (bool) output) {
>> 1537 |         assembly {
   1538 |             output := input
   1539 |         }
   1540 |     }
```

---

### 58. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1780 行
- **函数**: `unsafeMemoryAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1777 |      * WARNING: Only use if you are certain `pos` is lower than the array length.
   1778 |      */
   1779 |     function unsafeMemoryAccess(address[] memory arr, uint256 pos) internal pure returns (address res) {
>> 1780 |         assembly {
   1781 |             res := mload(add(add(arr, 0x20), mul(pos, 0x20)))
   1782 |         }
   1783 |     }
```

---

### 59. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1791 行
- **函数**: `unsafeMemoryAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1788 |      * WARNING: Only use if you are certain `pos` is lower than the array length.
   1789 |      */
   1790 |     function unsafeMemoryAccess(bytes32[] memory arr, uint256 pos) internal pure returns (bytes32 res) {
>> 1791 |         assembly {
   1792 |             res := mload(add(add(arr, 0x20), mul(pos, 0x20)))
   1793 |         }
   1794 |     }
```

---

### 60. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1802 行
- **函数**: `unsafeMemoryAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1799 |      * WARNING: Only use if you are certain `pos` is lower than the array length.
   1800 |      */
   1801 |     function unsafeMemoryAccess(uint256[] memory arr, uint256 pos) internal pure returns (uint256 res) {
>> 1802 |         assembly {
   1803 |             res := mload(add(add(arr, 0x20), mul(pos, 0x20)))
   1804 |         }
   1805 |     }
```

---

### 61. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1813 行
- **函数**: `unsafeMemoryAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1810 |      * WARNING: Only use if you are certain `pos` is lower than the array length.
   1811 |      */
   1812 |     function unsafeMemoryAccess(bytes[] memory arr, uint256 pos) internal pure returns (bytes memory res) {
>> 1813 |         assembly {
   1814 |             res := mload(add(add(arr, 0x20), mul(pos, 0x20)))
   1815 |         }
   1816 |     }
```

---

### 62. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6413734f92248D4B29ae35883290BD93212654Dc` 第 1824 行
- **函数**: `unsafeMemoryAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1821 |      * WARNING: Only use if you are certain `pos` is lower than the array length.
   1822 |      */
   1823 |     function unsafeMemoryAccess(string[] memory arr, uint256 pos) internal pure returns (string memory res) {
>> 1824 |         assembly {
   1825 |             res := mload(add(add(arr, 0x20), mul(pos, 0x20)))
   1826 |         }
   1827 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*