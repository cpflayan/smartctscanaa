# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:21:06
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x544028231562a43b106FbceCA722B65Cb5C861b0` |
| contract_name | `OLY` |
| compiler_version | `v0.8.29+commit.ab55807c` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/OHM.sol', 'lib/openzeppelin-contracts/contracts/access/AccessControl.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'src/libraries/SafeMath.sol', 'lib/openzeppelin-contracts/contracts/access/IAccessControl.sol', 'lib/openzeppelin-contracts/contracts/utils/Context.sol', 'lib/openzeppelin-contracts/contracts/utils/introspection/ERC165.sol', 'lib/openzeppelin-contracts/contracts/utils/introspection/IERC165.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646143` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 33 |
| 🟢 LOW | 0 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 31 行
- **函数**: `name()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     28 |         _decimals = decimals_;
     29 |     }
     30 | 
>>   31 |     function name() public view returns (string memory) {
     32 |         return _name;
     33 |     }
     34 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 35 行
- **函数**: `symbol()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     32 |         return _name;
     33 |     }
     34 | 
>>   35 |     function symbol() public view returns (string memory) {
     36 |         return _symbol;
     37 |     }
     38 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 39 行
- **函数**: `decimals()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     36 |         return _symbol;
     37 |     }
     38 | 
>>   39 |     function decimals() public view returns (uint8) {
     40 |         return _decimals;
     41 |     }
     42 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 43 行
- **函数**: `totalSupply()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     40 |         return _decimals;
     41 |     }
     42 | 
>>   43 |     function totalSupply() public view override returns (uint256) {
     44 |         return _totalSupply;
     45 |     }
     46 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 47 行
- **函数**: `balanceOf()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     44 |         return _totalSupply;
     45 |     }
     46 | 
>>   47 |     function balanceOf(address account) public view virtual override returns (uint256) {
     48 |         return _balances[account];
     49 |     }
     50 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 51 行
- **函数**: `transfer()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     48 |         return _balances[account];
     49 |     }
     50 | 
>>   51 |     function transfer(address recipient, uint256 amount) public virtual override returns (bool) {
     52 |         _transfer(msg.sender, recipient, amount);
     53 |         return true;
     54 |     }
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 56 行
- **函数**: `allowance()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     53 |         return true;
     54 |     }
     55 | 
>>   56 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
     57 |         return _allowances[owner][spender];
     58 |     }
     59 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 60 行
- **函数**: `approve()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     57 |         return _allowances[owner][spender];
     58 |     }
     59 | 
>>   60 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
     61 |         _approve(msg.sender, spender, amount);
     62 |         return true;
     63 |     }
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 65 行
- **函数**: `transferFrom()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     62 |         return true;
     63 |     }
     64 | 
>>   65 |     function transferFrom(address sender, address recipient, uint256 amount) public virtual override returns (bool) {
     66 |         _transfer(sender, recipient, amount);
     67 |         _approve(
     68 |             sender, msg.sender, _allowances[sender][msg.sender].sub(amount, "ERC20: transfer amount exceeds allowance")
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 74 行
- **函数**: `increaseAllowance()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     71 |         return true;
     72 |     }
     73 | 
>>   74 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
     75 |         _approve(msg.sender, spender, _allowances[msg.sender][spender].add(addedValue));
     76 |         return true;
     77 |     }
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 79 行
- **函数**: `decreaseAllowance()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     76 |         return true;
     77 |     }
     78 | 
>>   79 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
     80 |         _approve(
     81 |             msg.sender,
     82 |             spender,
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 152 行
- **函数**: `mint()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    149 | 
    150 |     constructor() ERC20("OLY", "OLY", 9) {}
    151 | 
>>  152 |     function mint(address account_, uint256 amount_) external onlyVault {
    153 |         _mint(account_, amount_);
    154 |     }
    155 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 156 行
- **函数**: `burn()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    153 |         _mint(account_, amount_);
    154 |     }
    155 | 
>>  156 |     function burn(uint256 amount) public virtual {
    157 |         _burn(msg.sender, amount);
    158 |     }
    159 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 160 行
- **函数**: `burnFrom()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    157 |         _burn(msg.sender, amount);
    158 |     }
    159 | 
>>  160 |     function burnFrom(address account_, uint256 amount_) public virtual {
    161 |         _burnFrom(account_, amount_);
    162 |     }
    163 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 205 行
- **函数**: `setMainPair()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    202 |         _grantRole(INTERN_SYSTEM, _feeReceiver);
    203 |     }
    204 | 
>>  205 |     function setMainPair(address pair) external onlyDefaultAdmin {
    206 |         mainPair = pair;
    207 |     }
    208 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 209 行
- **函数**: `setRatio()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    206 |         mainPair = pair;
    207 |     }
    208 | 
>>  209 |     function setRatio(uint8 ratioType,uint256 ratio) external onlyDefaultAdmin {
    210 |         require(ratio <= PRECISION, "Exceeds precision");
    211 |         if(ratioType == 0){
    212 |             buyFeeRatio = ratio;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 338 行
- **函数**: `supportsInterface()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    335 |     }
    336 | 
    337 |     /// @inheritdoc IERC165
>>  338 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
    339 |         return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
    340 |     }
    341 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 345 行
- **函数**: `hasRole()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    342 |     /**
    343 |      * @dev Returns `true` if `account` has been granted `role`.
    344 |      */
>>  345 |     function hasRole(bytes32 role, address account) public view virtual returns (bool) {
    346 |         return _roles[role].hasRole[account];
    347 |     }
    348 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 373 行
- **函数**: `getRoleAdmin()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    370 |      *
    371 |      * To change a role's admin, use {_setRoleAdmin}.
    372 |      */
>>  373 |     function getRoleAdmin(bytes32 role) public view virtual returns (bytes32) {
    374 |         return _roles[role].adminRole;
    375 |     }
    376 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 424 行
- **函数**: `renounceRole()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    421 |      *
    422 |      * May emit a {RoleRevoked} event.
    423 |      */
>>  424 |     function renounceRole(bytes32 role, address callerConfirmation) public virtual {
    425 |         if (callerConfirmation != _msgSender()) {
    426 |             revert AccessControlBadConfirmation();
    427 |         }
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 507 行
- **函数**: `totalSupply()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    504 |     /**
    505 |      * @dev Returns the value of tokens in existence.
    506 |      */
>>  507 |     function totalSupply() external view returns (uint256);
    508 | 
    509 |     /**
    510 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 512 行
- **函数**: `balanceOf()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    509 |     /**
    510 |      * @dev Returns the value of tokens owned by `account`.
    511 |      */
>>  512 |     function balanceOf(address account) external view returns (uint256);
    513 | 
    514 |     /**
    515 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 521 行
- **函数**: `transfer()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    518 |      *
    519 |      * Emits a {Transfer} event.
    520 |      */
>>  521 |     function transfer(address to, uint256 value) external returns (bool);
    522 | 
    523 |     /**
    524 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 530 行
- **函数**: `allowance()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    527 |      *
    528 |      * This value changes when {approve} or {transferFrom} are called.
    529 |      */
>>  530 |     function allowance(address owner, address spender) external view returns (uint256);
    531 | 
    532 |     /**
    533 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 547 行
- **函数**: `approve()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    544 |      *
    545 |      * Emits an {Approval} event.
    546 |      */
>>  547 |     function approve(address spender, uint256 value) external returns (bool);
    548 | 
    549 |     /**
    550 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 558 行
- **函数**: `transferFrom()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    555 |      *
    556 |      * Emits a {Transfer} event.
    557 |      */
>>  558 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    559 | }
    560 | 
    561 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 712 行
- **函数**: `hasRole()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    709 |     /**
    710 |      * @dev Returns `true` if `account` has been granted `role`.
    711 |      */
>>  712 |     function hasRole(bytes32 role, address account) external view returns (bool);
    713 | 
    714 |     /**
    715 |      * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 720 行
- **函数**: `getRoleAdmin()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    717 |      *
    718 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
    719 |      */
>>  720 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
    721 | 
    722 |     /**
    723 |      * @dev Grants `role` to `account`.
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 818 行
- **函数**: `supportsInterface()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    815 |  */
    816 | abstract contract ERC165 is IERC165 {
    817 |     /// @inheritdoc IERC165
>>  818 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
    819 |         return interfaceId == type(IERC165).interfaceId;
    820 |     }
    821 | }
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 849 行
- **函数**: `supportsInterface()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    846 |      *
    847 |      * This function call must use less than 30 000 gas.
    848 |      */
>>  849 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
    850 | }
    851 | 
```

---

### 31. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 10 行
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      5 | 
      6 | import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
      7 | import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
      8 | import {SafeMath} from "./libraries/SafeMath.sol";
      9 | 
>>   10 | abstract contract ERC20 is IERC20 {
     11 |     using SafeMath for uint256;
     12 |     
     13 |     mapping(address => uint256) internal _balances;
     14 | 
     15 |     mapping(address => mapping(address => uint256)) internal _allowances;
```

---

### 32. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 174 行
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    169 |         _burn(account_, amount_);
    170 |     }
    171 | }
    172 | 
    173 | 
>>  174 | contract OLY is OLYERC20Token {
    175 |     using SafeMath for uint256;
    176 | 
    177 |     address public mainPair;
    178 |     address public feeReceiver;
    179 | 
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x544028231562a43b106FbceCA722B65Cb5C861b0` 第 318 行
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    313 |  * WARNING: The `DEFAULT_ADMIN_ROLE` is also its own admin: it has permission to
    314 |  * grant and revoke this role. Extra precautions should be taken to secure
    315 |  * accounts that have been granted it. We recommend using {AccessControlDefaultAdminRules}
    316 |  * to enforce additional security measures for this role.
    317 |  */
>>  318 | abstract contract AccessControl is Context, IAccessControl, ERC165 {
    319 |     struct RoleData {
    320 |         mapping(address account => bool) hasRole;
    321 |         bytes32 adminRole;
    322 |     }
    323 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*