# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:04:58
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` |
| contract_name | `ERC1967Proxy` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `True` |
| runs | `1` |
| evm_version | `shanghai` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['lib/openzeppelin-contracts/contracts/proxy/ERC1967/ERC1967Proxy.sol', 'lib/openzeppelin-contracts/contracts/proxy/Proxy.sol', 'lib/openzeppelin-contracts/contracts/proxy/ERC1967/ERC1967Utils.sol', 'lib/openzeppelin-contracts/contracts/proxy/beacon/IBeacon.sol', 'lib/openzeppelin-contracts/contracts/utils/Address.sol', 'lib/openzeppelin-contracts/contracts/utils/StorageSlot.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 6 |
| 🟢 LOW | 13 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 77 行
- **函数**: `_delegate()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
     74 | 
     75 |             // Call the implementation.
     76 |             // out and outsize are 0 because we don't know the size yet.
>>   77 |             let result := delegatecall(gas(), implementation, 0, calldatasize(), 0, 0)
     78 | 
     79 |             // Copy the returned data.
     80 |             returndatacopy(0, 0, returndatasize())
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 441 行
- **函数**: `functionDelegateCall()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    438 |      * but performing a delegate call.
    439 |      */
    440 |     function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
>>  441 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    442 |         return verifyCallResultFromTarget(target, success, returndata);
    443 |     }
    444 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 382 行
- **函数**: `sendValue()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    379 |             revert AddressInsufficientBalance(address(this));
    380 |         }
    381 | 
>>  382 |         (bool success, ) = recipient.call{value: amount}("");
    383 |         if (!success) {
    384 |             revert FailedInnerCall();
    385 |         }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 423 行
- **函数**: `functionCallWithValue()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    420 |         if (address(this).balance < value) {
    421 |             revert AddressInsufficientBalance(address(this));
    422 |         }
>>  423 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    424 |         return verifyCallResultFromTarget(target, success, returndata);
    425 |     }
    426 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 331 行
- **函数**: `implementation()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    328 |      *
    329 |      * {UpgradeableBeacon} will check that this address is a contract.
    330 |      */
>>  331 |     function implementation() external view returns (address);
    332 | }
    333 | 
    334 | 
```

---

### 6. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 12 行
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      7 | 
      8 | import {Proxy} from "../Proxy.sol";
      9 | import {ERC1967Utils} from "./ERC1967Utils.sol";
     10 | 
     11 | /**
>>   12 |  * @dev This contract implements an upgradeable proxy. It is upgradeable because calls are delegated to an
     13 |  * implementation address that can be changed. This address is stored in storage in the location specified by
     14 |  * https://eips.ethereum.org/EIPS/eip-1967[EIP1967], so that it doesn't conflict with the storage layout of the
     15 |  * implementation behind the proxy.
     16 |  */
     17 | contract ERC1967Proxy is Proxy {
```

---

### 7. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 62 行
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     57 |  * Additionally, delegation to the implementation can be triggered manually through the {_fallback} function, or to a
     58 |  * different contract through the {_delegate} function.
     59 |  *
     60 |  * The success and return data of the delegated call will be returned back to the caller of the proxy.
     61 |  */
>>   62 | abstract contract Proxy {
     63 |     /**
     64 |      * @dev Delegates the current call to `implementation`.
     65 |      *
     66 |      * This function does not return to its internal call site, it will return directly to the external caller.
     67 |      */
```

---

### 8. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 130 行
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    125 | import {IBeacon} from "../beacon/IBeacon.sol";
    126 | import {Address} from "../../utils/Address.sol";
    127 | import {StorageSlot} from "../../utils/StorageSlot.sol";
    128 | 
    129 | /**
>>  130 |  * @dev This abstract contract provides getters and event emitting update functions for
    131 |  * https://eips.ethereum.org/EIPS/eip-1967[EIP1967] slots.
    132 |  */
    133 | library ERC1967Utils {
    134 |     // We re-declare ERC-1967 events here because they can't be used directly from IERC1967.
    135 |     // This will be fixed in Solidity 0.8.21. At that point we should remove these events.
```

---

### 9. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 156 行
- **函数**: `_fallback()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    153 |      * This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1.
    154 |      */
    155 |     // solhint-disable-next-line private-vars-leading-underscore
>>  156 |     bytes32 internal constant IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
    157 | 
    158 |     /**
    159 |      * @dev The `implementation` of the proxy is invalid.
```

---

### 10. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 218 行
- **函数**: `upgradeToAndCall()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    215 |      * This is the keccak-256 hash of "eip1967.proxy.admin" subtracted by 1.
    216 |      */
    217 |     // solhint-disable-next-line private-vars-leading-underscore
>>  218 |     bytes32 internal constant ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    219 | 
    220 |     /**
    221 |      * @dev Returns the current admin.
```

---

### 11. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 256 行
- **函数**: `changeAdmin()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    253 |      * This is the keccak-256 hash of "eip1967.proxy.beacon" subtracted by 1.
    254 |      */
    255 |     // solhint-disable-next-line private-vars-leading-underscore
>>  256 |     bytes32 internal constant BEACON_SLOT = 0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50;
    257 | 
    258 |     /**
    259 |      * @dev Returns the current beacon.
```

---

### 12. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 69 行
- **函数**: `_delegate()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     66 |      * This function does not return to its internal call site, it will return directly to the external caller.
     67 |      */
     68 |     function _delegate(address implementation) internal virtual {
>>   69 |         assembly {
     70 |             // Copy msg.data. We take full control of memory in this inline assembly
     71 |             // block because it will not return to Solidity code. We overwrite the
     72 |             // Solidity scratch pad at memory position 0.
```

---

### 13. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 487 行
- **函数**: `_revert()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    484 |         if (returndata.length > 0) {
    485 |             // The easiest way to bubble the revert reason is using memory via assembly
    486 |             /// @solidity memory-safe-assembly
>>  487 |             assembly {
    488 |                 let returndata_size := mload(returndata)
    489 |                 revert(add(32, returndata), returndata_size)
    490 |             }
```

---

### 14. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 560 行
- **函数**: `getAddressSlot()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    557 |      */
    558 |     function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
    559 |         /// @solidity memory-safe-assembly
>>  560 |         assembly {
    561 |             r.slot := slot
    562 |         }
    563 |     }
```

---

### 15. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 570 行
- **函数**: `getBooleanSlot()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    567 |      */
    568 |     function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
    569 |         /// @solidity memory-safe-assembly
>>  570 |         assembly {
    571 |             r.slot := slot
    572 |         }
    573 |     }
```

---

### 16. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 580 行
- **函数**: `getBytes32Slot()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    577 |      */
    578 |     function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
    579 |         /// @solidity memory-safe-assembly
>>  580 |         assembly {
    581 |             r.slot := slot
    582 |         }
    583 |     }
```

---

### 17. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 590 行
- **函数**: `getUint256Slot()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    587 |      */
    588 |     function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
    589 |         /// @solidity memory-safe-assembly
>>  590 |         assembly {
    591 |             r.slot := slot
    592 |         }
    593 |     }
```

---

### 18. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 600 行
- **函数**: `getStringSlot()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    597 |      */
    598 |     function getStringSlot(bytes32 slot) internal pure returns (StringSlot storage r) {
    599 |         /// @solidity memory-safe-assembly
>>  600 |         assembly {
    601 |             r.slot := slot
    602 |         }
    603 |     }
```

---

### 19. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 610 行
- **函数**: `getStringSlot()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    607 |      */
    608 |     function getStringSlot(string storage store) internal pure returns (StringSlot storage r) {
    609 |         /// @solidity memory-safe-assembly
>>  610 |         assembly {
    611 |             r.slot := store.slot
    612 |         }
    613 |     }
```

---

### 20. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 620 行
- **函数**: `getBytesSlot()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    617 |      */
    618 |     function getBytesSlot(bytes32 slot) internal pure returns (BytesSlot storage r) {
    619 |         /// @solidity memory-safe-assembly
>>  620 |         assembly {
    621 |             r.slot := slot
    622 |         }
    623 |     }
```

---

### 21. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xAA16b7ab0dED19BA1F174E5Fc239f13b5595874A` 第 630 行
- **函数**: `getBytesSlot()`
- **合约**: `implements`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    627 |      */
    628 |     function getBytesSlot(bytes storage store) internal pure returns (BytesSlot storage r) {
    629 |         /// @solidity memory-safe-assembly
>>  630 |         assembly {
    631 |             r.slot := store.slot
    632 |         }
    633 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*