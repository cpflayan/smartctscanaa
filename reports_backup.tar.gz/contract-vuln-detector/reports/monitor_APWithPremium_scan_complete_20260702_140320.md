# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:03:20
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` |
| contract_name | `APWithPremium` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `GNU GPLv3` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 21 |
| 🟢 LOW | 9 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 70 行
- **函数**: `getRoleAdmin()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     67 |      *
     68 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
     69 |      */
>>   70 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
     71 | 
     72 |     /**
     73 |      * @dev Grants `role` to `account`.
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 158 行
- **函数**: `supportsInterface()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    155 |      *
    156 |      * This function call must use less than 30 000 gas.
    157 |      */
>>  158 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
    159 | }
    160 | 
    161 | /**
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 401 行
- **函数**: `totalSupply()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    398 | }
    399 | 
    400 | interface IERC20 {
>>  401 |     function totalSupply() external view returns (uint256);
    402 | 
    403 |     function balanceOf(address account) external view returns (uint256);
    404 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 403 行
- **函数**: `balanceOf()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    400 | interface IERC20 {
    401 |     function totalSupply() external view returns (uint256);
    402 | 
>>  403 |     function balanceOf(address account) external view returns (uint256);
    404 | 
    405 |     function transfer(
    406 |         address recipient,
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 415 行
- **函数**: `approve()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    412 |         address spender
    413 |     ) external view returns (uint256);
    414 | 
>>  415 |     function approve(address spender, uint256 amount) external returns (bool);
    416 | 
    417 |     function transferFrom(
    418 |         address sender,
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 481 行
- **函数**: `nonces()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    478 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
    479 |      * prevents a signature from being used multiple times.
    480 |      */
>>  481 |     function nonces(address owner) external view returns (uint256);
    482 | 
    483 |     /**
    484 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 487 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    484 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
    485 |      */
    486 |     // solhint-disable-next-line func-name-mixedcase
>>  487 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    488 | }
    489 | 
    490 | // TODO(zx): Replace all instances of SafeMath with OZ implementation
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 769 行
- **函数**: `name()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    766 |         _decimals = decimals_;
    767 |     }
    768 | 
>>  769 |     function name() public view returns (string memory) {
    770 |         return _name;
    771 |     }
    772 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 773 行
- **函数**: `symbol()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    770 |         return _name;
    771 |     }
    772 | 
>>  773 |     function symbol() public view returns (string memory) {
    774 |         return _symbol;
    775 |     }
    776 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 777 行
- **函数**: `decimals()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    774 |         return _symbol;
    775 |     }
    776 | 
>>  777 |     function decimals() public view virtual returns (uint8) {
    778 |         return _decimals;
    779 |     }
    780 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 781 行
- **函数**: `totalSupply()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    778 |         return _decimals;
    779 |     }
    780 | 
>>  781 |     function totalSupply() public view override returns (uint256) {
    782 |         return _totalSupply;
    783 |     }
    784 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 1022 行
- **函数**: `getRoleAdmin()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1019 |      *
   1020 |      * To change a role's admin, use {_setRoleAdmin}.
   1021 |      */
>> 1022 |     function getRoleAdmin(bytes32 role) public view virtual returns (bytes32) {
   1023 |         return _roles[role].adminRole;
   1024 |     }
   1025 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 1216 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1213 |      * @dev See {IERC20Permit-DOMAIN_SEPARATOR}.
   1214 |      */
   1215 |     // solhint-disable-next-line func-name-mixedcase
>> 1216 |     function DOMAIN_SEPARATOR() external view override returns (bytes32) {
   1217 |         return _domainSeparatorV4();
   1218 |     }
   1219 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 1270 行
- **函数**: `burn()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1267 |         _mint(account_, amount_);
   1268 |     }
   1269 | 
>> 1270 |     function burn(uint256 amount) external override(IERC20, IAP) {
   1271 |         _burn(msg.sender, amount);
   1272 |     }
   1273 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 1274 行
- **函数**: `burnFrom()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1271 |         _burn(msg.sender, amount);
   1272 |     }
   1273 | 
>> 1274 |     function burnFrom(address account_, uint256 amount_) external override {
   1275 |         _burnFrom(account_, amount_);
   1276 |     }
   1277 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 1329 行
- **函数**: `setMainPair()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1326 |         _grantRole(INTERN_SYSTEM, sellTaxReceiver);
   1327 |     }
   1328 | 
>> 1329 |     function setMainPair(address _pair) external onlyDefaultAdmin {
   1330 |         mainPair = _pair;
   1331 |     }
   1332 | 
```

---

### 17. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 595 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    590 |  * ({_hashTypedDataV4}).
    591 |  *
    592 |  * The implementation of the domain separator was designed to be as efficient as possible while still properly updating
    593 |  * the chain id to protect against replay attacks on an eventual fork of the chain.
    594 |  *
>>  595 |  * NOTE: This contract implements the version of the encoding known as "v4", as implemented by the JSON RPC method
    596 |  * https://docs.metamask.io/guide/signing-data.html[`eth_signTypedDataV4` in MetaMask].
    597 |  *
    598 |  * _Available since v3.4._
    599 |  */
    600 | abstract contract EIP712 {
```

---

### 18. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 744 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    739 |     function decrement(Counter storage counter) internal {
    740 |         counter._value = counter._value.sub(1);
    741 |     }
    742 | }
    743 | 
>>  744 | abstract contract ERC20 is IERC20 {
    745 |     using SafeMath for uint256;
    746 | 
    747 |     // TODO comment actual hash value.
    748 |     bytes32 private constant ERC20TOKEN_ERC1820_INTERFACE_ID =
    749 |         keccak256("ERC20Token");
```

---

### 19. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 958 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    953 |  * WARNING: The `DEFAULT_ADMIN_ROLE` is also its own admin: it has permission to
    954 |  * grant and revoke this role. Extra precautions should be taken to secure
    955 |  * accounts that have been granted it. We recommend using {AccessControlDefaultAdminRules}
    956 |  * to enforce additional security measures for this role.
    957 |  */
>>  958 | abstract contract AccessControl is Context, IAccessControl, ERC165 {
    959 |     struct RoleData {
    960 |         mapping(address account => bool) hasRole;
    961 |         bytes32 adminRole;
    962 |     }
    963 | 
```

---

### 20. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 1152 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1147 |  * presenting a message signed by the account. By not relying on `{IERC20-approve}`, the token holder account doesn't
   1148 |  * need to send a transaction, and thus is not required to hold Ether at all.
   1149 |  *
   1150 |  * _Available since v3.4._
   1151 |  */
>> 1152 | abstract contract ERC20Permit is ERC20, IERC20Permit, EIP712 {
   1153 |     using Counters for Counters.Counter;
   1154 | 
   1155 |     mapping(address => Counters.Counter) private _nonces;
   1156 | 
   1157 |     // solhint-disable-next-line var-name-mixedcase
```

---

### 21. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 1290 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1285 |         _approve(account_, msg.sender, decreasedAllowance);
   1286 |         _burn(account_, amount_);
   1287 |     }
   1288 | }
   1289 | 
>> 1290 | contract APWithPremium is APERC20Token {
   1291 |     using SafeMath for uint256;
   1292 | 
   1293 |     address public mainPair;
   1294 |     address public buyTaxReceiver;
   1295 |     address public sellTaxReceiver;
```

---

### 22. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 1182 行
- **函数**: `permit()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1179 |         bytes32 r,
   1180 |         bytes32 s
   1181 |     ) public virtual override {
>> 1182 |         require(block.timestamp <= deadline, "ERC20Permit: expired deadline");
   1183 | 
   1184 |         bytes32 structHash = keccak256(
   1185 |             abi.encode(
```

---

### 23. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 284 行
- **函数**: `tryRecover()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    281 |         assembly {
    282 |             s := and(
    283 |                 vs,
>>  284 |                 0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
    285 |             )
    286 |             v := add(shr(255, vs), 27)
    287 |         }
```

---

### 24. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 329 行
- **函数**: `tryRecover()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    326 |         // these malleable signatures as well.
    327 |         if (
    328 |             uint256(s) >
>>  329 |             0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0
    330 |         ) {
    331 |             return (address(0), RecoverError.InvalidSignatureS);
    332 |         }
```

---

### 25. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 223 行
- **函数**: `tryRecover()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    220 |             uint8 v;
    221 |             // ecrecover takes the signature parameters, and the only way to get them
    222 |             // currently is to use assembly.
>>  223 |             assembly {
    224 |                 r := mload(add(signature, 0x20))
    225 |                 s := mload(add(signature, 0x40))
    226 |                 v := byte(0, mload(add(signature, 0x60)))
```

---

### 26. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 234 行
- **函数**: `tryRecover()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    231 |             bytes32 vs;
    232 |             // ecrecover takes the signature parameters, and the only way to get them
    233 |             // currently is to use assembly.
>>  234 |             assembly {
    235 |                 r := mload(add(signature, 0x20))
    236 |                 vs := mload(add(signature, 0x40))
    237 |             }
```

---

### 27. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 281 行
- **函数**: `tryRecover()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    278 |     ) internal pure returns (address, RecoverError) {
    279 |         bytes32 s;
    280 |         uint8 v;
>>  281 |         assembly {
    282 |             s := and(
    283 |                 vs,
    284 |                 0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
```

---

### 28. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 627 行
- **函数**: `supportsInterface()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    624 |      */
    625 |     constructor(string memory name, string memory version) {
    626 |         uint256 chainID;
>>  627 |         assembly {
    628 |             chainID := chainid()
    629 |         }
    630 | 
```

---

### 29. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 652 行
- **函数**: `_domainSeparatorV4()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    649 |      */
    650 |     function _domainSeparatorV4() internal view returns (bytes32) {
    651 |         uint256 chainID;
>>  652 |         assembly {
    653 |             chainID := chainid()
    654 |         }
    655 | 
```

---

### 30. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x001208F7F53F78Db2b32E1c68198D3e8f320Aa23` 第 674 行
- **函数**: `_buildDomainSeparator()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    671 |         bytes32 versionHash
    672 |     ) private view returns (bytes32) {
    673 |         uint256 chainID;
>>  674 |         assembly {
    675 |             chainID := chainid()
    676 |         }
    677 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*