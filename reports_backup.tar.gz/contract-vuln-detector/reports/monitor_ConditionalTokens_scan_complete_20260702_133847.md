# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:38:47
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xF64b0b318AAf83BD9071110af24D24445719A07F` |
| contract_name | `ConditionalTokens` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/ConditionalTokens/ConditionalTokens.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/IERC20.sol', 'contracts/ConditionalTokens/CTHelpers.sol', 'contracts/ConditionalTokens/WhitelistedERC1155.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/ERC1155.sol', 'node_modules/@openzeppelin/contracts/access/AccessControl.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/IERC1155.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/IERC1155Receiver.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/extensions/IERC1155MetadataURI.sol', 'node_modules/@openzeppelin/contracts/utils/Context.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/ERC165.sol', 'node_modules/@openzeppelin/contracts/utils/Arrays.sol', 'node_modules/@openzeppelin/contracts/interfaces/draft-IERC6093.sol', 'node_modules/@openzeppelin/contracts/access/IAccessControl.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/IERC165.sol', 'node_modules/@openzeppelin/contracts/utils/StorageSlot.sol', 'node_modules/@openzeppelin/contracts/utils/math/Math.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646139` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 33 |
| 🟢 LOW | 22 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 117 行
- **函数**: `prepareCondition()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    114 |     ///
    115 |     /// @param questionId An identifier for the question to be answered by the oracle.
    116 |     /// @param outcomeSlotCount The number of outcome slots which should be used for this condition. Must not exceed 256.
>>  117 |     function prepareCondition(bytes32 questionId, uint outcomeSlotCount) external {
    118 |         // Limit of 256 because we use a partition array that is a number of 256 bits.
    119 |         require(outcomeSlotCount <= 256, "too many outcome slots");
    120 |         require(outcomeSlotCount > 1, "there should be more than one outcome slot");
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 130 行
- **函数**: `reportPayouts()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    127 |     /// @dev Called by the oracle for reporting results of conditions. Will set the payout vector for the condition with the ID ``keccak256(abi.encodePacked(oracle, questionId, outcomeSlotCount))``, where oracle is the message sender, questionId is one of the parameters of this function, and outcomeSlotCount is the length of the payouts parameter, which contains the payoutNumerators for each outcome slot of the condition.
    128 |     /// @param questionId The question ID the oracle is answering for
    129 |     /// @param payouts The oracle's answer
>>  130 |     function reportPayouts(bytes32 questionId, uint[] calldata payouts) external {
    131 |         uint outcomeSlotCount = payouts.length;
    132 |         require(outcomeSlotCount > 1, "there should be more than one outcome slot");
    133 |         // IMPORTANT, the oracle is enforced to be the sender because it's part of the hash.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 330 行
- **函数**: `getOutcomeSlotCount()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    327 |     /// @dev Gets the outcome slot count of a condition.
    328 |     /// @param conditionId ID of the condition.
    329 |     /// @return Number of outcome slots associated with a condition, or zero if condition has not been prepared yet.
>>  330 |     function getOutcomeSlotCount(bytes32 conditionId) external view returns (uint) {
    331 |         return payoutNumerators[conditionId].length;
    332 |     }
    333 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 338 行
- **函数**: `getConditionId()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    335 |     /// @param oracle The account assigned to report the result for the prepared condition.
    336 |     /// @param questionId An identifier for the question to be answered by the oracle.
    337 |     /// @param outcomeSlotCount The number of outcome slots which should be used for this condition. Must not exceed 256.
>>  338 |     function getConditionId(address oracle, bytes32 questionId, uint outcomeSlotCount) external pure returns (bytes32) {
    339 |         return CTHelpers.getConditionId(oracle, questionId, outcomeSlotCount);
    340 |     }
    341 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 357 行
- **函数**: `getPositionId()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    354 |     /// @dev Constructs a position ID from a collateral token and an outcome collection. These IDs are used as the ERC-1155 ID for this contract.
    355 |     /// @param collateralToken Collateral token which backs the position.
    356 |     /// @param collectionId ID of the outcome collection associated with this position.
>>  357 |     function getPositionId(IERC20 collateralToken, bytes32 collectionId) external pure returns (uint) {
    358 |         return CTHelpers.getPositionId(collateralToken, collectionId);
    359 |     }
    360 | }
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 391 行
- **函数**: `totalSupply()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    388 |     /**
    389 |      * @dev Returns the value of tokens in existence.
    390 |      */
>>  391 |     function totalSupply() external view returns (uint256);
    392 | 
    393 |     /**
    394 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 396 行
- **函数**: `balanceOf()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    393 |     /**
    394 |      * @dev Returns the value of tokens owned by `account`.
    395 |      */
>>  396 |     function balanceOf(address account) external view returns (uint256);
    397 | 
    398 |     /**
    399 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 405 行
- **函数**: `transfer()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    402 |      *
    403 |      * Emits a {Transfer} event.
    404 |      */
>>  405 |     function transfer(address to, uint256 value) external returns (bool);
    406 | 
    407 |     /**
    408 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 414 行
- **函数**: `allowance()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    411 |      *
    412 |      * This value changes when {approve} or {transferFrom} are called.
    413 |      */
>>  414 |     function allowance(address owner, address spender) external view returns (uint256);
    415 | 
    416 |     /**
    417 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 431 行
- **函数**: `approve()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    428 |      *
    429 |      * Emits an {Approval} event.
    430 |      */
>>  431 |     function approve(address spender, uint256 value) external returns (bool);
    432 | 
    433 |     /**
    434 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 442 行
- **函数**: `transferFrom()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    439 |      *
    440 |      * Emits a {Transfer} event.
    441 |      */
>>  442 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    443 | }
    444 | 
    445 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 991 行
- **函数**: `supportsInterface()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    988 |                             OVERRIDES
    989 |     //////////////////////////////////////////////////////////////////*/
    990 | 
>>  991 |     function supportsInterface(bytes4 interfaceId) public view virtual override(ERC1155, AccessControl) returns (bool) {
    992 |         return
    993 |             interfaceId == type(ERC1155).interfaceId ||
    994 |             interfaceId == type(AccessControl).interfaceId ||
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1041 行
- **函数**: `supportsInterface()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1038 |     /**
   1039 |      * @dev See {IERC165-supportsInterface}.
   1040 |      */
>> 1041 |     function supportsInterface(bytes4 interfaceId) public view virtual override(ERC165, IERC165) returns (bool) {
   1042 |         return
   1043 |             interfaceId == type(IERC1155).interfaceId ||
   1044 |             interfaceId == type(IERC1155MetadataURI).interfaceId ||
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1058 行
- **函数**: `uri()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1055 |      * Clients calling this function must replace the `\{id\}` substring with the
   1056 |      * actual token type ID.
   1057 |      */
>> 1058 |     function uri(uint256 /* id */) public view virtual returns (string memory) {
   1059 |         return _uri;
   1060 |     }
   1061 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1065 行
- **函数**: `balanceOf()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1062 |     /**
   1063 |      * @dev See {IERC1155-balanceOf}.
   1064 |      */
>> 1065 |     function balanceOf(address account, uint256 id) public view virtual returns (uint256) {
   1066 |         return _balances[id][account];
   1067 |     }
   1068 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1096 行
- **函数**: `setApprovalForAll()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1093 |     /**
   1094 |      * @dev See {IERC1155-setApprovalForAll}.
   1095 |      */
>> 1096 |     function setApprovalForAll(address operator, bool approved) public virtual {
   1097 |         _setApprovalForAll(_msgSender(), operator, approved);
   1098 |     }
   1099 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1103 行
- **函数**: `isApprovedForAll()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1100 |     /**
   1101 |      * @dev See {IERC1155-isApprovedForAll}.
   1102 |      */
>> 1103 |     function isApprovedForAll(address account, address operator) public view virtual returns (bool) {
   1104 |         return _operatorApprovals[account][operator];
   1105 |     }
   1106 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1110 行
- **函数**: `safeTransferFrom()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1107 |     /**
   1108 |      * @dev See {IERC1155-safeTransferFrom}.
   1109 |      */
>> 1110 |     function safeTransferFrom(address from, address to, uint256 id, uint256 value, bytes memory data) public virtual {
   1111 |         address sender = _msgSender();
   1112 |         if (from != sender && !isApprovedForAll(from, sender)) {
   1113 |             revert ERC1155MissingApprovalForAll(sender, from);
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1544 行
- **函数**: `supportsInterface()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1541 |     /**
   1542 |      * @dev See {IERC165-supportsInterface}.
   1543 |      */
>> 1544 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
   1545 |         return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
   1546 |     }
   1547 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1551 行
- **函数**: `hasRole()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1548 |     /**
   1549 |      * @dev Returns `true` if `account` has been granted `role`.
   1550 |      */
>> 1551 |     function hasRole(bytes32 role, address account) public view virtual returns (bool) {
   1552 |         return _roles[role].hasRole[account];
   1553 |     }
   1554 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1579 行
- **函数**: `getRoleAdmin()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1576 |      *
   1577 |      * To change a role's admin, use {_setRoleAdmin}.
   1578 |      */
>> 1579 |     function getRoleAdmin(bytes32 role) public view virtual returns (bytes32) {
   1580 |         return _roles[role].adminRole;
   1581 |     }
   1582 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1630 行
- **函数**: `renounceRole()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1627 |      *
   1628 |      * May emit a {RoleRevoked} event.
   1629 |      */
>> 1630 |     function renounceRole(bytes32 role, address callerConfirmation) public virtual {
   1631 |         if (callerConfirmation != _msgSender()) {
   1632 |             revert AccessControlBadConfirmation();
   1633 |         }
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1738 行
- **函数**: `balanceOf()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1735 |      *
   1736 |      * - `account` cannot be the zero address.
   1737 |      */
>> 1738 |     function balanceOf(address account, uint256 id) external view returns (uint256);
   1739 | 
   1740 |     /**
   1741 |      * @dev xref:ROOT:erc1155.adoc#batch-operations[Batched] version of {balanceOf}.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1768 行
- **函数**: `isApprovedForAll()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1765 |      *
   1766 |      * See {setApprovalForAll}.
   1767 |      */
>> 1768 |     function isApprovedForAll(address account, address operator) external view returns (bool);
   1769 | 
   1770 |     /**
   1771 |      * @dev Transfers a `value` amount of tokens of type `id` from `from` to `to`.
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1899 行
- **函数**: `uri()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1896 |      * If the `\{id\}` substring is present in the URI, it must be replaced by
   1897 |      * clients with the actual token type ID.
   1898 |      */
>> 1899 |     function uri(uint256 id) external view returns (string memory);
   1900 | }
   1901 | 
   1902 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1960 行
- **函数**: `supportsInterface()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1957 |     /**
   1958 |      * @dev See {IERC165-supportsInterface}.
   1959 |      */
>> 1960 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   1961 |         return interfaceId == type(IERC165).interfaceId;
   1962 |     }
   1963 | }
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2313 行
- **函数**: `hasRole()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2310 |     /**
   2311 |      * @dev Returns `true` if `account` has been granted `role`.
   2312 |      */
>> 2313 |     function hasRole(bytes32 role, address account) external view returns (bool);
   2314 | 
   2315 |     /**
   2316 |      * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2321 行
- **函数**: `getRoleAdmin()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2318 |      *
   2319 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
   2320 |      */
>> 2321 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
   2322 | 
   2323 |     /**
   2324 |      * @dev Grants `role` to `account`.
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2389 行
- **函数**: `supportsInterface()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2386 |      *
   2387 |      * This function call must use less than 30 000 gas.
   2388 |      */
>> 2389 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   2390 | }
   2391 | 
   2392 | 
```

---

### 30. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 10 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      5 | 
      6 | import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
      7 | import {CTHelpers} from "./CTHelpers.sol";
      8 | import {WhitelistedERC1155} from "./WhitelistedERC1155.sol";
      9 | 
>>   10 | contract ConditionalTokens is WhitelistedERC1155 {
     11 |     bytes32 public constant SPLIT_POSITION_ROLE = keccak256("SPLIT_POSITION_ROLE");
     12 |     bytes32 public constant MERGE_POSITIONS_ROLE = keccak256("MERGE_POSITIONS_ROLE");
     13 | 
     14 |     /**
     15 |      * @notice Enable or disable split position gating.
```

---

### 31. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 896 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    891 | 
    892 | /**
    893 |  * @title WhitelistedERC1155
    894 |  * @notice ERC1155 extension with optional transfer whitelist control
    895 |  */
>>  896 | contract WhitelistedERC1155 is ERC1155, AccessControl {
    897 |     /**
    898 |      * @notice Enable or disable CTF transfers.
    899 |      *         It is enabled by default, but if something breaks, it can be disabled as it
    900 |      *         is the default behavior of the original implementation.
    901 |      */
```

---

### 32. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1020 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1015 | /**
   1016 |  * @dev Implementation of the basic standard multi-token.
   1017 |  * See https://eips.ethereum.org/EIPS/eip-1155
   1018 |  * Originally based on code by Enjin: https://github.com/enjin/erc-1155
   1019 |  */
>> 1020 | abstract contract ERC1155 is Context, ERC165, IERC1155, IERC1155MetadataURI, IERC1155Errors {
   1021 |     using Arrays for uint256[];
   1022 |     using Arrays for address[];
   1023 | 
   1024 |     mapping(uint256 id => mapping(address account => uint256)) private _balances;
   1025 | 
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1522 行
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1517 |  * WARNING: The `DEFAULT_ADMIN_ROLE` is also its own admin: it has permission to
   1518 |  * grant and revoke this role. Extra precautions should be taken to secure
   1519 |  * accounts that have been granted it. We recommend using {AccessControlDefaultAdminRules}
   1520 |  * to enforce additional security measures for this role.
   1521 |  */
>> 1522 | abstract contract AccessControl is Context, IAccessControl, ERC165 {
   1523 |     struct RoleData {
   1524 |         mapping(address account => bool) hasRole;
   1525 |         bytes32 adminRole;
   1526 |     }
   1527 | 
```

---

### 34. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 259 行
- **函数**: `mergePositions()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    256 | 
    257 |         if (freeIndexSet == 0) {
    258 |             if (parentCollectionId == bytes32(0)) {
>>  259 |                 require(collateralToken.transfer(msg.sender, amount), "could not send collateral tokens");
    260 |             } else {
    261 |                 _mint(msg.sender, CTHelpers.getPositionId(collateralToken, parentCollectionId), amount, "");
    262 |             }
```

---

### 35. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 317 行
- **函数**: `redeemPositions()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    314 |         if (totalPayout > 0) {
    315 |             if (parentCollectionId == bytes32(0)) {
    316 |                 require(
>>  317 |                     collateralToken.transfer(msg.sender, totalPayout),
    318 |                     "could not transfer payout to message sender"
    319 |                 );
    320 |             } else {
```

---

### 36. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 468 行
- **函数**: `sqrt()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    465 |     function sqrt(uint x) private pure returns (uint y) {
    466 |         uint p = P;
    467 |         // solium-disable-next-line security/no-inline-assembly
>>  468 |         assembly {
    469 |             // add chain generated via https://crypto.stackexchange.com/q/27179/71252
    470 |             // and transformed to the following program:
    471 | 
```

---

### 37. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1402 行
- **函数**: `_doSafeTransferAcceptanceCheck()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1399 |                     revert ERC1155InvalidReceiver(to);
   1400 |                 } else {
   1401 |                     /// @solidity memory-safe-assembly
>> 1402 |                     assembly {
   1403 |                         revert(add(32, reason), mload(reason))
   1404 |                     }
   1405 |                 }
```

---

### 38. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1436 行
- **函数**: `_doSafeBatchTransferAcceptanceCheck()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1433 |                     revert ERC1155InvalidReceiver(to);
   1434 |                 } else {
   1435 |                     /// @solidity memory-safe-assembly
>> 1436 |                     assembly {
   1437 |                         revert(add(32, reason), mload(reason))
   1438 |                     }
   1439 |                 }
```

---

### 39. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 1452 行
- **函数**: `_asSingletonArrays()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1449 |         uint256 element2
   1450 |     ) private pure returns (uint256[] memory array1, uint256[] memory array2) {
   1451 |         /// @solidity memory-safe-assembly
>> 1452 |         assembly {
   1453 |             // Load the free memory pointer
   1454 |             array1 := mload(0x40)
   1455 |             // Set array length to 1
```

---

### 40. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2030 行
- **函数**: `unsafeAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2027 |         // following https://docs.soliditylang.org/en/v0.8.20/internals/layout_in_storage.html#mappings-and-dynamic-arrays.
   2028 | 
   2029 |         /// @solidity memory-safe-assembly
>> 2030 |         assembly {
   2031 |             mstore(0, arr.slot)
   2032 |             slot := add(keccak256(0, 0x20), pos)
   2033 |         }
```

---

### 41. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2048 行
- **函数**: `unsafeAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2045 |         // following https://docs.soliditylang.org/en/v0.8.20/internals/layout_in_storage.html#mappings-and-dynamic-arrays.
   2046 | 
   2047 |         /// @solidity memory-safe-assembly
>> 2048 |         assembly {
   2049 |             mstore(0, arr.slot)
   2050 |             slot := add(keccak256(0, 0x20), pos)
   2051 |         }
```

---

### 42. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2066 行
- **函数**: `unsafeAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2063 |         // following https://docs.soliditylang.org/en/v0.8.20/internals/layout_in_storage.html#mappings-and-dynamic-arrays.
   2064 | 
   2065 |         /// @solidity memory-safe-assembly
>> 2066 |         assembly {
   2067 |             mstore(0, arr.slot)
   2068 |             slot := add(keccak256(0, 0x20), pos)
   2069 |         }
```

---

### 43. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2079 行
- **函数**: `unsafeMemoryAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2076 |      * WARNING: Only use if you are certain `pos` is lower than the array length.
   2077 |      */
   2078 |     function unsafeMemoryAccess(uint256[] memory arr, uint256 pos) internal pure returns (uint256 res) {
>> 2079 |         assembly {
   2080 |             res := mload(add(add(arr, 0x20), mul(pos, 0x20)))
   2081 |         }
   2082 |     }
```

---

### 44. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2090 行
- **函数**: `unsafeMemoryAccess()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2087 |      * WARNING: Only use if you are certain `pos` is lower than the array length.
   2088 |      */
   2089 |     function unsafeMemoryAccess(address[] memory arr, uint256 pos) internal pure returns (address res) {
>> 2090 |         assembly {
   2091 |             res := mload(add(add(arr, 0x20), mul(pos, 0x20)))
   2092 |         }
   2093 |     }
```

---

### 45. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2455 行
- **函数**: `getAddressSlot()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2452 |      */
   2453 |     function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
   2454 |         /// @solidity memory-safe-assembly
>> 2455 |         assembly {
   2456 |             r.slot := slot
   2457 |         }
   2458 |     }
```

---

### 46. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2465 行
- **函数**: `getBooleanSlot()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2462 |      */
   2463 |     function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
   2464 |         /// @solidity memory-safe-assembly
>> 2465 |         assembly {
   2466 |             r.slot := slot
   2467 |         }
   2468 |     }
```

---

### 47. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2475 行
- **函数**: `getBytes32Slot()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2472 |      */
   2473 |     function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
   2474 |         /// @solidity memory-safe-assembly
>> 2475 |         assembly {
   2476 |             r.slot := slot
   2477 |         }
   2478 |     }
```

---

### 48. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2485 行
- **函数**: `getUint256Slot()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2482 |      */
   2483 |     function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
   2484 |         /// @solidity memory-safe-assembly
>> 2485 |         assembly {
   2486 |             r.slot := slot
   2487 |         }
   2488 |     }
```

---

### 49. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2495 行
- **函数**: `getStringSlot()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2492 |      */
   2493 |     function getStringSlot(bytes32 slot) internal pure returns (StringSlot storage r) {
   2494 |         /// @solidity memory-safe-assembly
>> 2495 |         assembly {
   2496 |             r.slot := slot
   2497 |         }
   2498 |     }
```

---

### 50. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2505 行
- **函数**: `getStringSlot()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2502 |      */
   2503 |     function getStringSlot(string storage store) internal pure returns (StringSlot storage r) {
   2504 |         /// @solidity memory-safe-assembly
>> 2505 |         assembly {
   2506 |             r.slot := store.slot
   2507 |         }
   2508 |     }
```

---

### 51. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2515 行
- **函数**: `getBytesSlot()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2512 |      */
   2513 |     function getBytesSlot(bytes32 slot) internal pure returns (BytesSlot storage r) {
   2514 |         /// @solidity memory-safe-assembly
>> 2515 |         assembly {
   2516 |             r.slot := slot
   2517 |         }
   2518 |     }
```

---

### 52. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2525 行
- **函数**: `getBytesSlot()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2522 |      */
   2523 |     function getBytesSlot(bytes storage store) internal pure returns (BytesSlot storage r) {
   2524 |         /// @solidity memory-safe-assembly
>> 2525 |         assembly {
   2526 |             r.slot := store.slot
   2527 |         }
   2528 |     }
```

---

### 53. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2663 行
- **函数**: `mulDiv()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2660 |             // variables such that product = prod1 * 2^256 + prod0.
   2661 |             uint256 prod0 = x * y; // Least significant 256 bits of the product
   2662 |             uint256 prod1; // Most significant 256 bits of the product
>> 2663 |             assembly {
   2664 |                 let mm := mulmod(x, y, not(0))
   2665 |                 prod1 := sub(sub(mm, prod0), lt(mm, prod0))
   2666 |             }
```

---

### 54. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2687 行
- **函数**: `mulDiv()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2684 | 
   2685 |             // Make division exact by subtracting the remainder from [prod1 prod0].
   2686 |             uint256 remainder;
>> 2687 |             assembly {
   2688 |                 // Compute remainder using mulmod.
   2689 |                 remainder := mulmod(x, y, denominator)
   2690 | 
```

---

### 55. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF64b0b318AAf83BD9071110af24D24445719A07F` 第 2700 行
- **函数**: `mulDiv()`
- **合约**: `ConditionalTokens`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2697 |             // Always >= 1. See https://cs.stackexchange.com/q/138556/92363.
   2698 | 
   2699 |             uint256 twos = denominator & (0 - denominator);
>> 2700 |             assembly {
   2701 |                 // Divide denominator by twos.
   2702 |                 denominator := div(denominator, twos)
   2703 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*