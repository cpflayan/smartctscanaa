# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:20:21
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` |
| contract_name | `WBNB` |
| compiler_version | `v0.4.18+commit.9cf6e910` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `GNU GPLv3` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646143` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 6 |
| 🟢 LOW | 2 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` 第 23 行
- **函数**: `deposit()`
- **合约**: `WBNB`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     20 |     function() public payable {
     21 |         deposit();
     22 |     }
>>   23 |     function deposit() public payable {
     24 |         balanceOf[msg.sender] += msg.value;
     25 |         Deposit(msg.sender, msg.value);
     26 |     }
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` 第 27 行
- **函数**: `withdraw()`
- **合约**: `WBNB`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     24 |         balanceOf[msg.sender] += msg.value;
     25 |         Deposit(msg.sender, msg.value);
     26 |     }
>>   27 |     function withdraw(uint wad) public {
     28 |         require(balanceOf[msg.sender] >= wad);
     29 |         balanceOf[msg.sender] -= wad;
     30 |         msg.sender.transfer(wad);
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` 第 34 行
- **函数**: `totalSupply()`
- **合约**: `WBNB`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     31 |         Withdrawal(msg.sender, wad);
     32 |     }
     33 | 
>>   34 |     function totalSupply() public view returns (uint) {
     35 |         return this.balance;
     36 |     }
     37 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` 第 38 行
- **函数**: `approve()`
- **合约**: `WBNB`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     35 |         return this.balance;
     36 |     }
     37 | 
>>   38 |     function approve(address guy, uint wad) public returns (bool) {
     39 |         allowance[msg.sender][guy] = wad;
     40 |         Approval(msg.sender, guy, wad);
     41 |         return true;
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` 第 44 行
- **函数**: `transfer()`
- **合约**: `WBNB`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     41 |         return true;
     42 |     }
     43 | 
>>   44 |     function transfer(address dst, uint wad) public returns (bool) {
     45 |         return transferFrom(msg.sender, dst, wad);
     46 |     }
     47 | 
```

---

### 6. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` 第 7 行
- **合约**: `WBNB`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      2 |  *Submitted for verification at Bscscan.com on 2020-09-03
      3 | */
      4 | 
      5 | pragma solidity ^0.4.18;
      6 | 
>>    7 | contract WBNB {
      8 |     string public name     = "Wrapped BNB";
      9 |     string public symbol   = "WBNB";
     10 |     uint8  public decimals = 18;
     11 | 
     12 |     event  Approval(address indexed src, address indexed guy, uint wad);
```

---

### 7. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` 第 5 行
- **合约**: `WBNB`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
      2 |  *Submitted for verification at Bscscan.com on 2020-09-03
      3 | */
      4 | 
>>    5 | pragma solidity ^0.4.18;
      6 | 
      7 | contract WBNB {
      8 |     string public name     = "Wrapped BNB";
```

---

### 8. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c` 第 30 行
- **函数**: `withdraw()`
- **合约**: `WBNB`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
     27 |     function withdraw(uint wad) public {
     28 |         require(balanceOf[msg.sender] >= wad);
     29 |         balanceOf[msg.sender] -= wad;
>>   30 |         msg.sender.transfer(wad);
     31 |         Withdrawal(msg.sender, wad);
     32 |     }
     33 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*