# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:15:06
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` |
| contract_name | `NonfungiblePositionManager` |
| compiler_version | `v0.7.6+commit.7338295f` |
| optimization_used | `True` |
| runs | `2000` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `True` |
| implementation | `0x46a15b0b27311cedf172ab29e4f4766fbe7f4364` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/drafts/IERC20Permit.sol', '@openzeppelin/contracts/introspection/ERC165.sol', '@openzeppelin/contracts/introspection/IERC165.sol', '@openzeppelin/contracts/math/SafeMath.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC721/ERC721.sol', '@openzeppelin/contracts/token/ERC721/IERC721.sol', '@openzeppelin/contracts/token/ERC721/IERC721Enumerable.sol', '@openzeppelin/contracts/token/ERC721/IERC721Metadata.sol', '@openzeppelin/contracts/token/ERC721/IERC721Receiver.sol', '@openzeppelin/contracts/utils/Address.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/utils/EnumerableMap.sol', '@openzeppelin/contracts/utils/EnumerableSet.sol', '@openzeppelin/contracts/utils/Strings.sol', '@pancakeswap/v3-core/contracts/interfaces/callback/IPancakeV3MintCallback.sol', '@pancakeswap/v3-core/contracts/interfaces/IPancakeV3Factory.sol', '@pancakeswap/v3-core/contracts/interfaces/IPancakeV3Pool.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolActions.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolDerivedState.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolEvents.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolImmutables.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolOwnerActions.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolState.sol', '@pancakeswap/v3-core/contracts/libraries/FixedPoint128.sol', '@pancakeswap/v3-core/contracts/libraries/FixedPoint96.sol', '@pancakeswap/v3-core/contracts/libraries/FullMath.sol', '@pancakeswap/v3-core/contracts/libraries/TickMath.sol', 'contracts/base/BlockTimestamp.sol', 'contracts/base/ERC721Permit.sol', 'contracts/base/LiquidityManagement.sol', 'contracts/base/Multicall.sol', 'contracts/base/PeripheryImmutableState.sol', 'contracts/base/PeripheryPayments.sol', 'contracts/base/PeripheryValidation.sol', 'contracts/base/PoolInitializer.sol', 'contracts/base/SelfPermit.sol', 'contracts/interfaces/external/IERC1271.sol', 'contracts/interfaces/external/IERC20PermitAllowed.sol', 'contracts/interfaces/external/IWETH9.sol', 'contracts/interfaces/IERC721Permit.sol', 'contracts/interfaces/IMulticall.sol', 'contracts/interfaces/INonfungiblePositionManager.sol', 'contracts/interfaces/INonfungibleTokenPositionDescriptor.sol', 'contracts/interfaces/IPeripheryImmutableState.sol', 'contracts/interfaces/IPeripheryPayments.sol', 'contracts/interfaces/IPoolInitializer.sol', 'contracts/interfaces/ISelfPermit.sol', 'contracts/libraries/CallbackValidation.sol', 'contracts/libraries/ChainId.sol', 'contracts/libraries/LiquidityAmounts.sol', 'contracts/libraries/PoolAddress.sol', 'contracts/libraries/PositionKey.sol', 'contracts/libraries/TransferHelper.sol', 'contracts/NonfungiblePositionManager.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646143` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 92 |
| 🟢 LOW | 51 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1313 行
- **函数**: `functionDelegateCall()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1310 |         require(isContract(target), "Address: delegate call to non-contract");
   1311 | 
   1312 |         // solhint-disable-next-line avoid-low-level-calls
>> 1313 |         (bool success, bytes memory returndata) = target.delegatecall(data);
   1314 |         return _verifyCallResult(success, returndata, errorMessage);
   1315 |     }
   1316 | 
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3205 行
- **函数**: `multicall()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   3202 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
   3203 |         results = new bytes[](data.length);
   3204 |         for (uint256 i = 0; i < data.length; i++) {
>> 3205 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
   3206 | 
   3207 |             if (!success) {
   3208 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
```

---

### 3. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4211 行
- **函数**: `safeTransferFrom()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   4208 |         uint256 value
   4209 |     ) internal {
   4210 |         (bool success, bytes memory data) =
>> 4211 |             token.call(abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, value));
   4212 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'STF');
   4213 |     }
   4214 | 
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4225 行
- **函数**: `safeTransfer()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   4222 |         address to,
   4223 |         uint256 value
   4224 |     ) internal {
>> 4225 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transfer.selector, to, value));
   4226 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'ST');
   4227 |     }
   4228 | 
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4239 行
- **函数**: `safeApprove()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   4236 |         address to,
   4237 |         uint256 value
   4238 |     ) internal {
>> 4239 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.approve.selector, to, value));
   4240 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'SA');
   4241 |     }
   4242 | 
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4248 行
- **函数**: `safeTransferETH()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   4245 |     /// @param to The destination of the transfer
   4246 |     /// @param value The value to be transferred
   4247 |     function safeTransferETH(address to, uint256 value) internal {
>> 4248 |         (bool success, ) = to.call{value: value}(new bytes(0));
   4249 |         require(success, 'STE');
   4250 |     }
   4251 | }
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 46 行
- **函数**: `nonces()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     43 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
     44 |      * prevents a signature from being used multiple times.
     45 |      */
>>   46 |     function nonces(address owner) external view returns (uint256);
     47 | 
     48 |     /**
     49 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 52 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     49 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
     50 |      */
     51 |     // solhint-disable-next-line func-name-mixedcase
>>   52 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
     53 | }
     54 | 
     55 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 92 行
- **函数**: `supportsInterface()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     89 |      *
     90 |      * Time complexity O(1), guaranteed to always use less than 30 000 gas.
     91 |      */
>>   92 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
     93 |         return _supportedInterfaces[interfaceId];
     94 |     }
     95 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 138 行
- **函数**: `supportsInterface()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    135 |      *
    136 |      * This function call must use less than 30 000 gas.
    137 |      */
>>  138 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
    139 | }
    140 | 
    141 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 373 行
- **函数**: `totalSupply()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    370 |     /**
    371 |      * @dev Returns the amount of tokens in existence.
    372 |      */
>>  373 |     function totalSupply() external view returns (uint256);
    374 | 
    375 |     /**
    376 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 378 行
- **函数**: `balanceOf()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    375 |     /**
    376 |      * @dev Returns the amount of tokens owned by `account`.
    377 |      */
>>  378 |     function balanceOf(address account) external view returns (uint256);
    379 | 
    380 |     /**
    381 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 387 行
- **函数**: `transfer()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    384 |      *
    385 |      * Emits a {Transfer} event.
    386 |      */
>>  387 |     function transfer(address recipient, uint256 amount) external returns (bool);
    388 | 
    389 |     /**
    390 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 396 行
- **函数**: `allowance()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    393 |      *
    394 |      * This value changes when {approve} or {transferFrom} are called.
    395 |      */
>>  396 |     function allowance(address owner, address spender) external view returns (uint256);
    397 | 
    398 |     /**
    399 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 412 行
- **函数**: `approve()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    409 |      *
    410 |      * Emits an {Approval} event.
    411 |      */
>>  412 |     function approve(address spender, uint256 amount) external returns (bool);
    413 | 
    414 |     /**
    415 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 423 行
- **函数**: `transferFrom()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    420 |      *
    421 |      * Emits a {Transfer} event.
    422 |      */
>>  423 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    424 | 
    425 |     /**
    426 |      * @dev Emitted when `value` tokens are moved from one account (`from`) to
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 548 行
- **函数**: `balanceOf()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    545 |     /**
    546 |      * @dev See {IERC721-balanceOf}.
    547 |      */
>>  548 |     function balanceOf(address owner) public view virtual override returns (uint256) {
    549 |         require(owner != address(0), "ERC721: balance query for the zero address");
    550 |         return _holderTokens[owner].length();
    551 |     }
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 556 行
- **函数**: `ownerOf()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    553 |     /**
    554 |      * @dev See {IERC721-ownerOf}.
    555 |      */
>>  556 |     function ownerOf(uint256 tokenId) public view virtual override returns (address) {
    557 |         return _tokenOwners.get(tokenId, "ERC721: owner query for nonexistent token");
    558 |     }
    559 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 563 行
- **函数**: `name()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    560 |     /**
    561 |      * @dev See {IERC721Metadata-name}.
    562 |      */
>>  563 |     function name() public view virtual override returns (string memory) {
    564 |         return _name;
    565 |     }
    566 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 570 行
- **函数**: `symbol()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    567 |     /**
    568 |      * @dev See {IERC721Metadata-symbol}.
    569 |      */
>>  570 |     function symbol() public view virtual override returns (string memory) {
    571 |         return _symbol;
    572 |     }
    573 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 577 行
- **函数**: `tokenURI()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    574 |     /**
    575 |      * @dev See {IERC721Metadata-tokenURI}.
    576 |      */
>>  577 |     function tokenURI(uint256 tokenId) public view virtual override returns (string memory) {
    578 |         require(_exists(tokenId), "ERC721Metadata: URI query for nonexistent token");
    579 | 
    580 |         string memory _tokenURI = _tokenURIs[tokenId];
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 600 行
- **函数**: `baseURI()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    597 |     * automatically added as a prefix in {tokenURI} to each token's URI, or
    598 |     * to the token ID if no specific URI is set for that token ID.
    599 |     */
>>  600 |     function baseURI() public view virtual returns (string memory) {
    601 |         return _baseURI;
    602 |     }
    603 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 607 行
- **函数**: `tokenOfOwnerByIndex()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    604 |     /**
    605 |      * @dev See {IERC721Enumerable-tokenOfOwnerByIndex}.
    606 |      */
>>  607 |     function tokenOfOwnerByIndex(address owner, uint256 index) public view virtual override returns (uint256) {
    608 |         return _holderTokens[owner].at(index);
    609 |     }
    610 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 614 行
- **函数**: `totalSupply()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    611 |     /**
    612 |      * @dev See {IERC721Enumerable-totalSupply}.
    613 |      */
>>  614 |     function totalSupply() public view virtual override returns (uint256) {
    615 |         // _tokenOwners are indexed by tokenIds, so .length() returns the number of tokenIds
    616 |         return _tokenOwners.length();
    617 |     }
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 622 行
- **函数**: `tokenByIndex()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    619 |     /**
    620 |      * @dev See {IERC721Enumerable-tokenByIndex}.
    621 |      */
>>  622 |     function tokenByIndex(uint256 index) public view virtual override returns (uint256) {
    623 |         (uint256 tokenId, ) = _tokenOwners.at(index);
    624 |         return tokenId;
    625 |     }
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 630 行
- **函数**: `approve()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    627 |     /**
    628 |      * @dev See {IERC721-approve}.
    629 |      */
>>  630 |     function approve(address to, uint256 tokenId) public virtual override {
    631 |         address owner = ERC721.ownerOf(tokenId);
    632 |         require(to != owner, "ERC721: approval to current owner");
    633 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 644 行
- **函数**: `getApproved()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    641 |     /**
    642 |      * @dev See {IERC721-getApproved}.
    643 |      */
>>  644 |     function getApproved(uint256 tokenId) public view virtual override returns (address) {
    645 |         require(_exists(tokenId), "ERC721: approved query for nonexistent token");
    646 | 
    647 |         return _tokenApprovals[tokenId];
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 653 行
- **函数**: `setApprovalForAll()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    650 |     /**
    651 |      * @dev See {IERC721-setApprovalForAll}.
    652 |      */
>>  653 |     function setApprovalForAll(address operator, bool approved) public virtual override {
    654 |         require(operator != _msgSender(), "ERC721: approve to caller");
    655 | 
    656 |         _operatorApprovals[_msgSender()][operator] = approved;
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 663 行
- **函数**: `isApprovedForAll()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    660 |     /**
    661 |      * @dev See {IERC721-isApprovedForAll}.
    662 |      */
>>  663 |     function isApprovedForAll(address owner, address operator) public view virtual override returns (bool) {
    664 |         return _operatorApprovals[owner][operator];
    665 |     }
    666 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 670 行
- **函数**: `transferFrom()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    667 |     /**
    668 |      * @dev See {IERC721-transferFrom}.
    669 |      */
>>  670 |     function transferFrom(address from, address to, uint256 tokenId) public virtual override {
    671 |         //solhint-disable-next-line max-line-length
    672 |         require(_isApprovedOrOwner(_msgSender(), tokenId), "ERC721: transfer caller is not owner nor approved");
    673 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 680 行
- **函数**: `safeTransferFrom()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    677 |     /**
    678 |      * @dev See {IERC721-safeTransferFrom}.
    679 |      */
>>  680 |     function safeTransferFrom(address from, address to, uint256 tokenId) public virtual override {
    681 |         safeTransferFrom(from, to, tokenId, "");
    682 |     }
    683 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 687 行
- **函数**: `safeTransferFrom()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    684 |     /**
    685 |      * @dev See {IERC721-safeTransferFrom}.
    686 |      */
>>  687 |     function safeTransferFrom(address from, address to, uint256 tokenId, bytes memory _data) public virtual override {
    688 |         require(_isApprovedOrOwner(_msgSender(), tokenId), "ERC721: transfer caller is not owner nor approved");
    689 |         _safeTransfer(from, to, tokenId, _data);
    690 |     }
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 953 行
- **函数**: `balanceOf()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    950 |     /**
    951 |      * @dev Returns the number of tokens in ``owner``'s account.
    952 |      */
>>  953 |     function balanceOf(address owner) external view returns (uint256 balance);
    954 | 
    955 |     /**
    956 |      * @dev Returns the owner of the `tokenId` token.
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 962 行
- **函数**: `ownerOf()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    959 |      *
    960 |      * - `tokenId` must exist.
    961 |      */
>>  962 |     function ownerOf(uint256 tokenId) external view returns (address owner);
    963 | 
    964 |     /**
    965 |      * @dev Safely transfers `tokenId` token from `from` to `to`, checking first that contract recipients
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1018 行
- **函数**: `getApproved()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1015 |      *
   1016 |      * - `tokenId` must exist.
   1017 |      */
>> 1018 |     function getApproved(uint256 tokenId) external view returns (address operator);
   1019 | 
   1020 |     /**
   1021 |      * @dev Approve or remove `operator` as an operator for the caller.
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1037 行
- **函数**: `isApprovedForAll()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1034 |      *
   1035 |      * See {setApprovalForAll}
   1036 |      */
>> 1037 |     function isApprovedForAll(address owner, address operator) external view returns (bool);
   1038 | 
   1039 |     /**
   1040 |       * @dev Safely transfers `tokenId` token from `from` to `to`.
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1073 行
- **函数**: `totalSupply()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1070 |     /**
   1071 |      * @dev Returns the total amount of tokens stored by the contract.
   1072 |      */
>> 1073 |     function totalSupply() external view returns (uint256);
   1074 | 
   1075 |     /**
   1076 |      * @dev Returns a token ID owned by `owner` at a given `index` of its token list.
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1079 行
- **函数**: `tokenOfOwnerByIndex()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1076 |      * @dev Returns a token ID owned by `owner` at a given `index` of its token list.
   1077 |      * Use along with {balanceOf} to enumerate all of ``owner``'s tokens.
   1078 |      */
>> 1079 |     function tokenOfOwnerByIndex(address owner, uint256 index) external view returns (uint256 tokenId);
   1080 | 
   1081 |     /**
   1082 |      * @dev Returns a token ID at a given `index` of all the tokens stored by the contract.
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1085 行
- **函数**: `tokenByIndex()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1082 |      * @dev Returns a token ID at a given `index` of all the tokens stored by the contract.
   1083 |      * Use along with {totalSupply} to enumerate all tokens.
   1084 |      */
>> 1085 |     function tokenByIndex(uint256 index) external view returns (uint256);
   1086 | }
   1087 | 
   1088 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1106 行
- **函数**: `name()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1103 |     /**
   1104 |      * @dev Returns the token collection name.
   1105 |      */
>> 1106 |     function name() external view returns (string memory);
   1107 | 
   1108 |     /**
   1109 |      * @dev Returns the token collection symbol.
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1111 行
- **函数**: `symbol()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1108 |     /**
   1109 |      * @dev Returns the token collection symbol.
   1110 |      */
>> 1111 |     function symbol() external view returns (string memory);
   1112 | 
   1113 |     /**
   1114 |      * @dev Returns the Uniform Resource Identifier (URI) for `tokenId` token.
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1116 行
- **函数**: `tokenURI()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1113 |     /**
   1114 |      * @dev Returns the Uniform Resource Identifier (URI) for `tokenId` token.
   1115 |      */
>> 1116 |     function tokenURI(uint256 tokenId) external view returns (string memory);
   1117 | }
   1118 | 
   1119 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1141 行
- **函数**: `onERC721Received()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1138 |      *
   1139 |      * The selector can be obtained in Solidity with `IERC721.onERC721Received.selector`.
   1140 |      */
>> 1141 |     function onERC721Received(address operator, address from, uint256 tokenId, bytes calldata data) external returns (bytes4);
   1142 | }
   1143 | 
   1144 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2044 行
- **函数**: `owner()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2041 |     /// @notice Returns the current owner of the factory
   2042 |     /// @dev Can be changed by the current owner via setOwner
   2043 |     /// @return The address of the factory owner
>> 2044 |     function owner() external view returns (address);
   2045 | 
   2046 |     /// @notice Returns the tick spacing for a given fee amount, if enabled, or 0 if not enabled
   2047 |     /// @dev A fee amount can never be removed, so this value should be hard coded or cached in the calling context
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2050 行
- **函数**: `feeAmountTickSpacing()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2047 |     /// @dev A fee amount can never be removed, so this value should be hard coded or cached in the calling context
   2048 |     /// @param fee The enabled fee, denominated in hundredths of a bip. Returns 0 in case of unenabled fee
   2049 |     /// @return The tick spacing
>> 2050 |     function feeAmountTickSpacing(uint24 fee) external view returns (int24);
   2051 | 
   2052 |     /// @notice Returns the tick spacing extra info
   2053 |     /// @dev A fee amount can never be removed, so this value should be hard coded or cached in the calling context
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2056 行
- **函数**: `feeAmountTickSpacingExtraInfo()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2053 |     /// @dev A fee amount can never be removed, so this value should be hard coded or cached in the calling context
   2054 |     /// @param fee The enabled fee, denominated in hundredths of a bip. Returns 0 in case of unenabled fee
   2055 |     /// @return whitelistRequested The flag whether should be created by white list users only
>> 2056 |     function feeAmountTickSpacingExtraInfo(uint24 fee) external view returns (bool whitelistRequested, bool enabled);
   2057 | 
   2058 |     /// @notice Returns the pool address for a given pair of tokens and a fee, or address 0 if it does not exist
   2059 |     /// @dev tokenA and tokenB may be passed in either token0/token1 or token1/token0 order
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2448 行
- **函数**: `factory()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2445 | interface IPancakeV3PoolImmutables {
   2446 |     /// @notice The contract that deployed the pool, which must adhere to the IPancakeV3Factory interface
   2447 |     /// @return The contract address
>> 2448 |     function factory() external view returns (address);
   2449 | 
   2450 |     /// @notice The first of the two tokens of the pool, sorted by address
   2451 |     /// @return The token contract address
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2452 行
- **函数**: `token0()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2449 | 
   2450 |     /// @notice The first of the two tokens of the pool, sorted by address
   2451 |     /// @return The token contract address
>> 2452 |     function token0() external view returns (address);
   2453 | 
   2454 |     /// @notice The second of the two tokens of the pool, sorted by address
   2455 |     /// @return The token contract address
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2456 行
- **函数**: `token1()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2453 | 
   2454 |     /// @notice The second of the two tokens of the pool, sorted by address
   2455 |     /// @return The token contract address
>> 2456 |     function token1() external view returns (address);
   2457 | 
   2458 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   2459 |     /// @return The fee
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2460 行
- **函数**: `fee()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2457 | 
   2458 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   2459 |     /// @return The fee
>> 2460 |     function fee() external view returns (uint24);
   2461 | 
   2462 |     /// @notice The pool tick spacing
   2463 |     /// @dev Ticks can only be used at multiples of this value, minimum of 1 and always positive
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2467 行
- **函数**: `tickSpacing()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2464 |     /// e.g.: a tickSpacing of 3 means ticks can be initialized every 3rd tick, i.e., ..., -6, -3, 0, 3, 6, ...
   2465 |     /// This value is an int24 to avoid casting even though it is always positive.
   2466 |     /// @return The tick spacing
>> 2467 |     function tickSpacing() external view returns (int24);
   2468 | 
   2469 |     /// @notice The maximum amount of position liquidity that can use any tick in the range
   2470 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2473 行
- **函数**: `maxLiquidityPerTick()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2470 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
   2471 |     /// also prevents out-of-range liquidity from being used to prevent adding in-range liquidity to a pool
   2472 |     /// @return The max amount of liquidity per tick
>> 2473 |     function maxLiquidityPerTick() external view returns (uint128);
   2474 | }
   2475 | 
   2476 | 
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2544 行
- **函数**: `feeGrowthGlobal0X128()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2541 | 
   2542 |     /// @notice The fee growth as a Q128.128 fees of token0 collected per unit of liquidity for the entire life of the pool
   2543 |     /// @dev This value can overflow the uint256
>> 2544 |     function feeGrowthGlobal0X128() external view returns (uint256);
   2545 | 
   2546 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   2547 |     /// @dev This value can overflow the uint256
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2548 行
- **函数**: `feeGrowthGlobal1X128()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2545 | 
   2546 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   2547 |     /// @dev This value can overflow the uint256
>> 2548 |     function feeGrowthGlobal1X128() external view returns (uint256);
   2549 | 
   2550 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   2551 |     /// @dev Protocol fees will never exceed uint128 max in either token
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2552 行
- **函数**: `protocolFees()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2549 | 
   2550 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   2551 |     /// @dev Protocol fees will never exceed uint128 max in either token
>> 2552 |     function protocolFees() external view returns (uint128 token0, uint128 token1);
   2553 | 
   2554 |     /// @notice The currently in range liquidity available to the pool
   2555 |     /// @dev This value has no relationship to the total liquidity across all ticks
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2556 行
- **函数**: `liquidity()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2553 | 
   2554 |     /// @notice The currently in range liquidity available to the pool
   2555 |     /// @dev This value has no relationship to the total liquidity across all ticks
>> 2556 |     function liquidity() external view returns (uint128);
   2557 | 
   2558 |     /// @notice Look up information about a specific tick in the pool
   2559 |     /// @param tick The tick to look up
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2587 行
- **函数**: `tickBitmap()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2584 |         );
   2585 | 
   2586 |     /// @notice Returns 256 packed tick initialized boolean values. See TickBitmap for more information
>> 2587 |     function tickBitmap(int16 wordPosition) external view returns (uint256);
   2588 | 
   2589 |     /// @notice Returns the information about a position by the position's key
   2590 |     /// @param key The position's key is a hash of a preimage composed by the owner, tickLower and tickUpper
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3042 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3039 |     }
   3040 | 
   3041 |     /// @inheritdoc IERC721Permit
>> 3042 |     function DOMAIN_SEPARATOR() public view override returns (bytes32) {
   3043 |         return
   3044 |             keccak256(
   3045 |                 abi.encode(
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3202 行
- **函数**: `multicall()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3199 | /// @notice Enables calling multiple methods in a single call to the contract
   3200 | abstract contract Multicall is IMulticall {
   3201 |     /// @inheritdoc IMulticall
>> 3202 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
   3203 |         results = new bytes[](data.length);
   3204 |         for (uint256 i = 0; i < data.length; i++) {
   3205 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3267 行
- **函数**: `unwrapWETH9()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3264 |     }
   3265 | 
   3266 |     /// @inheritdoc IPeripheryPayments
>> 3267 |     function unwrapWETH9(uint256 amountMinimum, address recipient) public payable override {
   3268 |         uint256 balanceWETH9 = IWETH9(WETH9).balanceOf(address(this));
   3269 |         require(balanceWETH9 >= amountMinimum, 'Insufficient WETH9');
   3270 | 
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3292 行
- **函数**: `refundETH()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3289 |     }
   3290 | 
   3291 |     /// @inheritdoc IPeripheryPayments
>> 3292 |     function refundETH() external payable override {
   3293 |         if (address(this).balance > 0) TransferHelper.safeTransferETH(msg.sender, address(this).balance);
   3294 |     }
   3295 | 
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3455 行
- **函数**: `isValidSignature()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3452 |     /// @param hash Hash of the data to be signed
   3453 |     /// @param signature Signature byte array associated with _data
   3454 |     /// @return magicValue The bytes4 magic value 0x1626ba7e
>> 3455 |     function isValidSignature(bytes32 hash, bytes memory signature) external view returns (bytes4 magicValue);
   3456 | }
   3457 | 
   3458 | 
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3500 行
- **函数**: `deposit()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3497 | /// @title Interface for WETH9
   3498 | interface IWETH9 is IERC20 {
   3499 |     /// @notice Deposit ether to get wrapped ether
>> 3500 |     function deposit() external payable;
   3501 | 
   3502 |     /// @notice Withdraw wrapped ether to get ether
   3503 |     function withdraw(uint256) external;
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3519 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3516 | interface IERC721Permit is IERC721 {
   3517 |     /// @notice The permit typehash used in the permit signature
   3518 |     /// @return The typehash for the permit
>> 3519 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   3520 | 
   3521 |     /// @notice The domain separator used in the permit signature
   3522 |     /// @return The domain seperator used in encoding of permit signature
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3523 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3520 | 
   3521 |     /// @notice The domain separator used in the permit signature
   3522 |     /// @return The domain seperator used in encoding of permit signature
>> 3523 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   3524 | 
   3525 |     /// @notice Approve of a specific token ID for spending by spender via signature
   3526 |     /// @param spender The account that is being approved
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3556 行
- **函数**: `multicall()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3553 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   3554 |     /// @param data The encoded function data for each of the calls to make to this contract
   3555 |     /// @return results The results from each of the calls passed in via data
>> 3556 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results);
   3557 | }
   3558 | 
   3559 | 
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3735 行
- **函数**: `collect()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3732 |     /// amount1Max The maximum amount of token1 to collect
   3733 |     /// @return amount0 The amount of fees collected in token0
   3734 |     /// @return amount1 The amount of fees collected in token1
>> 3735 |     function collect(CollectParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
   3736 | 
   3737 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   3738 |     /// must be collected first.
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3740 行
- **函数**: `burn()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3737 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   3738 |     /// must be collected first.
   3739 |     /// @param tokenId The ID of the token that is being burned
>> 3740 |     function burn(uint256 tokenId) external payable;
   3741 | }
   3742 | 
   3743 | 
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3774 行
- **函数**: `deployer()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3771 | /// @notice Functions that return immutable state of the router
   3772 | interface IPeripheryImmutableState {
   3773 |     /// @return Returns the address of the PancakeSwap V3 deployer
>> 3774 |     function deployer() external view returns (address);
   3775 | 
   3776 |     /// @return Returns the address of the PancakeSwap V3 factory
   3777 |     function factory() external view returns (address);
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3777 行
- **函数**: `factory()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3774 |     function deployer() external view returns (address);
   3775 | 
   3776 |     /// @return Returns the address of the PancakeSwap V3 factory
>> 3777 |     function factory() external view returns (address);
   3778 | 
   3779 |     /// @return Returns the address of WETH9
   3780 |     function WETH9() external view returns (address);
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3780 行
- **函数**: `WETH9()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3777 |     function factory() external view returns (address);
   3778 | 
   3779 |     /// @return Returns the address of WETH9
>> 3780 |     function WETH9() external view returns (address);
   3781 | }
   3782 | 
   3783 | 
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3796 行
- **函数**: `unwrapWETH9()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3793 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   3794 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
   3795 |     /// @param recipient The address receiving ETH
>> 3796 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external payable;
   3797 | 
   3798 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   3799 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3802 行
- **函数**: `refundETH()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3799 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
   3800 |     /// that use ether for the input amount. And in PancakeSwap Router, this would be called 
   3801 |     /// at the very end of swap
>> 3802 |     function refundETH() external payable;
   3803 | 
   3804 |     /// @notice Transfers the full amount of a token held by this contract to recipient
   3805 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4445 行
- **函数**: `tokenURI()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4442 |         _;
   4443 |     }
   4444 | 
>> 4445 |     function tokenURI(uint256 tokenId) public view override(ERC721, IERC721Metadata) returns (string memory) {
   4446 |         require(_exists(tokenId));
   4447 |         return INonfungibleTokenPositionDescriptor(_tokenDescriptor).tokenURI(this, tokenId);
   4448 |     }
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4451 行
- **函数**: `baseURI()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4448 |     }
   4449 | 
   4450 |     // save bytecode by removing implementation of unused method
>> 4451 |     function baseURI() public pure override returns (string memory) {}
   4452 | 
   4453 |     /// @inheritdoc INonfungiblePositionManager
   4454 |     function increaseLiquidity(IncreaseLiquidityParams calldata params)
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4633 行
- **函数**: `burn()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4630 |     }
   4631 | 
   4632 |     /// @inheritdoc INonfungiblePositionManager
>> 4633 |     function burn(uint256 tokenId) external payable override isAuthorizedForToken(tokenId) {
   4634 |         Position storage position = _positions[tokenId];
   4635 |         require(position.liquidity == 0 && position.tokensOwed0 == 0 && position.tokensOwed1 == 0, 'Not cleared');
   4636 |         delete _positions[tokenId];
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4645 行
- **函数**: `getApproved()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4642 |     }
   4643 | 
   4644 |     /// @inheritdoc IERC721
>> 4645 |     function getApproved(uint256 tokenId) public view override(ERC721, IERC721) returns (address) {
   4646 |         require(_exists(tokenId), 'ERC721: approved query for nonexistent token');
   4647 | 
   4648 |         return _positions[tokenId].operator;
```

---

### 78. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 463 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    458 | 
    459 | /**
    460 |  * @title ERC721 Non-Fungible Token Standard basic implementation
    461 |  * @dev see https://eips.ethereum.org/EIPS/eip-721
    462 |  */
>>  463 | contract ERC721 is Context, ERC165, IERC721, IERC721Metadata, IERC721Enumerable {
    464 |     using SafeMath for uint256;
    465 |     using Address for address;
    466 |     using EnumerableSet for EnumerableSet.UintSet;
    467 |     using EnumerableMap for EnumerableMap.UintToAddressMap;
    468 |     using Strings for uint256;
```

---

### 79. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1352 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1347 |  * via msg.sender and msg.data, they should not be accessed in such a direct
   1348 |  * manner, since when dealing with GSN meta-transactions the account sending and
   1349 |  * paying for execution may not be the actual sender (as far as an application
   1350 |  * is concerned).
   1351 |  *
>> 1352 |  * This contract is only required for intermediate, library-like contracts.
   1353 |  */
   1354 | abstract contract Context {
   1355 |     function _msgSender() internal view virtual returns (address payable) {
   1356 |         return msg.sender;
   1357 |     }
```

---

### 80. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1981 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1976 | 
   1977 | // SPDX-License-Identifier: GPL-2.0-or-later
   1978 | pragma solidity >=0.5.0;
   1979 | 
   1980 | /// @title Callback for IPancakeV3PoolActions#mint
>> 1981 | /// @notice Any contract that calls IPancakeV3PoolActions#mint must implement this interface
   1982 | interface IPancakeV3MintCallback {
   1983 |     /// @notice Called to `msg.sender` after minting liquidity to a position from IPancakeV3Pool#mint.
   1984 |     /// @dev In the implementation you must pay the pool tokens owed for the minted liquidity.
   1985 |     /// The caller of this method must be checked to be a PancakeV3Pool deployed by the canonical PancakeV3Factory.
   1986 |     /// @param amount0Owed The amount of token0 due to the pool for the minted liquidity
```

---

### 81. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2446 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2441 | pragma solidity >=0.5.0;
   2442 | 
   2443 | /// @title Pool state that never changes
   2444 | /// @notice These parameters are fixed for a pool forever, i.e., the methods will always return the same values
   2445 | interface IPancakeV3PoolImmutables {
>> 2446 |     /// @notice The contract that deployed the pool, which must adhere to the IPancakeV3Factory interface
   2447 |     /// @return The contract address
   2448 |     function factory() external view returns (address);
   2449 | 
   2450 |     /// @notice The first of the two tokens of the pool, sorted by address
   2451 |     /// @return The token contract address
```

---

### 82. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3021 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3016 | import '../interfaces/IERC721Permit.sol';
   3017 | import './BlockTimestamp.sol';
   3018 | 
   3019 | /// @title ERC721 with permit
   3020 | /// @notice Nonfungible tokens that support an approve via signature, i.e. permit
>> 3021 | abstract contract ERC721Permit is BlockTimestamp, ERC721, IERC721Permit {
   3022 |     /// @dev Gets the current nonce for a token ID and then increments it, returning the original value
   3023 |     function _getAndIncrementNonce(uint256 tokenId) internal virtual returns (uint256);
   3024 | 
   3025 |     /// @dev The hash of the name used in the permit signature verification
   3026 |     bytes32 private immutable nameHash;
```

---

### 83. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3115 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3110 | import './PeripheryPayments.sol';
   3111 | import './PeripheryImmutableState.sol';
   3112 | 
   3113 | /// @title Liquidity management functions
   3114 | /// @notice Internal functions for safely managing liquidity in PancakeSwap V3
>> 3115 | abstract contract LiquidityManagement is IPancakeV3MintCallback, PeripheryImmutableState, PeripheryPayments {
   3116 |     struct MintCallbackData {
   3117 |         PoolAddress.PoolKey poolKey;
   3118 |         address payer;
   3119 |     }
   3120 | 
```

---

### 84. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3199 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3194 | pragma abicoder v2;
   3195 | 
   3196 | import '../interfaces/IMulticall.sol';
   3197 | 
   3198 | /// @title Multicall
>> 3199 | /// @notice Enables calling multiple methods in a single call to the contract
   3200 | abstract contract Multicall is IMulticall {
   3201 |     /// @inheritdoc IMulticall
   3202 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
   3203 |         results = new bytes[](data.length);
   3204 |         for (uint256 i = 0; i < data.length; i++) {
```

---

### 85. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3231 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3226 | 
   3227 | import '../interfaces/IPeripheryImmutableState.sol';
   3228 | 
   3229 | /// @title Immutable state
   3230 | /// @notice Immutable state used by periphery contracts
>> 3231 | abstract contract PeripheryImmutableState is IPeripheryImmutableState {
   3232 |     /// @inheritdoc IPeripheryImmutableState
   3233 |     address public immutable override deployer;
   3234 |     /// @inheritdoc IPeripheryImmutableState
   3235 |     address public immutable override factory;
   3236 |     /// @inheritdoc IPeripheryImmutableState
```

---

### 86. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3348 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3343 | 
   3344 | import './PeripheryImmutableState.sol';
   3345 | import '../interfaces/IPoolInitializer.sol';
   3346 | 
   3347 | /// @title Creates and initializes V3 Pools
>> 3348 | abstract contract PoolInitializer is IPoolInitializer, PeripheryImmutableState {
   3349 |     /// @inheritdoc IPoolInitializer
   3350 |     function createAndInitializePoolIfNecessary(
   3351 |         address token0,
   3352 |         address token1,
   3353 |         uint24 fee,
```

---

### 87. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3385 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3380 | import '../interfaces/ISelfPermit.sol';
   3381 | import '../interfaces/external/IERC20PermitAllowed.sol';
   3382 | 
   3383 | /// @title Self Permit
   3384 | /// @notice Functionality to call permit on any EIP-2612-compliant token for use in the route
>> 3385 | /// @dev These functions are expected to be embedded in multicalls to allow EOAs to approve a contract and call a function
   3386 | /// that requires an approval in a single transaction.
   3387 | abstract contract SelfPermit is ISelfPermit {
   3388 |     /// @inheritdoc ISelfPermit
   3389 |     function selfPermit(
   3390 |         address token,
```

---

### 88. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3552 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3547 | pragma abicoder v2;
   3548 | 
   3549 | /// @title Multicall interface
   3550 | /// @notice Enables calling multiple methods in a single call to the contract
   3551 | interface IMulticall {
>> 3552 |     /// @notice Call multiple functions in the current contract and return the data from all of them if they all succeed
   3553 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   3554 |     /// @param data The encoded function data for each of the calls to make to this contract
   3555 |     /// @return results The results from each of the calls passed in via data
   3556 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results);
   3557 | }
```

---

### 89. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3798 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3793 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   3794 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
   3795 |     /// @param recipient The address receiving ETH
   3796 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external payable;
   3797 | 
>> 3798 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   3799 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
   3800 |     /// that use ether for the input amount. And in PancakeSwap Router, this would be called 
   3801 |     /// at the very end of swap
   3802 |     function refundETH() external payable;
   3803 | 
```

---

### 90. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3851 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3846 | pragma solidity >=0.7.5;
   3847 | 
   3848 | /// @title Self Permit
   3849 | /// @notice Functionality to call permit on any EIP-2612-compliant token for use in the route
   3850 | interface ISelfPermit {
>> 3851 |     /// @notice Permits this contract to spend a given token from `msg.sender`
   3852 |     /// @dev The `owner` is always msg.sender and the `spender` is always address(this).
   3853 |     /// @param token The address of the token spent
   3854 |     /// @param value The amount that can be spent of token
   3855 |     /// @param deadline A timestamp, the current blocktime must be less than or equal to this timestamp
   3856 |     /// @param v Must produce valid secp256k1 signature from the holder along with `r` and `s`
```

---

### 91. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4200 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4195 | import '@openzeppelin/contracts/token/ERC20/IERC20.sol';
   4196 | 
   4197 | library TransferHelper {
   4198 |     /// @notice Transfers tokens from the targeted address to the given destination
   4199 |     /// @notice Errors with 'STF' if transfer fails
>> 4200 |     /// @param token The contract address of the token to be transferred
   4201 |     /// @param from The originating address from which the tokens will be transferred
   4202 |     /// @param to The destination address of the transfer
   4203 |     /// @param value The amount to be transferred
   4204 |     function safeTransferFrom(
   4205 |         address token,
```

---

### 92. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4217 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4212 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'STF');
   4213 |     }
   4214 | 
   4215 |     /// @notice Transfers tokens from msg.sender to a recipient
   4216 |     /// @dev Errors with ST if transfer fails
>> 4217 |     /// @param token The contract address of the token which will be transferred
   4218 |     /// @param to The recipient of the transfer
   4219 |     /// @param value The value of the transfer
   4220 |     function safeTransfer(
   4221 |         address token,
   4222 |         address to,
```

---

### 93. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4229 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4224 |     ) internal {
   4225 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transfer.selector, to, value));
   4226 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'ST');
   4227 |     }
   4228 | 
>> 4229 |     /// @notice Approves the stipulated contract to spend the given allowance in the given token
   4230 |     /// @dev Errors with 'SA' if transfer fails
   4231 |     /// @param token The contract address of the token to be approved
   4232 |     /// @param to The target of the approval
   4233 |     /// @param value The amount of the given token the target will be allowed to spend
   4234 |     function safeApprove(
```

---

### 94. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4278 行
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4273 | import './base/SelfPermit.sol';
   4274 | import './base/PoolInitializer.sol';
   4275 | 
   4276 | /// @title NFT positions
   4277 | /// @notice Wraps Pancake V3 positions in the ERC721 non-fungible token interface
>> 4278 | contract NonfungiblePositionManager is
   4279 |     INonfungiblePositionManager,
   4280 |     Multicall,
   4281 |     ERC721Permit,
   4282 |     PeripheryImmutableState,
   4283 |     PoolInitializer,
```

---

### 95. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 60 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
     57 | 
     58 | // SPDX-License-Identifier: MIT
     59 | 
>>   60 | pragma solidity ^0.7.0;
     61 | 
     62 | import "./IERC165.sol";
     63 | 
```

---

### 96. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 118 行
- **函数**: `_registerInterface()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    115 | 
    116 | // SPDX-License-Identifier: MIT
    117 | 
>>  118 | pragma solidity ^0.7.0;
    119 | 
    120 | /**
    121 |  * @dev Interface of the ERC165 standard, as defined in the
```

---

### 97. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 146 行
- **函数**: `supportsInterface()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    143 | 
    144 | // SPDX-License-Identifier: MIT
    145 | 
>>  146 | pragma solidity ^0.7.0;
    147 | 
    148 | /**
    149 |  * @dev Wrappers over Solidity's arithmetic operations with added overflow
```

---

### 98. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 364 行
- **函数**: `mod()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    361 | 
    362 | // SPDX-License-Identifier: MIT
    363 | 
>>  364 | pragma solidity ^0.7.0;
    365 | 
    366 | /**
    367 |  * @dev Interface of the ERC20 standard as defined in the EIP.
```

---

### 99. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 445 行
- **函数**: `transferFrom()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    442 | 
    443 | // SPDX-License-Identifier: MIT
    444 | 
>>  445 | pragma solidity ^0.7.0;
    446 | 
    447 | import "../../utils/Context.sol";
    448 | import "./IERC721.sol";
```

---

### 100. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 927 行
- **函数**: `_beforeTokenTransfer()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    924 | 
    925 | // SPDX-License-Identifier: MIT
    926 | 
>>  927 | pragma solidity ^0.7.0;
    928 | 
    929 | import "../../introspection/IERC165.sol";
    930 | 
```

---

### 101. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1060 行
- **函数**: `safeTransferFrom()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   1057 | 
   1058 | // SPDX-License-Identifier: MIT
   1059 | 
>> 1060 | pragma solidity ^0.7.0;
   1061 | 
   1062 | import "./IERC721.sol";
   1063 | 
```

---

### 102. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1093 行
- **函数**: `tokenByIndex()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   1090 | 
   1091 | // SPDX-License-Identifier: MIT
   1092 | 
>> 1093 | pragma solidity ^0.7.0;
   1094 | 
   1095 | import "./IERC721.sol";
   1096 | 
```

---

### 103. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1124 行
- **函数**: `tokenURI()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   1121 | 
   1122 | // SPDX-License-Identifier: MIT
   1123 | 
>> 1124 | pragma solidity ^0.7.0;
   1125 | 
   1126 | /**
   1127 |  * @title ERC721 token receiver interface
```

---

### 104. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1149 行
- **函数**: `onERC721Received()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   1146 | 
   1147 | // SPDX-License-Identifier: MIT
   1148 | 
>> 1149 | pragma solidity ^0.7.0;
   1150 | 
   1151 | /**
   1152 |  * @dev Collection of functions related to the address type
```

---

### 105. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1370 行
- **函数**: `_msgData()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   1367 | 
   1368 | // SPDX-License-Identifier: MIT
   1369 | 
>> 1370 | pragma solidity ^0.7.0;
   1371 | 
   1372 | /**
   1373 |  * @dev Library for managing an enumerable variant of Solidity's
```

---

### 106. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1640 行
- **函数**: `get()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   1637 | 
   1638 | // SPDX-License-Identifier: MIT
   1639 | 
>> 1640 | pragma solidity ^0.7.0;
   1641 | 
   1642 | /**
   1643 |  * @dev Library for managing
```

---

### 107. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1941 行
- **函数**: `at()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
   1938 | 
   1939 | // SPDX-License-Identifier: MIT
   1940 | 
>> 1941 | pragma solidity ^0.7.0;
   1942 | 
   1943 | /**
   1944 |  * @dev String operations.
```

---

### 108. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3001 行
- **函数**: `_blockTimestamp()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2998 |     /// @dev Method that exists purely to be overridden for tests
   2999 |     /// @return The current block timestamp
   3000 |     function _blockTimestamp() internal view virtual returns (uint256) {
>> 3001 |         return block.timestamp;
   3002 |     }
   3003 | }
   3004 | 
```

---

### 109. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3309 行
- **函数**: `pay()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   3306 |         if (token == WETH9 && address(this).balance >= value) {
   3307 |             // pay with WETH9
   3308 |             IWETH9(WETH9).deposit{value: value}(); // wrap only what is needed to pay
>> 3309 |             IWETH9(WETH9).transfer(recipient, value);
   3310 |         } else if (payer == address(this)) {
   3311 |             // pay with tokens already in the contract (for the exact input multihop case)
   3312 |             TransferHelper.safeTransfer(token, recipient, value);
```

---

### 110. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3047 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3044 |             keccak256(
   3045 |                 abi.encode(
   3046 |                     // keccak256('EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)')
>> 3047 |                     0x8b73c3c69bb8fe3d512ecc4cf759cc79239f7b179b0ffacaa9a75d522b39400f,
   3048 |                     nameHash,
   3049 |                     versionHash,
   3050 |                     ChainId.get(),
```

---

### 111. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3059 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3056 |     /// @inheritdoc IERC721Permit
   3057 |     /// @dev Value is equal to keccak256("Permit(address spender,uint256 tokenId,uint256 nonce,uint256 deadline)");
   3058 |     bytes32 public constant override PERMIT_TYPEHASH =
>> 3059 |         0x49ecf333e5b8c95c40fdafc95c1ad136e8914a8fb55e9dc8bb01eaa83a2df9ad;
   3060 | 
   3061 |     /// @inheritdoc IERC721Permit
   3062 |     function permit(
```

---

### 112. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 4128 行
- **函数**: `getAmountsForLiquidity()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4125 | 
   4126 | /// @title Provides functions for deriving a pool address from the factory, tokens, and the fee
   4127 | library PoolAddress {
>> 4128 |     bytes32 internal constant POOL_INIT_CODE_HASH = 0x6ce8eb472fa82df5469c6ab6d485f17c3ad13c8cd7af59b3d4a8026c5ce0f7e2;
   4129 | 
   4130 |     /// @notice The identifying key of the pool
   4131 |     struct PoolKey {
```

---

### 113. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1179 行
- **函数**: `isContract()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1176 | 
   1177 |         uint256 size;
   1178 |         // solhint-disable-next-line no-inline-assembly
>> 1179 |         assembly { size := extcodesize(account) }
   1180 |         return size > 0;
   1181 |     }
   1182 | 
```

---

### 114. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 1326 行
- **函数**: `_verifyCallResult()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1323 |                 // The easiest way to bubble the revert reason is using memory via assembly
   1324 | 
   1325 |                 // solhint-disable-next-line no-inline-assembly
>> 1326 |                 assembly {
   1327 |                     let returndata_size := mload(returndata)
   1328 |                     revert(add(32, returndata), returndata_size)
   1329 |                 }
```

---

### 115. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2680 行
- **函数**: `mulDiv()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2677 |         // variables such that product = prod1 * 2**256 + prod0
   2678 |         uint256 prod0; // Least significant 256 bits of the product
   2679 |         uint256 prod1; // Most significant 256 bits of the product
>> 2680 |         assembly {
   2681 |             let mm := mulmod(a, b, not(0))
   2682 |             prod0 := mul(a, b)
   2683 |             prod1 := sub(sub(mm, prod0), lt(mm, prod0))
```

---

### 116. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2689 行
- **函数**: `mulDiv()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2686 |         // Handle non-overflow cases, 256 by 256 division
   2687 |         if (prod1 == 0) {
   2688 |             require(denominator > 0);
>> 2689 |             assembly {
   2690 |                 result := div(prod0, denominator)
   2691 |             }
   2692 |             return result;
```

---

### 117. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2706 行
- **函数**: `mulDiv()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2703 |         // Make division exact by subtracting the remainder from [prod1 prod0]
   2704 |         // Compute remainder using mulmod
   2705 |         uint256 remainder;
>> 2706 |         assembly {
   2707 |             remainder := mulmod(a, b, denominator)
   2708 |         }
   2709 |         // Subtract 256 bit number from 512 bit number
```

---

### 118. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2710 行
- **函数**: `mulDiv()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2707 |             remainder := mulmod(a, b, denominator)
   2708 |         }
   2709 |         // Subtract 256 bit number from 512 bit number
>> 2710 |         assembly {
   2711 |             prod1 := sub(prod1, gt(remainder, prod0))
   2712 |             prod0 := sub(prod0, remainder)
   2713 |         }
```

---

### 119. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2720 行
- **函数**: `mulDiv()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2717 |         // Always >= 1.
   2718 |         uint256 twos = -denominator & denominator;
   2719 |         // Divide denominator by power of two
>> 2720 |         assembly {
   2721 |             denominator := div(denominator, twos)
   2722 |         }
   2723 | 
```

---

### 120. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2725 行
- **函数**: `mulDiv()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2722 |         }
   2723 | 
   2724 |         // Divide [prod1 prod0] by the factors of two
>> 2725 |         assembly {
   2726 |             prod0 := div(prod0, twos)
   2727 |         }
   2728 |         // Shift in bits from prod1 into prod0. For this we need
```

---

### 121. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2731 行
- **函数**: `mulDiv()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2728 |         // Shift in bits from prod1 into prod0. For this we need
   2729 |         // to flip `twos` such that it is 2**256 / twos.
   2730 |         // If twos is zero, then it becomes one
>> 2731 |         assembly {
   2732 |             twos := add(div(sub(0, twos), twos), 1)
   2733 |         }
   2734 |         prod0 |= prod1 * twos;
```

---

### 122. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2851 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2848 |         uint256 r = ratio;
   2849 |         uint256 msb = 0;
   2850 | 
>> 2851 |         assembly {
   2852 |             let f := shl(7, gt(r, 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF))
   2853 |             msb := or(msb, f)
   2854 |             r := shr(f, r)
```

---

### 123. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2856 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2853 |             msb := or(msb, f)
   2854 |             r := shr(f, r)
   2855 |         }
>> 2856 |         assembly {
   2857 |             let f := shl(6, gt(r, 0xFFFFFFFFFFFFFFFF))
   2858 |             msb := or(msb, f)
   2859 |             r := shr(f, r)
```

---

### 124. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2861 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2858 |             msb := or(msb, f)
   2859 |             r := shr(f, r)
   2860 |         }
>> 2861 |         assembly {
   2862 |             let f := shl(5, gt(r, 0xFFFFFFFF))
   2863 |             msb := or(msb, f)
   2864 |             r := shr(f, r)
```

---

### 125. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2866 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2863 |             msb := or(msb, f)
   2864 |             r := shr(f, r)
   2865 |         }
>> 2866 |         assembly {
   2867 |             let f := shl(4, gt(r, 0xFFFF))
   2868 |             msb := or(msb, f)
   2869 |             r := shr(f, r)
```

---

### 126. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2871 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2868 |             msb := or(msb, f)
   2869 |             r := shr(f, r)
   2870 |         }
>> 2871 |         assembly {
   2872 |             let f := shl(3, gt(r, 0xFF))
   2873 |             msb := or(msb, f)
   2874 |             r := shr(f, r)
```

---

### 127. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2876 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2873 |             msb := or(msb, f)
   2874 |             r := shr(f, r)
   2875 |         }
>> 2876 |         assembly {
   2877 |             let f := shl(2, gt(r, 0xF))
   2878 |             msb := or(msb, f)
   2879 |             r := shr(f, r)
```

---

### 128. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2881 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2878 |             msb := or(msb, f)
   2879 |             r := shr(f, r)
   2880 |         }
>> 2881 |         assembly {
   2882 |             let f := shl(1, gt(r, 0x3))
   2883 |             msb := or(msb, f)
   2884 |             r := shr(f, r)
```

---

### 129. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2886 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2883 |             msb := or(msb, f)
   2884 |             r := shr(f, r)
   2885 |         }
>> 2886 |         assembly {
   2887 |             let f := gt(r, 0x1)
   2888 |             msb := or(msb, f)
   2889 |         }
```

---

### 130. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2896 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2893 | 
   2894 |         int256 log_2 = (int256(msb) - 128) << 64;
   2895 | 
>> 2896 |         assembly {
   2897 |             r := shr(127, mul(r, r))
   2898 |             let f := shr(128, r)
   2899 |             log_2 := or(log_2, shl(63, f))
```

---

### 131. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2902 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2899 |             log_2 := or(log_2, shl(63, f))
   2900 |             r := shr(f, r)
   2901 |         }
>> 2902 |         assembly {
   2903 |             r := shr(127, mul(r, r))
   2904 |             let f := shr(128, r)
   2905 |             log_2 := or(log_2, shl(62, f))
```

---

### 132. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2908 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2905 |             log_2 := or(log_2, shl(62, f))
   2906 |             r := shr(f, r)
   2907 |         }
>> 2908 |         assembly {
   2909 |             r := shr(127, mul(r, r))
   2910 |             let f := shr(128, r)
   2911 |             log_2 := or(log_2, shl(61, f))
```

---

### 133. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2914 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2911 |             log_2 := or(log_2, shl(61, f))
   2912 |             r := shr(f, r)
   2913 |         }
>> 2914 |         assembly {
   2915 |             r := shr(127, mul(r, r))
   2916 |             let f := shr(128, r)
   2917 |             log_2 := or(log_2, shl(60, f))
```

---

### 134. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2920 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2917 |             log_2 := or(log_2, shl(60, f))
   2918 |             r := shr(f, r)
   2919 |         }
>> 2920 |         assembly {
   2921 |             r := shr(127, mul(r, r))
   2922 |             let f := shr(128, r)
   2923 |             log_2 := or(log_2, shl(59, f))
```

---

### 135. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2926 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2923 |             log_2 := or(log_2, shl(59, f))
   2924 |             r := shr(f, r)
   2925 |         }
>> 2926 |         assembly {
   2927 |             r := shr(127, mul(r, r))
   2928 |             let f := shr(128, r)
   2929 |             log_2 := or(log_2, shl(58, f))
```

---

### 136. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2932 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2929 |             log_2 := or(log_2, shl(58, f))
   2930 |             r := shr(f, r)
   2931 |         }
>> 2932 |         assembly {
   2933 |             r := shr(127, mul(r, r))
   2934 |             let f := shr(128, r)
   2935 |             log_2 := or(log_2, shl(57, f))
```

---

### 137. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2938 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2935 |             log_2 := or(log_2, shl(57, f))
   2936 |             r := shr(f, r)
   2937 |         }
>> 2938 |         assembly {
   2939 |             r := shr(127, mul(r, r))
   2940 |             let f := shr(128, r)
   2941 |             log_2 := or(log_2, shl(56, f))
```

---

### 138. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2944 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2941 |             log_2 := or(log_2, shl(56, f))
   2942 |             r := shr(f, r)
   2943 |         }
>> 2944 |         assembly {
   2945 |             r := shr(127, mul(r, r))
   2946 |             let f := shr(128, r)
   2947 |             log_2 := or(log_2, shl(55, f))
```

---

### 139. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2950 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2947 |             log_2 := or(log_2, shl(55, f))
   2948 |             r := shr(f, r)
   2949 |         }
>> 2950 |         assembly {
   2951 |             r := shr(127, mul(r, r))
   2952 |             let f := shr(128, r)
   2953 |             log_2 := or(log_2, shl(54, f))
```

---

### 140. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2956 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2953 |             log_2 := or(log_2, shl(54, f))
   2954 |             r := shr(f, r)
   2955 |         }
>> 2956 |         assembly {
   2957 |             r := shr(127, mul(r, r))
   2958 |             let f := shr(128, r)
   2959 |             log_2 := or(log_2, shl(53, f))
```

---

### 141. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2962 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2959 |             log_2 := or(log_2, shl(53, f))
   2960 |             r := shr(f, r)
   2961 |         }
>> 2962 |         assembly {
   2963 |             r := shr(127, mul(r, r))
   2964 |             let f := shr(128, r)
   2965 |             log_2 := or(log_2, shl(52, f))
```

---

### 142. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2968 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2965 |             log_2 := or(log_2, shl(52, f))
   2966 |             r := shr(f, r)
   2967 |         }
>> 2968 |         assembly {
   2969 |             r := shr(127, mul(r, r))
   2970 |             let f := shr(128, r)
   2971 |             log_2 := or(log_2, shl(51, f))
```

---

### 143. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 2974 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2971 |             log_2 := or(log_2, shl(51, f))
   2972 |             r := shr(f, r)
   2973 |         }
>> 2974 |         assembly {
   2975 |             r := shr(127, mul(r, r))
   2976 |             let f := shr(128, r)
   2977 |             log_2 := or(log_2, shl(50, f))
```

---

### 144. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3210 行
- **函数**: `multicall()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3207 |             if (!success) {
   3208 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
   3209 |                 if (result.length < 68) revert();
>> 3210 |                 assembly {
   3211 |                     result := add(result, 0x04)
   3212 |                 }
   3213 |                 revert(abi.decode(result, (string)));
```

---

### 145. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x46A15B0b27311cedF172AB29E4f4766fbE7F4364` 第 3973 行
- **函数**: `get()`
- **合约**: `ERC165`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3970 |     /// @dev Gets the current chain ID
   3971 |     /// @return chainId The current chain ID
   3972 |     function get() internal pure returns (uint256 chainId) {
>> 3973 |         assembly {
   3974 |             chainId := chainid()
   3975 |         }
   3976 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*