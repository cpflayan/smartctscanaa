# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:10:54
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x17907521Ac2E8637614CefB5f568A214e10e001A` |
| contract_name | `TOPSToken` |
| compiler_version | `v0.8.26+commit.8a97fa7a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655008` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 90 |
| 🟢 LOW | 29 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] arbitrary-send-erc20

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 1310 行
- **函数**: `transferFromERC20()`
- **扫描工具**: slither
- **综合评分**: 0.725

**工具描述**: TOPSToken.transferFromERC20(address,address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1310-1312) uses arbitrary from in transferFrom: IERC20(_token).transferFrom(account,_to,amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1311)

**代码片段**:
```solidity
   1307 |     function transferERC20(address _token, address account, uint amount) public  onlyOwner{
   1308 |         IERC20(_token).transfer(account,amount);
   1309 |     }
>> 1310 |     function transferFromERC20(address _token, address account,address _to ,uint amount) public  onlyOwner{
   1311 |         IERC20(_token).transferFrom(account,_to,amount);
   1312 |     }
   1313 | 
```

---

### 2. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 825 行
- **函数**: `doAddLP()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in TOPSToken.doAddLP() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#825-860):
	External calls:
	- addTeamAmount(_user,_amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#844)
		- INFT(nftToken).safeTransferFrom(nftfromAddr,sendShare,0,1,) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#881)
	- IWBNB(tokenWBNB).deposit{value: _amount}() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#846)
	- lpadd(_addLpwbnb,_user) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#849)
		- IERC20(tokenWBNB).approve(address(uniswapV2Router),tokenBAmount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1071)
		- uniswapV2Router.addLiquidity(address(this),address(tokenWBNB),tokenAmount,tokenBAmount,0,0,address(_user),block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1073-1082)
		- IERC20(tokenWBNB).approve(address(uniswapV2Router),tokenAmount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1089)
		- _autoSwap.withdraw(address(this)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#865)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1091-1097)
	- setShareReward(_user,_amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#852)
		- IERC20(tokenWBNB).transfer(sendShare,_amount.mul(shareFees[i]).div(1000)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#899)
		- INFTRight(nftRightsAddress).addCake(_amount.mul(_noshareCount).div(1000)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#907)
		- IERC20(tokenWBNB).transfer(nftRightsAddress,_amount.mul(_noshareCount).div(1000)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#908)
	- INFTRight(nftRightsAddress).addCake(_nftreward) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#855)
	- IERC20(tokenWBNB).transfer(nftRightsAddress,_nftreward) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#856)
	- ITokenDividendTracker(dividendLPTOPSTracker).setBalance(address(_user),IERC20(uniswapV2Pair).balanceOf(_user)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#858)
	External calls sending eth:
	- IWBNB(tokenWBNB).deposit{value: _amount}() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#846)
	State variables written after the call(s):
	- addlpswapping = false (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#859)
	TOPSToken.addlpswapping (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#777) can be used in cross function reentrancies:
	- TOPSToken.doAddLP() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#825-860)

**代码片段**:
```solidity
    822 |     }
    823 |     event eaddshare(address indexed _user,address indexed _share,uint _amount);
    824 |     event eaddteam(address indexed _user,address indexed _leader ,address indexed _douser,uint _amount);
>>  825 |     function doAddLP() public payable  {
    826 |         address _user = msg.sender;
    827 |         uint _amount = msg.value;
    828 |         if(!isOpen){
```

---

### 3. 🟡 [MEDIUM] locked-ether

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 1318 行
- **合约**: `TransitSwap`
- **扫描工具**: slither
- **综合评分**: 0.560

**工具描述**: Contract locking ether found:
	Contract TransitSwap (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1318-1335) has payable functions:
	 - TransitSwap.receive() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1324)
	 - TransitSwap.withdraw(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1326-1332)
	But does not have a function to withdraw the ether

**代码片段**:
```solidity
   1315 | 
   1316 | 
   1317 | 
>> 1318 | contract TransitSwap {
   1319 |     using SafeMath for uint256;
   1320 |     address owner;
   1321 |     constructor(address _owner) {
```

---

### 4. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 922 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023):
	External calls:
	- ITokenDividendTracker(dividendLPTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#937)
	- ITokenDividendTracker(dividendNFTTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#938)
	- ITokenDividendTracker(dividendNFTWBNBTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#939)
	- autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#957)
		- ITokenDividendTracker(dividendLPTOPSTracker).distributeCAKEDividends(_toLP) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1143)
		- ITokenDividendTracker(dividendNFTTOPSTracker).distributeCAKEDividends(_toNFT) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1150)
		- pair.sync() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1157)
	- swapTokensForTokenB(nftRightTotal,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#961)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	- _autoSwap.withdraw(address(tokenWBNB)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#963)
	- INFTRight(nftRightsAddress).addCake(_newwbnbbalance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#965)
	- IERC20(tokenWBNB).transfer(nftRightsAddress,_newwbnbbalance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#966)
	- swapTokensForTokenB(marketTotal,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#970)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	- _autoSwap.withdraw(address(tokenWBNB)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#972)
	- IERC20(tokenWBNB).transfer(marketAddress,_newwbnbbalance_scope_1) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#974)
	- swapTokensForTokenB(dumpAmount,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#978)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	- _autoSwap.withdraw(address(tokenWBNB)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#980)
	- IERC20(tokenWBNB).transfer(dumpAddress,_newwbnbbalance_scope_3) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#982)
	State variables written after the call(s):
	- super._transfer(from,_deadWalletAddress,amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#992)
		- _balances[sender] = _balances[sender].sub(amount,ERC20: transfer amount exceeds balance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#385)
		- _balances[recipient] = _balances[recipient].add(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#386)
	ERC20._balances (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#201) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#399-407)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#375-388)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#266-268)
	- super._transfer(from,to,amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#996)
		- _balances[sender] = _balances[sender].sub(amount,ERC20: transfer amount exceeds balance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#385)
		- _balances[recipient] = _balances[recipient].add(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#386)
	ERC20._balances (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#201) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#399-407)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#375-388)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#266-268)
	- super._transfer(from,dividendLPTOPSTracker,_dividendLP) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1002)
		- _balances[sender] = _balances[sender].sub(amount,ERC20: transfer amount exceeds balance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#385)
		- _balances[recipient] = _balances[recipient].add(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#386)
	ERC20._balances (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#201) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#399-407)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#375-388)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#266-268)
	- swapping = false (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#984)
	TOPSToken.swapping (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#776) can be used in cross function reentrancies:
	- TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023)

**代码片段**:
```solidity
    919 | 
    920 |     event BindEvent(address indexed leader, address indexed addr);
    921 |     event edump(uint _amount,uint _now,uint _dump);
>>  922 |     function _transfer(
    923 |         address from,
    924 |         address to,
    925 |         uint256 amount
```

---

### 5. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 922 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023):
	External calls:
	- ITokenDividendTracker(dividendLPTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#937)
	- ITokenDividendTracker(dividendNFTTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#938)
	- ITokenDividendTracker(dividendNFTWBNBTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#939)
	- autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#957)
		- ITokenDividendTracker(dividendLPTOPSTracker).distributeCAKEDividends(_toLP) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1143)
		- ITokenDividendTracker(dividendNFTTOPSTracker).distributeCAKEDividends(_toNFT) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1150)
		- pair.sync() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1157)
	- swapTokensForTokenB(nftRightTotal,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#961)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	- _autoSwap.withdraw(address(tokenWBNB)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#963)
	- INFTRight(nftRightsAddress).addCake(_newwbnbbalance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#965)
	- IERC20(tokenWBNB).transfer(nftRightsAddress,_newwbnbbalance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#966)
	- swapTokensForTokenB(marketTotal,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#970)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	- _autoSwap.withdraw(address(tokenWBNB)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#972)
	- IERC20(tokenWBNB).transfer(marketAddress,_newwbnbbalance_scope_1) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#974)
	- swapTokensForTokenB(dumpAmount,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#978)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	- _autoSwap.withdraw(address(tokenWBNB)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#980)
	- IERC20(tokenWBNB).transfer(dumpAddress,_newwbnbbalance_scope_3) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#982)
	- ITokenDividendTracker(dividendLPTOPSTracker).distributeCAKEDividends(_dividendLP) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1003)
	State variables written after the call(s):
	- super._transfer(from,address(this),_toNftRight + _toMarket) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1009)
		- _balances[sender] = _balances[sender].sub(amount,ERC20: transfer amount exceeds balance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#385)
		- _balances[recipient] = _balances[recipient].add(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#386)
	ERC20._balances (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#201) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#399-407)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#375-388)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#266-268)
	- super._transfer(from,address(this),_todump) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1017)
		- _balances[sender] = _balances[sender].sub(amount,ERC20: transfer amount exceeds balance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#385)
		- _balances[recipient] = _balances[recipient].add(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#386)
	ERC20._balances (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#201) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#399-407)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#375-388)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#266-268)
	- super._transfer(from,to,amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1022)
		- _balances[sender] = _balances[sender].sub(amount,ERC20: transfer amount exceeds balance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#385)
		- _balances[recipient] = _balances[recipient].add(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#386)
	ERC20._balances (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#201) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#399-407)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#375-388)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#266-268)
	- dumpAmount = dumpAmount.add(_todump) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1016)
	TOPSToken.dumpAmount (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#739) can be used in cross function reentrancies:
	- TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023)
	- TOPSToken.dumpAmount (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#739)
	- marketTotal = marketTotal.add(_toMarket) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1008)
	TOPSToken.marketTotal (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#734) can be used in cross function reentrancies:
	- TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023)
	- TOPSToken.marketTotal (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#734)
	- nftRightTotal = nftRightTotal.add(_toNftRight) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1006)
	TOPSToken.nftRightTotal (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#733) can be used in cross function reentrancies:
	- TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023)
	- TOPSToken.nftRightTotal (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#733)

**代码片段**:
```solidity
    919 | 
    920 |     event BindEvent(address indexed leader, address indexed addr);
    921 |     event edump(uint _amount,uint _now,uint _dump);
>>  922 |     function _transfer(
    923 |         address from,
    924 |         address to,
    925 |         uint256 amount
```

---

### 6. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 870 行
- **函数**: `addTeamAmount()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in TOPSToken.addTeamAmount(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#870-889):
	External calls:
	- INFT(nftToken).safeTransferFrom(nftfromAddr,sendShare,0,1,) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#881)
	State variables written after the call(s):
	- isSendNFT[sendShare] = true (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#882)
	TOPSToken.isSendNFT (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#765) can be used in cross function reentrancies:
	- TOPSToken.addTeamAmount(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#870-889)
	- TOPSToken.isSendNFT (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#765)
	- TOPSToken.setMapping(uint256,address,bool) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1260-1270)
	- userRecommandAmount[sendShare] = userRecommandAmount[sendShare].add(_amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#877)
	TOPSToken.userRecommandAmount (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#757) can be used in cross function reentrancies:
	- TOPSToken.ASearch(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#799-805)
	- TOPSToken.addTeamAmount(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#870-889)
	- TOPSToken.setMappingUint(uint256,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1271-1279)
	- TOPSToken.userRecommandAmount (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#757)

**代码片段**:
```solidity
    867 |         uint _addwbnb = _wbnbamount.sub(_halfValue);
    868 |         addLiquidityForTokenB(afteruValue, _addwbnb,_user);
    869 |     }
>>  870 |     function addTeamAmount(address _user,uint _amount) private{
    871 |         address addressRe = _user;
    872 |         for(uint i = 1; i <= 50; i++){
    873 |             address sendShare = recommend[addressRe];
```

---

### 7. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 1131 行
- **函数**: `autoBurnLiquidityPairTokens()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in TOPSToken.autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1131-1158):
	External calls:
	- ITokenDividendTracker(dividendLPTOPSTracker).distributeCAKEDividends(_toLP) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1143)
	- ITokenDividendTracker(dividendNFTTOPSTracker).distributeCAKEDividends(_toNFT) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1150)
	State variables written after the call(s):
	- super._transfer(uniswapV2Pair,devAddress,_toDev) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1153)
		- _balances[sender] = _balances[sender].sub(amount,ERC20: transfer amount exceeds balance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#385)
		- _balances[recipient] = _balances[recipient].add(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#386)
	ERC20._balances (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#201) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#399-407)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#375-388)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#266-268)

**代码片段**:
```solidity
   1128 |             return (block.timestamp)/ 86400 * 86400 - 28800 + 86400;
   1129 |         }
   1130 |     }
>> 1131 |     function autoBurnLiquidityPairTokens() private  {
   1132 |         lastLpBurnTime = block.timestamp;
   1133 | 
   1134 |         uint256 liquidityPairBalance = this.balanceOf(uniswapV2Pair);
```

---

### 8. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 922 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023):
	External calls:
	- ITokenDividendTracker(dividendLPTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#937)
	- ITokenDividendTracker(dividendNFTTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#938)
	- ITokenDividendTracker(dividendNFTWBNBTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#939)
	- autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#957)
		- ITokenDividendTracker(dividendLPTOPSTracker).distributeCAKEDividends(_toLP) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1143)
		- ITokenDividendTracker(dividendNFTTOPSTracker).distributeCAKEDividends(_toNFT) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1150)
		- pair.sync() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1157)
	- swapTokensForTokenB(nftRightTotal,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#961)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	- _autoSwap.withdraw(address(tokenWBNB)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#963)
	- INFTRight(nftRightsAddress).addCake(_newwbnbbalance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#965)
	- IERC20(tokenWBNB).transfer(nftRightsAddress,_newwbnbbalance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#966)
	- swapTokensForTokenB(marketTotal,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#970)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	- _autoSwap.withdraw(address(tokenWBNB)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#972)
	- IERC20(tokenWBNB).transfer(marketAddress,_newwbnbbalance_scope_1) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#974)
	- swapTokensForTokenB(dumpAmount,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#978)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	State variables written after the call(s):
	- dumpAmount = 0 (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#979)
	TOPSToken.dumpAmount (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#739) can be used in cross function reentrancies:
	- TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023)
	- TOPSToken.dumpAmount (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#739)

**代码片段**:
```solidity
    919 | 
    920 |     event BindEvent(address indexed leader, address indexed addr);
    921 |     event edump(uint _amount,uint _now,uint _dump);
>>  922 |     function _transfer(
    923 |         address from,
    924 |         address to,
    925 |         uint256 amount
```

---

### 9. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 922 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023):
	External calls:
	- ITokenDividendTracker(dividendLPTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#937)
	- ITokenDividendTracker(dividendNFTTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#938)
	- ITokenDividendTracker(dividendNFTWBNBTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#939)
	- autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#957)
		- ITokenDividendTracker(dividendLPTOPSTracker).distributeCAKEDividends(_toLP) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1143)
		- ITokenDividendTracker(dividendNFTTOPSTracker).distributeCAKEDividends(_toNFT) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1150)
		- pair.sync() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1157)
	- swapTokensForTokenB(nftRightTotal,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#961)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	State variables written after the call(s):
	- nftRightTotal = 0 (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#962)
	TOPSToken.nftRightTotal (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#733) can be used in cross function reentrancies:
	- TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023)
	- TOPSToken.nftRightTotal (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#733)

**代码片段**:
```solidity
    919 | 
    920 |     event BindEvent(address indexed leader, address indexed addr);
    921 |     event edump(uint _amount,uint _now,uint _dump);
>>  922 |     function _transfer(
    923 |         address from,
    924 |         address to,
    925 |         uint256 amount
```

---

### 10. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 922 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023):
	External calls:
	- ITokenDividendTracker(dividendLPTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#937)
	- ITokenDividendTracker(dividendNFTTOPSTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#938)
	- ITokenDividendTracker(dividendNFTWBNBTracker).processAccount(address(from),true) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#939)
	- autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#957)
		- ITokenDividendTracker(dividendLPTOPSTracker).distributeCAKEDividends(_toLP) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1143)
		- ITokenDividendTracker(dividendNFTTOPSTracker).distributeCAKEDividends(_toNFT) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1150)
		- pair.sync() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1157)
	- swapTokensForTokenB(nftRightTotal,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#961)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	- _autoSwap.withdraw(address(tokenWBNB)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#963)
	- INFTRight(nftRightsAddress).addCake(_newwbnbbalance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#965)
	- IERC20(tokenWBNB).transfer(nftRightsAddress,_newwbnbbalance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#966)
	- swapTokensForTokenB(marketTotal,address(_autoSwap)) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#970)
		- uniswapV2Router.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount,0,path,recipient,block.timestamp) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1060-1066)
	State variables written after the call(s):
	- marketTotal = 0 (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#971)
	TOPSToken.marketTotal (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#734) can be used in cross function reentrancies:
	- TOPSToken._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#922-1023)
	- TOPSToken.marketTotal (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#734)

**代码片段**:
```solidity
    919 | 
    920 |     event BindEvent(address indexed leader, address indexed addr);
    921 |     event edump(uint _amount,uint _now,uint _dump);
>>  922 |     function _transfer(
    923 |         address from,
    924 |         address to,
    925 |         uint256 amount
```

---

### 11. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 1131 行
- **函数**: `autoBurnLiquidityPairTokens()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in TOPSToken.autoBurnLiquidityPairTokens() (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1131-1158):
	External calls:
	- ITokenDividendTracker(dividendLPTOPSTracker).distributeCAKEDividends(_toLP) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1143)
	State variables written after the call(s):
	- super._transfer(uniswapV2Pair,daoAddress,_toDao) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1146)
		- _balances[sender] = _balances[sender].sub(amount,ERC20: transfer amount exceeds balance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#385)
		- _balances[recipient] = _balances[recipient].add(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#386)
	ERC20._balances (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#201) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#399-407)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#375-388)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#266-268)
	- super._transfer(uniswapV2Pair,dividendNFTTOPSTracker,_toNFT) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1149)
		- _balances[sender] = _balances[sender].sub(amount,ERC20: transfer amount exceeds balance) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#385)
		- _balances[recipient] = _balances[recipient].add(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#386)
	ERC20._balances (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#201) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#399-407)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#375-388)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#266-268)

**代码片段**:
```solidity
   1128 |             return (block.timestamp)/ 86400 * 86400 - 28800 + 86400;
   1129 |         }
   1130 |     }
>> 1131 |     function autoBurnLiquidityPairTokens() private  {
   1132 |         lastLpBurnTime = block.timestamp;
   1133 | 
   1134 |         uint256 liquidityPairBalance = this.balanceOf(uniswapV2Pair);
```

---

### 12. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 663 行
- **函数**: `getReserves()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    660 |     function factory() external view returns (address);
    661 |     function token0() external view returns (address);
    662 |     function token1() external view returns (address);
>>  663 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    664 |     function price0CumulativeLast() external view returns (uint);
    665 |     function price1CumulativeLast() external view returns (uint);
    666 |     function kLast() external view returns (uint);
```

---

### 13. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1100 行
- **函数**: `_getReserves()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1097 |         );
   1098 |     }
   1099 | 
>> 1100 |     function _getReserves()public view returns (uint256 rOther, uint256 rThis, uint256 balanceOther){
   1101 |         IUniswapV2Pair mainPair = IUniswapV2Pair(uniswapV2Pair);
   1102 |         (uint r0, uint256 r1, ) = mainPair.getReserves();
   1103 |         address tokenOther = tokenWBNB;
```

---

### 14. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1102 行
- **函数**: `_getReserves()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1099 | 
   1100 |     function _getReserves()public view returns (uint256 rOther, uint256 rThis, uint256 balanceOther){
   1101 |         IUniswapV2Pair mainPair = IUniswapV2Pair(uniswapV2Pair);
>> 1102 |         (uint r0, uint256 r1, ) = mainPair.getReserves();
   1103 |         address tokenOther = tokenWBNB;
   1104 |         if (tokenOther < address(this)) {
   1105 |             rOther = r0;
```

---

### 15. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1114 行
- **函数**: `_isRemoveLiquidity()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1111 |         balanceOther = IERC20(tokenOther).balanceOf(uniswapV2Pair);
   1112 |     }
   1113 |     function _isRemoveLiquidity(uint256 amount) internal view returns (uint256 liquidity) {
>> 1114 |         (uint256 rOther, , uint256 balanceOther) = _getReserves();
   1115 | 
   1116 |         if (balanceOther <= rOther) {
   1117 |             liquidity =
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 22 行
- **函数**: `owner()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     19 |         _transferOwnership(_msgSender());
     20 |     }
     21 | 
>>   22 |     function owner() public view virtual returns (address) {
     23 |         return _owner;
     24 |     }
     25 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 46 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     43 | }
     44 | 
     45 | interface IERC20 {
>>   46 |     function totalSupply() external view returns (uint256);
     47 | 
     48 |     function balanceOf(address account) external view returns (uint256);
     49 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 48 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     45 | interface IERC20 {
     46 |     function totalSupply() external view returns (uint256);
     47 | 
>>   48 |     function balanceOf(address account) external view returns (uint256);
     49 | 
     50 |     function transfer(address recipient, uint256 amount) external returns (bool);
     51 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 50 行
- **函数**: `transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     47 | 
     48 |     function balanceOf(address account) external view returns (uint256);
     49 | 
>>   50 |     function transfer(address recipient, uint256 amount) external returns (bool);
     51 | 
     52 |     function allowance(address owner, address spender) external view returns (uint256);
     53 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 52 行
- **函数**: `allowance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     49 | 
     50 |     function transfer(address recipient, uint256 amount) external returns (bool);
     51 | 
>>   52 |     function allowance(address owner, address spender) external view returns (uint256);
     53 | 
     54 |     function approve(address spender, uint256 amount) external returns (bool);
     55 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 54 行
- **函数**: `approve()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     51 | 
     52 |     function allowance(address owner, address spender) external view returns (uint256);
     53 | 
>>   54 |     function approve(address spender, uint256 amount) external returns (bool);
     55 | 
     56 |     function transferFrom(
     57 |         address sender,
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 69 行
- **函数**: `name()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     66 | 
     67 | interface IERC20Metadata is IERC20 {
     68 | 
>>   69 |     function name() external view returns (string memory);
     70 | 
     71 |     function symbol() external view returns (string memory);
     72 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 71 行
- **函数**: `symbol()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     68 | 
     69 |     function name() external view returns (string memory);
     70 | 
>>   71 |     function symbol() external view returns (string memory);
     72 | 
     73 |     function decimals() external view returns (uint8);
     74 | }
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 73 行
- **函数**: `decimals()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     70 | 
     71 |     function symbol() external view returns (string memory);
     72 | 
>>   73 |     function decimals() external view returns (uint8);
     74 | }
     75 | library SafeMath {
     76 |     function add(uint256 a, uint256 b) internal pure returns (uint256) {
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 227 行
- **函数**: `name()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    224 |     /**
    225 |      * @dev Returns the name of the token.
    226 |      */
>>  227 |     function name() public view virtual override returns (string memory) {
    228 |         return _name;
    229 |     }
    230 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 235 行
- **函数**: `symbol()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    232 |      * @dev Returns the symbol of the token, usually a shorter version of the
    233 |      * name.
    234 |      */
>>  235 |     function symbol() public view virtual override returns (string memory) {
    236 |         return _symbol;
    237 |     }
    238 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 252 行
- **函数**: `decimals()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    249 |      * no way affects any of the arithmetic of the contract, including
    250 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    251 |      */
>>  252 |     function decimals() public view virtual override returns (uint8) {
    253 |         return 18;
    254 |     }
    255 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 259 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    256 |     /**
    257 |      * @dev See {IERC20-totalSupply}.
    258 |      */
>>  259 |     function totalSupply() public view virtual override returns (uint256) {
    260 |         return _totalSupply;
    261 |     }
    262 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 266 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    263 |     /**
    264 |      * @dev See {IERC20-balanceOf}.
    265 |      */
>>  266 |     function balanceOf(address account) public view virtual override returns (uint256) {
    267 |         return _balances[account];
    268 |     }
    269 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 278 行
- **函数**: `transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    275 |      * - `recipient` cannot be the zero address.
    276 |      * - the caller must have a balance of at least `amount`.
    277 |      */
>>  278 |     function transfer(address recipient, uint256 amount) public virtual override returns (bool) {
    279 |         _transfer(_msgSender(), recipient, amount);
    280 |         return true;
    281 |     }
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 286 行
- **函数**: `allowance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    283 |     /**
    284 |      * @dev See {IERC20-allowance}.
    285 |      */
>>  286 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    287 |         return _allowances[owner][spender];
    288 |     }
    289 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 297 行
- **函数**: `approve()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    294 |      *
    295 |      * - `spender` cannot be the zero address.
    296 |      */
>>  297 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    298 |         _approve(_msgSender(), spender, amount);
    299 |         return true;
    300 |     }
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 337 行
- **函数**: `increaseAllowance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    334 |      *
    335 |      * - `spender` cannot be the zero address.
    336 |      */
>>  337 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    338 |         _approve(_msgSender(), spender, _allowances[_msgSender()][spender].add(addedValue));
    339 |         return true;
    340 |     }
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 356 行
- **函数**: `decreaseAllowance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    353 |      * - `spender` must have allowance for the caller of at least
    354 |      * `subtractedValue`.
    355 |      */
>>  356 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    357 |         _approve(_msgSender(), spender, _allowances[_msgSender()][spender].sub(subtractedValue, "ERC20: decreased allowance below zero"));
    358 |         return true;
    359 |     }
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 476 行
- **函数**: `factory()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    473 | }
    474 | 
    475 | interface IUniswapV2Router01 {
>>  476 |     function factory() external pure returns (address);
    477 |     function WETH() external pure returns (address);
    478 | 
    479 |     function addLiquidity(
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 477 行
- **函数**: `WETH()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    474 | 
    475 | interface IUniswapV2Router01 {
    476 |     function factory() external pure returns (address);
>>  477 |     function WETH() external pure returns (address);
    478 | 
    479 |     function addLiquidity(
    480 |         address tokenA,
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 562 行
- **函数**: `quote()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    559 |         payable
    560 |         returns (uint[] memory amounts);
    561 | 
>>  562 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    563 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    564 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    565 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 563 行
- **函数**: `getAmountOut()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    560 |         returns (uint[] memory amounts);
    561 | 
    562 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
>>  563 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    564 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    565 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    566 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 564 行
- **函数**: `getAmountIn()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    561 | 
    562 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    563 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
>>  564 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    565 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    566 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
    567 | }
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 565 行
- **函数**: `getAmountsOut()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    562 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    563 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    564 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
>>  565 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    566 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
    567 | }
    568 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 566 行
- **函数**: `getAmountsIn()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    563 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    564 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    565 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
>>  566 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
    567 | }
    568 | 
    569 | interface IUniswapV2Router02 is IUniswapV2Router01 {
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 613 行
- **函数**: `feeTo()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    610 | interface IUniswapV2Factory {
    611 |     event PairCreated(address indexed token0, address indexed token1, address pair, uint);
    612 | 
>>  613 |     function feeTo() external view returns (address);
    614 |     function feeToSetter() external view returns (address);
    615 | 
    616 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 614 行
- **函数**: `feeToSetter()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    611 |     event PairCreated(address indexed token0, address indexed token1, address pair, uint);
    612 | 
    613 |     function feeTo() external view returns (address);
>>  614 |     function feeToSetter() external view returns (address);
    615 | 
    616 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    617 |     function allPairs(uint) external view returns (address pair);
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 616 行
- **函数**: `getPair()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    613 |     function feeTo() external view returns (address);
    614 |     function feeToSetter() external view returns (address);
    615 | 
>>  616 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    617 |     function allPairs(uint) external view returns (address pair);
    618 |     function allPairsLength() external view returns (uint);
    619 | 
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 617 行
- **函数**: `allPairs()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    614 |     function feeToSetter() external view returns (address);
    615 | 
    616 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
>>  617 |     function allPairs(uint) external view returns (address pair);
    618 |     function allPairsLength() external view returns (uint);
    619 | 
    620 |     function createPair(address tokenA, address tokenB) external returns (address pair);
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 618 行
- **函数**: `allPairsLength()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    615 | 
    616 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    617 |     function allPairs(uint) external view returns (address pair);
>>  618 |     function allPairsLength() external view returns (uint);
    619 | 
    620 |     function createPair(address tokenA, address tokenB) external returns (address pair);
    621 | 
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 620 行
- **函数**: `createPair()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    617 |     function allPairs(uint) external view returns (address pair);
    618 |     function allPairsLength() external view returns (uint);
    619 | 
>>  620 |     function createPair(address tokenA, address tokenB) external returns (address pair);
    621 | 
    622 |     function setFeeTo(address) external;
    623 |     function setFeeToSetter(address) external;
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 630 行
- **函数**: `name()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    627 |     event Approval(address indexed owner, address indexed spender, uint value);
    628 |     event Transfer(address indexed from, address indexed to, uint value);
    629 | 
>>  630 |     function name() external pure returns (string memory);
    631 |     function symbol() external pure returns (string memory);
    632 |     function decimals() external pure returns (uint8);
    633 |     function totalSupply() external view returns (uint);
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 631 行
- **函数**: `symbol()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    628 |     event Transfer(address indexed from, address indexed to, uint value);
    629 | 
    630 |     function name() external pure returns (string memory);
>>  631 |     function symbol() external pure returns (string memory);
    632 |     function decimals() external pure returns (uint8);
    633 |     function totalSupply() external view returns (uint);
    634 |     function balanceOf(address owner) external view returns (uint);
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 632 行
- **函数**: `decimals()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    629 | 
    630 |     function name() external pure returns (string memory);
    631 |     function symbol() external pure returns (string memory);
>>  632 |     function decimals() external pure returns (uint8);
    633 |     function totalSupply() external view returns (uint);
    634 |     function balanceOf(address owner) external view returns (uint);
    635 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 633 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    630 |     function name() external pure returns (string memory);
    631 |     function symbol() external pure returns (string memory);
    632 |     function decimals() external pure returns (uint8);
>>  633 |     function totalSupply() external view returns (uint);
    634 |     function balanceOf(address owner) external view returns (uint);
    635 |     function allowance(address owner, address spender) external view returns (uint);
    636 | 
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 634 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    631 |     function symbol() external pure returns (string memory);
    632 |     function decimals() external pure returns (uint8);
    633 |     function totalSupply() external view returns (uint);
>>  634 |     function balanceOf(address owner) external view returns (uint);
    635 |     function allowance(address owner, address spender) external view returns (uint);
    636 | 
    637 |     function approve(address spender, uint value) external returns (bool);
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 635 行
- **函数**: `allowance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    632 |     function decimals() external pure returns (uint8);
    633 |     function totalSupply() external view returns (uint);
    634 |     function balanceOf(address owner) external view returns (uint);
>>  635 |     function allowance(address owner, address spender) external view returns (uint);
    636 | 
    637 |     function approve(address spender, uint value) external returns (bool);
    638 |     function transfer(address to, uint value) external returns (bool);
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 637 行
- **函数**: `approve()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    634 |     function balanceOf(address owner) external view returns (uint);
    635 |     function allowance(address owner, address spender) external view returns (uint);
    636 | 
>>  637 |     function approve(address spender, uint value) external returns (bool);
    638 |     function transfer(address to, uint value) external returns (bool);
    639 |     function transferFrom(address from, address to, uint value) external returns (bool);
    640 | 
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 638 行
- **函数**: `transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    635 |     function allowance(address owner, address spender) external view returns (uint);
    636 | 
    637 |     function approve(address spender, uint value) external returns (bool);
>>  638 |     function transfer(address to, uint value) external returns (bool);
    639 |     function transferFrom(address from, address to, uint value) external returns (bool);
    640 | 
    641 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 639 行
- **函数**: `transferFrom()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    636 | 
    637 |     function approve(address spender, uint value) external returns (bool);
    638 |     function transfer(address to, uint value) external returns (bool);
>>  639 |     function transferFrom(address from, address to, uint value) external returns (bool);
    640 | 
    641 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    642 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 641 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    638 |     function transfer(address to, uint value) external returns (bool);
    639 |     function transferFrom(address from, address to, uint value) external returns (bool);
    640 | 
>>  641 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    642 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
    643 |     function nonces(address owner) external view returns (uint);
    644 | 
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 642 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    639 |     function transferFrom(address from, address to, uint value) external returns (bool);
    640 | 
    641 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>>  642 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
    643 |     function nonces(address owner) external view returns (uint);
    644 | 
    645 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 643 行
- **函数**: `nonces()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    640 | 
    641 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    642 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>>  643 |     function nonces(address owner) external view returns (uint);
    644 | 
    645 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
    646 | 
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 659 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    656 |     );
    657 |     event Sync(uint112 reserve0, uint112 reserve1);
    658 | 
>>  659 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
    660 |     function factory() external view returns (address);
    661 |     function token0() external view returns (address);
    662 |     function token1() external view returns (address);
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 660 行
- **函数**: `factory()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    657 |     event Sync(uint112 reserve0, uint112 reserve1);
    658 | 
    659 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
>>  660 |     function factory() external view returns (address);
    661 |     function token0() external view returns (address);
    662 |     function token1() external view returns (address);
    663 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 661 行
- **函数**: `token0()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    658 | 
    659 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
    660 |     function factory() external view returns (address);
>>  661 |     function token0() external view returns (address);
    662 |     function token1() external view returns (address);
    663 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    664 |     function price0CumulativeLast() external view returns (uint);
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 662 行
- **函数**: `token1()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    659 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
    660 |     function factory() external view returns (address);
    661 |     function token0() external view returns (address);
>>  662 |     function token1() external view returns (address);
    663 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    664 |     function price0CumulativeLast() external view returns (uint);
    665 |     function price1CumulativeLast() external view returns (uint);
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 663 行
- **函数**: `getReserves()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    660 |     function factory() external view returns (address);
    661 |     function token0() external view returns (address);
    662 |     function token1() external view returns (address);
>>  663 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    664 |     function price0CumulativeLast() external view returns (uint);
    665 |     function price1CumulativeLast() external view returns (uint);
    666 |     function kLast() external view returns (uint);
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 664 行
- **函数**: `price0CumulativeLast()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    661 |     function token0() external view returns (address);
    662 |     function token1() external view returns (address);
    663 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>>  664 |     function price0CumulativeLast() external view returns (uint);
    665 |     function price1CumulativeLast() external view returns (uint);
    666 |     function kLast() external view returns (uint);
    667 | 
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 665 行
- **函数**: `price1CumulativeLast()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    662 |     function token1() external view returns (address);
    663 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    664 |     function price0CumulativeLast() external view returns (uint);
>>  665 |     function price1CumulativeLast() external view returns (uint);
    666 |     function kLast() external view returns (uint);
    667 | 
    668 |     function mint(address to) external returns (uint liquidity);
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 666 行
- **函数**: `kLast()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    663 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    664 |     function price0CumulativeLast() external view returns (uint);
    665 |     function price1CumulativeLast() external view returns (uint);
>>  666 |     function kLast() external view returns (uint);
    667 | 
    668 |     function mint(address to) external returns (uint liquidity);
    669 |     function burn(address to) external returns (uint amount0, uint amount1);
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 668 行
- **函数**: `mint()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    665 |     function price1CumulativeLast() external view returns (uint);
    666 |     function kLast() external view returns (uint);
    667 | 
>>  668 |     function mint(address to) external returns (uint liquidity);
    669 |     function burn(address to) external returns (uint amount0, uint amount1);
    670 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    671 |     function skim(address to) external;
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 669 行
- **函数**: `burn()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    666 |     function kLast() external view returns (uint);
    667 | 
    668 |     function mint(address to) external returns (uint liquidity);
>>  669 |     function burn(address to) external returns (uint amount0, uint amount1);
    670 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    671 |     function skim(address to) external;
    672 |     function sync() external;
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 678 行
- **函数**: `deposit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    675 | }
    676 | 
    677 | interface IWBNB {
>>  678 |     function deposit() external payable;
    679 |     function withdraw(uint wad) external;
    680 | }
    681 | 
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 685 行
- **函数**: `processAccount()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    682 | interface ITokenDividendTracker {
    683 |     function setBalance(address payable account, uint256 newBalance) external;
    684 |     function distributeCAKEDividends(uint256 amount) external;
>>  685 |     function processAccount(address payable account,bool automatic) external returns(bool);
    686 | 
    687 | }
    688 | interface INFTRight {
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 693 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    690 | }
    691 | interface INFT{
    692 |         function safeTransferFrom(address from,address to,uint id,uint256 value,bytes memory data) external;
>>  693 |         function balanceOf(address account,uint256 id) external view returns(uint256);
    694 |     }
    695 | contract TOPSToken is ERC20, Ownable {
    696 | 
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 799 行
- **函数**: `ASearch()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    796 |     receive() external payable { doAddLP();}
    797 |     fallback() external payable{}
    798 |     /// @notice 输入地址查询业绩信息
>>  799 |     function ASearch(address _user) public view returns(address _leader,
    800 |                                                         uint _shareCount,
    801 |                                                         uint _teamAmount){
    802 |         _leader = recommend[_user];
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 806 行
- **函数**: `getBNBAmount()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    803 |         _shareCount = userRecommandCount[_user];
    804 |         _teamAmount = userRecommandAmount[_user];
    805 |     }
>>  806 |     function getBNBAmount() public view returns(uint){
    807 |         uint _wbnb = IERC20(tokenWBNB).balanceOf(uniswapV2Pair);
    808 |         if(_wbnb > pairWBNB[4]){
    809 |             return lpBNB[5];
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 825 行
- **函数**: `doAddLP()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    822 |     }
    823 |     event eaddshare(address indexed _user,address indexed _share,uint _amount);
    824 |     event eaddteam(address indexed _user,address indexed _leader ,address indexed _douser,uint _amount);
>>  825 |     function doAddLP() public payable  {
    826 |         address _user = msg.sender;
    827 |         uint _amount = msg.value;
    828 |         if(!isOpen){
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 911 行
- **函数**: `getDeep()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    908 |             IERC20(tokenWBNB).transfer(nftRightsAddress,_amount.mul(_noshareCount).div(1000));
    909 |         }
    910 |     }
>>  911 |     function getDeep(uint _count) public pure returns(uint){
    912 |         if(_count>=5){
    913 |             return 20;
    914 |         }else{
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1025 行
- **函数**: `getDumpAmount()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1022 |         super._transfer(from, to, amount);        
   1023 |     }
   1024 | 
>> 1025 |     function getDumpAmount(uint _amount) public view returns(uint _dumpAmount){
   1026 |         _dumpAmount = 0;
   1027 |         if(isDumpingFee){
   1028 |             uint _startPrice = dayPrice[getDayStart()];
```

---

### 78. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1124 行
- **函数**: `getDayStart()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1121 |     }
   1122 | 
   1123 | 
>> 1124 |     function getDayStart() public view returns(uint) {
   1125 |         if(block.timestamp % 86400 < 57600) {
   1126 |             return (block.timestamp)/ 86400 * 86400 - 28800;
   1127 |         } else {
```

---

### 79. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1159 行
- **函数**: `getToDeadUint()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1156 |         IUniswapV2Pair pair = IUniswapV2Pair(uniswapV2Pair);
   1157 |         pair.sync();
   1158 |     }
>> 1159 |     function getToDeadUint(uint _amount) public view returns(uint){
   1160 |         uint _Deadbalance  =  this.balanceOf(_deadWalletAddress);
   1161 |         if(_Deadbalance.add(_amount) > deadTotal){
   1162 |             if(_Deadbalance >= deadTotal){
```

---

### 80. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1183 行
- **函数**: `getpairDeads()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1180 |         path[1] = tokenWBNB;
   1181 |         return IUniswapV2Router02(uniswapV2Router).getAmountsOut(_topsAmount, path)[1];
   1182 |     }
>> 1183 |     function getpairDeads() public view returns(uint [5] memory){
   1184 |         return pairDeads;
   1185 |     }
   1186 |     function getsellFees() public view returns(uint [3] memory){
```

---

### 81. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1186 行
- **函数**: `getsellFees()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1183 |     function getpairDeads() public view returns(uint [5] memory){
   1184 |         return pairDeads;
   1185 |     }
>> 1186 |     function getsellFees() public view returns(uint [3] memory){
   1187 |         return sellFees;
   1188 |     }
   1189 |     function getpairWBNB() public view returns(uint [5] memory){
```

---

### 82. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1189 行
- **函数**: `getpairWBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1186 |     function getsellFees() public view returns(uint [3] memory){
   1187 |         return sellFees;
   1188 |     }
>> 1189 |     function getpairWBNB() public view returns(uint [5] memory){
   1190 |         return pairWBNB;
   1191 |     }
   1192 |     function getlpBNB() public view returns(uint [6] memory){
```

---

### 83. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1192 行
- **函数**: `getlpBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1189 |     function getpairWBNB() public view returns(uint [5] memory){
   1190 |         return pairWBNB;
   1191 |     }
>> 1192 |     function getlpBNB() public view returns(uint [6] memory){
   1193 |         return lpBNB;
   1194 |     }
   1195 |     function getlpFee() public view returns(uint [3] memory){
```

---

### 84. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1195 行
- **函数**: `getlpFee()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1192 |     function getlpBNB() public view returns(uint [6] memory){
   1193 |         return lpBNB;
   1194 |     }
>> 1195 |     function getlpFee() public view returns(uint [3] memory){
   1196 |         return lpFee;
   1197 |     }
   1198 |     function getshareFees() public view returns(uint [20] memory){
```

---

### 85. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1198 行
- **函数**: `getshareFees()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1195 |     function getlpFee() public view returns(uint [3] memory){
   1196 |         return lpFee;
   1197 |     }
>> 1198 |     function getshareFees() public view returns(uint [20] memory){
   1199 |         return shareFees;
   1200 |     }
   1201 |     function getdumpParameters() public view returns(uint [3] memory){
```

---

### 86. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1201 行
- **函数**: `getdumpParameters()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1198 |     function getshareFees() public view returns(uint [20] memory){
   1199 |         return shareFees;
   1200 |     }
>> 1201 |     function getdumpParameters() public view returns(uint [3] memory){
   1202 |         return dumpParameters;
   1203 |     }
   1204 |     function getdumpFee() public view returns(uint [3] memory){
```

---

### 87. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1204 行
- **函数**: `getdumpFee()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1201 |     function getdumpParameters() public view returns(uint [3] memory){
   1202 |         return dumpParameters;
   1203 |     }
>> 1204 |     function getdumpFee() public view returns(uint [3] memory){
   1205 |         return dumpFee;
   1206 |     }
   1207 |     function setBool(uint _t,bool _istrue) public onlyOwner{
```

---

### 88. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1326 行
- **函数**: `withdraw()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1323 |     }
   1324 |     receive() external payable {}
   1325 | 
>> 1326 |     function withdraw(address token) public payable {
   1327 |         require(msg.sender == owner, "caller is not owner");
   1328 |         uint256 balance = IERC20(token).balanceOf(address(this));
   1329 |         if (balance > 0) {
```

---

### 89. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 14 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      9 |     function _msgData() internal view virtual returns (bytes calldata) {
     10 |         return msg.data;
     11 |     }
     12 | }
     13 | 
>>   14 | abstract contract Ownable is Context {
     15 |     address private _owner;
     16 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     17 | 
     18 |     constructor() {
     19 |         _transferOwnership(_msgSender());
```

---

### 90. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 198 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    193 |     require(b >= 0);
    194 |     return b;
    195 |   }
    196 | }
    197 | 
>>  198 | contract ERC20 is Context, IERC20, IERC20Metadata {
    199 |     using SafeMath for uint256;
    200 | 
    201 |     mapping(address => uint256) private _balances;
    202 | 
    203 |     mapping(address => mapping(address => uint256)) private _allowances;
```

---

### 91. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 695 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    690 | }
    691 | interface INFT{
    692 |         function safeTransferFrom(address from,address to,uint id,uint256 value,bytes memory data) external;
    693 |         function balanceOf(address account,uint256 id) external view returns(uint256);
    694 |     }
>>  695 | contract TOPSToken is ERC20, Ownable {
    696 | 
    697 |     using SafeMath for uint256;
    698 | 
    699 |     address public _deadWalletAddress  = 0x000000000000000000000000000000000000dEaD;
    700 |        
```

---

### 92. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1318 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1313 | 
   1314 | }
   1315 | 
   1316 | 
   1317 | 
>> 1318 | contract TransitSwap {
   1319 |     using SafeMath for uint256;
   1320 |     address owner;
   1321 |     constructor(address _owner) {
   1322 |         owner = _owner;
   1323 |     }
```

---

### 93. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 1218 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: TOPSToken.setAddress(uint256,address)._addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1218) lacks a zero-check on :
		- daoAddress = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1220)
		- nftRightsAddress = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1222)
		- marketAddress = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1224)
		- devAddress = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1226)
		- topAddress = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1228)
		- dividendLPTOPSTracker = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1230)
		- dividendNFTTOPSTracker = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1232)
		- dividendNFTWBNBTracker = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1234)
		- dumpAddress = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1236)
		- nftfromAddr = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1238)
		- nftToken = _addr (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1240)

**代码片段**:
```solidity
   1215 |             isOpen = _istrue;
   1216 |         }
   1217 |     }
>> 1218 |     function setAddress(uint _t,address _addr) public onlyOwner{
   1219 |         if(_t == 0){
   1220 |             daoAddress = _addr;
   1221 |         }else if(_t == 1){
```

---

### 94. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 1321 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: TransitSwap.constructor(address)._owner (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1321) lacks a zero-check on :
		- owner = _owner (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1322)

**代码片段**:
```solidity
   1318 | contract TransitSwap {
   1319 |     using SafeMath for uint256;
   1320 |     address owner;
>> 1321 |     constructor(address _owner) {
   1322 |         owner = _owner;
   1323 |     }
   1324 |     receive() external payable {}
```

---

### 95. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol` 第 1303 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: TOPSToken.transferBNB(address,uint256).account (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1303) lacks a zero-check on :
		- address(account).transfer(amount) (../../../tmp/slither_scan_llwjpv1n/0x17907521Ac2E8637614CefB5f568A214e10e001A.sol#1304)

**代码片段**:
```solidity
   1300 |         }
   1301 |     }
   1302 | 
>> 1303 |     function transferBNB(address account, uint amount) public  onlyOwner{
   1304 |         payable(account).transfer(amount);
   1305 |     }
   1306 | 
```

---

### 96. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 956 行
- **函数**: `_transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    953 |         if(uniswapV2Pair == to && !swapping && _isfee) {
    954 |             swapping = true;
    955 |        
>>  956 |             if (lpBurnEnabled && block.timestamp >= (lastLpBurnTime + lpBurnFrequency)) {
    957 |                 autoBurnLiquidityPairTokens();
    958 |             }
    959 |             if(nftRightTotal > AmountLiquidityFeeDoAdd){
```

---

### 97. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1065 行
- **函数**: `swapTokensForTokenB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1062 |             0,
   1063 |             path,
   1064 |             recipient,
>> 1065 |             block.timestamp
   1066 |         );
   1067 |     }
   1068 |     function addLiquidityForTokenB(uint256 tokenAmount, uint256 tokenBAmount,address _user) private {
```

---

### 98. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1081 行
- **函数**: `addLiquidityForTokenB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1078 |             0,
   1079 |             0,
   1080 |             address(_user),
>> 1081 |             block.timestamp
   1082 |         );
   1083 |     }
   1084 |     function swapWBNBForToken(uint256 tokenAmount, address recipient) private {
```

---

### 99. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1096 行
- **函数**: `swapWBNBForToken()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1093 |             0,
   1094 |             path,
   1095 |             recipient,
>> 1096 |             block.timestamp
   1097 |         );
   1098 |     }
   1099 | 
```

---

### 100. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1125 行
- **函数**: `getDayStart()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1122 | 
   1123 | 
   1124 |     function getDayStart() public view returns(uint) {
>> 1125 |         if(block.timestamp % 86400 < 57600) {
   1126 |             return (block.timestamp)/ 86400 * 86400 - 28800;
   1127 |         } else {
   1128 |             return (block.timestamp)/ 86400 * 86400 - 28800 + 86400;
```

---

### 101. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1126 行
- **函数**: `getDayStart()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1123 | 
   1124 |     function getDayStart() public view returns(uint) {
   1125 |         if(block.timestamp % 86400 < 57600) {
>> 1126 |             return (block.timestamp)/ 86400 * 86400 - 28800;
   1127 |         } else {
   1128 |             return (block.timestamp)/ 86400 * 86400 - 28800 + 86400;
   1129 |         }
```

---

### 102. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1128 行
- **函数**: `getDayStart()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1125 |         if(block.timestamp % 86400 < 57600) {
   1126 |             return (block.timestamp)/ 86400 * 86400 - 28800;
   1127 |         } else {
>> 1128 |             return (block.timestamp)/ 86400 * 86400 - 28800 + 86400;
   1129 |         }
   1130 |     }
   1131 |     function autoBurnLiquidityPairTokens() private  {
```

---

### 103. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1132 行
- **函数**: `autoBurnLiquidityPairTokens()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1129 |         }
   1130 |     }
   1131 |     function autoBurnLiquidityPairTokens() private  {
>> 1132 |         lastLpBurnTime = block.timestamp;
   1133 | 
   1134 |         uint256 liquidityPairBalance = this.balanceOf(uniswapV2Pair);
   1135 | 
```

---

### 104. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 856 行
- **函数**: `doAddLP()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    853 | 
    854 |         uint _nftreward = _amount.mul(lpFee[2]).div(100);
    855 |         INFTRight(nftRightsAddress).addCake(_nftreward);
>>  856 |         IERC20(tokenWBNB).transfer(nftRightsAddress,_nftreward);
    857 | 
    858 |         try ITokenDividendTracker(dividendLPTOPSTracker).setBalance(payable(_user), IERC20(uniswapV2Pair).balanceOf(_user)){} catch {}
    859 |         addlpswapping = false;
```

---

### 105. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 899 行
- **函数**: `setShareReward()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    896 |                     _noshareCount = _noshareCount.add(shareFees[i]);
    897 |                 }else{
    898 |                     if(getDeep(userRecommandCount[sendShare]) > i){
>>  899 |                         IERC20(tokenWBNB).transfer(sendShare, _amount.mul(shareFees[i]).div(1000));
    900 |                     }else{
    901 |                         _noshareCount = _noshareCount.add(shareFees[i]);
    902 |                     }
```

---

### 106. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 908 行
- **函数**: `setShareReward()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    905 |         }
    906 |         if(_noshareCount > 0){
    907 |             INFTRight(nftRightsAddress).addCake(_amount.mul(_noshareCount).div(1000));
>>  908 |             IERC20(tokenWBNB).transfer(nftRightsAddress,_amount.mul(_noshareCount).div(1000));
    909 |         }
    910 |     }
    911 |     function getDeep(uint _count) public pure returns(uint){
```

---

### 107. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 966 行
- **函数**: `_transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    963 |                 _autoSwap.withdraw(address(tokenWBNB));
    964 |                 uint256 _newwbnbbalance = IERC20(tokenWBNB).balanceOf(address(this)).sub(_wbnbbalance);
    965 |                 INFTRight(nftRightsAddress).addCake(_newwbnbbalance);
>>  966 |                 IERC20(tokenWBNB).transfer(nftRightsAddress,_newwbnbbalance);
    967 |             }
    968 |             if(marketTotal > AmountLiquidityFeeDoAdd){
    969 |                 uint _wbnbbalance = IERC20(tokenWBNB).balanceOf(address(this));
```

---

### 108. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 974 行
- **函数**: `_transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    971 |                 marketTotal = 0;
    972 |                 _autoSwap.withdraw(address(tokenWBNB));
    973 |                 uint256 _newwbnbbalance = IERC20(tokenWBNB).balanceOf(address(this)).sub(_wbnbbalance);
>>  974 |                 IERC20(tokenWBNB).transfer(marketAddress,_newwbnbbalance);
    975 |             }
    976 |             if(dumpAmount > AmountLiquidityFeeDoAdd){
    977 |                 uint _wbnbbalance = IERC20(tokenWBNB).balanceOf(address(this));
```

---

### 109. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 982 行
- **函数**: `_transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    979 |                 dumpAmount = 0;
    980 |                 _autoSwap.withdraw(address(tokenWBNB));
    981 |                 uint256 _newwbnbbalance = IERC20(tokenWBNB).balanceOf(address(this)).sub(_wbnbbalance);
>>  982 |                 IERC20(tokenWBNB).transfer(dumpAddress,_newwbnbbalance);
    983 |             }
    984 |             swapping = false;
    985 |         }
```

---

### 110. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1304 行
- **函数**: `transferBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1301 |     }
   1302 | 
   1303 |     function transferBNB(address account, uint amount) public  onlyOwner{
>> 1304 |         payable(account).transfer(amount);
   1305 |     }
   1306 | 
   1307 |     function transferERC20(address _token, address account, uint amount) public  onlyOwner{
```

---

### 111. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1308 行
- **函数**: `transferERC20()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1305 |     }
   1306 | 
   1307 |     function transferERC20(address _token, address account, uint amount) public  onlyOwner{
>> 1308 |         IERC20(_token).transfer(account,amount);
   1309 |     }
   1310 |     function transferFromERC20(address _token, address account,address _to ,uint amount) public  onlyOwner{
   1311 |         IERC20(_token).transferFrom(account,_to,amount);
```

---

### 112. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 1330 行
- **函数**: `withdraw()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1327 |         require(msg.sender == owner, "caller is not owner");
   1328 |         uint256 balance = IERC20(token).balanceOf(address(this));
   1329 |         if (balance > 0) {
>> 1330 |             IERC20(token).transfer(msg.sender, balance);
   1331 |         }
   1332 |     }
   1333 | 
```

---

### 113. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 699 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    696 | 
    697 |     using SafeMath for uint256;
    698 | 
>>  699 |     address public _deadWalletAddress  = 0x000000000000000000000000000000000000dEaD;
    700 |        
    701 |     address public tokenWBNB = address(0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c);
    702 | 
```

---

### 114. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 701 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    698 | 
    699 |     address public _deadWalletAddress  = 0x000000000000000000000000000000000000dEaD;
    700 |        
>>  701 |     address public tokenWBNB = address(0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c);
    702 | 
    703 |     address public daoAddress = 0xA2CbA2E4F46b98f1785672D7F794De7630aCE67f;
    704 | 
```

---

### 115. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 703 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    700 |        
    701 |     address public tokenWBNB = address(0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c);
    702 | 
>>  703 |     address public daoAddress = 0xA2CbA2E4F46b98f1785672D7F794De7630aCE67f;
    704 | 
    705 |     address public nftRightsAddress;
    706 | 
```

---

### 116. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 707 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    704 | 
    705 |     address public nftRightsAddress;
    706 | 
>>  707 |     address public marketAddress = 0x15d631f44B80CBF0A4D538030F138ABeccBf0B16;
    708 | 
    709 |     address public devAddress = 0x162B543Ed434121e9acd81ed222e0E01118d8D04;
    710 |     address public topAddress = 0x8559d2Ba317b7Aa0A0D2C322b57ff321Fe440f9C;
```

---

### 117. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 709 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    706 | 
    707 |     address public marketAddress = 0x15d631f44B80CBF0A4D538030F138ABeccBf0B16;
    708 | 
>>  709 |     address public devAddress = 0x162B543Ed434121e9acd81ed222e0E01118d8D04;
    710 |     address public topAddress = 0x8559d2Ba317b7Aa0A0D2C322b57ff321Fe440f9C;
    711 |     mapping (address => bool) public _isExcludedFromFees;
    712 |     address public uniswapV2Pair;
```

---

### 118. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 710 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    707 |     address public marketAddress = 0x15d631f44B80CBF0A4D538030F138ABeccBf0B16;
    708 | 
    709 |     address public devAddress = 0x162B543Ed434121e9acd81ed222e0E01118d8D04;
>>  710 |     address public topAddress = 0x8559d2Ba317b7Aa0A0D2C322b57ff321Fe440f9C;
    711 |     mapping (address => bool) public _isExcludedFromFees;
    712 |     address public uniswapV2Pair;
    713 |     IUniswapV2Router02 public uniswapV2Router;
```

---

### 119. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 740 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    737 |     uint[3] public dumpParameters = [10,15,20];
    738 |     uint[3] public dumpFee = [20,30,38];
    739 |     uint public dumpAmount;
>>  740 |     address public dumpAddress = 0xAce73Ee3f3E8Af14Bd1d20D5A1B99060Dff1dD4d;
    741 |     uint public AmountLiquidityFeeDoAdd = 10*1e18;
    742 | 
    743 |     mapping(address => mapping(address => bool)) public waitrecommend;
```

---

### 120. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 764 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    761 | 
    762 |     mapping(address => bool) public isUseUser;
    763 |     mapping(address => uint) public userTotalAmount;
>>  764 |     address public nftfromAddr = 0x5a70A936b1239B272d4bF185019124585fAc1C22;
    765 |     mapping(address => bool) public isSendNFT;
    766 |     address public nftToken;
    767 |     event ProcessedDividendTracker(
```

---

### 121. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x17907521Ac2E8637614CefB5f568A214e10e001A` 第 789 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    786 |         _isExcludedFromFees[address(_autoSwap)] = true;
    787 | 
    788 |         _mint(owner(), totalSupply);
>>  789 |         IUniswapV2Router02 _uniswapV2Router = IUniswapV2Router02(0x10ED43C718714eb63d5aA57B78B54704E256024E);
    790 |         address _uniswapV2Pair = IUniswapV2Factory(_uniswapV2Router.factory()).createPair(address(this), _uniswapV2Router.WETH());
    791 |         uniswapV2Router = _uniswapV2Router;
    792 |         uniswapV2Pair = _uniswapV2Pair; 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*