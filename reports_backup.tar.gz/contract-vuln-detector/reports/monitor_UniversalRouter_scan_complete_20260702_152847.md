# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:28:47
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` |
| contract_name | `UniversalRouter` |
| compiler_version | `v0.8.17+commit.8df45f5f` |
| optimization_used | `True` |
| runs | `1000000` |
| evm_version | `london` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/UniversalRouter.sol', 'contracts/base/Dispatcher.sol', 'contracts/base/RewardsCollector.sol', 'contracts/base/RouterImmutables.sol', 'contracts/libraries/Commands.sol', 'contracts/interfaces/IUniversalRouter.sol', 'contracts/modules/uniswap/v2/V2SwapRouter.sol', 'contracts/modules/uniswap/v3/V3SwapRouter.sol', 'contracts/modules/uniswap/v3/BytesLib.sol', 'contracts/modules/Payments.sol', 'contracts/base/Callbacks.sol', 'contracts/base/LockAndMsgSender.sol', 'lib/solmate/src/tokens/ERC721.sol', 'lib/solmate/src/tokens/ERC1155.sol', 'lib/solmate/src/tokens/ERC20.sol', 'lib/permit2/src/interfaces/IAllowanceTransfer.sol', 'contracts/interfaces/external/ICryptoPunksMarket.sol', 'lib/solmate/src/utils/SafeTransferLib.sol', 'contracts/interfaces/IRewardsCollector.sol', 'contracts/interfaces/external/IWETH9.sol', 'node_modules/@openzeppelin/contracts/token/ERC721/IERC721Receiver.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/IERC1155Receiver.sol', 'node_modules/@uniswap/v2-core/contracts/interfaces/IUniswapV2Pair.sol', 'contracts/modules/uniswap/v2/UniswapV2Library.sol', 'contracts/modules/Permit2Payments.sol', 'contracts/libraries/Constants.sol', 'contracts/modules/uniswap/v3/V3Path.sol', 'node_modules/@uniswap/v3-core/contracts/libraries/SafeCast.sol', 'node_modules/@uniswap/v3-core/contracts/interfaces/IUniswapV3Pool.sol', 'node_modules/@uniswap/v3-core/contracts/interfaces/callback/IUniswapV3SwapCallback.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/IERC165.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/IERC20.sol', 'lib/permit2/src/libraries/SafeCast160.sol', 'node_modules/@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolImmutables.sol', 'node_modules/@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolState.sol', 'node_modules/@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolDerivedState.sol', 'node_modules/@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolActions.sol', 'node_modules/@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolOwnerActions.sol', 'node_modules/@uniswap/v3-core/contracts/interfaces/pool/IUniswapV3PoolEvents.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655011` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 97 |
| 🟢 LOW | 40 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 785 行
- **函数**: `_v2Swap()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    782 |             uint256 penultimatePairIndex = finalPairIndex - 1;
    783 |             for (uint256 i; i < finalPairIndex; i++) {
    784 |                 (address input, address output) = (path[i], path[i + 1]);
>>  785 |                 (uint256 reserve0, uint256 reserve1,) = IUniswapV2Pair(pair).getReserves();
    786 |                 (uint256 reserveInput, uint256 reserveOutput) =
    787 |                     input == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
    788 |                 uint256 amountInput = ERC20(input).balanceOf(pair) - reserveInput;
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2540 行
- **函数**: `getReserves()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2537 |     function factory() external view returns (address);
   2538 |     function token0() external view returns (address);
   2539 |     function token1() external view returns (address);
>> 2540 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2541 |     function price0CumulativeLast() external view returns (uint);
   2542 |     function price1CumulativeLast() external view returns (uint);
   2543 |     function kLast() external view returns (uint);
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2637 行
- **函数**: `pairAndReservesFor()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2634 |     {
   2635 |         address token0;
   2636 |         (pair, token0) = pairAndToken0For(factory, initCodeHash, tokenA, tokenB);
>> 2637 |         (uint256 reserve0, uint256 reserve1,) = IUniswapV2Pair(pair).getReserves();
   2638 |         (reserveA, reserveB) = tokenA == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
   2639 |     }
   2640 | 
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 288 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    285 |                         ///     For some such purchases, an OWNER_CHECK command can be prepended to ensure that all tokens have the desired owner at the end of the transaction.
    286 |                         ///     This is also outlined in the Seaport documentation: https://github.com/ProjectOpenSea/seaport/blob/main/docs/SeaportDocumentation.md
    287 |                         (uint256 value, bytes calldata data) = getValueAndData(inputs);
>>  288 |                         (success, output) = SEAPORT_V1_5.call{value: value}(data);
    289 |                     } else if (command == Commands.LOOKS_RARE_V2) {
    290 |                         // equivalent: abi.decode(inputs, (uint256, bytes))
    291 |                         uint256 value;
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 296 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    293 |                             value := calldataload(inputs.offset)
    294 |                         }
    295 |                         bytes calldata data = inputs.toBytes(1);
>>  296 |                         (success, output) = LOOKS_RARE_V2.call{value: value}(data);
    297 |                     } else if (command == Commands.NFTX) {
    298 |                         // equivalent: abi.decode(inputs, (uint256, bytes))
    299 |                         (uint256 value, bytes calldata data) = getValueAndData(inputs);
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 300 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    297 |                     } else if (command == Commands.NFTX) {
    298 |                         // equivalent: abi.decode(inputs, (uint256, bytes))
    299 |                         (uint256 value, bytes calldata data) = getValueAndData(inputs);
>>  300 |                         (success, output) = NFTX_ZAP.call{value: value}(data);
    301 |                     } else if (command == Commands.CRYPTOPUNKS) {
    302 |                         // equivalent: abi.decode(inputs, (uint256, address, uint256))
    303 |                         uint256 punkId;
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 311 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    308 |                             recipient := calldataload(add(inputs.offset, 0x20))
    309 |                             value := calldataload(add(inputs.offset, 0x40))
    310 |                         }
>>  311 |                         (success, output) = CRYPTOPUNKS.call{value: value}(
    312 |                             abi.encodeWithSelector(ICryptoPunksMarket.buyPunk.selector, punkId)
    313 |                         );
    314 |                         if (success) ICryptoPunksMarket(CRYPTOPUNKS).transferPunk(map(recipient), punkId);
```

---

### 8. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 361 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    358 |                     } else if (command == Commands.SUDOSWAP) {
    359 |                         // equivalent: abi.decode(inputs, (uint256, bytes))
    360 |                         (uint256 value, bytes calldata data) = getValueAndData(inputs);
>>  361 |                         (success, output) = SUDOSWAP.call{value: value}(data);
    362 |                     } else if (command == Commands.NFT20) {
    363 |                         // equivalent: abi.decode(inputs, (uint256, bytes))
    364 |                         (uint256 value, bytes calldata data) = getValueAndData(inputs);
```

---

### 9. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 365 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    362 |                     } else if (command == Commands.NFT20) {
    363 |                         // equivalent: abi.decode(inputs, (uint256, bytes))
    364 |                         (uint256 value, bytes calldata data) = getValueAndData(inputs);
>>  365 |                         (success, output) = NFT20_ZAP.call{value: value}(data);
    366 |                     } else if (command == Commands.X2Y2_1155) {
    367 |                         (success, output) = callAndTransfer1155(inputs, X2Y2);
    368 |                     } else if (command == Commands.FOUNDATION) {
```

---

### 10. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 386 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    383 |                     } else if (command == Commands.ELEMENT_MARKET) {
    384 |                         // equivalent: abi.decode(inputs, (uint256, bytes))
    385 |                         (uint256 value, bytes calldata data) = getValueAndData(inputs);
>>  386 |                         (success, output) = ELEMENT_MARKET.call{value: value}(data);
    387 |                     } else {
    388 |                         // placeholder for command 0x1f
    389 |                         revert InvalidCommandType(command);
```

---

### 11. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 404 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    401 |                 ///     For some such purchases, an OWNER_CHECK command can be prepended to ensure that all tokens have the desired owner at the end of the transaction.
    402 |                 ///     This is also outlined in the Seaport documentation: https://github.com/ProjectOpenSea/seaport/blob/main/docs/SeaportDocumentation.md
    403 |                 (uint256 value, bytes calldata data) = getValueAndData(inputs);
>>  404 |                 (success, output) = SEAPORT_V1_4.call{value: value}(data);
    405 |             } else if (command == Commands.EXECUTE_SUB_PLAN) {
    406 |                 bytes calldata _commands = inputs.toBytes(0);
    407 |                 bytes[] calldata _inputs = inputs.toBytesArray(1);
```

---

### 12. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 409 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    406 |                 bytes calldata _commands = inputs.toBytes(0);
    407 |                 bytes[] calldata _inputs = inputs.toBytesArray(1);
    408 |                 (success, output) =
>>  409 |                     (address(this)).call(abi.encodeWithSelector(Dispatcher.execute.selector, _commands, _inputs));
    410 |             } else if (command == Commands.APPROVE_ERC20) {
    411 |                 ERC20 token;
    412 |                 RouterImmutables.Spenders spender;
```

---

### 13. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 450 行
- **函数**: `callAndTransfer721()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    447 |             token := calldataload(add(inputs.offset, 0x60))
    448 |             id := calldataload(add(inputs.offset, 0x80))
    449 |         }
>>  450 |         (success, output) = protocol.call{value: value}(data);
    451 |         if (success) ERC721(token).safeTransferFrom(address(this), map(recipient), id);
    452 |     }
    453 | 
```

---

### 14. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 476 行
- **函数**: `callAndTransfer1155()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    473 |             id := calldataload(add(inputs.offset, 0x80))
    474 |             amount := calldataload(add(inputs.offset, 0xa0))
    475 |         }
>>  476 |         (success, output) = protocol.call{value: value}(data);
    477 |         if (success) ERC1155(token).safeTransferFrom(address(this), map(recipient), id, amount, new bytes(0));
    478 |     }
    479 | 
```

---

### 15. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 513 行
- **函数**: `collectRewards()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    510 | 
    511 |     /// @inheritdoc IRewardsCollector
    512 |     function collectRewards(bytes calldata looksRareClaim) external {
>>  513 |         (bool success,) = LOOKS_RARE_REWARDS_DISTRIBUTOR.call(looksRareClaim);
    514 |         if (!success) revert UnableToClaim();
    515 | 
    516 |         uint256 balance = LOOKS_RARE_TOKEN.balanceOf(address(this));
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 31 行
- **函数**: `execute()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     28 |     }
     29 | 
     30 |     /// @inheritdoc Dispatcher
>>   31 |     function execute(bytes calldata commands, bytes[] calldata inputs) public payable override isNotLocked {
     32 |         bool success;
     33 |         bytes memory output;
     34 |         uint256 numCommands = commands.length;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 428 行
- **函数**: `execute()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    425 |     /// @notice Executes encoded commands along with provided inputs.
    426 |     /// @param commands A set of concatenated commands, each 1 byte in length
    427 |     /// @param inputs An array of byte strings containing abi encoded inputs for each command
>>  428 |     function execute(bytes calldata commands, bytes[] calldata inputs) external payable virtual;
    429 | 
    430 |     /// @notice Performs a call to purchase an ERC721, then transfers the ERC721 to a specified recipient
    431 |     /// @param inputs The inputs for the protocol and ERC721 transfer, encoded
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 512 行
- **函数**: `collectRewards()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    509 |     error UnableToClaim();
    510 | 
    511 |     /// @inheritdoc IRewardsCollector
>>  512 |     function collectRewards(bytes calldata looksRareClaim) external {
    513 |         (bool success,) = LOOKS_RARE_REWARDS_DISTRIBUTOR.call(looksRareClaim);
    514 |         if (!success) revert UnableToClaim();
    515 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 752 行
- **函数**: `execute()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    749 |     /// @param commands A set of concatenated commands, each 1 byte in length
    750 |     /// @param inputs An array of byte strings containing abi encoded inputs for each command
    751 |     /// @param deadline The deadline by which the transaction must be executed
>>  752 |     function execute(bytes calldata commands, bytes[] calldata inputs, uint256 deadline) external payable;
    753 | }
    754 | 
    755 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 898 行
- **函数**: `uniswapV3SwapCallback()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    895 |     /// @dev The maximum value that can be returned from #getSqrtRatioAtTick. Equivalent to getSqrtRatioAtTick(MAX_TICK)
    896 |     uint160 internal constant MAX_SQRT_RATIO = 1461446703485210103287273052203988822378723970342;
    897 | 
>>  898 |     function uniswapV3SwapCallback(int256 amount0Delta, int256 amount1Delta, bytes calldata data) external {
    899 |         if (amount0Delta <= 0 && amount1Delta <= 0) revert V3InvalidSwap(); // swaps entirely within 0-liquidity regions are not supported
    900 |         (, address payer) = abi.decode(data, (bytes, address));
    901 |         bytes calldata path = data.toBytes(0);
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1293 行
- **函数**: `onERC721Received()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1290 | /// @notice Implements various functions introduced by a variety of ERCs for security reasons.
   1291 | /// All are called by external contracts to ensure that this contract safely supports the ERC in question.
   1292 | contract Callbacks is IERC721Receiver, IERC1155Receiver {
>> 1293 |     function onERC721Received(address, address, uint256, bytes calldata) external pure returns (bytes4) {
   1294 |         return this.onERC721Received.selector;
   1295 |     }
   1296 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1297 行
- **函数**: `onERC1155Received()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1294 |         return this.onERC721Received.selector;
   1295 |     }
   1296 | 
>> 1297 |     function onERC1155Received(address, address, uint256, uint256, bytes calldata) external pure returns (bytes4) {
   1298 |         return this.onERC1155Received.selector;
   1299 |     }
   1300 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1309 行
- **函数**: `supportsInterface()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1306 |         return this.onERC1155BatchReceived.selector;
   1307 |     }
   1308 | 
>> 1309 |     function supportsInterface(bytes4 interfaceId) external pure returns (bool) {
   1310 |         return interfaceId == type(IERC1155Receiver).interfaceId || interfaceId == type(IERC721Receiver).interfaceId
   1311 |             || interfaceId == type(IERC165).interfaceId;
   1312 |     }
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1381 行
- **函数**: `tokenURI()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1378 | 
   1379 |     string public symbol;
   1380 | 
>> 1381 |     function tokenURI(uint256 id) public view virtual returns (string memory);
   1382 | 
   1383 |     /*//////////////////////////////////////////////////////////////
   1384 |                       ERC721 BALANCE/OWNER STORAGE
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1391 行
- **函数**: `ownerOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1388 | 
   1389 |     mapping(address => uint256) internal _balanceOf;
   1390 | 
>> 1391 |     function ownerOf(uint256 id) public view virtual returns (address owner) {
   1392 |         require((owner = _ownerOf[id]) != address(0), "NOT_MINTED");
   1393 |     }
   1394 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1395 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1392 |         require((owner = _ownerOf[id]) != address(0), "NOT_MINTED");
   1393 |     }
   1394 | 
>> 1395 |     function balanceOf(address owner) public view virtual returns (uint256) {
   1396 |         require(owner != address(0), "ZERO_ADDRESS");
   1397 | 
   1398 |         return _balanceOf[owner];
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1422 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1419 |                               ERC721 LOGIC
   1420 |     //////////////////////////////////////////////////////////////*/
   1421 | 
>> 1422 |     function approve(address spender, uint256 id) public virtual {
   1423 |         address owner = _ownerOf[id];
   1424 | 
   1425 |         require(msg.sender == owner || isApprovedForAll[owner][msg.sender], "NOT_AUTHORIZED");
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1432 行
- **函数**: `setApprovalForAll()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1429 |         emit Approval(owner, spender, id);
   1430 |     }
   1431 | 
>> 1432 |     function setApprovalForAll(address operator, bool approved) public virtual {
   1433 |         isApprovedForAll[msg.sender][operator] = approved;
   1434 | 
   1435 |         emit ApprovalForAll(msg.sender, operator, approved);
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1502 行
- **函数**: `supportsInterface()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1499 |                               ERC165 LOGIC
   1500 |     //////////////////////////////////////////////////////////////*/
   1501 | 
>> 1502 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   1503 |         return
   1504 |             interfaceId == 0x01ffc9a7 || // ERC165 Interface ID for ERC165
   1505 |             interfaceId == 0x80ac58cd || // ERC165 Interface ID for ERC721
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1634 行
- **函数**: `uri()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1631 |                              METADATA LOGIC
   1632 |     //////////////////////////////////////////////////////////////*/
   1633 | 
>> 1634 |     function uri(uint256 id) public view virtual returns (string memory);
   1635 | 
   1636 |     /*//////////////////////////////////////////////////////////////
   1637 |                               ERC1155 LOGIC
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1640 行
- **函数**: `setApprovalForAll()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1637 |                               ERC1155 LOGIC
   1638 |     //////////////////////////////////////////////////////////////*/
   1639 | 
>> 1640 |     function setApprovalForAll(address operator, bool approved) public virtual {
   1641 |         isApprovedForAll[msg.sender][operator] = approved;
   1642 | 
   1643 |         emit ApprovalForAll(msg.sender, operator, approved);
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1732 行
- **函数**: `supportsInterface()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1729 |                               ERC165 LOGIC
   1730 |     //////////////////////////////////////////////////////////////*/
   1731 | 
>> 1732 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   1733 |         return
   1734 |             interfaceId == 0x01ffc9a7 || // ERC165 Interface ID for ERC165
   1735 |             interfaceId == 0xd9b67a26 || // ERC165 Interface ID for ERC1155
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1920 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1917 |                                ERC20 LOGIC
   1918 |     //////////////////////////////////////////////////////////////*/
   1919 | 
>> 1920 |     function approve(address spender, uint256 amount) public virtual returns (bool) {
   1921 |         allowance[msg.sender][spender] = amount;
   1922 | 
   1923 |         emit Approval(msg.sender, spender, amount);
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1928 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1925 |         return true;
   1926 |     }
   1927 | 
>> 1928 |     function transfer(address to, uint256 amount) public virtual returns (bool) {
   1929 |         balanceOf[msg.sender] -= amount;
   1930 | 
   1931 |         // Cannot overflow because the sum of all user
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2014 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2011 |         emit Approval(owner, spender, value);
   2012 |     }
   2013 | 
>> 2014 |     function DOMAIN_SEPARATOR() public view virtual returns (bytes32) {
   2015 |         return block.chainid == INITIAL_CHAIN_ID ? INITIAL_DOMAIN_SEPARATOR : computeDomainSeparator();
   2016 |     }
   2017 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2171 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2168 |     /// @notice A mapping from owner address to token address to spender address to PackedAllowance struct, which contains details and conditions of the approval.
   2169 |     /// @notice The mapping is indexed in the above order see: allowance[ownerAddress][tokenAddress][spenderAddress]
   2170 |     /// @dev The packed slot holds the allowed amount, expiration at which the allowed amount is no longer valid, and current nonce thats updated on any signature based approvals.
>> 2171 |     function allowance(address, address, address) external view returns (uint160, uint48, uint48);
   2172 | 
   2173 |     /// @notice Approves the spender to use up to amount of the specified token up until the expiration
   2174 |     /// @param token The token to approve
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2233 行
- **函数**: `buyPunk()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2230 | /// @title Interface for CryptoPunksMarket
   2231 | interface ICryptoPunksMarket {
   2232 |     /// @notice Buy a cryptopunk
>> 2233 |     function buyPunk(uint256 punkIndex) external payable;
   2234 | 
   2235 |     /// @notice Transfer a cryptopunk to another address
   2236 |     function transferPunk(address to, uint256 punkIndex) external;
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2399 行
- **函数**: `deposit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2396 | /// @title Interface for WETH9
   2397 | interface IWETH9 is IERC20 {
   2398 |     /// @notice Deposit ether to get wrapped ether
>> 2399 |     function deposit() external payable;
   2400 | 
   2401 |     /// @notice Withdraw wrapped ether to get ether
   2402 |     function withdraw(uint256) external;
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2507 行
- **函数**: `name()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2504 |     event Approval(address indexed owner, address indexed spender, uint value);
   2505 |     event Transfer(address indexed from, address indexed to, uint value);
   2506 | 
>> 2507 |     function name() external pure returns (string memory);
   2508 |     function symbol() external pure returns (string memory);
   2509 |     function decimals() external pure returns (uint8);
   2510 |     function totalSupply() external view returns (uint);
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2508 行
- **函数**: `symbol()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2505 |     event Transfer(address indexed from, address indexed to, uint value);
   2506 | 
   2507 |     function name() external pure returns (string memory);
>> 2508 |     function symbol() external pure returns (string memory);
   2509 |     function decimals() external pure returns (uint8);
   2510 |     function totalSupply() external view returns (uint);
   2511 |     function balanceOf(address owner) external view returns (uint);
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2509 行
- **函数**: `decimals()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2506 | 
   2507 |     function name() external pure returns (string memory);
   2508 |     function symbol() external pure returns (string memory);
>> 2509 |     function decimals() external pure returns (uint8);
   2510 |     function totalSupply() external view returns (uint);
   2511 |     function balanceOf(address owner) external view returns (uint);
   2512 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2510 行
- **函数**: `totalSupply()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2507 |     function name() external pure returns (string memory);
   2508 |     function symbol() external pure returns (string memory);
   2509 |     function decimals() external pure returns (uint8);
>> 2510 |     function totalSupply() external view returns (uint);
   2511 |     function balanceOf(address owner) external view returns (uint);
   2512 |     function allowance(address owner, address spender) external view returns (uint);
   2513 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2511 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2508 |     function symbol() external pure returns (string memory);
   2509 |     function decimals() external pure returns (uint8);
   2510 |     function totalSupply() external view returns (uint);
>> 2511 |     function balanceOf(address owner) external view returns (uint);
   2512 |     function allowance(address owner, address spender) external view returns (uint);
   2513 | 
   2514 |     function approve(address spender, uint value) external returns (bool);
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2512 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2509 |     function decimals() external pure returns (uint8);
   2510 |     function totalSupply() external view returns (uint);
   2511 |     function balanceOf(address owner) external view returns (uint);
>> 2512 |     function allowance(address owner, address spender) external view returns (uint);
   2513 | 
   2514 |     function approve(address spender, uint value) external returns (bool);
   2515 |     function transfer(address to, uint value) external returns (bool);
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2514 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2511 |     function balanceOf(address owner) external view returns (uint);
   2512 |     function allowance(address owner, address spender) external view returns (uint);
   2513 | 
>> 2514 |     function approve(address spender, uint value) external returns (bool);
   2515 |     function transfer(address to, uint value) external returns (bool);
   2516 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2517 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2515 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2512 |     function allowance(address owner, address spender) external view returns (uint);
   2513 | 
   2514 |     function approve(address spender, uint value) external returns (bool);
>> 2515 |     function transfer(address to, uint value) external returns (bool);
   2516 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2517 | 
   2518 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2516 行
- **函数**: `transferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2513 | 
   2514 |     function approve(address spender, uint value) external returns (bool);
   2515 |     function transfer(address to, uint value) external returns (bool);
>> 2516 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2517 | 
   2518 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2519 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2518 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2515 |     function transfer(address to, uint value) external returns (bool);
   2516 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2517 | 
>> 2518 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2519 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   2520 |     function nonces(address owner) external view returns (uint);
   2521 | 
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2519 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2516 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2517 | 
   2518 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>> 2519 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   2520 |     function nonces(address owner) external view returns (uint);
   2521 | 
   2522 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2520 行
- **函数**: `nonces()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2517 | 
   2518 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2519 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>> 2520 |     function nonces(address owner) external view returns (uint);
   2521 | 
   2522 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
   2523 | 
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2536 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2533 |     );
   2534 |     event Sync(uint112 reserve0, uint112 reserve1);
   2535 | 
>> 2536 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   2537 |     function factory() external view returns (address);
   2538 |     function token0() external view returns (address);
   2539 |     function token1() external view returns (address);
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2537 行
- **函数**: `factory()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2534 |     event Sync(uint112 reserve0, uint112 reserve1);
   2535 | 
   2536 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
>> 2537 |     function factory() external view returns (address);
   2538 |     function token0() external view returns (address);
   2539 |     function token1() external view returns (address);
   2540 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2538 行
- **函数**: `token0()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2535 | 
   2536 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   2537 |     function factory() external view returns (address);
>> 2538 |     function token0() external view returns (address);
   2539 |     function token1() external view returns (address);
   2540 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2541 |     function price0CumulativeLast() external view returns (uint);
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2539 行
- **函数**: `token1()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2536 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   2537 |     function factory() external view returns (address);
   2538 |     function token0() external view returns (address);
>> 2539 |     function token1() external view returns (address);
   2540 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2541 |     function price0CumulativeLast() external view returns (uint);
   2542 |     function price1CumulativeLast() external view returns (uint);
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2540 行
- **函数**: `getReserves()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2537 |     function factory() external view returns (address);
   2538 |     function token0() external view returns (address);
   2539 |     function token1() external view returns (address);
>> 2540 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2541 |     function price0CumulativeLast() external view returns (uint);
   2542 |     function price1CumulativeLast() external view returns (uint);
   2543 |     function kLast() external view returns (uint);
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2541 行
- **函数**: `price0CumulativeLast()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2538 |     function token0() external view returns (address);
   2539 |     function token1() external view returns (address);
   2540 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>> 2541 |     function price0CumulativeLast() external view returns (uint);
   2542 |     function price1CumulativeLast() external view returns (uint);
   2543 |     function kLast() external view returns (uint);
   2544 | 
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2542 行
- **函数**: `price1CumulativeLast()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2539 |     function token1() external view returns (address);
   2540 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2541 |     function price0CumulativeLast() external view returns (uint);
>> 2542 |     function price1CumulativeLast() external view returns (uint);
   2543 |     function kLast() external view returns (uint);
   2544 | 
   2545 |     function mint(address to) external returns (uint liquidity);
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2543 行
- **函数**: `kLast()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2540 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2541 |     function price0CumulativeLast() external view returns (uint);
   2542 |     function price1CumulativeLast() external view returns (uint);
>> 2543 |     function kLast() external view returns (uint);
   2544 | 
   2545 |     function mint(address to) external returns (uint liquidity);
   2546 |     function burn(address to) external returns (uint amount0, uint amount1);
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2545 行
- **函数**: `mint()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2542 |     function price1CumulativeLast() external view returns (uint);
   2543 |     function kLast() external view returns (uint);
   2544 | 
>> 2545 |     function mint(address to) external returns (uint liquidity);
   2546 |     function burn(address to) external returns (uint amount0, uint amount1);
   2547 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
   2548 |     function skim(address to) external;
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2546 行
- **函数**: `burn()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2543 |     function kLast() external view returns (uint);
   2544 | 
   2545 |     function mint(address to) external returns (uint liquidity);
>> 2546 |     function burn(address to) external returns (uint amount0, uint amount1);
   2547 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
   2548 |     function skim(address to) external;
   2549 |     function sync() external;
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2959 行
- **函数**: `supportsInterface()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2956 |      *
   2957 |      * This function call must use less than 30 000 gas.
   2958 |      */
>> 2959 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   2960 | }
   2961 | 
   2962 | 
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2991 行
- **函数**: `totalSupply()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2988 |     /**
   2989 |      * @dev Returns the amount of tokens in existence.
   2990 |      */
>> 2991 |     function totalSupply() external view returns (uint256);
   2992 | 
   2993 |     /**
   2994 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2996 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2993 |     /**
   2994 |      * @dev Returns the amount of tokens owned by `account`.
   2995 |      */
>> 2996 |     function balanceOf(address account) external view returns (uint256);
   2997 | 
   2998 |     /**
   2999 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3005 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3002 |      *
   3003 |      * Emits a {Transfer} event.
   3004 |      */
>> 3005 |     function transfer(address to, uint256 amount) external returns (bool);
   3006 | 
   3007 |     /**
   3008 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3014 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3011 |      *
   3012 |      * This value changes when {approve} or {transferFrom} are called.
   3013 |      */
>> 3014 |     function allowance(address owner, address spender) external view returns (uint256);
   3015 | 
   3016 |     /**
   3017 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3030 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3027 |      *
   3028 |      * Emits an {Approval} event.
   3029 |      */
>> 3030 |     function approve(address spender, uint256 amount) external returns (bool);
   3031 | 
   3032 |     /**
   3033 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3077 行
- **函数**: `factory()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3074 | interface IUniswapV3PoolImmutables {
   3075 |     /// @notice The contract that deployed the pool, which must adhere to the IUniswapV3Factory interface
   3076 |     /// @return The contract address
>> 3077 |     function factory() external view returns (address);
   3078 | 
   3079 |     /// @notice The first of the two tokens of the pool, sorted by address
   3080 |     /// @return The token contract address
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3081 行
- **函数**: `token0()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3078 | 
   3079 |     /// @notice The first of the two tokens of the pool, sorted by address
   3080 |     /// @return The token contract address
>> 3081 |     function token0() external view returns (address);
   3082 | 
   3083 |     /// @notice The second of the two tokens of the pool, sorted by address
   3084 |     /// @return The token contract address
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3085 行
- **函数**: `token1()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3082 | 
   3083 |     /// @notice The second of the two tokens of the pool, sorted by address
   3084 |     /// @return The token contract address
>> 3085 |     function token1() external view returns (address);
   3086 | 
   3087 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   3088 |     /// @return The fee
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3089 行
- **函数**: `fee()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3086 | 
   3087 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   3088 |     /// @return The fee
>> 3089 |     function fee() external view returns (uint24);
   3090 | 
   3091 |     /// @notice The pool tick spacing
   3092 |     /// @dev Ticks can only be used at multiples of this value, minimum of 1 and always positive
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3096 行
- **函数**: `tickSpacing()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3093 |     /// e.g.: a tickSpacing of 3 means ticks can be initialized every 3rd tick, i.e., ..., -6, -3, 0, 3, 6, ...
   3094 |     /// This value is an int24 to avoid casting even though it is always positive.
   3095 |     /// @return The tick spacing
>> 3096 |     function tickSpacing() external view returns (int24);
   3097 | 
   3098 |     /// @notice The maximum amount of position liquidity that can use any tick in the range
   3099 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3102 行
- **函数**: `maxLiquidityPerTick()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3099 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
   3100 |     /// also prevents out-of-range liquidity from being used to prevent adding in-range liquidity to a pool
   3101 |     /// @return The max amount of liquidity per tick
>> 3102 |     function maxLiquidityPerTick() external view returns (uint128);
   3103 | }
   3104 | 
   3105 | 
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3143 行
- **函数**: `feeGrowthGlobal0X128()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3140 | 
   3141 |     /// @notice The fee growth as a Q128.128 fees of token0 collected per unit of liquidity for the entire life of the pool
   3142 |     /// @dev This value can overflow the uint256
>> 3143 |     function feeGrowthGlobal0X128() external view returns (uint256);
   3144 | 
   3145 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   3146 |     /// @dev This value can overflow the uint256
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3147 行
- **函数**: `feeGrowthGlobal1X128()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3144 | 
   3145 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   3146 |     /// @dev This value can overflow the uint256
>> 3147 |     function feeGrowthGlobal1X128() external view returns (uint256);
   3148 | 
   3149 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   3150 |     /// @dev Protocol fees will never exceed uint128 max in either token
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3151 行
- **函数**: `protocolFees()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3148 | 
   3149 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   3150 |     /// @dev Protocol fees will never exceed uint128 max in either token
>> 3151 |     function protocolFees() external view returns (uint128 token0, uint128 token1);
   3152 | 
   3153 |     /// @notice The currently in range liquidity available to the pool
   3154 |     /// @dev This value has no relationship to the total liquidity across all ticks
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3155 行
- **函数**: `liquidity()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3152 | 
   3153 |     /// @notice The currently in range liquidity available to the pool
   3154 |     /// @dev This value has no relationship to the total liquidity across all ticks
>> 3155 |     function liquidity() external view returns (uint128);
   3156 | 
   3157 |     /// @notice Look up information about a specific tick in the pool
   3158 |     /// @param tick The tick to look up
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3186 行
- **函数**: `tickBitmap()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3183 |         );
   3184 | 
   3185 |     /// @notice Returns 256 packed tick initialized boolean values. See TickBitmap for more information
>> 3186 |     function tickBitmap(int16 wordPosition) external view returns (uint256);
   3187 | 
   3188 |     /// @notice Returns the information about a position by the position's key
   3189 |     /// @param key The position's key is a hash of a preimage composed by the owner, tickLower and tickUpper
```

---

### 78. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 84 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     79 | import {ERC20} from 'solmate/src/tokens/ERC20.sol';
     80 | import {IAllowanceTransfer} from 'permit2/src/interfaces/IAllowanceTransfer.sol';
     81 | import {ICryptoPunksMarket} from '../interfaces/external/ICryptoPunksMarket.sol';
     82 | 
     83 | /// @title Decodes and Executes Commands
>>   84 | /// @notice Called by the UniversalRouter contract to efficiently decode and execute a singular command
     85 | abstract contract Dispatcher is Payments, V2SwapRouter, V3SwapRouter, Callbacks, LockAndMsgSender {
     86 |     using BytesLib for bytes;
     87 | 
     88 |     error InvalidCommandType(uint256 commandType);
     89 |     error BuyPunkFailed();
```

---

### 79. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 504 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    499 | import {ERC20} from 'solmate/src/tokens/ERC20.sol';
    500 | import {SafeTransferLib} from 'solmate/src/utils/SafeTransferLib.sol';
    501 | import {RouterImmutables} from './RouterImmutables.sol';
    502 | import {IRewardsCollector} from '../interfaces/IRewardsCollector.sol';
    503 | 
>>  504 | abstract contract RewardsCollector is IRewardsCollector, RouterImmutables {
    505 |     using SafeTransferLib for ERC20;
    506 | 
    507 |     event RewardsSent(uint256 amount);
    508 | 
    509 |     error UnableToClaim();
```

---

### 80. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 557 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    552 |     bytes32 poolInitCodeHash;
    553 | }
    554 | 
    555 | /// @title Router Immutable Storage contract
    556 | /// @notice Used along with the `RouterParameters` struct for ease of cross-chain deployment
>>  557 | contract RouterImmutables {
    558 |     /// @dev WETH9 address
    559 |     IWETH9 internal immutable WETH9;
    560 | 
    561 |     /// @dev Permit2 address
    562 |     IAllowanceTransfer internal immutable PERMIT2;
```

---

### 81. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 770 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    765 | import {Permit2Payments} from '../../Permit2Payments.sol';
    766 | import {Constants} from '../../../libraries/Constants.sol';
    767 | import {ERC20} from 'solmate/src/tokens/ERC20.sol';
    768 | 
    769 | /// @title Router for Uniswap v2 Trades
>>  770 | abstract contract V2SwapRouter is RouterImmutables, Permit2Payments {
    771 |     error V2TooLittleReceived();
    772 |     error V2TooMuchRequested();
    773 |     error V2InvalidPath();
    774 | 
    775 |     function _v2Swap(address[] calldata path, address recipient, address pair) private {
```

---

### 82. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 874 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    869 | import {Permit2Payments} from '../../Permit2Payments.sol';
    870 | import {Constants} from '../../../libraries/Constants.sol';
    871 | import {ERC20} from 'solmate/src/tokens/ERC20.sol';
    872 | 
    873 | /// @title Router for Uniswap v3 Trades
>>  874 | abstract contract V3SwapRouter is RouterImmutables, Permit2Payments, IUniswapV3SwapCallback {
    875 |     using V3Path for bytes;
    876 |     using BytesLib for bytes;
    877 |     using SafeCast for uint256;
    878 | 
    879 |     error V3InvalidSwap();
```

---

### 83. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 941 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    936 |         uint256 amountIn,
    937 |         uint256 amountOutMinimum,
    938 |         bytes calldata path,
    939 |         address payer
    940 |     ) internal {
>>  941 |         // use amountIn == Constants.CONTRACT_BALANCE as a flag to swap the entire balance of the contract
    942 |         if (amountIn == Constants.CONTRACT_BALANCE) {
    943 |             address tokenIn = path.decodeFirstToken();
    944 |             amountIn = ERC20(tokenIn).balanceOf(address(this));
    945 |         }
    946 | 
```

---

### 84. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1150 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1145 | import {ERC721} from 'solmate/src/tokens/ERC721.sol';
   1146 | import {ERC1155} from 'solmate/src/tokens/ERC1155.sol';
   1147 | 
   1148 | /// @title Payments contract
   1149 | /// @notice Performs various operations around the payment of ETH and tokens
>> 1150 | abstract contract Payments is RouterImmutables {
   1151 |     using SafeTransferLib for ERC20;
   1152 |     using SafeTransferLib for address;
   1153 | 
   1154 |     error InsufficientToken();
   1155 |     error InsufficientETH();
```

---

### 85. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1291 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1286 | import {IERC1155Receiver} from '@openzeppelin/contracts/token/ERC1155/IERC1155Receiver.sol';
   1287 | import {IERC165} from '@openzeppelin/contracts/utils/introspection/IERC165.sol';
   1288 | 
   1289 | /// @title ERC Callback Support
   1290 | /// @notice Implements various functions introduced by a variety of ERCs for security reasons.
>> 1291 | /// All are called by external contracts to ensure that this contract safely supports the ERC in question.
   1292 | contract Callbacks is IERC721Receiver, IERC1155Receiver {
   1293 |     function onERC721Received(address, address, uint256, bytes calldata) external pure returns (bytes4) {
   1294 |         return this.onERC721Received.selector;
   1295 |     }
   1296 | 
```

---

### 86. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1323 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1318 | // SPDX-License-Identifier: GPL-3.0-or-later
   1319 | pragma solidity ^0.8.17;
   1320 | 
   1321 | import {Constants} from '../libraries/Constants.sol';
   1322 | 
>> 1323 | contract LockAndMsgSender {
   1324 |     error ContractLocked();
   1325 | 
   1326 |     address internal constant NOT_LOCKED_FLAG = address(1);
   1327 |     address internal lockedBy = NOT_LOCKED_FLAG;
   1328 | 
```

---

### 87. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1362 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1357 | // SPDX-License-Identifier: AGPL-3.0-only
   1358 | pragma solidity >=0.8.0;
   1359 | 
   1360 | /// @notice Modern, minimalist, and gas efficient ERC-721 implementation.
   1361 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC721.sol)
>> 1362 | abstract contract ERC721 {
   1363 |     /*//////////////////////////////////////////////////////////////
   1364 |                                  EVENTS
   1365 |     //////////////////////////////////////////////////////////////*/
   1366 | 
   1367 |     event Transfer(address indexed from, address indexed to, uint256 indexed id);
```

---

### 88. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1576 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1571 |             "UNSAFE_RECIPIENT"
   1572 |         );
   1573 |     }
   1574 | }
   1575 | 
>> 1576 | /// @notice A generic interface for a contract which properly accepts ERC721 tokens.
   1577 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC721.sol)
   1578 | abstract contract ERC721TokenReceiver {
   1579 |     function onERC721Received(
   1580 |         address,
   1581 |         address,
```

---

### 89. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1597 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1592 | // SPDX-License-Identifier: AGPL-3.0-only
   1593 | pragma solidity >=0.8.0;
   1594 | 
   1595 | /// @notice Minimalist and gas efficient standard ERC1155 implementation.
   1596 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC1155.sol)
>> 1597 | abstract contract ERC1155 {
   1598 |     /*//////////////////////////////////////////////////////////////
   1599 |                                  EVENTS
   1600 |     //////////////////////////////////////////////////////////////*/
   1601 | 
   1602 |     event TransferSingle(
```

---

### 90. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1826 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1821 | 
   1822 |         emit TransferSingle(msg.sender, from, address(0), id, amount);
   1823 |     }
   1824 | }
   1825 | 
>> 1826 | /// @notice A generic interface for a contract which properly accepts ERC1155 tokens.
   1827 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC1155.sol)
   1828 | abstract contract ERC1155TokenReceiver {
   1829 |     function onERC1155Received(
   1830 |         address,
   1831 |         address,
```

---

### 91. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1860 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1855 | 
   1856 | /// @notice Modern and gas efficient ERC20 + EIP-2612 implementation.
   1857 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC20.sol)
   1858 | /// @author Modified from Uniswap (https://github.com/Uniswap/uniswap-v2-core/blob/master/contracts/UniswapV2ERC20.sol)
   1859 | /// @dev Do not manually set balances without updating totalSupply, as the sum of all user balances must not exceed it.
>> 1860 | abstract contract ERC20 {
   1861 |     /*//////////////////////////////////////////////////////////////
   1862 |                                  EVENTS
   1863 |     //////////////////////////////////////////////////////////////*/
   1864 | 
   1865 |     event Transfer(address indexed from, address indexed to, uint256 amount);
```

---

### 92. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2068 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2063 | // SPDX-License-Identifier: MIT
   2064 | pragma solidity ^0.8.17;
   2065 | 
   2066 | /// @title AllowanceTransfer
   2067 | /// @notice Handles ERC20 token permissions through signature based allowance setting and ERC20 token transfers by checking allowed amounts
>> 2068 | /// @dev Requires user's token approval on the Permit2 contract
   2069 | interface IAllowanceTransfer {
   2070 |     /// @notice Thrown when an allowance on a token has expired.
   2071 |     /// @param deadline The timestamp at which the allowed amount is no longer valid
   2072 |     error AllowanceExpired(uint256 deadline);
   2073 | 
```

---

### 93. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2381 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2376 | 
   2377 | import {ERC20} from 'solmate/src/tokens/ERC20.sol';
   2378 | 
   2379 | /// @title LooksRare Rewards Collector
   2380 | /// @notice Implements a permissionless call to fetch LooksRare rewards earned by Universal Router users
>> 2381 | /// and transfers them to an external rewards distributor contract
   2382 | interface IRewardsCollector {
   2383 |     /// @notice Fetches users' LooksRare rewards and sends them to the distributor contract
   2384 |     /// @param looksRareClaim The data required by LooksRare to claim reward tokens
   2385 |     function collectRewards(bytes calldata looksRareClaim) external;
   2386 | }
```

---

### 94. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2720 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2715 | import {Constants} from '../libraries/Constants.sol';
   2716 | import {RouterImmutables} from '../base/RouterImmutables.sol';
   2717 | 
   2718 | /// @title Payments through Permit2
   2719 | /// @notice Performs interactions with Permit2 to transfer tokens
>> 2720 | abstract contract Permit2Payments is Payments {
   2721 |     using SafeCast160 for uint256;
   2722 | 
   2723 |     error FromAddressIsNotOwner();
   2724 | 
   2725 |     /// @notice Performs a transferFrom on Permit2
```

---

### 95. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2915 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2910 | 
   2911 | // SPDX-License-Identifier: GPL-2.0-or-later
   2912 | pragma solidity >=0.5.0;
   2913 | 
   2914 | /// @title Callback for IUniswapV3PoolActions#swap
>> 2915 | /// @notice Any contract that calls IUniswapV3PoolActions#swap must implement this interface
   2916 | interface IUniswapV3SwapCallback {
   2917 |     /// @notice Called to `msg.sender` after executing a swap via IUniswapV3Pool#swap.
   2918 |     /// @dev In the implementation you must pay the pool tokens owed for the swap.
   2919 |     /// The caller of this method must be checked to be a UniswapV3Pool deployed by the canonical UniswapV3Factory.
   2920 |     /// amount0Delta and amount1Delta can both be 0 if no tokens were swapped.
```

---

### 96. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2952 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2947 |  *
   2948 |  * For an implementation, see {ERC165}.
   2949 |  */
   2950 | interface IERC165 {
   2951 |     /**
>> 2952 |      * @dev Returns true if this contract implements the interface defined by
   2953 |      * `interfaceId`. See the corresponding
   2954 |      * https://eips.ethereum.org/EIPS/eip-165#how-interfaces-are-identified[EIP section]
   2955 |      * to learn more about how these ids are created.
   2956 |      *
   2957 |      * This function call must use less than 30 000 gas.
```

---

### 97. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 3075 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3070 | pragma solidity >=0.5.0;
   3071 | 
   3072 | /// @title Pool state that never changes
   3073 | /// @notice These parameters are fixed for a pool forever, i.e., the methods will always return the same values
   3074 | interface IUniswapV3PoolImmutables {
>> 3075 |     /// @notice The contract that deployed the pool, which must adhere to the IUniswapV3Factory interface
   3076 |     /// @return The contract address
   3077 |     function factory() external view returns (address);
   3078 | 
   3079 |     /// @notice The first of the two tokens of the pool, sorted by address
   3080 |     /// @return The token contract address
```

---

### 98. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 15 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     12 | 
     13 | contract UniversalRouter is RouterImmutables, IUniversalRouter, Dispatcher, RewardsCollector {
     14 |     modifier checkDeadline(uint256 deadline) {
>>   15 |         if (block.timestamp > deadline) revert TransactionDeadlinePassed();
     16 |         _;
     17 |     }
     18 | 
```

---

### 99. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1977 行
- **函数**: `permit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1974 |         bytes32 r,
   1975 |         bytes32 s
   1976 |     ) public virtual {
>> 1977 |         require(deadline >= block.timestamp, "PERMIT_DEADLINE_EXPIRED");
   1978 | 
   1979 |         // Unchecked because the only math done is incrementing
   1980 |         // the owner's nonce which cannot realistically overflow.
```

---

### 100. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 517 行
- **函数**: `collectRewards()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    514 |         if (!success) revert UnableToClaim();
    515 | 
    516 |         uint256 balance = LOOKS_RARE_TOKEN.balanceOf(address(this));
>>  517 |         LOOKS_RARE_TOKEN.transfer(ROUTER_REWARDS_DISTRIBUTOR, balance);
    518 |         emit RewardsSent(balance);
    519 |     }
    520 | }
```

---

### 101. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1257 行
- **函数**: `wrapETH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1254 |         if (amount > 0) {
   1255 |             WETH9.deposit{value: amount}();
   1256 |             if (recipient != address(this)) {
>> 1257 |                 WETH9.transfer(recipient, amount);
   1258 |             }
   1259 |         }
   1260 |     }
```

---

### 102. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2286 行
- **函数**: `safeTransferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2283 |             let freeMemoryPointer := mload(0x40)
   2284 | 
   2285 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 2286 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   2287 |             mstore(add(freeMemoryPointer, 4), from) // Append the "from" argument.
   2288 |             mstore(add(freeMemoryPointer, 36), to) // Append the "to" argument.
   2289 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument.
```

---

### 103. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2319 行
- **函数**: `safeTransfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2316 |             let freeMemoryPointer := mload(0x40)
   2317 | 
   2318 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 2319 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   2320 |             mstore(add(freeMemoryPointer, 4), to) // Append the "to" argument.
   2321 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument.
   2322 | 
```

---

### 104. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2351 行
- **函数**: `safeApprove()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2348 |             let freeMemoryPointer := mload(0x40)
   2349 | 
   2350 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 2351 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
   2352 |             mstore(add(freeMemoryPointer, 4), to) // Append the "to" argument.
   2353 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument.
   2354 | 
```

---

### 105. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2770 行
- **函数**: `payOrPermit2Transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2767 | library Constants {
   2768 |     /// @dev Used for identifying cases when this contract's balance of a token is to be used as an input
   2769 |     /// This value is equivalent to 1<<255, i.e. a singular 1 in the most significant bit.
>> 2770 |     uint256 internal constant CONTRACT_BALANCE = 0x8000000000000000000000000000000000000000000000000000000000000000;
   2771 | 
   2772 |     /// @dev Used for identifying cases when a v2 pair has already received input tokens
   2773 |     uint256 internal constant ALREADY_PAID = 0;
```

---

### 106. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 115 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    112 |                         uint256 amountIn;
    113 |                         uint256 amountOutMin;
    114 |                         bool payerIsUser;
>>  115 |                         assembly {
    116 |                             recipient := calldataload(inputs.offset)
    117 |                             amountIn := calldataload(add(inputs.offset, 0x20))
    118 |                             amountOutMin := calldataload(add(inputs.offset, 0x40))
```

---

### 107. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 131 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    128 |                         uint256 amountOut;
    129 |                         uint256 amountInMax;
    130 |                         bool payerIsUser;
>>  131 |                         assembly {
    132 |                             recipient := calldataload(inputs.offset)
    133 |                             amountOut := calldataload(add(inputs.offset, 0x20))
    134 |                             amountInMax := calldataload(add(inputs.offset, 0x40))
```

---

### 108. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 146 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    143 |                         address token;
    144 |                         address recipient;
    145 |                         uint160 amount;
>>  146 |                         assembly {
    147 |                             token := calldataload(inputs.offset)
    148 |                             recipient := calldataload(add(inputs.offset, 0x20))
    149 |                             amount := calldataload(add(inputs.offset, 0x40))
```

---

### 109. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 162 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    159 |                         address token;
    160 |                         address recipient;
    161 |                         uint160 amountMin;
>>  162 |                         assembly {
    163 |                             token := calldataload(inputs.offset)
    164 |                             recipient := calldataload(add(inputs.offset, 0x20))
    165 |                             amountMin := calldataload(add(inputs.offset, 0x40))
```

---

### 110. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 173 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    170 |                         address token;
    171 |                         address recipient;
    172 |                         uint256 value;
>>  173 |                         assembly {
    174 |                             token := calldataload(inputs.offset)
    175 |                             recipient := calldataload(add(inputs.offset, 0x20))
    176 |                             value := calldataload(add(inputs.offset, 0x40))
```

---

### 111. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 184 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    181 |                         address token;
    182 |                         address recipient;
    183 |                         uint256 bips;
>>  184 |                         assembly {
    185 |                             token := calldataload(inputs.offset)
    186 |                             recipient := calldataload(add(inputs.offset, 0x20))
    187 |                             bips := calldataload(add(inputs.offset, 0x40))
```

---

### 112. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 202 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    199 |                         uint256 amountIn;
    200 |                         uint256 amountOutMin;
    201 |                         bool payerIsUser;
>>  202 |                         assembly {
    203 |                             recipient := calldataload(inputs.offset)
    204 |                             amountIn := calldataload(add(inputs.offset, 0x20))
    205 |                             amountOutMin := calldataload(add(inputs.offset, 0x40))
```

---

### 113. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 218 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    215 |                         uint256 amountOut;
    216 |                         uint256 amountInMax;
    217 |                         bool payerIsUser;
>>  218 |                         assembly {
    219 |                             recipient := calldataload(inputs.offset)
    220 |                             amountOut := calldataload(add(inputs.offset, 0x20))
    221 |                             amountInMax := calldataload(add(inputs.offset, 0x40))
```

---

### 114. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 231 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    228 |                     } else if (command == Commands.PERMIT2_PERMIT) {
    229 |                         // equivalent: abi.decode(inputs, (IAllowanceTransfer.PermitSingle, bytes))
    230 |                         IAllowanceTransfer.PermitSingle calldata permitSingle;
>>  231 |                         assembly {
    232 |                             permitSingle := inputs.offset
    233 |                         }
    234 |                         bytes calldata data = inputs.toBytes(6); // PermitSingle takes first 6 slots (0..5)
```

---

### 115. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 240 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    237 |                         // equivalent: abi.decode(inputs, (address, uint256))
    238 |                         address recipient;
    239 |                         uint256 amountMin;
>>  240 |                         assembly {
    241 |                             recipient := calldataload(inputs.offset)
    242 |                             amountMin := calldataload(add(inputs.offset, 0x20))
    243 |                         }
```

---

### 116. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 249 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    246 |                         // equivalent: abi.decode(inputs, (address, uint256))
    247 |                         address recipient;
    248 |                         uint256 amountMin;
>>  249 |                         assembly {
    250 |                             recipient := calldataload(inputs.offset)
    251 |                             amountMin := calldataload(add(inputs.offset, 0x20))
    252 |                         }
```

---

### 117. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 263 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    260 |                         address owner;
    261 |                         address token;
    262 |                         uint256 minBalance;
>>  263 |                         assembly {
    264 |                             owner := calldataload(inputs.offset)
    265 |                             token := calldataload(add(inputs.offset, 0x20))
    266 |                             minBalance := calldataload(add(inputs.offset, 0x40))
```

---

### 118. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 292 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    289 |                     } else if (command == Commands.LOOKS_RARE_V2) {
    290 |                         // equivalent: abi.decode(inputs, (uint256, bytes))
    291 |                         uint256 value;
>>  292 |                         assembly {
    293 |                             value := calldataload(inputs.offset)
    294 |                         }
    295 |                         bytes calldata data = inputs.toBytes(1);
```

---

### 119. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 306 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    303 |                         uint256 punkId;
    304 |                         address recipient;
    305 |                         uint256 value;
>>  306 |                         assembly {
    307 |                             punkId := calldataload(inputs.offset)
    308 |                             recipient := calldataload(add(inputs.offset, 0x20))
    309 |                             value := calldataload(add(inputs.offset, 0x40))
```

---

### 120. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 321 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    318 |                         address owner;
    319 |                         address token;
    320 |                         uint256 id;
>>  321 |                         assembly {
    322 |                             owner := calldataload(inputs.offset)
    323 |                             token := calldataload(add(inputs.offset, 0x20))
    324 |                             id := calldataload(add(inputs.offset, 0x40))
```

---

### 121. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 334 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    331 |                         address token;
    332 |                         uint256 id;
    333 |                         uint256 minBalance;
>>  334 |                         assembly {
    335 |                             owner := calldataload(inputs.offset)
    336 |                             token := calldataload(add(inputs.offset, 0x20))
    337 |                             id := calldataload(add(inputs.offset, 0x40))
```

---

### 122. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 347 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    344 |                         address token;
    345 |                         address recipient;
    346 |                         uint256 id;
>>  347 |                         assembly {
    348 |                             token := calldataload(inputs.offset)
    349 |                             recipient := calldataload(add(inputs.offset, 0x20))
    350 |                             id := calldataload(add(inputs.offset, 0x40))
```

---

### 123. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 376 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    373 |                         address recipient;
    374 |                         uint256 id;
    375 |                         uint256 amount;
>>  376 |                         assembly {
    377 |                             token := calldataload(inputs.offset)
    378 |                             recipient := calldataload(add(inputs.offset, 0x20))
    379 |                             id := calldataload(add(inputs.offset, 0x40))
```

---

### 124. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 413 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    410 |             } else if (command == Commands.APPROVE_ERC20) {
    411 |                 ERC20 token;
    412 |                 RouterImmutables.Spenders spender;
>>  413 |                 assembly {
    414 |                     token := calldataload(inputs.offset)
    415 |                     spender := calldataload(add(inputs.offset, 0x20))
    416 |                 }
```

---

### 125. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 444 行
- **函数**: `callAndTransfer721()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    441 |         address recipient;
    442 |         address token;
    443 |         uint256 id;
>>  444 |         assembly {
    445 |             // 0x00 and 0x20 offsets are value and data, above
    446 |             recipient := calldataload(add(inputs.offset, 0x40))
    447 |             token := calldataload(add(inputs.offset, 0x60))
```

---

### 126. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 469 行
- **函数**: `callAndTransfer1155()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    466 |         address token;
    467 |         uint256 id;
    468 |         uint256 amount;
>>  469 |         assembly {
    470 |             // 0x00 and 0x20 offsets are value and data, above
    471 |             recipient := calldataload(add(inputs.offset, 0x40))
    472 |             token := calldataload(add(inputs.offset, 0x60))
```

---

### 127. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 486 行
- **函数**: `getValueAndData()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    483 |     /// @return value The 256 bit integer value
    484 |     /// @return data The data bytes string
    485 |     function getValueAndData(bytes calldata inputs) internal pure returns (uint256 value, bytes calldata data) {
>>  486 |         assembly {
    487 |             value := calldataload(inputs.offset)
    488 |         }
    489 |         data = inputs.toBytes(1);
```

---

### 128. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1056 行
- **函数**: `toAddress()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1053 |     /// @return _address The address starting at byte 0
   1054 |     function toAddress(bytes calldata _bytes) internal pure returns (address _address) {
   1055 |         if (_bytes.length < Constants.ADDR_SIZE) revert SliceOutOfBounds();
>> 1056 |         assembly {
   1057 |             _address := shr(96, calldataload(_bytes.offset))
   1058 |         }
   1059 |     }
```

---

### 129. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1069 行
- **函数**: `toPool()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1066 |     /// @return token1 The address at byte 23
   1067 |     function toPool(bytes calldata _bytes) internal pure returns (address token0, uint24 fee, address token1) {
   1068 |         if (_bytes.length < Constants.V3_POP_OFFSET) revert SliceOutOfBounds();
>> 1069 |         assembly {
   1070 |             let firstWord := calldataload(_bytes.offset)
   1071 |             token0 := shr(96, firstWord)
   1072 |             fee := and(shr(72, firstWord), 0xffffff)
```

---

### 130. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1090 行
- **函数**: `toLengthOffset()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1087 |         returns (uint256 length, uint256 offset)
   1088 |     {
   1089 |         uint256 relativeOffset;
>> 1090 |         assembly {
   1091 |             // The offset of the `_arg`-th element is `32 * arg`, which stores the offset of the length pointer.
   1092 |             // shl(5, x) is equivalent to mul(32, x)
   1093 |             let lengthPtr := add(_bytes.offset, calldataload(add(_bytes.offset, shl(5, _arg))))
```

---

### 131. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1106 行
- **函数**: `toBytes()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1103 |     /// @param _arg The index of the argument to extract
   1104 |     function toBytes(bytes calldata _bytes, uint256 _arg) internal pure returns (bytes calldata res) {
   1105 |         (uint256 length, uint256 offset) = toLengthOffset(_bytes, _arg);
>> 1106 |         assembly {
   1107 |             res.length := length
   1108 |             res.offset := offset
   1109 |         }
```

---

### 132. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1117 行
- **函数**: `toAddressArray()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1114 |     /// @param _arg The index of the argument to extract
   1115 |     function toAddressArray(bytes calldata _bytes, uint256 _arg) internal pure returns (address[] calldata res) {
   1116 |         (uint256 length, uint256 offset) = toLengthOffset(_bytes, _arg);
>> 1117 |         assembly {
   1118 |             res.length := length
   1119 |             res.offset := offset
   1120 |         }
```

---

### 133. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 1128 行
- **函数**: `toBytesArray()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1125 |     /// @param _arg The index of the argument to extract
   1126 |     function toBytesArray(bytes calldata _bytes, uint256 _arg) internal pure returns (bytes[] calldata res) {
   1127 |         (uint256 length, uint256 offset) = toLengthOffset(_bytes, _arg);
>> 1128 |         assembly {
   1129 |             res.length := length
   1130 |             res.offset := offset
   1131 |         }
```

---

### 134. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2260 行
- **函数**: `safeTransferETH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2257 |         bool success;
   2258 | 
   2259 |         /// @solidity memory-safe-assembly
>> 2260 |         assembly {
   2261 |             // Transfer the ETH and store if it succeeded or not.
   2262 |             success := call(gas(), to, amount, 0, 0, 0, 0)
   2263 |         }
```

---

### 135. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2281 行
- **函数**: `safeTransferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2278 |         bool success;
   2279 | 
   2280 |         /// @solidity memory-safe-assembly
>> 2281 |         assembly {
   2282 |             // Get a pointer to some free memory.
   2283 |             let freeMemoryPointer := mload(0x40)
   2284 | 
```

---

### 136. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2314 行
- **函数**: `safeTransfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2311 |         bool success;
   2312 | 
   2313 |         /// @solidity memory-safe-assembly
>> 2314 |         assembly {
   2315 |             // Get a pointer to some free memory.
   2316 |             let freeMemoryPointer := mload(0x40)
   2317 | 
```

---

### 137. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4Dae2f939ACf50408e13d58534Ff8c2776d45265` 第 2346 行
- **函数**: `safeApprove()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2343 |         bool success;
   2344 | 
   2345 |         /// @solidity memory-safe-assembly
>> 2346 |         assembly {
   2347 |             // Get a pointer to some free memory.
   2348 |             let freeMemoryPointer := mload(0x40)
   2349 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*