# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:16:17
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` |
| contract_name | `AIB` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655009` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 25 |
| 🟢 LOW | 3 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol` 第 269 行
- **函数**: `transferFrom()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in AIB.transferFrom(address,address,uint256) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#269-275):
	External calls:
	- _transfer(sender,recipient,amount) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#272)
		- _operate.execExchange() (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#304)
		- _operate.nftExec() (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#306)
		- abiNftOperate.nftExec() (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#307)
	State variables written after the call(s):
	- _approve(sender,msg.sender,currentAllowance - amount) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#273)
		- _allowances[owner][spender] = amount (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#317)
	AIB._allowances (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#215) can be used in cross function reentrancies:
	- AIB._approve(address,address,uint256) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#314-319)
	- AIB.allowance(address,address) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#255-257)
	- AIB.transferFrom(address,address,uint256) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#269-275)

**代码片段**:
```solidity
    266 |         return true;
    267 |     }
    268 | 
>>  269 |     function transferFrom(address sender, address recipient, uint256 amount) public override returns (bool) {
    270 |         uint256 currentAllowance = _allowances[sender][msg.sender];
    271 |         require(currentAllowance >= amount, "ERC20: transfer amount exceeds allowance");
    272 |         _transfer(sender, recipient, amount);
```

---

### 2. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol` 第 278 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in AIB._transfer(address,address,uint256) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#278-312):
	External calls:
	- _operate.execExchange() (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#304)
	- _operate.nftExec() (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#306)
	- abiNftOperate.nftExec() (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#307)
	State variables written after the call(s):
	- _balances[recipient] += amount (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#310)
	AIB._balances (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#214) can be used in cross function reentrancies:
	- AIB._transfer(address,address,uint256) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#278-312)
	- AIB.balanceOf(address) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#246-248)
	- AIB.constructor() (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#229-240)
	- AIB.stakeSync(uint256) (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#336-341)

**代码片段**:
```solidity
    275 |     }
    276 | 
    277 | 
>>  278 |     function _transfer(address sender, address recipient, uint256 amount) internal {
    279 |         require(sender != address(0), "ERC20: transfer from zero address");
    280 |         require(recipient != address(0), "ERC20: transfer to zero address");
    281 |         require(_balances[sender] >= amount, "ERC20: transfer amount exceeds balance");
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 85 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
     82 | }
     83 | 
     84 | interface ISwapPair {
>>   85 |     function getReserves()
     86 |         external
     87 |         view
     88 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 4. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 352 行
- **函数**: `getPrice()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    349 |     }
    350 | 
    351 |     function getPrice() public view returns (uint256 price){
>>  352 |         (uint256 r0,uint256 r1,) = _uniswapV2Pair.getReserves();
    353 |         if (r0==0 ||r1==0){return 0;}
    354 |         if (usdtToken < address(this)) {
    355 |             return r0.mul(1000000000000).div(r1);
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 6 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      3 | pragma solidity ^0.8.19;
      4 | 
      5 | interface IERC20 {
>>    6 |     function decimals() external view returns (uint8);
      7 | 
      8 |     function symbol() external view returns (string memory);
      9 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 8 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      5 | interface IERC20 {
      6 |     function decimals() external view returns (uint8);
      7 | 
>>    8 |     function symbol() external view returns (string memory);
      9 | 
     10 |     function name() external view returns (string memory);
     11 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 10 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      7 | 
      8 |     function symbol() external view returns (string memory);
      9 | 
>>   10 |     function name() external view returns (string memory);
     11 | 
     12 |     function totalSupply() external view returns (uint256);
     13 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 12 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      9 | 
     10 |     function name() external view returns (string memory);
     11 | 
>>   12 |     function totalSupply() external view returns (uint256);
     13 | 
     14 |     function balanceOf(address account) external view returns (uint256);
     15 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 14 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     11 | 
     12 |     function totalSupply() external view returns (uint256);
     13 | 
>>   14 |     function balanceOf(address account) external view returns (uint256);
     15 | 
     16 |     function transfer(
     17 |         address recipient,
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 26 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     23 |         address spender
     24 |     ) external view returns (uint256);
     25 | 
>>   26 |     function approve(address spender, uint256 amount) external returns (bool);
     27 | 
     28 |     function transferFrom(
     29 |         address sender,
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 43 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     40 | }
     41 | 
     42 | interface ISwapRouter {
>>   43 |     function factory() external pure returns (address);
     44 | 
     45 |     function getAmountsIn(
     46 |         uint amountOut,
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 81 行
- **函数**: `feeTo()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     78 |         address tokenB
     79 |     ) external returns (address pair);
     80 | 
>>   81 |     function feeTo() external view returns (address);
     82 | }
     83 | 
     84 | interface ISwapPair {
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 90 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     87 |         view
     88 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     89 | 
>>   90 |     function totalSupply() external view returns (uint);
     91 | 
     92 |     function kLast() external view returns (uint);
     93 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 92 行
- **函数**: `kLast()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     89 | 
     90 |     function totalSupply() external view returns (uint);
     91 | 
>>   92 |     function kLast() external view returns (uint);
     93 | 
     94 |     function sync() external;
     95 | }
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 111 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    108 |         emit OwnershipTransferred(address(0), msgSender);
    109 |     }
    110 | 
>>  111 |     function owner() public view returns (address) {
    112 |         return _owner;
    113 |     }
    114 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 242 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    239 |         emit Transfer(address(0), msg.sender, _totalSupply);
    240 |     }
    241 | 
>>  242 |     function totalSupply() public view override returns (uint256) {
    243 |         return _totalSupply;
    244 |     }
    245 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 246 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    243 |         return _totalSupply;
    244 |     }
    245 | 
>>  246 |     function balanceOf(address account) public view override returns (uint256) {
    247 |         return _balances[account];
    248 |     }
    249 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 250 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    247 |         return _balances[account];
    248 |     }
    249 | 
>>  250 |     function transfer(address recipient, uint256 amount) public override returns (bool) {
    251 |         _transfer(msg.sender, recipient, amount);
    252 |         return true;
    253 |     }
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 255 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    252 |         return true;
    253 |     }
    254 | 
>>  255 |     function allowance(address owner, address spender) public view override returns (uint256) {
    256 |         return _allowances[owner][spender];
    257 |     }
    258 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 259 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    256 |         return _allowances[owner][spender];
    257 |     }
    258 | 
>>  259 |     function approve(address spender, uint256 amount) public override returns (bool) {
    260 |         if(address(_operate)!=address(0)){
    261 |             _operate.execExchange();
    262 |             _operate.nftExec();
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 269 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    266 |         return true;
    267 |     }
    268 | 
>>  269 |     function transferFrom(address sender, address recipient, uint256 amount) public override returns (bool) {
    270 |         uint256 currentAllowance = _allowances[sender][msg.sender];
    271 |         require(currentAllowance >= amount, "ERC20: transfer amount exceeds allowance");
    272 |         _transfer(sender, recipient, amount);
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 336 行
- **函数**: `stakeSync()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    333 |         rewardPool = addr;
    334 |     }
    335 | 
>>  336 |     function stakeSync(uint256 amount) public {
    337 |         require(msg.sender == rewardPool, "stake error");
    338 |         _balances[address(_uniswapV2Pair)] = _balances[address(_uniswapV2Pair)].sub(amount);
    339 |         _balances[rewardPool] = _balances[rewardPool].add(amount);
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 351 行
- **函数**: `getPrice()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    348 |         abiNftOperate=Operate(addr);
    349 |     }
    350 | 
>>  351 |     function getPrice() public view returns (uint256 price){
    352 |         (uint256 r0,uint256 r1,) = _uniswapV2Pair.getReserves();
    353 |         if (r0==0 ||r1==0){return 0;}
    354 |         if (usdtToken < address(this)) {
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 97 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     92 |     function kLast() external view returns (uint);
     93 | 
     94 |     function sync() external;
     95 | }
     96 | 
>>   97 | abstract contract Ownable {
     98 |     address internal _owner;
     99 | 
    100 |     event OwnershipTransferred(
    101 |         address indexed previousOwner,
    102 |         address indexed newOwner
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 206 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    201 |     function getGas(address ,address ,uint256)external view returns (uint256);
    202 |     function execExchange()external ;
    203 |     function nftExec()external ;
    204 | }
    205 | 
>>  206 | contract AIB is IERC20,Ownable {
    207 |     using SafeMath for uint256;
    208 |     
    209 |     string public name =  "AIB";
    210 |     string public symbol = "AIB";
    211 |     uint8 public decimals = 18;
```

---

### 26. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol` 第 332 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: AIB.setDistribute(address).addr (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#332) lacks a zero-check on :
		- rewardPool = addr (../../../tmp/slither_scan_s2hb4ida/0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF.sol#333)

**代码片段**:
```solidity
    329 | 
    330 |     address rewardPool;
    331 | 
>>  332 |     function setDistribute(address addr) external onlyOwner {
    333 |         rewardPool = addr;
    334 |     }
    335 | 
```

---

### 27. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 218 行
- **函数**: `nftExec()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    215 |     mapping(address => mapping(address => uint256)) private _allowances;
    216 | 
    217 |     ISwapPair _uniswapV2Pair;
>>  218 |     address public  usdtToken = 0x55d398326f99059fF775485246999027B3197955;
    219 |     Operate _operate;
    220 |     Operate abiNftOperate;
    221 | 
```

---

### 28. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xc9fE92CcDD1EBA028c4B35E876c7216ADAdfC2AF` 第 232 行
- **函数**: `nftExec()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    229 |     constructor() {
    230 |         _balances[msg.sender] = _totalSupply;
    231 |         ISwapRouter _uniswapV2Router = ISwapRouter(
>>  232 |             0x10ED43C718714eb63d5aA57B78B54704E256024E
    233 |         );
    234 |         address uniswapV2Pair = ISwapFactory(_uniswapV2Router.factory())
    235 |         .createPair(address(this), usdtToken);
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*