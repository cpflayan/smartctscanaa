# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:03:28
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` |
| contract_name | `Fortune2Predict` |
| compiler_version | `v0.8.30+commit.73712a01` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `None` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['Fortune2PredictFun.sol', '@openzeppelin/contracts/utils/ReentrancyGuard.sol', '@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/utils/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 15 |
| 🟢 LOW | 5 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 11 行
- **函数**: `getReserves()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
      8 | 
      9 | 
     10 | interface IPancakePair {
>>   11 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     12 |     function token0() external view returns (address);
     13 |     function token1() external view returns (address);
     14 | }
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 125 行
- **函数**: `getRequiredBNB()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    122 |             return 0;
    123 |         }
    124 |         IPancakePair pair = IPancakePair(PANCAKE_USDT_BNB_PAIR);
>>  125 |         (uint112 reserve0, uint112 reserve1, ) = pair.getReserves();
    126 | 
    127 |         address token0 = pair.token0();
    128 |         uint256 reserveBNB = (token0 == WBNB) ? uint256(reserve0) : uint256(reserve1);
```

---

### 3. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 23 行
- **函数**: `safeTransfer()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
     20 |         uint256 value
     21 |     ) internal {
     22 |         // bytes4(keccak256(bytes('transfer(address,uint256)')));
>>   23 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
     24 |         require(
     25 |             success && (data.length == 0 || abi.decode(data, (bool))),
     26 |             'TransferHelper::safeTransfer: transfer failed'
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 30 行
- **函数**: `safeTransferETH()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     27 |         );
     28 |     }
     29 |     function safeTransferETH(address to, uint256 value) internal {
>>   30 |         (bool success, ) = to.call{value: value}(new bytes(0));
     31 |         require(success, 'STE');
     32 |     }
     33 | }
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 103 行
- **函数**: `buyShares()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    100 |         uint256 fee = requiredBNB;
    101 |         uint256 refund = msg.value - fee;
    102 | 
>>  103 |         (bool sent, ) = feeRecipient.call{value: fee * 62 / 100}("");
    104 |         require(sent, "Fee transfer failed");
    105 |         (sent, ) = feeRecipientContract.call{value: fee * 38 / 100}("");
    106 |         require(sent, "Fee transfer failed");        
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 105 行
- **函数**: `buyShares()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    102 | 
    103 |         (bool sent, ) = feeRecipient.call{value: fee * 62 / 100}("");
    104 |         require(sent, "Fee transfer failed");
>>  105 |         (sent, ) = feeRecipientContract.call{value: fee * 38 / 100}("");
    106 |         require(sent, "Fee transfer failed");        
    107 | 
    108 |         if (refund > 0) {
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 109 行
- **函数**: `buyShares()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    106 |         require(sent, "Fee transfer failed");        
    107 | 
    108 |         if (refund > 0) {
>>  109 |             (bool refunded, ) = msg.sender.call{value: refund}("");
    110 |             require(refunded, "Refund failed");
    111 |         }
    112 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 11 行
- **函数**: `getReserves()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      8 | 
      9 | 
     10 | interface IPancakePair {
>>   11 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     12 |     function token0() external view returns (address);
     13 |     function token1() external view returns (address);
     14 | }
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 12 行
- **函数**: `token0()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      9 | 
     10 | interface IPancakePair {
     11 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>>   12 |     function token0() external view returns (address);
     13 |     function token1() external view returns (address);
     14 | }
     15 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 13 行
- **函数**: `token1()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     10 | interface IPancakePair {
     11 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     12 |     function token0() external view returns (address);
>>   13 |     function token1() external view returns (address);
     14 | }
     15 | 
     16 | library TransferHelper {
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 120 行
- **函数**: `getRequiredBNB()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    117 |     // Price Calculation
    118 |     // ──────────────────────────────────────────────
    119 | 
>>  120 |     function getRequiredBNB() public view returns (uint256) {
    121 |         if (feeUsdtValue == 0) {
    122 |             return 0;
    123 |         }
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 296 行
- **函数**: `owner()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    293 |     /**
    294 |      * @dev Returns the address of the current owner.
    295 |      */
>>  296 |     function owner() public view virtual returns (address) {
    297 |         return _owner;
    298 |     }
    299 | 
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 36 行
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     31 |         require(success, 'STE');
     32 |     }
     33 | }
     34 | 
     35 | 
>>   36 | contract Fortune2Predict is Ownable, ReentrancyGuard {
     37 |     // ──────────────────────────────────────────────
     38 |     // Events
     39 |     // ──────────────────────────────────────────────
     40 |     event SharesBoughtThirdPaty(
     41 |         uint256 indexed marketId, 
```

---

### 14. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 260 行
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    255 |  *
    256 |  * This module is used through inheritance. It will make available the modifier
    257 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    258 |  * the owner.
    259 |  */
>>  260 | abstract contract Ownable is Context {
    261 |     address private _owner;
    262 | 
    263 |     /**
    264 |      * @dev The caller account is not authorized to perform an operation.
    265 |      */
```

---

### 15. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 332 行
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    327 |         }
    328 |         _transferOwnership(newOwner);
    329 |     }
    330 | 
    331 |     /**
>>  332 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    333 |      * Internal function without access restriction.
    334 |      */
    335 |     function _transferOwnership(address newOwner) internal virtual {
    336 |         address oldOwner = _owner;
    337 |         _owner = newOwner;
```

---

### 16. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 140 行
- **函数**: `rescueBNB()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    137 |     // Emergency
    138 |     // ──────────────────────────────────────────────
    139 |     function rescueBNB(uint256 amount) external onlyOwner {
>>  140 |         payable(owner()).transfer(amount);
    141 |     }
    142 | 
    143 |     function rescueToken(address tokenAddress, uint256 tokens) public onlyOwner {
```

---

### 17. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 55 行
- **函数**: `safeTransferETH()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     52 |     uint256 public feeUsdtValue = 500_000_000_000_000_000; // 0.5 USDT
     53 | 
     54 |     // Pancake V2 USDT-BNB Pair 
>>   55 |     address public constant PANCAKE_USDT_BNB_PAIR = 0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE;
     56 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
     57 |     address public feeRecipient = 0x0abd7E3d31527E08514bE82c2537da92a36230B4;
     58 |     address public feeRecipientContract = 0xebd0F63Acd642F451C2e80Ca3c04825B452F3B9a; // Vote Contract
```

---

### 18. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 56 行
- **函数**: `safeTransferETH()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     53 | 
     54 |     // Pancake V2 USDT-BNB Pair 
     55 |     address public constant PANCAKE_USDT_BNB_PAIR = 0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE;
>>   56 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
     57 |     address public feeRecipient = 0x0abd7E3d31527E08514bE82c2537da92a36230B4;
     58 |     address public feeRecipientContract = 0xebd0F63Acd642F451C2e80Ca3c04825B452F3B9a; // Vote Contract
     59 | 
```

---

### 19. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 57 行
- **函数**: `safeTransferETH()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     54 |     // Pancake V2 USDT-BNB Pair 
     55 |     address public constant PANCAKE_USDT_BNB_PAIR = 0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE;
     56 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
>>   57 |     address public feeRecipient = 0x0abd7E3d31527E08514bE82c2537da92a36230B4;
     58 |     address public feeRecipientContract = 0xebd0F63Acd642F451C2e80Ca3c04825B452F3B9a; // Vote Contract
     59 | 
     60 |     uint256 public constant MAX_DAILY_VOTES = 1000;
```

---

### 20. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd84Cf9Fc929f7CA657d9762b5157515fF19C157E` 第 58 行
- **函数**: `safeTransferETH()`
- **合约**: `Fortune2Predict`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     55 |     address public constant PANCAKE_USDT_BNB_PAIR = 0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE;
     56 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
     57 |     address public feeRecipient = 0x0abd7E3d31527E08514bE82c2537da92a36230B4;
>>   58 |     address public feeRecipientContract = 0xebd0F63Acd642F451C2e80Ca3c04825B452F3B9a; // Vote Contract
     59 | 
     60 |     uint256 public constant MAX_DAILY_VOTES = 1000;
     61 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*