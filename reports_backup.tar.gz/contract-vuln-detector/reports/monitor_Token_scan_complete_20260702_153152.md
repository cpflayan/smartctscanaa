# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:31:52
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` |
| contract_name | `Token` |
| compiler_version | `v0.8.7+commit.e28d00a7` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655011` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 6 |
| 🟡 MEDIUM | 32 |
| 🟢 LOW | 22 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] arbitrary-send-erc20

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol` 第 922 行
- **函数**: `swapTokenForFund()`
- **扫描工具**: slither
- **综合评分**: 0.725

**工具描述**: Token.swapTokenForFund(uint256,uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#922-1012) uses arbitrary from in transferFrom: _c.transferFrom(address(_tokenDistributor),address(this),newBal) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#955)

**代码片段**:
```solidity
    919 |         generateLpReceiverAddr = newAddr;
    920 |     }
    921 | 
>>  922 |     function swapTokenForFund(
    923 |         uint256 tokenAmount,
    924 |         uint256 swapFee
    925 |     ) private lockTheSwap {
```

---

### 2. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 635 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    632 |         bool isAdd;
    633 | 
    634 |         uint256 addLPLiquidity;
>>  635 |         if (to == _mainPair && _swapRouters[msg.sender] && tx.origin == from) {
    636 |             addLPLiquidity = _isAddLiquidity(amount);
    637 |             if (addLPLiquidity > 0 && !isContract(from)) {
    638 |                 isAdd = true;
```

---

### 3. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 723 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    720 |                     _swapPairList[from] &&
    721 |                     block.number < startTradeBlock + killBatchBlockNumber
    722 |                 ) {
>>  723 |                     if (block.number != user2blocks[tx.origin]) {
    724 |                         user2blocks[tx.origin] = block.number;
    725 |                     } else {
    726 |                         batchBots++;
```

---

### 4. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 724 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    721 |                     block.number < startTradeBlock + killBatchBlockNumber
    722 |                 ) {
    723 |                     if (block.number != user2blocks[tx.origin]) {
>>  724 |                         user2blocks[tx.origin] = block.number;
    725 |                     } else {
    726 |                         batchBots++;
    727 |                         _funTransfer(from, to, amount);
```

---

### 5. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol` 第 619 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in Token._transfer(address,address,uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#619-779):
	External calls:
	- swapTokenForFund(numTokensSellToFund,swapFee) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#747)
		- _swapRouter.swapExactTokensForTokensSupportingFeeOnTransferTokens(tokenAmount - lpAmount,0,toCurrencyPath,address(_tokenDistributor),block.timestamp) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#939-951)
		- _c.transferFrom(address(_tokenDistributor),address(this),newBal) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#955)
		- IWBNB(currency).withdraw(toFundAmt) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#965)
		- _c.transfer(fundAddress,toFundAmt) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#968)
		- _swapRouter.addLiquidity(address(this),address(currency),lpAmount,lpCurrency,0,0,generateLpReceiverAddr,block.timestamp) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#975-988)
		- _swapRouter.swapExactTokensForTokensSupportingFeeOnTransferTokens(_c.balanceOf(address(this)),0,rewardPath,address(this),block.timestamp) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#999-1011)
	External calls sending eth:
	- swapTokenForFund(numTokensSellToFund,swapFee) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#747)
		- fundAddress.transfer(toFundAmt) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#966)
	State variables written after the call(s):
	- _tokenTransfer(from,to,amount,takeFee,isSell,isTransfer,isAdd,isRemove) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#762-771)
		- _balances[to] = _balances[to] + tAmount (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1019)
		- _balances[sender] = _balances[sender] - tAmount (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#831)
	Token._balances (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#179) can be used in cross function reentrancies:
	- Token._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#465-474)
	- Token._funTransfer(address,address,uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#791-800)
	- Token._takeTransfer(address,address,uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1014-1021)
	- Token._tokenTransfer(address,address,uint256,bool,bool,bool,bool,bool) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#821-905)
	- Token._transfer(address,address,uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#619-779)
	- Token.balanceOf(address) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#394-399)
	- Token.constructor(string[],address[],uint256[],bool[]) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#250-370)

**代码片段**:
```solidity
    616 |         }
    617 |     }
    618 | 
>>  619 |     function _transfer(address from, address to, uint256 amount) private {
    620 |         uint256 balance = _balances[from];
    621 |         require(balance >= amount, "balanceNotEnough");
    622 | 
```

---

### 6. 🟠 [HIGH] arbitrary-send-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol` 第 1123 行
- **函数**: `claimBalance()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Token.claimBalance() (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1123-1125) sends eth to arbitrary user
	Dangerous calls:
	- fundAddress.transfer(address(this).balance) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1124)

**代码片段**:
```solidity
   1120 |         maxWalletAmount = _amount;
   1121 |     }
   1122 | 
>> 1123 |     function claimBalance() external {
   1124 |         fundAddress.transfer(address(this).balance);
   1125 |     }
   1126 | 
```

---

### 7. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol` 第 1179 行
- **函数**: `processReward()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in Token.processReward(uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1179-1230):
	External calls:
	- FIST.transfer(shareHolder,amount) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1219)
	State variables written after the call(s):
	- currentIndex = 0 (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1212)
	Token.currentIndex (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1170) can be used in cross function reentrancies:
	- Token.processReward(uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1179-1230)
	- currentIndex ++ (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1225)
	Token.currentIndex (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1170) can be used in cross function reentrancies:
	- Token.processReward(uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1179-1230)
	- progressRewardBlock = block.number (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1229)
	Token.progressRewardBlock (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1172) can be used in cross function reentrancies:
	- Token.processReward(uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#1179-1230)

**代码片段**:
```solidity
   1176 |         processRewardWaitBlock = newValue;
   1177 |     }
   1178 | 
>> 1179 |     function processReward(uint256 gas) private {
   1180 |         if (progressRewardBlock + processRewardWaitBlock > block.number) {
   1181 |             return;
   1182 |         }
```

---

### 8. 🟡 [MEDIUM] tx-origin

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol` 第 619 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Token._transfer(address,address,uint256) (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#619-779) uses tx.origin for authorization: block.number != user2blocks[tx.origin] (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#723)

**代码片段**:
```solidity
    616 |         }
    617 |     }
    618 | 
>>  619 |     function _transfer(address from, address to, uint256 amount) private {
    620 |         uint256 balance = _balances[from];
    621 |         require(balance >= amount, "balanceNotEnough");
    622 | 
```

---

### 9. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 160 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    157 | }
    158 | 
    159 | interface ISwapPair {
>>  160 |     function getReserves()
    161 |         external
    162 |         view
    163 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 10. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 501 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    498 |     bool public isAddV2;
    499 |     bool public isRemoveV2;
    500 | 
>>  501 |     function _getReserves()
    502 |         public
    503 |         view
    504 |         returns (uint256 rOther, uint256 rThis, uint256 balanceOther)
```

---

### 11. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 507 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    504 |         returns (uint256 rOther, uint256 rThis, uint256 balanceOther)
    505 |     {
    506 |         ISwapPair mainPair = ISwapPair(_mainPair);
>>  507 |         (uint r0, uint256 r1, ) = mainPair.getReserves();
    508 | 
    509 |         address tokenOther = currency;
    510 |         if (tokenOther < address(this)) {
```

---

### 12. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 524 行
- **函数**: `_isAddLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    521 |     function _isAddLiquidity(
    522 |         uint256 amount
    523 |     ) internal view returns (uint256 liquidity) {
>>  524 |         (uint256 rOther, uint256 rThis, uint256 balanceOther) = _getReserves();
    525 |         uint256 amountOther;
    526 |         if (rOther > 0 && rThis > 0) {
    527 |             amountOther = (amount * rOther) / rThis;
```

---

### 13. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 591 行
- **函数**: `_strictCheckBuy()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    588 |     function _strictCheckBuy(
    589 |         uint256 amount
    590 |     ) internal view returns (uint256 liquidity) {
>>  591 |         (uint256 rOther, uint256 rThis, uint256 balanceOther) = _getReserves();
    592 |         //isRemoveLP
    593 |         if (balanceOther < rOther) {
    594 |             liquidity =
```

---

### 14. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 610 行
- **函数**: `_isRemoveLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    607 |     function _isRemoveLiquidity(
    608 |         uint256 amount
    609 |     ) internal view returns (uint256 liquidity) {
>>  610 |         (uint256 rOther, , uint256 balanceOther) = _getReserves();
    611 |         //isRemoveLP
    612 |         if (balanceOther <= rOther) {
    613 |             liquidity =
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 24 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     21 | }
     22 | 
     23 | interface IERC20 {
>>   24 |     function decimals() external view returns (uint256);
     25 | 
     26 |     function symbol() external view returns (string memory);
     27 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 26 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     23 | interface IERC20 {
     24 |     function decimals() external view returns (uint256);
     25 | 
>>   26 |     function symbol() external view returns (string memory);
     27 | 
     28 |     function name() external view returns (string memory);
     29 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 28 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     25 | 
     26 |     function symbol() external view returns (string memory);
     27 | 
>>   28 |     function name() external view returns (string memory);
     29 | 
     30 |     function totalSupply() external view returns (uint256);
     31 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 30 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     27 | 
     28 |     function name() external view returns (string memory);
     29 | 
>>   30 |     function totalSupply() external view returns (uint256);
     31 | 
     32 |     function balanceOf(address account) external view returns (uint256);
     33 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 32 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     29 | 
     30 |     function totalSupply() external view returns (uint256);
     31 | 
>>   32 |     function balanceOf(address account) external view returns (uint256);
     33 | 
     34 |     function transfer(
     35 |         address recipient,
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 44 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     41 |         address spender
     42 |     ) external view returns (uint256);
     43 | 
>>   44 |     function approve(address spender, uint256 amount) external returns (bool);
     45 | 
     46 |     function transferFrom(
     47 |         address sender,
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 61 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     58 | }
     59 | 
     60 | interface ISwapRouter {
>>   61 |     function factory() external pure returns (address);
     62 | 
     63 |     function WETH() external pure returns (address);
     64 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 63 行
- **函数**: `WETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     60 | interface ISwapRouter {
     61 |     function factory() external pure returns (address);
     62 | 
>>   63 |     function WETH() external pure returns (address);
     64 | 
     65 |     function swapExactTokensForTokensSupportingFeeOnTransferTokens(
     66 |         uint256 amountIn,
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 115 行
- **函数**: `feeTo()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    112 |         address tokenA,
    113 |         address tokenB
    114 |     ) external view returns (address pair);
>>  115 |     function feeTo() external view returns (address);
    116 | }
    117 | 
    118 | abstract contract Ownable {
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 132 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    129 |         emit OwnershipTransferred(address(0), msgSender);
    130 |     }
    131 | 
>>  132 |     function owner() public view returns (address) {
    133 |         return _owner;
    134 |     }
    135 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 165 行
- **函数**: `token0()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    162 |         view
    163 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    164 | 
>>  165 |     function token0() external view returns (address);
    166 | 
    167 |     function balanceOf(address account) external view returns (uint256);
    168 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 167 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    164 | 
    165 |     function token0() external view returns (address);
    166 | 
>>  167 |     function balanceOf(address account) external view returns (uint256);
    168 | 
    169 |     function kLast() external view returns (uint);
    170 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 169 行
- **函数**: `kLast()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    166 | 
    167 |     function balanceOf(address account) external view returns (uint256);
    168 | 
>>  169 |     function kLast() external view returns (uint);
    170 | 
    171 |     function totalSupply() external view returns (uint256);
    172 | }
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 171 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    168 | 
    169 |     function kLast() external view returns (uint);
    170 | 
>>  171 |     function totalSupply() external view returns (uint256);
    172 | }
    173 | 
    174 | interface IWBNB {
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 372 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    369 |         // _rewardTokenDistributor = new TokenDistributor(ETH);
    370 |     }
    371 | 
>>  372 |     function symbol() external view override returns (string memory) {
    373 |         return _symbol;
    374 |     }
    375 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 376 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    373 |         return _symbol;
    374 |     }
    375 | 
>>  376 |     function name() external view override returns (string memory) {
    377 |         return _name;
    378 |     }
    379 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 380 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    377 |         return _name;
    378 |     }
    379 | 
>>  380 |     function decimals() external view override returns (uint256) {
    381 |         return _decimals;
    382 |     }
    383 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 384 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    381 |         return _decimals;
    382 |     }
    383 | 
>>  384 |     function totalSupply() public view override returns (uint256) {
    385 |         return _tTotal;
    386 |     }
    387 | 
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 394 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    391 |         antiSYNC = s;
    392 |     }
    393 | 
>>  394 |     function balanceOf(address account) public view override returns (uint256) {
    395 |         if (account == _mainPair && msg.sender == _mainPair && antiSYNC) {
    396 |             require(_balances[_mainPair] > 0, "!sync");
    397 |         }
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 451 行
- **函数**: `isReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    448 |         kb = a;
    449 |     }
    450 | 
>>  451 |     function isReward(address account) public view returns (uint256) {
    452 |         if (_rewardList[account]) {
    453 |             return 1;
    454 |         } else {
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1123 行
- **函数**: `claimBalance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1120 |         maxWalletAmount = _amount;
   1121 |     }
   1122 | 
>> 1123 |     function claimBalance() external {
   1124 |         fundAddress.transfer(address(this).balance);
   1125 |     }
   1126 | 
```

---

### 36. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 118 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    113 |         address tokenB
    114 |     ) external view returns (address pair);
    115 |     function feeTo() external view returns (address);
    116 | }
    117 | 
>>  118 | abstract contract Ownable {
    119 |     address internal _owner;
    120 | 
    121 |     event OwnershipTransferred(
    122 |         address indexed previousOwner,
    123 |         address indexed newOwner
```

---

### 37. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 153 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    148 |         emit OwnershipTransferred(_owner, newOwner);
    149 |         _owner = newOwner;
    150 |     }
    151 | }
    152 | 
>>  153 | contract TokenDistributor {
    154 |     constructor(address token) {
    155 |         IERC20(token).approve(msg.sender, uint256(~uint256(0)));
    156 |     }
    157 | }
    158 | 
```

---

### 38. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 178 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    173 | 
    174 | interface IWBNB {
    175 |     function withdraw(uint wad) external; //unwarp WBNB -> BNB
    176 | }
    177 | 
>>  178 | contract Token is IERC20, Ownable {
    179 |     mapping(address => uint256) private _balances;
    180 |     mapping(address => mapping(address => uint256)) private _allowances;
    181 | 
    182 |     address payable public fundAddress;
    183 | 
```

---

### 39. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol` 第 306 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: Token.constructor(string[],address[],uint256[],bool[]).swapPair (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#306) lacks a zero-check on :
		- _mainPair = swapPair (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#307)

**代码片段**:
```solidity
    303 |         _swapRouters[address(swapRouter)] = true;
    304 | 
    305 |         ISwapFactory swapFactory = ISwapFactory(swapRouter.factory());
>>  306 |         address swapPair = swapFactory.createPair(address(this), currency);
    307 |         _mainPair = swapPair;
    308 |         _swapPairList[swapPair] = true;
    309 | 
```

---

### 40. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol` 第 918 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: Token.setGenerateLpReceiverAddr(address).newAddr (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#918) lacks a zero-check on :
		- generateLpReceiverAddr = newAddr (../../../tmp/slither_scan_ge20b1cg/0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D.sol#919)

**代码片段**:
```solidity
    915 | 
    916 |     address public generateLpReceiverAddr;
    917 | 
>>  918 |     function setGenerateLpReceiverAddr(address newAddr) public onlyOwner {
    919 |         generateLpReceiverAddr = newAddr;
    920 |     }
    921 | 
```

---

### 41. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 678 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    675 |                     uint160(
    676 |                         uint256(
    677 |                             keccak256(
>>  678 |                                 abi.encodePacked(i, amount, block.timestamp)
    679 |                             )
    680 |                         )
    681 |                     )
```

---

### 42. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 945 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    942 |                 0,
    943 |                 toCurrencyPath,
    944 |                 address(_tokenDistributor),
>>  945 |                 block.timestamp
    946 |             )
    947 |         {} catch {
    948 |             emit Failed_swapExactTokensForTokensSupportingFeeOnTransferTokens(
```

---

### 43. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 984 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    981 |                     0,
    982 |                     0,
    983 |                     generateLpReceiverAddr,
>>  984 |                     block.timestamp
    985 |                 )
    986 |             {} catch {
    987 |                 emit Failed_AddLiquidity();
```

---

### 44. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1005 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1002 |                 0,
   1003 |                 rewardPath,
   1004 |                 address(this),
>> 1005 |                 block.timestamp
   1006 |             )
   1007 |         {} catch {
   1008 |             emit Failed_swapExactTokensForTokensSupportingFeeOnTransferTokens(
```

---

### 45. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 966 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    963 |         if (toFundAmt > 0) {
    964 |             if (currencyIsEth) {
    965 |                 IWBNB(currency).withdraw(toFundAmt);
>>  966 |                 fundAddress.transfer(toFundAmt);
    967 |             } else {
    968 |                 _c.transfer(fundAddress, toFundAmt);
    969 |             }
```

---

### 46. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 968 行
- **函数**: `swapTokenForFund()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    965 |                 IWBNB(currency).withdraw(toFundAmt);
    966 |                 fundAddress.transfer(toFundAmt);
    967 |             } else {
>>  968 |                 _c.transfer(fundAddress, toFundAmt);
    969 |             }
    970 |             totalFundAmountReceive += toFundAmt;
    971 |         }
```

---

### 47. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1124 行
- **函数**: `claimBalance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1121 |     }
   1122 | 
   1123 |     function claimBalance() external {
>> 1124 |         fundAddress.transfer(address(this).balance);
   1125 |     }
   1126 | 
   1127 |     function claimToken(
```

---

### 48. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1132 行
- **函数**: `claimToken()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1129 |         uint256 amount,
   1130 |         address to
   1131 |     ) external onlyFunder {
>> 1132 |         IERC20(token).transfer(to, amount);
   1133 |     }
   1134 | 
   1135 |     modifier onlyFunder() {
```

---

### 49. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1219 行
- **函数**: `processReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1216 |             if (tokenBalance > 0 && !excludeHolder[shareHolder]) {
   1217 |                 amount = (balance * tokenBalance) / holdTokenTotal;
   1218 |                 if (amount > 0 && FIST.balanceOf(address(this)) > amount) {
>> 1219 |                     FIST.transfer(shareHolder, amount);
   1220 |                 }
   1221 |             }
   1222 | 
```

---

### 50. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 711 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    708 |                 if (
    709 |                     enableOffTrade &&
    710 |                     enableKillBlock &&
>>  711 |                     block.number < startTradeBlock + kb &&
    712 |                     !_swapPairList[to]
    713 |                 ) {
    714 |                     _rewardList[to] = true;
```

---

### 51. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 721 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    718 |                 if (
    719 |                     enableKillBatchBots &&
    720 |                     _swapPairList[from] &&
>>  721 |                     block.number < startTradeBlock + killBatchBlockNumber
    722 |                 ) {
    723 |                     if (block.number != user2blocks[tx.origin]) {
    724 |                         user2blocks[tx.origin] = block.number;
```

---

### 52. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 723 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    720 |                     _swapPairList[from] &&
    721 |                     block.number < startTradeBlock + killBatchBlockNumber
    722 |                 ) {
>>  723 |                     if (block.number != user2blocks[tx.origin]) {
    724 |                         user2blocks[tx.origin] = block.number;
    725 |                     } else {
    726 |                         batchBots++;
```

---

### 53. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 724 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    721 |                     block.number < startTradeBlock + killBatchBlockNumber
    722 |                 ) {
    723 |                     if (block.number != user2blocks[tx.origin]) {
>>  724 |                         user2blocks[tx.origin] = block.number;
    725 |                     } else {
    726 |                         batchBots++;
    727 |                         _funTransfer(from, to, amount);
```

---

### 54. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1041 行
- **函数**: `startLP()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1038 | 
   1039 |     function startLP() external onlyOwner {
   1040 |         require(0 == startLPBlock, "startedAddLP");
>> 1041 |         startLPBlock = block.number;
   1042 |     }
   1043 | 
   1044 |     function stopLP() external onlyOwner {
```

---

### 55. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1050 行
- **函数**: `launch()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1047 | 
   1048 |     function launch() external onlyOwner {
   1049 |         require(0 == startTradeBlock, "already open");
>> 1050 |         startTradeBlock = block.number;
   1051 |     }
   1052 | 
   1053 |     function setFeeWhiteList(
```

---

### 56. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1180 行
- **函数**: `processReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1177 |     }
   1178 | 
   1179 |     function processReward(uint256 gas) private {
>> 1180 |         if (progressRewardBlock + processRewardWaitBlock > block.number) {
   1181 |             return;
   1182 |         }
   1183 | 
```

---

### 57. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1229 行
- **函数**: `processReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1226 |             iterations++;
   1227 |         }
   1228 | 
>> 1229 |         progressRewardBlock = block.number;
   1230 |     }
   1231 | 
   1232 |     function setHolderRewardCondition(uint256 amount) external onlyOwner {
```

---

### 58. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 363 行
- **函数**: `setSwapRouter()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    360 | 
    361 |         excludeHolder[address(0)] = true;
    362 |         excludeHolder[
>>  363 |             address(0x000000000000000000000000000000000000dEaD)
    364 |         ] = true;
    365 | 
    366 |         holderRewardCondition = 10 ** IERC20(ETH).decimals() / 10;
```

---

### 59. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1031 行
- **函数**: `isContract()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1028 | 
   1029 |     function isContract(address _addr) private view returns (bool) {
   1030 |         uint32 size;
>> 1031 |         assembly {
   1032 |             size := extcodesize(_addr)
   1033 |         }
   1034 |         return (size > 0);
```

---

### 60. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xD25bD6F78e4043Ff166468E16bDD4B3aA31E022D` 第 1156 行
- **函数**: `addHolder()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1153 | 
   1154 |     function addHolder(address adr) private {
   1155 |         uint256 size;
>> 1156 |         assembly {
   1157 |             size := extcodesize(adr)
   1158 |         }
   1159 |         if (size > 0) {
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*