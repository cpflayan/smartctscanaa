# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:20:57
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` |
| contract_name | `Token` |
| compiler_version | `v0.8.30+commit.73712a01` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/ProToken.sol', 'lib/openzeppelin-contracts/contracts/access/Ownable.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol', 'lib/openzeppelin-contracts/contracts/utils/Context.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/extensions/IERC20Metadata.sol', 'lib/openzeppelin-contracts/contracts/interfaces/draft-IERC6093.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646143` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 25 |
| 🟢 LOW | 3 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 103 行
- **函数**: `decimals()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    100 |         _;
    101 |     }
    102 | 
>>  103 |     function decimals() public pure override returns (uint8) {
    104 |         return 9;
    105 |     }
    106 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 279 行
- **函数**: `mint()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    276 |      * Requirements:
    277 |      * - Only callable by treasury address
    278 |      */
>>  279 |     function mint(address _to, uint256 _amount) external {
    280 |         if(msg.sender != treasury) revert Unauthorized();
    281 | 
    282 |         _mint(_to, _amount);
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 344 行
- **函数**: `owner()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    341 |     /**
    342 |      * @dev Returns the address of the current owner.
    343 |      */
>>  344 |     function owner() public view virtual returns (address) {
    345 |         return _owner;
    346 |     }
    347 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 444 行
- **函数**: `name()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    441 |     /**
    442 |      * @dev Returns the name of the token.
    443 |      */
>>  444 |     function name() public view virtual returns (string memory) {
    445 |         return _name;
    446 |     }
    447 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 452 行
- **函数**: `symbol()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    449 |      * @dev Returns the symbol of the token, usually a shorter version of the
    450 |      * name.
    451 |      */
>>  452 |     function symbol() public view virtual returns (string memory) {
    453 |         return _symbol;
    454 |     }
    455 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 469 行
- **函数**: `decimals()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    466 |      * no way affects any of the arithmetic of the contract, including
    467 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    468 |      */
>>  469 |     function decimals() public view virtual returns (uint8) {
    470 |         return 18;
    471 |     }
    472 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 474 行
- **函数**: `totalSupply()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    471 |     }
    472 | 
    473 |     /// @inheritdoc IERC20
>>  474 |     function totalSupply() public view virtual returns (uint256) {
    475 |         return _totalSupply;
    476 |     }
    477 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 479 行
- **函数**: `balanceOf()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    476 |     }
    477 | 
    478 |     /// @inheritdoc IERC20
>>  479 |     function balanceOf(address account) public view virtual returns (uint256) {
    480 |         return _balances[account];
    481 |     }
    482 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 491 行
- **函数**: `transfer()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    488 |      * - `to` cannot be the zero address.
    489 |      * - the caller must have a balance of at least `value`.
    490 |      */
>>  491 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    492 |         address owner = _msgSender();
    493 |         _transfer(owner, to, value);
    494 |         return true;
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 498 行
- **函数**: `allowance()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    495 |     }
    496 | 
    497 |     /// @inheritdoc IERC20
>>  498 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    499 |         return _allowances[owner][spender];
    500 |     }
    501 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 512 行
- **函数**: `approve()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    509 |      *
    510 |      * - `spender` cannot be the zero address.
    511 |      */
>>  512 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    513 |         address owner = _msgSender();
    514 |         _approve(owner, spender, value);
    515 |         return true;
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 534 行
- **函数**: `transferFrom()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    531 |      * - the caller must have allowance for ``from``'s tokens of at least
    532 |      * `value`.
    533 |      */
>>  534 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    535 |         address spender = _msgSender();
    536 |         _spendAllowance(from, spender, value);
    537 |         _transfer(from, to, value);
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 760 行
- **函数**: `totalSupply()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    757 |     /**
    758 |      * @dev Returns the value of tokens in existence.
    759 |      */
>>  760 |     function totalSupply() external view returns (uint256);
    761 | 
    762 |     /**
    763 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 765 行
- **函数**: `balanceOf()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    762 |     /**
    763 |      * @dev Returns the value of tokens owned by `account`.
    764 |      */
>>  765 |     function balanceOf(address account) external view returns (uint256);
    766 | 
    767 |     /**
    768 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 774 行
- **函数**: `transfer()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    771 |      *
    772 |      * Emits a {Transfer} event.
    773 |      */
>>  774 |     function transfer(address to, uint256 value) external returns (bool);
    775 | 
    776 |     /**
    777 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 783 行
- **函数**: `allowance()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    780 |      *
    781 |      * This value changes when {approve} or {transferFrom} are called.
    782 |      */
>>  783 |     function allowance(address owner, address spender) external view returns (uint256);
    784 | 
    785 |     /**
    786 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 800 行
- **函数**: `approve()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    797 |      *
    798 |      * Emits an {Approval} event.
    799 |      */
>>  800 |     function approve(address spender, uint256 value) external returns (bool);
    801 | 
    802 |     /**
    803 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 811 行
- **函数**: `transferFrom()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    808 |      *
    809 |      * Emits a {Transfer} event.
    810 |      */
>>  811 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    812 | }
    813 | 
    814 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 831 行
- **函数**: `name()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    828 |     /**
    829 |      * @dev Returns the name of the token.
    830 |      */
>>  831 |     function name() external view returns (string memory);
    832 | 
    833 |     /**
    834 |      * @dev Returns the symbol of the token.
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 836 行
- **函数**: `symbol()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    833 |     /**
    834 |      * @dev Returns the symbol of the token.
    835 |      */
>>  836 |     function symbol() external view returns (string memory);
    837 | 
    838 |     /**
    839 |      * @dev Returns the decimals places of the token.
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 841 行
- **函数**: `decimals()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    838 |     /**
    839 |      * @dev Returns the decimals places of the token.
    840 |      */
>>  841 |     function decimals() external view returns (uint8);
    842 | }
    843 | 
    844 | 
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 19 行
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     14 |   function sync() external;
     15 | }
     16 | 
     17 | /**
     18 |  * @title Token
>>   19 |  * @dev ERC20 token contract with liquidity pool balancing functionality
     20 |  * Features:
     21 |  * - Whitelist management for exempt addresses
     22 |  * - Sell tax mechanism
     23 |  * - Transfer restrictions from/to liquidity pool
     24 |  * - Automatic liquidity pool balancing
```

---

### 23. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 308 行
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    303 |  *
    304 |  * This module is used through inheritance. It will make available the modifier
    305 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    306 |  * the owner.
    307 |  */
>>  308 | abstract contract Ownable is Context {
    309 |     address private _owner;
    310 | 
    311 |     /**
    312 |      * @dev The caller account is not authorized to perform an operation.
    313 |      */
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 380 行
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    375 |         }
    376 |         _transferOwnership(newOwner);
    377 |     }
    378 | 
    379 |     /**
>>  380 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    381 |      * Internal function without access restriction.
    382 |      */
    383 |     function _transferOwnership(address newOwner) internal virtual {
    384 |         address oldOwner = _owner;
    385 |         _owner = newOwner;
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 421 行
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    416 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    417 |  * instead returning `false` on failure. This behavior is nonetheless
    418 |  * conventional and does not conflict with the expectations of ERC-20
    419 |  * applications.
    420 |  */
>>  421 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    422 |     mapping(address account => uint256) private _balances;
    423 | 
    424 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    425 | 
    426 |     uint256 private _totalSupply;
```

---

### 26. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 258 行
- **函数**: `balancePool()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    255 |      * - Only callable by governance
    256 |      */
    257 |     function balancePool() external onlyGovernance {
>>  258 |         if (block.timestamp < lastBalanceTime + BALANCE_COOLDOWN) revert ErrorCooldown();
    259 |         if (targetRatio > 500) revert InvalidRatio();  // max 5%
    260 |         if (targetPool == address(0)) revert InvalidAddress();
    261 | 
```

---

### 27. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 267 行
- **函数**: `balancePool()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    264 |         _update(targetPool, DEAD, burnAmount);
    265 |        
    266 |         IPancakePair(targetPool).sync();
>>  267 |         lastBalanceTime = block.timestamp;
    268 |         emit BalancePoolBurned(burnAmount);
    269 |     }
    270 | 
```

---

### 28. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x8D65744527f55d0b2338350912d5C99A81ddF0e2` 第 53 行
- **函数**: `sync()`
- **合约**: `with`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     50 |     address public feeReceiver;
     51 | 
     52 |     /// @dev Dead address for token burns
>>   53 |     address public constant DEAD = 0x000000000000000000000000000000000000dEaD;
     54 |     
     55 |     /// @dev Base value for percentage calculations (10000 = 100%)
     56 |     uint256 public constant BASE_100 = 10000;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*