# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:50:46
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x43be8192363899B853a98661e2ea6451940e27e3` |
| contract_name | `AlloXCheck` |
| compiler_version | `v0.8.26+commit.8a97fa7a` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['alloX.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646140` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 7 |
| 🟢 LOW | 5 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 28 行
- **函数**: `checkIn()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
     25 | 
     26 |     /// @notice Check in once per UTC day (resets at 00:00 UTC)
     27 |     function checkIn() external {
>>   28 |         uint256 currentDay = block.timestamp / 1 days;
     29 | 
     30 |         require(
     31 |             lastCheckInDay[msg.sender] < currentDay,
```

---

### 2. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 43 行
- **函数**: `canCheckIn()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
     40 | 
     41 |     /// @notice Returns true if user can check in right now
     42 |     function canCheckIn(address user) external view returns (bool) {
>>   43 |         uint256 currentDay = block.timestamp / 1 days;
     44 |         return lastCheckInDay[user] < currentDay;
     45 |     }
     46 | 
```

---

### 3. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 49 行
- **函数**: `secondsUntilNextReset()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
     46 | 
     47 |     /// @notice Returns seconds remaining until next 00:00 UTC
     48 |     function secondsUntilNextReset() external view returns (uint256) {
>>   49 |         uint256 nextReset = ((block.timestamp / 1 days) + 1) * 1 days;
     50 |         return nextReset - block.timestamp;
     51 |     }
     52 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 27 行
- **函数**: `checkIn()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     24 |     }
     25 | 
     26 |     /// @notice Check in once per UTC day (resets at 00:00 UTC)
>>   27 |     function checkIn() external {
     28 |         uint256 currentDay = block.timestamp / 1 days;
     29 | 
     30 |         require(
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 42 行
- **函数**: `canCheckIn()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     39 |     }
     40 | 
     41 |     /// @notice Returns true if user can check in right now
>>   42 |     function canCheckIn(address user) external view returns (bool) {
     43 |         uint256 currentDay = block.timestamp / 1 days;
     44 |         return lastCheckInDay[user] < currentDay;
     45 |     }
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 48 行
- **函数**: `secondsUntilNextReset()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     45 |     }
     46 | 
     47 |     /// @notice Returns seconds remaining until next 00:00 UTC
>>   48 |     function secondsUntilNextReset() external view returns (uint256) {
     49 |         uint256 nextReset = ((block.timestamp / 1 days) + 1) * 1 days;
     50 |         return nextReset - block.timestamp;
     51 |     }
```

---

### 7. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 6 行
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      1 | // ── alloX.sol ──────────────────────────────
      2 | 
      3 | // SPDX-License-Identifier: MIT
      4 | pragma solidity ^0.8.0;
      5 | 
>>    6 | contract AlloXCheck {
      7 |     address public owner;
      8 | 
      9 |     // Total lifetime check-ins per user
     10 |     mapping(address => uint256) public lifetimeCheckInCount;
     11 | 
```

---

### 8. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 28 行
- **函数**: `checkIn()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     25 | 
     26 |     /// @notice Check in once per UTC day (resets at 00:00 UTC)
     27 |     function checkIn() external {
>>   28 |         uint256 currentDay = block.timestamp / 1 days;
     29 | 
     30 |         require(
     31 |             lastCheckInDay[msg.sender] < currentDay,
```

---

### 9. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 38 行
- **函数**: `checkIn()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     35 |         lastCheckInDay[msg.sender] = currentDay;
     36 |         lifetimeCheckInCount[msg.sender] += 1;
     37 | 
>>   38 |         emit CheckedIn(msg.sender, currentDay, block.timestamp);
     39 |     }
     40 | 
     41 |     /// @notice Returns true if user can check in right now
```

---

### 10. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 43 行
- **函数**: `canCheckIn()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     40 | 
     41 |     /// @notice Returns true if user can check in right now
     42 |     function canCheckIn(address user) external view returns (bool) {
>>   43 |         uint256 currentDay = block.timestamp / 1 days;
     44 |         return lastCheckInDay[user] < currentDay;
     45 |     }
     46 | 
```

---

### 11. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 49 行
- **函数**: `secondsUntilNextReset()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     46 | 
     47 |     /// @notice Returns seconds remaining until next 00:00 UTC
     48 |     function secondsUntilNextReset() external view returns (uint256) {
>>   49 |         uint256 nextReset = ((block.timestamp / 1 days) + 1) * 1 days;
     50 |         return nextReset - block.timestamp;
     51 |     }
     52 | 
```

---

### 12. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x43be8192363899B853a98661e2ea6451940e27e3` 第 50 行
- **函数**: `secondsUntilNextReset()`
- **合约**: `AlloXCheck`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     47 |     /// @notice Returns seconds remaining until next 00:00 UTC
     48 |     function secondsUntilNextReset() external view returns (uint256) {
     49 |         uint256 nextReset = ((block.timestamp / 1 days) + 1) * 1 days;
>>   50 |         return nextReset - block.timestamp;
     51 |     }
     52 | 
     53 |     /// @notice Transfer contract ownership
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*