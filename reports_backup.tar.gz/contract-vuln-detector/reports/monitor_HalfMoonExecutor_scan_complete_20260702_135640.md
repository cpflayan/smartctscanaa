# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:56:40
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` |
| contract_name | `HalfMoonExecutor` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `True` |
| runs | `1000000` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/HalfMoonExecutor.sol', 'lib/solmate/src/auth/Owned.sol', 'lib/solmate/src/utils/SafeTransferLib.sol', 'lib/solmate/src/tokens/ERC20.sol', 'src/pancake-x/interfaces/IReactorCallback.sol', 'src/pancake-x/interfaces/IReactor.sol', 'src/pancake-x/base/ReactorStructs.sol', 'src/rfq/interfaces/ISettlement.sol', 'src/rfq/libraries/RFQLib.sol', 'src/pancake-x/interfaces/IValidationCallback.sol', 'lib/openzeppelin-contracts/contracts/utils/cryptography/ECDSA.sol', 'lib/prb-math/src/UD60x18.sol', 'lib/prb-math/src/ud60x18/Casting.sol', 'lib/prb-math/src/ud60x18/Constants.sol', 'lib/prb-math/src/ud60x18/Conversions.sol', 'lib/prb-math/src/ud60x18/Errors.sol', 'lib/prb-math/src/ud60x18/Helpers.sol', 'lib/prb-math/src/ud60x18/Math.sol', 'lib/prb-math/src/ud60x18/ValueType.sol', 'lib/prb-math/src/Common.sol', 'lib/prb-math/src/sd1x18/Constants.sol', 'lib/prb-math/src/sd1x18/ValueType.sol', 'lib/prb-math/src/sd21x18/Constants.sol', 'lib/prb-math/src/sd21x18/ValueType.sol', 'lib/prb-math/src/sd59x18/Constants.sol', 'lib/prb-math/src/sd59x18/ValueType.sol', 'lib/prb-math/src/ud2x18/Constants.sol', 'lib/prb-math/src/ud21x18/Constants.sol', 'lib/prb-math/src/ud2x18/ValueType.sol', 'lib/prb-math/src/ud21x18/ValueType.sol', 'lib/prb-math/src/sd1x18/Casting.sol', 'lib/prb-math/src/sd21x18/Casting.sol', 'lib/prb-math/src/sd59x18/Casting.sol', 'lib/prb-math/src/sd59x18/Helpers.sol', 'lib/prb-math/src/sd59x18/Math.sol', 'lib/prb-math/src/ud2x18/Casting.sol', 'lib/prb-math/src/ud21x18/Casting.sol', 'lib/prb-math/src/sd1x18/Errors.sol', 'lib/prb-math/src/sd21x18/Errors.sol', 'lib/prb-math/src/sd59x18/Errors.sol', 'lib/prb-math/src/ud2x18/Errors.sol', 'lib/prb-math/src/ud21x18/Errors.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646141` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 19 |
| 🟢 LOW | 18 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 982 行
- **函数**: `decayedAmountOut()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    979 |         }
    980 | 
    981 |         uint256 maxDropAmt = (amountOut * cev.confidenceExtractedValueM) / 10_000;
>>  982 |         uint256 elapsed = block.timestamp - cev.confidenceExtractedValueN;
    983 | 
    984 |         if (elapsed >= cev.confidenceExtractedValueT) {
    985 |             return amountOut - maxDropAmt;
```

---

### 2. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 152 行
- **函数**: `reactorCallback()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    149 |         if (nativeOut) {
    150 |             // Push native BNB to the reactor. Reactor's _fill forwards to swapper
    151 |             // and refunds any excess back to this executor (msg.sender in _fill).
>>  152 |             (bool ok,) = msg.sender.call{value: outputReceived}("");
    153 |             if (!ok) revert NativeTransferFailed();
    154 |         } else {
    155 |             ERC20(outputToken).safeApprove(msg.sender, outputReceived);
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 474 行
- **函数**: `approve()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    471 |                                ERC20 LOGIC
    472 |     //////////////////////////////////////////////////////////////*/
    473 | 
>>  474 |     function approve(address spender, uint256 amount) public virtual returns (bool) {
    475 |         allowance[msg.sender][spender] = amount;
    476 | 
    477 |         emit Approval(msg.sender, spender, amount);
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 482 行
- **函数**: `transfer()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    479 |         return true;
    480 |     }
    481 | 
>>  482 |     function transfer(address to, uint256 amount) public virtual returns (bool) {
    483 |         balanceOf[msg.sender] -= amount;
    484 | 
    485 |         // Cannot overflow because the sum of all user
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 568 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    565 |         emit Approval(owner, spender, value);
    566 |     }
    567 | 
>>  568 |     function DOMAIN_SEPARATOR() public view virtual returns (bytes32) {
    569 |         return block.chainid == INITIAL_CHAIN_ID ? INITIAL_DOMAIN_SEPARATOR : computeDomainSeparator();
    570 |     }
    571 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 644 行
- **函数**: `execute()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    641 | interface IReactor {
    642 |     /// @notice Execute a single order
    643 |     /// @param order The order definition and valid signature to execute
>>  644 |     function execute(SignedOrder calldata order) external payable;
    645 | 
    646 |     /// @notice Execute a single order using the given callback data
    647 |     /// @param order The order definition and valid signature to execute
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 648 行
- **函数**: `executeWithCallback()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    645 | 
    646 |     /// @notice Execute a single order using the given callback data
    647 |     /// @param order The order definition and valid signature to execute
>>  648 |     function executeWithCallback(SignedOrder calldata order, bytes calldata callbackData) external payable;
    649 | 
    650 |     /// @notice Execute the given orders at once
    651 |     /// @param orders The order definitions and valid signatures to execute
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 652 行
- **函数**: `executeBatch()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    649 | 
    650 |     /// @notice Execute the given orders at once
    651 |     /// @param orders The order definitions and valid signatures to execute
>>  652 |     function executeBatch(SignedOrder[] calldata orders) external payable;
    653 | 
    654 |     /// @notice Execute the given orders at once using a callback with the given callback data
    655 |     /// @param orders The order definitions and valid signatures to execute
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 657 行
- **函数**: `executeBatchWithCallback()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    654 |     /// @notice Execute the given orders at once using a callback with the given callback data
    655 |     /// @param orders The order definitions and valid signatures to execute
    656 |     /// @param callbackData The callbackData to pass to the callback
>>  657 |     function executeBatchWithCallback(SignedOrder[] calldata orders, bytes calldata callbackData) external payable;
    658 | }
    659 | 
    660 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 750 行
- **函数**: `WETH9()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    747 |         returns (uint256 amountOut, uint256 feeAmount);
    748 | 
    749 |     /// @notice WETH9 address used for native token resolution
>>  750 |     function WETH9() external view returns (address);
    751 | 
    752 |     /// @notice RFQ settle callback, invoked by Vault to pull full validated input amount in one transfer
    753 |     function rfqSettleCallback() external;
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 879 行
- **函数**: `hashRFQQuotes()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    876 |     }
    877 | 
    878 |     /// @notice Hash an RFQ quote array for Permit2 witness binding.
>>  879 |     function hashRFQQuotes(RFQQuote[] calldata quotes) public pure returns (bytes32 quotesHash) {
    880 |         bytes32[] memory quoteHashes = new bytes32[](quotes.length);
    881 |         for (uint256 i; i < quotes.length;) {
    882 |             quoteHashes[i] = hashRFQQuote(quotes[i]);
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 908 行
- **函数**: `recover()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    905 | 
    906 |     /// @notice Recover signer from digest and signature (uses OpenZeppelin ECDSA).
    907 |     /// @dev Digest should be from EIP712._hashTypedDataV4(structHash) in your contract.
>>  908 |     function recover(bytes32 digest, bytes memory signature) public pure returns (address) {
    909 |         return ECDSA.recover(digest, signature);
    910 |     }
    911 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 916 行
- **函数**: `recoverMMQuoteSigner()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    913 |     /// @param q The MMQuote whose mmSignature will be verified.
    914 |     /// @param domainSep The EIP-712 domain separator of the verifying contract.
    915 |     /// @return signer The address that signed the MMQuote.
>>  916 |     function recoverMMQuoteSigner(MMQuote calldata q, bytes32 domainSep) public pure returns (address signer) {
    917 |         bytes32 structHash = hashMMQuote(q);
    918 |         bytes32 digest = keccak256(abi.encodePacked("\x19\x01", domainSep, structHash));
    919 |         signer = ECDSA.recover(digest, q.mmSignature);
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 926 行
- **函数**: `recoverRFQQuoteSigner()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    923 |     /// @param q The RFQQuote whose rfqSignature will be verified.
    924 |     /// @param domainSep The EIP-712 domain separator of the verifying contract.
    925 |     /// @return signer The address that signed the RFQQuote.
>>  926 |     function recoverRFQQuoteSigner(RFQQuote calldata q, bytes32 domainSep) public pure returns (address signer) {
    927 |         bytes32 structHash = hashRFQQuote(q);
    928 |         bytes32 digest = keccak256(abi.encodePacked("\x19\x01", domainSep, structHash));
    929 |         signer = ECDSA.recover(digest, q.rfqSignature);
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 1015 行
- **函数**: `validate()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1012 |     /// @notice Called by the reactor for custom validation of an order. Will revert if validation fails
   1013 |     /// @param filler The filler of the order
   1014 |     /// @param resolvedOrder The resolved order to fill
>> 1015 |     function validate(address filler, ResolvedOrder calldata resolvedOrder) external view;
   1016 | }
   1017 | 
   1018 | 
```

---

### 16. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 15 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     10 | import {IReactor} from "pancake-x/interfaces/IReactor.sol";
     11 | import {ResolvedOrder, SignedOrder} from "pancake-x/base/ReactorStructs.sol";
     12 | import {ISettlement} from "rfq/interfaces/ISettlement.sol";
     13 | import {RFQLib} from "rfq/libraries/RFQLib.sol";
     14 | 
>>   15 | /// @notice A fill contract that uses HalfMoon RFQ Settlement to execute single orders; supports multiple whitelisted reactors
     16 | contract HalfMoonExecutor is IReactorCallback, Owned {
     17 |     using SafeTransferLib for ERC20;
     18 | 
     19 |     /// @notice thrown if reactorCallback is called with a non-whitelisted filler
     20 |     error CallerNotWhitelisted();
```

---

### 17. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 236 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    231 | // SPDX-License-Identifier: MIT
    232 | pragma solidity >=0.8.0;
    233 | 
    234 | /// @notice Simple single owner authorization mixin.
    235 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/auth/Owned.sol)
>>  236 | abstract contract Owned {
    237 |     /*//////////////////////////////////////////////////////////////
    238 |                                  EVENTS
    239 |     //////////////////////////////////////////////////////////////*/
    240 | 
    241 |     event OwnershipTransferred(address indexed user, address indexed newOwner);
```

---

### 18. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 414 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    409 | 
    410 | /// @notice Modern and gas efficient ERC20 + EIP-2612 implementation.
    411 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC20.sol)
    412 | /// @author Modified from Uniswap (https://github.com/Uniswap/uniswap-v2-core/blob/master/contracts/UniswapV2ERC20.sol)
    413 | /// @dev Do not manually set balances without updating totalSupply, as the sum of all user balances must not exceed it.
>>  414 | abstract contract ERC20 {
    415 |     /*//////////////////////////////////////////////////////////////
    416 |                                  EVENTS
    417 |     //////////////////////////////////////////////////////////////*/
    418 | 
    419 |     event Transfer(address indexed from, address indexed to, uint256 amount);
```

---

### 19. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 715 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    710 |     bytes sig;
    711 |     bytes32 hash;
    712 | }
    713 | 
    714 | /// @dev external struct including a generic encoded order and swapper signature
>>  715 | ///  The order bytes will be parsed and mapped to a ResolvedOrder in the concrete reactor contract
    716 | struct SignedOrder {
    717 |     bytes order;
    718 |     bytes sig;
    719 | }
    720 | 
```

---

### 20. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 531 行
- **函数**: `permit()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    528 |         bytes32 r,
    529 |         bytes32 s
    530 |     ) public virtual {
>>  531 |         require(deadline >= block.timestamp, "PERMIT_DEADLINE_EXPIRED");
    532 | 
    533 |         // Unchecked because the only math done is incrementing
    534 |         // the owner's nonce which cannot realistically overflow.
```

---

### 21. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 976 行
- **函数**: `decayedAmountOut()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    973 |     {
    974 |         if (
    975 |             cev.confidenceExtractedValueM == 0 || cev.confidenceExtractedValueT == 0
>>  976 |                 || block.timestamp <= cev.confidenceExtractedValueN
    977 |         ) {
    978 |             return amountOut;
    979 |         }
```

---

### 22. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 982 行
- **函数**: `decayedAmountOut()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    979 |         }
    980 | 
    981 |         uint256 maxDropAmt = (amountOut * cev.confidenceExtractedValueM) / 10_000;
>>  982 |         uint256 elapsed = block.timestamp - cev.confidenceExtractedValueN;
    983 | 
    984 |         if (elapsed >= cev.confidenceExtractedValueT) {
    985 |             return amountOut - maxDropAmt;
```

---

### 23. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 49 行
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     46 |     /// @dev uint256 internal constant TRANSIENT_CALLBACK_HASH_SLOT =
     47 |     /// uint256(keccak256("HalfMoonExecutor.transientHash")) - 1;
     48 |     uint256 internal constant TRANSIENT_CALLBACK_HASH_SLOT =
>>   49 |         0x2f0a388e1d32947365ec9bab44413e614ee34a7fee4e312ab3fa57a8b652a843;
     50 | 
     51 |     /// @notice callers allowed to invoke execute
     52 |     mapping(address => bool) public callerWhitelist;
```

---

### 24. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 322 行
- **函数**: `safeTransferFrom()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    319 |             let freeMemoryPointer := mload(0x40)
    320 | 
    321 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>>  322 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
    323 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
    324 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
    325 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
```

---

### 25. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 323 行
- **函数**: `safeTransferFrom()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    320 | 
    321 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
    322 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
>>  323 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
    324 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
    325 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
    326 | 
```

---

### 26. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 324 行
- **函数**: `safeTransferFrom()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    321 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
    322 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
    323 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
>>  324 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
    325 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
    326 | 
    327 |             // We use 100 because the length of our calldata totals up like so: 4 + 32 * 3.
```

---

### 27. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 354 行
- **函数**: `safeTransfer()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    351 |             let freeMemoryPointer := mload(0x40)
    352 | 
    353 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>>  354 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
    355 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
    356 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
    357 | 
```

---

### 28. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 355 行
- **函数**: `safeTransfer()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    352 | 
    353 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
    354 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>>  355 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
    356 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
    357 | 
    358 |             // We use 68 because the length of our calldata totals up like so: 4 + 32 * 2.
```

---

### 29. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 385 行
- **函数**: `safeApprove()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    382 |             let freeMemoryPointer := mload(0x40)
    383 | 
    384 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>>  385 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
    386 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
    387 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
    388 | 
```

---

### 30. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 386 行
- **函数**: `safeApprove()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    383 | 
    384 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
    385 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
>>  386 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
    387 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
    388 | 
    389 |             // We use 68 because the length of our calldata totals up like so: 4 + 32 * 2.
```

---

### 31. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 1170 行
- **函数**: `tryRecover()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1167 |         bytes32 vs
   1168 |     ) internal pure returns (address recovered, RecoverError err, bytes32 errArg) {
   1169 |         unchecked {
>> 1170 |             bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
   1171 |             // We do not check for an overflow here since the shift operation results in 0 or 1.
   1172 |             uint8 v = uint8((uint256(vs) >> 255) + 27);
   1173 |             return tryRecover(hash, v, r, s);
```

---

### 32. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 1205 行
- **函数**: `tryRecover()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1202 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
   1203 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
   1204 |         // these malleable signatures as well.
>> 1205 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
   1206 |             return (address(0), RecoverError.InvalidSignatureS, s);
   1207 |         }
   1208 | 
```

---

### 33. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 2451 行
- **函数**: `exp2()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2448 | function exp2(uint256 x) pure returns (uint256 result) {
   2449 |     unchecked {
   2450 |         // Start from 0.5 in the 192.64-bit fixed-point format.
>> 2451 |         result = 0x800000000000000000000000000000000000000000000000;
   2452 | 
   2453 |         // The following logic multiplies the result by $\sqrt{2^{-i}}$ when the bit at position i is 1. Key points:
   2454 |         //
```

---

### 34. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 296 行
- **函数**: `safeTransferETH()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    293 |         bool success;
    294 | 
    295 |         /// @solidity memory-safe-assembly
>>  296 |         assembly {
    297 |             // Transfer the ETH and store if it succeeded or not.
    298 |             success := call(gas(), to, amount, 0, 0, 0, 0)
    299 |         }
```

---

### 35. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 317 行
- **函数**: `safeTransferFrom()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    314 |         bool success;
    315 | 
    316 |         /// @solidity memory-safe-assembly
>>  317 |         assembly {
    318 |             // Get a pointer to some free memory.
    319 |             let freeMemoryPointer := mload(0x40)
    320 | 
```

---

### 36. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 349 行
- **函数**: `safeTransfer()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    346 |         bool success;
    347 | 
    348 |         /// @solidity memory-safe-assembly
>>  349 |         assembly {
    350 |             // Get a pointer to some free memory.
    351 |             let freeMemoryPointer := mload(0x40)
    352 | 
```

---

### 37. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xb4A18c0D1306297F7fd4403884Ab0DEd263fCF0e` 第 380 行
- **函数**: `safeApprove()`
- **合约**: `that`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    377 |         bool success;
    378 | 
    379 |         /// @solidity memory-safe-assembly
>>  380 |         assembly {
    381 |             // Get a pointer to some free memory.
    382 |             let freeMemoryPointer := mload(0x40)
    383 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*