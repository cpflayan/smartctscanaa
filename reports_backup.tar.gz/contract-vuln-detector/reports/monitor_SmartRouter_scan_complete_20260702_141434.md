# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:14:34
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` |
| contract_name | `SmartRouter` |
| compiler_version | `v0.7.6+commit.7338295f` |
| optimization_used | `True` |
| runs | `10` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `True` |
| implementation | `0x13f4ea83d0bd40e75c8222255bc855a974568dd4` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/drafts/IERC20Permit.sol', '@openzeppelin/contracts/introspection/IERC165.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC721/IERC721.sol', '@openzeppelin/contracts/token/ERC721/IERC721Enumerable.sol', '@openzeppelin/contracts/token/ERC721/IERC721Metadata.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/utils/ReentrancyGuard.sol', '@pancakeswap/v3-core/contracts/interfaces/callback/IPancakeV3SwapCallback.sol', '@pancakeswap/v3-core/contracts/interfaces/IPancakeV3Pool.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolActions.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolDerivedState.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolEvents.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolImmutables.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolOwnerActions.sol', '@pancakeswap/v3-core/contracts/interfaces/pool/IPancakeV3PoolState.sol', '@pancakeswap/v3-core/contracts/libraries/FullMath.sol', '@pancakeswap/v3-core/contracts/libraries/LowGasSafeMath.sol', '@pancakeswap/v3-core/contracts/libraries/SafeCast.sol', '@pancakeswap/v3-core/contracts/libraries/TickMath.sol', '@pancakeswap/v3-periphery/contracts/base/BlockTimestamp.sol', '@pancakeswap/v3-periphery/contracts/base/Multicall.sol', '@pancakeswap/v3-periphery/contracts/base/PeripheryImmutableState.sol', '@pancakeswap/v3-periphery/contracts/base/PeripheryPayments.sol', '@pancakeswap/v3-periphery/contracts/base/PeripheryPaymentsWithFee.sol', '@pancakeswap/v3-periphery/contracts/base/PeripheryValidation.sol', '@pancakeswap/v3-periphery/contracts/base/SelfPermit.sol', '@pancakeswap/v3-periphery/contracts/interfaces/external/IERC20PermitAllowed.sol', '@pancakeswap/v3-periphery/contracts/interfaces/external/IWETH9.sol', '@pancakeswap/v3-periphery/contracts/interfaces/IERC721Permit.sol', '@pancakeswap/v3-periphery/contracts/interfaces/IMulticall.sol', '@pancakeswap/v3-periphery/contracts/interfaces/INonfungiblePositionManager.sol', '@pancakeswap/v3-periphery/contracts/interfaces/IPeripheryImmutableState.sol', '@pancakeswap/v3-periphery/contracts/interfaces/IPeripheryPayments.sol', '@pancakeswap/v3-periphery/contracts/interfaces/IPeripheryPaymentsWithFee.sol', '@pancakeswap/v3-periphery/contracts/interfaces/IPoolInitializer.sol', '@pancakeswap/v3-periphery/contracts/interfaces/ISelfPermit.sol', '@pancakeswap/v3-periphery/contracts/libraries/BytesLib.sol', '@pancakeswap/v3-periphery/contracts/libraries/OracleLibrary.sol', '@pancakeswap/v3-periphery/contracts/libraries/Path.sol', '@pancakeswap/v3-periphery/contracts/libraries/PoolAddress.sol', '@pancakeswap/v3-periphery/contracts/libraries/TransferHelper.sol', '@uniswap/v2-core/contracts/interfaces/IUniswapV2Pair.sol', 'contracts/base/ApproveAndCall.sol', 'contracts/base/ImmutableState.sol', 'contracts/base/MulticallExtended.sol', 'contracts/base/OracleSlippage.sol', 'contracts/base/PeripheryPaymentsExtended.sol', 'contracts/base/PeripheryPaymentsWithFeeExtended.sol', 'contracts/base/PeripheryValidationExtended.sol', 'contracts/interfaces/IApproveAndCall.sol', 'contracts/interfaces/IImmutableState.sol', 'contracts/interfaces/IMulticallExtended.sol', 'contracts/interfaces/IOracleSlippage.sol', 'contracts/interfaces/IPeripheryPaymentsExtended.sol', 'contracts/interfaces/IPeripheryPaymentsWithFeeExtended.sol', 'contracts/interfaces/ISmartRouter.sol', 'contracts/interfaces/IStableSwap.sol', 'contracts/interfaces/IStableSwapFactory.sol', 'contracts/interfaces/IStableSwapInfo.sol', 'contracts/interfaces/IStableSwapRouter.sol', 'contracts/interfaces/IV2SwapRouter.sol', 'contracts/interfaces/IV3SwapRouter.sol', 'contracts/libraries/Constants.sol', 'contracts/libraries/SmartRouterHelper.sol', 'contracts/SmartRouter.sol', 'contracts/StableSwapRouter.sol', 'contracts/V2SwapRouter.sol', 'contracts/V3SwapRouter.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 142 |
| 🟢 LOW | 50 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1505 行
- **函数**: `multicall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1502 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
   1503 |         results = new bytes[](data.length);
   1504 |         for (uint256 i = 0; i < data.length; i++) {
>> 1505 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
   1506 | 
   1507 |             if (!success) {
   1508 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2757 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2754 |     function factory() external view returns (address);
   2755 |     function token0() external view returns (address);
   2756 |     function token1() external view returns (address);
>> 2757 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2758 |     function price0CumulativeLast() external view returns (uint);
   2759 |     function price1CumulativeLast() external view returns (uint);
   2760 |     function kLast() external view returns (uint);
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3822 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   3819 |         address tokenB
   3820 |     ) public view returns (uint256 reserveA, uint256 reserveB) {
   3821 |         (address token0, ) = sortTokens(tokenA, tokenB);
>> 3822 |         (uint256 reserve0, uint256 reserve1, ) = IUniswapV2Pair(pairFor(factory, tokenA, tokenB)).getReserves();
   3823 |         (reserveA, reserveB) = tokenA == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
   3824 |     }
   3825 | 
```

---

### 4. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 4143 行
- **函数**: `_swap()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   4140 |             uint256 amountOutput;
   4141 |             // scope to avoid stack too deep errors
   4142 |             {
>> 4143 |                 (uint256 reserve0, uint256 reserve1, ) = pair.getReserves();
   4144 |                 (uint256 reserveInput, uint256 reserveOutput) =
   4145 |                     input == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
   4146 |                 amountInput = IERC20(input).balanceOf(address(pair)).sub(reserveInput);
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2673 行
- **函数**: `safeTransferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   2670 |         uint256 value
   2671 |     ) internal {
   2672 |         (bool success, bytes memory data) =
>> 2673 |             token.call(abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, value));
   2674 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'STF');
   2675 |     }
   2676 | 
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2687 行
- **函数**: `safeTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   2684 |         address to,
   2685 |         uint256 value
   2686 |     ) internal {
>> 2687 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transfer.selector, to, value));
   2688 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'ST');
   2689 |     }
   2690 | 
```

---

### 7. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2701 行
- **函数**: `safeApprove()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   2698 |         address to,
   2699 |         uint256 value
   2700 |     ) internal {
>> 2701 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.approve.selector, to, value));
   2702 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'SA');
   2703 |     }
   2704 | 
```

---

### 8. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2710 行
- **函数**: `safeTransferETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   2707 |     /// @param to The destination of the transfer
   2708 |     /// @param value The value to be transferred
   2709 |     function safeTransferETH(address to, uint256 value) internal {
>> 2710 |         (bool success, ) = to.call{value: value}(new bytes(0));
   2711 |         require(success, 'STE');
   2712 |     }
   2713 | }
```

---

### 9. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2790 行
- **函数**: `tryApprove()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   2787 | abstract contract ApproveAndCall is IApproveAndCall, ImmutableState {
   2788 |     function tryApprove(address token, uint256 amount) private returns (bool) {
   2789 |         (bool success, bytes memory data) =
>> 2790 |             token.call(abi.encodeWithSelector(IERC20.approve.selector, positionManager, amount));
   2791 |         return success && (data.length == 0 || abi.decode(data, (bool)));
   2792 |     }
   2793 | 
```

---

### 10. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2838 行
- **函数**: `callPositionManager()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   2835 |     /// @inheritdoc IApproveAndCall
   2836 |     function callPositionManager(bytes memory data) public payable override returns (bytes memory result) {
   2837 |         bool success;
>> 2838 |         (success, result) = positionManager.call(data);
   2839 | 
   2840 |         if (!success) {
   2841 |             // Next 5 lines from https://ethereum.stackexchange.com/a/83577
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 37 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     34 |     /**
     35 |      * @dev Returns the address of the current owner.
     36 |      */
>>   37 |     function owner() public view virtual returns (address) {
     38 |         return _owner;
     39 |     }
     40 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 118 行
- **函数**: `nonces()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    115 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
    116 |      * prevents a signature from being used multiple times.
    117 |      */
>>  118 |     function nonces(address owner) external view returns (uint256);
    119 | 
    120 |     /**
    121 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 124 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    121 |      * @dev Returns the domain separator used in the encoding of the signature for `permit`, as defined by {EIP712}.
    122 |      */
    123 |     // solhint-disable-next-line func-name-mixedcase
>>  124 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    125 | }
    126 | 
    127 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 152 行
- **函数**: `supportsInterface()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    149 |      *
    150 |      * This function call must use less than 30 000 gas.
    151 |      */
>>  152 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
    153 | }
    154 | 
    155 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 169 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    166 |     /**
    167 |      * @dev Returns the amount of tokens in existence.
    168 |      */
>>  169 |     function totalSupply() external view returns (uint256);
    170 | 
    171 |     /**
    172 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 174 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    171 |     /**
    172 |      * @dev Returns the amount of tokens owned by `account`.
    173 |      */
>>  174 |     function balanceOf(address account) external view returns (uint256);
    175 | 
    176 |     /**
    177 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 183 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    180 |      *
    181 |      * Emits a {Transfer} event.
    182 |      */
>>  183 |     function transfer(address recipient, uint256 amount) external returns (bool);
    184 | 
    185 |     /**
    186 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 192 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    189 |      *
    190 |      * This value changes when {approve} or {transferFrom} are called.
    191 |      */
>>  192 |     function allowance(address owner, address spender) external view returns (uint256);
    193 | 
    194 |     /**
    195 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 208 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    205 |      *
    206 |      * Emits an {Approval} event.
    207 |      */
>>  208 |     function approve(address spender, uint256 amount) external returns (bool);
    209 | 
    210 |     /**
    211 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 219 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    216 |      *
    217 |      * Emits a {Transfer} event.
    218 |      */
>>  219 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    220 | 
    221 |     /**
    222 |      * @dev Emitted when `value` tokens are moved from one account (`from`) to
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 267 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    264 |     /**
    265 |      * @dev Returns the number of tokens in ``owner``'s account.
    266 |      */
>>  267 |     function balanceOf(address owner) external view returns (uint256 balance);
    268 | 
    269 |     /**
    270 |      * @dev Returns the owner of the `tokenId` token.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 276 行
- **函数**: `ownerOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    273 |      *
    274 |      * - `tokenId` must exist.
    275 |      */
>>  276 |     function ownerOf(uint256 tokenId) external view returns (address owner);
    277 | 
    278 |     /**
    279 |      * @dev Safely transfers `tokenId` token from `from` to `to`, checking first that contract recipients
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 332 行
- **函数**: `getApproved()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    329 |      *
    330 |      * - `tokenId` must exist.
    331 |      */
>>  332 |     function getApproved(uint256 tokenId) external view returns (address operator);
    333 | 
    334 |     /**
    335 |      * @dev Approve or remove `operator` as an operator for the caller.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 351 行
- **函数**: `isApprovedForAll()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    348 |      *
    349 |      * See {setApprovalForAll}
    350 |      */
>>  351 |     function isApprovedForAll(address owner, address operator) external view returns (bool);
    352 | 
    353 |     /**
    354 |       * @dev Safely transfers `tokenId` token from `from` to `to`.
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 387 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    384 |     /**
    385 |      * @dev Returns the total amount of tokens stored by the contract.
    386 |      */
>>  387 |     function totalSupply() external view returns (uint256);
    388 | 
    389 |     /**
    390 |      * @dev Returns a token ID owned by `owner` at a given `index` of its token list.
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 393 行
- **函数**: `tokenOfOwnerByIndex()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    390 |      * @dev Returns a token ID owned by `owner` at a given `index` of its token list.
    391 |      * Use along with {balanceOf} to enumerate all of ``owner``'s tokens.
    392 |      */
>>  393 |     function tokenOfOwnerByIndex(address owner, uint256 index) external view returns (uint256 tokenId);
    394 | 
    395 |     /**
    396 |      * @dev Returns a token ID at a given `index` of all the tokens stored by the contract.
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 399 行
- **函数**: `tokenByIndex()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    396 |      * @dev Returns a token ID at a given `index` of all the tokens stored by the contract.
    397 |      * Use along with {totalSupply} to enumerate all tokens.
    398 |      */
>>  399 |     function tokenByIndex(uint256 index) external view returns (uint256);
    400 | }
    401 | 
    402 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 420 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    417 |     /**
    418 |      * @dev Returns the token collection name.
    419 |      */
>>  420 |     function name() external view returns (string memory);
    421 | 
    422 |     /**
    423 |      * @dev Returns the token collection symbol.
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 425 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    422 |     /**
    423 |      * @dev Returns the token collection symbol.
    424 |      */
>>  425 |     function symbol() external view returns (string memory);
    426 | 
    427 |     /**
    428 |      * @dev Returns the Uniform Resource Identifier (URI) for `tokenId` token.
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 430 行
- **函数**: `tokenURI()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    427 |     /**
    428 |      * @dev Returns the Uniform Resource Identifier (URI) for `tokenId` token.
    429 |      */
>>  430 |     function tokenURI(uint256 tokenId) external view returns (string memory);
    431 | }
    432 | 
    433 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 876 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    873 | interface IPancakeV3PoolImmutables {
    874 |     /// @notice The contract that deployed the pool, which must adhere to the IPancakeV3Factory interface
    875 |     /// @return The contract address
>>  876 |     function factory() external view returns (address);
    877 | 
    878 |     /// @notice The first of the two tokens of the pool, sorted by address
    879 |     /// @return The token contract address
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 880 行
- **函数**: `token0()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    877 | 
    878 |     /// @notice The first of the two tokens of the pool, sorted by address
    879 |     /// @return The token contract address
>>  880 |     function token0() external view returns (address);
    881 | 
    882 |     /// @notice The second of the two tokens of the pool, sorted by address
    883 |     /// @return The token contract address
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 884 行
- **函数**: `token1()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    881 | 
    882 |     /// @notice The second of the two tokens of the pool, sorted by address
    883 |     /// @return The token contract address
>>  884 |     function token1() external view returns (address);
    885 | 
    886 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
    887 |     /// @return The fee
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 888 行
- **函数**: `fee()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    885 | 
    886 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
    887 |     /// @return The fee
>>  888 |     function fee() external view returns (uint24);
    889 | 
    890 |     /// @notice The pool tick spacing
    891 |     /// @dev Ticks can only be used at multiples of this value, minimum of 1 and always positive
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 895 行
- **函数**: `tickSpacing()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    892 |     /// e.g.: a tickSpacing of 3 means ticks can be initialized every 3rd tick, i.e., ..., -6, -3, 0, 3, 6, ...
    893 |     /// This value is an int24 to avoid casting even though it is always positive.
    894 |     /// @return The tick spacing
>>  895 |     function tickSpacing() external view returns (int24);
    896 | 
    897 |     /// @notice The maximum amount of position liquidity that can use any tick in the range
    898 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 901 行
- **函数**: `maxLiquidityPerTick()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    898 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
    899 |     /// also prevents out-of-range liquidity from being used to prevent adding in-range liquidity to a pool
    900 |     /// @return The max amount of liquidity per tick
>>  901 |     function maxLiquidityPerTick() external view returns (uint128);
    902 | }
    903 | 
    904 | 
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 972 行
- **函数**: `feeGrowthGlobal0X128()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    969 | 
    970 |     /// @notice The fee growth as a Q128.128 fees of token0 collected per unit of liquidity for the entire life of the pool
    971 |     /// @dev This value can overflow the uint256
>>  972 |     function feeGrowthGlobal0X128() external view returns (uint256);
    973 | 
    974 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
    975 |     /// @dev This value can overflow the uint256
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 976 行
- **函数**: `feeGrowthGlobal1X128()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    973 | 
    974 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
    975 |     /// @dev This value can overflow the uint256
>>  976 |     function feeGrowthGlobal1X128() external view returns (uint256);
    977 | 
    978 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
    979 |     /// @dev Protocol fees will never exceed uint128 max in either token
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 980 行
- **函数**: `protocolFees()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    977 | 
    978 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
    979 |     /// @dev Protocol fees will never exceed uint128 max in either token
>>  980 |     function protocolFees() external view returns (uint128 token0, uint128 token1);
    981 | 
    982 |     /// @notice The currently in range liquidity available to the pool
    983 |     /// @dev This value has no relationship to the total liquidity across all ticks
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 984 行
- **函数**: `liquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    981 | 
    982 |     /// @notice The currently in range liquidity available to the pool
    983 |     /// @dev This value has no relationship to the total liquidity across all ticks
>>  984 |     function liquidity() external view returns (uint128);
    985 | 
    986 |     /// @notice Look up information about a specific tick in the pool
    987 |     /// @param tick The tick to look up
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1015 行
- **函数**: `tickBitmap()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1012 |         );
   1013 | 
   1014 |     /// @notice Returns 256 packed tick initialized boolean values. See TickBitmap for more information
>> 1015 |     function tickBitmap(int16 wordPosition) external view returns (uint256);
   1016 | 
   1017 |     /// @notice Returns the information about a position by the position's key
   1018 |     /// @param key The position's key is a hash of a preimage composed by the owner, tickLower and tickUpper
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1502 行
- **函数**: `multicall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1499 | /// @notice Enables calling multiple methods in a single call to the contract
   1500 | abstract contract Multicall is IMulticall {
   1501 |     /// @inheritdoc IMulticall
>> 1502 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
   1503 |         results = new bytes[](data.length);
   1504 |         for (uint256 i = 0; i < data.length; i++) {
   1505 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1567 行
- **函数**: `unwrapWETH9()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1564 |     }
   1565 | 
   1566 |     /// @inheritdoc IPeripheryPayments
>> 1567 |     function unwrapWETH9(uint256 amountMinimum, address recipient) public payable override {
   1568 |         uint256 balanceWETH9 = IWETH9(WETH9).balanceOf(address(this));
   1569 |         require(balanceWETH9 >= amountMinimum, 'Insufficient WETH9');
   1570 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1592 行
- **函数**: `refundETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1589 |     }
   1590 | 
   1591 |     /// @inheritdoc IPeripheryPayments
>> 1592 |     function refundETH() external payable override {
   1593 |         if (address(this).balance > 0) TransferHelper.safeTransferETH(msg.sender, address(this).balance);
   1594 |     }
   1595 | 
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1803 行
- **函数**: `deposit()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1800 | /// @title Interface for WETH9
   1801 | interface IWETH9 is IERC20 {
   1802 |     /// @notice Deposit ether to get wrapped ether
>> 1803 |     function deposit() external payable;
   1804 | 
   1805 |     /// @notice Withdraw wrapped ether to get ether
   1806 |     function withdraw(uint256) external;
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1822 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1819 | interface IERC721Permit is IERC721 {
   1820 |     /// @notice The permit typehash used in the permit signature
   1821 |     /// @return The typehash for the permit
>> 1822 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   1823 | 
   1824 |     /// @notice The domain separator used in the permit signature
   1825 |     /// @return The domain seperator used in encoding of permit signature
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1826 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1823 | 
   1824 |     /// @notice The domain separator used in the permit signature
   1825 |     /// @return The domain seperator used in encoding of permit signature
>> 1826 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1827 | 
   1828 |     /// @notice Approve of a specific token ID for spending by spender via signature
   1829 |     /// @param spender The account that is being approved
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1859 行
- **函数**: `multicall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1856 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   1857 |     /// @param data The encoded function data for each of the calls to make to this contract
   1858 |     /// @return results The results from each of the calls passed in via data
>> 1859 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results);
   1860 | }
   1861 | 
   1862 | 
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2038 行
- **函数**: `collect()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2035 |     /// amount1Max The maximum amount of token1 to collect
   2036 |     /// @return amount0 The amount of fees collected in token0
   2037 |     /// @return amount1 The amount of fees collected in token1
>> 2038 |     function collect(CollectParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
   2039 | 
   2040 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   2041 |     /// must be collected first.
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2043 行
- **函数**: `burn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2040 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   2041 |     /// must be collected first.
   2042 |     /// @param tokenId The ID of the token that is being burned
>> 2043 |     function burn(uint256 tokenId) external payable;
   2044 | }
   2045 | 
   2046 | 
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2056 行
- **函数**: `deployer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2053 | /// @notice Functions that return immutable state of the router
   2054 | interface IPeripheryImmutableState {
   2055 |     /// @return Returns the address of the PancakeSwap V3 deployer
>> 2056 |     function deployer() external view returns (address);
   2057 | 
   2058 |     /// @return Returns the address of the PancakeSwap V3 factory
   2059 |     function factory() external view returns (address);
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2059 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2056 |     function deployer() external view returns (address);
   2057 | 
   2058 |     /// @return Returns the address of the PancakeSwap V3 factory
>> 2059 |     function factory() external view returns (address);
   2060 | 
   2061 |     /// @return Returns the address of WETH9
   2062 |     function WETH9() external view returns (address);
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2062 行
- **函数**: `WETH9()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2059 |     function factory() external view returns (address);
   2060 | 
   2061 |     /// @return Returns the address of WETH9
>> 2062 |     function WETH9() external view returns (address);
   2063 | }
   2064 | 
   2065 | 
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2078 行
- **函数**: `unwrapWETH9()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2075 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   2076 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
   2077 |     /// @param recipient The address receiving ETH
>> 2078 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external payable;
   2079 | 
   2080 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   2081 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2084 行
- **函数**: `refundETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2081 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
   2082 |     /// that use ether for the input amount. And in PancakeSwap Router, this would be called 
   2083 |     /// at the very end of swap
>> 2084 |     function refundETH() external payable;
   2085 | 
   2086 |     /// @notice Transfers the full amount of a token held by this contract to recipient
   2087 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2724 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2721 |     event Approval(address indexed owner, address indexed spender, uint value);
   2722 |     event Transfer(address indexed from, address indexed to, uint value);
   2723 | 
>> 2724 |     function name() external pure returns (string memory);
   2725 |     function symbol() external pure returns (string memory);
   2726 |     function decimals() external pure returns (uint8);
   2727 |     function totalSupply() external view returns (uint);
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2725 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2722 |     event Transfer(address indexed from, address indexed to, uint value);
   2723 | 
   2724 |     function name() external pure returns (string memory);
>> 2725 |     function symbol() external pure returns (string memory);
   2726 |     function decimals() external pure returns (uint8);
   2727 |     function totalSupply() external view returns (uint);
   2728 |     function balanceOf(address owner) external view returns (uint);
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2726 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2723 | 
   2724 |     function name() external pure returns (string memory);
   2725 |     function symbol() external pure returns (string memory);
>> 2726 |     function decimals() external pure returns (uint8);
   2727 |     function totalSupply() external view returns (uint);
   2728 |     function balanceOf(address owner) external view returns (uint);
   2729 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2727 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2724 |     function name() external pure returns (string memory);
   2725 |     function symbol() external pure returns (string memory);
   2726 |     function decimals() external pure returns (uint8);
>> 2727 |     function totalSupply() external view returns (uint);
   2728 |     function balanceOf(address owner) external view returns (uint);
   2729 |     function allowance(address owner, address spender) external view returns (uint);
   2730 | 
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2728 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2725 |     function symbol() external pure returns (string memory);
   2726 |     function decimals() external pure returns (uint8);
   2727 |     function totalSupply() external view returns (uint);
>> 2728 |     function balanceOf(address owner) external view returns (uint);
   2729 |     function allowance(address owner, address spender) external view returns (uint);
   2730 | 
   2731 |     function approve(address spender, uint value) external returns (bool);
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2729 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2726 |     function decimals() external pure returns (uint8);
   2727 |     function totalSupply() external view returns (uint);
   2728 |     function balanceOf(address owner) external view returns (uint);
>> 2729 |     function allowance(address owner, address spender) external view returns (uint);
   2730 | 
   2731 |     function approve(address spender, uint value) external returns (bool);
   2732 |     function transfer(address to, uint value) external returns (bool);
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2731 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2728 |     function balanceOf(address owner) external view returns (uint);
   2729 |     function allowance(address owner, address spender) external view returns (uint);
   2730 | 
>> 2731 |     function approve(address spender, uint value) external returns (bool);
   2732 |     function transfer(address to, uint value) external returns (bool);
   2733 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2734 | 
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2732 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2729 |     function allowance(address owner, address spender) external view returns (uint);
   2730 | 
   2731 |     function approve(address spender, uint value) external returns (bool);
>> 2732 |     function transfer(address to, uint value) external returns (bool);
   2733 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2734 | 
   2735 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2733 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2730 | 
   2731 |     function approve(address spender, uint value) external returns (bool);
   2732 |     function transfer(address to, uint value) external returns (bool);
>> 2733 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2734 | 
   2735 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2736 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2735 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2732 |     function transfer(address to, uint value) external returns (bool);
   2733 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2734 | 
>> 2735 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2736 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   2737 |     function nonces(address owner) external view returns (uint);
   2738 | 
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2736 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2733 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2734 | 
   2735 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>> 2736 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   2737 |     function nonces(address owner) external view returns (uint);
   2738 | 
   2739 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2737 行
- **函数**: `nonces()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2734 | 
   2735 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2736 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>> 2737 |     function nonces(address owner) external view returns (uint);
   2738 | 
   2739 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
   2740 | 
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2753 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2750 |     );
   2751 |     event Sync(uint112 reserve0, uint112 reserve1);
   2752 | 
>> 2753 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   2754 |     function factory() external view returns (address);
   2755 |     function token0() external view returns (address);
   2756 |     function token1() external view returns (address);
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2754 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2751 |     event Sync(uint112 reserve0, uint112 reserve1);
   2752 | 
   2753 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
>> 2754 |     function factory() external view returns (address);
   2755 |     function token0() external view returns (address);
   2756 |     function token1() external view returns (address);
   2757 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2755 行
- **函数**: `token0()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2752 | 
   2753 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   2754 |     function factory() external view returns (address);
>> 2755 |     function token0() external view returns (address);
   2756 |     function token1() external view returns (address);
   2757 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2758 |     function price0CumulativeLast() external view returns (uint);
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2756 行
- **函数**: `token1()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2753 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   2754 |     function factory() external view returns (address);
   2755 |     function token0() external view returns (address);
>> 2756 |     function token1() external view returns (address);
   2757 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2758 |     function price0CumulativeLast() external view returns (uint);
   2759 |     function price1CumulativeLast() external view returns (uint);
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2757 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2754 |     function factory() external view returns (address);
   2755 |     function token0() external view returns (address);
   2756 |     function token1() external view returns (address);
>> 2757 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2758 |     function price0CumulativeLast() external view returns (uint);
   2759 |     function price1CumulativeLast() external view returns (uint);
   2760 |     function kLast() external view returns (uint);
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2758 行
- **函数**: `price0CumulativeLast()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2755 |     function token0() external view returns (address);
   2756 |     function token1() external view returns (address);
   2757 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>> 2758 |     function price0CumulativeLast() external view returns (uint);
   2759 |     function price1CumulativeLast() external view returns (uint);
   2760 |     function kLast() external view returns (uint);
   2761 | 
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2759 行
- **函数**: `price1CumulativeLast()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2756 |     function token1() external view returns (address);
   2757 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2758 |     function price0CumulativeLast() external view returns (uint);
>> 2759 |     function price1CumulativeLast() external view returns (uint);
   2760 |     function kLast() external view returns (uint);
   2761 | 
   2762 |     function mint(address to) external returns (uint liquidity);
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2760 行
- **函数**: `kLast()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2757 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2758 |     function price0CumulativeLast() external view returns (uint);
   2759 |     function price1CumulativeLast() external view returns (uint);
>> 2760 |     function kLast() external view returns (uint);
   2761 | 
   2762 |     function mint(address to) external returns (uint liquidity);
   2763 |     function burn(address to) external returns (uint amount0, uint amount1);
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2762 行
- **函数**: `mint()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2759 |     function price1CumulativeLast() external view returns (uint);
   2760 |     function kLast() external view returns (uint);
   2761 | 
>> 2762 |     function mint(address to) external returns (uint liquidity);
   2763 |     function burn(address to) external returns (uint amount0, uint amount1);
   2764 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
   2765 |     function skim(address to) external;
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2763 行
- **函数**: `burn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2760 |     function kLast() external view returns (uint);
   2761 | 
   2762 |     function mint(address to) external returns (uint liquidity);
>> 2763 |     function burn(address to) external returns (uint amount0, uint amount1);
   2764 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
   2765 |     function skim(address to) external;
   2766 |     function sync() external;
```

---

### 78. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2795 行
- **函数**: `getApprovalType()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2792 |     }
   2793 | 
   2794 |     /// @inheritdoc IApproveAndCall
>> 2795 |     function getApprovalType(address token, uint256 amount) external override returns (ApprovalType) {
   2796 |         // check existing approval
   2797 |         if (IERC20(token).allowance(address(this), positionManager) >= amount) return ApprovalType.NOT_REQUIRED;
   2798 | 
```

---

### 79. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2814 行
- **函数**: `approveMax()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2811 |     }
   2812 | 
   2813 |     /// @inheritdoc IApproveAndCall
>> 2814 |     function approveMax(address token) external payable override {
   2815 |         require(tryApprove(token, type(uint256).max));
   2816 |     }
   2817 | 
```

---

### 80. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2819 行
- **函数**: `approveMaxMinusOne()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2816 |     }
   2817 | 
   2818 |     /// @inheritdoc IApproveAndCall
>> 2819 |     function approveMaxMinusOne(address token) external payable override {
   2820 |         require(tryApprove(token, type(uint256).max - 1));
   2821 |     }
   2822 | 
```

---

### 81. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2824 行
- **函数**: `approveZeroThenMax()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2821 |     }
   2822 | 
   2823 |     /// @inheritdoc IApproveAndCall
>> 2824 |     function approveZeroThenMax(address token) external payable override {
   2825 |         require(tryApprove(token, 0));
   2826 |         require(tryApprove(token, type(uint256).max));
   2827 |     }
```

---

### 82. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2830 行
- **函数**: `approveZeroThenMaxMinusOne()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2827 |     }
   2828 | 
   2829 |     /// @inheritdoc IApproveAndCall
>> 2830 |     function approveZeroThenMaxMinusOne(address token) external payable override {
   2831 |         require(tryApprove(token, 0));
   2832 |         require(tryApprove(token, type(uint256).max - 1));
   2833 |     }
```

---

### 83. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2836 行
- **函数**: `callPositionManager()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2833 |     }
   2834 | 
   2835 |     /// @inheritdoc IApproveAndCall
>> 2836 |     function callPositionManager(bytes memory data) public payable override returns (bytes memory result) {
   2837 |         bool success;
   2838 |         (success, result) = positionManager.call(data);
   2839 | 
```

---

### 84. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2855 行
- **函数**: `mint()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2852 |     }
   2853 | 
   2854 |     /// @inheritdoc IApproveAndCall
>> 2855 |     function mint(MintParams calldata params) external payable override returns (bytes memory result) {
   2856 |         return
   2857 |             callPositionManager(
   2858 |                 abi.encodeWithSelector(
```

---

### 85. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3150 行
- **函数**: `unwrapWETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3147 | abstract contract PeripheryPaymentsExtended is IPeripheryPaymentsExtended, PeripheryPayments {
   3148 |     /**
   3149 |     /// @inheritdoc IPeripheryPaymentsExtended
>> 3150 |     function unwrapWETH(uint256 amount, address to) external payable override {
   3151 |         uint256 balance = IWETH9(WETH9).balanceOf(msg.sender);
   3152 |         require(balance >= amount);
   3153 |         TransferHelper.safeTransferFrom(WETH9, msg.sender, address(this), amount);
```

---

### 86. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3160 行
- **函数**: `wrapETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3157 |     */
   3158 | 
   3159 |     /// @inheritdoc IPeripheryPaymentsExtended
>> 3160 |     function wrapETH(uint256 value) external payable override {
   3161 |         IWETH9(WETH9).deposit{value: value}();
   3162 |     }
   3163 | 
```

---

### 87. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3165 行
- **函数**: `sweepToken()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3162 |     }
   3163 | 
   3164 |     /// @inheritdoc IPeripheryPaymentsExtended
>> 3165 |     function sweepToken(address token, uint256 amountMinimum) external payable override {
   3166 |         sweepToken(token, amountMinimum, msg.sender);
   3167 |     }
   3168 | 
```

---

### 88. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3170 行
- **函数**: `pull()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3167 |     }
   3168 | 
   3169 |     /// @inheritdoc IPeripheryPaymentsExtended
>> 3170 |     function pull(address token, uint256 value) external payable override {
   3171 |         TransferHelper.safeTransferFrom(token, msg.sender, address(this), value);
   3172 |     }
   3173 | }
```

---

### 89. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3239 行
- **函数**: `getApprovalType()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3236 |     /// @param token The token to approve
   3237 |     /// @param amount The amount to approve
   3238 |     /// @return The required approval type
>> 3239 |     function getApprovalType(address token, uint256 amount) external returns (ApprovalType);
   3240 | 
   3241 |     /// @notice Approves a token for the maximum possible amount
   3242 |     /// @param token The token to approve
```

---

### 90. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3243 行
- **函数**: `approveMax()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3240 | 
   3241 |     /// @notice Approves a token for the maximum possible amount
   3242 |     /// @param token The token to approve
>> 3243 |     function approveMax(address token) external payable;
   3244 | 
   3245 |     /// @notice Approves a token for the maximum possible amount minus one
   3246 |     /// @param token The token to approve
```

---

### 91. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3247 行
- **函数**: `approveMaxMinusOne()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3244 | 
   3245 |     /// @notice Approves a token for the maximum possible amount minus one
   3246 |     /// @param token The token to approve
>> 3247 |     function approveMaxMinusOne(address token) external payable;
   3248 | 
   3249 |     /// @notice Approves a token for zero, then the maximum possible amount
   3250 |     /// @param token The token to approve
```

---

### 92. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3251 行
- **函数**: `approveZeroThenMax()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3248 | 
   3249 |     /// @notice Approves a token for zero, then the maximum possible amount
   3250 |     /// @param token The token to approve
>> 3251 |     function approveZeroThenMax(address token) external payable;
   3252 | 
   3253 |     /// @notice Approves a token for zero, then the maximum possible amount minus one
   3254 |     /// @param token The token to approve
```

---

### 93. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3255 行
- **函数**: `approveZeroThenMaxMinusOne()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3252 | 
   3253 |     /// @notice Approves a token for zero, then the maximum possible amount minus one
   3254 |     /// @param token The token to approve
>> 3255 |     function approveZeroThenMaxMinusOne(address token) external payable;
   3256 | 
   3257 |     /// @notice Calls the position manager with arbitrary calldata
   3258 |     /// @param data Calldata to pass along to the position manager
```

---

### 94. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3260 行
- **函数**: `callPositionManager()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3257 |     /// @notice Calls the position manager with arbitrary calldata
   3258 |     /// @param data Calldata to pass along to the position manager
   3259 |     /// @return result The result from the call
>> 3260 |     function callPositionManager(bytes memory data) external payable returns (bytes memory result);
   3261 | 
   3262 |     struct MintParams {
   3263 |         address token0;
```

---

### 95. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3276 行
- **函数**: `mint()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3273 |     /// @notice Calls the position manager's mint function
   3274 |     /// @param params Calldata to pass along to the position manager
   3275 |     /// @return result The result from the call
>> 3276 |     function mint(MintParams calldata params) external payable returns (bytes memory result);
   3277 | 
   3278 |     struct IncreaseLiquidityParams {
   3279 |         address token0;
```

---

### 96. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3289 行
- **函数**: `increaseLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3286 |     /// @notice Calls the position manager's increaseLiquidity function
   3287 |     /// @param params Calldata to pass along to the position manager
   3288 |     /// @return result The result from the call
>> 3289 |     function increaseLiquidity(IncreaseLiquidityParams calldata params) external payable returns (bytes memory result);
   3290 | }
   3291 | 
   3292 | 
```

---

### 97. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3302 行
- **函数**: `factoryV2()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3299 | /// @notice Functions that return immutable state of the router
   3300 | interface IImmutableState {
   3301 |     /// @return Returns the address of the PancakeSwap V2 factory
>> 3302 |     function factoryV2() external view returns (address);
   3303 | 
   3304 |     /// @return Returns the address of PancakeSwap V3 NFT position manager
   3305 |     function positionManager() external view returns (address);
```

---

### 98. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3305 行
- **函数**: `positionManager()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3302 |     function factoryV2() external view returns (address);
   3303 | 
   3304 |     /// @return Returns the address of PancakeSwap V3 NFT position manager
>> 3305 |     function positionManager() external view returns (address);
   3306 | }
   3307 | 
   3308 | 
```

---

### 99. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3325 行
- **函数**: `multicall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3322 |     /// @param deadline The time by which this function must be called before failing
   3323 |     /// @param data The encoded function data for each of the calls to make to this contract
   3324 |     /// @return results The results from each of the calls passed in via data
>> 3325 |     function multicall(uint256 deadline, bytes[] calldata data) external payable returns (bytes[] memory results);
   3326 | 
   3327 |     /// @notice Call multiple functions in the current contract and return the data from all of them if they all succeed
   3328 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
```

---

### 100. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3389 行
- **函数**: `wrapETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3386 |     /// @notice Wraps the contract's ETH balance into WETH9
   3387 |     /// @dev The resulting WETH9 is custodied by the router, thus will require further distribution
   3388 |     /// @param value The amount of ETH to wrap
>> 3389 |     function wrapETH(uint256 value) external payable;
   3390 | 
   3391 |     /// @notice Transfers the full amount of a token held by this contract to msg.sender
   3392 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
```

---

### 101. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3395 行
- **函数**: `sweepToken()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3392 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
   3393 |     /// @param token The contract address of the token which will be transferred to msg.sender
   3394 |     /// @param amountMinimum The minimum amount of token required for a transfer
>> 3395 |     function sweepToken(address token, uint256 amountMinimum) external payable;
   3396 | 
   3397 |     /// @notice Transfers the specified amount of a token from the msg.sender to address(this)
   3398 |     /// @param token The token to pull
```

---

### 102. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3400 行
- **函数**: `pull()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3397 |     /// @notice Transfers the specified amount of a token from the msg.sender to address(this)
   3398 |     /// @param token The token to pull
   3399 |     /// @param value The amount to pay
>> 3400 |     function pull(address token, uint256 value) external payable;
   3401 | }
   3402 | 
   3403 | 
```

---

### 103. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3480 行
- **函数**: `coins()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3477 |     ) external payable;
   3478 | 
   3479 |     // solium-disable-next-line mixedcase
>> 3480 |     function coins(uint256 i) external view returns (address);
   3481 | 
   3482 |     // solium-disable-next-line mixedcase
   3483 |     function balances(uint256 i) external view returns (uint256);
```

---

### 104. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3483 行
- **函数**: `balances()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3480 |     function coins(uint256 i) external view returns (address);
   3481 | 
   3482 |     // solium-disable-next-line mixedcase
>> 3483 |     function balances(uint256 i) external view returns (uint256);
   3484 | 
   3485 |     // solium-disable-next-line mixedcase
   3486 |     function A() external view returns (uint256);
```

---

### 105. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3486 行
- **函数**: `A()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3483 |     function balances(uint256 i) external view returns (uint256);
   3484 | 
   3485 |     // solium-disable-next-line mixedcase
>> 3486 |     function A() external view returns (uint256);
   3487 | 
   3488 |     // solium-disable-next-line mixedcase
   3489 |     function fee() external view returns (uint256);
```

---

### 106. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3489 行
- **函数**: `fee()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3486 |     function A() external view returns (uint256);
   3487 | 
   3488 |     // solium-disable-next-line mixedcase
>> 3489 |     function fee() external view returns (uint256);
   3490 | }
   3491 | 
   3492 | 
```

---

### 107. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3516 行
- **函数**: `pairLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3513 |     }
   3514 | 
   3515 |     // solium-disable-next-line mixedcase
>> 3516 |     function pairLength() external view returns (uint256);
   3517 | 
   3518 |     function getPairInfo(address _tokenA, address _tokenB) 
   3519 |         external 
```

---

### 108. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3646 行
- **函数**: `exactInputSingle()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3643 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
   3644 |     /// @param params The parameters necessary for the swap, encoded as `ExactInputSingleParams` in calldata
   3645 |     /// @return amountOut The amount of the received token
>> 3646 |     function exactInputSingle(ExactInputSingleParams calldata params) external payable returns (uint256 amountOut);
   3647 | 
   3648 |     struct ExactInputParams {
   3649 |         bytes path;
```

---

### 109. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3660 行
- **函数**: `exactInput()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3657 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
   3658 |     /// @param params The parameters necessary for the multi-hop swap, encoded as `ExactInputParams` in calldata
   3659 |     /// @return amountOut The amount of the received token
>> 3660 |     function exactInput(ExactInputParams calldata params) external payable returns (uint256 amountOut);
   3661 | 
   3662 |     struct ExactOutputSingleParams {
   3663 |         address tokenIn;
```

---

### 110. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3676 行
- **函数**: `exactOutputSingle()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3673 |     /// that may remain in the router after the swap.
   3674 |     /// @param params The parameters necessary for the swap, encoded as `ExactOutputSingleParams` in calldata
   3675 |     /// @return amountIn The amount of the input token
>> 3676 |     function exactOutputSingle(ExactOutputSingleParams calldata params) external payable returns (uint256 amountIn);
   3677 | 
   3678 |     struct ExactOutputParams {
   3679 |         bytes path;
```

---

### 111. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3689 行
- **函数**: `exactOutput()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3686 |     /// that may remain in the router after the swap.
   3687 |     /// @param params The parameters necessary for the multi-hop swap, encoded as `ExactOutputParams` in calldata
   3688 |     /// @return amountIn The amount of the input token
>> 3689 |     function exactOutput(ExactOutputParams calldata params) external payable returns (uint256 amountIn);
   3690 | }
   3691 | 
   3692 | 
```

---

### 112. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3788 行
- **函数**: `sortTokens()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3785 |     bytes32 internal constant V2_INIT_CODE_HASH = 0x00fb7f630766e6a796048ea87d01acd3068e8ff67d078148a3fa3f4a84f69bd5;
   3786 | 
   3787 |     // returns sorted token addresses, used to handle return values from pairs sorted in this order
>> 3788 |     function sortTokens(address tokenA, address tokenB) public pure returns (address token0, address token1) {
   3789 |         require(tokenA != tokenB);
   3790 |         (token0, token1) = tokenA < tokenB ? (tokenA, tokenB) : (tokenB, tokenA);
   3791 |         require(token0 != address(0));
```

---

### 113. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3899 行
- **函数**: `computeAddress()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3896 |     /// @param deployer The PancakeSwap V3 deployer contract address
   3897 |     /// @param key The PoolKey
   3898 |     /// @return pool The contract address of the V3 pool
>> 3899 |     function computeAddress(address deployer, PoolKey memory key) public pure returns (address pool) {
   3900 |         require(key.token0 < key.token1);
   3901 |         pool = address(
   3902 |             uint256(
```

---

### 114. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 20 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     15 |  *
     16 |  * This module is used through inheritance. It will make available the modifier
     17 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     18 |  * the owner.
     19 |  */
>>   20 | abstract contract Ownable is Context {
     21 |     address private _owner;
     22 | 
     23 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     24 | 
     25 |     /**
```

---

### 115. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 145 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    140 |  *
    141 |  * For an implementation, see {ERC165}.
    142 |  */
    143 | interface IERC165 {
    144 |     /**
>>  145 |      * @dev Returns true if this contract implements the interface defined by
    146 |      * `interfaceId`. See the corresponding
    147 |      * https://eips.ethereum.org/EIPS/eip-165#how-interfaces-are-identified[EIP section]
    148 |      * to learn more about how these ids are created.
    149 |      *
    150 |      * This function call must use less than 30 000 gas.
```

---

### 116. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 448 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    443 |  * via msg.sender and msg.data, they should not be accessed in such a direct
    444 |  * manner, since when dealing with GSN meta-transactions the account sending and
    445 |  * paying for execution may not be the actual sender (as far as an application
    446 |  * is concerned).
    447 |  *
>>  448 |  * This contract is only required for intermediate, library-like contracts.
    449 |  */
    450 | abstract contract Context {
    451 |     function _msgSender() internal view virtual returns (address payable) {
    452 |         return msg.sender;
    453 |     }
```

---

### 117. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 506 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    501 |     constructor () {
    502 |         _status = _NOT_ENTERED;
    503 |     }
    504 | 
    505 |     /**
>>  506 |      * @dev Prevents a contract from calling itself, directly or indirectly.
    507 |      * Calling a `nonReentrant` function from another `nonReentrant`
    508 |      * function is not supported. It is possible to prevent this from happening
    509 |      * by making the `nonReentrant` function external, and make it call a
    510 |      * `private` function that does the actual work.
    511 |      */
```

---

### 118. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 534 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    529 | 
    530 | // SPDX-License-Identifier: GPL-2.0-or-later
    531 | pragma solidity >=0.5.0;
    532 | 
    533 | /// @title Callback for IPancakeV3PoolActions#swap
>>  534 | /// @notice Any contract that calls IPancakeV3PoolActions#swap must implement this interface
    535 | interface IPancakeV3SwapCallback {
    536 |     /// @notice Called to `msg.sender` after executing a swap via IPancakeV3Pool#swap.
    537 |     /// @dev In the implementation you must pay the pool tokens owed for the swap.
    538 |     /// The caller of this method must be checked to be a PancakeV3Pool deployed by the canonical PancakeV3Factory.
    539 |     /// amount0Delta and amount1Delta can both be 0 if no tokens were swapped.
```

---

### 119. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 874 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    869 | pragma solidity >=0.5.0;
    870 | 
    871 | /// @title Pool state that never changes
    872 | /// @notice These parameters are fixed for a pool forever, i.e., the methods will always return the same values
    873 | interface IPancakeV3PoolImmutables {
>>  874 |     /// @notice The contract that deployed the pool, which must adhere to the IPancakeV3Factory interface
    875 |     /// @return The contract address
    876 |     function factory() external view returns (address);
    877 | 
    878 |     /// @notice The first of the two tokens of the pool, sorted by address
    879 |     /// @return The token contract address
```

---

### 120. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1499 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1494 | pragma abicoder v2;
   1495 | 
   1496 | import '../interfaces/IMulticall.sol';
   1497 | 
   1498 | /// @title Multicall
>> 1499 | /// @notice Enables calling multiple methods in a single call to the contract
   1500 | abstract contract Multicall is IMulticall {
   1501 |     /// @inheritdoc IMulticall
   1502 |     function multicall(bytes[] calldata data) public payable override returns (bytes[] memory results) {
   1503 |         results = new bytes[](data.length);
   1504 |         for (uint256 i = 0; i < data.length; i++) {
```

---

### 121. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1531 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1526 | 
   1527 | import '../interfaces/IPeripheryImmutableState.sol';
   1528 | 
   1529 | /// @title Immutable state
   1530 | /// @notice Immutable state used by periphery contracts
>> 1531 | abstract contract PeripheryImmutableState is IPeripheryImmutableState {
   1532 |     /// @inheritdoc IPeripheryImmutableState
   1533 |     address public immutable override deployer;
   1534 |     /// @inheritdoc IPeripheryImmutableState
   1535 |     address public immutable override factory;
   1536 |     /// @inheritdoc IPeripheryImmutableState
```

---

### 122. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1635 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1630 | import '../interfaces/IPeripheryPaymentsWithFee.sol';
   1631 | 
   1632 | import '../interfaces/external/IWETH9.sol';
   1633 | import '../libraries/TransferHelper.sol';
   1634 | 
>> 1635 | abstract contract PeripheryPaymentsWithFee is PeripheryPayments, IPeripheryPaymentsWithFee {
   1636 |     using LowGasSafeMath for uint256;
   1637 | 
   1638 |     /// @inheritdoc IPeripheryPaymentsWithFee
   1639 |     function unwrapWETH9WithFee(
   1640 |         uint256 amountMinimum,
```

---

### 123. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1708 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1703 | import '../interfaces/ISelfPermit.sol';
   1704 | import '../interfaces/external/IERC20PermitAllowed.sol';
   1705 | 
   1706 | /// @title Self Permit
   1707 | /// @notice Functionality to call permit on any EIP-2612-compliant token for use in the route
>> 1708 | /// @dev These functions are expected to be embedded in multicalls to allow EOAs to approve a contract and call a function
   1709 | /// that requires an approval in a single transaction.
   1710 | abstract contract SelfPermit is ISelfPermit {
   1711 |     /// @inheritdoc ISelfPermit
   1712 |     function selfPermit(
   1713 |         address token,
```

---

### 124. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1855 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1850 | pragma abicoder v2;
   1851 | 
   1852 | /// @title Multicall interface
   1853 | /// @notice Enables calling multiple methods in a single call to the contract
   1854 | interface IMulticall {
>> 1855 |     /// @notice Call multiple functions in the current contract and return the data from all of them if they all succeed
   1856 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   1857 |     /// @param data The encoded function data for each of the calls to make to this contract
   1858 |     /// @return results The results from each of the calls passed in via data
   1859 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results);
   1860 | }
```

---

### 125. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2080 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2075 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   2076 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
   2077 |     /// @param recipient The address receiving ETH
   2078 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external payable;
   2079 | 
>> 2080 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   2081 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
   2082 |     /// that use ether for the input amount. And in PancakeSwap Router, this would be called 
   2083 |     /// at the very end of swap
   2084 |     function refundETH() external payable;
   2085 | 
```

---

### 126. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2144 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2139 | /// @notice Provides a method for creating and initializing a pool, if necessary, for bundling with other methods that
   2140 | /// require the pool to exist.
   2141 | interface IPoolInitializer {
   2142 |     /// @notice Creates a new pool if it does not exist, then initializes if not initialized
   2143 |     /// @dev This method can be bundled with others via IMulticall for the first action (e.g. mint) performed against a pool
>> 2144 |     /// @param token0 The contract address of token0 of the pool
   2145 |     /// @param token1 The contract address of token1 of the pool
   2146 |     /// @param fee The fee amount of the v3 pool for the specified token pair
   2147 |     /// @param sqrtPriceX96 The initial square root price of the pool as a Q64.96 value
   2148 |     /// @return pool Returns the pool address based on the pair of tokens and fee, will return the newly created pool address if necessary
   2149 |     function createAndInitializePoolIfNecessary(
```

---

### 127. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2509 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2504 |     }
   2505 | 
   2506 |     /// @notice Returns the "synthetic" tick which represents the price of the first entry in `tokens` in terms of the last
   2507 |     /// @dev Useful for calculating relative prices along routes.
   2508 |     /// @dev There must be one tick for each pairwise set of tokens.
>> 2509 |     /// @param tokens The token contract addresses
   2510 |     /// @param ticks The ticks, representing the price of each token pair in `tokens`
   2511 |     /// @return syntheticTick The synthetic tick, representing the relative price of the outermost tokens in `tokens`
   2512 |     function getChainedPrice(address[] memory tokens, int24[] memory ticks)
   2513 |         internal
   2514 |         pure
```

---

### 128. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2662 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2657 | import '@openzeppelin/contracts/token/ERC20/IERC20.sol';
   2658 | 
   2659 | library TransferHelper {
   2660 |     /// @notice Transfers tokens from the targeted address to the given destination
   2661 |     /// @notice Errors with 'STF' if transfer fails
>> 2662 |     /// @param token The contract address of the token to be transferred
   2663 |     /// @param from The originating address from which the tokens will be transferred
   2664 |     /// @param to The destination address of the transfer
   2665 |     /// @param value The amount to be transferred
   2666 |     function safeTransferFrom(
   2667 |         address token,
```

---

### 129. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2679 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2674 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'STF');
   2675 |     }
   2676 | 
   2677 |     /// @notice Transfers tokens from msg.sender to a recipient
   2678 |     /// @dev Errors with ST if transfer fails
>> 2679 |     /// @param token The contract address of the token which will be transferred
   2680 |     /// @param to The recipient of the transfer
   2681 |     /// @param value The value of the transfer
   2682 |     function safeTransfer(
   2683 |         address token,
   2684 |         address to,
```

---

### 130. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2691 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2686 |     ) internal {
   2687 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transfer.selector, to, value));
   2688 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'ST');
   2689 |     }
   2690 | 
>> 2691 |     /// @notice Approves the stipulated contract to spend the given allowance in the given token
   2692 |     /// @dev Errors with 'SA' if transfer fails
   2693 |     /// @param token The contract address of the token to be approved
   2694 |     /// @param to The target of the approval
   2695 |     /// @param value The amount of the given token the target will be allowed to spend
   2696 |     function safeApprove(
```

---

### 131. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2787 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2782 | import './ImmutableState.sol';
   2783 | 
   2784 | /// @title Approve and Call
   2785 | /// @notice Allows callers to approve the PancakeSwap V3 position manager from this contract,
   2786 | /// for any token, and then make calls into the position manager
>> 2787 | abstract contract ApproveAndCall is IApproveAndCall, ImmutableState {
   2788 |     function tryApprove(address token, uint256 amount) private returns (bool) {
   2789 |         (bool success, bytes memory data) =
   2790 |             token.call(abi.encodeWithSelector(IERC20.approve.selector, positionManager, amount));
   2791 |         return success && (data.length == 0 || abi.decode(data, (bool)));
   2792 |     }
```

---

### 132. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2911 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2906 | 
   2907 | import '../interfaces/IImmutableState.sol';
   2908 | 
   2909 | /// @title Immutable state
   2910 | /// @notice Immutable state used by the swap router
>> 2911 | abstract contract ImmutableState is IImmutableState {
   2912 |     /// @inheritdoc IImmutableState
   2913 |     address public immutable override factoryV2;
   2914 |     /// @inheritdoc IImmutableState
   2915 |     address public immutable override positionManager;
   2916 | 
```

---

### 133. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3147 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3142 | import '@pancakeswap/v3-periphery/contracts/base/PeripheryPayments.sol';
   3143 | import '@pancakeswap/v3-periphery/contracts/libraries/TransferHelper.sol';
   3144 | 
   3145 | import '../interfaces/IPeripheryPaymentsExtended.sol';
   3146 | 
>> 3147 | abstract contract PeripheryPaymentsExtended is IPeripheryPaymentsExtended, PeripheryPayments {
   3148 |     /**
   3149 |     /// @inheritdoc IPeripheryPaymentsExtended
   3150 |     function unwrapWETH(uint256 amount, address to) external payable override {
   3151 |         uint256 balance = IWETH9(WETH9).balanceOf(msg.sender);
   3152 |         require(balance >= amount);
```

---

### 134. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3185 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3180 | import '@pancakeswap/v3-periphery/contracts/base/PeripheryPaymentsWithFee.sol';
   3181 | 
   3182 | import '../interfaces/IPeripheryPaymentsWithFeeExtended.sol';
   3183 | import './PeripheryPaymentsExtended.sol';
   3184 | 
>> 3185 | abstract contract PeripheryPaymentsWithFeeExtended is
   3186 |     IPeripheryPaymentsWithFeeExtended,
   3187 |     PeripheryPaymentsExtended,
   3188 |     PeripheryPaymentsWithFee
   3189 | {
   3190 |     /// @inheritdoc IPeripheryPaymentsWithFeeExtended
```

---

### 135. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3320 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3315 | import '@pancakeswap/v3-periphery/contracts/interfaces/IMulticall.sol';
   3316 | 
   3317 | /// @title MulticallExtended interface
   3318 | /// @notice Enables calling multiple methods in a single call to the contract with optional validation
   3319 | interface IMulticallExtended is IMulticall {
>> 3320 |     /// @notice Call multiple functions in the current contract and return the data from all of them if they all succeed
   3321 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   3322 |     /// @param deadline The time by which this function must be called before failing
   3323 |     /// @param data The encoded function data for each of the calls to make to this contract
   3324 |     /// @return results The results from each of the calls passed in via data
   3325 |     function multicall(uint256 deadline, bytes[] calldata data) external payable returns (bytes[] memory results);
```

---

### 136. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3391 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3386 |     /// @notice Wraps the contract's ETH balance into WETH9
   3387 |     /// @dev The resulting WETH9 is custodied by the router, thus will require further distribution
   3388 |     /// @param value The amount of ETH to wrap
   3389 |     function wrapETH(uint256 value) external payable;
   3390 | 
>> 3391 |     /// @notice Transfers the full amount of a token held by this contract to msg.sender
   3392 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
   3393 |     /// @param token The contract address of the token which will be transferred to msg.sender
   3394 |     /// @param amountMinimum The minimum amount of token required for a transfer
   3395 |     function sweepToken(address token, uint256 amountMinimum) external payable;
   3396 | 
```

---

### 137. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3591 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3586 | 
   3587 | /// @title Router token swapping functionality
   3588 | /// @notice Functions for swapping tokens via PancakeSwap V2
   3589 | interface IV2SwapRouter {
   3590 |     /// @notice Swaps `amountIn` of one token for as much as possible of another token
>> 3591 |     /// @dev Setting `amountIn` to 0 will cause the contract to look up its own balance,
   3592 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
   3593 |     /// @param amountIn The amount of token to swap
   3594 |     /// @param amountOutMin The minimum amount of output that must be received
   3595 |     /// @param path The ordered list of tokens to swap through
   3596 |     /// @param to The recipient address
```

---

### 138. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3642 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3637 |         uint256 amountOutMinimum;
   3638 |         uint160 sqrtPriceLimitX96;
   3639 |     }
   3640 | 
   3641 |     /// @notice Swaps `amountIn` of one token for as much as possible of another token
>> 3642 |     /// @dev Setting `amountIn` to 0 will cause the contract to look up its own balance,
   3643 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
   3644 |     /// @param params The parameters necessary for the swap, encoded as `ExactInputSingleParams` in calldata
   3645 |     /// @return amountOut The amount of the received token
   3646 |     function exactInputSingle(ExactInputSingleParams calldata params) external payable returns (uint256 amountOut);
   3647 | 
```

---

### 139. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3656 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3651 |         uint256 amountIn;
   3652 |         uint256 amountOutMinimum;
   3653 |     }
   3654 | 
   3655 |     /// @notice Swaps `amountIn` of one token for as much as possible of another along the specified path
>> 3656 |     /// @dev Setting `amountIn` to 0 will cause the contract to look up its own balance,
   3657 |     /// and swap the entire amount, enabling contracts to send tokens before calling this function.
   3658 |     /// @param params The parameters necessary for the multi-hop swap, encoded as `ExactInputParams` in calldata
   3659 |     /// @return amountOut The amount of the received token
   3660 |     function exactInput(ExactInputParams calldata params) external payable returns (uint256 amountOut);
   3661 | 
```

---

### 140. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3972 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3967 | import './StableSwapRouter.sol';
   3968 | import './base/ApproveAndCall.sol';
   3969 | import './base/MulticallExtended.sol';
   3970 | 
   3971 | /// @title Pancake Smart Router
>> 3972 | contract SmartRouter is ISmartRouter, V2SwapRouter, V3SwapRouter, StableSwapRouter, ApproveAndCall, MulticallExtended, SelfPermit {
   3973 |     constructor(
   3974 |         address _factoryV2,
   3975 |         address _deployer,
   3976 |         address _factoryV3,
   3977 |         address _positionManager,
```

---

### 141. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 4128 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4123 | import './libraries/Constants.sol';
   4124 | import './libraries/SmartRouterHelper.sol';
   4125 | 
   4126 | /// @title PancakeSwap V2 Swap Router
   4127 | /// @notice Router for stateless execution of swaps against PancakeSwap V2
>> 4128 | abstract contract V2SwapRouter is IV2SwapRouter, ImmutableState, PeripheryPaymentsWithFeeExtended, ReentrancyGuard {
   4129 |     using LowGasSafeMath for uint256;
   4130 | 
   4131 |     // supports fee-on-transfer tokens
   4132 |     // requires the initial amount to have already been sent to the first pair
   4133 |     // `refundETH` should be called at very end of all swaps
```

---

### 142. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 4235 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4230 | import './libraries/Constants.sol';
   4231 | import './libraries/SmartRouterHelper.sol';
   4232 | 
   4233 | /// @title PancakeSwap V3 Swap Router
   4234 | /// @notice Router for stateless execution of swaps against PancakeSwap V3
>> 4235 | abstract contract V3SwapRouter is IV3SwapRouter, PeripheryPaymentsWithFeeExtended, OracleSlippage, ReentrancyGuard {
   4236 |     using Path for bytes;
   4237 |     using SafeCast for uint256;
   4238 | 
   4239 |     /// @dev Used as the placeholder value for amountInCached, because the computed amount in for an exact output swap
   4240 |     /// can never actually be this value
```

---

### 143. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 4341 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4336 |         require(amountOut >= params.amountOutMinimum);
   4337 |     }
   4338 | 
   4339 |     /// @inheritdoc IV3SwapRouter
   4340 |     function exactInput(ExactInputParams memory params) external payable nonReentrant override returns (uint256 amountOut) {
>> 4341 |         // use amountIn == Constants.CONTRACT_BALANCE as a flag to swap the entire balance of the contract
   4342 |         bool hasAlreadyPaid;
   4343 |         if (params.amountIn == Constants.CONTRACT_BALANCE) {
   4344 |             hasAlreadyPaid = true;
   4345 |             (address tokenIn, , ) = params.path.decodeFirstPool();
   4346 |             params.amountIn = IERC20(tokenIn).balanceOf(address(this));
```

---

### 144. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 5 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
      2 | 
      3 | // SPDX-License-Identifier: MIT
      4 | 
>>    5 | pragma solidity ^0.7.0;
      6 | 
      7 | import "../utils/Context.sol";
      8 | /**
```

---

### 145. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 132 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    129 | 
    130 | // SPDX-License-Identifier: MIT
    131 | 
>>  132 | pragma solidity ^0.7.0;
    133 | 
    134 | /**
    135 |  * @dev Interface of the ERC165 standard, as defined in the
```

---

### 146. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 160 行
- **函数**: `supportsInterface()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    157 | 
    158 | // SPDX-License-Identifier: MIT
    159 | 
>>  160 | pragma solidity ^0.7.0;
    161 | 
    162 | /**
    163 |  * @dev Interface of the ERC20 standard as defined in the EIP.
```

---

### 147. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 241 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    238 | 
    239 | // SPDX-License-Identifier: MIT
    240 | 
>>  241 | pragma solidity ^0.7.0;
    242 | 
    243 | import "../../introspection/IERC165.sol";
    244 | 
```

---

### 148. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 374 行
- **函数**: `safeTransferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    371 | 
    372 | // SPDX-License-Identifier: MIT
    373 | 
>>  374 | pragma solidity ^0.7.0;
    375 | 
    376 | import "./IERC721.sol";
    377 | 
```

---

### 149. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 407 行
- **函数**: `tokenByIndex()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    404 | 
    405 | // SPDX-License-Identifier: MIT
    406 | 
>>  407 | pragma solidity ^0.7.0;
    408 | 
    409 | import "./IERC721.sol";
    410 | 
```

---

### 150. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 466 行
- **函数**: `_msgData()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
    463 | 
    464 | // SPDX-License-Identifier: MIT
    465 | 
>>  466 | pragma solidity ^0.7.0;
    467 | 
    468 | /**
    469 |  * @dev Contract module that helps prevent reentrant calls to a function.
```

---

### 151. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1485 行
- **函数**: `_blockTimestamp()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1482 |     /// @dev Method that exists purely to be overridden for tests
   1483 |     /// @return The current block timestamp
   1484 |     function _blockTimestamp() internal view virtual returns (uint256) {
>> 1485 |         return block.timestamp;
   1486 |     }
   1487 | }
   1488 | 
```

---

### 152. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2431 行
- **函数**: `getOldestObservationSecondsAgo()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2428 |             (observationTimestamp, , , ) = IPancakeV3Pool(pool).observations(0);
   2429 |         }
   2430 | 
>> 2431 |         secondsAgo = uint32(block.timestamp) - observationTimestamp;
   2432 |     }
   2433 | 
   2434 |     /// @notice Given a pool, it returns the tick value as of the start of the current block
```

---

### 153. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2448 行
- **函数**: `getBlockStartingTickAndLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2445 |         // We don't need to check if this observation is initialized - it is guaranteed to be.
   2446 |         (uint32 observationTimestamp, int56 tickCumulative, uint160 secondsPerLiquidityCumulativeX128, ) =
   2447 |             IPancakeV3Pool(pool).observations(observationIndex);
>> 2448 |         if (observationTimestamp != uint32(block.timestamp)) {
   2449 |             return (tick, IPancakeV3Pool(pool).liquidity());
   2450 |         }
   2451 | 
```

---

### 154. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1609 行
- **函数**: `pay()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1606 |         if (token == WETH9 && address(this).balance >= value) {
   1607 |             // pay with WETH9
   1608 |             IWETH9(WETH9).deposit{value: value}(); // wrap only what is needed to pay
>> 1609 |             IWETH9(WETH9).transfer(recipient, value);
   1610 |         } else if (payer == address(this)) {
   1611 |             // pay with tokens already in the contract (for the exact input multihop case)
   1612 |             TransferHelper.safeTransfer(token, recipient, value);
```

---

### 155. 🟢 [LOW] blockhash-usage

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3220 行
- **函数**: `sweepTokenWithFee()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: 使用 blockhash()，只能获取最近 256 个区块的哈希，超出范围返回 0。

**代码片段**:
```solidity
   3217 | 
   3218 | abstract contract PeripheryValidationExtended is PeripheryValidation {
   3219 |     modifier checkPreviousBlockhash(bytes32 previousBlockhash) {
>> 3220 |         require(blockhash(block.number - 1) == previousBlockhash, 'Blockhash');
   3221 |         _;
   3222 |     }
   3223 | }
```

---

### 156. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3220 行
- **函数**: `sweepTokenWithFee()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   3217 | 
   3218 | abstract contract PeripheryValidationExtended is PeripheryValidation {
   3219 |     modifier checkPreviousBlockhash(bytes32 previousBlockhash) {
>> 3220 |         require(blockhash(block.number - 1) == previousBlockhash, 'Blockhash');
   3221 |         _;
   3222 |     }
   3223 | }
```

---

### 157. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2607 行
- **函数**: `skipToken()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2604 | 
   2605 | /// @title Provides functions for deriving a pool address from the factory, tokens, and the fee
   2606 | library PoolAddress {
>> 2607 |     bytes32 internal constant POOL_INIT_CODE_HASH = 0x6ce8eb472fa82df5469c6ab6d485f17c3ad13c8cd7af59b3d4a8026c5ce0f7e2;
   2608 | 
   2609 |     /// @notice The identifying key of the pool
   2610 |     struct PoolKey {
```

---

### 158. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3785 行
- **函数**: `getStableAmountsIn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3782 |     // bytes32 internal constant V2_INIT_CODE_HASH = 0xd0d4c4cd0848c93cb4fd1f498d7013ee6bfb25783ea21593d5834f5d250ece66; // BSC TESTNET
   3783 |     // bytes32 internal constant V2_INIT_CODE_HASH = 0x00fb7f630766e6a796048ea87d01acd3068e8ff67d078148a3fa3f4a84f69bd5; // BSC
   3784 |     // bytes32 internal constant V2_INIT_CODE_HASH = 0x57224589c67f3f30a6b0d7a1b54cf3153ab84563bc609ef41dfb34f8b2974d2d; // ETH, GOERLI
>> 3785 |     bytes32 internal constant V2_INIT_CODE_HASH = 0x00fb7f630766e6a796048ea87d01acd3068e8ff67d078148a3fa3f4a84f69bd5;
   3786 | 
   3787 |     // returns sorted token addresses, used to handle return values from pairs sorted in this order
   3788 |     function sortTokens(address tokenA, address tokenB) public pure returns (address token0, address token1) {
```

---

### 159. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 3872 行
- **函数**: `getAmountsIn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3869 | 
   3870 |     /************************************************** V3 **************************************************/
   3871 | 
>> 3872 |     bytes32 internal constant V3_INIT_CODE_HASH = 0x6ce8eb472fa82df5469c6ab6d485f17c3ad13c8cd7af59b3d4a8026c5ce0f7e2;
   3873 | 
   3874 |     /// @notice The identifying key of the pool
   3875 |     struct PoolKey {
```

---

### 160. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1082 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1079 |         // variables such that product = prod1 * 2**256 + prod0
   1080 |         uint256 prod0; // Least significant 256 bits of the product
   1081 |         uint256 prod1; // Most significant 256 bits of the product
>> 1082 |         assembly {
   1083 |             let mm := mulmod(a, b, not(0))
   1084 |             prod0 := mul(a, b)
   1085 |             prod1 := sub(sub(mm, prod0), lt(mm, prod0))
```

---

### 161. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1091 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1088 |         // Handle non-overflow cases, 256 by 256 division
   1089 |         if (prod1 == 0) {
   1090 |             require(denominator > 0);
>> 1091 |             assembly {
   1092 |                 result := div(prod0, denominator)
   1093 |             }
   1094 |             return result;
```

---

### 162. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1108 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1105 |         // Make division exact by subtracting the remainder from [prod1 prod0]
   1106 |         // Compute remainder using mulmod
   1107 |         uint256 remainder;
>> 1108 |         assembly {
   1109 |             remainder := mulmod(a, b, denominator)
   1110 |         }
   1111 |         // Subtract 256 bit number from 512 bit number
```

---

### 163. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1112 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1109 |             remainder := mulmod(a, b, denominator)
   1110 |         }
   1111 |         // Subtract 256 bit number from 512 bit number
>> 1112 |         assembly {
   1113 |             prod1 := sub(prod1, gt(remainder, prod0))
   1114 |             prod0 := sub(prod0, remainder)
   1115 |         }
```

---

### 164. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1122 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1119 |         // Always >= 1.
   1120 |         uint256 twos = -denominator & denominator;
   1121 |         // Divide denominator by power of two
>> 1122 |         assembly {
   1123 |             denominator := div(denominator, twos)
   1124 |         }
   1125 | 
```

---

### 165. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1127 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1124 |         }
   1125 | 
   1126 |         // Divide [prod1 prod0] by the factors of two
>> 1127 |         assembly {
   1128 |             prod0 := div(prod0, twos)
   1129 |         }
   1130 |         // Shift in bits from prod1 into prod0. For this we need
```

---

### 166. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1133 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1130 |         // Shift in bits from prod1 into prod0. For this we need
   1131 |         // to flip `twos` such that it is 2**256 / twos.
   1132 |         // If twos is zero, then it becomes one
>> 1133 |         assembly {
   1134 |             twos := add(div(sub(0, twos), twos), 1)
   1135 |         }
   1136 |         prod0 |= prod1 * twos;
```

---

### 167. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1335 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1332 |         uint256 r = ratio;
   1333 |         uint256 msb = 0;
   1334 | 
>> 1335 |         assembly {
   1336 |             let f := shl(7, gt(r, 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF))
   1337 |             msb := or(msb, f)
   1338 |             r := shr(f, r)
```

---

### 168. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1340 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1337 |             msb := or(msb, f)
   1338 |             r := shr(f, r)
   1339 |         }
>> 1340 |         assembly {
   1341 |             let f := shl(6, gt(r, 0xFFFFFFFFFFFFFFFF))
   1342 |             msb := or(msb, f)
   1343 |             r := shr(f, r)
```

---

### 169. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1345 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1342 |             msb := or(msb, f)
   1343 |             r := shr(f, r)
   1344 |         }
>> 1345 |         assembly {
   1346 |             let f := shl(5, gt(r, 0xFFFFFFFF))
   1347 |             msb := or(msb, f)
   1348 |             r := shr(f, r)
```

---

### 170. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1350 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1347 |             msb := or(msb, f)
   1348 |             r := shr(f, r)
   1349 |         }
>> 1350 |         assembly {
   1351 |             let f := shl(4, gt(r, 0xFFFF))
   1352 |             msb := or(msb, f)
   1353 |             r := shr(f, r)
```

---

### 171. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1355 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1352 |             msb := or(msb, f)
   1353 |             r := shr(f, r)
   1354 |         }
>> 1355 |         assembly {
   1356 |             let f := shl(3, gt(r, 0xFF))
   1357 |             msb := or(msb, f)
   1358 |             r := shr(f, r)
```

---

### 172. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1360 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1357 |             msb := or(msb, f)
   1358 |             r := shr(f, r)
   1359 |         }
>> 1360 |         assembly {
   1361 |             let f := shl(2, gt(r, 0xF))
   1362 |             msb := or(msb, f)
   1363 |             r := shr(f, r)
```

---

### 173. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1365 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1362 |             msb := or(msb, f)
   1363 |             r := shr(f, r)
   1364 |         }
>> 1365 |         assembly {
   1366 |             let f := shl(1, gt(r, 0x3))
   1367 |             msb := or(msb, f)
   1368 |             r := shr(f, r)
```

---

### 174. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1370 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1367 |             msb := or(msb, f)
   1368 |             r := shr(f, r)
   1369 |         }
>> 1370 |         assembly {
   1371 |             let f := gt(r, 0x1)
   1372 |             msb := or(msb, f)
   1373 |         }
```

---

### 175. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1380 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1377 | 
   1378 |         int256 log_2 = (int256(msb) - 128) << 64;
   1379 | 
>> 1380 |         assembly {
   1381 |             r := shr(127, mul(r, r))
   1382 |             let f := shr(128, r)
   1383 |             log_2 := or(log_2, shl(63, f))
```

---

### 176. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1386 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1383 |             log_2 := or(log_2, shl(63, f))
   1384 |             r := shr(f, r)
   1385 |         }
>> 1386 |         assembly {
   1387 |             r := shr(127, mul(r, r))
   1388 |             let f := shr(128, r)
   1389 |             log_2 := or(log_2, shl(62, f))
```

---

### 177. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1392 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1389 |             log_2 := or(log_2, shl(62, f))
   1390 |             r := shr(f, r)
   1391 |         }
>> 1392 |         assembly {
   1393 |             r := shr(127, mul(r, r))
   1394 |             let f := shr(128, r)
   1395 |             log_2 := or(log_2, shl(61, f))
```

---

### 178. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1398 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1395 |             log_2 := or(log_2, shl(61, f))
   1396 |             r := shr(f, r)
   1397 |         }
>> 1398 |         assembly {
   1399 |             r := shr(127, mul(r, r))
   1400 |             let f := shr(128, r)
   1401 |             log_2 := or(log_2, shl(60, f))
```

---

### 179. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1404 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1401 |             log_2 := or(log_2, shl(60, f))
   1402 |             r := shr(f, r)
   1403 |         }
>> 1404 |         assembly {
   1405 |             r := shr(127, mul(r, r))
   1406 |             let f := shr(128, r)
   1407 |             log_2 := or(log_2, shl(59, f))
```

---

### 180. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1410 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1407 |             log_2 := or(log_2, shl(59, f))
   1408 |             r := shr(f, r)
   1409 |         }
>> 1410 |         assembly {
   1411 |             r := shr(127, mul(r, r))
   1412 |             let f := shr(128, r)
   1413 |             log_2 := or(log_2, shl(58, f))
```

---

### 181. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1416 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1413 |             log_2 := or(log_2, shl(58, f))
   1414 |             r := shr(f, r)
   1415 |         }
>> 1416 |         assembly {
   1417 |             r := shr(127, mul(r, r))
   1418 |             let f := shr(128, r)
   1419 |             log_2 := or(log_2, shl(57, f))
```

---

### 182. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1422 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1419 |             log_2 := or(log_2, shl(57, f))
   1420 |             r := shr(f, r)
   1421 |         }
>> 1422 |         assembly {
   1423 |             r := shr(127, mul(r, r))
   1424 |             let f := shr(128, r)
   1425 |             log_2 := or(log_2, shl(56, f))
```

---

### 183. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1428 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1425 |             log_2 := or(log_2, shl(56, f))
   1426 |             r := shr(f, r)
   1427 |         }
>> 1428 |         assembly {
   1429 |             r := shr(127, mul(r, r))
   1430 |             let f := shr(128, r)
   1431 |             log_2 := or(log_2, shl(55, f))
```

---

### 184. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1434 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1431 |             log_2 := or(log_2, shl(55, f))
   1432 |             r := shr(f, r)
   1433 |         }
>> 1434 |         assembly {
   1435 |             r := shr(127, mul(r, r))
   1436 |             let f := shr(128, r)
   1437 |             log_2 := or(log_2, shl(54, f))
```

---

### 185. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1440 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1437 |             log_2 := or(log_2, shl(54, f))
   1438 |             r := shr(f, r)
   1439 |         }
>> 1440 |         assembly {
   1441 |             r := shr(127, mul(r, r))
   1442 |             let f := shr(128, r)
   1443 |             log_2 := or(log_2, shl(53, f))
```

---

### 186. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1446 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1443 |             log_2 := or(log_2, shl(53, f))
   1444 |             r := shr(f, r)
   1445 |         }
>> 1446 |         assembly {
   1447 |             r := shr(127, mul(r, r))
   1448 |             let f := shr(128, r)
   1449 |             log_2 := or(log_2, shl(52, f))
```

---

### 187. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1452 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1449 |             log_2 := or(log_2, shl(52, f))
   1450 |             r := shr(f, r)
   1451 |         }
>> 1452 |         assembly {
   1453 |             r := shr(127, mul(r, r))
   1454 |             let f := shr(128, r)
   1455 |             log_2 := or(log_2, shl(51, f))
```

---

### 188. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1458 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1455 |             log_2 := or(log_2, shl(51, f))
   1456 |             r := shr(f, r)
   1457 |         }
>> 1458 |         assembly {
   1459 |             r := shr(127, mul(r, r))
   1460 |             let f := shr(128, r)
   1461 |             log_2 := or(log_2, shl(50, f))
```

---

### 189. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 1510 行
- **函数**: `multicall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1507 |             if (!success) {
   1508 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
   1509 |                 if (result.length < 68) revert();
>> 1510 |                 assembly {
   1511 |                     result := add(result, 0x04)
   1512 |                 }
   1513 |                 revert(abi.decode(result, (string)));
```

---

### 190. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2262 行
- **函数**: `slice()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2259 | 
   2260 |         bytes memory tempBytes;
   2261 | 
>> 2262 |         assembly {
   2263 |             switch iszero(_length)
   2264 |                 case 0 {
   2265 |                     // Get a location of some free memory and store it in tempBytes as
```

---

### 191. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2322 行
- **函数**: `toAddress()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2319 |         require(_bytes.length >= _start + 20, 'toAddress_outOfBounds');
   2320 |         address tempAddress;
   2321 | 
>> 2322 |         assembly {
   2323 |             tempAddress := div(mload(add(add(_bytes, 0x20), _start)), 0x1000000000000000000000000)
   2324 |         }
   2325 | 
```

---

### 192. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2334 行
- **函数**: `toUint24()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2331 |         require(_bytes.length >= _start + 3, 'toUint24_outOfBounds');
   2332 |         uint24 tempUint;
   2333 | 
>> 2334 |         assembly {
   2335 |             tempUint := mload(add(add(_bytes, 0x3), _start))
   2336 |         }
   2337 | 
```

---

### 193. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x13f4EA83D0bd40E75C8222255bc855a974568Dd4` 第 2843 行
- **函数**: `callPositionManager()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2840 |         if (!success) {
   2841 |             // Next 5 lines from https://ethereum.stackexchange.com/a/83577
   2842 |             if (result.length < 68) revert();
>> 2843 |             assembly {
   2844 |                 result := add(result, 0x04)
   2845 |             }
   2846 |             revert(abi.decode(result, (string)));
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*