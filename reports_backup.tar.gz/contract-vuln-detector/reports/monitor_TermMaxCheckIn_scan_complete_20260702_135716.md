# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:57:16
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x007200C66bd2a5BD7c744b90dF8eCBEB34fd26d4` |
| contract_name | `TermMaxCheckIn` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/TermMaxCheckIn.sol', 'node_modules/@openzeppelin/contracts/access/Ownable.sol', 'node_modules/@openzeppelin/contracts/utils/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646141` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 7 |
| 🟢 LOW | 1 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x007200C66bd2a5BD7c744b90dF8eCBEB34fd26d4` 第 17 行
- **函数**: `checkIn()`
- **合约**: `TermMaxCheckIn`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     14 | 
     15 |     constructor() Ownable(msg.sender) {}
     16 | 
>>   17 |     function checkIn() external {
     18 |         require(!paused, "Paused");
     19 | 
     20 |         uint256 currentDay = getCurrentDay();
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x007200C66bd2a5BD7c744b90dF8eCBEB34fd26d4` 第 29 行
- **函数**: `getCurrentDay()`
- **合约**: `TermMaxCheckIn`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     26 | 
     27 |     // Returns the current day number based on UTC+0 (00:00:00)
     28 |     // Day 0 = 1970-01-01, increments every 86400 seconds
>>   29 |     function getCurrentDay() public view returns (uint256) {
     30 |         return block.timestamp / 86400;
     31 |     }
     32 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x007200C66bd2a5BD7c744b90dF8eCBEB34fd26d4` 第 34 行
- **函数**: `hasCheckedInToday()`
- **合约**: `TermMaxCheckIn`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     31 |     }
     32 | 
     33 |     // Check if a user has checked in on the current day
>>   34 |     function hasCheckedInToday(address user) public view returns (bool) {
     35 |         return lastCheckInDay[user] == getCurrentDay();
     36 |     }
     37 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x007200C66bd2a5BD7c744b90dF8eCBEB34fd26d4` 第 104 行
- **函数**: `owner()`
- **合约**: `TermMaxCheckIn`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    101 |     /**
    102 |      * @dev Returns the address of the current owner.
    103 |      */
>>  104 |     function owner() public view virtual returns (address) {
    105 |         return _owner;
    106 |     }
    107 | 
```

---

### 5. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x007200C66bd2a5BD7c744b90dF8eCBEB34fd26d4` 第 8 行
- **合约**: `TermMaxCheckIn`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      3 | // SPDX-License-Identifier: MIT
      4 | pragma solidity ^0.8.27;
      5 | 
      6 | import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";
      7 | 
>>    8 | contract TermMaxCheckIn is Ownable {
      9 |     event UserCheckedIn(address indexed user);
     10 |     bool public paused;
     11 | 
     12 |     // Mapping to store the last check-in day for each user
     13 |     mapping(address => uint256) public lastCheckInDay;
```

---

### 6. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x007200C66bd2a5BD7c744b90dF8eCBEB34fd26d4` 第 68 行
- **合约**: `TermMaxCheckIn`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     63 |  *
     64 |  * This module is used through inheritance. It will make available the modifier
     65 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     66 |  * the owner.
     67 |  */
>>   68 | abstract contract Ownable is Context {
     69 |     address private _owner;
     70 | 
     71 |     /**
     72 |      * @dev The caller account is not authorized to perform an operation.
     73 |      */
```

---

### 7. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x007200C66bd2a5BD7c744b90dF8eCBEB34fd26d4` 第 140 行
- **合约**: `TermMaxCheckIn`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    135 |         }
    136 |         _transferOwnership(newOwner);
    137 |     }
    138 | 
    139 |     /**
>>  140 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    141 |      * Internal function without access restriction.
    142 |      */
    143 |     function _transferOwnership(address newOwner) internal virtual {
    144 |         address oldOwner = _owner;
    145 |         _owner = newOwner;
```

---

### 8. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x007200C66bd2a5BD7c744b90dF8eCBEB34fd26d4` 第 30 行
- **函数**: `getCurrentDay()`
- **合约**: `TermMaxCheckIn`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     27 |     // Returns the current day number based on UTC+0 (00:00:00)
     28 |     // Day 0 = 1970-01-01, increments every 86400 seconds
     29 |     function getCurrentDay() public view returns (uint256) {
>>   30 |         return block.timestamp / 86400;
     31 |     }
     32 | 
     33 |     // Check if a user has checked in on the current day
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*