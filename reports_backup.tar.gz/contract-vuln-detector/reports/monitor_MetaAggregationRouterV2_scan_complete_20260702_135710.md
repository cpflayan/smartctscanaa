# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:57:10
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` |
| contract_name | `MetaAggregationRouterV2` |
| compiler_version | `v0.8.9+commit.e5eed63a` |
| optimization_used | `True` |
| runs | `999999` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646141` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 26 |
| 🟢 LOW | 5 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 382 行
- **函数**: `functionDelegateCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    379 |     ) internal returns (bytes memory) {
    380 |         require(isContract(target), "Address: delegate call to non-contract");
    381 | 
>>  382 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    383 |         return verifyCallResult(success, returndata, errorMessage);
    384 |     }
    385 | 
```

---

### 2. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 254 行
- **函数**: `sendValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    251 |     function sendValue(address payable recipient, uint256 amount) internal {
    252 |         require(address(this).balance >= amount, "Address: insufficient balance");
    253 | 
>>  254 |         (bool success, ) = recipient.call{value: amount}("");
    255 |         require(success, "Address: unable to send value, recipient may have reverted");
    256 |     }
    257 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 328 行
- **函数**: `functionCallWithValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    325 |         require(address(this).balance >= value, "Address: insufficient balance for call");
    326 |         require(isContract(target), "Address: call to non-contract");
    327 | 
>>  328 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    329 |         return verifyCallResult(success, returndata, errorMessage);
    330 |     }
    331 | 
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 687 行
- **函数**: `_permit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    684 |   ) internal {
    685 |     if (permit.length == 32 * 7) {
    686 |       // solhint-disable-next-line avoid-low-level-calls
>>  687 |       (bool success, bytes memory result) = address(token).call(
    688 |         abi.encodePacked(IERC20Permit.permit.selector, permit)
    689 |       );
    690 |       if (!success) {
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 784 行
- **函数**: `safeApprove()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    781 |     uint256 value
    782 |   ) internal {
    783 |     // bytes4(keccak256(bytes('approve(address,uint256)')));
>>  784 |     (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x095ea7b3, to, value));
    785 |     require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: APPROVE_FAILED');
    786 |   }
    787 | 
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 795 行
- **函数**: `safeTransfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    792 |   ) internal {
    793 |     // bytes4(keccak256(bytes('transfer(address,uint256)')));
    794 |     if (value == 0) return;
>>  795 |     (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
    796 |     require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FAILED');
    797 |   }
    798 | 
```

---

### 7. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 807 行
- **函数**: `safeTransferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    804 |   ) internal {
    805 |     // bytes4(keccak256(bytes('transferFrom(address,address,uint256)')));
    806 |     if (value == 0) return;
>>  807 |     (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x23b872dd, from, to, value));
    808 |     require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FROM_FAILED');
    809 |   }
    810 | 
```

---

### 8. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 813 行
- **函数**: `safeTransferETH()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    810 | 
    811 |   function safeTransferETH(address to, uint256 value) internal {
    812 |     if (value == 0) return;
>>  813 |     (bool success, ) = to.call{value: value}(new bytes(0));
    814 |     require(success, 'TransferHelper: ETH_TRANSFER_FAILED');
    815 |   }
    816 | }
```

---

### 9. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 1220 行
- **函数**: `_swapMultiSequencesWithSimpleMode()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1217 |       {
   1218 |         // solhint-disable-next-line avoid-low-level-calls
   1219 |         // may take some native tokens for commission fee
>> 1220 |         (bool success, bytes memory result) = address(caller).call(
   1221 |           abi.encodeWithSelector(caller.swapSingleSequence.selector, swapData.swapDatas[i])
   1222 |         );
   1223 |         if (!success) {
```

---

### 10. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 1231 行
- **函数**: `_swapMultiSequencesWithSimpleMode()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1228 |     {
   1229 |       // solhint-disable-next-line avoid-low-level-calls
   1230 |       // may take some native tokens for commission fee
>> 1231 |       (bool success, bytes memory result) = address(caller).call(
   1232 |         abi.encodeWithSelector(
   1233 |           caller.finalTransactionProcessing.selector,
   1234 |           tokenIn,
```

---

### 11. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 1271 行
- **函数**: `_executeSwap()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1268 |     uint256 routerInitialDstBalance = _getBalance(desc.dstToken, address(this));
   1269 |     {
   1270 |       // call to external contract
>> 1271 |       (bool success, ) = callTarget.call{value: value}(targetData);
   1272 |       require(success, 'Call failed');
   1273 |     }
   1274 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 29 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     26 |     /**
     27 |      * @dev Returns the amount of tokens in existence.
     28 |      */
>>   29 |     function totalSupply() external view returns (uint256);
     30 | 
     31 |     /**
     32 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 34 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     31 |     /**
     32 |      * @dev Returns the amount of tokens owned by `account`.
     33 |      */
>>   34 |     function balanceOf(address account) external view returns (uint256);
     35 | 
     36 |     /**
     37 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 43 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     40 |      *
     41 |      * Emits a {Transfer} event.
     42 |      */
>>   43 |     function transfer(address to, uint256 amount) external returns (bool);
     44 | 
     45 |     /**
     46 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 52 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     49 |      *
     50 |      * This value changes when {approve} or {transferFrom} are called.
     51 |      */
>>   52 |     function allowance(address owner, address spender) external view returns (uint256);
     53 | 
     54 |     /**
     55 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 68 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     65 |      *
     66 |      * Emits an {Approval} event.
     67 |      */
>>   68 |     function approve(address spender, uint256 amount) external returns (bool);
     69 | 
     70 |     /**
     71 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 147 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    144 |     /**
    145 |      * @dev Returns the address of the current owner.
    146 |      */
>>  147 |     function owner() public view virtual returns (address) {
    148 |         return _owner;
    149 |     }
    150 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 569 行
- **函数**: `nonces()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    566 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
    567 |      * prevents a signature from being used multiple times.
    568 |      */
>>  569 |     function nonces(address owner) external view returns (uint256);
    570 | 
    571 |     /**
    572 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 575 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    572 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
    573 |      */
    574 |     // solhint-disable-next-line func-name-mixedcase
>>  575 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    576 | }
    577 | 
    578 | // File: contracts/libraries/RevertReasonParser.sol
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 709 行
- **函数**: `callBytes()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    706 | pragma solidity >=0.6.12;
    707 | 
    708 | interface IAggregationExecutor {
>>  709 |   function callBytes(bytes calldata data) external payable; // 0xd9c45357
    710 | 
    711 |   // callbytes per swap sequence
    712 |   function swapSingleSequence(bytes calldata data) external;
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 735 行
- **函数**: `callBytes()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    732 | pragma solidity 0.8.9;
    733 | 
    734 | interface IAggregationExecutor1Inch {
>>  735 |   function callBytes(address msgSender, bytes calldata data) external payable; // 0x2636f7f8
    736 | }
    737 | 
    738 | interface IAggregationRouter1InchV4 {
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 132 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    127 |  *
    128 |  * This module is used through inheritance. It will make available the modifier
    129 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    130 |  * the owner.
    131 |  */
>>  132 | abstract contract Ownable is Context {
    133 |     address private _owner;
    134 | 
    135 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    136 | 
    137 |     /**
```

---

### 23. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 180 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    175 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
    176 |         _transferOwnership(newOwner);
    177 |     }
    178 | 
    179 |     /**
>>  180 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    181 |      * Internal function without access restriction.
    182 |      */
    183 |     function _transferOwnership(address newOwner) internal virtual {
    184 |         address oldOwner = _owner;
    185 |         _owner = newOwner;
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 426 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    421 | 
    422 | 
    423 | /**
    424 |  * @title SafeERC20
    425 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>>  426 |  * contract returns false). Tokens that return no value (and instead revert or
    427 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    428 |  * successful.
    429 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    430 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    431 |  */
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 677 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    672 | IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
    673 | WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
    674 | OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE”.
    675 | */
    676 | 
>>  677 | contract Permitable {
    678 |   event Error(string reason);
    679 | 
    680 |   function _permit(
    681 |     IERC20 token,
    682 |     uint256 amount,
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 830 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    825 | 
    826 | 
    827 | 
    828 | 
    829 | 
>>  830 | contract MetaAggregationRouterV2 is Permitable, Ownable {
    831 |   using SafeERC20 for IERC20;
    832 | 
    833 |   address public immutable WETH;
    834 |   address private constant ETH_ADDRESS = address(0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE);
    835 | 
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 1258 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1253 | 
   1254 |   function _isETH(IERC20 token) internal pure returns (bool) {
   1255 |     return (address(token) == ETH_ADDRESS);
   1256 |   }
   1257 | 
>> 1258 |   /// @dev this function calls to external contract to execute swap and also validate the returned amounts
   1259 |   function _executeSwap(
   1260 |     address callTarget,
   1261 |     bytes memory targetData,
   1262 |     SwapDescriptionV2 memory desc,
   1263 |     uint256 value,
```

---

### 28. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 1201 行
- **函数**: `_swapMultiSequencesWithSimpleMode()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1198 |     bytes calldata data
   1199 |   ) internal {
   1200 |     SimpleSwapData memory swapData = abi.decode(data, (SimpleSwapData));
>> 1201 |     require(swapData.deadline >= block.timestamp, 'ROUTER: Expired');
   1202 |     require(
   1203 |       swapData.firstPools.length == swapData.firstSwapAmounts.length &&
   1204 |         swapData.firstPools.length == swapData.swapDatas.length,
```

---

### 29. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 834 行
- **函数**: `safeTransferETH()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    831 |   using SafeERC20 for IERC20;
    832 | 
    833 |   address public immutable WETH;
>>  834 |   address private constant ETH_ADDRESS = address(0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE);
    835 | 
    836 |   uint256 private constant _PARTIAL_FILL = 0x01;
    837 |   uint256 private constant _REQUIRES_EXTRA_ETH = 0x02;
```

---

### 30. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 404 行
- **函数**: `verifyCallResult()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    401 |             if (returndata.length > 0) {
    402 |                 // The easiest way to bubble the revert reason is using memory via assembly
    403 | 
>>  404 |                 assembly {
    405 |                     let returndata_size := mload(returndata)
    406 |                     revert(add(32, returndata), returndata_size)
    407 |                 }
```

---

### 31. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 609 行
- **函数**: `parse()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    606 |     if (data.length >= 68 && data[0] == '\x08' && data[1] == '\xc3' && data[2] == '\x79' && data[3] == '\xa0') {
    607 |       string memory reason;
    608 |       // solhint-disable no-inline-assembly
>>  609 |       assembly {
    610 |         // 68 = 32 bytes data length + 4-byte selector + 32 bytes offset
    611 |         reason := add(data, 68)
    612 |       }
```

---

### 32. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6131B5fae19EA4f9D964eAc0408E4408b66337b5` 第 627 行
- **函数**: `parse()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    624 |     else if (data.length == 36 && data[0] == '\x4e' && data[1] == '\x48' && data[2] == '\x7b' && data[3] == '\x71') {
    625 |       uint256 code;
    626 |       // solhint-disable no-inline-assembly
>>  627 |       assembly {
    628 |         // 36 = 32 bytes data length + 4-byte selector
    629 |         code := mload(add(data, 36))
    630 |       }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*