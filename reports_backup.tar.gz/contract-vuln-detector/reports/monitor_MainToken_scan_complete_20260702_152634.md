# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:26:34
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` |
| contract_name | `MainToken` |
| compiler_version | `v0.8.10+commit.fc410830` |
| optimization_used | `True` |
| runs | `20000` |
| evm_version | `istanbul` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655009` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 76 |
| 🟢 LOW | 8 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 1105 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in MainToken._transfer(address,address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1105-1145):
	External calls:
	- _safeBurnPairAmount((amount * 35) / 100) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1117)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1098)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
		- ILiquidityDelegater(liquidityDelegater).injectionLiquidity() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1100-1102)
	- super._transfer(from,address(this),feeAmount) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1125)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
	- _sellToken(super.balanceOf(address(this)),fee.receiptor) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1126)
		- IPancakeRouter(router).swapExactTokensForTokens(amount,0,paths,to,block.timestamp) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1084-1090)
	- super._transfer(from,fee_scope_2.receiptor,feeAmount_scope_3) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1138)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
	- super._transfer(from,to,amount) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1144)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
	State variables written after the call(s):
	- super._transfer(from,to,amount) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1144)
		- _balances[from] = fromBalance - amount (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#358)
		- _balances[to] += amount (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#360)
	ERC20._balances (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#155) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#376-386)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#345-365)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#220-222)

**代码片段**:
```solidity
   1102 |         }
   1103 |     }
   1104 | 
>> 1105 |     function _transfer(
   1106 |         address from,
   1107 |         address to,
   1108 |         uint256 amount
```

---

### 2. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 1093 行
- **函数**: `_safeBurnPairAmount()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in MainToken._safeBurnPairAmount(uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1093-1103):
	External calls:
	- super._transfer(pair,address(0xdead),pairAmount) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1096)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
	- super._transfer(pair,address(liquidityDelegater),amount - pairAmount) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1097)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
	State variables written after the call(s):
	- super._transfer(pair,address(liquidityDelegater),amount - pairAmount) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1097)
		- _balances[from] = fromBalance - amount (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#358)
		- _balances[to] += amount (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#360)
	ERC20._balances (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#155) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#376-386)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#345-365)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#220-222)

**代码片段**:
```solidity
   1090 |         );
   1091 |     }
   1092 | 
>> 1093 |     function _safeBurnPairAmount(uint256 amount) internal {
   1094 |         uint256 pairAmount = (amount * 99999) / 100000;
   1095 | 
   1096 |         super._transfer(pair, address(0xdead), pairAmount);
```

---

### 3. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 1105 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in MainToken._transfer(address,address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1105-1145):
	External calls:
	- _safeBurnPairAmount((amount * 35) / 100) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1117)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1098)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
		- ILiquidityDelegater(liquidityDelegater).injectionLiquidity() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1100-1102)
	- super._transfer(from,address(this),feeAmount) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1125)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
	- _sellToken(super.balanceOf(address(this)),fee.receiptor) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1126)
		- IPancakeRouter(router).swapExactTokensForTokens(amount,0,paths,to,block.timestamp) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1084-1090)
	State variables written after the call(s):
	- super._transfer(from,address(this),feeAmount) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1125)
		- _balances[from] = fromBalance - amount (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#358)
		- _balances[to] += amount (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#360)
	ERC20._balances (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#155) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#376-386)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#345-365)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#220-222)

**代码片段**:
```solidity
   1102 |         }
   1103 |     }
   1104 | 
>> 1105 |     function _transfer(
   1106 |         address from,
   1107 |         address to,
   1108 |         uint256 amount
```

---

### 4. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 1105 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in MainToken._transfer(address,address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1105-1145):
	External calls:
	- _safeBurnPairAmount((amount * 35) / 100) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1117)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1098)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
		- ILiquidityDelegater(liquidityDelegater).injectionLiquidity() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1100-1102)
	- super._transfer(from,address(this),feeAmount) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1125)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
	- _sellToken(super.balanceOf(address(this)),fee.receiptor) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1126)
		- IPancakeRouter(router).swapExactTokensForTokens(amount,0,paths,to,block.timestamp) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1084-1090)
	- super._transfer(from,fee_scope_2.receiptor,feeAmount_scope_3) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1138)
		- IOracleUpdate(oracle).update() (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1073)
	State variables written after the call(s):
	- super._transfer(from,fee_scope_2.receiptor,feeAmount_scope_3) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1138)
		- _balances[from] = fromBalance - amount (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#358)
		- _balances[to] += amount (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#360)
	ERC20._balances (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#155) can be used in cross function reentrancies:
	- ERC20._mint(address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#376-386)
	- ERC20._transfer(address,address,uint256) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#345-365)
	- ERC20.balanceOf(address) (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#220-222)

**代码片段**:
```solidity
   1102 |         }
   1103 |     }
   1104 | 
>> 1105 |     function _transfer(
   1106 |         address from,
   1107 |         address to,
   1108 |         uint256 amount
```

---

### 5. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 837 行
- **函数**: `getReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    834 |     function factory() external view returns (address);
    835 |     function token0() external view returns (address);
    836 |     function token1() external view returns (address);
>>  837 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    838 |     function price0CumulativeLast() external view returns (uint);
    839 |     function price1CumulativeLast() external view returns (uint);
    840 |     function kLast() external view returns (uint);
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 27 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     24 |     /**
     25 |      * @dev Returns the amount of tokens in existence.
     26 |      */
>>   27 |     function totalSupply() external view returns (uint256);
     28 | 
     29 |     /**
     30 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 32 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     29 |     /**
     30 |      * @dev Returns the amount of tokens owned by `account`.
     31 |      */
>>   32 |     function balanceOf(address account) external view returns (uint256);
     33 | 
     34 |     /**
     35 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 41 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     38 |      *
     39 |      * Emits a {Transfer} event.
     40 |      */
>>   41 |     function transfer(address to, uint256 amount) external returns (bool);
     42 | 
     43 |     /**
     44 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 50 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     47 |      *
     48 |      * This value changes when {approve} or {transferFrom} are called.
     49 |      */
>>   50 |     function allowance(address owner, address spender) external view returns (uint256);
     51 | 
     52 |     /**
     53 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 66 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     63 |      *
     64 |      * Emits an {Approval} event.
     65 |      */
>>   66 |     function approve(address spender, uint256 amount) external returns (bool);
     67 | 
     68 |     /**
     69 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 94 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     91 |     /**
     92 |      * @dev Returns the name of the token.
     93 |      */
>>   94 |     function name() external view returns (string memory);
     95 | 
     96 |     /**
     97 |      * @dev Returns the symbol of the token.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 99 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     96 |     /**
     97 |      * @dev Returns the symbol of the token.
     98 |      */
>>   99 |     function symbol() external view returns (string memory);
    100 | 
    101 |     /**
    102 |      * @dev Returns the decimals places of the token.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 104 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    101 |     /**
    102 |      * @dev Returns the decimals places of the token.
    103 |      */
>>  104 |     function decimals() external view returns (uint8);
    105 | }
    106 | 
    107 | // OpenZeppelin Contracts v4.4.1 (utils/Context.sol)
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 181 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    178 |     /**
    179 |      * @dev Returns the name of the token.
    180 |      */
>>  181 |     function name() public view virtual override returns (string memory) {
    182 |         return _name;
    183 |     }
    184 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 189 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    186 |      * @dev Returns the symbol of the token, usually a shorter version of the
    187 |      * name.
    188 |      */
>>  189 |     function symbol() public view virtual override returns (string memory) {
    190 |         return _symbol;
    191 |     }
    192 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 206 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    203 |      * no way affects any of the arithmetic of the contract, including
    204 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    205 |      */
>>  206 |     function decimals() public view virtual override returns (uint8) {
    207 |         return 18;
    208 |     }
    209 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 213 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    210 |     /**
    211 |      * @dev See {IERC20-totalSupply}.
    212 |      */
>>  213 |     function totalSupply() public view virtual override returns (uint256) {
    214 |         return _totalSupply;
    215 |     }
    216 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 220 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    217 |     /**
    218 |      * @dev See {IERC20-balanceOf}.
    219 |      */
>>  220 |     function balanceOf(address account) public view virtual override returns (uint256) {
    221 |         return _balances[account];
    222 |     }
    223 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 232 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    229 |      * - `to` cannot be the zero address.
    230 |      * - the caller must have a balance of at least `amount`.
    231 |      */
>>  232 |     function transfer(address to, uint256 amount) public virtual override returns (bool) {
    233 |         address owner = _msgSender();
    234 |         _transfer(owner, to, amount);
    235 |         return true;
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 241 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    238 |     /**
    239 |      * @dev See {IERC20-allowance}.
    240 |      */
>>  241 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    242 |         return _allowances[owner][spender];
    243 |     }
    244 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 255 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    252 |      *
    253 |      * - `spender` cannot be the zero address.
    254 |      */
>>  255 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    256 |         address owner = _msgSender();
    257 |         _approve(owner, spender, amount);
    258 |         return true;
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 300 行
- **函数**: `increaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    297 |      *
    298 |      * - `spender` cannot be the zero address.
    299 |      */
>>  300 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    301 |         address owner = _msgSender();
    302 |         _approve(owner, spender, allowance(owner, spender) + addedValue);
    303 |         return true;
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 320 行
- **函数**: `decreaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    317 |      * - `spender` must have allowance for the caller of at least
    318 |      * `subtractedValue`.
    319 |      */
>>  320 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    321 |         address owner = _msgSender();
    322 |         uint256 currentAllowance = allowance(owner, spender);
    323 |         require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 532 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    529 |     /**
    530 |      * @dev Returns the address of the current owner.
    531 |      */
>>  532 |     function owner() public view virtual returns (address) {
    533 |         return _owner;
    534 |     }
    535 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 581 行
- **函数**: `factory()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    578 | 
    579 | 
    580 | interface IPancakeRouter {
>>  581 |     function factory() external view returns (address);
    582 | 
    583 |     function WETH() external view returns (address);
    584 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 583 行
- **函数**: `WETH()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    580 | interface IPancakeRouter {
    581 |     function factory() external view returns (address);
    582 | 
>>  583 |     function WETH() external view returns (address);
    584 | 
    585 |     function addLiquidity(
    586 |         address tokenA,
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 775 行
- **函数**: `INIT_CODE_PAIR_HASH()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    772 | }
    773 | 
    774 | interface IPancakeFactory {
>>  775 |     function INIT_CODE_PAIR_HASH() external pure returns (bytes32);
    776 | 
    777 |     function feeTo() external view returns (address);
    778 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 777 行
- **函数**: `feeTo()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    774 | interface IPancakeFactory {
    775 |     function INIT_CODE_PAIR_HASH() external pure returns (bytes32);
    776 | 
>>  777 |     function feeTo() external view returns (address);
    778 | 
    779 |     function feeToSetter() external view returns (address);
    780 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 779 行
- **函数**: `feeToSetter()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    776 | 
    777 |     function feeTo() external view returns (address);
    778 | 
>>  779 |     function feeToSetter() external view returns (address);
    780 | 
    781 |     function getPair(
    782 |         address tokenA,
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 786 行
- **函数**: `allPairs()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    783 |         address tokenB
    784 |     ) external view returns (address pair);
    785 | 
>>  786 |     function allPairs(uint256) external view returns (address pair);
    787 | 
    788 |     function allPairsLength() external view returns (uint256);
    789 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 788 行
- **函数**: `allPairsLength()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    785 | 
    786 |     function allPairs(uint256) external view returns (address pair);
    787 | 
>>  788 |     function allPairsLength() external view returns (uint256);
    789 | 
    790 |     function createPair(
    791 |         address tokenA,
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 804 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    801 |     event Approval(address indexed owner, address indexed spender, uint value);
    802 |     event Transfer(address indexed from, address indexed to, uint value);
    803 | 
>>  804 |     function name() external pure returns (string memory);
    805 |     function symbol() external pure returns (string memory);
    806 |     function decimals() external pure returns (uint8);
    807 |     function totalSupply() external view returns (uint);
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 805 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    802 |     event Transfer(address indexed from, address indexed to, uint value);
    803 | 
    804 |     function name() external pure returns (string memory);
>>  805 |     function symbol() external pure returns (string memory);
    806 |     function decimals() external pure returns (uint8);
    807 |     function totalSupply() external view returns (uint);
    808 |     function balanceOf(address owner) external view returns (uint);
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 806 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    803 | 
    804 |     function name() external pure returns (string memory);
    805 |     function symbol() external pure returns (string memory);
>>  806 |     function decimals() external pure returns (uint8);
    807 |     function totalSupply() external view returns (uint);
    808 |     function balanceOf(address owner) external view returns (uint);
    809 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 807 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    804 |     function name() external pure returns (string memory);
    805 |     function symbol() external pure returns (string memory);
    806 |     function decimals() external pure returns (uint8);
>>  807 |     function totalSupply() external view returns (uint);
    808 |     function balanceOf(address owner) external view returns (uint);
    809 |     function allowance(address owner, address spender) external view returns (uint);
    810 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 808 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    805 |     function symbol() external pure returns (string memory);
    806 |     function decimals() external pure returns (uint8);
    807 |     function totalSupply() external view returns (uint);
>>  808 |     function balanceOf(address owner) external view returns (uint);
    809 |     function allowance(address owner, address spender) external view returns (uint);
    810 | 
    811 |     function approve(address spender, uint value) external returns (bool);
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 809 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    806 |     function decimals() external pure returns (uint8);
    807 |     function totalSupply() external view returns (uint);
    808 |     function balanceOf(address owner) external view returns (uint);
>>  809 |     function allowance(address owner, address spender) external view returns (uint);
    810 | 
    811 |     function approve(address spender, uint value) external returns (bool);
    812 |     function transfer(address to, uint value) external returns (bool);
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 811 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    808 |     function balanceOf(address owner) external view returns (uint);
    809 |     function allowance(address owner, address spender) external view returns (uint);
    810 | 
>>  811 |     function approve(address spender, uint value) external returns (bool);
    812 |     function transfer(address to, uint value) external returns (bool);
    813 |     function transferFrom(address from, address to, uint value) external returns (bool);
    814 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 812 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    809 |     function allowance(address owner, address spender) external view returns (uint);
    810 | 
    811 |     function approve(address spender, uint value) external returns (bool);
>>  812 |     function transfer(address to, uint value) external returns (bool);
    813 |     function transferFrom(address from, address to, uint value) external returns (bool);
    814 | 
    815 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 813 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    810 | 
    811 |     function approve(address spender, uint value) external returns (bool);
    812 |     function transfer(address to, uint value) external returns (bool);
>>  813 |     function transferFrom(address from, address to, uint value) external returns (bool);
    814 | 
    815 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    816 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 815 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    812 |     function transfer(address to, uint value) external returns (bool);
    813 |     function transferFrom(address from, address to, uint value) external returns (bool);
    814 | 
>>  815 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    816 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
    817 |     function nonces(address owner) external view returns (uint);
    818 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 816 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    813 |     function transferFrom(address from, address to, uint value) external returns (bool);
    814 | 
    815 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>>  816 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
    817 |     function nonces(address owner) external view returns (uint);
    818 | 
    819 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 817 行
- **函数**: `nonces()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    814 | 
    815 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    816 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>>  817 |     function nonces(address owner) external view returns (uint);
    818 | 
    819 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
    820 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 833 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    830 |     );
    831 |     event Sync(uint112 reserve0, uint112 reserve1);
    832 | 
>>  833 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
    834 |     function factory() external view returns (address);
    835 |     function token0() external view returns (address);
    836 |     function token1() external view returns (address);
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 834 行
- **函数**: `factory()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    831 |     event Sync(uint112 reserve0, uint112 reserve1);
    832 | 
    833 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
>>  834 |     function factory() external view returns (address);
    835 |     function token0() external view returns (address);
    836 |     function token1() external view returns (address);
    837 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 835 行
- **函数**: `token0()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    832 | 
    833 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
    834 |     function factory() external view returns (address);
>>  835 |     function token0() external view returns (address);
    836 |     function token1() external view returns (address);
    837 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    838 |     function price0CumulativeLast() external view returns (uint);
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 836 行
- **函数**: `token1()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    833 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
    834 |     function factory() external view returns (address);
    835 |     function token0() external view returns (address);
>>  836 |     function token1() external view returns (address);
    837 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    838 |     function price0CumulativeLast() external view returns (uint);
    839 |     function price1CumulativeLast() external view returns (uint);
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 837 行
- **函数**: `getReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    834 |     function factory() external view returns (address);
    835 |     function token0() external view returns (address);
    836 |     function token1() external view returns (address);
>>  837 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    838 |     function price0CumulativeLast() external view returns (uint);
    839 |     function price1CumulativeLast() external view returns (uint);
    840 |     function kLast() external view returns (uint);
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 838 行
- **函数**: `price0CumulativeLast()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    835 |     function token0() external view returns (address);
    836 |     function token1() external view returns (address);
    837 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>>  838 |     function price0CumulativeLast() external view returns (uint);
    839 |     function price1CumulativeLast() external view returns (uint);
    840 |     function kLast() external view returns (uint);
    841 | 
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 839 行
- **函数**: `price1CumulativeLast()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    836 |     function token1() external view returns (address);
    837 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    838 |     function price0CumulativeLast() external view returns (uint);
>>  839 |     function price1CumulativeLast() external view returns (uint);
    840 |     function kLast() external view returns (uint);
    841 | 
    842 |     function mint(address to) external returns (uint liquidity);
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 840 行
- **函数**: `kLast()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    837 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    838 |     function price0CumulativeLast() external view returns (uint);
    839 |     function price1CumulativeLast() external view returns (uint);
>>  840 |     function kLast() external view returns (uint);
    841 | 
    842 |     function mint(address to) external returns (uint liquidity);
    843 |     function burn(address to) external returns (uint amount0, uint amount1);
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 842 行
- **函数**: `mint()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    839 |     function price1CumulativeLast() external view returns (uint);
    840 |     function kLast() external view returns (uint);
    841 | 
>>  842 |     function mint(address to) external returns (uint liquidity);
    843 |     function burn(address to) external returns (uint amount0, uint amount1);
    844 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    845 |     function skim(address to) external;
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 843 行
- **函数**: `burn()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    840 |     function kLast() external view returns (uint);
    841 | 
    842 |     function mint(address to) external returns (uint liquidity);
>>  843 |     function burn(address to) external returns (uint amount0, uint amount1);
    844 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    845 |     function skim(address to) external;
    846 |     function sync() external;
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 857 行
- **函数**: `seasons()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    854 | }
    855 | 
    856 | interface ISeasonRouter {
>>  857 |     function seasons() external view returns (SeasonInfo[] memory);
    858 |     function currentSeason() external view returns (SeasonInfo memory);
    859 |     function currentSeasonIndex() external view returns (uint256);
    860 |     function todayTotalEarnedReward() external view returns (uint256);
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 858 行
- **函数**: `currentSeason()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    855 | 
    856 | interface ISeasonRouter {
    857 |     function seasons() external view returns (SeasonInfo[] memory);
>>  858 |     function currentSeason() external view returns (SeasonInfo memory);
    859 |     function currentSeasonIndex() external view returns (uint256);
    860 |     function todayTotalEarnedReward() external view returns (uint256);
    861 |     function todaySeasonRewardsOfIndex(uint256 seasonIndex) external view returns (uint256);
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 859 行
- **函数**: `currentSeasonIndex()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    856 | interface ISeasonRouter {
    857 |     function seasons() external view returns (SeasonInfo[] memory);
    858 |     function currentSeason() external view returns (SeasonInfo memory);
>>  859 |     function currentSeasonIndex() external view returns (uint256);
    860 |     function todayTotalEarnedReward() external view returns (uint256);
    861 |     function todaySeasonRewardsOfIndex(uint256 seasonIndex) external view returns (uint256);
    862 |     function isEnablePurchasePower() external view returns (bool);
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 860 行
- **函数**: `todayTotalEarnedReward()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    857 |     function seasons() external view returns (SeasonInfo[] memory);
    858 |     function currentSeason() external view returns (SeasonInfo memory);
    859 |     function currentSeasonIndex() external view returns (uint256);
>>  860 |     function todayTotalEarnedReward() external view returns (uint256);
    861 |     function todaySeasonRewardsOfIndex(uint256 seasonIndex) external view returns (uint256);
    862 |     function isEnablePurchasePower() external view returns (bool);
    863 | }
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 861 行
- **函数**: `todaySeasonRewardsOfIndex()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    858 |     function currentSeason() external view returns (SeasonInfo memory);
    859 |     function currentSeasonIndex() external view returns (uint256);
    860 |     function todayTotalEarnedReward() external view returns (uint256);
>>  861 |     function todaySeasonRewardsOfIndex(uint256 seasonIndex) external view returns (uint256);
    862 |     function isEnablePurchasePower() external view returns (bool);
    863 | }
    864 | 
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 862 行
- **函数**: `isEnablePurchasePower()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    859 |     function currentSeasonIndex() external view returns (uint256);
    860 |     function todayTotalEarnedReward() external view returns (uint256);
    861 |     function todaySeasonRewardsOfIndex(uint256 seasonIndex) external view returns (uint256);
>>  862 |     function isEnablePurchasePower() external view returns (bool);
    863 | }
    864 | 
    865 | interface ILiquidityDelegater {
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 866 行
- **函数**: `router()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    863 | }
    864 | 
    865 | interface ILiquidityDelegater {
>>  866 |     function router() external view returns (address);
    867 | 
    868 |     function token() external view returns (address);
    869 | 
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 868 行
- **函数**: `token()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    865 | interface ILiquidityDelegater {
    866 |     function router() external view returns (address);
    867 | 
>>  868 |     function token() external view returns (address);
    869 | 
    870 |     function usdt() external view returns (address);
    871 | 
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 870 行
- **函数**: `usdt()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    867 | 
    868 |     function token() external view returns (address);
    869 | 
>>  870 |     function usdt() external view returns (address);
    871 | 
    872 |     function injectionLiquidity()
    873 |         external
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 968 行
- **函数**: `addGuarded()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    965 |         oracle = _oracle;
    966 |     }
    967 | 
>>  968 |     function addGuarded(address account) external onlyOperatorOrSeasonRouter {
    969 |         require(!isGuardedOf[account], "account already exist");
    970 |         isGuardedOf[account] = true;
    971 |         emit Guarded(account, true);
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 974 行
- **函数**: `delGuarded()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    971 |         emit Guarded(account, true);
    972 |     }
    973 | 
>>  974 |     function delGuarded(address account) external onlyOperatorOrSeasonRouter {
    975 |         require(account != address(this), "cannot delete self address");
    976 |         require(isGuardedOf[account], "account not guarded");
    977 |         isGuardedOf[account] = false;
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 981 行
- **函数**: `addPurchaser()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    978 |         emit Guarded(account, false);
    979 |     }
    980 | 
>>  981 |     function addPurchaser(address account) external onlyOperatorOrSeasonRouter {
    982 |         require(!isPurchaserOf[account], "account already exist");
    983 |         isPurchaserOf[account] = true;
    984 |     }
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 986 行
- **函数**: `delPurchaser()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    983 |         isPurchaserOf[account] = true;
    984 |     }
    985 | 
>>  986 |     function delPurchaser(address account) external onlyOperatorOrSeasonRouter {
    987 |         require(isPurchaserOf[account], "account not buyer");
    988 |         isPurchaserOf[account] = false;
    989 |     }
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 1006 行
- **函数**: `addBuyFee()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1003 |         sellFees.push(FeeReceiptor(feeRate, feeReceiver));
   1004 |     }
   1005 | 
>> 1006 |     function addBuyFee(uint40 feeRate, address feeReceiver) external onlyOperator {
   1007 |         buyFees.push(FeeReceiptor(feeRate, feeReceiver));
   1008 |     }
   1009 | 
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 1020 行
- **函数**: `transferOperator()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1017 |         sellFees[index].receiptor = feeReceiver;
   1018 |     }
   1019 | 
>> 1020 |     function transferOperator(address _operator) external onlyOperator {
   1021 |         operator = _operator;
   1022 |     }
   1023 | 
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 1034 行
- **函数**: `delSellFee()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1031 |         buyFees[index].receiptor = feeReceiver;
   1032 |     }
   1033 | 
>> 1034 |     function delSellFee(uint256 index) external onlyOperator {
   1035 |         require(index < sellFees.length, "Invaild Index");
   1036 |         for (uint256 i = index; i < sellFees.length - 1; i++) {
   1037 |             sellFees[i] = sellFees[i + 1];
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 1042 行
- **函数**: `delBuyFee()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1039 |         sellFees.pop();
   1040 |     }
   1041 | 
>> 1042 |     function delBuyFee(uint256 index) external onlyOperator {
   1043 |         require(index < buyFees.length, "Invaild Index");
   1044 |         for (uint256 i = index; i < buyFees.length - 1; i++) {
   1045 |             buyFees[i] = buyFees[i + 1];
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 1050 行
- **函数**: `enableSwapPurchase()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1047 |         buyFees.pop();
   1048 |     }
   1049 | 
>> 1050 |     function enableSwapPurchase() external onlyOperator {
   1051 |         require(
   1052 |             IERC20(usdt).balanceOf(pair) >= 6000000e18 ||
   1053 |                 block.timestamp >= 1774915200,
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 1059 行
- **函数**: `activeTotalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1056 |         isOpenBuy = true;
   1057 |     }
   1058 | 
>> 1059 |     function activeTotalSupply() external view returns (uint256) {
   1060 |         return totalSupply() - balanceOf(address(0xdead)) - balanceOf(address(0));
   1061 |     }
   1062 | 
```

---

### 73. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 154 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    149 |  *
    150 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    151 |  * functions have been added to mitigate the well-known issues around setting
    152 |  * allowances. See {IERC20-approve}.
    153 |  */
>>  154 | contract ERC20 is Context, IERC20, IERC20Metadata {
    155 |     mapping(address => uint256) private _balances;
    156 | 
    157 |     mapping(address => mapping(address => uint256)) private _allowances;
    158 | 
    159 |     uint256 private _totalSupply;
```

---

### 74. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 517 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    512 |  *
    513 |  * This module is used through inheritance. It will make available the modifier
    514 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    515 |  * the owner.
    516 |  */
>>  517 | abstract contract Ownable is Context {
    518 |     address private _owner;
    519 | 
    520 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    521 | 
    522 |     /**
```

---

### 75. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 565 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    560 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
    561 |         _transferOwnership(newOwner);
    562 |     }
    563 | 
    564 |     /**
>>  565 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    566 |      * Internal function without access restriction.
    567 |      */
    568 |     function _transferOwnership(address newOwner) internal virtual {
    569 |         address oldOwner = _owner;
    570 |         _owner = newOwner;
```

---

### 76. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 907 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    902 | struct FeeReceiptor {
    903 |     uint256 rate;
    904 |     address receiptor;
    905 | }
    906 | 
>>  907 | contract MainToken is ERC20, Ownable {
    908 |     address public pair;
    909 |     address public usdt;
    910 |     address public router;
    911 |     address public liquidityDelegater;
    912 |     ISeasonRouter public seasonRouter;
```

---

### 77. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 1020 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: MainToken.transferOperator(address)._operator (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1020) lacks a zero-check on :
		- operator = _operator (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#1021)

**代码片段**:
```solidity
   1017 |         sellFees[index].receiptor = feeReceiver;
   1018 |     }
   1019 | 
>> 1020 |     function transferOperator(address _operator) external onlyOperator {
   1021 |         operator = _operator;
   1022 |     }
   1023 | 
```

---

### 78. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 964 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: MainToken.setOracle(address)._oracle (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#964) lacks a zero-check on :
		- oracle = _oracle (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#965)

**代码片段**:
```solidity
    961 |         seasonRouter = ISeasonRouter(_seasonRouter);
    962 |     }
    963 | 
>>  964 |     function setOracle(address _oracle) external onlyOwner {
    965 |         oracle = _oracle;
    966 |     }
    967 | 
```

---

### 79. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 943 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: MainToken.constructor(address,address,address,address)._liquidityDelegater (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#943) lacks a zero-check on :
		- liquidityDelegater = _liquidityDelegater (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#950)

**代码片段**:
```solidity
    940 |     constructor(
    941 |         address _usdt,
    942 |         address _router,
>>  943 |         address _liquidityDelegater,
    944 |         address _operator
    945 |     ) ERC20("Acorn", "AC") {
    946 |         _mint(msg.sender, 8000000000e18);
```

---

### 80. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 944 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: MainToken.constructor(address,address,address,address)._operator (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#944) lacks a zero-check on :
		- operator = _operator (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#951)

**代码片段**:
```solidity
    941 |         address _usdt,
    942 |         address _router,
    943 |         address _liquidityDelegater,
>>  944 |         address _operator
    945 |     ) ERC20("Acorn", "AC") {
    946 |         _mint(msg.sender, 8000000000e18);
    947 | 
```

---

### 81. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 942 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: MainToken.constructor(address,address,address,address)._router (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#942) lacks a zero-check on :
		- router = _router (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#948)

**代码片段**:
```solidity
    939 | 
    940 |     constructor(
    941 |         address _usdt,
>>  942 |         address _router,
    943 |         address _liquidityDelegater,
    944 |         address _operator
    945 |     ) ERC20("Acorn", "AC") {
```

---

### 82. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol` 第 941 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: MainToken.constructor(address,address,address,address)._usdt (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#941) lacks a zero-check on :
		- usdt = _usdt (../../../tmp/slither_scan_ru3rusdp/0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77.sol#949)

**代码片段**:
```solidity
    938 |     }
    939 | 
    940 |     constructor(
>>  941 |         address _usdt,
    942 |         address _router,
    943 |         address _liquidityDelegater,
    944 |         address _operator
```

---

### 83. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 1053 行
- **函数**: `enableSwapPurchase()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1050 |     function enableSwapPurchase() external onlyOperator {
   1051 |         require(
   1052 |             IERC20(usdt).balanceOf(pair) >= 6000000e18 ||
>> 1053 |                 block.timestamp >= 1774915200,
   1054 |             "insufficient liquidity or already exceeded the time"
   1055 |         );
   1056 |         isOpenBuy = true;
```

---

### 84. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x2b280B233B681F54C04e91341B6B601a1Ef1Ff77` 第 1089 行
- **函数**: `_sellToken()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1086 |             0,
   1087 |             paths,
   1088 |             to,
>> 1089 |             block.timestamp
   1090 |         );
   1091 |     }
   1092 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*