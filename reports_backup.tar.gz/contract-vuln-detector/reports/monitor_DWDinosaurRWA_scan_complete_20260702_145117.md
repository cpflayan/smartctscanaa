# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:51:17
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` |
| contract_name | `DWDinosaurRWA` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `shanghai` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['npm/@openzeppelin/contracts@5.4.0/access/Ownable.sol', 'npm/@openzeppelin/contracts@5.4.0/interfaces/draft-IERC6093.sol', 'npm/@openzeppelin/contracts@5.4.0/interfaces/IERC5267.sol', 'npm/@openzeppelin/contracts@5.4.0/token/ERC20/ERC20.sol', 'npm/@openzeppelin/contracts@5.4.0/token/ERC20/extensions/ERC20Pausable.sol', 'npm/@openzeppelin/contracts@5.4.0/token/ERC20/extensions/ERC20Permit.sol', 'npm/@openzeppelin/contracts@5.4.0/token/ERC20/extensions/IERC20Metadata.sol', 'npm/@openzeppelin/contracts@5.4.0/token/ERC20/extensions/IERC20Permit.sol', 'npm/@openzeppelin/contracts@5.4.0/token/ERC20/IERC20.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/Context.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/cryptography/ECDSA.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/cryptography/EIP712.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/cryptography/MessageHashUtils.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/math/Math.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/math/SafeCast.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/math/SignedMath.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/Nonces.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/Panic.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/Pausable.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/ShortStrings.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/StorageSlot.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/Strings.sol', 'project/contracts/DWDinosaurRWA.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655005` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 35 |
| 🟢 LOW | 4 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 58 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     55 |     /**
     56 |      * @dev Returns the address of the current owner.
     57 |      */
>>   58 |     function owner() public view virtual returns (address) {
     59 |         return _owner;
     60 |     }
     61 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 355 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    352 |     /**
    353 |      * @dev Returns the name of the token.
    354 |      */
>>  355 |     function name() public view virtual returns (string memory) {
    356 |         return _name;
    357 |     }
    358 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 363 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    360 |      * @dev Returns the symbol of the token, usually a shorter version of the
    361 |      * name.
    362 |      */
>>  363 |     function symbol() public view virtual returns (string memory) {
    364 |         return _symbol;
    365 |     }
    366 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 380 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    377 |      * no way affects any of the arithmetic of the contract, including
    378 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    379 |      */
>>  380 |     function decimals() public view virtual returns (uint8) {
    381 |         return 18;
    382 |     }
    383 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 385 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    382 |     }
    383 | 
    384 |     /// @inheritdoc IERC20
>>  385 |     function totalSupply() public view virtual returns (uint256) {
    386 |         return _totalSupply;
    387 |     }
    388 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 390 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    387 |     }
    388 | 
    389 |     /// @inheritdoc IERC20
>>  390 |     function balanceOf(address account) public view virtual returns (uint256) {
    391 |         return _balances[account];
    392 |     }
    393 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 402 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    399 |      * - `to` cannot be the zero address.
    400 |      * - the caller must have a balance of at least `value`.
    401 |      */
>>  402 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    403 |         address owner = _msgSender();
    404 |         _transfer(owner, to, value);
    405 |         return true;
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 409 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    406 |     }
    407 | 
    408 |     /// @inheritdoc IERC20
>>  409 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    410 |         return _allowances[owner][spender];
    411 |     }
    412 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 423 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    420 |      *
    421 |      * - `spender` cannot be the zero address.
    422 |      */
>>  423 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    424 |         address owner = _msgSender();
    425 |         _approve(owner, spender, value);
    426 |         return true;
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 445 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    442 |      * - the caller must have allowance for ``from``'s tokens of at least
    443 |      * `value`.
    444 |      */
>>  445 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    446 |         address spender = _msgSender();
    447 |         _spendAllowance(from, spender, value);
    448 |         _transfer(from, to, value);
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 717 行
- **函数**: `nonces()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    714 |     }
    715 | 
    716 |     /// @inheritdoc IERC20Permit
>>  717 |     function nonces(address owner) public view virtual override(IERC20Permit, Nonces) returns (uint256) {
    718 |         return super.nonces(owner);
    719 |     }
    720 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 723 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    720 | 
    721 |     /// @inheritdoc IERC20Permit
    722 |     // solhint-disable-next-line func-name-mixedcase
>>  723 |     function DOMAIN_SEPARATOR() external view virtual returns (bytes32) {
    724 |         return _domainSeparatorV4();
    725 |     }
    726 | }
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 745 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    742 |     /**
    743 |      * @dev Returns the name of the token.
    744 |      */
>>  745 |     function name() external view returns (string memory);
    746 | 
    747 |     /**
    748 |      * @dev Returns the symbol of the token.
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 750 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    747 |     /**
    748 |      * @dev Returns the symbol of the token.
    749 |      */
>>  750 |     function symbol() external view returns (string memory);
    751 | 
    752 |     /**
    753 |      * @dev Returns the decimals places of the token.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 755 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    752 |     /**
    753 |      * @dev Returns the decimals places of the token.
    754 |      */
>>  755 |     function decimals() external view returns (uint8);
    756 | }
    757 | 
    758 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 843 行
- **函数**: `nonces()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    840 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
    841 |      * prevents a signature from being used multiple times.
    842 |      */
>>  843 |     function nonces(address owner) external view returns (uint256);
    844 | 
    845 |     /**
    846 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 849 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    846 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
    847 |      */
    848 |     // solhint-disable-next-line func-name-mixedcase
>>  849 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    850 | }
    851 | 
    852 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 881 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    878 |     /**
    879 |      * @dev Returns the value of tokens in existence.
    880 |      */
>>  881 |     function totalSupply() external view returns (uint256);
    882 | 
    883 |     /**
    884 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 886 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    883 |     /**
    884 |      * @dev Returns the value of tokens owned by `account`.
    885 |      */
>>  886 |     function balanceOf(address account) external view returns (uint256);
    887 | 
    888 |     /**
    889 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 895 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    892 |      *
    893 |      * Emits a {Transfer} event.
    894 |      */
>>  895 |     function transfer(address to, uint256 value) external returns (bool);
    896 | 
    897 |     /**
    898 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 904 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    901 |      *
    902 |      * This value changes when {approve} or {transferFrom} are called.
    903 |      */
>>  904 |     function allowance(address owner, address spender) external view returns (uint256);
    905 | 
    906 |     /**
    907 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 921 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    918 |      *
    919 |      * Emits an {Approval} event.
    920 |      */
>>  921 |     function approve(address spender, uint256 value) external returns (bool);
    922 | 
    923 |     /**
    924 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 932 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    929 |      *
    930 |      * Emits a {Transfer} event.
    931 |      */
>>  932 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    933 | }
    934 | 
    935 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 3430 行
- **函数**: `nonces()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3427 |     /**
   3428 |      * @dev Returns the next unused nonce for an address.
   3429 |      */
>> 3430 |     function nonces(address owner) public view virtual returns (uint256) {
   3431 |         return _nonces[owner];
   3432 |     }
   3433 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 3589 行
- **函数**: `paused()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3586 |     /**
   3587 |      * @dev Returns true if the contract is paused, and false otherwise.
   3588 |      */
>> 3589 |     function paused() public view virtual returns (bool) {
   3590 |         return _paused;
   3591 |     }
   3592 | 
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 22 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     17 |  *
     18 |  * This module is used through inheritance. It will make available the modifier
     19 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     20 |  * the owner.
     21 |  */
>>   22 | abstract contract Ownable is Context {
     23 |     address private _owner;
     24 | 
     25 |     /**
     26 |      * @dev The caller account is not authorized to perform an operation.
     27 |      */
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 94 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     89 |         }
     90 |         _transferOwnership(newOwner);
     91 |     }
     92 | 
     93 |     /**
>>   94 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     95 |      * Internal function without access restriction.
     96 |      */
     97 |     function _transferOwnership(address newOwner) internal virtual {
     98 |         address oldOwner = _owner;
     99 |         _owner = newOwner;
```

---

### 28. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 332 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    327 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    328 |  * instead returning `false` on failure. This behavior is nonetheless
    329 |  * conventional and does not conflict with the expectations of ERC-20
    330 |  * applications.
    331 |  */
>>  332 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    333 |     mapping(address account => uint256) private _balances;
    334 | 
    335 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    336 | 
    337 |     uint256 private _totalSupply;
```

---

### 29. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 669 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    664 |  *
    665 |  * Adds the {permit} method, which can be used to change an account's ERC-20 allowance (see {IERC20-allowance}) by
    666 |  * presenting a message signed by the account. By not relying on `{IERC20-approve}`, the token holder account doesn't
    667 |  * need to send a transaction, and thus is not required to hold Ether at all.
    668 |  */
>>  669 | abstract contract ERC20Permit is ERC20, IERC20Permit, EIP712, Nonces {
    670 |     bytes32 private constant PERMIT_TYPEHASH =
    671 |         keccak256("Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)");
    672 | 
    673 |     /**
    674 |      * @dev Permit deadline has expired.
```

---

### 30. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 1187 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1182 |  * separator of the implementation contract. This will cause the {_domainSeparatorV4} function to always rebuild the
   1183 |  * separator from the immutable values, which is cheaper than accessing a cached version in cold storage.
   1184 |  *
   1185 |  * @custom:oz-upgrades-unsafe-allow state-variable-immutable
   1186 |  */
>> 1187 | abstract contract EIP712 is IERC5267 {
   1188 |     using ShortStrings for *;
   1189 | 
   1190 |     bytes32 private constant TYPE_HASH =
   1191 |         keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
   1192 | 
```

---

### 31. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 1806 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1801 |      * Requirements:
   1802 |      * - modulus can't be zero
   1803 |      * - underlying staticcall to precompile must succeed
   1804 |      *
   1805 |      * IMPORTANT: The result is only valid if the underlying call succeeds. When using this function, make
>> 1806 |      * sure the chain you're using it on supports the precompiled contract for modular exponentiation
   1807 |      * at address 0x05 as specified in https://eips.ethereum.org/EIPS/eip-198[EIP-198]. Otherwise,
   1808 |      * the underlying function will succeed given the lack of a revert, but the result may be incorrectly
   1809 |      * interpreted as 0.
   1810 |      */
   1811 |     function modExp(uint256 b, uint256 e, uint256 m) internal view returns (uint256) {
```

---

### 32. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 3419 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3414 | pragma solidity ^0.8.20;
   3415 | 
   3416 | /**
   3417 |  * @dev Provides tracking nonces for addresses. Nonces will only increment.
   3418 |  */
>> 3419 | abstract contract Nonces {
   3420 |     /**
   3421 |      * @dev The nonce used for an `account` is not the expected current nonce.
   3422 |      */
   3423 |     error InvalidAccountNonce(address account, uint256 currentNonce);
   3424 | 
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 3539 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3534 |  * This module is used through inheritance. It will make available the
   3535 |  * modifiers `whenNotPaused` and `whenPaused`, which can be applied to
   3536 |  * the functions of your contract. Note that they will not be pausable by
   3537 |  * simply including this module, only once the modifiers are put in place.
   3538 |  */
>> 3539 | abstract contract Pausable is Context {
   3540 |     bool private _paused;
   3541 | 
   3542 |     /**
   3543 |      * @dev Emitted when the pause is triggered by `account`.
   3544 |      */
```

---

### 34. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 3662 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3657 |  * fallback mechanism can be used for every other case.
   3658 |  *
   3659 |  * Usage example:
   3660 |  *
   3661 |  * ```solidity
>> 3662 |  * contract Named {
   3663 |  *     using ShortStrings for *;
   3664 |  *
   3665 |  *     ShortString private immutable _name;
   3666 |  *     string private _nameFallback;
   3667 |  *
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 4415 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4410 | import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
   4411 | import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Pausable.sol";
   4412 | import "@openzeppelin/contracts/access/Ownable.sol";
   4413 | import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol";
   4414 | 
>> 4415 | contract DWDinosaurRWA is ERC20, ERC20Pausable, Ownable, ERC20Permit {
   4416 |     constructor(address initialOwner)
   4417 |         ERC20("DW Dinosaur RWA", "DW")
   4418 |         Ownable(initialOwner)
   4419 |         ERC20Permit("DW Dinosaur RWA")
   4420 |     {
```

---

### 36. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 700 行
- **函数**: `permit()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    697 |         bytes32 r,
    698 |         bytes32 s
    699 |     ) public virtual {
>>  700 |         if (block.timestamp > deadline) {
    701 |             revert ERC2612ExpiredSignature(deadline);
    702 |         }
    703 | 
```

---

### 37. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 1077 行
- **函数**: `tryRecover()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1074 |         bytes32 vs
   1075 |     ) internal pure returns (address recovered, RecoverError err, bytes32 errArg) {
   1076 |         unchecked {
>> 1077 |             bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
   1078 |             // We do not check for an overflow here since the shift operation results in 0 or 1.
   1079 |             uint8 v = uint8((uint256(vs) >> 255) + 27);
   1080 |             return tryRecover(hash, v, r, s);
```

---

### 38. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 1112 行
- **函数**: `tryRecover()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1109 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
   1110 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
   1111 |         // these malleable signatures as well.
>> 1112 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
   1113 |             return (address(0), RecoverError.InvalidSignatureS, s);
   1114 |         }
   1115 | 
```

---

### 39. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xC47Ce083F18776E711c4365Bc4daa283229Cb6CA` 第 2069 行
- **函数**: `log2()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2066 |         //
   2067 |         // The lookup table is represented as a 32-byte value with the MSB positions for 0-15 in the last 16 bytes.
   2068 |         assembly ("memory-safe") {
>> 2069 |             r := or(r, byte(shr(r, x), 0x0000010102020202030303030303030300000000000000000000000000000000))
   2070 |         }
   2071 |     }
   2072 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*