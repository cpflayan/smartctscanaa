# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:02:47
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` |
| contract_name | `BEP20Token` |
| compiler_version | `v0.5.16+commit.9c3226ce` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `Apache-2.0` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646141` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 26 |
| 🟢 LOW | 1 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 7 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      4 |   /**
      5 |    * @dev Returns the amount of tokens in existence.
      6 |    */
>>    7 |   function totalSupply() external view returns (uint256);
      8 | 
      9 |   /**
     10 |    * @dev Returns the token decimals.
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 12 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      9 |   /**
     10 |    * @dev Returns the token decimals.
     11 |    */
>>   12 |   function decimals() external view returns (uint8);
     13 | 
     14 |   /**
     15 |    * @dev Returns the token symbol.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 17 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     14 |   /**
     15 |    * @dev Returns the token symbol.
     16 |    */
>>   17 |   function symbol() external view returns (string memory);
     18 | 
     19 |   /**
     20 |   * @dev Returns the token name.
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 22 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     19 |   /**
     20 |   * @dev Returns the token name.
     21 |   */
>>   22 |   function name() external view returns (string memory);
     23 | 
     24 |   /**
     25 |    * @dev Returns the bep token owner.
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 27 行
- **函数**: `getOwner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     24 |   /**
     25 |    * @dev Returns the bep token owner.
     26 |    */
>>   27 |   function getOwner() external view returns (address);
     28 | 
     29 |   /**
     30 |    * @dev Returns the amount of tokens owned by `account`.
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 32 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     29 |   /**
     30 |    * @dev Returns the amount of tokens owned by `account`.
     31 |    */
>>   32 |   function balanceOf(address account) external view returns (uint256);
     33 | 
     34 |   /**
     35 |    * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 41 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     38 |    *
     39 |    * Emits a {Transfer} event.
     40 |    */
>>   41 |   function transfer(address recipient, uint256 amount) external returns (bool);
     42 | 
     43 |   /**
     44 |    * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 50 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     47 |    *
     48 |    * This value changes when {approve} or {transferFrom} are called.
     49 |    */
>>   50 |   function allowance(address _owner, address spender) external view returns (uint256);
     51 | 
     52 |   /**
     53 |    * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 66 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     63 |    *
     64 |    * Emits an {Approval} event.
     65 |    */
>>   66 |   function approve(address spender, uint256 amount) external returns (bool);
     67 | 
     68 |   /**
     69 |    * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 77 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     74 |    *
     75 |    * Emits a {Transfer} event.
     76 |    */
>>   77 |   function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     78 | 
     79 |   /**
     80 |    * @dev Emitted when `value` tokens are moved from one account (`from`) to
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 297 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    294 |   /**
    295 |    * @dev Returns the address of the current owner.
    296 |    */
>>  297 |   function owner() public view returns (address) {
    298 |     return _owner;
    299 |   }
    300 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 364 行
- **函数**: `getOwner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    361 |   /**
    362 |    * @dev Returns the bep token owner.
    363 |    */
>>  364 |   function getOwner() external view returns (address) {
    365 |     return owner();
    366 |   }
    367 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 371 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    368 |   /**
    369 |    * @dev Returns the token decimals.
    370 |    */
>>  371 |   function decimals() external view returns (uint8) {
    372 |     return _decimals;
    373 |   }
    374 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 378 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    375 |   /**
    376 |    * @dev Returns the token symbol.
    377 |    */
>>  378 |   function symbol() external view returns (string memory) {
    379 |     return _symbol;
    380 |   }
    381 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 385 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    382 |   /**
    383 |   * @dev Returns the token name.
    384 |   */
>>  385 |   function name() external view returns (string memory) {
    386 |     return _name;
    387 |   }
    388 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 392 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    389 |   /**
    390 |    * @dev See {BEP20-totalSupply}.
    391 |    */
>>  392 |   function totalSupply() external view returns (uint256) {
    393 |     return _totalSupply;
    394 |   }
    395 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 399 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    396 |   /**
    397 |    * @dev See {BEP20-balanceOf}.
    398 |    */
>>  399 |   function balanceOf(address account) external view returns (uint256) {
    400 |     return _balances[account];
    401 |   }
    402 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 411 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    408 |    * - `recipient` cannot be the zero address.
    409 |    * - the caller must have a balance of at least `amount`.
    410 |    */
>>  411 |   function transfer(address recipient, uint256 amount) external returns (bool) {
    412 |     _transfer(_msgSender(), recipient, amount);
    413 |     return true;
    414 |   }
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 419 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    416 |   /**
    417 |    * @dev See {BEP20-allowance}.
    418 |    */
>>  419 |   function allowance(address owner, address spender) external view returns (uint256) {
    420 |     return _allowances[owner][spender];
    421 |   }
    422 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 430 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    427 |    *
    428 |    * - `spender` cannot be the zero address.
    429 |    */
>>  430 |   function approve(address spender, uint256 amount) external returns (bool) {
    431 |     _approve(_msgSender(), spender, amount);
    432 |     return true;
    433 |   }
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 447 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    444 |    * - the caller must have allowance for `sender`'s tokens of at least
    445 |    * `amount`.
    446 |    */
>>  447 |   function transferFrom(address sender, address recipient, uint256 amount) external returns (bool) {
    448 |     _transfer(sender, recipient, amount);
    449 |     _approve(sender, _msgSender(), _allowances[sender][_msgSender()].sub(amount, "BEP20: transfer amount exceeds allowance"));
    450 |     return true;
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 465 行
- **函数**: `increaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    462 |    *
    463 |    * - `spender` cannot be the zero address.
    464 |    */
>>  465 |   function increaseAllowance(address spender, uint256 addedValue) public returns (bool) {
    466 |     _approve(_msgSender(), spender, _allowances[_msgSender()][spender].add(addedValue));
    467 |     return true;
    468 |   }
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 484 行
- **函数**: `decreaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    481 |    * - `spender` must have allowance for the caller of at least
    482 |    * `subtractedValue`.
    483 |    */
>>  484 |   function decreaseAllowance(address spender, uint256 subtractedValue) public returns (bool) {
    485 |     _approve(_msgSender(), spender, _allowances[_msgSender()][spender].sub(subtractedValue, "BEP20: decreased allowance below zero"));
    486 |     return true;
    487 |   }
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 505 行
- **函数**: `burn()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    502 |   /**
    503 |    * @dev Burn `amount` tokens and decreasing the total supply.
    504 |    */
>>  505 |   function burn(uint256 amount) public returns (bool) {
    506 |     _burn(_msgSender(), amount);
    507 |     return true;
    508 |   }
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 280 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    275 |  *
    276 |  * This module is used through inheritance. It will make available the modifier
    277 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    278 |  * the owner.
    279 |  */
>>  280 | contract Ownable is Context {
    281 |   address private _owner;
    282 | 
    283 |   event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    284 | 
    285 |   /**
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 339 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    334 |     emit OwnershipTransferred(_owner, newOwner);
    335 |     _owner = newOwner;
    336 |   }
    337 | }
    338 | 
>>  339 | contract BEP20Token is Context, IBEP20, Ownable {
    340 |   using SafeMath for uint256;
    341 | 
    342 |   mapping (address => uint256) private _balances;
    343 | 
    344 |   mapping (address => mapping (address => uint256)) private _allowances;
```

---

### 27. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0x7130d2A12B9BCbFAe4f2634d864A1Ee1Ce3Ead9c` 第 1 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
>>    1 | pragma solidity 0.5.16;
      2 | 
      3 | interface IBEP20 {
      4 |   /**
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*