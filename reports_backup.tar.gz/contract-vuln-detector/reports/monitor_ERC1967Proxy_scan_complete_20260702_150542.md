# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:05:42
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` |
| contract_name | `ERC1967Proxy` |
| compiler_version | `v0.8.29+commit.ab55807c` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/interfaces/IERC1967.sol', '@openzeppelin/contracts/proxy/beacon/BeaconProxy.sol', '@openzeppelin/contracts/proxy/beacon/IBeacon.sol', '@openzeppelin/contracts/proxy/beacon/UpgradeableBeacon.sol', '@openzeppelin/contracts/proxy/ERC1967/ERC1967Proxy.sol', '@openzeppelin/contracts/proxy/ERC1967/ERC1967Utils.sol', '@openzeppelin/contracts/proxy/Proxy.sol', '@openzeppelin/contracts/proxy/transparent/ProxyAdmin.sol', '@openzeppelin/contracts/proxy/transparent/TransparentUpgradeableProxy.sol', '@openzeppelin/contracts/utils/Address.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/utils/Errors.sol', '@openzeppelin/contracts/utils/StorageSlot.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 14 |
| 🟢 LOW | 4 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 545 行
- **函数**: `_delegate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    542 | 
    543 |             // Call the implementation.
    544 |             // out and outsize are 0 because we don't know the size yet.
>>  545 |             let result := delegatecall(gas(), implementation, 0, calldatasize(), 0, 0)
    546 | 
    547 |             // Copy the returned data.
    548 |             returndatacopy(0, 0, returndatasize())
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 855 行
- **函数**: `functionDelegateCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    852 |      * but performing a delegate call.
    853 |      */
    854 |     function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
>>  855 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    856 |         return verifyCallResultFromTarget(target, success, returndata);
    857 |     }
    858 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 796 行
- **函数**: `sendValue()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    793 |             revert Errors.InsufficientBalance(address(this).balance, amount);
    794 |         }
    795 | 
>>  796 |         (bool success, bytes memory returndata) = recipient.call{value: amount}("");
    797 |         if (!success) {
    798 |             _revert(returndata);
    799 |         }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 837 行
- **函数**: `functionCallWithValue()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    834 |         if (address(this).balance < value) {
    835 |             revert Errors.InsufficientBalance(address(this).balance, value);
    836 |         }
>>  837 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    838 |         return verifyCallResultFromTarget(target, success, returndata);
    839 |     }
    840 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 58 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     55 |     /**
     56 |      * @dev Returns the address of the current owner.
     57 |      */
>>   58 |     function owner() public view virtual returns (address) {
     59 |         return _owner;
     60 |     }
     61 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 210 行
- **函数**: `implementation()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    207 |      *
    208 |      * {UpgradeableBeacon} will check that this address is a contract.
    209 |      */
>>  210 |     function implementation() external view returns (address);
    211 | }
    212 | 
    213 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 253 行
- **函数**: `implementation()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    250 |     /**
    251 |      * @dev Returns the current implementation address.
    252 |      */
>>  253 |     function implementation() public view virtual returns (address) {
    254 |         return _implementation;
    255 |     }
    256 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 655 行
- **函数**: `upgradeToAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    652 |  */
    653 | interface ITransparentUpgradeableProxy is IERC1967 {
    654 |     /// @dev See {UUPSUpgradeable-upgradeToAndCall}
>>  655 |     function upgradeToAndCall(address newImplementation, bytes calldata data) external payable;
    656 | }
    657 | 
    658 | /**
```

---

### 9. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 22 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     17 |  *
     18 |  * This module is used through inheritance. It will make available the modifier
     19 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     20 |  * the owner.
     21 |  */
>>   22 | abstract contract Ownable is Context {
     23 |     address private _owner;
     24 | 
     25 |     /**
     26 |      * @dev The caller account is not authorized to perform an operation.
     27 |      */
```

---

### 10. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 94 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     89 |         }
     90 |         _transferOwnership(newOwner);
     91 |     }
     92 | 
     93 |     /**
>>   94 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     95 |      * Internal function without access restriction.
     96 |      */
     97 |     function _transferOwnership(address newOwner) internal virtual {
     98 |         address oldOwner = _owner;
     99 |         _owner = newOwner;
```

---

### 11. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 157 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    152 |  * the beacon to not upgrade the implementation maliciously.
    153 |  *
    154 |  * IMPORTANT: Do not use the implementation logic to modify the beacon storage slot. Doing so would leave the proxy in
    155 |  * an inconsistent state where the beacon storage slot does not match the beacon address.
    156 |  */
>>  157 | contract BeaconProxy is Proxy {
    158 |     // An immutable address for the beacon to avoid unnecessary SLOADs before each delegate call.
    159 |     address private immutable _beacon;
    160 | 
    161 |     /**
    162 |      * @dev Initializes the proxy with `beacon`.
```

---

### 12. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 230 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    225 |  * @dev This contract is used in conjunction with one or more instances of {BeaconProxy} to determine their
    226 |  * implementation contract, which is where they will delegate all function calls.
    227 |  *
    228 |  * An owner is able to change the implementation the beacon points to, thus upgrading the proxies that use this beacon.
    229 |  */
>>  230 | contract UpgradeableBeacon is IBeacon, Ownable {
    231 |     address private _implementation;
    232 | 
    233 |     /**
    234 |      * @dev The `implementation` of the beacon is invalid.
    235 |      */
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 299 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    294 | 
    295 | import {Proxy} from "../Proxy.sol";
    296 | import {ERC1967Utils} from "./ERC1967Utils.sol";
    297 | 
    298 | /**
>>  299 |  * @dev This contract implements an upgradeable proxy. It is upgradeable because calls are delegated to an
    300 |  * implementation address that can be changed. This address is stored in storage in the location specified by
    301 |  * https://eips.ethereum.org/EIPS/eip-1967[ERC-1967], so that it doesn't conflict with the storage layout of the
    302 |  * implementation behind the proxy.
    303 |  */
    304 | contract ERC1967Proxy is Proxy {
```

---

### 14. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 530 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    525 |  * Additionally, delegation to the implementation can be triggered manually through the {_fallback} function, or to a
    526 |  * different contract through the {_delegate} function.
    527 |  *
    528 |  * The success and return data of the delegated call will be returned back to the caller of the proxy.
    529 |  */
>>  530 | abstract contract Proxy {
    531 |     /**
    532 |      * @dev Delegates the current call to `implementation`.
    533 |      *
    534 |      * This function does not return to its internal call site, it will return directly to the external caller.
    535 |      */
```

---

### 15. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 600 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    595 | 
    596 | /**
    597 |  * @dev This is an auxiliary contract meant to be assigned as the admin of a {TransparentUpgradeableProxy}. For an
    598 |  * explanation of why you would want to use this see the documentation for {TransparentUpgradeableProxy}.
    599 |  */
>>  600 | contract ProxyAdmin is Ownable {
    601 |     /**
    602 |      * @dev The version of the upgrade interface of the contract. If this getter is missing, both `upgrade(address,address)`
    603 |      * and `upgradeAndCall(address,address,bytes)` are present, and `upgrade` must be used if no function should be called,
    604 |      * while `upgradeAndCall` will invoke the `receive` function if the third argument is the empty byte string.
    605 |      * If the getter returns `"5.0.0"`, only `upgradeAndCall(address,address,bytes)` is present, and the third argument must
```

---

### 16. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 698 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    693 |  * WARNING: It is not recommended to extend this contract to add additional external functions. If you do so, the
    694 |  * compiler will not check that there are no selector conflicts, due to the note above. A selector clash between any new
    695 |  * function and the functions declared in {ITransparentUpgradeableProxy} will be resolved in favor of the new one. This
    696 |  * could render the `upgradeToAndCall` function inaccessible, preventing upgradeability and compromising transparency.
    697 |  */
>>  698 | contract TransparentUpgradeableProxy is ERC1967Proxy {
    699 |     // An immutable address for the admin to avoid unnecessary SLOADs before each call
    700 |     // at the expense of removing the ability to change the admin once it's set.
    701 |     // This is acceptable if the admin is always a ProxyAdmin instance or similar contract
    702 |     // with its own ability to transfer the permissions to another account.
    703 |     address private immutable _admin;
```

---

### 17. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 354 行
- **函数**: `_implementation()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    351 |      * This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1.
    352 |      */
    353 |     // solhint-disable-next-line private-vars-leading-underscore
>>  354 |     bytes32 internal constant IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
    355 | 
    356 |     /**
    357 |      * @dev The `implementation` of the proxy is invalid.
```

---

### 18. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 416 行
- **函数**: `upgradeToAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    413 |      * This is the keccak-256 hash of "eip1967.proxy.admin" subtracted by 1.
    414 |      */
    415 |     // solhint-disable-next-line private-vars-leading-underscore
>>  416 |     bytes32 internal constant ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    417 | 
    418 |     /**
    419 |      * @dev Returns the current admin.
```

---

### 19. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 454 行
- **函数**: `changeAdmin()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    451 |      * This is the keccak-256 hash of "eip1967.proxy.beacon" subtracted by 1.
    452 |      */
    453 |     // solhint-disable-next-line private-vars-leading-underscore
>>  454 |     bytes32 internal constant BEACON_SLOT = 0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50;
    455 | 
    456 |     /**
    457 |      * @dev Returns the current beacon.
```

---

### 20. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF8500d88Be054E5b67b69f107CE8D74A7a020cc9` 第 537 行
- **函数**: `_delegate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    534 |      * This function does not return to its internal call site, it will return directly to the external caller.
    535 |      */
    536 |     function _delegate(address implementation) internal virtual {
>>  537 |         assembly {
    538 |             // Copy msg.data. We take full control of memory in this inline assembly
    539 |             // block because it will not return to Solidity code. We overwrite the
    540 |             // Solidity scratch pad at memory position 0.
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*