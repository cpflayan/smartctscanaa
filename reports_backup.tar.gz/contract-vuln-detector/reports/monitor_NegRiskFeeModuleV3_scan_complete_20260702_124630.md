# 智能合约安全审计报告

> 生成时间: 2026-07-02 12:46:30
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x0989942f8E5b778E804858A0cC791b4469A5fD63` |
| contract_name | `NegRiskFeeModuleV3` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/NegRisk/NegRiskFeeModuleV3.sol', 'contracts/ExchangeFee/FeeModuleV3.sol', 'contracts/NegRisk/interfaces/IConditionalTokens.sol', 'node_modules/@openzeppelin/contracts/access/AccessControl.sol', 'node_modules/solmate/src/tokens/ERC1155.sol', 'contracts/ExchangeFee/mixins/Transfers.sol', 'contracts/ExchangeFee/interfaces/IExchange.sol', 'contracts/ExchangeFee/interfaces/IFeeModuleV3.sol', 'contracts/Exchange/libraries/OrderStructs.sol', 'contracts/ExchangeFee/libraries/CalculatorHelperV3.sol', 'node_modules/@openzeppelin/contracts/access/IAccessControl.sol', 'node_modules/@openzeppelin/contracts/utils/Context.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/ERC165.sol', 'contracts/ExchangeFee/libraries/TransferHelper.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/IERC165.sol', 'node_modules/solmate/src/utils/SafeTransferLib.sol', 'node_modules/solmate/src/tokens/ERC20.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107638938` |

## 安全摘要

**整体风险等级**: UNKNOWN

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 31 |
| 🟢 LOW | 12 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 334 行
- **函数**: `balanceOf()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    331 | 
    332 |     event URI(string value, uint256 indexed id);
    333 | 
>>  334 |     function balanceOf(address owner, uint256 id) external view returns (uint256);
    335 | 
    336 |     function balanceOfBatch(address[] memory owners, uint256[] memory ids) external view returns (uint256[] memory);
    337 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 336 行
- **函数**: `balanceOfBatch()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    333 | 
    334 |     function balanceOf(address owner, uint256 id) external view returns (uint256);
    335 | 
>>  336 |     function balanceOfBatch(address[] memory owners, uint256[] memory ids) external view returns (uint256[] memory);
    337 | 
    338 |     function setApprovalForAll(address operator, bool approved) external;
    339 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 340 行
- **函数**: `isApprovedForAll()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    337 | 
    338 |     function setApprovalForAll(address operator, bool approved) external;
    339 | 
>>  340 |     function isApprovedForAll(address owner, address operator) external view returns (bool);
    341 | 
    342 |     function safeTransferFrom(address from, address to, uint256 id, uint256 value, bytes calldata data) external;
    343 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 398 行
- **函数**: `payoutNumerators()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    395 | }
    396 | 
    397 | interface IConditionalTokens is IConditionalTokensEE, IERC1155 {
>>  398 |     function payoutNumerators(bytes32 conditionId, uint256 index) external view returns (uint256);
    399 | 
    400 |     function payoutDenominator(bytes32 conditionId) external view returns (uint256);
    401 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 400 行
- **函数**: `payoutDenominator()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    397 | interface IConditionalTokens is IConditionalTokensEE, IERC1155 {
    398 |     function payoutNumerators(bytes32 conditionId, uint256 index) external view returns (uint256);
    399 | 
>>  400 |     function payoutDenominator(bytes32 conditionId) external view returns (uint256);
    401 | 
    402 |     /// @dev This function prepares a condition by initializing a payout vector associated with the
    403 |     /// condition.
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 461 行
- **函数**: `getOutcomeSlotCount()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    458 |     /// @param conditionId ID of the condition.
    459 |     /// @return Number of outcome slots associated with a condition, or zero if condition has not
    460 |     /// been prepared yet.
>>  461 |     function getOutcomeSlotCount(bytes32 conditionId) external view returns (uint256);
    462 | 
    463 |     /// @dev Constructs a condition ID from an oracle, a question ID, and the outcome slot count for
    464 |     /// the question.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 492 行
- **函数**: `getPositionId()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    489 |     /// are used as the ERC-1155 ID for this contract.
    490 |     /// @param collateralToken Collateral token which backs the position.
    491 |     /// @param collectionId ID of the outcome collection associated with this position.
>>  492 |     function getPositionId(address collateralToken, bytes32 collectionId) external pure returns (uint256);
    493 | }
    494 | 
    495 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 568 行
- **函数**: `supportsInterface()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    565 |     /**
    566 |      * @dev See {IERC165-supportsInterface}.
    567 |      */
>>  568 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
    569 |         return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
    570 |     }
    571 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 575 行
- **函数**: `hasRole()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    572 |     /**
    573 |      * @dev Returns `true` if `account` has been granted `role`.
    574 |      */
>>  575 |     function hasRole(bytes32 role, address account) public view virtual returns (bool) {
    576 |         return _roles[role].hasRole[account];
    577 |     }
    578 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 603 行
- **函数**: `getRoleAdmin()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    600 |      *
    601 |      * To change a role's admin, use {_setRoleAdmin}.
    602 |      */
>>  603 |     function getRoleAdmin(bytes32 role) public view virtual returns (bytes32) {
    604 |         return _roles[role].adminRole;
    605 |     }
    606 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 654 行
- **函数**: `renounceRole()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    651 |      *
    652 |      * May emit a {RoleRevoked} event.
    653 |      */
>>  654 |     function renounceRole(bytes32 role, address callerConfirmation) public virtual {
    655 |         if (callerConfirmation != _msgSender()) {
    656 |             revert AccessControlBadConfirmation();
    657 |         }
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 753 行
- **函数**: `uri()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    750 |                              METADATA LOGIC
    751 |     //////////////////////////////////////////////////////////////*/
    752 | 
>>  753 |     function uri(uint256 id) public view virtual returns (string memory);
    754 | 
    755 |     /*//////////////////////////////////////////////////////////////
    756 |                               ERC1155 LOGIC
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 759 行
- **函数**: `setApprovalForAll()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    756 |                               ERC1155 LOGIC
    757 |     //////////////////////////////////////////////////////////////*/
    758 | 
>>  759 |     function setApprovalForAll(address operator, bool approved) public virtual {
    760 |         isApprovedForAll[msg.sender][operator] = approved;
    761 | 
    762 |         emit ApprovalForAll(msg.sender, operator, approved);
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 851 行
- **函数**: `supportsInterface()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    848 |                               ERC165 LOGIC
    849 |     //////////////////////////////////////////////////////////////*/
    850 | 
>>  851 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
    852 |         return
    853 |             interfaceId == 0x01ffc9a7 || // ERC165 Interface ID for ERC165
    854 |             interfaceId == 0xd9b67a26 || // ERC165 Interface ID for ERC1155
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1006 行
- **函数**: `getCollateral()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1003 | import {Order} from "../../Exchange/libraries/OrderStructs.sol";
   1004 | 
   1005 | interface IExchange {
>> 1006 |     function getCollateral() external view returns (address);
   1007 | 
   1008 |     function getCtf() external view returns (address);
   1009 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1008 行
- **函数**: `getCtf()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1005 | interface IExchange {
   1006 |     function getCollateral() external view returns (address);
   1007 | 
>> 1008 |     function getCtf() external view returns (address);
   1009 | 
   1010 |     function hashOrder(Order memory order) external view returns (bytes32);
   1011 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1010 行
- **函数**: `hashOrder()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1007 | 
   1008 |     function getCtf() external view returns (address);
   1009 | 
>> 1010 |     function hashOrder(Order memory order) external view returns (bytes32);
   1011 | 
   1012 |     function matchOrders(
   1013 |         Order memory takerOrder,
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1320 行
- **函数**: `hasRole()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1317 |     /**
   1318 |      * @dev Returns `true` if `account` has been granted `role`.
   1319 |      */
>> 1320 |     function hasRole(bytes32 role, address account) external view returns (bool);
   1321 | 
   1322 |     /**
   1323 |      * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1328 行
- **函数**: `getRoleAdmin()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1325 |      *
   1326 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
   1327 |      */
>> 1328 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
   1329 | 
   1330 |     /**
   1331 |      * @dev Grants `role` to `account`.
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1428 行
- **函数**: `supportsInterface()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1425 |     /**
   1426 |      * @dev See {IERC165-supportsInterface}.
   1427 |      */
>> 1428 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   1429 |         return interfaceId == type(IERC165).interfaceId;
   1430 |     }
   1431 | }
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1498 行
- **函数**: `supportsInterface()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1495 |      *
   1496 |      * This function call must use less than 30 000 gas.
   1497 |      */
>> 1498 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   1499 | }
   1500 | 
   1501 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1703 行
- **函数**: `approve()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1700 |                                ERC20 LOGIC
   1701 |     //////////////////////////////////////////////////////////////*/
   1702 | 
>> 1703 |     function approve(address spender, uint256 amount) public virtual returns (bool) {
   1704 |         allowance[msg.sender][spender] = amount;
   1705 | 
   1706 |         emit Approval(msg.sender, spender, amount);
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1711 行
- **函数**: `transfer()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1708 |         return true;
   1709 |     }
   1710 | 
>> 1711 |     function transfer(address to, uint256 amount) public virtual returns (bool) {
   1712 |         balanceOf[msg.sender] -= amount;
   1713 | 
   1714 |         // Cannot overflow because the sum of all user
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1797 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1794 |         emit Approval(owner, spender, value);
   1795 |     }
   1796 | 
>> 1797 |     function DOMAIN_SEPARATOR() public view virtual returns (bytes32) {
   1798 |         return block.chainid == INITIAL_CHAIN_ID ? INITIAL_DOMAIN_SEPARATOR : computeDomainSeparator();
   1799 |     }
   1800 | 
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 12 行
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      7 | import {IConditionalTokens} from "./interfaces/IConditionalTokens.sol";
      8 | 
      9 | /// @title NegRiskFeeModuleV3
     10 | /// @notice FeeModuleV3 with neg risk support
     11 | /// @author predict.fun protocol team
>>   12 | contract NegRiskFeeModuleV3 is FeeModuleV3 {
     13 |     constructor(
     14 |         address _negRiskCtfExchange,
     15 |         address _negRiskAdapter,
     16 |         address _ctf,
     17 |         address _admin
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 47 行
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     42 | /**
     43 |  * @title CTF Fee Module V3
     44 |  * @notice Proxies the CTFExchange contract, refunds orders and distributes maker rebates + referral fees
     45 |  * @author predict.fun protocol team
     46 |  */
>>   47 | contract FeeModuleV3 is IFeeModuleV3, AccessControl, Transfers, ERC1155TokenReceiver {
     48 |     /**
     49 |      * @notice Role allowed to match orders
     50 |      */
     51 |     bytes32 public constant ORDERS_MATCHER_ROLE = keccak256("ORDERS_MATCHER_ROLE");
     52 | 
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 546 行
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    541 |  * WARNING: The `DEFAULT_ADMIN_ROLE` is also its own admin: it has permission to
    542 |  * grant and revoke this role. Extra precautions should be taken to secure
    543 |  * accounts that have been granted it. We recommend using {AccessControlDefaultAdminRules}
    544 |  * to enforce additional security measures for this role.
    545 |  */
>>  546 | abstract contract AccessControl is Context, IAccessControl, ERC165 {
    547 |     struct RoleData {
    548 |         mapping(address account => bool) hasRole;
    549 |         bytes32 adminRole;
    550 |     }
    551 | 
```

---

### 28. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 716 行
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    711 | // SPDX-License-Identifier: AGPL-3.0-only
    712 | pragma solidity >=0.8.0;
    713 | 
    714 | /// @notice Minimalist and gas efficient standard ERC1155 implementation.
    715 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC1155.sol)
>>  716 | abstract contract ERC1155 {
    717 |     /*//////////////////////////////////////////////////////////////
    718 |                                  EVENTS
    719 |     //////////////////////////////////////////////////////////////*/
    720 | 
    721 |     event TransferSingle(
```

---

### 29. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 945 行
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    940 | 
    941 |         emit TransferSingle(msg.sender, from, address(0), id, amount);
    942 |     }
    943 | }
    944 | 
>>  945 | /// @notice A generic interface for a contract which properly accepts ERC1155 tokens.
    946 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC1155.sol)
    947 | abstract contract ERC1155TokenReceiver {
    948 |     function onERC1155Received(
    949 |         address,
    950 |         address,
```

---

### 30. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 977 行
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    972 | // SPDX-License-Identifier: MIT
    973 | pragma solidity 0.8.24;
    974 | 
    975 | import {TransferHelper} from "../libraries/TransferHelper.sol";
    976 | 
>>  977 | contract Transfers {
    978 |     /// @notice Transfers tokens. no-op if amount is zero
    979 |     /// @param token    - The Token to be transferred
    980 |     /// @param from     - The originating address
    981 |     /// @param to       - The destination address
    982 |     /// @param id       - The TokenId to be transferred, 0 if ERC20
```

---

### 31. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1643 行
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1638 | 
   1639 | /// @notice Modern and gas efficient ERC20 + EIP-2612 implementation.
   1640 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC20.sol)
   1641 | /// @author Modified from Uniswap (https://github.com/Uniswap/uniswap-v2-core/blob/master/contracts/UniswapV2ERC20.sol)
   1642 | /// @dev Do not manually set balances without updating totalSupply, as the sum of all user balances must not exceed it.
>> 1643 | abstract contract ERC20 {
   1644 |     /*//////////////////////////////////////////////////////////////
   1645 |                                  EVENTS
   1646 |     //////////////////////////////////////////////////////////////*/
   1647 | 
   1648 |     event Transfer(address indexed from, address indexed to, uint256 amount);
```

---

### 32. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1760 行
- **函数**: `permit()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1757 |         bytes32 r,
   1758 |         bytes32 s
   1759 |     ) public virtual {
>> 1760 |         require(deadline >= block.timestamp, "PERMIT_DEADLINE_EXPIRED");
   1761 | 
   1762 |         // Unchecked because the only math done is incrementing
   1763 |         // the owner's nonce which cannot realistically overflow.
```

---

### 33. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1548 行
- **函数**: `safeTransferFrom()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1545 |             let freeMemoryPointer := mload(0x40)
   1546 | 
   1547 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 1548 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   1549 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
   1550 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1551 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
```

---

### 34. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1549 行
- **函数**: `safeTransferFrom()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1546 | 
   1547 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   1548 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
>> 1549 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
   1550 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1551 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1552 | 
```

---

### 35. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1550 行
- **函数**: `safeTransferFrom()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1547 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   1548 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   1549 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
>> 1550 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1551 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1552 | 
   1553 |             success := and(
```

---

### 36. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1581 行
- **函数**: `safeTransfer()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1578 |             let freeMemoryPointer := mload(0x40)
   1579 | 
   1580 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 1581 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   1582 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1583 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1584 | 
```

---

### 37. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1582 行
- **函数**: `safeTransfer()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1579 | 
   1580 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   1581 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>> 1582 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1583 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1584 | 
   1585 |             success := and(
```

---

### 38. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1613 行
- **函数**: `safeApprove()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1610 |             let freeMemoryPointer := mload(0x40)
   1611 | 
   1612 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 1613 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
   1614 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1615 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1616 | 
```

---

### 39. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1614 行
- **函数**: `safeApprove()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1611 | 
   1612 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   1613 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
>> 1614 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1615 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1616 | 
   1617 |             success := and(
```

---

### 40. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1522 行
- **函数**: `safeTransferETH()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1519 |         bool success;
   1520 | 
   1521 |         /// @solidity memory-safe-assembly
>> 1522 |         assembly {
   1523 |             // Transfer the ETH and store if it succeeded or not.
   1524 |             success := call(gas(), to, amount, 0, 0, 0, 0)
   1525 |         }
```

---

### 41. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1543 行
- **函数**: `safeTransferFrom()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1540 |         bool success;
   1541 | 
   1542 |         /// @solidity memory-safe-assembly
>> 1543 |         assembly {
   1544 |             // Get a pointer to some free memory.
   1545 |             let freeMemoryPointer := mload(0x40)
   1546 | 
```

---

### 42. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1576 行
- **函数**: `safeTransfer()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1573 |         bool success;
   1574 | 
   1575 |         /// @solidity memory-safe-assembly
>> 1576 |         assembly {
   1577 |             // Get a pointer to some free memory.
   1578 |             let freeMemoryPointer := mload(0x40)
   1579 | 
```

---

### 43. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0989942f8E5b778E804858A0cC791b4469A5fD63` 第 1608 行
- **函数**: `safeApprove()`
- **合约**: `NegRiskFeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1605 |         bool success;
   1606 | 
   1607 |         /// @solidity memory-safe-assembly
>> 1608 |         assembly {
   1609 |             // Get a pointer to some free memory.
   1610 |             let freeMemoryPointer := mload(0x40)
   1611 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*