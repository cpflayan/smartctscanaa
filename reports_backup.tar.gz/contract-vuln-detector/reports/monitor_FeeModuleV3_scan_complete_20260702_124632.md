# 智能合约安全审计报告

> 生成时间: 2026-07-02 12:46:32
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` |
| contract_name | `FeeModuleV3` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/ExchangeFee/FeeModuleV3.sol', 'node_modules/@openzeppelin/contracts/access/AccessControl.sol', 'node_modules/solmate/src/tokens/ERC1155.sol', 'contracts/ExchangeFee/mixins/Transfers.sol', 'contracts/ExchangeFee/interfaces/IExchange.sol', 'contracts/ExchangeFee/interfaces/IFeeModuleV3.sol', 'contracts/Exchange/libraries/OrderStructs.sol', 'contracts/ExchangeFee/libraries/CalculatorHelperV3.sol', 'node_modules/@openzeppelin/contracts/access/IAccessControl.sol', 'node_modules/@openzeppelin/contracts/utils/Context.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/ERC165.sol', 'contracts/ExchangeFee/libraries/TransferHelper.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/IERC165.sol', 'node_modules/solmate/src/utils/SafeTransferLib.sol', 'node_modules/solmate/src/tokens/ERC20.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107638938` |

## 安全摘要

**整体风险等级**: UNKNOWN

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 23 |
| 🟢 LOW | 12 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 359 行
- **函数**: `supportsInterface()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    356 |     /**
    357 |      * @dev See {IERC165-supportsInterface}.
    358 |      */
>>  359 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
    360 |         return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
    361 |     }
    362 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 366 行
- **函数**: `hasRole()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    363 |     /**
    364 |      * @dev Returns `true` if `account` has been granted `role`.
    365 |      */
>>  366 |     function hasRole(bytes32 role, address account) public view virtual returns (bool) {
    367 |         return _roles[role].hasRole[account];
    368 |     }
    369 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 394 行
- **函数**: `getRoleAdmin()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    391 |      *
    392 |      * To change a role's admin, use {_setRoleAdmin}.
    393 |      */
>>  394 |     function getRoleAdmin(bytes32 role) public view virtual returns (bytes32) {
    395 |         return _roles[role].adminRole;
    396 |     }
    397 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 445 行
- **函数**: `renounceRole()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    442 |      *
    443 |      * May emit a {RoleRevoked} event.
    444 |      */
>>  445 |     function renounceRole(bytes32 role, address callerConfirmation) public virtual {
    446 |         if (callerConfirmation != _msgSender()) {
    447 |             revert AccessControlBadConfirmation();
    448 |         }
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 544 行
- **函数**: `uri()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    541 |                              METADATA LOGIC
    542 |     //////////////////////////////////////////////////////////////*/
    543 | 
>>  544 |     function uri(uint256 id) public view virtual returns (string memory);
    545 | 
    546 |     /*//////////////////////////////////////////////////////////////
    547 |                               ERC1155 LOGIC
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 550 行
- **函数**: `setApprovalForAll()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    547 |                               ERC1155 LOGIC
    548 |     //////////////////////////////////////////////////////////////*/
    549 | 
>>  550 |     function setApprovalForAll(address operator, bool approved) public virtual {
    551 |         isApprovedForAll[msg.sender][operator] = approved;
    552 | 
    553 |         emit ApprovalForAll(msg.sender, operator, approved);
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 642 行
- **函数**: `supportsInterface()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    639 |                               ERC165 LOGIC
    640 |     //////////////////////////////////////////////////////////////*/
    641 | 
>>  642 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
    643 |         return
    644 |             interfaceId == 0x01ffc9a7 || // ERC165 Interface ID for ERC165
    645 |             interfaceId == 0xd9b67a26 || // ERC165 Interface ID for ERC1155
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 797 行
- **函数**: `getCollateral()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    794 | import {Order} from "../../Exchange/libraries/OrderStructs.sol";
    795 | 
    796 | interface IExchange {
>>  797 |     function getCollateral() external view returns (address);
    798 | 
    799 |     function getCtf() external view returns (address);
    800 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 799 行
- **函数**: `getCtf()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    796 | interface IExchange {
    797 |     function getCollateral() external view returns (address);
    798 | 
>>  799 |     function getCtf() external view returns (address);
    800 | 
    801 |     function hashOrder(Order memory order) external view returns (bytes32);
    802 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 801 行
- **函数**: `hashOrder()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    798 | 
    799 |     function getCtf() external view returns (address);
    800 | 
>>  801 |     function hashOrder(Order memory order) external view returns (bytes32);
    802 | 
    803 |     function matchOrders(
    804 |         Order memory takerOrder,
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1111 行
- **函数**: `hasRole()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1108 |     /**
   1109 |      * @dev Returns `true` if `account` has been granted `role`.
   1110 |      */
>> 1111 |     function hasRole(bytes32 role, address account) external view returns (bool);
   1112 | 
   1113 |     /**
   1114 |      * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1119 行
- **函数**: `getRoleAdmin()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1116 |      *
   1117 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
   1118 |      */
>> 1119 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
   1120 | 
   1121 |     /**
   1122 |      * @dev Grants `role` to `account`.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1219 行
- **函数**: `supportsInterface()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1216 |     /**
   1217 |      * @dev See {IERC165-supportsInterface}.
   1218 |      */
>> 1219 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   1220 |         return interfaceId == type(IERC165).interfaceId;
   1221 |     }
   1222 | }
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1289 行
- **函数**: `supportsInterface()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1286 |      *
   1287 |      * This function call must use less than 30 000 gas.
   1288 |      */
>> 1289 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   1290 | }
   1291 | 
   1292 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1494 行
- **函数**: `approve()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1491 |                                ERC20 LOGIC
   1492 |     //////////////////////////////////////////////////////////////*/
   1493 | 
>> 1494 |     function approve(address spender, uint256 amount) public virtual returns (bool) {
   1495 |         allowance[msg.sender][spender] = amount;
   1496 | 
   1497 |         emit Approval(msg.sender, spender, amount);
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1502 行
- **函数**: `transfer()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1499 |         return true;
   1500 |     }
   1501 | 
>> 1502 |     function transfer(address to, uint256 amount) public virtual returns (bool) {
   1503 |         balanceOf[msg.sender] -= amount;
   1504 | 
   1505 |         // Cannot overflow because the sum of all user
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1588 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1585 |         emit Approval(owner, spender, value);
   1586 |     }
   1587 | 
>> 1588 |     function DOMAIN_SEPARATOR() public view virtual returns (bytes32) {
   1589 |         return block.chainid == INITIAL_CHAIN_ID ? INITIAL_DOMAIN_SEPARATOR : computeDomainSeparator();
   1590 |     }
   1591 | 
```

---

### 18. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 23 行
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     18 | /**
     19 |  * @title CTF Fee Module V3
     20 |  * @notice Proxies the CTFExchange contract, refunds orders and distributes maker rebates + referral fees
     21 |  * @author predict.fun protocol team
     22 |  */
>>   23 | contract FeeModuleV3 is IFeeModuleV3, AccessControl, Transfers, ERC1155TokenReceiver {
     24 |     /**
     25 |      * @notice Role allowed to match orders
     26 |      */
     27 |     bytes32 public constant ORDERS_MATCHER_ROLE = keccak256("ORDERS_MATCHER_ROLE");
     28 | 
```

---

### 19. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 337 行
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    332 |  * WARNING: The `DEFAULT_ADMIN_ROLE` is also its own admin: it has permission to
    333 |  * grant and revoke this role. Extra precautions should be taken to secure
    334 |  * accounts that have been granted it. We recommend using {AccessControlDefaultAdminRules}
    335 |  * to enforce additional security measures for this role.
    336 |  */
>>  337 | abstract contract AccessControl is Context, IAccessControl, ERC165 {
    338 |     struct RoleData {
    339 |         mapping(address account => bool) hasRole;
    340 |         bytes32 adminRole;
    341 |     }
    342 | 
```

---

### 20. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 507 行
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    502 | // SPDX-License-Identifier: AGPL-3.0-only
    503 | pragma solidity >=0.8.0;
    504 | 
    505 | /// @notice Minimalist and gas efficient standard ERC1155 implementation.
    506 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC1155.sol)
>>  507 | abstract contract ERC1155 {
    508 |     /*//////////////////////////////////////////////////////////////
    509 |                                  EVENTS
    510 |     //////////////////////////////////////////////////////////////*/
    511 | 
    512 |     event TransferSingle(
```

---

### 21. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 736 行
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    731 | 
    732 |         emit TransferSingle(msg.sender, from, address(0), id, amount);
    733 |     }
    734 | }
    735 | 
>>  736 | /// @notice A generic interface for a contract which properly accepts ERC1155 tokens.
    737 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC1155.sol)
    738 | abstract contract ERC1155TokenReceiver {
    739 |     function onERC1155Received(
    740 |         address,
    741 |         address,
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 768 行
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    763 | // SPDX-License-Identifier: MIT
    764 | pragma solidity 0.8.24;
    765 | 
    766 | import {TransferHelper} from "../libraries/TransferHelper.sol";
    767 | 
>>  768 | contract Transfers {
    769 |     /// @notice Transfers tokens. no-op if amount is zero
    770 |     /// @param token    - The Token to be transferred
    771 |     /// @param from     - The originating address
    772 |     /// @param to       - The destination address
    773 |     /// @param id       - The TokenId to be transferred, 0 if ERC20
```

---

### 23. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1434 行
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1429 | 
   1430 | /// @notice Modern and gas efficient ERC20 + EIP-2612 implementation.
   1431 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC20.sol)
   1432 | /// @author Modified from Uniswap (https://github.com/Uniswap/uniswap-v2-core/blob/master/contracts/UniswapV2ERC20.sol)
   1433 | /// @dev Do not manually set balances without updating totalSupply, as the sum of all user balances must not exceed it.
>> 1434 | abstract contract ERC20 {
   1435 |     /*//////////////////////////////////////////////////////////////
   1436 |                                  EVENTS
   1437 |     //////////////////////////////////////////////////////////////*/
   1438 | 
   1439 |     event Transfer(address indexed from, address indexed to, uint256 amount);
```

---

### 24. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1551 行
- **函数**: `permit()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1548 |         bytes32 r,
   1549 |         bytes32 s
   1550 |     ) public virtual {
>> 1551 |         require(deadline >= block.timestamp, "PERMIT_DEADLINE_EXPIRED");
   1552 | 
   1553 |         // Unchecked because the only math done is incrementing
   1554 |         // the owner's nonce which cannot realistically overflow.
```

---

### 25. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1339 行
- **函数**: `safeTransferFrom()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1336 |             let freeMemoryPointer := mload(0x40)
   1337 | 
   1338 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 1339 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   1340 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
   1341 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1342 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
```

---

### 26. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1340 行
- **函数**: `safeTransferFrom()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1337 | 
   1338 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   1339 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
>> 1340 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
   1341 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1342 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1343 | 
```

---

### 27. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1341 行
- **函数**: `safeTransferFrom()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1338 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   1339 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   1340 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
>> 1341 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1342 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1343 | 
   1344 |             success := and(
```

---

### 28. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1372 行
- **函数**: `safeTransfer()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1369 |             let freeMemoryPointer := mload(0x40)
   1370 | 
   1371 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 1372 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   1373 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1374 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1375 | 
```

---

### 29. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1373 行
- **函数**: `safeTransfer()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1370 | 
   1371 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   1372 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>> 1373 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1374 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1375 | 
   1376 |             success := and(
```

---

### 30. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1404 行
- **函数**: `safeApprove()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1401 |             let freeMemoryPointer := mload(0x40)
   1402 | 
   1403 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 1404 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
   1405 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1406 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1407 | 
```

---

### 31. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1405 行
- **函数**: `safeApprove()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1402 | 
   1403 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   1404 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
>> 1405 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1406 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1407 | 
   1408 |             success := and(
```

---

### 32. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1313 行
- **函数**: `safeTransferETH()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1310 |         bool success;
   1311 | 
   1312 |         /// @solidity memory-safe-assembly
>> 1313 |         assembly {
   1314 |             // Transfer the ETH and store if it succeeded or not.
   1315 |             success := call(gas(), to, amount, 0, 0, 0, 0)
   1316 |         }
```

---

### 33. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1334 行
- **函数**: `safeTransferFrom()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1331 |         bool success;
   1332 | 
   1333 |         /// @solidity memory-safe-assembly
>> 1334 |         assembly {
   1335 |             // Get a pointer to some free memory.
   1336 |             let freeMemoryPointer := mload(0x40)
   1337 | 
```

---

### 34. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1367 行
- **函数**: `safeTransfer()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1364 |         bool success;
   1365 | 
   1366 |         /// @solidity memory-safe-assembly
>> 1367 |         assembly {
   1368 |             // Get a pointer to some free memory.
   1369 |             let freeMemoryPointer := mload(0x40)
   1370 | 
```

---

### 35. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xF291a67165D751A2E7B4da4F0A012449Eef0a279` 第 1399 行
- **函数**: `safeApprove()`
- **合约**: `FeeModuleV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1396 |         bool success;
   1397 | 
   1398 |         /// @solidity memory-safe-assembly
>> 1399 |         assembly {
   1400 |             // Get a pointer to some free memory.
   1401 |             let freeMemoryPointer := mload(0x40)
   1402 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*