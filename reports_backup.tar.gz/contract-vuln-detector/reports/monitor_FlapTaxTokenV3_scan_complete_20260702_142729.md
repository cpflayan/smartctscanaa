# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:27:29
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` |
| contract_name | `FlapTaxTokenV3` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `99999` |
| evm_version | `london` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/Tax/FlapTaxTokenV3.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/token/ERC20/ERC20Upgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/proxy/utils/Initializable.sol', 'src/interfaces/Tax/IFlapTaxTokenV3.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/token/ERC20/extensions/ERC20PermitUpgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/access/OwnableUpgradeable.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/utils/SafeERC20.sol', 'src/interfaces/Tax/ITaxProcessor.sol', 'src/interfaces/Tax/IDividend.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/token/ERC20/IERC20Upgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/token/ERC20/extensions/IERC20MetadataUpgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/utils/ContextUpgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/utils/AddressUpgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/token/ERC20/extensions/IERC20PermitUpgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/utils/cryptography/ECDSAUpgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/utils/cryptography/EIP712Upgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/utils/CountersUpgradeable.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/extensions/IERC20Permit.sol', 'lib/openzeppelin-contracts/contracts/utils/Address.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/utils/StringsUpgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/interfaces/IERC5267Upgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/utils/math/MathUpgradeable.sol', 'lib/openzeppelin-contracts-upgradeable/contracts/utils/math/SignedMathUpgradeable.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646145` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 108 |
| 🟢 LOW | 17 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2268 行
- **函数**: `functionDelegateCall()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   2265 |         bytes memory data,
   2266 |         string memory errorMessage
   2267 |     ) internal returns (bytes memory) {
>> 2268 |         (bool success, bytes memory returndata) = target.delegatecall(data);
   2269 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
   2270 |     }
   2271 | 
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 3181 行
- **函数**: `functionDelegateCall()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   3178 |         bytes memory data,
   3179 |         string memory errorMessage
   3180 |     ) internal returns (bytes memory) {
>> 3181 |         (bool success, bytes memory returndata) = target.delegatecall(data);
   3182 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
   3183 |     }
   3184 | 
```

---

### 3. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1587 行
- **函数**: `_callOptionalReturnBool()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1584 |         // we're implementing it ourselves. We cannot use {Address-functionCall} here since this should return false
   1585 |         // and not revert is the subcall reverts.
   1586 | 
>> 1587 |         (bool success, bytes memory returndata) = address(token).call(data);
   1588 |         return
   1589 |             success && (returndata.length == 0 || abi.decode(returndata, (bool))) && Address.isContract(address(token));
   1590 |     }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2150 行
- **函数**: `sendValue()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   2147 |     function sendValue(address payable recipient, uint256 amount) internal {
   2148 |         require(address(this).balance >= amount, "Address: insufficient balance");
   2149 | 
>> 2150 |         (bool success, ) = recipient.call{value: amount}("");
   2151 |         require(success, "Address: unable to send value, recipient may have reverted");
   2152 |     }
   2153 | 
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2218 行
- **函数**: `functionCallWithValue()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   2215 |         string memory errorMessage
   2216 |     ) internal returns (bytes memory) {
   2217 |         require(address(this).balance >= value, "Address: insufficient balance for call");
>> 2218 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
   2219 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
   2220 |     }
   2221 | 
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 3063 行
- **函数**: `sendValue()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   3060 |     function sendValue(address payable recipient, uint256 amount) internal {
   3061 |         require(address(this).balance >= amount, "Address: insufficient balance");
   3062 | 
>> 3063 |         (bool success, ) = recipient.call{value: amount}("");
   3064 |         require(success, "Address: unable to send value, recipient may have reverted");
   3065 |     }
   3066 | 
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 3131 行
- **函数**: `functionCallWithValue()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   3128 |         string memory errorMessage
   3129 |     ) internal returns (bytes memory) {
   3130 |         require(address(this).balance >= value, "Address: insufficient balance for call");
>> 3131 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
   3132 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
   3133 |     }
   3134 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 120 行
- **函数**: `initialize()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    117 | 
    118 |     /// @notice Initializes the token with the given parameters
    119 |     /// @param params The initialization parameters
>>  120 |     function initialize(InitParams memory params) external override initializer {
    121 |         v2Router = params.v2Router;
    122 |         antiFarmerDuration = params.antiFarmerDuration;
    123 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 411 行
- **函数**: `state()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    408 |     // ---------------------------------------------------------------------------
    409 | 
    410 |     /// @notice Returns the current state of the pool
>>  411 |     function state() external view returns (PoolState) {
    412 |         return PoolState(poolState.state);
    413 |     }
    414 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 417 行
- **函数**: `taxRate()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    414 | 
    415 |     /// @notice Returns the effective (worst-case) tax rate for backward compatibility.
    416 |     ///         Returns max(buyTaxRate, sellTaxRate).
>>  417 |     function taxRate() external view override returns (uint16) {
    418 |         PackedPoolState memory s = poolState;
    419 |         return s.buyTaxRate > s.sellTaxRate ? s.buyTaxRate : s.sellTaxRate;
    420 |     }
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 423 行
- **函数**: `buyTaxRate()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    420 |     }
    421 | 
    422 |     /// @notice Returns the buy tax rate in basis points
>>  423 |     function buyTaxRate() external view override returns (uint16) {
    424 |         return poolState.buyTaxRate;
    425 |     }
    426 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 428 行
- **函数**: `sellTaxRate()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    425 |     }
    426 | 
    427 |     /// @notice Returns the sell tax rate in basis points
>>  428 |     function sellTaxRate() external view override returns (uint16) {
    429 |         return poolState.sellTaxRate;
    430 |     }
    431 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 433 行
- **函数**: `liquidationThreshold()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    430 |     }
    431 | 
    432 |     /// @notice Returns the liquidation threshold
>>  433 |     function liquidationThreshold() external view override returns (uint256) {
    434 |         return poolState.liquidationThreshold;
    435 |     }
    436 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 438 行
- **函数**: `taxExpirationTime()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    435 |     }
    436 | 
    437 |     /// @notice Returns the timestamp when the tax expires
>>  438 |     function taxExpirationTime() external view returns (uint256) {
    439 |         return poolState.taxExpirationTime;
    440 |     }
    441 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 443 行
- **函数**: `antiFarmerExpirationTime()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    440 |     }
    441 | 
    442 |     /// @notice Returns the timestamp when the anti-farmer tax expires
>>  443 |     function antiFarmerExpirationTime() external view returns (uint256) {
    444 |         return poolState.antiFarmerExpirationTime;
    445 |     }
    446 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 541 行
- **函数**: `name()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    538 |     /**
    539 |      * @dev Returns the name of the token.
    540 |      */
>>  541 |     function name() public view virtual override returns (string memory) {
    542 |         return _name;
    543 |     }
    544 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 549 行
- **函数**: `symbol()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    546 |      * @dev Returns the symbol of the token, usually a shorter version of the
    547 |      * name.
    548 |      */
>>  549 |     function symbol() public view virtual override returns (string memory) {
    550 |         return _symbol;
    551 |     }
    552 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 566 行
- **函数**: `decimals()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    563 |      * no way affects any of the arithmetic of the contract, including
    564 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    565 |      */
>>  566 |     function decimals() public view virtual override returns (uint8) {
    567 |         return 18;
    568 |     }
    569 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 573 行
- **函数**: `totalSupply()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    570 |     /**
    571 |      * @dev See {IERC20-totalSupply}.
    572 |      */
>>  573 |     function totalSupply() public view virtual override returns (uint256) {
    574 |         return _totalSupply;
    575 |     }
    576 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 580 行
- **函数**: `balanceOf()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    577 |     /**
    578 |      * @dev See {IERC20-balanceOf}.
    579 |      */
>>  580 |     function balanceOf(address account) public view virtual override returns (uint256) {
    581 |         return _balances[account];
    582 |     }
    583 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 592 行
- **函数**: `transfer()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    589 |      * - `to` cannot be the zero address.
    590 |      * - the caller must have a balance of at least `amount`.
    591 |      */
>>  592 |     function transfer(address to, uint256 amount) public virtual override returns (bool) {
    593 |         address owner = _msgSender();
    594 |         _transfer(owner, to, amount);
    595 |         return true;
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 601 行
- **函数**: `allowance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    598 |     /**
    599 |      * @dev See {IERC20-allowance}.
    600 |      */
>>  601 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    602 |         return _allowances[owner][spender];
    603 |     }
    604 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 615 行
- **函数**: `approve()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    612 |      *
    613 |      * - `spender` cannot be the zero address.
    614 |      */
>>  615 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    616 |         address owner = _msgSender();
    617 |         _approve(owner, spender, amount);
    618 |         return true;
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 637 行
- **函数**: `transferFrom()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    634 |      * - the caller must have allowance for ``from``'s tokens of at least
    635 |      * `amount`.
    636 |      */
>>  637 |     function transferFrom(address from, address to, uint256 amount) public virtual override returns (bool) {
    638 |         address spender = _msgSender();
    639 |         _spendAllowance(from, spender, amount);
    640 |         _transfer(from, to, amount);
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 656 行
- **函数**: `increaseAllowance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    653 |      *
    654 |      * - `spender` cannot be the zero address.
    655 |      */
>>  656 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    657 |         address owner = _msgSender();
    658 |         _approve(owner, spender, allowance(owner, spender) + addedValue);
    659 |         return true;
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 676 行
- **函数**: `decreaseAllowance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    673 |      * - `spender` must have allowance for the caller of at least
    674 |      * `subtractedValue`.
    675 |      */
>>  676 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    677 |         address owner = _msgSender();
    678 |         uint256 currentAllowance = allowance(owner, spender);
    679 |         require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1085 行
- **函数**: `v2Router()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1082 |     function initialize(InitParams memory params) external;
   1083 | 
   1084 |     /// @notice Returns the stored PCS V2 router address
>> 1085 |     function v2Router() external view returns (address);
   1086 | 
   1087 |     /// @notice Returns the main V2 pool address for this token
   1088 |     function mainPool() external view returns (address);
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1088 行
- **函数**: `mainPool()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1085 |     function v2Router() external view returns (address);
   1086 | 
   1087 |     /// @notice Returns the main V2 pool address for this token
>> 1088 |     function mainPool() external view returns (address);
   1089 | 
   1090 |     /// @notice Returns the minimum liquidation threshold (immutable in implementation)
   1091 |     function MIN_LIQ_THRESHOLD() external view returns (uint256);
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1091 行
- **函数**: `MIN_LIQ_THRESHOLD()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1088 |     function mainPool() external view returns (address);
   1089 | 
   1090 |     /// @notice Returns the minimum liquidation threshold (immutable in implementation)
>> 1091 |     function MIN_LIQ_THRESHOLD() external view returns (uint256);
   1092 | 
   1093 |     /// @notice Returns the starting liquidation threshold (immutable in implementation)
   1094 |     function START_LIQ_THRESHOLD() external view returns (uint256);
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1094 行
- **函数**: `START_LIQ_THRESHOLD()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1091 |     function MIN_LIQ_THRESHOLD() external view returns (uint256);
   1092 | 
   1093 |     /// @notice Returns the starting liquidation threshold (immutable in implementation)
>> 1094 |     function START_LIQ_THRESHOLD() external view returns (uint256);
   1095 | 
   1096 |     /// @notice Returns the initial liquidation threshold stored at initialization time.
   1097 |     /// This is the upper bound for threshold recovery.
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1098 行
- **函数**: `initialLiquidationThreshold()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1095 | 
   1096 |     /// @notice Returns the initial liquidation threshold stored at initialization time.
   1097 |     /// This is the upper bound for threshold recovery.
>> 1098 |     function initialLiquidationThreshold() external view returns (uint256);
   1099 | 
   1100 |     /// @notice Returns the anti-farmer duration
   1101 |     function antiFarmerDuration() external view returns (uint256);
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1101 行
- **函数**: `antiFarmerDuration()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1098 |     function initialLiquidationThreshold() external view returns (uint256);
   1099 | 
   1100 |     /// @notice Returns the anti-farmer duration
>> 1101 |     function antiFarmerDuration() external view returns (uint256);
   1102 | 
   1103 |     /// @notice Returns the IPFS CID of the metadata JSON
   1104 |     function metaURI() external view returns (string memory);
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1104 行
- **函数**: `metaURI()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1101 |     function antiFarmerDuration() external view returns (uint256);
   1102 | 
   1103 |     /// @notice Returns the IPFS CID of the metadata JSON
>> 1104 |     function metaURI() external view returns (string memory);
   1105 | 
   1106 |     /// @notice Returns the effective (worst-case) tax rate in basis points.
   1107 |     /// @dev Returns max(buyTaxRate, sellTaxRate) for backward compatibility with systems
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1110 行
- **函数**: `taxRate()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1107 |     /// @dev Returns max(buyTaxRate, sellTaxRate) for backward compatibility with systems
   1108 |     ///      that only understand a single tax rate. Aggregators that cannot detect asymmetric
   1109 |     ///      buy/sell rates will see a safe (worst-case) value and avoid under-reporting the tax.
>> 1110 |     function taxRate() external view returns (uint16);
   1111 | 
   1112 |     /// @notice Returns the buy tax rate in basis points
   1113 |     function buyTaxRate() external view returns (uint16);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1113 行
- **函数**: `buyTaxRate()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1110 |     function taxRate() external view returns (uint16);
   1111 | 
   1112 |     /// @notice Returns the buy tax rate in basis points
>> 1113 |     function buyTaxRate() external view returns (uint16);
   1114 | 
   1115 |     /// @notice Returns the sell tax rate in basis points
   1116 |     function sellTaxRate() external view returns (uint16);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1116 行
- **函数**: `sellTaxRate()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1113 |     function buyTaxRate() external view returns (uint16);
   1114 | 
   1115 |     /// @notice Returns the sell tax rate in basis points
>> 1116 |     function sellTaxRate() external view returns (uint16);
   1117 | 
   1118 |     /// @notice Returns the tax processor address
   1119 |     function taxProcessor() external view returns (address);
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1119 行
- **函数**: `taxProcessor()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1116 |     function sellTaxRate() external view returns (uint16);
   1117 | 
   1118 |     /// @notice Returns the tax processor address
>> 1119 |     function taxProcessor() external view returns (address);
   1120 | 
   1121 |     /// @notice Returns the dividend contract address
   1122 |     function dividendContract() external view returns (address);
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1122 行
- **函数**: `dividendContract()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1119 |     function taxProcessor() external view returns (address);
   1120 | 
   1121 |     /// @notice Returns the dividend contract address
>> 1122 |     function dividendContract() external view returns (address);
   1123 | 
   1124 |     /// @notice Starts the migration process (used by the Portal Contract)
   1125 |     function startMigration() external;
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1146 行
- **函数**: `liquidationThreshold()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1143 |     event TokensBurned(uint256 amount);
   1144 | 
   1145 |     /// @notice Returns the current liquidation threshold
>> 1146 |     function liquidationThreshold() external view returns (uint256);
   1147 | 
   1148 |     /// @notice Returns the current state of the pool
   1149 |     function state() external view returns (PoolState);
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1149 行
- **函数**: `state()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1146 |     function liquidationThreshold() external view returns (uint256);
   1147 | 
   1148 |     /// @notice Returns the current state of the pool
>> 1149 |     function state() external view returns (PoolState);
   1150 | }
   1151 | 
   1152 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1234 行
- **函数**: `nonces()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1231 |     /**
   1232 |      * @inheritdoc IERC20PermitUpgradeable
   1233 |      */
>> 1234 |     function nonces(address owner) public view virtual override returns (uint256) {
   1235 |         return _nonces[owner].current();
   1236 |     }
   1237 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1242 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1239 |      * @inheritdoc IERC20PermitUpgradeable
   1240 |      */
   1241 |     // solhint-disable-next-line func-name-mixedcase
>> 1242 |     function DOMAIN_SEPARATOR() external view override returns (bytes32) {
   1243 |         return _domainSeparatorV4();
   1244 |     }
   1245 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1315 行
- **函数**: `owner()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1312 |     /**
   1313 |      * @dev Returns the address of the current owner.
   1314 |      */
>> 1315 |     function owner() public view virtual returns (address) {
   1316 |         return _owner;
   1317 |     }
   1318 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1393 行
- **函数**: `totalSupply()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1390 |     /**
   1391 |      * @dev Returns the amount of tokens in existence.
   1392 |      */
>> 1393 |     function totalSupply() external view returns (uint256);
   1394 | 
   1395 |     /**
   1396 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1398 行
- **函数**: `balanceOf()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1395 |     /**
   1396 |      * @dev Returns the amount of tokens owned by `account`.
   1397 |      */
>> 1398 |     function balanceOf(address account) external view returns (uint256);
   1399 | 
   1400 |     /**
   1401 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1407 行
- **函数**: `transfer()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1404 |      *
   1405 |      * Emits a {Transfer} event.
   1406 |      */
>> 1407 |     function transfer(address to, uint256 amount) external returns (bool);
   1408 | 
   1409 |     /**
   1410 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1416 行
- **函数**: `allowance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1413 |      *
   1414 |      * This value changes when {approve} or {transferFrom} are called.
   1415 |      */
>> 1416 |     function allowance(address owner, address spender) external view returns (uint256);
   1417 | 
   1418 |     /**
   1419 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1432 行
- **函数**: `approve()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1429 |      *
   1430 |      * Emits an {Approval} event.
   1431 |      */
>> 1432 |     function approve(address spender, uint256 amount) external returns (bool);
   1433 | 
   1434 |     /**
   1435 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1443 行
- **函数**: `transferFrom()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1440 |      *
   1441 |      * Emits a {Transfer} event.
   1442 |      */
>> 1443 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
   1444 | }
   1445 | 
   1446 | 
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1688 行
- **函数**: `processTaxTokens()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1685 |     ///         == 0 => no change (output matched expected, or liqExpectedOutputAmount is zero)
   1686 |     /// @dev The return value is backward-compatible: V2 tax tokens call this via `try ... {}`
   1687 |     ///      and Solidity silently ignores extra return data when no return type is declared.
>> 1688 |     function processTaxTokens(uint256 taxAmount) external returns (int8 liqThresholdDirection);
   1689 | 
   1690 |     /// @notice Process bonding curve tax by accepting quote tokens and distributing them
   1691 |     function processBondingCurveTax(uint256 quoteAmount) external;
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1702 行
- **函数**: `getQuoteToken()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1699 |     // --- View: Addresses ---
   1700 | 
   1701 |     /// @notice Get the quote token address (WETH if isWeth, otherwise stored quoteToken)
>> 1702 |     function getQuoteToken() external view returns (address);
   1703 | 
   1704 |     /// @notice Get WETH address
   1705 |     function weth() external view returns (address);
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1705 行
- **函数**: `weth()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1702 |     function getQuoteToken() external view returns (address);
   1703 | 
   1704 |     /// @notice Get WETH address
>> 1705 |     function weth() external view returns (address);
   1706 | 
   1707 |     /// @notice Get flapBlackHole address
   1708 |     function flapBlackHole() external view returns (address);
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1708 行
- **函数**: `flapBlackHole()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1705 |     function weth() external view returns (address);
   1706 | 
   1707 |     /// @notice Get flapBlackHole address
>> 1708 |     function flapBlackHole() external view returns (address);
   1709 | 
   1710 |     /// @notice Get tax token address
   1711 |     function taxToken() external view returns (address);
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1711 行
- **函数**: `taxToken()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1708 |     function flapBlackHole() external view returns (address);
   1709 | 
   1710 |     /// @notice Get tax token address
>> 1711 |     function taxToken() external view returns (address);
   1712 | 
   1713 |     /// @notice Get router address
   1714 |     function router() external view returns (address);
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1714 行
- **函数**: `router()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1711 |     function taxToken() external view returns (address);
   1712 | 
   1713 |     /// @notice Get router address
>> 1714 |     function router() external view returns (address);
   1715 | 
   1716 |     /// @notice Get fee receiver address
   1717 |     function feeReceiver() external view returns (address);
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1717 行
- **函数**: `feeReceiver()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1714 |     function router() external view returns (address);
   1715 | 
   1716 |     /// @notice Get fee receiver address
>> 1717 |     function feeReceiver() external view returns (address);
   1718 | 
   1719 |     /// @notice Get market receiver address
   1720 |     function marketAddress() external view returns (address);
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1720 行
- **函数**: `marketAddress()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1717 |     function feeReceiver() external view returns (address);
   1718 | 
   1719 |     /// @notice Get market receiver address
>> 1720 |     function marketAddress() external view returns (address);
   1721 | 
   1722 |     /// @notice Get dividend contract address
   1723 |     function dividendAddress() external view returns (address);
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1723 行
- **函数**: `dividendAddress()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1720 |     function marketAddress() external view returns (address);
   1721 | 
   1722 |     /// @notice Get dividend contract address
>> 1723 |     function dividendAddress() external view returns (address);
   1724 | 
   1725 |     /// @notice Get commission receiver address (address(0) if commission disabled)
   1726 |     function commissionReceiver() external view returns (address);
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1726 行
- **函数**: `commissionReceiver()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1723 |     function dividendAddress() external view returns (address);
   1724 | 
   1725 |     /// @notice Get commission receiver address (address(0) if commission disabled)
>> 1726 |     function commissionReceiver() external view returns (address);
   1727 | 
   1728 |     /// @notice Get the converter address for MEV-protected dividend-token swaps (address(0) if not needed)
   1729 |     function converter() external view returns (address);
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1729 行
- **函数**: `converter()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1726 |     function commissionReceiver() external view returns (address);
   1727 | 
   1728 |     /// @notice Get the converter address for MEV-protected dividend-token swaps (address(0) if not needed)
>> 1729 |     function converter() external view returns (address);
   1730 | 
   1731 |     /// @notice Get the dividend token address (address(0) means quoteToken is used)
   1732 |     function dividendToken() external view returns (address);
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1732 行
- **函数**: `dividendToken()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1729 |     function converter() external view returns (address);
   1730 | 
   1731 |     /// @notice Get the dividend token address (address(0) means quoteToken is used)
>> 1732 |     function dividendToken() external view returns (address);
   1733 | 
   1734 |     /// @notice Get the SwapRegistry address (immutable, set in constructor)
   1735 |     function swapRegistry() external view returns (address);
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1735 行
- **函数**: `swapRegistry()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1732 |     function dividendToken() external view returns (address);
   1733 | 
   1734 |     /// @notice Get the SwapRegistry address (immutable, set in constructor)
>> 1735 |     function swapRegistry() external view returns (address);
   1736 | 
   1737 |     // --- View: Balances ---
   1738 | 
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1740 行
- **函数**: `feeQuoteBalance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1737 |     // --- View: Balances ---
   1738 | 
   1739 |     /// @notice Get accumulated fee quote balance
>> 1740 |     function feeQuoteBalance() external view returns (uint256);
   1741 | 
   1742 |     /// @notice Get accumulated LP quote balance
   1743 |     function lpQuoteBalance() external view returns (uint256);
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1743 行
- **函数**: `lpQuoteBalance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1740 |     function feeQuoteBalance() external view returns (uint256);
   1741 | 
   1742 |     /// @notice Get accumulated LP quote balance
>> 1743 |     function lpQuoteBalance() external view returns (uint256);
   1744 | 
   1745 |     /// @notice Get accumulated market quote balance
   1746 |     function marketQuoteBalance() external view returns (uint256);
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1746 行
- **函数**: `marketQuoteBalance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1743 |     function lpQuoteBalance() external view returns (uint256);
   1744 | 
   1745 |     /// @notice Get accumulated market quote balance
>> 1746 |     function marketQuoteBalance() external view returns (uint256);
   1747 | 
   1748 |     /// @notice Get accumulated pending dividend quote token balance (awaiting conversion to dividend token)
   1749 |     function pendingDividendQuoteTokenBalance() external view returns (uint256);
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1749 行
- **函数**: `pendingDividendQuoteTokenBalance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1746 |     function marketQuoteBalance() external view returns (uint256);
   1747 | 
   1748 |     /// @notice Get accumulated pending dividend quote token balance (awaiting conversion to dividend token)
>> 1749 |     function pendingDividendQuoteTokenBalance() external view returns (uint256);
   1750 | 
   1751 |     /// @notice Get accumulated dividend quote balance
   1752 |     /// @dev Deprecated: backward-compatible alias for pendingDividendQuoteTokenBalance().
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1753 行
- **函数**: `dividendQuoteBalance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1750 | 
   1751 |     /// @notice Get accumulated dividend quote balance
   1752 |     /// @dev Deprecated: backward-compatible alias for pendingDividendQuoteTokenBalance().
>> 1753 |     function dividendQuoteBalance() external view returns (uint256);
   1754 | 
   1755 |     /// @notice Get accumulated dividend token balance waiting to be deposited to dividend contract
   1756 |     function dividendTokenBalance() external view returns (uint256);
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1756 行
- **函数**: `dividendTokenBalance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1753 |     function dividendQuoteBalance() external view returns (uint256);
   1754 | 
   1755 |     /// @notice Get accumulated dividend token balance waiting to be deposited to dividend contract
>> 1756 |     function dividendTokenBalance() external view returns (uint256);
   1757 | 
   1758 |     /// @notice Get accumulated commission quote balance
   1759 |     function commissionQuoteBalance() external view returns (uint256);
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1759 行
- **函数**: `commissionQuoteBalance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1756 |     function dividendTokenBalance() external view returns (uint256);
   1757 | 
   1758 |     /// @notice Get accumulated commission quote balance
>> 1759 |     function commissionQuoteBalance() external view returns (uint256);
   1760 | 
   1761 |     // --- View: Config ---
   1762 | 
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1764 行
- **函数**: `feeConfig()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1761 |     // --- View: Config ---
   1762 | 
   1763 |     /// @notice Get packed fee configuration (unchanged from V2 for backward compatibility)
>> 1764 |     function feeConfig() external view returns (PackedFeeConfig memory);
   1765 | 
   1766 |     /// @notice Get fee configuration including commission bps (V3 extension).
   1767 |     /// @dev Use this when you need the commission bps. feeConfig() is unchanged for backward compat.
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1768 行
- **函数**: `feeConfigV2()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1765 | 
   1766 |     /// @notice Get fee configuration including commission bps (V3 extension).
   1767 |     /// @dev Use this when you need the commission bps. feeConfig() is unchanged for backward compat.
>> 1768 |     function feeConfigV2() external view returns (PackedFeeConfigV2 memory);
   1769 | 
   1770 |     /// @notice Get the commission in basis points (taken from remainder after protocol fee)
   1771 |     function commissionBps() external view returns (uint16);
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1771 行
- **函数**: `commissionBps()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1768 |     function feeConfigV2() external view returns (PackedFeeConfigV2 memory);
   1769 | 
   1770 |     /// @notice Get the commission in basis points (taken from remainder after protocol fee)
>> 1771 |     function commissionBps() external view returns (uint16);
   1772 | 
   1773 |     /// @notice Get the reference expected output amount for liquidation threshold direction
   1774 |     function liqExpectedOutputAmount() external view returns (uint256);
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1774 行
- **函数**: `liqExpectedOutputAmount()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1771 |     function commissionBps() external view returns (uint16);
   1772 | 
   1773 |     /// @notice Get the reference expected output amount for liquidation threshold direction
>> 1774 |     function liqExpectedOutputAmount() external view returns (uint256);
   1775 | 
   1776 |     /// @notice Returns true when this TaxProcessor requires a MEV-protected RPC for the converter.
   1777 |     /// @dev True when dividendToken != address(0) && dividendToken != quoteToken &&
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1780 行
- **函数**: `requiresMEVProtection()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1777 |     /// @dev True when dividendToken != address(0) && dividendToken != quoteToken &&
   1778 |     ///      dividendToken != taxToken (Case 3 - dividend requires a DEX swap).
   1779 |     ///      When true, the converter MUST call dispatch() through a MEV-protected RPC.
>> 1780 |     function requiresMEVProtection() external view returns (bool);
   1781 | 
   1782 |     // --- View: Totals ---
   1783 | 
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1785 行
- **函数**: `totalDividendTokenSent()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1782 |     // --- View: Totals ---
   1783 | 
   1784 |     /// @notice Get total dividend tokens sent to dividend contract
>> 1785 |     function totalDividendTokenSent() external view returns (uint256);
   1786 | 
   1787 |     /// @notice Get total quote tokens sent to dividend contract
   1788 |     /// @dev Deprecated: backward-compatible alias for totalDividendTokenSent().
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1791 行
- **函数**: `totalQuoteSentToDividend()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1788 |     /// @dev Deprecated: backward-compatible alias for totalDividendTokenSent().
   1789 |     ///      The returned value represents total dividend tokens sent (not just quote tokens).
   1790 |     ///      Its semantic does not match its name.
>> 1791 |     function totalQuoteSentToDividend() external view returns (uint256);
   1792 | 
   1793 |     /// @notice Get total quote tokens added to liquidity
   1794 |     function totalQuoteAddedToLiquidity() external view returns (uint256);
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1794 行
- **函数**: `totalQuoteAddedToLiquidity()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1791 |     function totalQuoteSentToDividend() external view returns (uint256);
   1792 | 
   1793 |     /// @notice Get total quote tokens added to liquidity
>> 1794 |     function totalQuoteAddedToLiquidity() external view returns (uint256);
   1795 | 
   1796 |     /// @notice Get total tax tokens added to liquidity
   1797 |     function totalTokenAddedToLiquidity() external view returns (uint256);
```

---

### 78. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1797 行
- **函数**: `totalTokenAddedToLiquidity()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1794 |     function totalQuoteAddedToLiquidity() external view returns (uint256);
   1795 | 
   1796 |     /// @notice Get total tax tokens added to liquidity
>> 1797 |     function totalTokenAddedToLiquidity() external view returns (uint256);
   1798 | 
   1799 |     /// @notice Get total quote tokens sent to marketing wallet
   1800 |     function totalQuoteSentToMarketing() external view returns (uint256);
```

---

### 79. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1800 行
- **函数**: `totalQuoteSentToMarketing()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1797 |     function totalTokenAddedToLiquidity() external view returns (uint256);
   1798 | 
   1799 |     /// @notice Get total quote tokens sent to marketing wallet
>> 1800 |     function totalQuoteSentToMarketing() external view returns (uint256);
   1801 | }
   1802 | 
   1803 | 
```

---

### 80. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1871 行
- **函数**: `deposit()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1868 |     /// @notice Deposit dividends to be distributed
   1869 |     /// @param amount The amount of dividend tokens to deposit
   1870 |     /// @return success Whether the deposit was successful
>> 1871 |     function deposit(uint256 amount) external returns (bool success);
   1872 | 
   1873 |     /// @notice Batch distribute dividends to specified users
   1874 |     /// @param users Array of user addresses to distribute dividends to
```

---

### 81. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1876 行
- **函数**: `distributeDividend()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1873 |     /// @notice Batch distribute dividends to specified users
   1874 |     /// @param users Array of user addresses to distribute dividends to
   1875 |     /// @return successCount Number of successful distributions
>> 1876 |     function distributeDividend(address[] calldata users) external returns (uint256 successCount);
   1877 | 
   1878 |     /// @notice User can call this to withdraw their own dividends (unwraps WETH to ETH if applicable)
   1879 |     /// @return success Whether the withdrawal was successful
```

---

### 82. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1880 行
- **函数**: `withdrawDividends()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1877 | 
   1878 |     /// @notice User can call this to withdraw their own dividends (unwraps WETH to ETH if applicable)
   1879 |     /// @return success Whether the withdrawal was successful
>> 1880 |     function withdrawDividends() external returns (bool success);
   1881 | 
   1882 |     /// @notice Withdraw dividends for a specific user
   1883 |     /// @param user The user address to withdraw for
```

---

### 83. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1885 行
- **函数**: `withdrawDividendsFor()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1882 |     /// @notice Withdraw dividends for a specific user
   1883 |     /// @param user The user address to withdraw for
   1884 |     /// @return success Whether the withdrawal was successful
>> 1885 |     function withdrawDividendsFor(address user) external returns (bool success);
   1886 | 
   1887 |     /// @notice Withdraw dividends for a specific user with option to unwrap WETH
   1888 |     /// @param user The user address to withdraw for
```

---

### 84. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1891 行
- **函数**: `withdrawDividendsFor()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1888 |     /// @param user The user address to withdraw for
   1889 |     /// @param unwrapWETH Whether to unwrap WETH to ETH
   1890 |     /// @return success Whether the withdrawal was successful
>> 1891 |     function withdrawDividendsFor(address user, bool unwrapWETH) external returns (bool success);
   1892 | 
   1893 |     /// @notice Get the withdrawable dividend amount for a user
   1894 |     /// @param user The user address
```

---

### 85. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1896 行
- **函数**: `withdrawableDividends()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1893 |     /// @notice Get the withdrawable dividend amount for a user
   1894 |     /// @param user The user address
   1895 |     /// @return The amount of dividends the user can claim
>> 1896 |     function withdrawableDividends(address user) external view returns (uint256);
   1897 | 
   1898 |     /// @notice Exclude an address from receiving dividends
   1899 |     /// @param addr The address to exclude
```

---

### 86. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1904 行
- **函数**: `totalShares()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1901 | 
   1902 |     /// @notice Get total shares across all users
   1903 |     /// @return The total amount of shares
>> 1904 |     function totalShares() external view returns (uint256);
   1905 | 
   1906 |     /// @notice Get the minimum share balance required for dividend eligibility
   1907 |     /// @return The minimum share balance
```

---

### 87. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1908 行
- **函数**: `minimumShareBalance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1905 | 
   1906 |     /// @notice Get the minimum share balance required for dividend eligibility
   1907 |     /// @return The minimum share balance
>> 1908 |     function minimumShareBalance() external view returns (uint256);
   1909 | 
   1910 |     /// @notice Get total dividends withdrawn by a user
   1911 |     /// @param user The user address
```

---

### 88. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1913 行
- **函数**: `withdrawnDividends()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1910 |     /// @notice Get total dividends withdrawn by a user
   1911 |     /// @param user The user address
   1912 |     /// @return The total amount of dividends withdrawn
>> 1913 |     function withdrawnDividends(address user) external view returns (uint256);
   1914 | 
   1915 |     /// @notice Emergency withdraw function to recover tokens in case of emergency
   1916 |     /// @param token The token address to withdraw (use address(0) for native ETH)
```

---

### 89. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1951 行
- **函数**: `totalSupply()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1948 |     /**
   1949 |      * @dev Returns the amount of tokens in existence.
   1950 |      */
>> 1951 |     function totalSupply() external view returns (uint256);
   1952 | 
   1953 |     /**
   1954 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 90. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1956 行
- **函数**: `balanceOf()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1953 |     /**
   1954 |      * @dev Returns the amount of tokens owned by `account`.
   1955 |      */
>> 1956 |     function balanceOf(address account) external view returns (uint256);
   1957 | 
   1958 |     /**
   1959 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 91. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1965 行
- **函数**: `transfer()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1962 |      *
   1963 |      * Emits a {Transfer} event.
   1964 |      */
>> 1965 |     function transfer(address to, uint256 amount) external returns (bool);
   1966 | 
   1967 |     /**
   1968 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 92. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1974 行
- **函数**: `allowance()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1971 |      *
   1972 |      * This value changes when {approve} or {transferFrom} are called.
   1973 |      */
>> 1974 |     function allowance(address owner, address spender) external view returns (uint256);
   1975 | 
   1976 |     /**
   1977 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 93. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1990 行
- **函数**: `approve()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1987 |      *
   1988 |      * Emits an {Approval} event.
   1989 |      */
>> 1990 |     function approve(address spender, uint256 amount) external returns (bool);
   1991 | 
   1992 |     /**
   1993 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 94. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2001 行
- **函数**: `transferFrom()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1998 |      *
   1999 |      * Emits a {Transfer} event.
   2000 |      */
>> 2001 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
   2002 | }
   2003 | 
   2004 | 
```

---

### 95. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2023 行
- **函数**: `name()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2020 |     /**
   2021 |      * @dev Returns the name of the token.
   2022 |      */
>> 2023 |     function name() external view returns (string memory);
   2024 | 
   2025 |     /**
   2026 |      * @dev Returns the symbol of the token.
```

---

### 96. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2028 行
- **函数**: `symbol()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2025 |     /**
   2026 |      * @dev Returns the symbol of the token.
   2027 |      */
>> 2028 |     function symbol() external view returns (string memory);
   2029 | 
   2030 |     /**
   2031 |      * @dev Returns the decimals places of the token.
```

---

### 97. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2033 行
- **函数**: `decimals()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2030 |     /**
   2031 |      * @dev Returns the decimals places of the token.
   2032 |      */
>> 2033 |     function decimals() external view returns (uint8);
   2034 | }
   2035 | 
   2036 | 
```

---

### 98. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2414 行
- **函数**: `nonces()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2411 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   2412 |      * prevents a signature from being used multiple times.
   2413 |      */
>> 2414 |     function nonces(address owner) external view returns (uint256);
   2415 | 
   2416 |     /**
   2417 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 99. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2420 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2417 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
   2418 |      */
   2419 |     // solhint-disable-next-line func-name-mixedcase
>> 2420 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2421 | }
   2422 | 
   2423 | 
```

---

### 100. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2985 行
- **函数**: `nonces()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2982 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   2983 |      * prevents a signature from being used multiple times.
   2984 |      */
>> 2985 |     function nonces(address owner) external view returns (uint256);
   2986 | 
   2987 |     /**
   2988 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 101. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2991 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2988 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
   2989 |      */
   2990 |     // solhint-disable-next-line func-name-mixedcase
>> 2991 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2992 | }
   2993 | 
   2994 | 
```

---

### 102. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 36 行
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     31 | ///                       liquidation. It can both decrease (unfavorable conditions) and recover toward
     32 | ///                       `initialLiquidationThreshold` (favorable conditions).
     33 | ///    - Immutable threshold limits: `MIN_LIQ_THRESHOLD` and `START_LIQ_THRESHOLD` are implementation-level
     34 | ///                       immutables, allowing the protocol to adjust system-wide limits by deploying a
     35 | ///                       new implementation without code changes. All clones share these values.
>>   36 | contract FlapTaxTokenV3 is Initializable, ERC20PermitUpgradeable, OwnableUpgradeable, IFlapTaxTokenV3 {
     37 |     using SafeERC20 for IERC20;
     38 | 
     39 |     /// @notice The minimum liquidation threshold — set via constructor immutable.
     40 |     ///         All clones of the same implementation share this value.
     41 |     uint256 public immutable MIN_LIQ_THRESHOLD;
```

---

### 103. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 513 行
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    508 |  *
    509 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    510 |  * functions have been added to mitigate the well-known issues around setting
    511 |  * allowances. See {IERC20-approve}.
    512 |  */
>>  513 | contract ERC20Upgradeable is Initializable, ContextUpgradeable, IERC20Upgradeable, IERC20MetadataUpgradeable {
    514 |     mapping(address => uint256) private _balances;
    515 | 
    516 |     mapping(address => mapping(address => uint256)) private _allowances;
    517 | 
    518 |     uint256 private _totalSupply;
```

---

### 104. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 913 行
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    908 |  *     _disableInitializers();
    909 |  * }
    910 |  * ```
    911 |  * ====
    912 |  */
>>  913 | abstract contract Initializable {
    914 |     /**
    915 |      * @dev Indicates that the contract has been initialized.
    916 |      * @custom:oz-retyped-from bool
    917 |      */
    918 |     uint8 private _initialized;
```

---

### 105. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1179 行
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1174 |  *
   1175 |  * _Available since v3.4._
   1176 |  *
   1177 |  * @custom:storage-size 51
   1178 |  */
>> 1179 | abstract contract ERC20PermitUpgradeable is Initializable, ERC20Upgradeable, IERC20PermitUpgradeable, EIP712Upgradeable {
   1180 |     using CountersUpgradeable for CountersUpgradeable.Counter;
   1181 | 
   1182 |     mapping(address => CountersUpgradeable.Counter) private _nonces;
   1183 | 
   1184 |     // solhint-disable-next-line var-name-mixedcase
```

---

### 106. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1288 行
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1283 |  *
   1284 |  * This module is used through inheritance. It will make available the modifier
   1285 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
   1286 |  * the owner.
   1287 |  */
>> 1288 | abstract contract OwnableUpgradeable is Initializable, ContextUpgradeable {
   1289 |     address private _owner;
   1290 | 
   1291 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
   1292 | 
   1293 |     /**
```

---

### 107. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1347 行
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1342 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
   1343 |         _transferOwnership(newOwner);
   1344 |     }
   1345 | 
   1346 |     /**
>> 1347 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
   1348 |      * Internal function without access restriction.
   1349 |      */
   1350 |     function _transferOwnership(address newOwner) internal virtual {
   1351 |         address oldOwner = _owner;
   1352 |         _owner = newOwner;
```

---

### 108. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1461 行
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1456 | import "../../../utils/Address.sol";
   1457 | 
   1458 | /**
   1459 |  * @title SafeERC20
   1460 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>> 1461 |  * contract returns false). Tokens that return no value (and instead revert or
   1462 |  * throw on failure) are also supported, non-reverting calls are assumed to be
   1463 |  * successful.
   1464 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
   1465 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
   1466 |  */
```

---

### 109. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1722 行
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1717 |     function feeReceiver() external view returns (address);
   1718 | 
   1719 |     /// @notice Get market receiver address
   1720 |     function marketAddress() external view returns (address);
   1721 | 
>> 1722 |     /// @notice Get dividend contract address
   1723 |     function dividendAddress() external view returns (address);
   1724 | 
   1725 |     /// @notice Get commission receiver address (address(0) if commission disabled)
   1726 |     function commissionReceiver() external view returns (address);
   1727 | 
```

---

### 110. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2670 行
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2665 |  * ({_hashTypedDataV4}).
   2666 |  *
   2667 |  * The implementation of the domain separator was designed to be as efficient as possible while still properly updating
   2668 |  * the chain id to protect against replay attacks on an eventual fork of the chain.
   2669 |  *
>> 2670 |  * NOTE: This contract implements the version of the encoding known as "v4", as implemented by the JSON RPC method
   2671 |  * https://docs.metamask.io/guide/signing-data.html[`eth_signTypedDataV4` in MetaMask].
   2672 |  *
   2673 |  * NOTE: In the upgradeable version of this contract, the cached values will correspond to the address, and the domain
   2674 |  * separator of the implementation contract. This will cause the `_domainSeparatorV4` function to always rebuild the
   2675 |  * separator from the immutable values, which is cheaper than accessing a cached version in cold storage.
```

---

### 111. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 179 行
- **函数**: `finalizeMigration()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    176 |         PackedPoolState memory currentPoolState = poolState;
    177 |         if (PoolState(currentPoolState.state) == PoolState.Migrating) {
    178 |             currentPoolState.state = uint8(PoolState.TaxEnforcedAntiFarmer);
>>  179 |             currentPoolState.taxExpirationTime = uint64(currentPoolState.taxExpirationTime + block.timestamp);
    180 |             currentPoolState.antiFarmerExpirationTime = uint48(block.timestamp + antiFarmerDuration);
    181 |             poolState = currentPoolState;
    182 |             emit PoolStateChanged(uint8(PoolState.Migrating), currentPoolState.state);
```

---

### 112. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 180 行
- **函数**: `finalizeMigration()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    177 |         if (PoolState(currentPoolState.state) == PoolState.Migrating) {
    178 |             currentPoolState.state = uint8(PoolState.TaxEnforcedAntiFarmer);
    179 |             currentPoolState.taxExpirationTime = uint64(currentPoolState.taxExpirationTime + block.timestamp);
>>  180 |             currentPoolState.antiFarmerExpirationTime = uint48(block.timestamp + antiFarmerDuration);
    181 |             poolState = currentPoolState;
    182 |             emit PoolStateChanged(uint8(PoolState.Migrating), currentPoolState.state);
    183 |         }
```

---

### 113. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 277 行
- **函数**: `_liquidateTax()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    274 |             bool stateChanged = false;
    275 | 
    276 |             // State transitions
>>  277 |             if (block.timestamp > currentPoolState.taxExpirationTime) {
    278 |                 PoolState oldState = PoolState(currentPoolState.state);
    279 |                 currentPoolState.state = uint8(PoolState.TaxFree);
    280 |                 currentPoolState.buyTaxRate = 0;
```

---

### 114. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 285 行
- **函数**: `_liquidateTax()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    282 |                 stateChanged = true;
    283 |                 emit PoolStateChanged(uint8(oldState), currentPoolState.state);
    284 |             } else if (
>>  285 |                 block.timestamp > currentPoolState.antiFarmerExpirationTime && currentState != PoolState.TaxEnforced
    286 |             ) {
    287 |                 PoolState oldState = PoolState(currentPoolState.state);
    288 |                 currentPoolState.state = uint8(PoolState.TaxEnforced);
```

---

### 115. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 1219 行
- **函数**: `permit()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1216 |         bytes32 r,
   1217 |         bytes32 s
   1218 |     ) public virtual override {
>> 1219 |         require(block.timestamp <= deadline, "ERC20Permit: expired deadline");
   1220 | 
   1221 |         bytes32 structHash = keccak256(abi.encode(_PERMIT_TYPEHASH, owner, spender, value, _useNonce(owner), deadline));
   1222 | 
```

---

### 116. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2527 行
- **函数**: `tryRecover()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2524 |      * _Available since v4.3._
   2525 |      */
   2526 |     function tryRecover(bytes32 hash, bytes32 r, bytes32 vs) internal pure returns (address, RecoverError) {
>> 2527 |         bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
   2528 |         uint8 v = uint8((uint256(vs) >> 255) + 27);
   2529 |         return tryRecover(hash, v, r, s);
   2530 |     }
```

---

### 117. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2559 行
- **函数**: `tryRecover()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2556 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
   2557 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
   2558 |         // these malleable signatures as well.
>> 2559 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
   2560 |             return (address(0), RecoverError.InvalidSignatureS);
   2561 |         }
   2562 | 
```

---

### 118. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2319 行
- **函数**: `_revert()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2316 |         if (returndata.length > 0) {
   2317 |             // The easiest way to bubble the revert reason is using memory via assembly
   2318 |             /// @solidity memory-safe-assembly
>> 2319 |             assembly {
   2320 |                 let returndata_size := mload(returndata)
   2321 |                 revert(add(32, returndata), returndata_size)
   2322 |             }
```

---

### 119. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2488 行
- **函数**: `tryRecover()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2485 |             // ecrecover takes the signature parameters, and the only way to get them
   2486 |             // currently is to use assembly.
   2487 |             /// @solidity memory-safe-assembly
>> 2488 |             assembly {
   2489 |                 r := mload(add(signature, 0x20))
   2490 |                 s := mload(add(signature, 0x40))
   2491 |                 v := byte(0, mload(add(signature, 0x60)))
```

---

### 120. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2594 行
- **函数**: `toEthSignedMessageHash()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2591 |         // 32 is the length in bytes of hash,
   2592 |         // enforced by the type signature above
   2593 |         /// @solidity memory-safe-assembly
>> 2594 |         assembly {
   2595 |             mstore(0x00, "\x19Ethereum Signed Message:\n32")
   2596 |             mstore(0x1c, hash)
   2597 |             message := keccak256(0x00, 0x3c)
```

---

### 121. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 2624 行
- **函数**: `toTypedDataHash()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2621 |      */
   2622 |     function toTypedDataHash(bytes32 domainSeparator, bytes32 structHash) internal pure returns (bytes32 data) {
   2623 |         /// @solidity memory-safe-assembly
>> 2624 |         assembly {
   2625 |             let ptr := mload(0x40)
   2626 |             mstore(ptr, "\x19\x01")
   2627 |             mstore(add(ptr, 0x02), domainSeparator)
```

---

### 122. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 3232 行
- **函数**: `_revert()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3229 |         if (returndata.length > 0) {
   3230 |             // The easiest way to bubble the revert reason is using memory via assembly
   3231 |             /// @solidity memory-safe-assembly
>> 3232 |             assembly {
   3233 |                 let returndata_size := mload(returndata)
   3234 |                 revert(add(32, returndata), returndata_size)
   3235 |             }
```

---

### 123. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 3269 行
- **函数**: `toString()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3266 |             string memory buffer = new string(length);
   3267 |             uint256 ptr;
   3268 |             /// @solidity memory-safe-assembly
>> 3269 |             assembly {
   3270 |                 ptr := add(buffer, add(32, length))
   3271 |             }
   3272 |             while (true) {
```

---

### 124. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 3275 行
- **函数**: `toString()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3272 |             while (true) {
   3273 |                 ptr--;
   3274 |                 /// @solidity memory-safe-assembly
>> 3275 |                 assembly {
   3276 |                     mstore8(ptr, byte(mod(value, 10), _SYMBOLS))
   3277 |                 }
   3278 |                 value /= 10;
```

---

### 125. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 3427 行
- **函数**: `mulDiv()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3424 |             // variables such that product = prod1 * 2^256 + prod0.
   3425 |             uint256 prod0; // Least significant 256 bits of the product
   3426 |             uint256 prod1; // Most significant 256 bits of the product
>> 3427 |             assembly {
   3428 |                 let mm := mulmod(x, y, not(0))
   3429 |                 prod0 := mul(x, y)
   3430 |                 prod1 := sub(sub(mm, prod0), lt(mm, prod0))
```

---

### 126. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 3450 行
- **函数**: `mulDiv()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3447 | 
   3448 |             // Make division exact by subtracting the remainder from [prod1 prod0].
   3449 |             uint256 remainder;
>> 3450 |             assembly {
   3451 |                 // Compute remainder using mulmod.
   3452 |                 remainder := mulmod(x, y, denominator)
   3453 | 
```

---

### 127. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe6378926bAb18F4D80CAF3Fee5BB738a55e37777` 第 3464 行
- **函数**: `mulDiv()`
- **合约**: `FlapTaxTokenV3`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3461 | 
   3462 |             // Does not overflow because the denominator cannot be zero at this stage in the function.
   3463 |             uint256 twos = denominator & (~denominator + 1);
>> 3464 |             assembly {
   3465 |                 // Divide denominator by twos.
   3466 |                 denominator := div(denominator, twos)
   3467 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*