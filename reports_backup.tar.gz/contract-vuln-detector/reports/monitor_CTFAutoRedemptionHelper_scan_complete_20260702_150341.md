# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:03:41
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xfca64d34859b120C36426D41f941E708EA47CBec` |
| contract_name | `CTFAutoRedemptionHelper` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/CTFAutoRedemptionHelper.sol', 'node_modules/@openzeppelin/contracts/access/AccessControl.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/IERC20.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/utils/ERC1155Holder.sol', 'contracts/UMA/interfaces/IConditionalTokens.sol', 'contracts/NegRisk/interfaces/INegRiskAdapter.sol', 'contracts/ConditionalTokens/CTHelpers.sol', 'node_modules/@openzeppelin/contracts/access/IAccessControl.sol', 'node_modules/@openzeppelin/contracts/utils/Context.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/ERC165.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol', 'node_modules/@openzeppelin/contracts/utils/Address.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/IERC1155Receiver.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/IERC1155.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/IERC165.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655006` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 51 |
| 🟢 LOW | 2 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1833 行
- **函数**: `functionDelegateCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1830 |      * but performing a delegate call.
   1831 |      */
   1832 |     function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
>> 1833 |         (bool success, bytes memory returndata) = target.delegatecall(data);
   1834 |         return verifyCallResultFromTarget(target, success, returndata);
   1835 |     }
   1836 | 
```

---

### 2. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 807 行
- **函数**: `_callOptionalReturnBool()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    804 |         // we're implementing it ourselves. We cannot use {Address-functionCall} here since this should return false
    805 |         // and not revert is the subcall reverts.
    806 | 
>>  807 |         (bool success, bytes memory returndata) = address(token).call(data);
    808 |         return success && (returndata.length == 0 || abi.decode(returndata, (bool))) && address(token).code.length > 0;
    809 |     }
    810 | }
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1774 行
- **函数**: `sendValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1771 |             revert AddressInsufficientBalance(address(this));
   1772 |         }
   1773 | 
>> 1774 |         (bool success, ) = recipient.call{value: amount}("");
   1775 |         if (!success) {
   1776 |             revert FailedInnerCall();
   1777 |         }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1815 行
- **函数**: `functionCallWithValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1812 |         if (address(this).balance < value) {
   1813 |             revert AddressInsufficientBalance(address(this));
   1814 |         }
>> 1815 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
   1816 |         return verifyCallResultFromTarget(target, success, returndata);
   1817 |     }
   1818 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 268 行
- **函数**: `supportsInterface()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    265 |     }
    266 | 
    267 |     /// @inheritdoc AccessControl
>>  268 |     function supportsInterface(bytes4 interfaceId) public view override(AccessControl, ERC1155Holder) returns (bool) {
    269 |         return super.supportsInterface(interfaceId);
    270 |     }
    271 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 467 行
- **函数**: `supportsInterface()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    464 |     /**
    465 |      * @dev See {IERC165-supportsInterface}.
    466 |      */
>>  467 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
    468 |         return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
    469 |     }
    470 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 474 行
- **函数**: `hasRole()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    471 |     /**
    472 |      * @dev Returns `true` if `account` has been granted `role`.
    473 |      */
>>  474 |     function hasRole(bytes32 role, address account) public view virtual returns (bool) {
    475 |         return _roles[role].hasRole[account];
    476 |     }
    477 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 502 行
- **函数**: `getRoleAdmin()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    499 |      *
    500 |      * To change a role's admin, use {_setRoleAdmin}.
    501 |      */
>>  502 |     function getRoleAdmin(bytes32 role) public view virtual returns (bytes32) {
    503 |         return _roles[role].adminRole;
    504 |     }
    505 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 553 行
- **函数**: `renounceRole()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    550 |      *
    551 |      * May emit a {RoleRevoked} event.
    552 |      */
>>  553 |     function renounceRole(bytes32 role, address callerConfirmation) public virtual {
    554 |         if (callerConfirmation != _msgSender()) {
    555 |             revert AccessControlBadConfirmation();
    556 |         }
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 636 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    633 |     /**
    634 |      * @dev Returns the value of tokens in existence.
    635 |      */
>>  636 |     function totalSupply() external view returns (uint256);
    637 | 
    638 |     /**
    639 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 641 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    638 |     /**
    639 |      * @dev Returns the value of tokens owned by `account`.
    640 |      */
>>  641 |     function balanceOf(address account) external view returns (uint256);
    642 | 
    643 |     /**
    644 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 650 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    647 |      *
    648 |      * Emits a {Transfer} event.
    649 |      */
>>  650 |     function transfer(address to, uint256 value) external returns (bool);
    651 | 
    652 |     /**
    653 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 659 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    656 |      *
    657 |      * This value changes when {approve} or {transferFrom} are called.
    658 |      */
>>  659 |     function allowance(address owner, address spender) external view returns (uint256);
    660 | 
    661 |     /**
    662 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 676 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    673 |      *
    674 |      * Emits an {Approval} event.
    675 |      */
>>  676 |     function approve(address spender, uint256 value) external returns (bool);
    677 | 
    678 |     /**
    679 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 687 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    684 |      *
    685 |      * Emits a {Transfer} event.
    686 |      */
>>  687 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    688 | }
    689 | 
    690 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 833 行
- **函数**: `supportsInterface()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    830 |     /**
    831 |      * @dev See {IERC165-supportsInterface}.
    832 |      */
>>  833 |     function supportsInterface(bytes4 interfaceId) public view virtual override(ERC165, IERC165) returns (bool) {
    834 |         return interfaceId == type(IERC1155Receiver).interfaceId || super.supportsInterface(interfaceId);
    835 |     }
    836 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 869 行
- **函数**: `payoutNumerators()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    866 | 
    867 | interface IConditionalTokens is IERC1155 {
    868 |     /// Mapping key is an condition ID. Value represents numerators of the payout vector associated with the condition. This array is initialized with a length equal to the outcome slot count. E.g. Condition with 3 outcomes [A, B, C] and two of those correct [0.5, 0.5, 0]. In Ethereum there are no decimal values, so here, 0.5 is represented by fractions like 1/2 == 0.5. That's why we need numerator and denominator values. Payout numerators are also used as a check of initialization. If the numerators array is empty (has length zero), the condition was not created/prepared. See getOutcomeSlotCount.
>>  869 |     function payoutNumerators(bytes32) external returns (uint256[] memory);
    870 | 
    871 |     /// Denominator is also used for checking if the condition has been resolved. If the denominator is non-zero, then the condition has been resolved.
    872 |     function payoutDenominator(bytes32) external returns (uint256);
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 872 行
- **函数**: `payoutDenominator()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    869 |     function payoutNumerators(bytes32) external returns (uint256[] memory);
    870 | 
    871 |     /// Denominator is also used for checking if the condition has been resolved. If the denominator is non-zero, then the condition has been resolved.
>>  872 |     function payoutDenominator(bytes32) external returns (uint256);
    873 | 
    874 |     /// @dev This function prepares a condition by initializing a payout vector associated with the condition.
    875 |     /// @param questionId An identifier for the question to be answered by the oracle.
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 916 行
- **函数**: `getOutcomeSlotCount()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    913 |     /// @dev Gets the outcome slot count of a condition.
    914 |     /// @param conditionId ID of the condition.
    915 |     /// @return Number of outcome slots associated with a condition, or zero if condition has not been prepared yet.
>>  916 |     function getOutcomeSlotCount(bytes32 conditionId) external view returns (uint256);
    917 | 
    918 |     /// @dev Constructs a condition ID from an oracle, a question ID, and the outcome slot count for the question.
    919 |     /// @param oracle The account assigned to report the result for the prepared condition.
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 941 行
- **函数**: `getPositionId()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    938 |     /// @dev Constructs a position ID from a collateral token and an outcome collection. These IDs are used as the ERC-1155 ID for this contract.
    939 |     /// @param collateralToken Collateral token which backs the position.
    940 |     /// @param collectionId ID of the outcome collection associated with this position.
>>  941 |     function getPositionId(IERC20 collateralToken, bytes32 collectionId) external pure returns (uint256);
    942 | }
    943 | 
    944 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 979 行
- **函数**: `FEE_DENOMINATOR()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    976 |     event PositionsMerge(address indexed stakeholder, bytes32 indexed conditionId, uint256 amount);
    977 |     event QuestionPrepared(bytes32 indexed marketId, bytes32 indexed questionId, uint256 index, bytes data);
    978 | 
>>  979 |     function FEE_DENOMINATOR() external view returns (uint256);
    980 |     function NO_TOKEN_BURN_ADDRESS() external view returns (address);
    981 |     function addAdmin(address admin) external;
    982 |     function admins(address) external view returns (uint256);
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 980 行
- **函数**: `NO_TOKEN_BURN_ADDRESS()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    977 |     event QuestionPrepared(bytes32 indexed marketId, bytes32 indexed questionId, uint256 index, bytes data);
    978 | 
    979 |     function FEE_DENOMINATOR() external view returns (uint256);
>>  980 |     function NO_TOKEN_BURN_ADDRESS() external view returns (address);
    981 |     function addAdmin(address admin) external;
    982 |     function admins(address) external view returns (uint256);
    983 |     function balanceOf(address _owner, uint256 _id) external view returns (uint256);
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 982 行
- **函数**: `admins()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    979 |     function FEE_DENOMINATOR() external view returns (uint256);
    980 |     function NO_TOKEN_BURN_ADDRESS() external view returns (address);
    981 |     function addAdmin(address admin) external;
>>  982 |     function admins(address) external view returns (uint256);
    983 |     function balanceOf(address _owner, uint256 _id) external view returns (uint256);
    984 |     function balanceOfBatch(address[] memory _owners, uint256[] memory _ids) external view returns (uint256[] memory);
    985 |     function col() external view returns (address);
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 983 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    980 |     function NO_TOKEN_BURN_ADDRESS() external view returns (address);
    981 |     function addAdmin(address admin) external;
    982 |     function admins(address) external view returns (uint256);
>>  983 |     function balanceOf(address _owner, uint256 _id) external view returns (uint256);
    984 |     function balanceOfBatch(address[] memory _owners, uint256[] memory _ids) external view returns (uint256[] memory);
    985 |     function col() external view returns (address);
    986 |     function convertPositions(bytes32 _marketId, uint256 _indexSet, uint256 _amount) external;
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 984 行
- **函数**: `balanceOfBatch()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    981 |     function addAdmin(address admin) external;
    982 |     function admins(address) external view returns (uint256);
    983 |     function balanceOf(address _owner, uint256 _id) external view returns (uint256);
>>  984 |     function balanceOfBatch(address[] memory _owners, uint256[] memory _ids) external view returns (uint256[] memory);
    985 |     function col() external view returns (address);
    986 |     function convertPositions(bytes32 _marketId, uint256 _indexSet, uint256 _amount) external;
    987 |     function ctf() external view returns (address);
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 985 行
- **函数**: `col()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    982 |     function admins(address) external view returns (uint256);
    983 |     function balanceOf(address _owner, uint256 _id) external view returns (uint256);
    984 |     function balanceOfBatch(address[] memory _owners, uint256[] memory _ids) external view returns (uint256[] memory);
>>  985 |     function col() external view returns (address);
    986 |     function convertPositions(bytes32 _marketId, uint256 _indexSet, uint256 _amount) external;
    987 |     function ctf() external view returns (address);
    988 |     function getConditionId(bytes32 _questionId) external view returns (bytes32);
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 987 行
- **函数**: `ctf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    984 |     function balanceOfBatch(address[] memory _owners, uint256[] memory _ids) external view returns (uint256[] memory);
    985 |     function col() external view returns (address);
    986 |     function convertPositions(bytes32 _marketId, uint256 _indexSet, uint256 _amount) external;
>>  987 |     function ctf() external view returns (address);
    988 |     function getConditionId(bytes32 _questionId) external view returns (bytes32);
    989 |     function getDetermined(bytes32 _marketId) external view returns (bool);
    990 |     function getFeeBips(bytes32 _marketId) external view returns (uint256);
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 988 行
- **函数**: `getConditionId()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    985 |     function col() external view returns (address);
    986 |     function convertPositions(bytes32 _marketId, uint256 _indexSet, uint256 _amount) external;
    987 |     function ctf() external view returns (address);
>>  988 |     function getConditionId(bytes32 _questionId) external view returns (bytes32);
    989 |     function getDetermined(bytes32 _marketId) external view returns (bool);
    990 |     function getFeeBips(bytes32 _marketId) external view returns (uint256);
    991 |     function getMarketData(bytes32 _marketId) external view returns (MarketData);
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 989 行
- **函数**: `getDetermined()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    986 |     function convertPositions(bytes32 _marketId, uint256 _indexSet, uint256 _amount) external;
    987 |     function ctf() external view returns (address);
    988 |     function getConditionId(bytes32 _questionId) external view returns (bytes32);
>>  989 |     function getDetermined(bytes32 _marketId) external view returns (bool);
    990 |     function getFeeBips(bytes32 _marketId) external view returns (uint256);
    991 |     function getMarketData(bytes32 _marketId) external view returns (MarketData);
    992 |     function getOracle(bytes32 _marketId) external view returns (address);
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 990 行
- **函数**: `getFeeBips()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    987 |     function ctf() external view returns (address);
    988 |     function getConditionId(bytes32 _questionId) external view returns (bytes32);
    989 |     function getDetermined(bytes32 _marketId) external view returns (bool);
>>  990 |     function getFeeBips(bytes32 _marketId) external view returns (uint256);
    991 |     function getMarketData(bytes32 _marketId) external view returns (MarketData);
    992 |     function getOracle(bytes32 _marketId) external view returns (address);
    993 |     function getPositionId(bytes32 _questionId, bool _outcome) external view returns (uint256);
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 991 行
- **函数**: `getMarketData()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    988 |     function getConditionId(bytes32 _questionId) external view returns (bytes32);
    989 |     function getDetermined(bytes32 _marketId) external view returns (bool);
    990 |     function getFeeBips(bytes32 _marketId) external view returns (uint256);
>>  991 |     function getMarketData(bytes32 _marketId) external view returns (MarketData);
    992 |     function getOracle(bytes32 _marketId) external view returns (address);
    993 |     function getPositionId(bytes32 _questionId, bool _outcome) external view returns (uint256);
    994 |     function getQuestionCount(bytes32 _marketId) external view returns (uint256);
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 992 行
- **函数**: `getOracle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    989 |     function getDetermined(bytes32 _marketId) external view returns (bool);
    990 |     function getFeeBips(bytes32 _marketId) external view returns (uint256);
    991 |     function getMarketData(bytes32 _marketId) external view returns (MarketData);
>>  992 |     function getOracle(bytes32 _marketId) external view returns (address);
    993 |     function getPositionId(bytes32 _questionId, bool _outcome) external view returns (uint256);
    994 |     function getQuestionCount(bytes32 _marketId) external view returns (uint256);
    995 |     function getResult(bytes32 _marketId) external view returns (uint256);
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 993 行
- **函数**: `getPositionId()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    990 |     function getFeeBips(bytes32 _marketId) external view returns (uint256);
    991 |     function getMarketData(bytes32 _marketId) external view returns (MarketData);
    992 |     function getOracle(bytes32 _marketId) external view returns (address);
>>  993 |     function getPositionId(bytes32 _questionId, bool _outcome) external view returns (uint256);
    994 |     function getQuestionCount(bytes32 _marketId) external view returns (uint256);
    995 |     function getResult(bytes32 _marketId) external view returns (uint256);
    996 |     function mergePositions(
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 994 行
- **函数**: `getQuestionCount()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    991 |     function getMarketData(bytes32 _marketId) external view returns (MarketData);
    992 |     function getOracle(bytes32 _marketId) external view returns (address);
    993 |     function getPositionId(bytes32 _questionId, bool _outcome) external view returns (uint256);
>>  994 |     function getQuestionCount(bytes32 _marketId) external view returns (uint256);
    995 |     function getResult(bytes32 _marketId) external view returns (uint256);
    996 |     function mergePositions(
    997 |         address _collateralToken,
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 995 行
- **函数**: `getResult()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    992 |     function getOracle(bytes32 _marketId) external view returns (address);
    993 |     function getPositionId(bytes32 _questionId, bool _outcome) external view returns (uint256);
    994 |     function getQuestionCount(bytes32 _marketId) external view returns (uint256);
>>  995 |     function getResult(bytes32 _marketId) external view returns (uint256);
    996 |     function mergePositions(
    997 |         address _collateralToken,
    998 |         bytes32,
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1011 行
- **函数**: `onERC1155Received()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1008 |         uint256[] memory,
   1009 |         bytes memory
   1010 |     ) external returns (bytes4);
>> 1011 |     function onERC1155Received(address, address, uint256, uint256, bytes memory) external returns (bytes4);
   1012 |     function prepareMarket(uint256 _feeBips, bytes memory _metadata) external returns (bytes32);
   1013 |     function prepareQuestion(bytes32 _marketId, bytes memory _metadata) external returns (bytes32);
   1014 |     function redeemPositions(bytes32 _conditionId, uint256[] memory _amounts) external;
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1012 行
- **函数**: `prepareMarket()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1009 |         bytes memory
   1010 |     ) external returns (bytes4);
   1011 |     function onERC1155Received(address, address, uint256, uint256, bytes memory) external returns (bytes4);
>> 1012 |     function prepareMarket(uint256 _feeBips, bytes memory _metadata) external returns (bytes32);
   1013 |     function prepareQuestion(bytes32 _marketId, bytes memory _metadata) external returns (bytes32);
   1014 |     function redeemPositions(bytes32 _conditionId, uint256[] memory _amounts) external;
   1015 |     function reportOutcome(bytes32 _questionId, bool _outcome) external;
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1013 行
- **函数**: `prepareQuestion()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1010 |     ) external returns (bytes4);
   1011 |     function onERC1155Received(address, address, uint256, uint256, bytes memory) external returns (bytes4);
   1012 |     function prepareMarket(uint256 _feeBips, bytes memory _metadata) external returns (bytes32);
>> 1013 |     function prepareQuestion(bytes32 _marketId, bytes memory _metadata) external returns (bytes32);
   1014 |     function redeemPositions(bytes32 _conditionId, uint256[] memory _amounts) external;
   1015 |     function reportOutcome(bytes32 _questionId, bool _outcome) external;
   1016 |     function safeTransferFrom(address _from, address _to, uint256 _id, uint256 _value, bytes memory _data) external;
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1025 行
- **函数**: `vault()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1022 |         uint256 _amount
   1023 |     ) external;
   1024 |     function splitPosition(bytes32 _conditionId, uint256 _amount) external;
>> 1025 |     function vault() external view returns (address);
   1026 |     function wcol() external view returns (address);
   1027 | }
   1028 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1026 行
- **函数**: `wcol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1023 |     ) external;
   1024 |     function splitPosition(bytes32 _conditionId, uint256 _amount) external;
   1025 |     function vault() external view returns (address);
>> 1026 |     function wcol() external view returns (address);
   1027 | }
   1028 | 
   1029 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1519 行
- **函数**: `hasRole()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1516 |     /**
   1517 |      * @dev Returns `true` if `account` has been granted `role`.
   1518 |      */
>> 1519 |     function hasRole(bytes32 role, address account) external view returns (bool);
   1520 | 
   1521 |     /**
   1522 |      * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1527 行
- **函数**: `getRoleAdmin()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1524 |      *
   1525 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
   1526 |      */
>> 1527 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
   1528 | 
   1529 |     /**
   1530 |      * @dev Grants `role` to `account`.
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1627 行
- **函数**: `supportsInterface()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1624 |     /**
   1625 |      * @dev See {IERC165-supportsInterface}.
   1626 |      */
>> 1627 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   1628 |         return interfaceId == type(IERC165).interfaceId;
   1629 |     }
   1630 | }
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1717 行
- **函数**: `nonces()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1714 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   1715 |      * prevents a signature from being used multiple times.
   1716 |      */
>> 1717 |     function nonces(address owner) external view returns (uint256);
   1718 | 
   1719 |     /**
   1720 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1723 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1720 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
   1721 |      */
   1722 |     // solhint-disable-next-line func-name-mixedcase
>> 1723 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1724 | }
   1725 | 
   1726 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 2006 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2003 |      *
   2004 |      * - `account` cannot be the zero address.
   2005 |      */
>> 2006 |     function balanceOf(address account, uint256 id) external view returns (uint256);
   2007 | 
   2008 |     /**
   2009 |      * @dev xref:ROOT:erc1155.adoc#batch-operations[Batched] version of {balanceOf}.
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 2036 行
- **函数**: `isApprovedForAll()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2033 |      *
   2034 |      * See {setApprovalForAll}.
   2035 |      */
>> 2036 |     function isApprovedForAll(address account, address operator) external view returns (bool);
   2037 | 
   2038 |     /**
   2039 |      * @dev Transfers a `value` amount of tokens of type `id` from `from` to `to`.
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 2109 行
- **函数**: `supportsInterface()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2106 |      *
   2107 |      * This function call must use less than 30 000 gas.
   2108 |      */
>> 2109 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   2110 | }
   2111 | 
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 18 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     13 | import {CTHelpers} from "./ConditionalTokens/CTHelpers.sol";
     14 | 
     15 | /**
     16 |  * @title CTFAutoRedemptionHelper
     17 |  * @author predict.fun protocol team
>>   18 |  * @notice This contract is used to auto-redeem user positions for users that have granted permission to the contract
     19 |  */
     20 | contract CTFAutoRedemptionHelper is AccessControl, ERC1155Holder {
     21 |     using SafeERC20 for IERC20;
     22 | 
     23 |     /// @notice Role allowed to redeem positions
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 445 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    440 |  * WARNING: The `DEFAULT_ADMIN_ROLE` is also its own admin: it has permission to
    441 |  * grant and revoke this role. Extra precautions should be taken to secure
    442 |  * accounts that have been granted it. We recommend using {AccessControlDefaultAdminRules}
    443 |  * to enforce additional security measures for this role.
    444 |  */
>>  445 | abstract contract AccessControl is Context, IAccessControl, ERC165 {
    446 |     struct RoleData {
    447 |         mapping(address account => bool) hasRole;
    448 |         bytes32 adminRole;
    449 |     }
    450 | 
```

---

### 51. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 705 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    700 | import {Address} from "../../../utils/Address.sol";
    701 | 
    702 | /**
    703 |  * @title SafeERC20
    704 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>>  705 |  * contract returns false). Tokens that return no value (and instead revert or
    706 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    707 |  * successful.
    708 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    709 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    710 |  */
```

---

### 52. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 884 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    879 |     /// @dev Called by the oracle for reporting results of conditions. Will set the payout vector for the condition with the ID ``keccak256(abi.encodePacked(oracle, questionId, outcomeSlotCount))``, where oracle is the message sender, questionId is one of the parameters of this function, and outcomeSlotCount is the length of the payouts parameter, which contains the payoutNumerators for each outcome slot of the condition.
    880 |     /// @param questionId The question ID the oracle is answering for
    881 |     /// @param payouts The oracle's answer
    882 |     function reportPayouts(bytes32 questionId, uint256[] calldata payouts) external;
    883 | 
>>  884 |     /// @dev This function splits a position. If splitting from the collateral, this contract will attempt to transfer `amount` collateral from the message sender to itself. Otherwise, this contract will burn `amount` stake held by the message sender in the position being split worth of EIP 1155 tokens. Regardless, if successful, `amount` stake will be minted in the split target positions. If any of the transfers, mints, or burns fail, the transaction will revert. The transaction will also revert if the given partition is trivial, invalid, or refers to more slots than the condition is prepared with.
    885 |     /// @param collateralToken The address of the positions' backing collateral token.
    886 |     /// @param parentCollectionId The ID of the outcome collections common to the position being split and the split target positions. May be null, in which only the collateral is shared.
    887 |     /// @param conditionId The ID of the condition to split on.
    888 |     /// @param partition An array of disjoint index sets representing a nontrivial partition of the outcome slots of the given condition. E.g. A|B and C but not A|B and B|C (is not disjoint). Each element's a number which, together with the condition, represents the outcome collection. E.g. 0b110 is A|B, 0b010 is B, etc.
    889 |     /// @param amount The amount of collateral or stake to split.
```

---

### 53. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1052 行
- **函数**: `sqrt()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1049 |     function sqrt(uint x) private pure returns (uint y) {
   1050 |         uint p = P;
   1051 |         // solium-disable-next-line security/no-inline-assembly
>> 1052 |         assembly {
   1053 |             // add chain generated via https://crypto.stackexchange.com/q/27179/71252
   1054 |             // and transformed to the following program:
   1055 | 
```

---

### 54. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xfca64d34859b120C36426D41f941E708EA47CBec` 第 1879 行
- **函数**: `_revert()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1876 |         if (returndata.length > 0) {
   1877 |             // The easiest way to bubble the revert reason is using memory via assembly
   1878 |             /// @solidity memory-safe-assembly
>> 1879 |             assembly {
   1880 |                 let returndata_size := mload(returndata)
   1881 |                 revert(add(32, returndata), returndata_size)
   1882 |             }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*