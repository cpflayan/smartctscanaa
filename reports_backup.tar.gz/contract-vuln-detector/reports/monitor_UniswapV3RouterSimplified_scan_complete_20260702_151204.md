# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:12:04
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` |
| contract_name | `UniswapV3RouterSimplified` |
| compiler_version | `v0.8.0+commit.c7dfd78e` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['routerv3.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655009` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 33 |
| 🟢 LOW | 7 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] arbitrary-send-erc20

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_x9_4sdr0/0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb.sol` 第 397 行
- **函数**: `_pay()`
- **扫描工具**: slither
- **综合评分**: 0.725

**工具描述**: UniswapV3RouterSimplified._pay(address,address,address,uint256) (../../../tmp/slither_scan_x9_4sdr0/0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb.sol#397-412) uses arbitrary from in transferFrom: TransferHelper.safeTransferFrom(token,payer,recipient,value) (../../../tmp/slither_scan_x9_4sdr0/0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb.sol#410)

**代码片段**:
```solidity
    394 |         require(pool != address(0), "UniswapV3Router: POOL_NOT_EXISTS");
    395 |     }
    396 | 
>>  397 |     function _pay(address token, address payer, address recipient, uint256 value) internal {
    398 |         if (token == WETH9 && address(this).balance >= value) {
    399 |             // ETH input: deposit ETH to WETH and transfer to recipient
    400 |             TransferHelper.safeWETHDeposit(WETH9, value);
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 1016 行
- **函数**: `multicall()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1013 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results) {
   1014 |         results = new bytes[](data.length);
   1015 |         for (uint256 i = 0; i < data.length; i++) {
>> 1016 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
   1017 | 
   1018 |             if (!success) {
   1019 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
```

---

### 3. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 65 行
- **函数**: `safeTransfer()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
     62 | 
     63 | library TransferHelper {
     64 |     function safeTransfer(address token, address to, uint256 value) internal {
>>   65 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transfer.selector, to, value));
     66 |         require(success && (data.length == 0 || abi.decode(data, (bool))), "TransferHelper: TRANSFER_FAILED");
     67 |     }
     68 | 
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 70 行
- **函数**: `safeTransferFrom()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
     67 |     }
     68 | 
     69 |     function safeTransferFrom(address token, address from, address to, uint256 value) internal {
>>   70 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.transferFrom.selector, from, to, value));
     71 |         require(success && (data.length == 0 || abi.decode(data, (bool))), "TransferHelper: TRANSFER_FROM_FAILED");
     72 |     }
     73 | 
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 75 行
- **函数**: `safeTransferETH()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     72 |     }
     73 | 
     74 |     function safeTransferETH(address to, uint256 value) internal {
>>   75 |         (bool success,) = to.call{value: value}(new bytes(0));
     76 |         require(success, "TransferHelper: ETH_TRANSFER_FAILED");
     77 |     }
     78 | 
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 80 行
- **函数**: `safeApprove()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
     77 |     }
     78 | 
     79 |     function safeApprove(address token, address spender, uint256 value) internal {
>>   80 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(IERC20.approve.selector, spender, value));
     81 |         require(success && (data.length == 0 || abi.decode(data, (bool))), "TransferHelper: APPROVE_FAILED");
     82 |     }
     83 | 
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 85 行
- **函数**: `safeWETHDeposit()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     82 |     }
     83 | 
     84 |     function safeWETHDeposit(address weth, uint256 value) internal {
>>   85 |         (bool success,) = weth.call{value: value}(abi.encodeWithSelector(IWETH.deposit.selector));
     86 |         require(success, "TransferHelper: WETH_DEPOSIT_FAILED");
     87 |     }
     88 | 
```

---

### 8. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 90 行
- **函数**: `safeWETHWithdraw()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
     87 |     }
     88 | 
     89 |     function safeWETHWithdraw(address weth, uint256 value) internal {
>>   90 |         (bool success,) = weth.call(abi.encodeWithSelector(IWETH.withdraw.selector, value));
     91 |         require(success, "TransferHelper: WETH_WITHDRAW_FAILED");
     92 |     }
     93 | 
```

---

### 9. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 95 行
- **函数**: `safeWETHTransfer()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
     92 |     }
     93 | 
     94 |     function safeWETHTransfer(address weth, address to, uint256 value) internal {
>>   95 |         (bool success, bytes memory data) = weth.call(abi.encodeWithSelector(IWETH.transfer.selector, to, value));
     96 |         require(success && (data.length == 0 || abi.decode(data, (bool))), "TransferHelper: WETH_TRANSFER_FAILED");
     97 |     }
     98 | }
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 9 行
- **函数**: `totalSupply()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      6 | // ============ Interfaces ============
      7 | 
      8 | interface IERC20 {
>>    9 |     function totalSupply() external view returns (uint256);
     10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address to, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 10 行
- **函数**: `balanceOf()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      7 | 
      8 | interface IERC20 {
      9 |     function totalSupply() external view returns (uint256);
>>   10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address to, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 11 行
- **函数**: `transfer()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      8 | interface IERC20 {
      9 |     function totalSupply() external view returns (uint256);
     10 |     function balanceOf(address account) external view returns (uint256);
>>   11 |     function transfer(address to, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
     14 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 12 行
- **函数**: `allowance()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      9 |     function totalSupply() external view returns (uint256);
     10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address to, uint256 amount) external returns (bool);
>>   12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
     14 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
     15 | }
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 13 行
- **函数**: `approve()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address to, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
>>   13 |     function approve(address spender, uint256 amount) external returns (bool);
     14 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
     15 | }
     16 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 14 行
- **函数**: `transferFrom()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     11 |     function transfer(address to, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
>>   14 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
     15 | }
     16 | 
     17 | interface IWETH {
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 18 行
- **函数**: `deposit()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     15 | }
     16 | 
     17 | interface IWETH {
>>   18 |     function deposit() external payable;
     19 |     function withdraw(uint256) external;
     20 |     function transfer(address to, uint256 value) external returns (bool);
     21 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 20 行
- **函数**: `transfer()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     17 | interface IWETH {
     18 |     function deposit() external payable;
     19 |     function withdraw(uint256) external;
>>   20 |     function transfer(address to, uint256 value) external returns (bool);
     21 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
     22 |     function balanceOf(address account) external view returns (uint256);
     23 |     function approve(address spender, uint256 value) external returns (bool);
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 21 行
- **函数**: `transferFrom()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     18 |     function deposit() external payable;
     19 |     function withdraw(uint256) external;
     20 |     function transfer(address to, uint256 value) external returns (bool);
>>   21 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
     22 |     function balanceOf(address account) external view returns (uint256);
     23 |     function approve(address spender, uint256 value) external returns (bool);
     24 | }
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 22 行
- **函数**: `balanceOf()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     19 |     function withdraw(uint256) external;
     20 |     function transfer(address to, uint256 value) external returns (bool);
     21 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
>>   22 |     function balanceOf(address account) external view returns (uint256);
     23 |     function approve(address spender, uint256 value) external returns (bool);
     24 | }
     25 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 23 行
- **函数**: `approve()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     20 |     function transfer(address to, uint256 value) external returns (bool);
     21 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
     22 |     function balanceOf(address account) external view returns (uint256);
>>   23 |     function approve(address spender, uint256 value) external returns (bool);
     24 | }
     25 | 
     26 | interface IUniswapV3Factory {
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 27 行
- **函数**: `getPool()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     24 | }
     25 | 
     26 | interface IUniswapV3Factory {
>>   27 |     function getPool(address tokenA, address tokenB, uint24 fee) external view returns (address pool);
     28 | }
     29 | 
     30 | interface IUniswapV3Pool {
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 31 行
- **函数**: `token0()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     28 | }
     29 | 
     30 | interface IUniswapV3Pool {
>>   31 |     function token0() external view returns (address);
     32 |     function token1() external view returns (address);
     33 |     function fee() external view returns (uint24);
     34 |     function swap(
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 32 行
- **函数**: `token1()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     29 | 
     30 | interface IUniswapV3Pool {
     31 |     function token0() external view returns (address);
>>   32 |     function token1() external view returns (address);
     33 |     function fee() external view returns (uint24);
     34 |     function swap(
     35 |         address recipient,
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 33 行
- **函数**: `fee()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     30 | interface IUniswapV3Pool {
     31 |     function token0() external view returns (address);
     32 |     function token1() external view returns (address);
>>   33 |     function fee() external view returns (uint24);
     34 |     function swap(
     35 |         address recipient,
     36 |         bool zeroForOne,
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 324 行
- **函数**: `getStableCoins()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    321 |         emit StableCoinRemoved(_stableCoin);
    322 |     }
    323 | 
>>  324 |     function getStableCoins() external view returns (address[] memory) {
    325 |         return stableCoins;
    326 |     }
    327 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 514 行
- **函数**: `exactInputSingle()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    511 |     // ============ Single Swap Functions ============
    512 | 
    513 |     /// @notice Swaps amountIn of one token for as much as possible of another token
>>  514 |     function exactInputSingle(ExactInputSingleParams calldata params) external payable ensure(params.deadline) returns (uint256 amountOut) {
    515 |         SwapContext memory ctx = _initSwapContext(params.tokenIn, params.tokenOut, params.amountIn);
    516 |         bool isETHInput = ctx.tokenIn == WETH9 && msg.value > 0;
    517 |         bool isETHOutput = ctx.tokenOut == WETH9;
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 601 行
- **函数**: `exactOutputSingle()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    598 |     }
    599 | 
    600 |     /// @notice Swaps as little as possible of one token for amountOut of another token
>>  601 |     function exactOutputSingle(ExactOutputSingleParams calldata params) external payable ensure(params.deadline) returns (uint256 amountIn) {
    602 |         SwapContext memory ctx = _initSwapContext(params.tokenIn, params.tokenOut, 0);
    603 |         bool isETHInput = ctx.tokenIn == WETH9 && msg.value > 0;
    604 |         bool isETHOutput = ctx.tokenOut == WETH9;
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 702 行
- **函数**: `exactInput()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    699 |     // ============ Multi-hop Swap Functions ============
    700 | 
    701 |     /// @notice Swaps amountIn of one token for as much as possible of another along the specified path
>>  702 |     function exactInput(ExactInputParams calldata params) external payable ensure(params.deadline) returns (uint256 amountOut) {
    703 |         (address tokenIn,,) = params.path.decodeFirstPool();
    704 |         SwapContext memory ctx = _initSwapContext(tokenIn, _getLastToken(params.path), params.amountIn);
    705 |         bool isETHInput = ctx.tokenIn == WETH9 && msg.value > 0;
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 756 行
- **函数**: `exactOutput()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    753 |     }
    754 | 
    755 |     /// @notice Swaps as little as possible of one token for amountOut of another along the specified path (reversed)
>>  756 |     function exactOutput(ExactOutputParams calldata params) external payable ensure(params.deadline) returns (uint256 amountIn) {
    757 |         // Note: For exactOutput, path is encoded in reverse order (output to input)
    758 |         (address tokenOut,,) = params.path.decodeFirstPool();
    759 |         SwapContext memory ctx = _initSwapContext(_getLastToken(params.path), tokenOut, 0);
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 982 行
- **函数**: `unwrapWETH9()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    979 |     // ============ Utility Functions ============
    980 | 
    981 |     /// @notice Unwraps WETH9 to ETH and sends to recipient
>>  982 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external {
    983 |         uint256 balance = IWETH(WETH9).balanceOf(address(this));
    984 |         require(balance >= amountMinimum, "UniswapV3Router: INSUFFICIENT_WETH9");
    985 |         if (balance > 0) {
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 992 行
- **函数**: `refundETH()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    989 |     }
    990 | 
    991 |     /// @notice Refunds any ETH balance to the caller
>>  992 |     function refundETH() external {
    993 |         if (address(this).balance > 0) {
    994 |             TransferHelper.safeTransferETH(msg.sender, address(this).balance);
    995 |         }
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 999 行
- **函数**: `sweepToken()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    996 |     }
    997 | 
    998 |     /// @notice Sweeps tokens to recipient
>>  999 |     function sweepToken(address token, uint256 amountMinimum, address recipient) external {
   1000 |         uint256 balance = IERC20(token).balanceOf(address(this));
   1001 |         require(balance >= amountMinimum, "UniswapV3Router: INSUFFICIENT_TOKEN");
   1002 |         if (balance > 0) {
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 1013 行
- **函数**: `multicall()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1010 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   1011 |     /// @param data The encoded function data for each of the calls to make to this contract
   1012 |     /// @return results The results from each of the calls passed in via data
>> 1013 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results) {
   1014 |         results = new bytes[](data.length);
   1015 |         for (uint256 i = 0; i < data.length; i++) {
   1016 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
```

---

### 34. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 168 行
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    163 |     }
    164 | }
    165 | 
    166 | // ============ Main Contract ============
    167 | 
>>  168 | contract UniswapV3RouterSimplified is IUniswapV3SwapCallback, IPancakeV3SwapCallback {
    169 |     using Path for bytes;
    170 | 
    171 |     // ============ Structs ============
    172 | 
    173 |     /// @dev Struct to reduce stack depth in swap functions
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 1009 行
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1004 |         }
   1005 |     }
   1006 | 
   1007 |     // ============ Multicall ============
   1008 | 
>> 1009 |     /// @notice Call multiple functions in the current contract and return the data from all of them if they all succeed
   1010 |     /// @dev The `msg.value` should not be trusted for any method callable from multicall.
   1011 |     /// @param data The encoded function data for each of the calls to make to this contract
   1012 |     /// @return results The results from each of the calls passed in via data
   1013 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results) {
   1014 |         results = new bytes[](data.length);
```

---

### 36. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_x9_4sdr0/0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb.sol` 第 272 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: UniswapV3RouterSimplified.constructor(address,address)._WETH9 (../../../tmp/slither_scan_x9_4sdr0/0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb.sol#272) lacks a zero-check on :
		- WETH9 = _WETH9 (../../../tmp/slither_scan_x9_4sdr0/0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb.sol#274)

**代码片段**:
```solidity
    269 | 
    270 |     // ============ Constructor ============
    271 | 
>>  272 |     constructor(address _factory, address _WETH9) {
    273 |         factory = _factory;
    274 |         WETH9 = _WETH9;
    275 |         owner = msg.sender;
```

---

### 37. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_x9_4sdr0/0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb.sol` 第 272 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: UniswapV3RouterSimplified.constructor(address,address)._factory (../../../tmp/slither_scan_x9_4sdr0/0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb.sol#272) lacks a zero-check on :
		- factory = _factory (../../../tmp/slither_scan_x9_4sdr0/0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb.sol#273)

**代码片段**:
```solidity
    269 | 
    270 |     // ============ Constructor ============
    271 | 
>>  272 |     constructor(address _factory, address _WETH9) {
    273 |         factory = _factory;
    274 |         WETH9 = _WETH9;
    275 |         owner = msg.sender;
```

---

### 38. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 266 行
- **函数**: `slice()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    263 |     }
    264 | 
    265 |     modifier ensure(uint256 deadline) {
>>  266 |         require(deadline >= block.timestamp, "UniswapV3Router: EXPIRED");
    267 |         _;
    268 |     }
    269 | 
```

---

### 39. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 135 行
- **函数**: `toAddress()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    132 |     function toAddress(bytes memory _bytes, uint256 _start) internal pure returns (address) {
    133 |         require(_bytes.length >= _start + 20, "toAddress_outOfBounds");
    134 |         address tempAddress;
>>  135 |         assembly { tempAddress := div(mload(add(add(_bytes, 0x20), _start)), 0x1000000000000000000000000) }
    136 |         return tempAddress;
    137 |     }
    138 | 
```

---

### 40. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 142 行
- **函数**: `toUint24()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    139 |     function toUint24(bytes memory _bytes, uint256 _start) internal pure returns (uint24) {
    140 |         require(_bytes.length >= _start + 3, "toUint24_outOfBounds");
    141 |         uint24 tempUint;
>>  142 |         assembly { tempUint := mload(add(add(_bytes, 0x3), _start)) }
    143 |         return tempUint;
    144 |     }
    145 | 
```

---

### 41. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 149 行
- **函数**: `slice()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    146 |     function slice(bytes memory _bytes, uint256 _start, uint256 _length) internal pure returns (bytes memory) {
    147 |         require(_bytes.length >= _start + _length, "slice_outOfBounds");
    148 |         bytes memory tempBytes;
>>  149 |         assembly {
    150 |             switch iszero(_length)
    151 |             case 0 {
    152 |                 tempBytes := mload(0x40)
```

---

### 42. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xBf92Bc3c54Df6C159Db95FAb69873B4Bd35EfFBb` 第 1021 行
- **函数**: `multicall()`
- **合约**: `UniswapV3RouterSimplified`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1018 |             if (!success) {
   1019 |                 // Next 5 lines from https://ethereum.stackexchange.com/a/83577
   1020 |                 if (result.length < 68) revert("UniswapV3Router: MULTICALL_FAILED");
>> 1021 |                 assembly {
   1022 |                     result := add(result, 0x04)
   1023 |                 }
   1024 |                 revert(abi.decode(result, (string)));
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*