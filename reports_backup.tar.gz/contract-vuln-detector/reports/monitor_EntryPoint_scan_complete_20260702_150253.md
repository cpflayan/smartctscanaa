# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:02:53
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` |
| contract_name | `EntryPoint` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `True` |
| runs | `1000000` |
| evm_version | `cancun` |
| license_type | `GNU GPLv3` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/interfaces/IERC5267.sol', '@openzeppelin/contracts/utils/cryptography/EIP712.sol', '@openzeppelin/contracts/utils/cryptography/MessageHashUtils.sol', '@openzeppelin/contracts/utils/introspection/ERC165.sol', '@openzeppelin/contracts/utils/introspection/IERC165.sol', '@openzeppelin/contracts/utils/math/Math.sol', '@openzeppelin/contracts/utils/math/SafeCast.sol', '@openzeppelin/contracts/utils/math/SignedMath.sol', '@openzeppelin/contracts/utils/Panic.sol', '@openzeppelin/contracts/utils/ReentrancyGuardTransient.sol', '@openzeppelin/contracts/utils/ShortStrings.sol', '@openzeppelin/contracts/utils/StorageSlot.sol', '@openzeppelin/contracts/utils/Strings.sol', '@openzeppelin/contracts/utils/TransientSlot.sol', 'contracts/core/Eip7702Support.sol', 'contracts/core/EntryPoint.sol', 'contracts/core/Helpers.sol', 'contracts/core/NonceManager.sol', 'contracts/core/SenderCreator.sol', 'contracts/core/StakeManager.sol', 'contracts/core/UserOperationLib.sol', 'contracts/interfaces/IAccount.sol', 'contracts/interfaces/IAccountExecute.sol', 'contracts/interfaces/IAggregator.sol', 'contracts/interfaces/IEntryPoint.sol', 'contracts/interfaces/INonceManager.sol', 'contracts/interfaces/IPaymaster.sol', 'contracts/interfaces/ISenderCreator.sol', 'contracts/interfaces/IStakeManager.sol', 'contracts/interfaces/PackedUserOperation.sol', 'contracts/utils/Exec.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655006` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 36 |
| 🟢 LOW | 7 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3225 行
- **函数**: `delegateAndRevert()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   3222 | 
   3223 |     /// @inheritdoc IEntryPoint
   3224 |     function delegateAndRevert(address target, bytes calldata data) external {
>> 3225 |         (bool success, bytes memory ret) = target.delegatecall(data);
   3226 |         revert DelegateAndRevert(success, ret);
   3227 |     }
   3228 | 
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 5228 行
- **函数**: `delegateCall()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   5225 |         uint256 txGas
   5226 |     ) internal returns (bool success) {
   5227 |         assembly ("memory-safe") {
>> 5228 |             success := delegatecall(txGas, to, add(data, 0x20), mload(data), 0, 0)
   5229 |         }
   5230 |     }
   5231 | 
```

---

### 3. 🟡 [MEDIUM] default-visibility

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4152 行
- **函数**: `finalize_allocation()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 函数未声明可见性修饰符（默认 public），可能导致意外暴露。

**代码片段**:
```solidity
   4149 |         assembly ("memory-safe"){
   4150 |             finalize_allocation(memPointer, allocationSize)
   4151 | 
>> 4152 |             function finalize_allocation(memPtr, size) {
   4153 |                 let newFreePtr := add(memPtr, round_up_to_mul_of_32(size))
   4154 |                 mstore(64, newFreePtr)
   4155 |             }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3254 行
- **函数**: `_compensate()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   3251 |      */
   3252 |     function _compensate(address payable beneficiary, uint256 amount) internal virtual {
   3253 |         require(beneficiary != address(0), "AA90 invalid beneficiary");
>> 3254 |         (bool success,) = beneficiary.call{value: amount}("");
   3255 |         require(success, "AA91 failed send to beneficiary");
   3256 |     }
   3257 | 
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3467 行
- **函数**: `innerHandleOp()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   3464 | 
   3465 |         IPaymaster.PostOpMode mode = IPaymaster.PostOpMode.opSucceeded;
   3466 |         if (callData.length > 0) {
>> 3467 |             bool success = Exec.call(mUserOp.sender, 0, callData, callGasLimit);
   3468 |             if (!success) {
   3469 |                 uint256 freePtr = _getFreePtr();
   3470 |                 bytes memory result = Exec.getReturnData(REVERT_REASON_MAX_LEN);
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4421 行
- **函数**: `withdrawStake()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   4418 |         info.withdrawTime = 0;
   4419 |         info.stake = 0;
   4420 |         emit StakeWithdrawn(msg.sender, withdrawAddress, stake);
>> 4421 |         (bool success,) = withdrawAddress.call{value: stake}("");
   4422 |         require(success, "failed to withdraw stake");
   4423 |     }
   4424 | 
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4435 行
- **函数**: `withdrawTo()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   4432 |         require(withdrawAmount <= currentDeposit, "Withdraw amount too large");
   4433 |         info.deposit = currentDeposit - withdrawAmount;
   4434 |         emit Withdrawn(msg.sender, withdrawAddress, withdrawAmount);
>> 4435 |         (bool success,) = withdrawAddress.call{value: withdrawAmount}("");
   4436 |         require(success, "failed to withdraw");
   4437 |     }
   4438 | }
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 310 行
- **函数**: `supportsInterface()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    307 |     /**
    308 |      * @dev See {IERC165-supportsInterface}.
    309 |      */
>>  310 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
    311 |         return interfaceId == type(IERC165).interfaceId;
    312 |     }
    313 | }
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 341 行
- **函数**: `supportsInterface()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    338 |      *
    339 |      * This function call must use less than 30 000 gas.
    340 |      */
>>  341 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
    342 | }
    343 | 
    344 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3213 行
- **函数**: `getSenderAddress()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3210 |     }
   3211 | 
   3212 |     /// @inheritdoc IEntryPoint
>> 3213 |     function getSenderAddress(bytes calldata initCode) external {
   3214 |         address sender = senderCreator().createSender(initCode);
   3215 |         revert SenderAddressResult(sender);
   3216 |     }
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3219 行
- **函数**: `senderCreator()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3216 |     }
   3217 | 
   3218 |     /// @inheritdoc IEntryPoint
>> 3219 |     function senderCreator() public view virtual returns (ISenderCreator) {
   3220 |         return _senderCreator;
   3221 |     }
   3222 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3224 行
- **函数**: `delegateAndRevert()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3221 |     }
   3222 | 
   3223 |     /// @inheritdoc IEntryPoint
>> 3224 |     function delegateAndRevert(address target, bytes calldata data) external {
   3225 |         (bool success, bytes memory ret) = target.delegatecall(data);
   3226 |         revert DelegateAndRevert(success, ret);
   3227 |     }
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3229 行
- **函数**: `getPackedUserOpTypeHash()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3226 |         revert DelegateAndRevert(success, ret);
   3227 |     }
   3228 | 
>> 3229 |     function getPackedUserOpTypeHash() external pure returns (bytes32) {
   3230 |         return UserOperationLib.PACKED_USEROP_TYPEHASH;
   3231 |     }
   3232 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3233 行
- **函数**: `getDomainSeparatorV4()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3230 |         return UserOperationLib.PACKED_USEROP_TYPEHASH;
   3231 |     }
   3232 | 
>> 3233 |     function getDomainSeparatorV4() public virtual view returns (bytes32) {
   3234 |         return _domainSeparatorV4();
   3235 |     }
   3236 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3238 行
- **函数**: `supportsInterface()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3235 |     }
   3236 | 
   3237 |     /// @inheritdoc IERC165
>> 3238 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
   3239 |         // note: solidity "type(IEntryPoint).interfaceId" is without inherited methods but we want to check everything
   3240 |         return interfaceId == (type(IEntryPoint).interfaceId ^ type(IStakeManager).interfaceId ^ type(INonceManager).interfaceId) ||
   3241 |         interfaceId == type(IEntryPoint).interfaceId ||
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4188 行
- **函数**: `incrementNonce()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4185 |     }
   4186 | 
   4187 |     /// @inheritdoc INonceManager
>> 4188 |     function incrementNonce(uint192 key) external override {
   4189 |         nonceSequenceNumber[msg.sender][key]++;
   4190 |     }
   4191 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4327 行
- **函数**: `balanceOf()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4324 |     }
   4325 | 
   4326 |     /// @inheritdoc IStakeManager
>> 4327 |     function balanceOf(address account) public view returns (uint256) {
   4328 |         return deposits[account].deposit;
   4329 |     }
   4330 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4370 行
- **函数**: `depositTo()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4367 |     }
   4368 | 
   4369 |     /// @inheritdoc IStakeManager
>> 4370 |     function depositTo(address account) public virtual payable {
   4371 |         uint256 newDeposit = _incrementDeposit(account, msg.value);
   4372 |         emit Deposited(account, newDeposit);
   4373 |     }
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4376 行
- **函数**: `addStake()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4373 |     }
   4374 | 
   4375 |     /// @inheritdoc IStakeManager
>> 4376 |     function addStake(uint32 unstakeDelaySec) external payable {
   4377 |         DepositInfo storage info = deposits[msg.sender];
   4378 |         require(unstakeDelaySec > 0, "must specify unstake delay");
   4379 |         require(
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4397 行
- **函数**: `unlockStake()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4394 |     }
   4395 | 
   4396 |     /// @inheritdoc IStakeManager
>> 4397 |     function unlockStake() external {
   4398 |         DepositInfo storage info = deposits[msg.sender];
   4399 |         require(info.unstakeDelaySec != 0, "not staked");
   4400 |         require(info.staked, "already unstaking");
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4408 行
- **函数**: `withdrawStake()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4405 |     }
   4406 | 
   4407 |     /// @inheritdoc IStakeManager
>> 4408 |     function withdrawStake(address payable withdrawAddress) external {
   4409 |         DepositInfo storage info = deposits[msg.sender];
   4410 |         uint256 stake = info.stake;
   4411 |         require(stake > 0, "No stake to withdraw");
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4913 行
- **函数**: `senderCreator()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4910 |     /**
   4911 |      * @notice Retrieves the immutable SenderCreator contract which is responsible for deployment of sender contracts.
   4912 |      */
>> 4913 |     function senderCreator() external view returns (ISenderCreator);
   4914 | }
   4915 | 
   4916 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 5028 行
- **函数**: `createSender()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5025 |      * @dev Creates a new sender contract.
   5026 |      * @return sender Address of the newly created sender contract.
   5027 |      */
>> 5028 |     function createSender(bytes calldata initCode) external returns (address sender);
   5029 | 
   5030 |     /**
   5031 |      * Use initCallData to initialize an EIP-7702 account.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 5117 行
- **函数**: `balanceOf()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5114 |      * @param account - The account to query.
   5115 |      * @return        - The deposit (for gas payment) of the account.
   5116 |      */
>> 5117 |     function balanceOf(address account) external view returns (uint256);
   5118 | 
   5119 |     /**
   5120 |      * Add to the deposit of the given account.
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 5123 行
- **函数**: `depositTo()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5120 |      * Add to the deposit of the given account.
   5121 |      * @param account - The account to add to.
   5122 |      */
>> 5123 |     function depositTo(address account) external payable;
   5124 | 
   5125 |     /**
   5126 |      * Add to the account's stake - amount and delay
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 5130 行
- **函数**: `addStake()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5127 |      * any pending unstake is first cancelled.
   5128 |      * @param unstakeDelaySec - The new lock duration before the deposit can be withdrawn.
   5129 |      */
>> 5130 |     function addStake(uint32 unstakeDelaySec) external payable;
   5131 | 
   5132 |     /**
   5133 |      * Attempt to unlock the stake.
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 68 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     63 |  * separator of the implementation contract. This will cause the {_domainSeparatorV4} function to always rebuild the
     64 |  * separator from the immutable values, which is cheaper than accessing a cached version in cold storage.
     65 |  *
     66 |  * @custom:oz-upgrades-unsafe-allow state-variable-immutable
     67 |  */
>>   68 | abstract contract EIP712 is IERC5267 {
     69 |     using ShortStrings for *;
     70 | 
     71 |     bytes32 private constant TYPE_HASH =
     72 |         keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
     73 | 
```

---

### 28. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 660 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    655 |      * Requirements:
    656 |      * - modulus can't be zero
    657 |      * - underlying staticcall to precompile must succeed
    658 |      *
    659 |      * IMPORTANT: The result is only valid if the underlying call succeeds. When using this function, make
>>  660 |      * sure the chain you're using it on supports the precompiled contract for modular exponentiation
    661 |      * at address 0x05 as specified in https://eips.ethereum.org/EIPS/eip-198[EIP-198]. Otherwise,
    662 |      * the underlying function will succeed given the lack of a revert, but the result may be incorrectly
    663 |      * interpreted as 0.
    664 |      */
    665 |     function modExp(uint256 b, uint256 e, uint256 m) internal view returns (uint256) {
```

---

### 29. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 2423 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2418 |  * fallback mechanism can be used for every other case.
   2419 |  *
   2420 |  * Usage example:
   2421 |  *
   2422 |  * ```solidity
>> 2423 |  * contract Named {
   2424 |  *     using ShortStrings for *;
   2425 |  *
   2426 |  *     ShortString private immutable _name;
   2427 |  *     string private _nameFallback;
   2428 |  *
```

---

### 30. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3092 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3087 | /**
   3088 |  * Account-Abstraction (EIP-4337) singleton EntryPoint v0.8 implementation.
   3089 |  * Only one instance required on each chain.
   3090 |  * @custom:security-contact https://bounty.ethereum.org
   3091 |  */
>> 3092 | contract EntryPoint is IEntryPoint, StakeManager, NonceManager, ReentrancyGuardTransient, ERC165, EIP712 {
   3093 | 
   3094 |     using UserOperationLib for PackedUserOperation;
   3095 | 
   3096 |     /**
   3097 |      * internal-use constants
```

---

### 31. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3538 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3533 |             requiredPrefund = requiredGas * mUserOp.maxFeePerGas;
   3534 |         }
   3535 |     }
   3536 | 
   3537 |     /**
>> 3538 |      * Create sender smart contract account if init code is provided.
   3539 |      * @param opIndex  - The operation index.
   3540 |      * @param opInfo   - The operation info.
   3541 |      * @param initCode - The init code for the smart contract account.
   3542 |      */
   3543 |     function _createSenderIfNeeded(
```

---

### 32. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4174 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4169 | import "../interfaces/INonceManager.sol";
   4170 | 
   4171 | /**
   4172 |  * nonce management functionality
   4173 |  */
>> 4174 | abstract contract NonceManager is INonceManager {
   4175 | 
   4176 |     /**
   4177 |      * The next valid sequence number for a given nonce key.
   4178 |      */
   4179 |     mapping(address => mapping(uint192 => uint256)) public nonceSequenceNumber;
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4220 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4215 | import "../interfaces/ISenderCreator.sol";
   4216 | import "../interfaces/IEntryPoint.sol";
   4217 | import "../utils/Exec.sol";
   4218 | 
   4219 | /**
>> 4220 |  * Helper contract for EntryPoint, to call userOp.initCode from a "neutral" address,
   4221 |  * which is explicitly not the entryPoint itself.
   4222 |  */
   4223 | contract SenderCreator is ISenderCreator {
   4224 |     address public immutable entryPoint;
   4225 | 
```

---

### 34. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4303 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4298 | /**
   4299 |  * Manage deposits and stakes.
   4300 |  * Deposit is just a balance used to pay for UserOperations (either by a paymaster or an account).
   4301 |  * Stake is value locked for at least "unstakeDelay" by a paymaster.
   4302 |  */
>> 4303 | abstract contract StakeManager is IStakeManager {
   4304 |     /// maps paymaster to their deposits and stakes
   4305 |     mapping(address => DepositInfo) private deposits;
   4306 | 
   4307 |     /// @inheritdoc IStakeManager
   4308 |     function getDepositInfo(
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4890 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4885 |         bytes paymasterContext;
   4886 |     }
   4887 | 
   4888 |     /**
   4889 |      * Get counterfactual sender address.
>> 4890 |      * Calculate the sender contract address that will be generated by the initCode and salt in the UserOperation.
   4891 |      * This method always revert, and returns the address in SenderAddressResult error.
   4892 |      * @notice this method cannot be used for EIP-7702 derived contracts.
   4893 |      *
   4894 |      * @param initCode - The constructor code to be passed into the UserOperation.
   4895 |      */
```

---

### 36. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 5032 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5027 |      */
   5028 |     function createSender(bytes calldata initCode) external returns (address sender);
   5029 | 
   5030 |     /**
   5031 |      * Use initCallData to initialize an EIP-7702 account.
>> 5032 |      * The caller is the EntryPoint contract and it is already verified to be an EIP-7702 account.
   5033 |      * Note: Can be called multiple times as long as an appropriate initCode is supplied
   5034 |      *
   5035 |      * @param sender - the 'sender' EIP-7702 account to be initialized.
   5036 |      * @param initCallData - the call data to be passed to the sender account call.
   5037 |      */
```

---

### 37. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 5166 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5161 | 
   5162 | /**
   5163 |  * User Operation struct
   5164 |  * @param sender                - The sender account of this request.
   5165 |  * @param nonce                 - Unique value the sender uses to verify it is not a replay.
>> 5166 |  * @param initCode              - If set, the account contract will be created by this constructor
   5167 |  * @param callData              - The method call to execute on this account.
   5168 |  * @param accountGasLimits      - Packed gas limits for validateUserOp and gas limit passed to the callData method call.
   5169 |  * @param preVerificationGas    - Gas not calculated by the handleOps method, but added to the gas paid.
   5170 |  *                                Covers batch overhead.
   5171 |  * @param gasFees               - packed gas fields maxPriorityFeePerGas and maxFeePerGas - Same as EIP-1559 gas parameters.
```

---

### 38. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 5197 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5192 | pragma solidity ^0.8.28;
   5193 | 
   5194 | // solhint-disable no-inline-assembly
   5195 | 
   5196 | /**
>> 5197 |  * Utility functions helpful when making different kinds of contract calls in Solidity.
   5198 |  */
   5199 | library Exec {
   5200 | 
   5201 |     function call(
   5202 |         address to,
```

---

### 39. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 3796 行
- **函数**: `_getValidationData()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   3793 |         }
   3794 |         ValidationData memory data = _parseValidationData(validationData);
   3795 |         // solhint-disable-next-line not-rely-on-time
>> 3796 |         outOfTimeRange = block.timestamp > data.validUntil || block.timestamp <= data.validAfter;
   3797 |         aggregator = data.aggregator;
   3798 |     }
   3799 | 
```

---

### 40. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4401 行
- **函数**: `unlockStake()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4398 |         DepositInfo storage info = deposits[msg.sender];
   4399 |         require(info.unstakeDelaySec != 0, "not staked");
   4400 |         require(info.staked, "already unstaking");
>> 4401 |         uint48 withdrawTime = uint48(block.timestamp) + info.unstakeDelaySec;
   4402 |         info.withdrawTime = withdrawTime;
   4403 |         info.staked = false;
   4404 |         emit StakeUnlocked(msg.sender, withdrawTime);
```

---

### 41. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 4414 行
- **函数**: `withdrawStake()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4411 |         require(stake > 0, "No stake to withdraw");
   4412 |         require(info.withdrawTime > 0, "must call unlockStake() first");
   4413 |         require(
>> 4414 |             info.withdrawTime <= block.timestamp,
   4415 |             "Stake withdrawal is not due"
   4416 |         );
   4417 |         info.unstakeDelaySec = 0;
```

---

### 42. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 2354 行
- **函数**: `panic()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2351 | 
   2352 |     // keccak256(abi.encode(uint256(keccak256("openzeppelin.storage.ReentrancyGuard")) - 1)) & ~bytes32(uint256(0xff))
   2353 |     bytes32 private constant REENTRANCY_GUARD_STORAGE =
>> 2354 |         0x9b779b17422d0df92223018b32b4d1fa46e071723d6817e2486d003becc55f00;
   2355 | 
   2356 |     /**
   2357 |      * @dev Unauthorized reentrant call.
```

---

### 43. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 497 行
- **函数**: `mulDiv()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    494 |             // variables such that product = prod1 * 2²⁵⁶ + prod0.
    495 |             uint256 prod0 = x * y; // Least significant 256 bits of the product
    496 |             uint256 prod1; // Most significant 256 bits of the product
>>  497 |             assembly {
    498 |                 let mm := mulmod(x, y, not(0))
    499 |                 prod1 := sub(sub(mm, prod0), lt(mm, prod0))
    500 |             }
```

---

### 44. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 521 行
- **函数**: `mulDiv()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    518 | 
    519 |             // Make division exact by subtracting the remainder from [prod1 prod0].
    520 |             uint256 remainder;
>>  521 |             assembly {
    522 |                 // Compute remainder using mulmod.
    523 |                 remainder := mulmod(x, y, denominator)
    524 | 
```

---

### 45. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x4337084D9E255Ff0702461CF8895CE9E3b5Ff108` 第 534 行
- **函数**: `mulDiv()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    531 |             // Always >= 1. See https://cs.stackexchange.com/q/138556/92363.
    532 | 
    533 |             uint256 twos = denominator & (0 - denominator);
>>  534 |             assembly {
    535 |                 // Divide denominator by twos.
    536 |                 denominator := div(denominator, twos)
    537 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*