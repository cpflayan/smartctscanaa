# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:04:30
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x56C892D6183D5B6BF2841d030147414FF1621B8b` |
| contract_name | `BuyBurn` |
| compiler_version | `v0.8.9+commit.e5eed63a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `None` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 47 |
| 🟢 LOW | 37 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 881 行
- **函数**: `functionDelegateCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    878 |         bytes memory data,
    879 |         string memory errorMessage
    880 |     ) internal returns (bytes memory) {
>>  881 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    882 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    883 |     }
    884 | 
```

---

### 2. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2035 行
- **函数**: `getClaimablePeriods()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   2032 |         if (burnInfo.lastBurn == 0) {
   2033 |             return 0;
   2034 |         }
>> 2035 |         uint256 timeElapsed = block.timestamp - burnInfo.lastBurn;
   2036 |         uint256 fullPeriods = (timeElapsed + BUFFER_SECONDS) / PERIOD_IN_SECONDS;
   2037 |         return fullPeriods > burnInfo.burnClaimedPeriods
   2038 |             ? fullPeriods - burnInfo.burnClaimedPeriods
```

---

### 3. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2046 行
- **函数**: `checkMinimumTimeElapsed()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   2043 |         BurnInfo memory record = burnInfoMap[user];
   2044 |         require(record.lastBurn != 0, "No burn record");
   2045 | 
>> 2046 |         uint256 elapsed = block.timestamp - record.lastBurn;
   2047 |         require(
   2048 |             elapsed >= PERIOD_IN_SECONDS + BUFFER_SECONDS,
   2049 |             "Please wait until next Beijing Time cycle (00:00 UTC+8)"
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 763 行
- **函数**: `sendValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    760 |     function sendValue(address payable recipient, uint256 amount) internal {
    761 |         require(address(this).balance >= amount, "Address: insufficient balance");
    762 | 
>>  763 |         (bool success, ) = recipient.call{value: amount}("");
    764 |         require(success, "Address: unable to send value, recipient may have reverted");
    765 |     }
    766 | 
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 831 行
- **函数**: `functionCallWithValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    828 |         string memory errorMessage
    829 |     ) internal returns (bytes memory) {
    830 |         require(address(this).balance >= value, "Address: insufficient balance for call");
>>  831 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    832 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    833 |     }
    834 | 
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1081 行
- **函数**: `_callOptionalReturnBool()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1078 |         // we're implementing it ourselves. We cannot use {Address-functionCall} here since this should return false
   1079 |         // and not revert is the subcall reverts.
   1080 | 
>> 1081 |         (bool success, bytes memory returndata) = address(token).call(data);
   1082 |         return
   1083 |             success && (returndata.length == 0 || abi.decode(returndata, (bool))) && Address.isContract(address(token));
   1084 |     }
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 79 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     76 |     /**
     77 |      * @dev Returns the address of the current owner.
     78 |      */
>>   79 |     function owner() public view virtual returns (address) {
     80 |         return _owner;
     81 |     }
     82 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 150 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    147 |     /**
    148 |      * @dev Returns the amount of tokens in existence.
    149 |      */
>>  150 |     function totalSupply() external view returns (uint256);
    151 | 
    152 |     /**
    153 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 155 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    152 |     /**
    153 |      * @dev Returns the amount of tokens owned by `account`.
    154 |      */
>>  155 |     function balanceOf(address account) external view returns (uint256);
    156 | 
    157 |     /**
    158 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 164 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    161 |      *
    162 |      * Emits a {Transfer} event.
    163 |      */
>>  164 |     function transfer(address to, uint256 amount) external returns (bool);
    165 | 
    166 |     /**
    167 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 173 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    170 |      *
    171 |      * This value changes when {approve} or {transferFrom} are called.
    172 |      */
>>  173 |     function allowance(address owner, address spender) external view returns (uint256);
    174 | 
    175 |     /**
    176 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 189 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    186 |      *
    187 |      * Emits an {Approval} event.
    188 |      */
>>  189 |     function approve(address spender, uint256 amount) external returns (bool);
    190 | 
    191 |     /**
    192 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 200 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    197 |      *
    198 |      * Emits a {Transfer} event.
    199 |      */
>>  200 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
    201 | }
    202 | 
    203 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 220 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    217 |     /**
    218 |      * @dev Returns the name of the token.
    219 |      */
>>  220 |     function name() external view returns (string memory);
    221 | 
    222 |     /**
    223 |      * @dev Returns the symbol of the token.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 225 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    222 |     /**
    223 |      * @dev Returns the symbol of the token.
    224 |      */
>>  225 |     function symbol() external view returns (string memory);
    226 | 
    227 |     /**
    228 |      * @dev Returns the decimals places of the token.
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 230 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    227 |     /**
    228 |      * @dev Returns the decimals places of the token.
    229 |      */
>>  230 |     function decimals() external view returns (uint8);
    231 | }
    232 | 
    233 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 295 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    292 |     /**
    293 |      * @dev Returns the name of the token.
    294 |      */
>>  295 |     function name() public view virtual override returns (string memory) {
    296 |         return _name;
    297 |     }
    298 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 303 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    300 |      * @dev Returns the symbol of the token, usually a shorter version of the
    301 |      * name.
    302 |      */
>>  303 |     function symbol() public view virtual override returns (string memory) {
    304 |         return _symbol;
    305 |     }
    306 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 320 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    317 |      * no way affects any of the arithmetic of the contract, including
    318 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    319 |      */
>>  320 |     function decimals() public view virtual override returns (uint8) {
    321 |         return 18;
    322 |     }
    323 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 327 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    324 |     /**
    325 |      * @dev See {IERC20-totalSupply}.
    326 |      */
>>  327 |     function totalSupply() public view virtual override returns (uint256) {
    328 |         return _totalSupply;
    329 |     }
    330 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 334 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    331 |     /**
    332 |      * @dev See {IERC20-balanceOf}.
    333 |      */
>>  334 |     function balanceOf(address account) public view virtual override returns (uint256) {
    335 |         return _balances[account];
    336 |     }
    337 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 346 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    343 |      * - `to` cannot be the zero address.
    344 |      * - the caller must have a balance of at least `amount`.
    345 |      */
>>  346 |     function transfer(address to, uint256 amount) public virtual override returns (bool) {
    347 |         address owner = _msgSender();
    348 |         _transfer(owner, to, amount);
    349 |         return true;
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 355 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    352 |     /**
    353 |      * @dev See {IERC20-allowance}.
    354 |      */
>>  355 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    356 |         return _allowances[owner][spender];
    357 |     }
    358 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 369 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    366 |      *
    367 |      * - `spender` cannot be the zero address.
    368 |      */
>>  369 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    370 |         address owner = _msgSender();
    371 |         _approve(owner, spender, amount);
    372 |         return true;
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 391 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    388 |      * - the caller must have allowance for ``from``'s tokens of at least
    389 |      * `amount`.
    390 |      */
>>  391 |     function transferFrom(address from, address to, uint256 amount) public virtual override returns (bool) {
    392 |         address spender = _msgSender();
    393 |         _spendAllowance(from, spender, amount);
    394 |         _transfer(from, to, amount);
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 410 行
- **函数**: `increaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    407 |      *
    408 |      * - `spender` cannot be the zero address.
    409 |      */
>>  410 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    411 |         address owner = _msgSender();
    412 |         _approve(owner, spender, allowance(owner, spender) + addedValue);
    413 |         return true;
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 430 行
- **函数**: `decreaseAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    427 |      * - `spender` must have allowance for the caller of at least
    428 |      * `subtractedValue`.
    429 |      */
>>  430 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    431 |         address owner = _msgSender();
    432 |         uint256 currentAllowance = allowance(owner, spender);
    433 |         require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 685 行
- **函数**: `nonces()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    682 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
    683 |      * prevents a signature from being used multiple times.
    684 |      */
>>  685 |     function nonces(address owner) external view returns (uint256);
    686 | 
    687 |     /**
    688 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 691 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    688 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
    689 |      */
    690 |     // solhint-disable-next-line func-name-mixedcase
>>  691 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    692 | }
    693 | 
    694 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1656 行
- **函数**: `isCouncilMember()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1653 | 
   1654 | 
   1655 | interface IDrdrCouncil {
>> 1656 |     function isCouncilMember(address) external view returns (bool);
   1657 |     function getAllMembers() external view returns (address[] memory);
   1658 | }
   1659 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1657 行
- **函数**: `getAllMembers()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1654 | 
   1655 | interface IDrdrCouncil {
   1656 |     function isCouncilMember(address) external view returns (bool);
>> 1657 |     function getAllMembers() external view returns (address[] memory);
   1658 | }
   1659 | 
   1660 | // sign base
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1691 行
- **函数**: `setSigners()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1688 |         return size == 0;
   1689 |     }
   1690 | 
>> 1691 |     function setSigners(address[] memory _signers) public onlyCouncil {
   1692 |         require(_signers.length <= 10, "length mismatch"); //max 10
   1693 |         for (uint256 i=0; i<_signers.length;i++){
   1694 |             require(_signers[i] != address(0), "zero address");
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1707 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1704 |     }
   1705 | 
   1706 |     // approve signers change
>> 1707 |     function approve() external onlyCouncil {
   1708 |         require(toChange.length > 0, "nothing to approve");
   1709 |         require(!hasApprovedMap[approveId][msg.sender], "Already approved");
   1710 |         hasApprovedMap[approveId][msg.sender] = true;
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1720 行
- **函数**: `getMessageHash()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1717 |         }
   1718 |     }
   1719 | 
>> 1720 |     function getMessageHash(address sender, address token, uint256 orderId, address newAddr, uint256 deadline, uint256 chainId) public pure returns (bytes32){
   1721 |         return keccak256(abi.encode(sender, token, orderId, newAddr, deadline, chainId));
   1722 |     }
   1723 |     // Generate message hash for signing
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1725 行
- **函数**: `getMessageHash()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1722 |     }
   1723 |     // Generate message hash for signing
   1724 |     // Overloaded version with additional parameters
>> 1725 |     function getMessageHash(address sender, address token, uint256 orderId, uint256 amount, uint256 deadline, uint256 category, uint256 dType, uint256 chainId) public pure returns (bytes32){
   1726 |         return keccak256(abi.encode(sender, token, orderId, amount, deadline, category, dType, chainId));
   1727 |     }
   1728 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1729 行
- **函数**: `toEthSignedMessageHash()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1726 |         return keccak256(abi.encode(sender, token, orderId, amount, deadline, category, dType, chainId));
   1727 |     }
   1728 | 
>> 1729 |     function toEthSignedMessageHash(bytes32 hash) public pure returns (bytes32) {
   1730 |         return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", hash));
   1731 |     }
   1732 |     function recoverSigner(bytes32 _msgHash, bytes memory _signature) public pure returns (address){
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1732 行
- **函数**: `recoverSigner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1729 |     function toEthSignedMessageHash(bytes32 hash) public pure returns (bytes32) {
   1730 |         return keccak256(abi.encodePacked("\x19Ethereum Signed Message:\n32", hash));
   1731 |     }
>> 1732 |     function recoverSigner(bytes32 _msgHash, bytes memory _signature) public pure returns (address){
   1733 |         bytes32 encodeHash = toEthSignedMessageHash(_msgHash);
   1734 |         require(_signature.length == 65, "invalid signature length");
   1735 |         bytes32 r;
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1751 行
- **函数**: `verifyOne()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1748 |         return signer;
   1749 |     }
   1750 | 
>> 1751 |     function verifyOne(bytes32 _msgHash, bytes memory _signature, address _signer) public pure returns (bool) {
   1752 |         return recoverSigner(_msgHash, _signature) == _signer;
   1753 |     }
   1754 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1755 行
- **函数**: `verify()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1752 |         return recoverSigner(_msgHash, _signature) == _signer;
   1753 |     }
   1754 | 
>> 1755 |     function verify(bytes32 _msgHash, bytes[] memory _signatures, address[] memory _signers) public  pure returns (bool) {
   1756 |         require(_signatures.length == _signers.length, "length mismatch");
   1757 |         require(_signatures.length <= 10, "length mismatch"); 
   1758 |         for (uint256 i = 0; i < _signatures.length; i++) {
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2030 行
- **函数**: `getClaimablePeriods()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2027 |     }
   2028 | 
   2029 |     // check
>> 2030 |     function getClaimablePeriods(address user) public view returns (uint256) {
   2031 |         BurnInfo storage burnInfo = burnInfoMap[user];
   2032 |         if (burnInfo.lastBurn == 0) {
   2033 |             return 0;
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2053 行
- **函数**: `verifyParam()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2050 |         );
   2051 |     }
   2052 | 
>> 2053 |     function verifyParam(address sender, address contrt, uint256 orderId, uint256 amount, uint256 deadline, bytes memory signature, address signer) public pure returns (bool){
   2054 |         // check
   2055 |         return verifyOne(getMessageHash(sender, contrt, orderId, amount, deadline, 1018, 1018, 56), signature, signer);
   2056 |     }
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2099 行
- **函数**: `resetAddr()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2096 |         }
   2097 |     }
   2098 |     
>> 2099 |     function resetAddr(address newAddr, uint256 orderId, uint256 deadline, bytes[] memory signatures) external {
   2100 |         // Verify signatures
   2101 |         bool check = verify(getMessageHash(msg.sender, address(this), orderId, newAddr, deadline, block.chainid), signatures, signers);
   2102 |         if (!check) {
```

---

### 43. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 56 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     51 |  *
     52 |  * This module is used through inheritance. It will make available the modifier
     53 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     54 |  * the owner.
     55 |  */
>>   56 | abstract contract Ownable is Context {
     57 |     address private _owner;
     58 | 
     59 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     60 | 
     61 |     /**
```

---

### 44. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 111 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    106 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
    107 |         _transferOwnership(newOwner);
    108 |     }
    109 | 
    110 |     /**
>>  111 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    112 |      * Internal function without access restriction.
    113 |      */
    114 |     function _transferOwnership(address newOwner) internal virtual {
    115 |         address oldOwner = _owner;
    116 |         _owner = newOwner;
```

---

### 45. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 271 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    266 |  *
    267 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    268 |  * functions have been added to mitigate the well-known issues around setting
    269 |  * allowances. See {IERC20-approve}.
    270 |  */
>>  271 | contract ERC20 is Context, IERC20, IERC20Metadata {
    272 |     mapping(address => uint256) private _balances;
    273 | 
    274 |     mapping(address => mapping(address => uint256)) private _allowances;
    275 | 
    276 |     uint256 private _totalSupply;
```

---

### 46. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 955 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    950 | 
    951 | 
    952 | /**
    953 |  * @title SafeERC20
    954 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>>  955 |  * contract returns false). Tokens that return no value (and instead revert or
    956 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    957 |  * successful.
    958 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    959 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    960 |  */
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1661 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1656 |     function isCouncilMember(address) external view returns (bool);
   1657 |     function getAllMembers() external view returns (address[] memory);
   1658 | }
   1659 | 
   1660 | // sign base
>> 1661 | abstract contract BaseSignable {
   1662 |     address[] public signers;
   1663 | 
   1664 |     uint256 public approveId;
   1665 |     uint256 public approvals; //appove num
   1666 |     mapping(uint256 => mapping(address => bool)) public hasApprovedMap;
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1767 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1762 |         }
   1763 |         return true;
   1764 |     }
   1765 | }
   1766 | 
>> 1767 | contract BuyBurn is BaseSignable, ReentrancyGuard, Ownable{
   1768 |     using SafeERC20 for IERC20;
   1769 | 
   1770 |     // 24 hours in seconds (86400)
   1771 |     uint256 public constant PERIOD_IN_SECONDS = 86400;
   1772 |     // Buffer time (e.g., 60 s) to allow some flexibility
```

---

### 49. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1826 行
- **函数**: `newBurn()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1823 |         require(_amount2 > 0,"Wrong token2 amount");
   1824 |         BurnInfo storage burnInfo = burnInfoMap[msg.sender];
   1825 |         burnInfo.user = msg.sender;
>> 1826 |         burnInfo.lastBurn = block.timestamp;
   1827 |         burnInfo.totalBurn += _amount1;
   1828 |         burnInfo.totalProfit += _amount1 * 2;
   1829 |         burnInfo.burnClaimedPeriods = 0;
```

---

### 50. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1854 行
- **函数**: `newBurn()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1851 |         IERC20(buy).safeTransfer(manage, toFd * 15 / 100);
   1852 |         IERC20(buy).safeTransfer(expand, toFd * 25 / 100);
   1853 | 
>> 1854 |         emit NewRecordBurn(msg.sender, _ordId, _amount1, _amount2, block.timestamp);
   1855 |     }
   1856 | 
   1857 |     function claimRank(uint256 orderId, uint256 category, uint256 rewards, uint256 deadline, bytes[] memory signatures) public nonReentrant{
```

---

### 51. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1859 行
- **函数**: `claimRank()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1856 | 
   1857 |     function claimRank(uint256 orderId, uint256 category, uint256 rewards, uint256 deadline, bytes[] memory signatures) public nonReentrant{
   1858 |         require(rewards > 0, "amount error");
>> 1859 |         require(deadline >= block.timestamp, "Invalid deadline");
   1860 |         require(orderClaimed[orderId] == false, "order taked");
   1861 |         BurnInfo storage burnInfo = burnInfoMap[msg.sender];
   1862 |         require(burnInfo.totalBurn > 0, "no burn");
```

---

### 52. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1873 行
- **函数**: `claimRank()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1870 |         require(rank[category-1001] >= rewards, "rank error");
   1871 |         rank[category-1001] -= rewards;
   1872 | 
>> 1873 |         burnInfo.lastClaim = block.timestamp;
   1874 |         uint256 totalClaims = burnInfo.totalClaim + rewards;
   1875 |         if (totalClaims >= burnInfo.totalProfit) {
   1876 |             rewards = burnInfo.totalProfit - burnInfo.totalClaim;
```

---

### 53. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1880 行
- **函数**: `claimRank()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1877 |             burnInfo.totalClaim = burnInfo.totalProfit;
   1878 |             IERC20(buy).safeTransfer(msg.sender, rewards);
   1879 |             emit NewRewardClear(msg.sender);
>> 1880 |             emit NewRewardClaim(msg.sender, orderId, category, rewards, block.timestamp);
   1881 |         } else {
   1882 |             burnInfo.totalClaim += rewards;
   1883 |             IERC20(buy).safeTransfer(msg.sender, rewards);
```

---

### 54. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1884 行
- **函数**: `claimRank()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1881 |         } else {
   1882 |             burnInfo.totalClaim += rewards;
   1883 |             IERC20(buy).safeTransfer(msg.sender, rewards);
>> 1884 |             emit NewRewardClaim(msg.sender, orderId, category, rewards, block.timestamp);
   1885 |         }
   1886 |     }
   1887 | 
```

---

### 55. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1891 行
- **函数**: `claimGroup()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1888 |     function claimGroup(uint256 orderId, uint256 dType, uint256 rewards, uint256 deadline, bytes[] memory signatures) public nonReentrant{
   1889 |         require(rewards > 0, "amount error");
   1890 |         require(dType > 0, "dType error");
>> 1891 |         require(deadline >= block.timestamp, "Invalid deadline");
   1892 |         require(orderClaimed[orderId] == false, "order taked");
   1893 |         BurnInfo storage burnInfo = burnInfoMap[msg.sender];
   1894 |         require(burnInfo.totalBurn > 0, "no burn");
```

---

### 56. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1904 行
- **函数**: `claimGroup()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1901 |         require(dbp[dType-1] >= rewards, "dbp pool error");
   1902 |         dbp[dType-1] -= rewards;
   1903 | 
>> 1904 |         burnInfo.lastClaim = block.timestamp;
   1905 |         uint256 totalClaims = burnInfo.totalClaim + rewards;
   1906 |         if (totalClaims >= burnInfo.totalProfit) {
   1907 |             rewards = burnInfo.totalProfit - burnInfo.totalClaim;
```

---

### 57. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1911 行
- **函数**: `claimGroup()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1908 |             burnInfo.totalClaim = burnInfo.totalProfit;
   1909 |             IERC20(buy).safeTransfer(msg.sender, rewards);
   1910 |             emit NewRewardClear(msg.sender);
>> 1911 |             emit NewRewardClaim(msg.sender, orderId, 1005, rewards, block.timestamp);
   1912 |         } else {
   1913 |             burnInfo.totalClaim += rewards;
   1914 |             IERC20(buy).safeTransfer(msg.sender, rewards);
```

---

### 58. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1915 行
- **函数**: `claimGroup()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1912 |         } else {
   1913 |             burnInfo.totalClaim += rewards;
   1914 |             IERC20(buy).safeTransfer(msg.sender, rewards);
>> 1915 |             emit NewRewardClaim(msg.sender, orderId, 1005, rewards, block.timestamp);
   1916 |         }
   1917 |     }
   1918 | 
```

---

### 59. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1922 行
- **函数**: `claimDirect()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1919 | 
   1920 |     function claimDirect(uint256 orderId, uint256 rewards, uint256 deadline, bytes[] memory signatures) public nonReentrant{
   1921 |         require(rewards > 0, "amount error");
>> 1922 |         require(deadline >= block.timestamp, "Invalid deadline");
   1923 |         require(orderClaimed[orderId] == false, "order taked");
   1924 |         BurnInfo storage burnInfo = burnInfoMap[msg.sender];
   1925 |         require(burnInfo.totalBurn > 0, "no burn");
```

---

### 60. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1933 行
- **函数**: `claimDirect()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1930 |         }
   1931 |         orderClaimed[orderId] = true;
   1932 | 
>> 1933 |         burnInfo.lastClaim = block.timestamp;
   1934 |         uint256 totalClaims = burnInfo.totalClaim + rewards;
   1935 |         if (totalClaims >= burnInfo.totalProfit) {
   1936 |             rewards = burnInfo.totalProfit - burnInfo.totalClaim;
```

---

### 61. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1940 行
- **函数**: `claimDirect()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1937 |             burnInfo.totalClaim = burnInfo.totalProfit;
   1938 |             IERC20(buy).safeTransfer(msg.sender, rewards);
   1939 |             emit NewRewardClear(msg.sender);
>> 1940 |             emit NewRewardClaim(msg.sender, orderId, 1006, rewards, block.timestamp);
   1941 |         } else {
   1942 |             burnInfo.totalClaim += rewards;
   1943 |             IERC20(buy).safeTransfer(msg.sender, rewards);
```

---

### 62. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1944 行
- **函数**: `claimDirect()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1941 |         } else {
   1942 |             burnInfo.totalClaim += rewards;
   1943 |             IERC20(buy).safeTransfer(msg.sender, rewards);
>> 1944 |             emit NewRewardClaim(msg.sender, orderId, 1006, rewards, block.timestamp);
   1945 |         }
   1946 |     }
   1947 | 
```

---

### 63. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1951 行
- **函数**: `claimStatic()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1948 | 
   1949 |     function claimStatic(uint256 orderId, uint256 period, uint256 rewards, uint256 deadline, bytes[] memory signatures) public nonReentrant{
   1950 |         require(rewards > 0, "amount error");
>> 1951 |         require(deadline >= block.timestamp, "Invalid deadline");
   1952 |         require(orderClaimed[orderId] == false, "order taked");
   1953 |         BurnInfo storage burnInfo = burnInfoMap[msg.sender];
   1954 |         require(burnInfo.totalBurn > 0, "no burn");
```

---

### 64. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1965 行
- **函数**: `claimStatic()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1962 |         }
   1963 |         orderClaimed[orderId] = true;
   1964 | 
>> 1965 |         burnInfo.lastClaim = block.timestamp;
   1966 |         uint256 totalClaims = burnInfo.totalClaim + rewards;
   1967 |         if (totalClaims >= burnInfo.totalProfit) {
   1968 |             rewards = burnInfo.totalProfit - burnInfo.totalClaim;
```

---

### 65. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1972 行
- **函数**: `claimStatic()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1969 |             burnInfo.totalClaim = burnInfo.totalProfit;
   1970 |             IERC20(buy).safeTransfer(msg.sender, rewards);
   1971 |             emit NewRewardClear(msg.sender);
>> 1972 |             emit NewRewardClaim(msg.sender, orderId, 1010, rewards, block.timestamp);
   1973 |         } else {
   1974 |             burnInfo.totalClaim += rewards;
   1975 |             IERC20(buy).safeTransfer(msg.sender, rewards);
```

---

### 66. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1976 行
- **函数**: `claimStatic()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1973 |         } else {
   1974 |             burnInfo.totalClaim += rewards;
   1975 |             IERC20(buy).safeTransfer(msg.sender, rewards);
>> 1976 |             emit NewRewardClaim(msg.sender, orderId, 1010, rewards, block.timestamp);
   1977 |         }
   1978 |     }
   1979 | 
```

---

### 67. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1983 行
- **函数**: `claimContribute()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1980 | 
   1981 |     function claimContribute(uint256 orderId, uint256 rewards, uint256 deadline, bytes[] memory signatures) public nonReentrant{
   1982 |         require(rewards > 0, "rewards error");
>> 1983 |         require(deadline >= block.timestamp, "Invalid deadline");
   1984 |         require(orderClaimed[orderId] == false, "order taked");
   1985 |         BurnInfo storage burnInfo = burnInfoMap[msg.sender];
   1986 |         require(burnInfo.totalBurn > 0, "no burn");
```

---

### 68. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1998 行
- **函数**: `claimContribute()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1995 |         require(contribute >= rewards, "contribute over");
   1996 |         contribute -= rewards;
   1997 | 
>> 1998 |         burnInfo.lastClaim = block.timestamp;
   1999 |         uint256 totalClaims = burnInfo.totalClaim + rewards;
   2000 |         if (totalClaims >= burnInfo.totalProfit) {
   2001 |             rewards = burnInfo.totalProfit - burnInfo.totalClaim;
```

---

### 69. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2005 行
- **函数**: `claimContribute()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2002 |             burnInfo.totalClaim = burnInfo.totalProfit;
   2003 |             IERC20(buy).safeTransfer(msg.sender, rewards);
   2004 |             emit NewRewardClear(msg.sender);
>> 2005 |             emit NewRewardClaim(msg.sender, orderId, 1019, rewards, block.timestamp);
   2006 |         } else {
   2007 |             burnInfo.totalClaim += rewards;
   2008 |             IERC20(buy).safeTransfer(msg.sender, rewards);
```

---

### 70. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2009 行
- **函数**: `claimContribute()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2006 |         } else {
   2007 |             burnInfo.totalClaim += rewards;
   2008 |             IERC20(buy).safeTransfer(msg.sender, rewards);
>> 2009 |             emit NewRewardClaim(msg.sender, orderId, 1019, rewards, block.timestamp);
   2010 |         }
   2011 |     }
   2012 | 
```

---

### 71. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2015 行
- **函数**: `claimBonus()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2012 | 
   2013 |     function claimBonus(uint256 orderId, uint256 amount, uint256 deadline, bytes[] memory signatures) public nonReentrant{
   2014 |         require(amount > 0, "amount error");
>> 2015 |         require(deadline >= block.timestamp, "Invalid deadline");
   2016 |         require(orderClaimed[orderId] == false, "order taked");
   2017 |         require(bonus >= amount, "bonus1 over");
   2018 |         bonus -= amount;
```

---

### 72. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2026 行
- **函数**: `claimBonus()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2023 |         orderClaimed[orderId] = true;
   2024 |         // withdraw
   2025 |         IERC20(buy).safeTransfer(msg.sender, amount);
>> 2026 |         emit NewRewardClaim(msg.sender, orderId, 1018, amount, block.timestamp);
   2027 |     }
   2028 | 
   2029 |     // check
```

---

### 73. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2035 行
- **函数**: `getClaimablePeriods()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2032 |         if (burnInfo.lastBurn == 0) {
   2033 |             return 0;
   2034 |         }
>> 2035 |         uint256 timeElapsed = block.timestamp - burnInfo.lastBurn;
   2036 |         uint256 fullPeriods = (timeElapsed + BUFFER_SECONDS) / PERIOD_IN_SECONDS;
   2037 |         return fullPeriods > burnInfo.burnClaimedPeriods
   2038 |             ? fullPeriods - burnInfo.burnClaimedPeriods
```

---

### 74. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 2046 行
- **函数**: `checkMinimumTimeElapsed()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2043 |         BurnInfo memory record = burnInfoMap[user];
   2044 |         require(record.lastBurn != 0, "No burn record");
   2045 | 
>> 2046 |         uint256 elapsed = block.timestamp - record.lastBurn;
   2047 |         require(
   2048 |             elapsed >= PERIOD_IN_SECONDS + BUFFER_SECONDS,
   2049 |             "Please wait until next Beijing Time cycle (00:00 UTC+8)"
```

---

### 75. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1744 行
- **函数**: `recoverSigner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1741 |             v := byte(0, mload(add(_signature, 0x60)))
   1742 |         }
   1743 |         // s ≤ n/2（n = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141）
>> 1744 |         uint256 sMax = 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0;
   1745 |         require(uint256(s) <= sMax, "invalid signature 's' value");
   1746 |         address signer = ecrecover(encodeHash, v, r, s);
   1747 |         require(signer != address(0), "invalid signature");
```

---

### 76. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1775 行
- **函数**: `verify()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1772 |     // Buffer time (e.g., 60 s) to allow some flexibility
   1773 |     uint256 public constant BUFFER_SECONDS = 60;
   1774 | 
>> 1775 |     address public dead = 0x000000000000000000000000000000000000dEaD;
   1776 |     address public zero = 0x000000000000000000000000000000000000d000;
   1777 | 
   1778 |     address public drdr;
```

---

### 77. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1776 行
- **函数**: `verify()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1773 |     uint256 public constant BUFFER_SECONDS = 60;
   1774 | 
   1775 |     address public dead = 0x000000000000000000000000000000000000dEaD;
>> 1776 |     address public zero = 0x000000000000000000000000000000000000d000;
   1777 | 
   1778 |     address public drdr;
   1779 |     address public buy;
```

---

### 78. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 932 行
- **函数**: `_revert()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    929 |         if (returndata.length > 0) {
    930 |             // The easiest way to bubble the revert reason is using memory via assembly
    931 |             /// @solidity memory-safe-assembly
>>  932 |             assembly {
    933 |                 let returndata_size := mload(returndata)
    934 |                 revert(add(32, returndata), returndata_size)
    935 |             }
```

---

### 79. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1151 行
- **函数**: `mulDiv()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1148 |             // variables such that product = prod1 * 2^256 + prod0.
   1149 |             uint256 prod0; // Least significant 256 bits of the product
   1150 |             uint256 prod1; // Most significant 256 bits of the product
>> 1151 |             assembly {
   1152 |                 let mm := mulmod(x, y, not(0))
   1153 |                 prod0 := mul(x, y)
   1154 |                 prod1 := sub(sub(mm, prod0), lt(mm, prod0))
```

---

### 80. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1174 行
- **函数**: `mulDiv()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1171 | 
   1172 |             // Make division exact by subtracting the remainder from [prod1 prod0].
   1173 |             uint256 remainder;
>> 1174 |             assembly {
   1175 |                 // Compute remainder using mulmod.
   1176 |                 remainder := mulmod(x, y, denominator)
   1177 | 
```

---

### 81. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1188 行
- **函数**: `mulDiv()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1185 | 
   1186 |             // Does not overflow because the denominator cannot be zero at this stage in the function.
   1187 |             uint256 twos = denominator & (~denominator + 1);
>> 1188 |             assembly {
   1189 |                 // Divide denominator by twos.
   1190 |                 denominator := div(denominator, twos)
   1191 | 
```

---

### 82. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1502 行
- **函数**: `toString()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1499 |             string memory buffer = new string(length);
   1500 |             uint256 ptr;
   1501 |             /// @solidity memory-safe-assembly
>> 1502 |             assembly {
   1503 |                 ptr := add(buffer, add(32, length))
   1504 |             }
   1505 |             while (true) {
```

---

### 83. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1508 行
- **函数**: `toString()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1505 |             while (true) {
   1506 |                 ptr--;
   1507 |                 /// @solidity memory-safe-assembly
>> 1508 |                 assembly {
   1509 |                     mstore8(ptr, byte(mod(value, 10), _SYMBOLS))
   1510 |                 }
   1511 |                 value /= 10;
```

---

### 84. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1685 行
- **函数**: `isEOA()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1682 | 
   1683 |     function isEOA(address _addr) internal view returns (bool) {
   1684 |         uint32 size;
>> 1685 |         assembly {
   1686 |             size := extcodesize(_addr)
   1687 |         }
   1688 |         return size == 0;
```

---

### 85. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x56C892D6183D5B6BF2841d030147414FF1621B8b` 第 1738 行
- **函数**: `recoverSigner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1735 |         bytes32 r;
   1736 |         bytes32 s;
   1737 |         uint8 v;
>> 1738 |         assembly {
   1739 |             r := mload(add(_signature, 0x20))
   1740 |             s := mload(add(_signature, 0x40))
   1741 |             v := byte(0, mload(add(_signature, 0x60)))
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*