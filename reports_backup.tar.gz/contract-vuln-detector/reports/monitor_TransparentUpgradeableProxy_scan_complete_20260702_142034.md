# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:20:34
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` |
| contract_name | `TransparentUpgradeableProxy` |
| compiler_version | `v0.8.29+commit.ab55807c` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `prague` |
| license_type | `` |
| proxy | `True` |
| implementation | `0x3d5f14617283c3d074014cfb51cf10dae50554cc` |
| multi_file | `True` |
| source_files | `['src/Proxy2.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646143` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 11 |
| 🟢 LOW | 5 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 137 行
- **函数**: `_delegate()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    134 | 
    135 |             // Call the implementation.
    136 |             // out and outsize are 0 because we don't know the size yet.
>>  137 |             let result := delegatecall(gas(), implementation, 0, calldatasize(), 0, 0)
    138 | 
    139 |             // Copy the returned data.
    140 |             returndatacopy(0, 0, returndatasize())
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 413 行
- **函数**: `functionDelegateCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    410 |      * but performing a delegate call.
    411 |      */
    412 |     function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
>>  413 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    414 |         return verifyCallResultFromTarget(target, success, returndata);
    415 |     }
    416 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 354 行
- **函数**: `sendValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    351 |             revert Errors.InsufficientBalance(address(this).balance, amount);
    352 |         }
    353 | 
>>  354 |         (bool success, bytes memory returndata) = recipient.call{value: amount}("");
    355 |         if (!success) {
    356 |             _revert(returndata);
    357 |         }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 395 行
- **函数**: `functionCallWithValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    392 |         if (address(this).balance < value) {
    393 |             revert Errors.InsufficientBalance(address(this).balance, value);
    394 |         }
>>  395 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    396 |         return verifyCallResultFromTarget(target, success, returndata);
    397 |     }
    398 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 81 行
- **函数**: `implementation()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     78 |      *
     79 |      * {UpgradeableBeacon} will check that this address is a contract.
     80 |      */
>>   81 |     function implementation() external view returns (address);
     82 | }
     83 | 
     84 | // lib/openzeppelin-contracts/contracts/interfaces/IERC1967.sol
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 519 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    516 |     /**
    517 |      * @dev Returns the address of the current owner.
    518 |      */
>>  519 |     function owner() public view virtual returns (address) {
    520 |         return _owner;
    521 |     }
    522 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 828 行
- **函数**: `upgradeToAndCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    825 |  */
    826 | interface ITransparentUpgradeableProxy is IERC1967 {
    827 |     /// @dev See {UUPSUpgradeable-upgradeToAndCall}
>>  828 |     function upgradeToAndCall(address newImplementation, bytes calldata data) external payable;
    829 | }
    830 | 
    831 | /**
```

---

### 8. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 122 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    117 |  * Additionally, delegation to the implementation can be triggered manually through the {_fallback} function, or to a
    118 |  * different contract through the {_delegate} function.
    119 |  *
    120 |  * The success and return data of the delegated call will be returned back to the caller of the proxy.
    121 |  */
>>  122 | abstract contract Proxy {
    123 |     /**
    124 |      * @dev Delegates the current call to `implementation`.
    125 |      *
    126 |      * This function does not return to its internal call site, it will return directly to the external caller.
    127 |      */
```

---

### 9. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 483 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    478 |  *
    479 |  * This module is used through inheritance. It will make available the modifier
    480 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    481 |  * the owner.
    482 |  */
>>  483 | abstract contract Ownable is Context {
    484 |     address private _owner;
    485 | 
    486 |     /**
    487 |      * @dev The caller account is not authorized to perform an operation.
    488 |      */
```

---

### 10. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 555 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    550 |         }
    551 |         _transferOwnership(newOwner);
    552 |     }
    553 | 
    554 |     /**
>>  555 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    556 |      * Internal function without access restriction.
    557 |      */
    558 |     function _transferOwnership(address newOwner) internal virtual {
    559 |         address oldOwner = _owner;
    560 |         _owner = newOwner;
```

---

### 11. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 742 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    737 | // lib/openzeppelin-contracts/contracts/proxy/ERC1967/ERC1967Proxy.sol
    738 | 
    739 | // OpenZeppelin Contracts (last updated v5.2.0) (proxy/ERC1967/ERC1967Proxy.sol)
    740 | 
    741 | /**
>>  742 |  * @dev This contract implements an upgradeable proxy. It is upgradeable because calls are delegated to an
    743 |  * implementation address that can be changed. This address is stored in storage in the location specified by
    744 |  * https://eips.ethereum.org/EIPS/eip-1967[ERC-1967], so that it doesn't conflict with the storage layout of the
    745 |  * implementation behind the proxy.
    746 |  */
    747 | contract ERC1967Proxy is Proxy {
```

---

### 12. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 782 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    777 | 
    778 | /**
    779 |  * @dev This is an auxiliary contract meant to be assigned as the admin of a {TransparentUpgradeableProxy}. For an
    780 |  * explanation of why you would want to use this see the documentation for {TransparentUpgradeableProxy}.
    781 |  */
>>  782 | contract ProxyAdmin is Ownable {
    783 |     /**
    784 |      * @dev The version of the upgrade interface of the contract. If this getter is missing, both `upgrade(address,address)`
    785 |      * and `upgradeAndCall(address,address,bytes)` are present, and `upgrade` must be used if no function should be called,
    786 |      * while `upgradeAndCall` will invoke the `receive` function if the third argument is the empty byte string.
    787 |      * If the getter returns `"5.0.0"`, only `upgradeAndCall(address,address,bytes)` is present, and the third argument must
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 871 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    866 |  * WARNING: It is not recommended to extend this contract to add additional external functions. If you do so, the
    867 |  * compiler will not check that there are no selector conflicts, due to the note above. A selector clash between any new
    868 |  * function and the functions declared in {ITransparentUpgradeableProxy} will be resolved in favor of the new one. This
    869 |  * could render the `upgradeToAndCall` function inaccessible, preventing upgradeability and compromising transparency.
    870 |  */
>>  871 | contract TransparentUpgradeableProxy is ERC1967Proxy {
    872 |     // An immutable address for the admin to avoid unnecessary SLOADs before each call
    873 |     // at the expense of removing the ability to change the admin once it's set.
    874 |     // This is acceptable if the admin is always a ProxyAdmin instance or similar contract
    875 |     // with its own ability to transfer the permissions to another account.
    876 |     address private immutable _admin;
```

---

### 14. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_j3jrs_s2/0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1.sol` 第 888 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: TransparentUpgradeableProxy.constructor(address,address,bytes).initialOwner (../../../tmp/slither_scan_j3jrs_s2/0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1.sol#888) lacks a zero-check on :
		- _admin = address(new ProxyAdmin(initialOwner)) (../../../tmp/slither_scan_j3jrs_s2/0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1.sol#889)

**代码片段**:
```solidity
    885 |      * backed by the implementation at `_logic`, and optionally initialized with `_data` as explained in
    886 |      * {ERC1967Proxy-constructor}.
    887 |      */
>>  888 |     constructor(address _logic, address initialOwner, bytes memory _data) payable ERC1967Proxy(_logic, _data) {
    889 |         _admin = address(new ProxyAdmin(initialOwner));
    890 |         // Set the storage value and emit an event for ERC-1967 compatibility
    891 |         ERC1967Utils.changeAdmin(_proxyAdmin());
```

---

### 15. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 579 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    576 |      * This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1.
    577 |      */
    578 |     // solhint-disable-next-line private-vars-leading-underscore
>>  579 |     bytes32 internal constant IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
    580 | 
    581 |     /**
    582 |      * @dev The `implementation` of the proxy is invalid.
```

---

### 16. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 641 行
- **函数**: `upgradeToAndCall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    638 |      * This is the keccak-256 hash of "eip1967.proxy.admin" subtracted by 1.
    639 |      */
    640 |     // solhint-disable-next-line private-vars-leading-underscore
>>  641 |     bytes32 internal constant ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    642 | 
    643 |     /**
    644 |      * @dev Returns the current admin.
```

---

### 17. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 679 行
- **函数**: `changeAdmin()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    676 |      * This is the keccak-256 hash of "eip1967.proxy.beacon" subtracted by 1.
    677 |      */
    678 |     // solhint-disable-next-line private-vars-leading-underscore
>>  679 |     bytes32 internal constant BEACON_SLOT = 0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50;
    680 | 
    681 |     /**
    682 |      * @dev Returns the current beacon.
```

---

### 18. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6A7054e68B9335c31b75A4c67D2D6B5c819119B1` 第 129 行
- **函数**: `_delegate()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    126 |      * This function does not return to its internal call site, it will return directly to the external caller.
    127 |      */
    128 |     function _delegate(address implementation) internal virtual {
>>  129 |         assembly {
    130 |             // Copy msg.data. We take full control of memory in this inline assembly
    131 |             // block because it will not return to Solidity code. We overwrite the
    132 |             // Solidity scratch pad at memory position 0.
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*