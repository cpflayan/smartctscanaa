# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:21:33
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x37ad5104056F6C158D305c50577aca5515Ca20ae` |
| contract_name | `Kernel` |
| compiler_version | `v0.8.25+commit.b61c2a91` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/Kernel.sol', 'src/interfaces/PackedUserOperation.sol', 'src/interfaces/IAccount.sol', 'src/interfaces/IEntryPoint.sol', 'src/interfaces/IAccountExecute.sol', 'src/interfaces/IERC7579Account.sol', 'src/utils/ModuleLib.sol', 'src/core/ValidationManager.sol', 'src/core/HookManager.sol', 'src/core/ExecutorManager.sol', 'src/core/SelectorManager.sol', 'src/interfaces/IERC7579Modules.sol', 'lib/solady/src/utils/EIP712.sol', 'src/utils/ExecLib.sol', 'src/types/Constants.sol', 'src/types/Types.sol', 'src/interfaces/IStakeManager.sol', 'src/interfaces/IAggregator.sol', 'src/interfaces/INonceManager.sol', 'lib/ExcessivelySafeCall/src/ExcessivelySafeCall.sol', 'src/utils/ValidationTypeLib.sol', 'src/utils/KernelValidationResult.sol', 'src/types/Structs.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655009` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 48 |
| 🟢 LOW | 79 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2232 行
- **函数**: `executeDelegatecall()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   2229 |             result := mload(0x40)
   2230 |             calldatacopy(result, callData.offset, callData.length)
   2231 |             // Forwards the `data` to `delegate` via delegatecall.
>> 2232 |             success := delegatecall(gas(), delegate, result, callData.length, codesize(), 0x00)
   2233 |             mstore(result, returndatasize()) // Store the length.
   2234 |             let o := add(result, 0x20)
   2235 |             returndatacopy(o, 0x00, returndatasize()) // Copy the returndata.
```

---

### 2. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 119 行
- **函数**: `initialize()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    116 |         vs.currentNonce = 1;
    117 |         _installValidation(_rootValidator, config, validatorData, hookData);
    118 |         for (uint256 i = 0; i < initConfig.length; i++) {
>>  119 |             (bool success,) = address(this).call(initConfig[i]);
    120 |             if (!success) {
    121 |                 revert InitConfigError(i);
    122 |             }
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 148 行
- **函数**: `upgradeTo()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    145 |         }
    146 |     }
    147 | 
>>  148 |     function upgradeTo(address _newImplementation) external payable onlyEntryPointOrSelfOrRoot {
    149 |         assembly {
    150 |             sstore(ERC1967_IMPLEMENTATION_SLOT, _newImplementation)
    151 |         }
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 164 行
- **函数**: `onERC721Received()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    161 |         emit Received(msg.sender, msg.value);
    162 |     }
    163 | 
>>  164 |     function onERC721Received(address, address, uint256, bytes calldata) external pure returns (bytes4) {
    165 |         return this.onERC721Received.selector;
    166 |     }
    167 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 168 行
- **函数**: `onERC1155Received()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    165 |         return this.onERC721Received.selector;
    166 |     }
    167 | 
>>  168 |     function onERC1155Received(address, address, uint256, uint256, bytes calldata) external pure returns (bytes4) {
    169 |         return this.onERC1155Received.selector;
    170 |     }
    171 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 316 行
- **函数**: `execute()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    313 |         }
    314 |     }
    315 | 
>>  316 |     function execute(ExecMode execMode, bytes calldata executionCalldata) external payable onlyEntryPointOrSelfOrRoot {
    317 |         ExecLib.execute(execMode, executionCalldata);
    318 |     }
    319 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 320 行
- **函数**: `isValidSignature()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    317 |         ExecLib.execute(execMode, executionCalldata);
    318 |     }
    319 | 
>>  320 |     function isValidSignature(bytes32 hash, bytes calldata signature) external view override returns (bytes4) {
    321 |         ValidationStorage storage vs = _validationStorage();
    322 |         (ValidationId vId, bytes calldata sig) = ValidatorLib.decodeSignature(signature);
    323 |         if (ValidatorLib.getType(vId) == VALIDATION_TYPE_ROOT) {
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 441 行
- **函数**: `invalidateNonce()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    438 |         _uninstallHook(hook, hookDeinitData);
    439 |     }
    440 | 
>>  441 |     function invalidateNonce(uint32 nonce) external payable onlyEntryPointOrSelfOrRoot {
    442 |         _invalidateNonce(nonce);
    443 |     }
    444 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 504 行
- **函数**: `supportsModule()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    501 |         }
    502 |     }
    503 | 
>>  504 |     function supportsModule(uint256 moduleTypeId) external pure override returns (bool) {
    505 |         if (moduleTypeId < 7) {
    506 |             return true;
    507 |         } else {
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 530 行
- **函数**: `accountId()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    527 |         }
    528 |     }
    529 | 
>>  530 |     function accountId() external pure override returns (string memory accountImplementationId) {
    531 |         return "kernel.advanced.v0.3.1";
    532 |     }
    533 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 534 行
- **函数**: `supportsExecutionMode()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    531 |         return "kernel.advanced.v0.3.1";
    532 |     }
    533 | 
>>  534 |     function supportsExecutionMode(ExecMode mode) external pure override returns (bool) {
    535 |         (CallType callType, ExecType execType, ExecModeSelector selector, ExecModePayload payload) =
    536 |             ExecLib.decode(mode);
    537 |         if (
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 786 行
- **函数**: `getUserOpHash()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    783 |      * @param userOp - The user operation to generate the request ID for.
    784 |      * @return hash the hash of this UserOperation
    785 |      */
>>  786 |     function getUserOpHash(PackedUserOperation calldata userOp) external view returns (bytes32);
    787 | 
    788 |     /**
    789 |      * Gas and return values during simulation.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 852 行
- **函数**: `executeUserOp()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    849 |      * @param userOp              - The operation that was just validated.
    850 |      * @param userOpHash          - Hash of the user's request data.
    851 |      */
>>  852 |     function executeUserOp(PackedUserOperation calldata userOp, bytes32 userOpHash) external payable;
    853 | }
    854 | 
    855 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 884 行
- **函数**: `execute()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    881 |      * @param mode The encoded execution mode of the transaction. See ModeLib.sol for details
    882 |      * @param executionCalldata The encoded execution call data
    883 |      */
>>  884 |     function execute(ExecMode mode, bytes calldata executionCalldata) external payable;
    885 | 
    886 |     /**
    887 |      * @dev Executes a transaction on behalf of the account.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 909 行
- **函数**: `isValidSignature()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    906 |      * @param hash The hash of the data that is signed
    907 |      * @param data The data that is signed
    908 |      */
>>  909 |     function isValidSignature(bytes32 hash, bytes calldata data) external view returns (bytes4);
    910 | 
    911 |     /**
    912 |      * @dev installs a Module of a certain type on the smart account
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 919 行
- **函数**: `installModule()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    916 |      * @param initData arbitrary data that may be required on the module during `onInstall`
    917 |      * initialization.
    918 |      */
>>  919 |     function installModule(uint256 moduleTypeId, address module, bytes calldata initData) external payable;
    920 | 
    921 |     /**
    922 |      * @dev uninstalls a Module of a certain type on the smart account
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 929 行
- **函数**: `uninstallModule()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    926 |      * @param deInitData arbitrary data that may be required on the module during `onUninstall`
    927 |      * de-initialization.
    928 |      */
>>  929 |     function uninstallModule(uint256 moduleTypeId, address module, bytes calldata deInitData) external payable;
    930 | 
    931 |     /**
    932 |      * Function to check if the account supports a certain CallType or ExecType (see ModeLib.sol)
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 935 行
- **函数**: `supportsExecutionMode()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    932 |      * Function to check if the account supports a certain CallType or ExecType (see ModeLib.sol)
    933 |      * @param encodedMode the encoded mode
    934 |      */
>>  935 |     function supportsExecutionMode(ExecMode encodedMode) external view returns (bool);
    936 | 
    937 |     /**
    938 |      * Function to check if the account supports installation of a certain module type Id
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 941 行
- **函数**: `supportsModule()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    938 |      * Function to check if the account supports installation of a certain module type Id
    939 |      * @param moduleTypeId the module type ID according the ERC-7579 spec
    940 |      */
>>  941 |     function supportsModule(uint256 moduleTypeId) external view returns (bool);
    942 | 
    943 |     /**
    944 |      * Function to check if the account has a certain module installed
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 965 行
- **函数**: `accountId()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    962 |      * the accountId should be structured like so:
    963 |      *        "vendorname.accountname.semver"
    964 |      */
>>  965 |     function accountId() external view returns (string memory accountImplementationId);
    966 | }
    967 | 
    968 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1083 行
- **函数**: `rootValidator()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1080 |         mapping(PermissionId => PermissionConfig) permissionConfig;
   1081 |     }
   1082 | 
>> 1083 |     function rootValidator() external view returns (ValidationId) {
   1084 |         return _validationStorage().rootValidator;
   1085 |     }
   1086 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1087 行
- **函数**: `currentNonce()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1084 |         return _validationStorage().rootValidator;
   1085 |     }
   1086 | 
>> 1087 |     function currentNonce() external view returns (uint32) {
   1088 |         return _validationStorage().currentNonce;
   1089 |     }
   1090 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1091 行
- **函数**: `validNonceFrom()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1088 |         return _validationStorage().currentNonce;
   1089 |     }
   1090 | 
>> 1091 |     function validNonceFrom() external view returns (uint32) {
   1092 |         return _validationStorage().validNonceFrom;
   1093 |     }
   1094 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1095 行
- **函数**: `isAllowedSelector()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1092 |         return _validationStorage().validNonceFrom;
   1093 |     }
   1094 | 
>> 1095 |     function isAllowedSelector(ValidationId vId, bytes4 selector) external view returns (bool) {
   1096 |         return _validationStorage().allowedSelectors[vId][selector];
   1097 |     }
   1098 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1099 行
- **函数**: `validationConfig()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1096 |         return _validationStorage().allowedSelectors[vId][selector];
   1097 |     }
   1098 | 
>> 1099 |     function validationConfig(ValidationId vId) external view returns (ValidationConfig memory) {
   1100 |         return _validationStorage().validationConfig[vId];
   1101 |     }
   1102 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1103 行
- **函数**: `permissionConfig()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1100 |         return _validationStorage().validationConfig[vId];
   1101 |     }
   1102 | 
>> 1103 |     function permissionConfig(PermissionId pId) external view returns (PermissionConfig memory) {
   1104 |         return (_validationStorage().permissionConfig[pId]);
   1105 |     }
   1106 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1667 行
- **函数**: `executorConfig()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1664 |         mapping(IExecutor => ExecutorConfig) executorConfig;
   1665 |     }
   1666 | 
>> 1667 |     function executorConfig(IExecutor executor) external view returns (ExecutorConfig memory) {
   1668 |         return _executorConfig(executor);
   1669 |     }
   1670 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1734 行
- **函数**: `selectorConfig()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1731 |         mapping(bytes4 => SelectorConfig) selectorConfig;
   1732 |     }
   1733 | 
>> 1734 |     function selectorConfig(bytes4 selector) external view returns (SelectorConfig memory) {
   1735 |         return _selectorConfig(selector);
   1736 |     }
   1737 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1800 行
- **函数**: `onInstall()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1797 |      *
   1798 |      * MUST revert on error (i.e. if module is already enabled)
   1799 |      */
>> 1800 |     function onInstall(bytes calldata data) external payable;
   1801 | 
   1802 |     /**
   1803 |      * @dev This function is called by the smart account during uninstallation of the module
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1809 行
- **函数**: `onUninstall()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1806 |      *
   1807 |      * MUST revert on error
   1808 |      */
>> 1809 |     function onUninstall(bytes calldata data) external payable;
   1810 | 
   1811 |     /**
   1812 |      * @dev Returns boolean value if module is a certain type
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1817 行
- **函数**: `isModuleType()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1814 |      *
   1815 |      * MUST return true if the module is of the given type and false otherwise
   1816 |      */
>> 1817 |     function isModuleType(uint256 moduleTypeId) external view returns (bool);
   1818 | 
   1819 |     /**
   1820 |      * @dev Returns if the module was already initialized for a provided smartaccount
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1822 行
- **函数**: `isInitialized()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1819 |     /**
   1820 |      * @dev Returns if the module was already initialized for a provided smartaccount
   1821 |      */
>> 1822 |     function isInitialized(address smartAccount) external view returns (bool);
   1823 | }
   1824 | 
   1825 | interface IValidator is IModule {
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1860 行
- **函数**: `postCheck()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1857 |         payable
   1858 |         returns (bytes memory hookData);
   1859 | 
>> 1860 |     function postCheck(bytes calldata hookData) external payable;
   1861 | }
   1862 | 
   1863 | interface IFallback is IModule {}
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1866 行
- **函数**: `checkUserOpPolicy()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1863 | interface IFallback is IModule {}
   1864 | 
   1865 | interface IPolicy is IModule {
>> 1866 |     function checkUserOpPolicy(bytes32 id, PackedUserOperation calldata userOp) external payable returns (uint256);
   1867 |     function checkSignaturePolicy(bytes32 id, address sender, bytes32 hash, bytes calldata sig)
   1868 |         external
   1869 |         view
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2623 行
- **函数**: `getDepositInfo()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2620 |      * @param account - The account to query.
   2621 |      * @return info   - Full deposit information of given account.
   2622 |      */
>> 2623 |     function getDepositInfo(address account) external view returns (DepositInfo memory info);
   2624 | 
   2625 |     /**
   2626 |      * Get account balance.
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2630 行
- **函数**: `balanceOf()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2627 |      * @param account - The account to query.
   2628 |      * @return        - The deposit (for gas payment) of the account.
   2629 |      */
>> 2630 |     function balanceOf(address account) external view returns (uint256);
   2631 | 
   2632 |     /**
   2633 |      * Add to the deposit of the given account.
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2636 行
- **函数**: `depositTo()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2633 |      * Add to the deposit of the given account.
   2634 |      * @param account - The account to add to.
   2635 |      */
>> 2636 |     function depositTo(address account) external payable;
   2637 | 
   2638 |     /**
   2639 |      * Add to the account's stake - amount and delay
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2643 行
- **函数**: `addStake()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2640 |      * any pending unstake is first cancelled.
   2641 |      * @param _unstakeDelaySec - The new lock duration before the deposit can be withdrawn.
   2642 |      */
>> 2643 |     function addStake(uint32 _unstakeDelaySec) external payable;
   2644 | 
   2645 |     /**
   2646 |      * Attempt to unlock the stake.
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2684 行
- **函数**: `validateSignatures()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2681 |      * @param userOps   - Array of UserOperations to validate the signature for.
   2682 |      * @param signature - The aggregated signature.
   2683 |      */
>> 2684 |     function validateSignatures(PackedUserOperation[] calldata userOps, bytes calldata signature) external view;
   2685 | 
   2686 |     /**
   2687 |      * Validate signature of a single userOp.
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2729 行
- **函数**: `getNonce()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2726 |      * @param key the high 192 bit of the nonce
   2727 |      * @return nonce a full nonce to pass for next UserOp with this sender.
   2728 |      */
>> 2729 |     function getNonce(address sender, uint192 key) external view returns (uint256 nonce);
   2730 | 
   2731 |     /**
   2732 |      * Manually increment the nonce of the sender.
```

---

### 41. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 50 行
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     45 |     CALLTYPE_SINGLE,
     46 |     CALLTYPE_BATCH,
     47 |     CALLTYPE_STATIC
     48 | } from "./types/Constants.sol";
     49 | 
>>   50 | contract Kernel is IAccount, IAccountExecute, IERC7579Account, ValidationManager {
     51 |     error ExecutionReverted();
     52 |     error InvalidExecutor();
     53 |     error InvalidFallback();
     54 |     error InvalidCallType();
     55 |     error OnlyExecuteUserOp();
```

---

### 42. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 572 行
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    567 | 
    568 | /**
    569 |  * User Operation struct
    570 |  * @param sender                - The sender account of this request.
    571 |  * @param nonce                 - Unique value the sender uses to verify it is not a replay.
>>  572 |  * @param initCode              - If set, the account contract will be created by this constructor/
    573 |  * @param callData              - The method call to execute on this account.
    574 |  * @param accountGasLimits      - Packed gas limits for validateUserOp and gas limit passed to the callData method call.
    575 |  * @param preVerificationGas    - Gas not calculated by the handleOps method, but added to the gas paid.
    576 |  *                                Covers batch overhead.
    577 |  * @param gasFees                - packed gas fields maxFeePerGas and maxPriorityFeePerGas - Same as EIP-1559 gas parameter.
```

---

### 43. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 815 行
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    810 |         StakeInfo stakeInfo;
    811 |     }
    812 | 
    813 |     /**
    814 |      * Get counterfactual sender address.
>>  815 |      * Calculate the sender contract address that will be generated by the initCode and salt in the UserOperation.
    816 |      * This method always revert, and returns the address in SenderAddressResult error
    817 |      * @param initCode - The constructor code to be passed into the UserOperation.
    818 |      */
    819 |     function getSenderAddress(bytes memory initCode) external;
    820 | 
```

---

### 44. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1034 行
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1029 |     MAX_NONCE_INCREMENT_SIZE,
   1030 |     ENABLE_TYPE_HASH,
   1031 |     KERNEL_WRAPPER_TYPE_HASH
   1032 | } from "../types/Constants.sol";
   1033 | 
>> 1034 | abstract contract ValidationManager is EIP712, SelectorManager, HookManager, ExecutorManager {
   1035 |     event RootValidatorUpdated(ValidationId rootValidator);
   1036 |     event ValidatorInstalled(IValidator validator, uint32 nonce);
   1037 |     event PermissionInstalled(PermissionId permission, uint32 nonce);
   1038 |     event NonceInvalidated(uint32 nonce);
   1039 |     event ValidatorUninstalled(IValidator validator);
```

---

### 45. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1599 行
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1594 | import {IHook} from "../interfaces/IERC7579Modules.sol";
   1595 | import {ModuleLib} from "../utils/ModuleLib.sol";
   1596 | import {IERC7579Account} from "../interfaces/IERC7579Account.sol";
   1597 | import {MODULE_TYPE_HOOK} from "../types/Constants.sol";
   1598 | 
>> 1599 | abstract contract HookManager {
   1600 |     // NOTE: currently, all install/uninstall calls onInstall/onUninstall
   1601 |     // I assume this does not pose any security risks, but there should be a way to branch if hook needs call to onInstall/onUninstall
   1602 |     // --- Hook ---
   1603 |     // Hook is activated on these scenarios
   1604 |     // - on 4337 flow, userOp.calldata starts with executeUserOp.selector && validator requires hook
```

---

### 46. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1721 行
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1716 |     CALLTYPE_SINGLE,
   1717 |     MODULE_TYPE_FALLBACK
   1718 | } from "../types/Constants.sol";
   1719 | import {ModuleLib} from "../utils/ModuleLib.sol";
   1720 | 
>> 1721 | abstract contract SelectorManager {
   1722 |     error NotSupportedCallType();
   1723 | 
   1724 |     struct SelectorConfig {
   1725 |         IHook hook; // 20 bytes for hook address
   1726 |         address target; // 20 bytes target will be fallback module, called with call
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1901 行
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1896 | /// - Uses `address(this)` for the `verifyingContract` field.
   1897 | /// - Does NOT use the optional EIP-712 salt.
   1898 | /// - Does NOT use any EIP-712 extensions.
   1899 | /// This is for simplicity and to save gas.
   1900 | /// If you need to customize, please fork / modify accordingly.
>> 1901 | abstract contract EIP712 {
   1902 |     /*´:°•.°+.*•´.*:˚.°*.˚•´.°:°•.°•.*•´.*:˚.°*.˚•´.°:°•.°+.*•´.*:*/
   1903 |     /*                  CONSTANTS AND IMMUTABLES                  */
   1904 |     /*.•°:°.´+˚.*°.˚:*.´•*.+°.•°:´*.´•*.•°.•°:°.´:•˚°.*°.˚:*.´+°.•*/
   1905 | 
   1906 |     /// @dev `keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)")`.
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2753 行
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2748 | library ExcessivelySafeCall {
   2749 |     uint256 constant LOW_28_MASK =
   2750 |         0x00000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffff;
   2751 | 
   2752 |     /// @notice Use when you _really_ really _really_ don't trust the called
>> 2753 |     /// contract. This prevents the called contract from causing reversion of
   2754 |     /// the caller in as many ways as we can.
   2755 |     /// @dev The main difference between this and a solidity low-level call is
   2756 |     /// that we limit the number of bytes that the callee can cause to be
   2757 |     /// copied to caller memory. This prevents stupid things like malicious
   2758 |     /// contracts returning 10,000,000 bytes causing a local OOG when copying
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2807 行
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2802 |         }
   2803 |         return (_success, _returnData);
   2804 |     }
   2805 | 
   2806 |     /// @notice Use when you _really_ really _really_ don't trust the called
>> 2807 |     /// contract. This prevents the called contract from causing reversion of
   2808 |     /// the caller in as many ways as we can.
   2809 |     /// @dev The main difference between this and a solidity low-level call is
   2810 |     /// that we limit the number of bytes that the callee can cause to be
   2811 |     /// copied to caller memory. This prevents stupid things like malicious
   2812 |     /// contracts returning 10,000,000 bytes causing a local OOG when copying
```

---

### 50. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1576 行
- **函数**: `_checkPermissionSignature()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1573 |         (ISigner signer, ValidationData valdiationData, bytes calldata validatorSig) =
   1574 |             _checkSignaturePolicy(pId, caller, hash, sig);
   1575 |         (ValidAfter validAfter, ValidUntil validUntil,) = parseValidationData(ValidationData.unwrap(valdiationData));
>> 1576 |         if (block.timestamp < ValidAfter.unwrap(validAfter) || block.timestamp > ValidUntil.unwrap(validUntil)) {
   1577 |             return 0xffffffff;
   1578 |         }
   1579 |         return signer.checkSignature(bytes32(PermissionId.unwrap(pId)), caller, _toWrappedHash(hash), validatorSig);
```

---

### 51. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 189 行
- **函数**: `onERC1155BatchReceived()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    186 |         }
    187 |         // action installed
    188 |         bytes memory context;
>>  189 |         if (address(config.hook) != address(1) && address(config.hook) != 0xFFfFfFffFFfffFFfFFfFFFFFffFFFffffFfFFFfF) {
    190 |             context = _doPreHook(config.hook, msg.value, msg.data);
    191 |         } else if (address(config.hook) == 0xFFfFfFffFFfffFFfFFfFFFFFffFFFffffFfFFFfF) {
    192 |             // for selector manager, address(0) for the hook will default to type(address).max,
```

---

### 52. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 191 行
- **函数**: `onERC1155BatchReceived()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    188 |         bytes memory context;
    189 |         if (address(config.hook) != address(1) && address(config.hook) != 0xFFfFfFffFFfffFFfFFfFFFFFffFFFffffFfFFFfF) {
    190 |             context = _doPreHook(config.hook, msg.value, msg.data);
>>  191 |         } else if (address(config.hook) == 0xFFfFfFffFFfffFFfFFfFFFFFffFFFffffFfFFFfF) {
    192 |             // for selector manager, address(0) for the hook will default to type(address).max,
    193 |             // and this will only allow entrypoints to interact
    194 |             if (msg.sender != address(entrypoint)) {
```

---

### 53. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 211 行
- **函数**: `onERC1155BatchReceived()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    208 |                 revert(add(result, 0x20), mload(result))
    209 |             }
    210 |         }
>>  211 |         if (address(config.hook) != address(1) && address(config.hook) != 0xFFfFfFffFFfffFFfFFfFFFFFffFFFffffFfFFFfF) {
    212 |             _doPostHook(config.hook, context);
    213 |         }
    214 |         assembly {
```

---

### 54. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1751 行
- **函数**: `_installSelector()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1748 | 
   1749 |     function _installSelector(bytes4 selector, address target, IHook hook, bytes calldata selectorData) internal {
   1750 |         if (address(hook) == address(0)) {
>> 1751 |             hook = IHook(address(0xFFfFfFffFFfffFFfFFfFFFFFffFFFffffFfFFFfF));
   1752 |         }
   1753 |         SelectorConfig storage ss = _selectorConfig(selector);
   1754 |         // we are going to install only through call/delegatecall
```

---

### 55. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1908 行
- **函数**: `checkSignature()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1905 | 
   1906 |     /// @dev `keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)")`.
   1907 |     bytes32 internal constant _DOMAIN_TYPEHASH =
>> 1908 |         0x8b73c3c69bb8fe3d512ecc4cf759cc79239f7b179b0ffacaa9a75d522b39400f;
   1909 | 
   1910 |     uint256 private immutable _cachedThis;
   1911 |     uint256 private immutable _cachedChainId;
```

---

### 56. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2418 行
- **函数**: `allocate()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2415 | 
   2416 | // --- storage slots ---
   2417 | // bytes32(uint256(keccak256('kernel.v3.selector')) - 1)
>> 2418 | bytes32 constant SELECTOR_MANAGER_STORAGE_SLOT = 0x7c341349a4360fdd5d5bc07e69f325dc6aaea3eb018b3e0ea7e53cc0bb0d6f3b;
   2419 | // bytes32(uint256(keccak256('kernel.v3.executor')) - 1)
   2420 | bytes32 constant EXECUTOR_MANAGER_STORAGE_SLOT = 0x1bbee3173dbdc223633258c9f337a0fff8115f206d302bea0ed3eac003b68b86;
   2421 | // bytes32(uint256(keccak256('kernel.v3.hook')) - 1)
```

---

### 57. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2420 行
- **函数**: `allocate()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2417 | // bytes32(uint256(keccak256('kernel.v3.selector')) - 1)
   2418 | bytes32 constant SELECTOR_MANAGER_STORAGE_SLOT = 0x7c341349a4360fdd5d5bc07e69f325dc6aaea3eb018b3e0ea7e53cc0bb0d6f3b;
   2419 | // bytes32(uint256(keccak256('kernel.v3.executor')) - 1)
>> 2420 | bytes32 constant EXECUTOR_MANAGER_STORAGE_SLOT = 0x1bbee3173dbdc223633258c9f337a0fff8115f206d302bea0ed3eac003b68b86;
   2421 | // bytes32(uint256(keccak256('kernel.v3.hook')) - 1)
   2422 | bytes32 constant HOOK_MANAGER_STORAGE_SLOT = 0x4605d5f70bb605094b2e761eccdc27bed9a362d8612792676bf3fb9b12832ffc;
   2423 | // bytes32(uint256(keccak256('kernel.v3.validation')) - 1)
```

---

### 58. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2422 行
- **函数**: `allocate()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2419 | // bytes32(uint256(keccak256('kernel.v3.executor')) - 1)
   2420 | bytes32 constant EXECUTOR_MANAGER_STORAGE_SLOT = 0x1bbee3173dbdc223633258c9f337a0fff8115f206d302bea0ed3eac003b68b86;
   2421 | // bytes32(uint256(keccak256('kernel.v3.hook')) - 1)
>> 2422 | bytes32 constant HOOK_MANAGER_STORAGE_SLOT = 0x4605d5f70bb605094b2e761eccdc27bed9a362d8612792676bf3fb9b12832ffc;
   2423 | // bytes32(uint256(keccak256('kernel.v3.validation')) - 1)
   2424 | bytes32 constant VALIDATION_MANAGER_STORAGE_SLOT = 0x7bcaa2ced2a71450ed5a9a1b4848e8e5206dbc3f06011e595f7f55428cc6f84f;
   2425 | bytes32 constant ERC1967_IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
```

---

### 59. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2424 行
- **函数**: `allocate()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2421 | // bytes32(uint256(keccak256('kernel.v3.hook')) - 1)
   2422 | bytes32 constant HOOK_MANAGER_STORAGE_SLOT = 0x4605d5f70bb605094b2e761eccdc27bed9a362d8612792676bf3fb9b12832ffc;
   2423 | // bytes32(uint256(keccak256('kernel.v3.validation')) - 1)
>> 2424 | bytes32 constant VALIDATION_MANAGER_STORAGE_SLOT = 0x7bcaa2ced2a71450ed5a9a1b4848e8e5206dbc3f06011e595f7f55428cc6f84f;
   2425 | bytes32 constant ERC1967_IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
   2426 | 
   2427 | // --- Kernel validation nonce incremental size limit ---
```

---

### 60. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2425 行
- **函数**: `allocate()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2422 | bytes32 constant HOOK_MANAGER_STORAGE_SLOT = 0x4605d5f70bb605094b2e761eccdc27bed9a362d8612792676bf3fb9b12832ffc;
   2423 | // bytes32(uint256(keccak256('kernel.v3.validation')) - 1)
   2424 | bytes32 constant VALIDATION_MANAGER_STORAGE_SLOT = 0x7bcaa2ced2a71450ed5a9a1b4848e8e5206dbc3f06011e595f7f55428cc6f84f;
>> 2425 | bytes32 constant ERC1967_IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
   2426 | 
   2427 | // --- Kernel validation nonce incremental size limit ---
   2428 | uint32 constant MAX_NONCE_INCREMENT_SIZE = 10;
```

---

### 61. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2431 行
- **函数**: `allocate()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2428 | uint32 constant MAX_NONCE_INCREMENT_SIZE = 10;
   2429 | 
   2430 | // -- EIP712 type hash ---
>> 2431 | bytes32 constant ENABLE_TYPE_HASH = 0xb17ab1224aca0d4255ef8161acaf2ac121b8faa32a4b2258c912cc5f8308c505;
   2432 | bytes32 constant KERNEL_WRAPPER_TYPE_HASH = 0x1547321c374afde8a591d972a084b071c594c275e36724931ff96c25f2999c83;
   2433 | 
   2434 | // --- ERC constants ---
```

---

### 62. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2432 行
- **函数**: `allocate()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2429 | 
   2430 | // -- EIP712 type hash ---
   2431 | bytes32 constant ENABLE_TYPE_HASH = 0xb17ab1224aca0d4255ef8161acaf2ac121b8faa32a4b2258c912cc5f8308c505;
>> 2432 | bytes32 constant KERNEL_WRAPPER_TYPE_HASH = 0x1547321c374afde8a591d972a084b071c594c275e36724931ff96c25f2999c83;
   2433 | 
   2434 | // --- ERC constants ---
   2435 | // ERC4337 constants
```

---

### 63. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2750 行
- **函数**: `incrementNonce()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2747 | 
   2748 | library ExcessivelySafeCall {
   2749 |     uint256 constant LOW_28_MASK =
>> 2750 |         0x00000000ffffffffffffffffffffffffffffffffffffffffffffffffffffffff;
   2751 | 
   2752 |     /// @notice Use when you _really_ really _really_ don't trust the called
   2753 |     /// contract. This prevents the called contract from causing reversion of
```

---

### 64. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2898 行
- **函数**: `encodeFlag()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2895 | library ValidatorLib {
   2896 |     function encodeFlag(bool skipUserOp, bool skipSignature) internal pure returns (PassFlag flag) {
   2897 |         assembly {
>> 2898 |             if skipUserOp { flag := 0x0001000000000000000000000000000000000000000000000000000000000000 }
   2899 |             if skipSignature { flag := or(flag, 0x0002000000000000000000000000000000000000000000000000000000000000) }
   2900 |         }
   2901 |     }
```

---

### 65. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2899 行
- **函数**: `encodeFlag()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2896 |     function encodeFlag(bool skipUserOp, bool skipSignature) internal pure returns (PassFlag flag) {
   2897 |         assembly {
   2898 |             if skipUserOp { flag := 0x0001000000000000000000000000000000000000000000000000000000000000 }
>> 2899 |             if skipSignature { flag := or(flag, 0x0002000000000000000000000000000000000000000000000000000000000000) }
   2900 |         }
   2901 |     }
   2902 | 
```

---

### 66. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2905 行
- **函数**: `encodePolicyData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2902 | 
   2903 |     function encodePolicyData(bool skipUserOp, bool skipSig, address policy) internal pure returns (PolicyData data) {
   2904 |         assembly {
>> 2905 |             if skipUserOp { data := 0x0001000000000000000000000000000000000000000000000000000000000000 }
   2906 |             if skipSig { data := or(data, 0x0002000000000000000000000000000000000000000000000000000000000000) }
   2907 |             data := or(data, shl(80, policy))
   2908 |         }
```

---

### 67. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2906 行
- **函数**: `encodePolicyData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2903 |     function encodePolicyData(bool skipUserOp, bool skipSig, address policy) internal pure returns (PolicyData data) {
   2904 |         assembly {
   2905 |             if skipUserOp { data := 0x0001000000000000000000000000000000000000000000000000000000000000 }
>> 2906 |             if skipSig { data := or(data, 0x0002000000000000000000000000000000000000000000000000000000000000) }
   2907 |             data := or(data, shl(80, policy))
   2908 |         }
   2909 |     }
```

---

### 68. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2961 行
- **函数**: `decodeNonce()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2958 |             identifier := shl(8, nonce)
   2959 |             switch shr(248, identifier)
   2960 |             case 0x0000000000000000000000000000000000000000000000000000000000000002 {
>> 2961 |                 identifier := and(identifier, 0xffffffffff000000000000000000000000000000000000000000000000000000)
   2962 |             }
   2963 |         }
   2964 |     }
```

---

### 69. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2982 行
- **函数**: `decodeSignature()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2979 |                 sig.length := sub(signature.length, 21)
   2980 |             }
   2981 |             case 2 {
>> 2982 |                 vId := and(vId, 0xffffffffff000000000000000000000000000000000000000000000000000000)
   2983 |                 sig.offset := add(signature.offset, 5)
   2984 |                 sig.length := sub(signature.length, 5)
   2985 |             }
```

---

### 70. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2999 行
- **函数**: `validatorToIdentifier()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2996 | 
   2997 |     function validatorToIdentifier(IValidator validator) internal pure returns (ValidationId vId) {
   2998 |         assembly {
>> 2999 |             vId := 0x0100000000000000000000000000000000000000000000000000000000000000
   3000 |             vId := or(vId, shl(88, validator))
   3001 |         }
   3002 |     }
```

---

### 71. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3024 行
- **函数**: `permissionToIdentifier()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3021 | 
   3022 |     function permissionToIdentifier(PermissionId permissionId) internal pure returns (ValidationId vId) {
   3023 |         assembly {
>> 3024 |             vId := 0x0200000000000000000000000000000000000000000000000000000000000000
   3025 |             vId := or(vId, shr(8, permissionId))
   3026 |         }
   3027 |     }
```

---

### 72. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3062 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3059 |         // a mul b != 0 && xor(a,b) != 0
   3060 |         let sum := shl(96, add(a, b))
   3061 |         switch or(
>> 3062 |             iszero(and(xor(a, b), 0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff)),
   3063 |             or(eq(sum, shl(96, a)), eq(sum, shl(96, b)))
   3064 |         )
   3065 |         case 1 {
```

---

### 73. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3066 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3063 |             or(eq(sum, shl(96, a)), eq(sum, shl(96, b)))
   3064 |         )
   3065 |         case 1 {
>> 3066 |             validationData := and(or(a, b), 0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff)
   3067 |             // validAfter
   3068 |             let a_vd := and(0xffffffffffff0000000000000000000000000000000000000000000000000000, a)
   3069 |             let b_vd := and(0xffffffffffff0000000000000000000000000000000000000000000000000000, b)
```

---

### 74. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3068 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3065 |         case 1 {
   3066 |             validationData := and(or(a, b), 0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff)
   3067 |             // validAfter
>> 3068 |             let a_vd := and(0xffffffffffff0000000000000000000000000000000000000000000000000000, a)
   3069 |             let b_vd := and(0xffffffffffff0000000000000000000000000000000000000000000000000000, b)
   3070 |             validationData := or(validationData, xor(a_vd, mul(xor(a_vd, b_vd), gt(b_vd, a_vd))))
   3071 |             // validUntil
```

---

### 75. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3069 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3066 |             validationData := and(or(a, b), 0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff)
   3067 |             // validAfter
   3068 |             let a_vd := and(0xffffffffffff0000000000000000000000000000000000000000000000000000, a)
>> 3069 |             let b_vd := and(0xffffffffffff0000000000000000000000000000000000000000000000000000, b)
   3070 |             validationData := or(validationData, xor(a_vd, mul(xor(a_vd, b_vd), gt(b_vd, a_vd))))
   3071 |             // validUntil
   3072 |             a_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, a)
```

---

### 76. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3072 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3069 |             let b_vd := and(0xffffffffffff0000000000000000000000000000000000000000000000000000, b)
   3070 |             validationData := or(validationData, xor(a_vd, mul(xor(a_vd, b_vd), gt(b_vd, a_vd))))
   3071 |             // validUntil
>> 3072 |             a_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, a)
   3073 |             if iszero(a_vd) { a_vd := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
   3074 |             b_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, b)
   3075 |             if iszero(b_vd) { b_vd := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
```

---

### 77. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3073 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3070 |             validationData := or(validationData, xor(a_vd, mul(xor(a_vd, b_vd), gt(b_vd, a_vd))))
   3071 |             // validUntil
   3072 |             a_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, a)
>> 3073 |             if iszero(a_vd) { a_vd := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
   3074 |             b_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, b)
   3075 |             if iszero(b_vd) { b_vd := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
   3076 |             let until := xor(a_vd, mul(xor(a_vd, b_vd), lt(b_vd, a_vd)))
```

---

### 78. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3074 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3071 |             // validUntil
   3072 |             a_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, a)
   3073 |             if iszero(a_vd) { a_vd := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
>> 3074 |             b_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, b)
   3075 |             if iszero(b_vd) { b_vd := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
   3076 |             let until := xor(a_vd, mul(xor(a_vd, b_vd), lt(b_vd, a_vd)))
   3077 |             if iszero(until) { until := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
```

---

### 79. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3075 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3072 |             a_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, a)
   3073 |             if iszero(a_vd) { a_vd := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
   3074 |             b_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, b)
>> 3075 |             if iszero(b_vd) { b_vd := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
   3076 |             let until := xor(a_vd, mul(xor(a_vd, b_vd), lt(b_vd, a_vd)))
   3077 |             if iszero(until) { until := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
   3078 |             validationData := or(validationData, until)
```

---

### 80. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3077 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3074 |             b_vd := and(0x000000000000ffffffffffff0000000000000000000000000000000000000000, b)
   3075 |             if iszero(b_vd) { b_vd := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
   3076 |             let until := xor(a_vd, mul(xor(a_vd, b_vd), lt(b_vd, a_vd)))
>> 3077 |             if iszero(until) { until := 0x000000000000ffffffffffff0000000000000000000000000000000000000000 }
   3078 |             validationData := or(validationData, until)
   3079 |         }
   3080 |         default { validationData := SIG_VALIDATION_FAILED_UINT }
```

---

### 81. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 149 行
- **函数**: `upgradeTo()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    146 |     }
    147 | 
    148 |     function upgradeTo(address _newImplementation) external payable onlyEntryPointOrSelfOrRoot {
>>  149 |         assembly {
    150 |             sstore(ERC1967_IMPLEMENTATION_SLOT, _newImplementation)
    151 |         }
    152 |         emit Upgraded(_newImplementation);
```

---

### 82. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 207 行
- **函数**: `onERC1155BatchReceived()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    204 |             revert NotSupportedCallType();
    205 |         }
    206 |         if (!success) {
>>  207 |             assembly {
    208 |                 revert(add(result, 0x20), mload(result))
    209 |             }
    210 |         }
```

---

### 83. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 214 行
- **函数**: `onERC1155BatchReceived()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    211 |         if (address(config.hook) != address(1) && address(config.hook) != 0xFFfFfFffFFfffFFfFFfFFFFFffFFFffffFfFFFfF) {
    212 |             _doPostHook(config.hook, context);
    213 |         }
>>  214 |         assembly {
    215 |             return(add(result, 0x20), mload(result))
    216 |         }
    217 |     }
```

---

### 84. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 266 行
- **函数**: `validateUserOp()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    263 |             }
    264 |         }
    265 | 
>>  266 |         assembly {
    267 |             if missingAccountFunds {
    268 |                 pop(call(gas(), caller(), missingAccountFunds, callvalue(), callvalue(), callvalue(), callvalue()))
    269 |                 //ignore failure (its EntryPoint's job to verify, not account.)
```

---

### 85. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 362 行
- **函数**: `installModule()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    359 |             bytes calldata validatorData;
    360 |             bytes calldata hookData;
    361 |             bytes calldata selectorData;
>>  362 |             assembly {
    363 |                 validatorData.offset := add(add(initData.offset, 52), calldataload(add(initData.offset, 20)))
    364 |                 validatorData.length := calldataload(sub(validatorData.offset, 32))
    365 |                 hookData.offset := add(add(initData.offset, 52), calldataload(add(initData.offset, 52)))
```

---

### 86. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 378 行
- **函数**: `installModule()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    375 |         } else if (moduleType == MODULE_TYPE_EXECUTOR) {
    376 |             bytes calldata executorData;
    377 |             bytes calldata hookData;
>>  378 |             assembly {
    379 |                 executorData.offset := add(add(initData.offset, 52), calldataload(add(initData.offset, 20)))
    380 |                 executorData.length := calldataload(sub(executorData.offset, 32))
    381 |                 hookData.offset := add(add(initData.offset, 52), calldataload(add(initData.offset, 52)))
```

---

### 87. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 390 行
- **函数**: `installModule()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    387 |         } else if (moduleType == MODULE_TYPE_FALLBACK) {
    388 |             bytes calldata selectorData;
    389 |             bytes calldata hookData;
>>  390 |             assembly {
    391 |                 selectorData.offset := add(add(initData.offset, 56), calldataload(add(initData.offset, 24)))
    392 |                 selectorData.length := calldataload(sub(selectorData.offset, 32))
    393 |                 hookData.offset := add(add(initData.offset, 56), calldataload(add(initData.offset, 56)))
```

---

### 88. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1108 行
- **函数**: `_validationStorage()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1105 |     }
   1106 | 
   1107 |     function _validationStorage() internal pure returns (ValidationStorage storage state) {
>> 1108 |         assembly {
   1109 |             state.slot := VALIDATION_MANAGER_STORAGE_SLOT
   1110 |         }
   1111 |     }
```

---

### 89. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1179 行
- **函数**: `_uninstallPermission()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1176 | 
   1177 |     function _uninstallPermission(PermissionId pId, bytes calldata data) internal {
   1178 |         bytes[] calldata permissionDisableData;
>> 1179 |         assembly {
   1180 |             permissionDisableData.offset := add(add(data.offset, 32), calldataload(data.offset))
   1181 |             permissionDisableData.length := calldataload(sub(permissionDisableData.offset, 32))
   1182 |         }
```

---

### 90. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1248 行
- **函数**: `_installPermission()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1245 |     function _installPermission(PermissionId permission, bytes calldata data) internal {
   1246 |         ValidationStorage storage state = _validationStorage();
   1247 |         bytes[] calldata permissionEnableData;
>> 1248 |         assembly {
   1249 |             permissionEnableData.offset := add(add(data.offset, 32), calldataload(data.offset))
   1250 |             permissionEnableData.length := calldataload(sub(permissionEnableData.offset, 32))
   1251 |         }
```

---

### 91. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1329 行
- **函数**: `_enableMode()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1326 |     {
   1327 |         validationData = _enableValidationWithSig(vId, packedData);
   1328 | 
>> 1329 |         assembly {
   1330 |             userOpSig.offset := add(add(packedData.offset, 52), calldataload(add(packedData.offset, 148)))
   1331 |             userOpSig.length := calldataload(sub(userOpSig.offset, 32))
   1332 |         }
```

---

### 92. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1349 行
- **函数**: `_enableValidationWithSig()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1346 |             bytes calldata selectorData,
   1347 |             bytes32 digest
   1348 |         ) = _enableDigest(vId, packedData);
>> 1349 |         assembly {
   1350 |             enableSig.offset := add(add(packedData.offset, 52), calldataload(add(packedData.offset, 116)))
   1351 |             enableSig.length := calldataload(sub(enableSig.offset, 32))
   1352 |         }
```

---

### 93. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1391 行
- **函数**: `_configureSelector()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1388 |                 bytes calldata selectorInitData;
   1389 |                 bytes calldata hookInitData;
   1390 |                 IModule selectorModule = IModule(address(bytes20(selectorData[4:24])));
>> 1391 |                 assembly {
   1392 |                     selectorInitData.offset :=
   1393 |                         add(add(selectorData.offset, 76), calldataload(add(selectorData.offset, 44)))
   1394 |                     selectorInitData.length := calldataload(sub(selectorInitData.offset, 32))
```

---

### 94. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1401 行
- **函数**: `_configureSelector()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1398 |                 if (CallType.wrap(bytes1(selectorInitData[0])) == CALLTYPE_SINGLE && selectorModule.isModuleType(2)) {
   1399 |                     // also adds as executor when fallback module is also a executor
   1400 |                     bytes calldata executorHookData;
>> 1401 |                     assembly {
   1402 |                         executorHookData.offset :=
   1403 |                             add(add(selectorData.offset, 76), calldataload(add(selectorData.offset, 108)))
   1404 |                         executorHookData.length := calldataload(sub(executorHookData.offset, 32))
```

---

### 95. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1437 行
- **函数**: `_enableDigest()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1434 |         config.hook = IHook(address(bytes20(packedData[0:20])));
   1435 |         config.nonce = state.currentNonce;
   1436 | 
>> 1437 |         assembly {
   1438 |             validatorData.offset := add(add(packedData.offset, 52), calldataload(add(packedData.offset, 20)))
   1439 |             validatorData.length := calldataload(sub(validatorData.offset, 32))
   1440 |             hookData.offset := add(add(packedData.offset, 52), calldataload(add(packedData.offset, 52)))
```

---

### 96. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1674 行
- **函数**: `_executorConfig()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1671 |     function _executorConfig(IExecutor executor) internal view returns (ExecutorConfig storage config) {
   1672 |         ExecutorStorage storage es;
   1673 |         bytes32 slot = EXECUTOR_MANAGER_STORAGE_SLOT;
>> 1674 |         assembly {
   1675 |             es.slot := slot
   1676 |         }
   1677 |         config = es.executorConfig[executor];
```

---

### 97. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1744 行
- **函数**: `_selectorStorage()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1741 | 
   1742 |     function _selectorStorage() internal pure returns (SelectorStorage storage ss) {
   1743 |         bytes32 slot = SELECTOR_MANAGER_STORAGE_SLOT;
>> 1744 |         assembly {
   1745 |             ss.slot := slot
   1746 |         }
   1747 |     }
```

---

### 98. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 1940 行
- **函数**: `checkSignature()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1937 |         bytes32 separator;
   1938 |         if (!_domainNameAndVersionMayChange()) {
   1939 |             /// @solidity memory-safe-assembly
>> 1940 |             assembly {
   1941 |                 let m := mload(0x40) // Load the free memory pointer.
   1942 |                 mstore(m, _DOMAIN_TYPEHASH)
   1943 |                 mstore(add(m, 0x20), nameHash)
```

---

### 99. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2019 行
- **函数**: `_hashTypedData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2016 |             if (_cachedDomainSeparatorInvalidated()) digest = _buildDomainSeparator();
   2017 |         }
   2018 |         /// @solidity memory-safe-assembly
>> 2019 |         assembly {
   2020 |             // Compute the digest.
   2021 |             mstore(0x00, 0x1901000000000000) // Store "\x19\x01".
   2022 |             mstore(0x1a, digest) // Store the domain separator.
```

---

### 100. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2074 行
- **函数**: `_buildDomainSeparator()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2071 |             versionHash = _cachedVersionHash;
   2072 |         }
   2073 |         /// @solidity memory-safe-assembly
>> 2074 |         assembly {
   2075 |             let m := mload(0x40) // Load the free memory pointer.
   2076 |             mstore(m, _DOMAIN_TYPEHASH)
   2077 |             mstore(add(m, 0x20), separator) // Name hash.
```

---

### 101. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2090 行
- **函数**: `_cachedDomainSeparatorInvalidated()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2087 |         uint256 cachedChainId = _cachedChainId;
   2088 |         uint256 cachedThis = _cachedThis;
   2089 |         /// @solidity memory-safe-assembly
>> 2090 |         assembly {
   2091 |             result := iszero(and(eq(chainid(), cachedChainId), eq(address(), cachedThis)))
   2092 |         }
   2093 |     }
```

---

### 102. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2191 行
- **函数**: `execute()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2188 | 
   2189 |     function execute(address target, uint256 value, bytes calldata callData) internal returns (bytes memory result) {
   2190 |         /// @solidity memory-safe-assembly
>> 2191 |         assembly {
   2192 |             result := mload(0x40)
   2193 |             calldatacopy(result, callData.offset, callData.length)
   2194 |             if iszero(call(gas(), target, value, result, callData.length, codesize(), 0x00)) {
```

---

### 103. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2211 行
- **函数**: `tryExecute()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2208 |         returns (bool success, bytes memory result)
   2209 |     {
   2210 |         /// @solidity memory-safe-assembly
>> 2211 |         assembly {
   2212 |             result := mload(0x40)
   2213 |             calldatacopy(result, callData.offset, callData.length)
   2214 |             success := call(gas(), target, value, result, callData.length, codesize(), 0x00)
```

---

### 104. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2228 行
- **函数**: `executeDelegatecall()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2225 |         returns (bool success, bytes memory result)
   2226 |     {
   2227 |         /// @solidity memory-safe-assembly
>> 2228 |         assembly {
   2229 |             result := mload(0x40)
   2230 |             calldatacopy(result, callData.offset, callData.length)
   2231 |             // Forwards the `data` to `delegate` via delegatecall.
```

---

### 105. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2245 行
- **函数**: `decode()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2242 |         pure
   2243 |         returns (CallType _calltype, ExecType _execType, ExecModeSelector _modeSelector, ExecModePayload _modePayload)
   2244 |     {
>> 2245 |         assembly {
   2246 |             _calltype := mode
   2247 |             _execType := shl(8, mode)
   2248 |             _modeSelector := shl(48, mode)
```

---

### 106. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2272 行
- **函数**: `getCallType()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2269 |     }
   2270 | 
   2271 |     function getCallType(ExecMode mode) internal pure returns (CallType calltype) {
>> 2272 |         assembly {
   2273 |             calltype := mode
   2274 |         }
   2275 |     }
```

---

### 107. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2318 行
- **函数**: `doFallback2771Static()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2315 |     }
   2316 | 
   2317 |     function doFallback2771Static(address fallbackHandler) internal view returns (bool success, bytes memory result) {
>> 2318 |         assembly {
   2319 |             function allocate(length) -> pos {
   2320 |                 pos := mload(0x40)
   2321 |                 mstore(0x40, add(pos, length))
```

---

### 108. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2344 行
- **函数**: `doFallback2771Call()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2341 |     }
   2342 | 
   2343 |     function doFallback2771Call(address target) internal returns (bool success, bytes memory result) {
>> 2344 |         assembly {
   2345 |             function allocate(length) -> pos {
   2346 |                 pos := mload(0x40)
   2347 |                 mstore(0x40, add(pos, length))
```

---

### 109. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2546 行
- **函数**: `getValidationResult()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2543 | type ValidUntil is uint48;
   2544 | 
   2545 | function getValidationResult(ValidationData validationData) pure returns (address result) {
>> 2546 |     assembly {
   2547 |         result := validationData
   2548 |     }
   2549 | }
```

---

### 110. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2559 行
- **函数**: `parseValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2556 |     pure
   2557 |     returns (ValidAfter validAfter, ValidUntil validUntil, address result)
   2558 | {
>> 2559 |     assembly {
   2560 |         result := validationData
   2561 |         validUntil := and(shr(160, validationData), 0xffffffffffff)
   2562 |         switch iszero(validUntil)
```

---

### 111. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2783 行
- **函数**: `excessivelySafeCall()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2780 |         // by assembly calling "handle" function
   2781 |         // we call via assembly to avoid memcopying a very large returndata
   2782 |         // returned by a malicious contract
>> 2783 |         assembly {
   2784 |             _success := call(
   2785 |                 _gas, // gas
   2786 |                 _target, // recipient
```

---

### 112. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2835 行
- **函数**: `excessivelySafeStaticCall()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2832 |         // by assembly calling "handle" function
   2833 |         // we call via assembly to avoid memcopying a very large returndata
   2834 |         // returned by a malicious contract
>> 2835 |         assembly {
   2836 |             _success := staticcall(
   2837 |                 _gas, // gas
   2838 |                 _target, // recipient
```

---

### 113. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2872 行
- **函数**: `swapSelector()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2869 |     {
   2870 |         require(_buf.length >= 4);
   2871 |         uint256 _mask = LOW_28_MASK;
>> 2872 |         assembly {
   2873 |             // load the first word of
   2874 |             let _word := mload(add(_buf, 0x20))
   2875 |             // mask out the top 4 bytes
```

---

### 114. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2897 行
- **函数**: `encodeFlag()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2894 | 
   2895 | library ValidatorLib {
   2896 |     function encodeFlag(bool skipUserOp, bool skipSignature) internal pure returns (PassFlag flag) {
>> 2897 |         assembly {
   2898 |             if skipUserOp { flag := 0x0001000000000000000000000000000000000000000000000000000000000000 }
   2899 |             if skipSignature { flag := or(flag, 0x0002000000000000000000000000000000000000000000000000000000000000) }
   2900 |         }
```

---

### 115. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2904 行
- **函数**: `encodePolicyData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2901 |     }
   2902 | 
   2903 |     function encodePolicyData(bool skipUserOp, bool skipSig, address policy) internal pure returns (PolicyData data) {
>> 2904 |         assembly {
   2905 |             if skipUserOp { data := 0x0001000000000000000000000000000000000000000000000000000000000000 }
   2906 |             if skipSig { data := or(data, 0x0002000000000000000000000000000000000000000000000000000000000000) }
   2907 |             data := or(data, shl(80, policy))
```

---

### 116. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2926 行
- **函数**: `encodeAsNonce()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2923 |         pure
   2924 |         returns (uint256 res)
   2925 |     {
>> 2926 |         assembly {
   2927 |             res := nonce
   2928 |             res := or(res, shl(64, nonceKey))
   2929 |             res := or(res, shr(16, ValidationIdWithoutType))
```

---

### 117. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2940 行
- **函数**: `encodeAsNonceKey()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2937 |         pure
   2938 |         returns (uint192 res)
   2939 |     {
>> 2940 |         assembly {
   2941 |             res := or(nonceKey, shr(80, ValidationIdWithoutType))
   2942 |             res := or(res, shr(72, vType))
   2943 |             res := or(res, shr(64, mode))
```

---

### 118. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2955 行
- **函数**: `decodeNonce()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2952 |         // 2bytes mode (1byte currentMode, 1byte type)
   2953 |         // 21bytes identifier
   2954 |         // 1byte mode  | 1byte type | 20bytes identifierWithoutType | 2byte nonceKey | 8byte nonce == 32bytes
>> 2955 |         assembly {
   2956 |             mode := nonce
   2957 |             vType := shl(8, nonce)
   2958 |             identifier := shl(8, nonce)
```

---

### 119. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2967 行
- **函数**: `decodeSignature()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2964 |     }
   2965 | 
   2966 |     function decodeSignature(bytes calldata signature) internal pure returns (ValidationId vId, bytes calldata sig) {
>> 2967 |         assembly {
   2968 |             vId := calldataload(signature.offset)
   2969 |             switch shr(248, vId)
   2970 |             case 0 {
```

---

### 120. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2991 行
- **函数**: `decodePolicyData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2988 |     }
   2989 | 
   2990 |     function decodePolicyData(PolicyData data) internal pure returns (PassFlag flag, IPolicy policy) {
>> 2991 |         assembly {
   2992 |             flag := data
   2993 |             policy := shr(80, data)
   2994 |         }
```

---

### 121. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 2998 行
- **函数**: `validatorToIdentifier()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2995 |     }
   2996 | 
   2997 |     function validatorToIdentifier(IValidator validator) internal pure returns (ValidationId vId) {
>> 2998 |         assembly {
   2999 |             vId := 0x0100000000000000000000000000000000000000000000000000000000000000
   3000 |             vId := or(vId, shl(88, validator))
   3001 |         }
```

---

### 122. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3005 行
- **函数**: `getType()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3002 |     }
   3003 | 
   3004 |     function getType(ValidationId validator) internal pure returns (ValidationType vType) {
>> 3005 |         assembly {
   3006 |             vType := validator
   3007 |         }
   3008 |     }
```

---

### 123. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3011 行
- **函数**: `getValidator()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3008 |     }
   3009 | 
   3010 |     function getValidator(ValidationId validator) internal pure returns (IValidator v) {
>> 3011 |         assembly {
   3012 |             v := shr(88, validator)
   3013 |         }
   3014 |     }
```

---

### 124. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3017 行
- **函数**: `getPermissionId()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3014 |     }
   3015 | 
   3016 |     function getPermissionId(ValidationId validator) internal pure returns (PermissionId id) {
>> 3017 |         assembly {
   3018 |             id := shl(8, validator)
   3019 |         }
   3020 |     }
```

---

### 125. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3023 行
- **函数**: `permissionToIdentifier()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3020 |     }
   3021 | 
   3022 |     function permissionToIdentifier(PermissionId permissionId) internal pure returns (ValidationId vId) {
>> 3023 |         assembly {
   3024 |             vId := 0x0200000000000000000000000000000000000000000000000000000000000000
   3025 |             vId := or(vId, shr(8, permissionId))
   3026 |         }
```

---

### 126. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3030 行
- **函数**: `getPolicy()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3027 |     }
   3028 | 
   3029 |     function getPolicy(PolicyData data) internal pure returns (IPolicy vId) {
>> 3030 |         assembly {
   3031 |             vId := shr(80, data)
   3032 |         }
   3033 |     }
```

---

### 127. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3036 行
- **函数**: `getPermissionSkip()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3033 |     }
   3034 | 
   3035 |     function getPermissionSkip(PolicyData data) internal pure returns (PassFlag flag) {
>> 3036 |         assembly {
   3037 |             flag := data
   3038 |         }
   3039 |     }
```

---

### 128. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x37ad5104056F6C158D305c50577aca5515Ca20ae` 第 3052 行
- **函数**: `_intersectValidationData()`
- **合约**: `Kernel`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3049 | import {ValidationData, getValidationResult} from "../types/Types.sol";
   3050 | 
   3051 | function _intersectValidationData(ValidationData a, ValidationData b) pure returns (ValidationData validationData) {
>> 3052 |     assembly {
   3053 |         // xor(a,b) == shows only matching bits
   3054 |         // and(xor(a,b), 0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff) == filters out the validAfter and validUntil bits
   3055 |         // if the result is not zero, then aggregator part is not matching
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*