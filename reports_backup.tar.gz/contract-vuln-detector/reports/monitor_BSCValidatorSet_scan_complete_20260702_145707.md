# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:57:07
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x0000000000000000000000000000000000001000` |
| contract_name | `BSCValidatorSet` |
| compiler_version | `v0.6.4+commit.1dca32f3` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `Apache-2.0` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655005` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 43 |
| 🟢 LOW | 135 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol` 第 1826 行
- **函数**: `updateValidatorSetV2()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in BSCValidatorSet.updateValidatorSetV2(address[],uint64[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1826-1875):
	External calls:
	- (validatorSetTemp,voteAddrsTemp) = _forceMaintainingValidatorsExit(_validatorSet,_voteAddrs) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1848-1849)
		- ISlashIndicator(SLASH_CONTRACT_ADDR).downtimeSlash(validator,slashCount,shouldRevert) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2695)
	- IStakeHub(STAKE_HUB_ADDR).distributeReward{value: incoming}(currentValidatorSet[i_scope_0].consensusAddress) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1856)
	External calls sending eth:
	- IStakeHub(STAKE_HUB_ADDR).distributeReward{value: incoming}(currentValidatorSet[i_scope_0].consensusAddress) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1856)
	State variables written after the call(s):
	- currentValidatorSet[i_scope_0].incoming = 0 (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1855)
	BSCValidatorSet.currentValidatorSet (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1666) can be used in cross function reentrancies:
	- BSCValidatorSet._felony(address,uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2549-2579)
	- BSCValidatorSet._forceMaintainingValidatorsExit(BSCValidatorSet.Validator[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2581-2659)
	- BSCValidatorSet._misdemeanor(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2517-2547)
	- BSCValidatorSet.canEnterMaintenance(uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2191-2209)
	- BSCValidatorSet.currentValidatorSet (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1666)
	- BSCValidatorSet.deposit(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1882-1930)
	- BSCValidatorSet.distributeFinalityReward(address[],uint256[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1932-1981)
	- BSCValidatorSet.doUpdateState(BSCValidatorSet.Validator[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2324-2391)
	- BSCValidatorSet.getIncoming(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2092-2098)
	- BSCValidatorSet.getLivingValidators() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1987-2015)
	- BSCValidatorSet.getValidators() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2070-2087)
	- BSCValidatorSet.getVoteAddresses(address[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2428-2442)
	- BSCValidatorSet.init() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1793-1802)
	- BSCValidatorSet.initValidatorExtraSet() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1748-1759)
	- BSCValidatorSet.isWorkingValidator(uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2105-2116)
	- BSCValidatorSet.updateValidatorSetV2(address[],uint64[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1826-1875)

**代码片段**:
```solidity
   1823 |     /**
   1824 |      * @dev Update validator set method after fusion fork.
   1825 |      */
>> 1826 |     function updateValidatorSetV2(
   1827 |         address[] memory _consensusAddrs,
   1828 |         uint64[] memory _votingPowers,
   1829 |         bytes[] memory _voteAddrs
```

---

### 2. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol` 第 1826 行
- **函数**: `updateValidatorSetV2()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in BSCValidatorSet.updateValidatorSetV2(address[],uint64[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1826-1875):
	External calls:
	- (validatorSetTemp,voteAddrsTemp) = _forceMaintainingValidatorsExit(_validatorSet,_voteAddrs) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1848-1849)
		- ISlashIndicator(SLASH_CONTRACT_ADDR).downtimeSlash(validator,slashCount,shouldRevert) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2695)
	- IStakeHub(STAKE_HUB_ADDR).distributeReward{value: incoming}(currentValidatorSet[i_scope_0].consensusAddress) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1856)
	External calls sending eth:
	- IStakeHub(STAKE_HUB_ADDR).distributeReward{value: incoming}(currentValidatorSet[i_scope_0].consensusAddress) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1856)
	- address(uint160(SYSTEM_REWARD_ADDR)).transfer(address(this).balance) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1863)
	State variables written after the call(s):
	- doUpdateState(validatorSetTemp,voteAddrsTemp) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1869)
		- currentValidatorSet.pop() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2346)
		- currentValidatorSet[i_scope_1] = newValidatorSet[i_scope_1] (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2356)
		- currentValidatorSet[i_scope_1].votingPower = newValidatorSet[i_scope_1].votingPower (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2361)
		- currentValidatorSet.push(newValidatorSet[i_scope_2]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2373)
	BSCValidatorSet.currentValidatorSet (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1666) can be used in cross function reentrancies:
	- BSCValidatorSet._felony(address,uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2549-2579)
	- BSCValidatorSet._forceMaintainingValidatorsExit(BSCValidatorSet.Validator[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2581-2659)
	- BSCValidatorSet._misdemeanor(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2517-2547)
	- BSCValidatorSet.canEnterMaintenance(uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2191-2209)
	- BSCValidatorSet.currentValidatorSet (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1666)
	- BSCValidatorSet.deposit(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1882-1930)
	- BSCValidatorSet.distributeFinalityReward(address[],uint256[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1932-1981)
	- BSCValidatorSet.doUpdateState(BSCValidatorSet.Validator[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2324-2391)
	- BSCValidatorSet.getIncoming(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2092-2098)
	- BSCValidatorSet.getLivingValidators() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1987-2015)
	- BSCValidatorSet.getValidators() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2070-2087)
	- BSCValidatorSet.getVoteAddresses(address[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2428-2442)
	- BSCValidatorSet.init() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1793-1802)
	- BSCValidatorSet.initValidatorExtraSet() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1748-1759)
	- BSCValidatorSet.isWorkingValidator(uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2105-2116)
	- BSCValidatorSet.updateValidatorSetV2(address[],uint64[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1826-1875)
	- doUpdateState(validatorSetTemp,voteAddrsTemp) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1869)
		- delete currentValidatorSetMap[oldValidator.consensusAddress] (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2339)
		- currentValidatorSetMap[newValidatorSet[i_scope_1].consensusAddress] = i_scope_1 + 1 (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2355)
		- currentValidatorSetMap[newValidatorSet[i_scope_2].consensusAddress] = i_scope_2 + 1 (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2375)
	BSCValidatorSet.currentValidatorSetMap (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1672) can be used in cross function reentrancies:
	- BSCValidatorSet._felony(address,uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2549-2579)
	- BSCValidatorSet._misdemeanor(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2517-2547)
	- BSCValidatorSet.currentValidatorSetMap (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1672)
	- BSCValidatorSet.deposit(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1882-1930)
	- BSCValidatorSet.distributeFinalityReward(address[],uint256[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1932-1981)
	- BSCValidatorSet.doUpdateState(BSCValidatorSet.Validator[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2324-2391)
	- BSCValidatorSet.felony(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2167-2181)
	- BSCValidatorSet.getCurrentValidatorIndex(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2136-2142)
	- BSCValidatorSet.getIncoming(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2092-2098)
	- BSCValidatorSet.getVoteAddresses(address[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2428-2442)
	- BSCValidatorSet.init() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1793-1802)
	- BSCValidatorSet.isCurrentValidator(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2122-2131)
	- doUpdateState(validatorSetTemp,voteAddrsTemp) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1869)
		- numOfMaintaining = 0 (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2385)
	BSCValidatorSet.numOfMaintaining (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1686) can be used in cross function reentrancies:
	- BSCValidatorSet._enterMaintenance(address,uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2661-2666)
	- BSCValidatorSet._exitMaintenance(address,uint256,uint256,bool) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2668-2702)
	- BSCValidatorSet.canEnterMaintenance(uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2191-2209)
	- BSCValidatorSet.doUpdateState(BSCValidatorSet.Validator[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2324-2391)
	- BSCValidatorSet.felony(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2167-2181)
	- BSCValidatorSet.numOfMaintaining (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1686)
	- doUpdateState(validatorSetTemp,voteAddrsTemp) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1869)
		- validatorExtraSet.pop() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2347)
		- validatorExtraSet[i_scope_1].voteAddress = newVoteAddrs[i_scope_1] (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2357)
		- validatorExtraSet[i_scope_1].isMaintaining = false (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2358)
		- validatorExtraSet[i_scope_1].enterMaintenanceHeight = 0 (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2359)
		- validatorExtraSet[i_scope_1].voteAddress = newVoteAddrs[i_scope_1] (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2364)
		- validatorExtraSet.push(_validatorExtra) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2374)
		- validatorExtraSet[i_scope_3].isMaintaining = false (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2388)
		- validatorExtraSet[i_scope_3].enterMaintenanceHeight = 0 (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2389)
	BSCValidatorSet.validatorExtraSet (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1691) can be used in cross function reentrancies:
	- BSCValidatorSet._enterMaintenance(address,uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2661-2666)
	- BSCValidatorSet._exitMaintenance(address,uint256,uint256,bool) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2668-2702)
	- BSCValidatorSet._felony(address,uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2549-2579)
	- BSCValidatorSet._forceMaintainingValidatorsExit(BSCValidatorSet.Validator[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2581-2659)
	- BSCValidatorSet.canEnterMaintenance(uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2191-2209)
	- BSCValidatorSet.doUpdateState(BSCValidatorSet.Validator[],bytes[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2324-2391)
	- BSCValidatorSet.exitMaintenance() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2231-2238)
	- BSCValidatorSet.felony(address) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2167-2181)
	- BSCValidatorSet.getLivingValidators() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1987-2015)
	- BSCValidatorSet.getVoteAddresses(address[]) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2428-2442)
	- BSCValidatorSet.initValidatorExtraSet() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1748-1759)
	- BSCValidatorSet.isWorkingValidator(uint256) (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2105-2116)
	- BSCValidatorSet.setCurrentVoteAddrFullSet() (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#2475-2497)
	- BSCValidatorSet.validatorExtraSet (../../../tmp/slither_scan_gnvxqu_b/0x0000000000000000000000000000000000001000.sol#1691)

**代码片段**:
```solidity
   1823 |     /**
   1824 |      * @dev Update validator set method after fusion fork.
   1825 |      */
>> 1826 |     function updateValidatorSetV2(
   1827 |         address[] memory _consensusAddrs,
   1828 |         uint64[] memory _votingPowers,
   1829 |         bytes[] memory _voteAddrs
```

---

### 3. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2038 行
- **函数**: `getMiningValidators()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   2035 |             _maxNumOfWorkingCandidates = validators.length - _numOfCabinets;
   2036 |         }
   2037 |         if (_maxNumOfWorkingCandidates > 0) {
>> 2038 |             uint256 shuffleNumber = block.number / _shuffleInterval;
   2039 |             shuffle(
   2040 |                 validators,
   2041 |                 voteAddrs,
```

---

### 4. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2683 行
- **函数**: `_exitMaintenance()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   2680 |         --numOfMaintaining;
   2681 | 
   2682 |         // step 1: calculate slashCount
>> 2683 |         uint256 slashCount = block.number.sub(validatorExtraSet[index].enterMaintenanceHeight).div(miningValidatorCount)
   2684 |             .div(maintainSlashScale);
   2685 | 
   2686 |         // step 2: clear isMaintaining info
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 949 行
- **函数**: `isCurrentValidator()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    946 | interface IBSCValidatorSet {
    947 |     function misdemeanor(address validator) external;
    948 |     function felony(address validator) external;
>>  949 |     function isCurrentValidator(address validator) external view returns (bool);
    950 |     function getLivingValidators() external view returns (address[] memory, bytes[] memory);
    951 |     function getMiningValidators() external view returns (address[] memory, bytes[] memory);
    952 |     function isMonitoredForMaliciousVote(bytes calldata voteAddr) external view returns (bool);
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 950 行
- **函数**: `getLivingValidators()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    947 |     function misdemeanor(address validator) external;
    948 |     function felony(address validator) external;
    949 |     function isCurrentValidator(address validator) external view returns (bool);
>>  950 |     function getLivingValidators() external view returns (address[] memory, bytes[] memory);
    951 |     function getMiningValidators() external view returns (address[] memory, bytes[] memory);
    952 |     function isMonitoredForMaliciousVote(bytes calldata voteAddr) external view returns (bool);
    953 | }
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 951 行
- **函数**: `getMiningValidators()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    948 |     function felony(address validator) external;
    949 |     function isCurrentValidator(address validator) external view returns (bool);
    950 |     function getLivingValidators() external view returns (address[] memory, bytes[] memory);
>>  951 |     function getMiningValidators() external view returns (address[] memory, bytes[] memory);
    952 |     function isMonitoredForMaliciousVote(bytes calldata voteAddr) external view returns (bool);
    953 | }
    954 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 952 行
- **函数**: `isMonitoredForMaliciousVote()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    949 |     function isCurrentValidator(address validator) external view returns (bool);
    950 |     function getLivingValidators() external view returns (address[] memory, bytes[] memory);
    951 |     function getMiningValidators() external view returns (address[] memory, bytes[] memory);
>>  952 |     function isMonitoredForMaliciousVote(bytes calldata voteAddr) external view returns (bool);
    953 | }
    954 | 
    955 | // contracts/interface/0.6.x/ILightClient.sol
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 958 行
- **函数**: `isHeaderSynced()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    955 | // contracts/interface/0.6.x/ILightClient.sol
    956 | 
    957 | interface ILightClient {
>>  958 |     function isHeaderSynced(uint64 height) external view returns (bool);
    959 | 
    960 |     function getAppHash(uint64 height) external view returns (bytes32);
    961 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 960 行
- **函数**: `getAppHash()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    957 | interface ILightClient {
    958 |     function isHeaderSynced(uint64 height) external view returns (bool);
    959 | 
>>  960 |     function getAppHash(uint64 height) external view returns (bytes32);
    961 | 
    962 |     function getSubmitter(uint64 height) external view returns (address payable);
    963 | }
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 962 行
- **函数**: `getSubmitter()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    959 | 
    960 |     function getAppHash(uint64 height) external view returns (bytes32);
    961 | 
>>  962 |     function getSubmitter(uint64 height) external view returns (address payable);
    963 | }
    964 | 
    965 | // contracts/interface/0.6.x/IParamSubscriber.sol
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 974 行
- **函数**: `isRelayer()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    971 | // contracts/interface/0.6.x/IRelayerHub.sol
    972 | 
    973 | interface IRelayerHub {
>>  974 |     function isRelayer(address sender) external view returns (bool);
    975 | }
    976 | 
    977 | // contracts/interface/0.6.x/ISlashIndicator.sol
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 983 行
- **函数**: `getSlashThresholds()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    980 |     function clean() external;
    981 |     function downtimeSlash(address validator, uint256 count, bool shouldRevert) external;
    982 |     function sendFelonyPackage(address validator) external;
>>  983 |     function getSlashThresholds() external view returns (uint256, uint256);
    984 | }
    985 | 
    986 | // contracts/interface/0.6.x/IStakeHub.sol
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 992 行
- **函数**: `voteToOperator()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    989 |     function downtimeSlash(address validator) external;
    990 |     function maliciousVoteSlash(bytes calldata voteAddress) external;
    991 |     function doubleSignSlash(address validator) external;
>>  992 |     function voteToOperator(bytes calldata voteAddress) external view returns (address);
    993 |     function consensusToOperator(address validator) external view returns (address);
    994 |     function getValidatorConsensusAddress(address validator) external view returns (address);
    995 |     function getValidatorCreditContract(address validator) external view returns (address);
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 993 行
- **函数**: `consensusToOperator()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    990 |     function maliciousVoteSlash(bytes calldata voteAddress) external;
    991 |     function doubleSignSlash(address validator) external;
    992 |     function voteToOperator(bytes calldata voteAddress) external view returns (address);
>>  993 |     function consensusToOperator(address validator) external view returns (address);
    994 |     function getValidatorConsensusAddress(address validator) external view returns (address);
    995 |     function getValidatorCreditContract(address validator) external view returns (address);
    996 |     function getValidatorVoteAddress(address validator) external view returns (bytes memory);
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 994 行
- **函数**: `getValidatorConsensusAddress()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    991 |     function doubleSignSlash(address validator) external;
    992 |     function voteToOperator(bytes calldata voteAddress) external view returns (address);
    993 |     function consensusToOperator(address validator) external view returns (address);
>>  994 |     function getValidatorConsensusAddress(address validator) external view returns (address);
    995 |     function getValidatorCreditContract(address validator) external view returns (address);
    996 |     function getValidatorVoteAddress(address validator) external view returns (bytes memory);
    997 |     function maxElectedValidators() external view returns (uint256);
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 995 行
- **函数**: `getValidatorCreditContract()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    992 |     function voteToOperator(bytes calldata voteAddress) external view returns (address);
    993 |     function consensusToOperator(address validator) external view returns (address);
    994 |     function getValidatorConsensusAddress(address validator) external view returns (address);
>>  995 |     function getValidatorCreditContract(address validator) external view returns (address);
    996 |     function getValidatorVoteAddress(address validator) external view returns (bytes memory);
    997 |     function maxElectedValidators() external view returns (uint256);
    998 |     function distributeReward(address validator) external payable;
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 996 行
- **函数**: `getValidatorVoteAddress()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    993 |     function consensusToOperator(address validator) external view returns (address);
    994 |     function getValidatorConsensusAddress(address validator) external view returns (address);
    995 |     function getValidatorCreditContract(address validator) external view returns (address);
>>  996 |     function getValidatorVoteAddress(address validator) external view returns (bytes memory);
    997 |     function maxElectedValidators() external view returns (uint256);
    998 |     function distributeReward(address validator) external payable;
    999 | }
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 997 行
- **函数**: `maxElectedValidators()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    994 |     function getValidatorConsensusAddress(address validator) external view returns (address);
    995 |     function getValidatorCreditContract(address validator) external view returns (address);
    996 |     function getValidatorVoteAddress(address validator) external view returns (bytes memory);
>>  997 |     function maxElectedValidators() external view returns (uint256);
    998 |     function distributeReward(address validator) external payable;
    999 | }
   1000 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 998 行
- **函数**: `distributeReward()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    995 |     function getValidatorCreditContract(address validator) external view returns (address);
    996 |     function getValidatorVoteAddress(address validator) external view returns (bytes memory);
    997 |     function maxElectedValidators() external view returns (uint256);
>>  998 |     function distributeReward(address validator) external payable;
    999 | }
   1000 | 
   1001 | // contracts/interface/0.6.x/ISystemReward.sol
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1004 行
- **函数**: `claimRewards()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1001 | // contracts/interface/0.6.x/ISystemReward.sol
   1002 | 
   1003 | interface ISystemReward {
>> 1004 |     function claimRewards(address payable to, uint256 amount) external returns (uint256 actualAmount);
   1005 | }
   1006 | 
   1007 | // contracts/lib/0.6.x/Memory.sol
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1793 行
- **函数**: `init()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1790 |     event tmpValidatorSetUpdated(uint256 validatorsNum);  // @dev deprecated
   1791 | 
   1792 |     /*----------------- init -----------------*/
>> 1793 |     function init() external onlyNotInit {
   1794 |         (ValidatorSetPackage memory validatorSetPkg, bool valid) =
   1795 |             decodeValidatorSet(INIT_VALIDATORSET_BYTES);
   1796 |         require(valid, "failed to parse init validatorSet");
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1814 行
- **函数**: `handleAckPackage()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1811 |         revert("deprecated");
   1812 |     }
   1813 | 
>> 1814 |     function handleAckPackage(uint8 channelId, bytes calldata msgBytes) external override onlyCrossChainContract {
   1815 |         revert("deprecated");
   1816 |     }
   1817 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1818 行
- **函数**: `handleFailAckPackage()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1815 |         revert("deprecated");
   1816 |     }
   1817 | 
>> 1818 |     function handleFailAckPackage(uint8 channelId, bytes calldata msgBytes) external override onlyCrossChainContract {
   1819 |         revert("deprecated");
   1820 |     }
   1821 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1882 行
- **函数**: `deposit()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1879 |      *
   1880 |      * @param valAddr The validator address who produced the current block
   1881 |      */
>> 1882 |     function deposit(address valAddr) external payable onlyCoinbase onlyInit noEmptyDeposit onlyZeroGasPrice {
   1883 |         uint256 value = msg.value;
   1884 |         uint256 index = currentValidatorSetMap[valAddr];
   1885 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1987 行
- **函数**: `getLivingValidators()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1984 |     /**
   1985 |      * @notice Return the vote address and consensus address of the validators in `currentValidatorSet` that are not jailed
   1986 |      */
>> 1987 |     function getLivingValidators() external view override returns (address[] memory, bytes[] memory) {
   1988 |         uint256 n = currentValidatorSet.length;
   1989 |         uint256 living;
   1990 |         for (uint256 i; i < n; ++i) {
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2023 行
- **函数**: `getMiningValidators()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2020 |      * Mining validators are block producers in the current epoch
   2021 |      * including most of the cabinets and a few of the candidates
   2022 |      */
>> 2023 |     function getMiningValidators() external view override returns (address[] memory, bytes[] memory) {
   2024 |         uint256 _maxNumOfWorkingCandidates = maxNumOfWorkingCandidates;
   2025 |         uint256 _numOfCabinets = numOfCabinets > 0 ? numOfCabinets : INIT_NUM_OF_CABINETS;
   2026 |         uint256 _shuffleInterval = 200;
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2070 行
- **函数**: `getValidators()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2067 |     /**
   2068 |      * @notice Return the consensus address of the validators in `currentValidatorSet` that are not jailed and not maintaining
   2069 |      */
>> 2070 |     function getValidators() public view returns (address[] memory) {
   2071 |         uint256 n = currentValidatorSet.length;
   2072 |         uint256 valid = 0;
   2073 |         for (uint256 i; i < n; ++i) {
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2092 行
- **函数**: `getIncoming()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2089 |     /**
   2090 |      * @notice Return the current incoming of the validator
   2091 |      */
>> 2092 |     function getIncoming(address validator) external view returns (uint256) {
   2093 |         uint256 index = currentValidatorSetMap[validator];
   2094 |         if (index <= 0) {
   2095 |             return 0;
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2105 行
- **函数**: `isWorkingValidator()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2102 |      *
   2103 |      * @param index The index of the validator in `currentValidatorSet`(from 0 to `currentValidatorSet.length-1`)
   2104 |      */
>> 2105 |     function isWorkingValidator(uint256 index) public view returns (bool) {
   2106 |         if (index >= currentValidatorSet.length) {
   2107 |             return false;
   2108 |         }
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2122 行
- **函数**: `isCurrentValidator()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2119 |      * @notice Return whether the validator is a working validator(not jailed or maintaining) by consensus address
   2120 |      * Will return false if the validator is not in `currentValidatorSet`
   2121 |      */
>> 2122 |     function isCurrentValidator(address validator) external view override returns (bool) {
   2123 |         uint256 index = currentValidatorSetMap[validator];
   2124 |         if (index <= 0) {
   2125 |             return false;
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2136 行
- **函数**: `getCurrentValidatorIndex()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2133 |     /**
   2134 |      * @notice Return the index of the validator in `currentValidatorSet`(from 0 to `currentValidatorSet.length-1`)
   2135 |      */
>> 2136 |     function getCurrentValidatorIndex(address validator) public view returns (uint256) {
   2137 |         uint256 index = currentValidatorSetMap[validator];
   2138 |         require(index > 0, "only current validators");
   2139 | 
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2148 行
- **函数**: `getWorkingValidatorCount()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2145 |      * @notice Return the number of mining validators.
   2146 |      * The function name is misleading, it should be `getMiningValidatorCount`. But it's kept for compatibility.
   2147 |      */
>> 2148 |     function getWorkingValidatorCount() public view returns (uint256 workingValidatorCount) {
   2149 |         workingValidatorCount = getValidators().length;
   2150 |         uint256 _numOfCabinets = numOfCabinets > 0 ? numOfCabinets : INIT_NUM_OF_CABINETS;
   2151 |         if (workingValidatorCount > _numOfCabinets) {
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2160 行
- **函数**: `misdemeanor()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2157 |     }
   2158 | 
   2159 |     /*----------------- For slash -----------------*/
>> 2160 |     function misdemeanor(address validator) external override onlySlash initValidatorExtraSet {
   2161 |         uint256 validatorIndex = _misdemeanor(validator);
   2162 |         if (canEnterMaintenance(validatorIndex)) {
   2163 |             _enterMaintenance(validator, validatorIndex);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2167 行
- **函数**: `felony()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2164 |         }
   2165 |     }
   2166 | 
>> 2167 |     function felony(address validator) external override initValidatorExtraSet {
   2168 |         require(msg.sender == SLASH_CONTRACT_ADDR || msg.sender == STAKE_HUB_ADDR, "only slash or stakeHub contract");
   2169 | 
   2170 |         uint256 index = currentValidatorSetMap[validator];
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2183 行
- **函数**: `removeTmpMigratedValidator()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2180 |         }
   2181 |     }
   2182 | 
>> 2183 |     function removeTmpMigratedValidator(address validator) external onlyStakeHub {
   2184 |         revert("deprecated");
   2185 |     }
   2186 | 
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2191 行
- **函数**: `canEnterMaintenance()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2188 |     /**
   2189 |      * @notice Return whether the validator at index could enter maintenance
   2190 |      */
>> 2191 |     function canEnterMaintenance(uint256 index) public view returns (bool) {
   2192 |         if (index >= currentValidatorSet.length) {
   2193 |             return false;
   2194 |         }
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2214 行
- **函数**: `enterMaintenance()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2211 |     /**
   2212 |      * @dev Enter maintenance for current validators. refer to https://github.com/bnb-chain/BEPs/blob/master/BEP127.md
   2213 |      */
>> 2214 |     function enterMaintenance() external initValidatorExtraSet {
   2215 |         // check maintain config
   2216 |         if (maxNumOfMaintaining == 0) {
   2217 |             maxNumOfMaintaining = INIT_MAX_NUM_OF_MAINTAINING;
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2231 行
- **函数**: `exitMaintenance()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2228 |     /**
   2229 |      * @dev Exit maintenance for current validators. refer to https://github.com/bnb-chain/BEPs/blob/master/BEP127.md
   2230 |      */
>> 2231 |     function exitMaintenance() external {
   2232 |         uint256 index = getCurrentValidatorIndex(msg.sender);
   2233 | 
   2234 |         // jailed validators are allowed to exit maintenance
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2241 行
- **函数**: `updateParam()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2238 |     }
   2239 | 
   2240 |     /*----------------- Param update -----------------*/
>> 2241 |     function updateParam(string calldata key, bytes calldata value) external override onlyInit onlyGov {
   2242 |         if (Memory.compareStrings(key, "burnRatio")) {
   2243 |             require(value.length == 32, "length of burnRatio mismatch");
   2244 |             uint256 newBurnRatio = BytesToTypes.bytesToUint256(32, value);
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2444 行
- **函数**: `getTurnLength()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2441 |         return voteAddrs;
   2442 |     }
   2443 | 
>> 2444 |     function getTurnLength() external view returns (uint256) {
   2445 |         if (turnLength == 0) {
   2446 |             return 1;
   2447 |         }
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2499 行
- **函数**: `isMonitoredForMaliciousVote()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2496 |         }
   2497 |     }
   2498 | 
>> 2499 |     function isMonitoredForMaliciousVote(bytes calldata voteAddr) external view override returns (bool) {
   2500 |         uint256 m = currentVoteAddrFullSet.length;
   2501 |         for (uint256 i; i < m; ++i) {
   2502 |             if (BytesLib.equal(voteAddr, currentVoteAddrFullSet[i])) {
```

---

### 43. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 481 行
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    476 | // contracts/lib/0.6.x/BytesToTypes.sol
    477 | 
    478 | /**
    479 |  * @title BytesToTypes
    480 |  * Copyright (c) 2016-2020 zpouladzade/Seriality
>>  481 |  * @dev The BytesToTypes contract converts the memory byte arrays to the standard solidity types
    482 |  * @author pouladzade@gmail.com
    483 |  */
    484 | library BytesToTypes {
    485 |     function bytesToAddress(uint256 _offst, bytes memory _input) internal pure returns (address _output) {
    486 |         assembly {
```

---

### 44. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1545 行
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1540 |     }
   1541 | }
   1542 | 
   1543 | // contracts/System.sol
   1544 | 
>> 1545 | contract System {
   1546 |     bool public alreadyInit;
   1547 | 
   1548 |     uint32 public constant CODE_OK = 0;
   1549 |     uint16 public constant bscChainID = 0x0038;
   1550 |     address public constant VALIDATOR_CONTRACT_ADDR = 0x0000000000000000000000000000000000001000;
```

---

### 45. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1655 行
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1650 |     }
   1651 | }
   1652 | 
   1653 | // contracts/BSCValidatorSet.sol
   1654 | 
>> 1655 | contract BSCValidatorSet is IBSCValidatorSet, System, IParamSubscriber, IApplication {
   1656 |     using SafeMath for uint256;
   1657 | 
   1658 |     using RLPDecode for *;
   1659 | 
   1660 |     bytes public constant INIT_VALIDATORSET_BYTES =
```

---

### 46. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1863 行
- **函数**: `updateValidatorSetV2()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1860 |         // step 2: do dusk transfer
   1861 |         if (address(this).balance > 0) {
   1862 |             emit systemTransfer(address(this).balance);
>> 1863 |             address(uint160(SYSTEM_REWARD_ADDR)).transfer(address(this).balance);
   1864 |         }
   1865 | 
   1866 |         // step 3: do update validator set state
```

---

### 47. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1900 行
- **函数**: `deposit()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1897 |         if (value > 0 && systemRewardRatio > 0) {
   1898 |             uint256 toSystemReward = msg.value.mul(systemRewardRatio).div(BLOCK_FEES_RATIO_SCALE);
   1899 |             if (toSystemReward > 0) {
>> 1900 |                 address(uint160(SYSTEM_REWARD_ADDR)).transfer(toSystemReward);
   1901 |                 emit systemTransfer(toSystemReward);
   1902 | 
   1903 |                 value = value.sub(toSystemReward);
```

---

### 48. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1910 行
- **函数**: `deposit()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1907 |         if (value > 0 && burnRatio > 0) {
   1908 |             uint256 toBurn = msg.value.mul(burnRatio).div(BLOCK_FEES_RATIO_SCALE);
   1909 |             if (toBurn > 0) {
>> 1910 |                 address(uint160(BURN_ADDRESS)).transfer(toBurn);
   1911 |                 emit feeBurned(toBurn);
   1912 | 
   1913 |                 value = value.sub(toBurn);
```

---

### 49. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1762 行
- **函数**: `isContract()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1759 |     }
   1760 | 
   1761 |     modifier oncePerBlock() {
>> 1762 |         require(block.number > previousHeight, "can not do this twice in one block");
   1763 |         _;
   1764 |         previousHeight = block.number;
   1765 |     }
```

---

### 50. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1764 行
- **函数**: `isContract()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1761 |     modifier oncePerBlock() {
   1762 |         require(block.number > previousHeight, "can not do this twice in one block");
   1763 |         _;
>> 1764 |         previousHeight = block.number;
   1765 |     }
   1766 | 
   1767 |     /*----------------- events -----------------*/
```

---

### 51. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1894 行
- **函数**: `deposit()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1891 | 
   1892 |         uint256 systemRewardRatio = systemRewardBaseRatio;
   1893 |         if (turnLength > 1 && systemRewardAntiMEVRatio > 0) {
>> 1894 |             systemRewardRatio += systemRewardAntiMEVRatio * (block.number % turnLength) / (turnLength - 1);
   1895 |         }
   1896 | 
   1897 |         if (value > 0 && systemRewardRatio > 0) {
```

---

### 52. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2038 行
- **函数**: `getMiningValidators()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   2035 |             _maxNumOfWorkingCandidates = validators.length - _numOfCabinets;
   2036 |         }
   2037 |         if (_maxNumOfWorkingCandidates > 0) {
>> 2038 |             uint256 shuffleNumber = block.number / _shuffleInterval;
   2039 |             shuffle(
   2040 |                 validators,
   2041 |                 voteAddrs,
```

---

### 53. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2664 行
- **函数**: `_enterMaintenance()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   2661 |     function _enterMaintenance(address validator, uint256 index) private {
   2662 |         ++numOfMaintaining;
   2663 |         validatorExtraSet[index].isMaintaining = true;
>> 2664 |         validatorExtraSet[index].enterMaintenanceHeight = block.number;
   2665 |         emit validatorEnterMaintenance(validator);
   2666 |     }
   2667 | 
```

---

### 54. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 2683 行
- **函数**: `_exitMaintenance()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   2680 |         --numOfMaintaining;
   2681 | 
   2682 |         // step 1: calculate slashCount
>> 2683 |         uint256 slashCount = block.number.sub(validatorExtraSet[index].enterMaintenanceHeight).div(miningValidatorCount)
   2684 |             .div(maintainSlashScale);
   2685 | 
   2686 |         // step 2: clear isMaintaining info
```

---

### 55. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 162 行
- **函数**: `concatStorage()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    159 |                 sstore(
    160 |                     sc,
    161 |                     add(
>>  162 |                         and(fslot, 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff00),
    163 |                         and(mload(mc), mask)
    164 |                     )
    165 |                 )
```

---

### 56. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1550 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1547 | 
   1548 |     uint32 public constant CODE_OK = 0;
   1549 |     uint16 public constant bscChainID = 0x0038;
>> 1550 |     address public constant VALIDATOR_CONTRACT_ADDR = 0x0000000000000000000000000000000000001000;
   1551 |     address public constant SLASH_CONTRACT_ADDR = 0x0000000000000000000000000000000000001001;
   1552 |     address public constant SYSTEM_REWARD_ADDR = 0x0000000000000000000000000000000000001002;
   1553 |     address public constant LIGHT_CLIENT_ADDR = 0x0000000000000000000000000000000000001003;
```

---

### 57. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1551 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1548 |     uint32 public constant CODE_OK = 0;
   1549 |     uint16 public constant bscChainID = 0x0038;
   1550 |     address public constant VALIDATOR_CONTRACT_ADDR = 0x0000000000000000000000000000000000001000;
>> 1551 |     address public constant SLASH_CONTRACT_ADDR = 0x0000000000000000000000000000000000001001;
   1552 |     address public constant SYSTEM_REWARD_ADDR = 0x0000000000000000000000000000000000001002;
   1553 |     address public constant LIGHT_CLIENT_ADDR = 0x0000000000000000000000000000000000001003;
   1554 |     address public constant TOKEN_HUB_ADDR = 0x0000000000000000000000000000000000001004;
```

---

### 58. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1552 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1549 |     uint16 public constant bscChainID = 0x0038;
   1550 |     address public constant VALIDATOR_CONTRACT_ADDR = 0x0000000000000000000000000000000000001000;
   1551 |     address public constant SLASH_CONTRACT_ADDR = 0x0000000000000000000000000000000000001001;
>> 1552 |     address public constant SYSTEM_REWARD_ADDR = 0x0000000000000000000000000000000000001002;
   1553 |     address public constant LIGHT_CLIENT_ADDR = 0x0000000000000000000000000000000000001003;
   1554 |     address public constant TOKEN_HUB_ADDR = 0x0000000000000000000000000000000000001004;
   1555 |     address public constant INCENTIVIZE_ADDR = 0x0000000000000000000000000000000000001005;
```

---

### 59. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1553 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1550 |     address public constant VALIDATOR_CONTRACT_ADDR = 0x0000000000000000000000000000000000001000;
   1551 |     address public constant SLASH_CONTRACT_ADDR = 0x0000000000000000000000000000000000001001;
   1552 |     address public constant SYSTEM_REWARD_ADDR = 0x0000000000000000000000000000000000001002;
>> 1553 |     address public constant LIGHT_CLIENT_ADDR = 0x0000000000000000000000000000000000001003;
   1554 |     address public constant TOKEN_HUB_ADDR = 0x0000000000000000000000000000000000001004;
   1555 |     address public constant INCENTIVIZE_ADDR = 0x0000000000000000000000000000000000001005;
   1556 |     address public constant RELAYERHUB_CONTRACT_ADDR = 0x0000000000000000000000000000000000001006;
```

---

### 60. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1554 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1551 |     address public constant SLASH_CONTRACT_ADDR = 0x0000000000000000000000000000000000001001;
   1552 |     address public constant SYSTEM_REWARD_ADDR = 0x0000000000000000000000000000000000001002;
   1553 |     address public constant LIGHT_CLIENT_ADDR = 0x0000000000000000000000000000000000001003;
>> 1554 |     address public constant TOKEN_HUB_ADDR = 0x0000000000000000000000000000000000001004;
   1555 |     address public constant INCENTIVIZE_ADDR = 0x0000000000000000000000000000000000001005;
   1556 |     address public constant RELAYERHUB_CONTRACT_ADDR = 0x0000000000000000000000000000000000001006;
   1557 |     address public constant GOV_HUB_ADDR = 0x0000000000000000000000000000000000001007;
```

---

### 61. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1555 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1552 |     address public constant SYSTEM_REWARD_ADDR = 0x0000000000000000000000000000000000001002;
   1553 |     address public constant LIGHT_CLIENT_ADDR = 0x0000000000000000000000000000000000001003;
   1554 |     address public constant TOKEN_HUB_ADDR = 0x0000000000000000000000000000000000001004;
>> 1555 |     address public constant INCENTIVIZE_ADDR = 0x0000000000000000000000000000000000001005;
   1556 |     address public constant RELAYERHUB_CONTRACT_ADDR = 0x0000000000000000000000000000000000001006;
   1557 |     address public constant GOV_HUB_ADDR = 0x0000000000000000000000000000000000001007;
   1558 |     address public constant TOKEN_MANAGER_ADDR = 0x0000000000000000000000000000000000001008;
```

---

### 62. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1556 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1553 |     address public constant LIGHT_CLIENT_ADDR = 0x0000000000000000000000000000000000001003;
   1554 |     address public constant TOKEN_HUB_ADDR = 0x0000000000000000000000000000000000001004;
   1555 |     address public constant INCENTIVIZE_ADDR = 0x0000000000000000000000000000000000001005;
>> 1556 |     address public constant RELAYERHUB_CONTRACT_ADDR = 0x0000000000000000000000000000000000001006;
   1557 |     address public constant GOV_HUB_ADDR = 0x0000000000000000000000000000000000001007;
   1558 |     address public constant TOKEN_MANAGER_ADDR = 0x0000000000000000000000000000000000001008;
   1559 |     address public constant CROSS_CHAIN_CONTRACT_ADDR = 0x0000000000000000000000000000000000002000;
```

---

### 63. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1557 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1554 |     address public constant TOKEN_HUB_ADDR = 0x0000000000000000000000000000000000001004;
   1555 |     address public constant INCENTIVIZE_ADDR = 0x0000000000000000000000000000000000001005;
   1556 |     address public constant RELAYERHUB_CONTRACT_ADDR = 0x0000000000000000000000000000000000001006;
>> 1557 |     address public constant GOV_HUB_ADDR = 0x0000000000000000000000000000000000001007;
   1558 |     address public constant TOKEN_MANAGER_ADDR = 0x0000000000000000000000000000000000001008;
   1559 |     address public constant CROSS_CHAIN_CONTRACT_ADDR = 0x0000000000000000000000000000000000002000;
   1560 |     address public constant STAKING_CONTRACT_ADDR = 0x0000000000000000000000000000000000002001;
```

---

### 64. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1558 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1555 |     address public constant INCENTIVIZE_ADDR = 0x0000000000000000000000000000000000001005;
   1556 |     address public constant RELAYERHUB_CONTRACT_ADDR = 0x0000000000000000000000000000000000001006;
   1557 |     address public constant GOV_HUB_ADDR = 0x0000000000000000000000000000000000001007;
>> 1558 |     address public constant TOKEN_MANAGER_ADDR = 0x0000000000000000000000000000000000001008;
   1559 |     address public constant CROSS_CHAIN_CONTRACT_ADDR = 0x0000000000000000000000000000000000002000;
   1560 |     address public constant STAKING_CONTRACT_ADDR = 0x0000000000000000000000000000000000002001;
   1561 |     address public constant STAKE_HUB_ADDR = 0x0000000000000000000000000000000000002002;
```

---

### 65. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1559 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1556 |     address public constant RELAYERHUB_CONTRACT_ADDR = 0x0000000000000000000000000000000000001006;
   1557 |     address public constant GOV_HUB_ADDR = 0x0000000000000000000000000000000000001007;
   1558 |     address public constant TOKEN_MANAGER_ADDR = 0x0000000000000000000000000000000000001008;
>> 1559 |     address public constant CROSS_CHAIN_CONTRACT_ADDR = 0x0000000000000000000000000000000000002000;
   1560 |     address public constant STAKING_CONTRACT_ADDR = 0x0000000000000000000000000000000000002001;
   1561 |     address public constant STAKE_HUB_ADDR = 0x0000000000000000000000000000000000002002;
   1562 |     address public constant STAKE_CREDIT_ADDR = 0x0000000000000000000000000000000000002003;
```

---

### 66. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1560 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1557 |     address public constant GOV_HUB_ADDR = 0x0000000000000000000000000000000000001007;
   1558 |     address public constant TOKEN_MANAGER_ADDR = 0x0000000000000000000000000000000000001008;
   1559 |     address public constant CROSS_CHAIN_CONTRACT_ADDR = 0x0000000000000000000000000000000000002000;
>> 1560 |     address public constant STAKING_CONTRACT_ADDR = 0x0000000000000000000000000000000000002001;
   1561 |     address public constant STAKE_HUB_ADDR = 0x0000000000000000000000000000000000002002;
   1562 |     address public constant STAKE_CREDIT_ADDR = 0x0000000000000000000000000000000000002003;
   1563 |     address public constant GOVERNOR_ADDR = 0x0000000000000000000000000000000000002004;
```

---

### 67. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1561 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1558 |     address public constant TOKEN_MANAGER_ADDR = 0x0000000000000000000000000000000000001008;
   1559 |     address public constant CROSS_CHAIN_CONTRACT_ADDR = 0x0000000000000000000000000000000000002000;
   1560 |     address public constant STAKING_CONTRACT_ADDR = 0x0000000000000000000000000000000000002001;
>> 1561 |     address public constant STAKE_HUB_ADDR = 0x0000000000000000000000000000000000002002;
   1562 |     address public constant STAKE_CREDIT_ADDR = 0x0000000000000000000000000000000000002003;
   1563 |     address public constant GOVERNOR_ADDR = 0x0000000000000000000000000000000000002004;
   1564 |     address public constant GOV_TOKEN_ADDR = 0x0000000000000000000000000000000000002005;
```

---

### 68. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1562 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1559 |     address public constant CROSS_CHAIN_CONTRACT_ADDR = 0x0000000000000000000000000000000000002000;
   1560 |     address public constant STAKING_CONTRACT_ADDR = 0x0000000000000000000000000000000000002001;
   1561 |     address public constant STAKE_HUB_ADDR = 0x0000000000000000000000000000000000002002;
>> 1562 |     address public constant STAKE_CREDIT_ADDR = 0x0000000000000000000000000000000000002003;
   1563 |     address public constant GOVERNOR_ADDR = 0x0000000000000000000000000000000000002004;
   1564 |     address public constant GOV_TOKEN_ADDR = 0x0000000000000000000000000000000000002005;
   1565 |     address public constant TIMELOCK_ADDR = 0x0000000000000000000000000000000000002006;
```

---

### 69. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1563 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1560 |     address public constant STAKING_CONTRACT_ADDR = 0x0000000000000000000000000000000000002001;
   1561 |     address public constant STAKE_HUB_ADDR = 0x0000000000000000000000000000000000002002;
   1562 |     address public constant STAKE_CREDIT_ADDR = 0x0000000000000000000000000000000000002003;
>> 1563 |     address public constant GOVERNOR_ADDR = 0x0000000000000000000000000000000000002004;
   1564 |     address public constant GOV_TOKEN_ADDR = 0x0000000000000000000000000000000000002005;
   1565 |     address public constant TIMELOCK_ADDR = 0x0000000000000000000000000000000000002006;
   1566 |     address public constant TOKEN_RECOVER_PORTAL_ADDR = 0x0000000000000000000000000000000000003000;
```

---

### 70. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1564 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1561 |     address public constant STAKE_HUB_ADDR = 0x0000000000000000000000000000000000002002;
   1562 |     address public constant STAKE_CREDIT_ADDR = 0x0000000000000000000000000000000000002003;
   1563 |     address public constant GOVERNOR_ADDR = 0x0000000000000000000000000000000000002004;
>> 1564 |     address public constant GOV_TOKEN_ADDR = 0x0000000000000000000000000000000000002005;
   1565 |     address public constant TIMELOCK_ADDR = 0x0000000000000000000000000000000000002006;
   1566 |     address public constant TOKEN_RECOVER_PORTAL_ADDR = 0x0000000000000000000000000000000000003000;
   1567 | 
```

---

### 71. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1565 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1562 |     address public constant STAKE_CREDIT_ADDR = 0x0000000000000000000000000000000000002003;
   1563 |     address public constant GOVERNOR_ADDR = 0x0000000000000000000000000000000000002004;
   1564 |     address public constant GOV_TOKEN_ADDR = 0x0000000000000000000000000000000000002005;
>> 1565 |     address public constant TIMELOCK_ADDR = 0x0000000000000000000000000000000000002006;
   1566 |     address public constant TOKEN_RECOVER_PORTAL_ADDR = 0x0000000000000000000000000000000000003000;
   1567 | 
   1568 |     modifier onlyCoinbase() {
```

---

### 72. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1566 行
- **函数**: `mod()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1563 |     address public constant GOVERNOR_ADDR = 0x0000000000000000000000000000000000002004;
   1564 |     address public constant GOV_TOKEN_ADDR = 0x0000000000000000000000000000000000002005;
   1565 |     address public constant TIMELOCK_ADDR = 0x0000000000000000000000000000000000002006;
>> 1566 |     address public constant TOKEN_RECOVER_PORTAL_ADDR = 0x0000000000000000000000000000000000003000;
   1567 | 
   1568 |     modifier onlyCoinbase() {
   1569 |         require(msg.sender == block.coinbase, "the message sender must be the block producer");
```

---

### 73. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1676 行
- **函数**: `isContract()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1673 |     uint256 public numOfJailed; // @dev deprecated
   1674 | 
   1675 |     uint256 public constant BLOCK_FEES_RATIO_SCALE = 10000;
>> 1676 |     address public constant BURN_ADDRESS = 0x000000000000000000000000000000000000dEaD;
   1677 |     uint256 public constant INIT_BURN_RATIO = 1000;
   1678 |     uint256 public burnRatio;
   1679 |     bool public burnRatioInitialized; // @dev deprecated
```

---

### 74. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 17 行
- **函数**: `concat()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     14 |     function concat(bytes memory _preBytes, bytes memory _postBytes) internal pure returns (bytes memory) {
     15 |         bytes memory tempBytes;
     16 | 
>>   17 |         assembly {
     18 |             // Get a location of some free memory and store it in tempBytes as
     19 |             // Solidity does for memory variables.
     20 |             tempBytes := mload(0x40)
```

---

### 75. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 85 行
- **函数**: `concatStorage()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     82 |     }
     83 | 
     84 |     function concatStorage(bytes storage _preBytes, bytes memory _postBytes) internal {
>>   85 |         assembly {
     86 |             // Read the first 32 bytes of _preBytes storage, which is the length
     87 |             // of the array. (We don't need to use the offset into the slot
     88 |             // because arrays use the entire slot.)
```

---

### 76. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 219 行
- **函数**: `slice()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    216 | 
    217 |         bytes memory tempBytes;
    218 | 
>>  219 |         assembly {
    220 |             switch iszero(_length)
    221 |             case 0 {
    222 |                 // Get a location of some free memory and store it in tempBytes as
```

---

### 77. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 273 行
- **函数**: `toAddress()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    270 |         require(_bytes.length >= (_start + 20));
    271 |         address tempAddress;
    272 | 
>>  273 |         assembly {
    274 |             tempAddress := div(mload(add(add(_bytes, 0x20), _start)), 0x1000000000000000000000000)
    275 |         }
    276 | 
```

---

### 78. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 284 行
- **函数**: `toUint8()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    281 |         require(_bytes.length >= (_start + 1));
    282 |         uint8 tempUint;
    283 | 
>>  284 |         assembly {
    285 |             tempUint := mload(add(add(_bytes, 0x1), _start))
    286 |         }
    287 | 
```

---

### 79. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 295 行
- **函数**: `toUint16()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    292 |         require(_bytes.length >= (_start + 2));
    293 |         uint16 tempUint;
    294 | 
>>  295 |         assembly {
    296 |             tempUint := mload(add(add(_bytes, 0x2), _start))
    297 |         }
    298 | 
```

---

### 80. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 306 行
- **函数**: `toUint32()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    303 |         require(_bytes.length >= (_start + 4));
    304 |         uint32 tempUint;
    305 | 
>>  306 |         assembly {
    307 |             tempUint := mload(add(add(_bytes, 0x4), _start))
    308 |         }
    309 | 
```

---

### 81. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 317 行
- **函数**: `toUint64()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    314 |         require(_bytes.length >= (_start + 8));
    315 |         uint64 tempUint;
    316 | 
>>  317 |         assembly {
    318 |             tempUint := mload(add(add(_bytes, 0x8), _start))
    319 |         }
    320 | 
```

---

### 82. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 328 行
- **函数**: `toUint96()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    325 |         require(_bytes.length >= (_start + 12));
    326 |         uint96 tempUint;
    327 | 
>>  328 |         assembly {
    329 |             tempUint := mload(add(add(_bytes, 0xc), _start))
    330 |         }
    331 | 
```

---

### 83. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 339 行
- **函数**: `toUint128()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    336 |         require(_bytes.length >= (_start + 16));
    337 |         uint128 tempUint;
    338 | 
>>  339 |         assembly {
    340 |             tempUint := mload(add(add(_bytes, 0x10), _start))
    341 |         }
    342 | 
```

---

### 84. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 350 行
- **函数**: `toUint()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    347 |         require(_bytes.length >= (_start + 32));
    348 |         uint256 tempUint;
    349 | 
>>  350 |         assembly {
    351 |             tempUint := mload(add(add(_bytes, 0x20), _start))
    352 |         }
    353 | 
```

---

### 85. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 361 行
- **函数**: `toBytes32()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    358 |         require(_bytes.length >= (_start + 32));
    359 |         bytes32 tempBytes32;
    360 | 
>>  361 |         assembly {
    362 |             tempBytes32 := mload(add(add(_bytes, 0x20), _start))
    363 |         }
    364 | 
```

---

### 86. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 371 行
- **函数**: `equal()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    368 |     function equal(bytes memory _preBytes, bytes memory _postBytes) internal pure returns (bool) {
    369 |         bool success = true;
    370 | 
>>  371 |         assembly {
    372 |             let length := mload(_preBytes)
    373 | 
    374 |             // if lengths don't match the arrays are not equal
```

---

### 87. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 413 行
- **函数**: `equalStorage()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    410 |     function equalStorage(bytes storage _preBytes, bytes memory _postBytes) internal view returns (bool) {
    411 |         bool success = true;
    412 | 
>>  413 |         assembly {
    414 |             // we know _preBytes_offset is 0
    415 |             let fslot := sload(_preBytes_slot)
    416 |             // Decode the length of the stored array like in concatStorage().
```

---

### 88. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 486 行
- **函数**: `bytesToAddress()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    483 |  */
    484 | library BytesToTypes {
    485 |     function bytesToAddress(uint256 _offst, bytes memory _input) internal pure returns (address _output) {
>>  486 |         assembly {
    487 |             _output := mload(add(_input, _offst))
    488 |         }
    489 |     }
```

---

### 89. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 493 行
- **函数**: `bytesToBool()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    490 | 
    491 |     function bytesToBool(uint256 _offst, bytes memory _input) internal pure returns (bool _output) {
    492 |         uint8 x;
>>  493 |         assembly {
    494 |             x := mload(add(_input, _offst))
    495 |         }
    496 |         x == 0 ? _output = false : _output = true;
```

---

### 90. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 500 行
- **函数**: `getStringSize()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    497 |     }
    498 | 
    499 |     function getStringSize(uint256 _offst, bytes memory _input) internal pure returns (uint256 size) {
>>  500 |         assembly {
    501 |             size := mload(add(_input, _offst))
    502 |             let chunk_count := add(div(size, 32), 1) // chunk_count = size/32 + 1
    503 | 
```

---

### 91. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 515 行
- **函数**: `bytesToString()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    512 | 
    513 |     function bytesToString(uint256 _offst, bytes memory _input, bytes memory _output) internal pure {
    514 |         uint256 size = 32;
>>  515 |         assembly {
    516 |             let chunk_count
    517 | 
    518 |             size := mload(add(_input, _offst))
```

---

### 92. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 531 行
- **函数**: `bytesToBytes32()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    528 |     }
    529 | 
    530 |     function bytesToBytes32(uint256 _offst, bytes memory _input, bytes32 _output) internal pure {
>>  531 |         assembly {
    532 |             mstore(_output, add(_input, _offst))
    533 |             mstore(add(_output, 32), add(add(_input, _offst), 32))
    534 |         }
```

---

### 93. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 538 行
- **函数**: `bytesToInt8()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    535 |     }
    536 | 
    537 |     function bytesToInt8(uint256 _offst, bytes memory _input) internal pure returns (int8 _output) {
>>  538 |         assembly {
    539 |             _output := mload(add(_input, _offst))
    540 |         }
    541 |     }
```

---

### 94. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 544 行
- **函数**: `bytesToInt16()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    541 |     }
    542 | 
    543 |     function bytesToInt16(uint256 _offst, bytes memory _input) internal pure returns (int16 _output) {
>>  544 |         assembly {
    545 |             _output := mload(add(_input, _offst))
    546 |         }
    547 |     }
```

---

### 95. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 550 行
- **函数**: `bytesToInt24()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    547 |     }
    548 | 
    549 |     function bytesToInt24(uint256 _offst, bytes memory _input) internal pure returns (int24 _output) {
>>  550 |         assembly {
    551 |             _output := mload(add(_input, _offst))
    552 |         }
    553 |     }
```

---

### 96. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 556 行
- **函数**: `bytesToInt32()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    553 |     }
    554 | 
    555 |     function bytesToInt32(uint256 _offst, bytes memory _input) internal pure returns (int32 _output) {
>>  556 |         assembly {
    557 |             _output := mload(add(_input, _offst))
    558 |         }
    559 |     }
```

---

### 97. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 562 行
- **函数**: `bytesToInt40()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    559 |     }
    560 | 
    561 |     function bytesToInt40(uint256 _offst, bytes memory _input) internal pure returns (int40 _output) {
>>  562 |         assembly {
    563 |             _output := mload(add(_input, _offst))
    564 |         }
    565 |     }
```

---

### 98. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 568 行
- **函数**: `bytesToInt48()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    565 |     }
    566 | 
    567 |     function bytesToInt48(uint256 _offst, bytes memory _input) internal pure returns (int48 _output) {
>>  568 |         assembly {
    569 |             _output := mload(add(_input, _offst))
    570 |         }
    571 |     }
```

---

### 99. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 574 行
- **函数**: `bytesToInt56()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    571 |     }
    572 | 
    573 |     function bytesToInt56(uint256 _offst, bytes memory _input) internal pure returns (int56 _output) {
>>  574 |         assembly {
    575 |             _output := mload(add(_input, _offst))
    576 |         }
    577 |     }
```

---

### 100. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 580 行
- **函数**: `bytesToInt64()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    577 |     }
    578 | 
    579 |     function bytesToInt64(uint256 _offst, bytes memory _input) internal pure returns (int64 _output) {
>>  580 |         assembly {
    581 |             _output := mload(add(_input, _offst))
    582 |         }
    583 |     }
```

---

### 101. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 586 行
- **函数**: `bytesToInt72()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    583 |     }
    584 | 
    585 |     function bytesToInt72(uint256 _offst, bytes memory _input) internal pure returns (int72 _output) {
>>  586 |         assembly {
    587 |             _output := mload(add(_input, _offst))
    588 |         }
    589 |     }
```

---

### 102. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 592 行
- **函数**: `bytesToInt80()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    589 |     }
    590 | 
    591 |     function bytesToInt80(uint256 _offst, bytes memory _input) internal pure returns (int80 _output) {
>>  592 |         assembly {
    593 |             _output := mload(add(_input, _offst))
    594 |         }
    595 |     }
```

---

### 103. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 598 行
- **函数**: `bytesToInt88()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    595 |     }
    596 | 
    597 |     function bytesToInt88(uint256 _offst, bytes memory _input) internal pure returns (int88 _output) {
>>  598 |         assembly {
    599 |             _output := mload(add(_input, _offst))
    600 |         }
    601 |     }
```

---

### 104. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 604 行
- **函数**: `bytesToInt96()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    601 |     }
    602 | 
    603 |     function bytesToInt96(uint256 _offst, bytes memory _input) internal pure returns (int96 _output) {
>>  604 |         assembly {
    605 |             _output := mload(add(_input, _offst))
    606 |         }
    607 |     }
```

---

### 105. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 610 行
- **函数**: `bytesToInt104()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    607 |     }
    608 | 
    609 |     function bytesToInt104(uint256 _offst, bytes memory _input) internal pure returns (int104 _output) {
>>  610 |         assembly {
    611 |             _output := mload(add(_input, _offst))
    612 |         }
    613 |     }
```

---

### 106. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 616 行
- **函数**: `bytesToInt112()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    613 |     }
    614 | 
    615 |     function bytesToInt112(uint256 _offst, bytes memory _input) internal pure returns (int112 _output) {
>>  616 |         assembly {
    617 |             _output := mload(add(_input, _offst))
    618 |         }
    619 |     }
```

---

### 107. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 622 行
- **函数**: `bytesToInt120()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    619 |     }
    620 | 
    621 |     function bytesToInt120(uint256 _offst, bytes memory _input) internal pure returns (int120 _output) {
>>  622 |         assembly {
    623 |             _output := mload(add(_input, _offst))
    624 |         }
    625 |     }
```

---

### 108. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 628 行
- **函数**: `bytesToInt128()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    625 |     }
    626 | 
    627 |     function bytesToInt128(uint256 _offst, bytes memory _input) internal pure returns (int128 _output) {
>>  628 |         assembly {
    629 |             _output := mload(add(_input, _offst))
    630 |         }
    631 |     }
```

---

### 109. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 634 行
- **函数**: `bytesToInt136()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    631 |     }
    632 | 
    633 |     function bytesToInt136(uint256 _offst, bytes memory _input) internal pure returns (int136 _output) {
>>  634 |         assembly {
    635 |             _output := mload(add(_input, _offst))
    636 |         }
    637 |     }
```

---

### 110. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 640 行
- **函数**: `bytesToInt144()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    637 |     }
    638 | 
    639 |     function bytesToInt144(uint256 _offst, bytes memory _input) internal pure returns (int144 _output) {
>>  640 |         assembly {
    641 |             _output := mload(add(_input, _offst))
    642 |         }
    643 |     }
```

---

### 111. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 646 行
- **函数**: `bytesToInt152()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    643 |     }
    644 | 
    645 |     function bytesToInt152(uint256 _offst, bytes memory _input) internal pure returns (int152 _output) {
>>  646 |         assembly {
    647 |             _output := mload(add(_input, _offst))
    648 |         }
    649 |     }
```

---

### 112. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 652 行
- **函数**: `bytesToInt160()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    649 |     }
    650 | 
    651 |     function bytesToInt160(uint256 _offst, bytes memory _input) internal pure returns (int160 _output) {
>>  652 |         assembly {
    653 |             _output := mload(add(_input, _offst))
    654 |         }
    655 |     }
```

---

### 113. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 658 行
- **函数**: `bytesToInt168()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    655 |     }
    656 | 
    657 |     function bytesToInt168(uint256 _offst, bytes memory _input) internal pure returns (int168 _output) {
>>  658 |         assembly {
    659 |             _output := mload(add(_input, _offst))
    660 |         }
    661 |     }
```

---

### 114. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 664 行
- **函数**: `bytesToInt176()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    661 |     }
    662 | 
    663 |     function bytesToInt176(uint256 _offst, bytes memory _input) internal pure returns (int176 _output) {
>>  664 |         assembly {
    665 |             _output := mload(add(_input, _offst))
    666 |         }
    667 |     }
```

---

### 115. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 670 行
- **函数**: `bytesToInt184()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    667 |     }
    668 | 
    669 |     function bytesToInt184(uint256 _offst, bytes memory _input) internal pure returns (int184 _output) {
>>  670 |         assembly {
    671 |             _output := mload(add(_input, _offst))
    672 |         }
    673 |     }
```

---

### 116. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 676 行
- **函数**: `bytesToInt192()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    673 |     }
    674 | 
    675 |     function bytesToInt192(uint256 _offst, bytes memory _input) internal pure returns (int192 _output) {
>>  676 |         assembly {
    677 |             _output := mload(add(_input, _offst))
    678 |         }
    679 |     }
```

---

### 117. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 682 行
- **函数**: `bytesToInt200()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    679 |     }
    680 | 
    681 |     function bytesToInt200(uint256 _offst, bytes memory _input) internal pure returns (int200 _output) {
>>  682 |         assembly {
    683 |             _output := mload(add(_input, _offst))
    684 |         }
    685 |     }
```

---

### 118. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 688 行
- **函数**: `bytesToInt208()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    685 |     }
    686 | 
    687 |     function bytesToInt208(uint256 _offst, bytes memory _input) internal pure returns (int208 _output) {
>>  688 |         assembly {
    689 |             _output := mload(add(_input, _offst))
    690 |         }
    691 |     }
```

---

### 119. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 694 行
- **函数**: `bytesToInt216()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    691 |     }
    692 | 
    693 |     function bytesToInt216(uint256 _offst, bytes memory _input) internal pure returns (int216 _output) {
>>  694 |         assembly {
    695 |             _output := mload(add(_input, _offst))
    696 |         }
    697 |     }
```

---

### 120. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 700 行
- **函数**: `bytesToInt224()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    697 |     }
    698 | 
    699 |     function bytesToInt224(uint256 _offst, bytes memory _input) internal pure returns (int224 _output) {
>>  700 |         assembly {
    701 |             _output := mload(add(_input, _offst))
    702 |         }
    703 |     }
```

---

### 121. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 706 行
- **函数**: `bytesToInt232()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    703 |     }
    704 | 
    705 |     function bytesToInt232(uint256 _offst, bytes memory _input) internal pure returns (int232 _output) {
>>  706 |         assembly {
    707 |             _output := mload(add(_input, _offst))
    708 |         }
    709 |     }
```

---

### 122. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 712 行
- **函数**: `bytesToInt240()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    709 |     }
    710 | 
    711 |     function bytesToInt240(uint256 _offst, bytes memory _input) internal pure returns (int240 _output) {
>>  712 |         assembly {
    713 |             _output := mload(add(_input, _offst))
    714 |         }
    715 |     }
```

---

### 123. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 718 行
- **函数**: `bytesToInt248()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    715 |     }
    716 | 
    717 |     function bytesToInt248(uint256 _offst, bytes memory _input) internal pure returns (int248 _output) {
>>  718 |         assembly {
    719 |             _output := mload(add(_input, _offst))
    720 |         }
    721 |     }
```

---

### 124. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 724 行
- **函数**: `bytesToInt256()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    721 |     }
    722 | 
    723 |     function bytesToInt256(uint256 _offst, bytes memory _input) internal pure returns (int256 _output) {
>>  724 |         assembly {
    725 |             _output := mload(add(_input, _offst))
    726 |         }
    727 |     }
```

---

### 125. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 730 行
- **函数**: `bytesToUint8()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    727 |     }
    728 | 
    729 |     function bytesToUint8(uint256 _offst, bytes memory _input) internal pure returns (uint8 _output) {
>>  730 |         assembly {
    731 |             _output := mload(add(_input, _offst))
    732 |         }
    733 |     }
```

---

### 126. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 736 行
- **函数**: `bytesToUint16()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    733 |     }
    734 | 
    735 |     function bytesToUint16(uint256 _offst, bytes memory _input) internal pure returns (uint16 _output) {
>>  736 |         assembly {
    737 |             _output := mload(add(_input, _offst))
    738 |         }
    739 |     }
```

---

### 127. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 742 行
- **函数**: `bytesToUint24()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    739 |     }
    740 | 
    741 |     function bytesToUint24(uint256 _offst, bytes memory _input) internal pure returns (uint24 _output) {
>>  742 |         assembly {
    743 |             _output := mload(add(_input, _offst))
    744 |         }
    745 |     }
```

---

### 128. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 748 行
- **函数**: `bytesToUint32()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    745 |     }
    746 | 
    747 |     function bytesToUint32(uint256 _offst, bytes memory _input) internal pure returns (uint32 _output) {
>>  748 |         assembly {
    749 |             _output := mload(add(_input, _offst))
    750 |         }
    751 |     }
```

---

### 129. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 754 行
- **函数**: `bytesToUint40()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    751 |     }
    752 | 
    753 |     function bytesToUint40(uint256 _offst, bytes memory _input) internal pure returns (uint40 _output) {
>>  754 |         assembly {
    755 |             _output := mload(add(_input, _offst))
    756 |         }
    757 |     }
```

---

### 130. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 760 行
- **函数**: `bytesToUint48()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    757 |     }
    758 | 
    759 |     function bytesToUint48(uint256 _offst, bytes memory _input) internal pure returns (uint48 _output) {
>>  760 |         assembly {
    761 |             _output := mload(add(_input, _offst))
    762 |         }
    763 |     }
```

---

### 131. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 766 行
- **函数**: `bytesToUint56()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    763 |     }
    764 | 
    765 |     function bytesToUint56(uint256 _offst, bytes memory _input) internal pure returns (uint56 _output) {
>>  766 |         assembly {
    767 |             _output := mload(add(_input, _offst))
    768 |         }
    769 |     }
```

---

### 132. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 772 行
- **函数**: `bytesToUint64()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    769 |     }
    770 | 
    771 |     function bytesToUint64(uint256 _offst, bytes memory _input) internal pure returns (uint64 _output) {
>>  772 |         assembly {
    773 |             _output := mload(add(_input, _offst))
    774 |         }
    775 |     }
```

---

### 133. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 778 行
- **函数**: `bytesToUint72()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    775 |     }
    776 | 
    777 |     function bytesToUint72(uint256 _offst, bytes memory _input) internal pure returns (uint72 _output) {
>>  778 |         assembly {
    779 |             _output := mload(add(_input, _offst))
    780 |         }
    781 |     }
```

---

### 134. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 784 行
- **函数**: `bytesToUint80()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    781 |     }
    782 | 
    783 |     function bytesToUint80(uint256 _offst, bytes memory _input) internal pure returns (uint80 _output) {
>>  784 |         assembly {
    785 |             _output := mload(add(_input, _offst))
    786 |         }
    787 |     }
```

---

### 135. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 790 行
- **函数**: `bytesToUint88()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    787 |     }
    788 | 
    789 |     function bytesToUint88(uint256 _offst, bytes memory _input) internal pure returns (uint88 _output) {
>>  790 |         assembly {
    791 |             _output := mload(add(_input, _offst))
    792 |         }
    793 |     }
```

---

### 136. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 796 行
- **函数**: `bytesToUint96()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    793 |     }
    794 | 
    795 |     function bytesToUint96(uint256 _offst, bytes memory _input) internal pure returns (uint96 _output) {
>>  796 |         assembly {
    797 |             _output := mload(add(_input, _offst))
    798 |         }
    799 |     }
```

---

### 137. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 802 行
- **函数**: `bytesToUint104()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    799 |     }
    800 | 
    801 |     function bytesToUint104(uint256 _offst, bytes memory _input) internal pure returns (uint104 _output) {
>>  802 |         assembly {
    803 |             _output := mload(add(_input, _offst))
    804 |         }
    805 |     }
```

---

### 138. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 808 行
- **函数**: `bytesToUint112()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    805 |     }
    806 | 
    807 |     function bytesToUint112(uint256 _offst, bytes memory _input) internal pure returns (uint112 _output) {
>>  808 |         assembly {
    809 |             _output := mload(add(_input, _offst))
    810 |         }
    811 |     }
```

---

### 139. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 814 行
- **函数**: `bytesToUint120()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    811 |     }
    812 | 
    813 |     function bytesToUint120(uint256 _offst, bytes memory _input) internal pure returns (uint120 _output) {
>>  814 |         assembly {
    815 |             _output := mload(add(_input, _offst))
    816 |         }
    817 |     }
```

---

### 140. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 820 行
- **函数**: `bytesToUint128()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    817 |     }
    818 | 
    819 |     function bytesToUint128(uint256 _offst, bytes memory _input) internal pure returns (uint128 _output) {
>>  820 |         assembly {
    821 |             _output := mload(add(_input, _offst))
    822 |         }
    823 |     }
```

---

### 141. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 826 行
- **函数**: `bytesToUint136()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    823 |     }
    824 | 
    825 |     function bytesToUint136(uint256 _offst, bytes memory _input) internal pure returns (uint136 _output) {
>>  826 |         assembly {
    827 |             _output := mload(add(_input, _offst))
    828 |         }
    829 |     }
```

---

### 142. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 832 行
- **函数**: `bytesToUint144()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    829 |     }
    830 | 
    831 |     function bytesToUint144(uint256 _offst, bytes memory _input) internal pure returns (uint144 _output) {
>>  832 |         assembly {
    833 |             _output := mload(add(_input, _offst))
    834 |         }
    835 |     }
```

---

### 143. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 838 行
- **函数**: `bytesToUint152()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    835 |     }
    836 | 
    837 |     function bytesToUint152(uint256 _offst, bytes memory _input) internal pure returns (uint152 _output) {
>>  838 |         assembly {
    839 |             _output := mload(add(_input, _offst))
    840 |         }
    841 |     }
```

---

### 144. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 844 行
- **函数**: `bytesToUint160()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    841 |     }
    842 | 
    843 |     function bytesToUint160(uint256 _offst, bytes memory _input) internal pure returns (uint160 _output) {
>>  844 |         assembly {
    845 |             _output := mload(add(_input, _offst))
    846 |         }
    847 |     }
```

---

### 145. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 850 行
- **函数**: `bytesToUint168()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    847 |     }
    848 | 
    849 |     function bytesToUint168(uint256 _offst, bytes memory _input) internal pure returns (uint168 _output) {
>>  850 |         assembly {
    851 |             _output := mload(add(_input, _offst))
    852 |         }
    853 |     }
```

---

### 146. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 856 行
- **函数**: `bytesToUint176()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    853 |     }
    854 | 
    855 |     function bytesToUint176(uint256 _offst, bytes memory _input) internal pure returns (uint176 _output) {
>>  856 |         assembly {
    857 |             _output := mload(add(_input, _offst))
    858 |         }
    859 |     }
```

---

### 147. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 862 行
- **函数**: `bytesToUint184()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    859 |     }
    860 | 
    861 |     function bytesToUint184(uint256 _offst, bytes memory _input) internal pure returns (uint184 _output) {
>>  862 |         assembly {
    863 |             _output := mload(add(_input, _offst))
    864 |         }
    865 |     }
```

---

### 148. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 868 行
- **函数**: `bytesToUint192()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    865 |     }
    866 | 
    867 |     function bytesToUint192(uint256 _offst, bytes memory _input) internal pure returns (uint192 _output) {
>>  868 |         assembly {
    869 |             _output := mload(add(_input, _offst))
    870 |         }
    871 |     }
```

---

### 149. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 874 行
- **函数**: `bytesToUint200()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    871 |     }
    872 | 
    873 |     function bytesToUint200(uint256 _offst, bytes memory _input) internal pure returns (uint200 _output) {
>>  874 |         assembly {
    875 |             _output := mload(add(_input, _offst))
    876 |         }
    877 |     }
```

---

### 150. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 880 行
- **函数**: `bytesToUint208()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    877 |     }
    878 | 
    879 |     function bytesToUint208(uint256 _offst, bytes memory _input) internal pure returns (uint208 _output) {
>>  880 |         assembly {
    881 |             _output := mload(add(_input, _offst))
    882 |         }
    883 |     }
```

---

### 151. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 886 行
- **函数**: `bytesToUint216()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    883 |     }
    884 | 
    885 |     function bytesToUint216(uint256 _offst, bytes memory _input) internal pure returns (uint216 _output) {
>>  886 |         assembly {
    887 |             _output := mload(add(_input, _offst))
    888 |         }
    889 |     }
```

---

### 152. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 892 行
- **函数**: `bytesToUint224()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    889 |     }
    890 | 
    891 |     function bytesToUint224(uint256 _offst, bytes memory _input) internal pure returns (uint224 _output) {
>>  892 |         assembly {
    893 |             _output := mload(add(_input, _offst))
    894 |         }
    895 |     }
```

---

### 153. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 898 行
- **函数**: `bytesToUint232()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    895 |     }
    896 | 
    897 |     function bytesToUint232(uint256 _offst, bytes memory _input) internal pure returns (uint232 _output) {
>>  898 |         assembly {
    899 |             _output := mload(add(_input, _offst))
    900 |         }
    901 |     }
```

---

### 154. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 904 行
- **函数**: `bytesToUint240()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    901 |     }
    902 | 
    903 |     function bytesToUint240(uint256 _offst, bytes memory _input) internal pure returns (uint240 _output) {
>>  904 |         assembly {
    905 |             _output := mload(add(_input, _offst))
    906 |         }
    907 |     }
```

---

### 155. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 910 行
- **函数**: `bytesToUint248()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    907 |     }
    908 | 
    909 |     function bytesToUint248(uint256 _offst, bytes memory _input) internal pure returns (uint248 _output) {
>>  910 |         assembly {
    911 |             _output := mload(add(_input, _offst))
    912 |         }
    913 |     }
```

---

### 156. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 916 行
- **函数**: `bytesToUint256()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    913 |     }
    914 | 
    915 |     function bytesToUint256(uint256 _offst, bytes memory _input) internal pure returns (uint256 _output) {
>>  916 |         assembly {
    917 |             _output := mload(add(_input, _offst))
    918 |         }
    919 |     }
```

---

### 157. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1021 行
- **函数**: `equals()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1018 |     // bytes starting at 'addr2'.
   1019 |     // Returns 'true' if the bytes are the same, otherwise 'false'.
   1020 |     function equals(uint256 addr, uint256 addr2, uint256 len) internal pure returns (bool equal) {
>> 1021 |         assembly {
   1022 |             equal := eq(keccak256(addr, len), keccak256(addr2, len))
   1023 |         }
   1024 |     }
```

---

### 158. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1033 行
- **函数**: `equals()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1030 |     function equals(uint256 addr, uint256 len, bytes memory bts) internal pure returns (bool equal) {
   1031 |         require(bts.length >= len);
   1032 |         uint256 addr2;
>> 1033 |         assembly {
   1034 |             addr2 := add(bts, /*BYTES_HEADER_SIZE*/ 32)
   1035 |         }
   1036 |         return equals(addr, addr2, len);
```

---

### 159. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1049 行
- **函数**: `copy()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1046 |     function copy(uint256 src, uint256 dest, uint256 len) internal pure {
   1047 |         // Copy word-length chunks while possible
   1048 |         for (; len >= WORD_SIZE; len -= WORD_SIZE) {
>> 1049 |             assembly {
   1050 |                 mstore(dest, mload(src))
   1051 |             }
   1052 |             dest += WORD_SIZE;
```

---

### 160. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1058 行
- **函数**: `copy()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1055 | 
   1056 |         // Copy remaining bytes
   1057 |         uint256 mask = 256 ** (WORD_SIZE - len) - 1;
>> 1058 |         assembly {
   1059 |             let srcpart := and(mload(src), not(mask))
   1060 |             let destpart := and(mload(dest), mask)
   1061 |             mstore(dest, or(destpart, srcpart))
```

---

### 161. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1067 行
- **函数**: `ptr()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1064 | 
   1065 |     // Returns a memory pointer to the provided bytes array.
   1066 |     function ptr(bytes memory bts) internal pure returns (uint256 addr) {
>> 1067 |         assembly {
   1068 |             addr := bts
   1069 |         }
   1070 |     }
```

---

### 162. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1074 行
- **函数**: `dataPtr()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1071 | 
   1072 |     // Returns a memory pointer to the data portion of the provided bytes array.
   1073 |     function dataPtr(bytes memory bts) internal pure returns (uint256 addr) {
>> 1074 |         assembly {
   1075 |             addr := add(bts, /*BYTES_HEADER_SIZE*/ 32)
   1076 |         }
   1077 |     }
```

---

### 163. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1083 行
- **函数**: `fromBytes()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1080 |     // length of the provided bytes array.
   1081 |     function fromBytes(bytes memory bts) internal pure returns (uint256 addr, uint256 len) {
   1082 |         len = bts.length;
>> 1083 |         assembly {
   1084 |             addr := add(bts, /*BYTES_HEADER_SIZE*/ 32)
   1085 |         }
   1086 |     }
```

---

### 164. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1094 行
- **函数**: `toBytes()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1091 |     function toBytes(uint256 addr, uint256 len) internal pure returns (bytes memory bts) {
   1092 |         bts = new bytes(len);
   1093 |         uint256 btsptr;
>> 1094 |         assembly {
   1095 |             btsptr := add(bts, /*BYTES_HEADER_SIZE*/ 32)
   1096 |         }
   1097 |         copy(addr, btsptr, len);
```

---

### 165. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1102 行
- **函数**: `toUint()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1099 | 
   1100 |     // Get the word stored at memory address 'addr' as a 'uint'.
   1101 |     function toUint(uint256 addr) internal pure returns (uint256 n) {
>> 1102 |         assembly {
   1103 |             n := mload(addr)
   1104 |         }
   1105 |     }
```

---

### 166. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1109 行
- **函数**: `toBytes32()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1106 | 
   1107 |     // Get the word stored at memory address 'addr' as a 'bytes32'.
   1108 |     function toBytes32(uint256 addr) internal pure returns (bytes32 bts) {
>> 1109 |         assembly {
   1110 |             bts := mload(addr)
   1111 |         }
   1112 |     }
```

---

### 167. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1152 行
- **函数**: `toRLPItem()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1149 | 
   1150 |     function toRLPItem(bytes memory self) internal pure returns (RLPItem memory) {
   1151 |         uint256 memPtr;
>> 1152 |         assembly {
   1153 |             memPtr := add(self, 0x20)
   1154 |         }
   1155 | 
```

---

### 168. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1196 行
- **函数**: `isList()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1193 | 
   1194 |         uint8 byte0;
   1195 |         uint256 memPtr = item.memPtr;
>> 1196 |         assembly {
   1197 |             byte0 := byte(0, mload(memPtr))
   1198 |         }
   1199 | 
```

---

### 169. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1211 行
- **函数**: `toRlpBytes()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1208 |         if (result.length == 0) return result;
   1209 | 
   1210 |         uint256 ptr;
>> 1211 |         assembly {
   1212 |             ptr := add(0x20, result)
   1213 |         }
   1214 | 
```

---

### 170. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1223 行
- **函数**: `toBoolean()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1220 |         require(item.len == 1);
   1221 |         uint256 result;
   1222 |         uint256 memPtr = item.memPtr;
>> 1223 |         assembly {
   1224 |             result := byte(0, mload(memPtr))
   1225 |         }
   1226 | 
```

---

### 171. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1250 行
- **函数**: `toUint()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1247 | 
   1248 |         uint256 result;
   1249 |         uint256 memPtr = item.memPtr + offset;
>> 1250 |         assembly {
   1251 |             result := mload(memPtr)
   1252 | 
   1253 |             // shift to the correct location if necessary
```

---

### 172. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1267 行
- **函数**: `toUintStrict()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1264 | 
   1265 |         uint256 result;
   1266 |         uint256 memPtr = item.memPtr + 1;
>> 1267 |         assembly {
   1268 |             result := mload(memPtr)
   1269 |         }
   1270 | 
```

---

### 173. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1282 行
- **函数**: `toBytes()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1279 |         bytes memory result = new bytes(len);
   1280 | 
   1281 |         uint256 destPtr;
>> 1282 |         assembly {
   1283 |             destPtr := add(0x20, result)
   1284 |         }
   1285 | 
```

---

### 174. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1307 行
- **函数**: `_itemLength()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1304 |     function _itemLength(uint256 memPtr) private pure returns (uint256) {
   1305 |         uint256 itemLen;
   1306 |         uint256 byte0;
>> 1307 |         assembly {
   1308 |             byte0 := byte(0, mload(memPtr))
   1309 |         }
   1310 | 
```

---

### 175. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1317 行
- **函数**: `_itemLength()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1314 |             itemLen = byte0 - STRING_SHORT_START + 1;
   1315 |         } else if (byte0 < LIST_SHORT_START) {
   1316 |             uint256 dataLen;
>> 1317 |             assembly {
   1318 |                 let byteLen := sub(byte0, 0xb7) // # of bytes the actual length is
   1319 |                 memPtr := add(memPtr, 1) // skip over the first byte
   1320 | 
```

---

### 176. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1330 行
- **函数**: `_itemLength()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1327 |             itemLen = byte0 - LIST_SHORT_START + 1;
   1328 |         } else {
   1329 |             uint256 dataLen;
>> 1330 |             assembly {
   1331 |                 let byteLen := sub(byte0, 0xf7)
   1332 |                 memPtr := add(memPtr, 1)
   1333 | 
```

---

### 177. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1346 行
- **函数**: `_payloadOffset()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1343 |     // @return number of bytes until the data
   1344 |     function _payloadOffset(uint256 memPtr) private pure returns (uint256) {
   1345 |         uint256 byte0;
>> 1346 |         assembly {
   1347 |             byte0 := byte(0, mload(memPtr))
   1348 |         }
   1349 | 
```

---

### 178. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1373 行
- **函数**: `copy()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1370 | 
   1371 |         // copy as many word sizes as possible
   1372 |         for (; len >= WORD_SIZE; len -= WORD_SIZE) {
>> 1373 |             assembly {
   1374 |                 mstore(dest, mload(src))
   1375 |             }
   1376 | 
```

---

### 179. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1383 行
- **函数**: `copy()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1380 | 
   1381 |         // left over bytes. Mask is used to remove unwanted bytes from the word
   1382 |         uint256 mask = 256 ** (WORD_SIZE - len) - 1;
>> 1383 |         assembly {
   1384 |             let srcpart := and(mload(src), not(mask)) // zero out src
   1385 |             let destpart := and(mload(dest), mask) // retrieve the bytes
   1386 |             mstore(dest, or(destpart, srcpart))
```

---

### 180. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000000000000000000000000000000001000` 第 1646 行
- **函数**: `isContract()`
- **合约**: `converts`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1643 |     // Not reliable, do not use when need strong verify
   1644 |     function isContract(address addr) internal view returns (bool) {
   1645 |         uint256 size;
>> 1646 |         assembly {
   1647 |             size := extcodesize(addr)
   1648 |         }
   1649 |         return size > 0;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*