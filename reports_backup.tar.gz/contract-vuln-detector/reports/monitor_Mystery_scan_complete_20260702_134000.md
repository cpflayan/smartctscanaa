# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:40:00
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` |
| contract_name | `Mystery` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['npm/@openzeppelin/contracts@5.6.1/access/Ownable.sol', 'npm/@openzeppelin/contracts@5.6.1/interfaces/IERC1363.sol', 'npm/@openzeppelin/contracts@5.6.1/interfaces/IERC165.sol', 'npm/@openzeppelin/contracts@5.6.1/interfaces/IERC20.sol', 'npm/@openzeppelin/contracts@5.6.1/token/ERC20/IERC20.sol', 'npm/@openzeppelin/contracts@5.6.1/token/ERC20/utils/SafeERC20.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/Address.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/Context.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/cryptography/Hashes.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/cryptography/MerkleProof.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/Errors.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/introspection/IERC165.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/LowLevelCall.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/math/Math.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/math/SafeCast.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/Panic.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/ReentrancyGuard.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/StorageSlot.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/structs/BitMaps.sol', 'project/contracts/DynStakingDividend.sol', 'project/contracts/interface/IBinding.sol', 'project/contracts/interface/ILpd.sol', 'project/contracts/Mystery.sol', 'project/contracts/NodeDividend.sol', 'project/contracts/RebateDividend.sol', 'project/contracts/WeekDividend.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646139` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 38 |
| 🟢 LOW | 13 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 1478 行
- **函数**: `delegatecallNoReturn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1475 |     /// @dev Performs a Solidity function call using a low level `delegatecall` and ignoring the return data.
   1476 |     function delegatecallNoReturn(address target, bytes memory data) internal returns (bool success) {
   1477 |         assembly ("memory-safe") {
>> 1478 |             success := delegatecall(gas(), target, add(data, 0x20), mload(data), 0x00, 0x00)
   1479 |         }
   1480 |     }
   1481 | 
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 1492 行
- **函数**: `delegatecallReturn64Bytes()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1489 |         bytes memory data
   1490 |     ) internal returns (bool success, bytes32 result1, bytes32 result2) {
   1491 |         assembly ("memory-safe") {
>> 1492 |             success := delegatecall(gas(), target, add(data, 0x20), mload(data), 0x00, 0x40)
   1493 |             result1 := mload(0x00)
   1494 |             result2 := mload(0x20)
   1495 |         }
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 58 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     55 |     /**
     56 |      * @dev Returns the address of the current owner.
     57 |      */
>>   58 |     function owner() public view virtual returns (address) {
     59 |         return _owner;
     60 |     }
     61 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 141 行
- **函数**: `transferAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    138 |      * @param value The amount of tokens to be transferred.
    139 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    140 |      */
>>  141 |     function transferAndCall(address to, uint256 value) external returns (bool);
    142 | 
    143 |     /**
    144 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 151 行
- **函数**: `transferAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    148 |      * @param data Additional data with no specified format, sent in call to `to`.
    149 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    150 |      */
>>  151 |     function transferAndCall(address to, uint256 value, bytes calldata data) external returns (bool);
    152 | 
    153 |     /**
    154 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 161 行
- **函数**: `transferFromAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    158 |      * @param value The amount of tokens to be transferred.
    159 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    160 |      */
>>  161 |     function transferFromAndCall(address from, address to, uint256 value) external returns (bool);
    162 | 
    163 |     /**
    164 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 172 行
- **函数**: `transferFromAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    169 |      * @param data Additional data with no specified format, sent in call to `to`.
    170 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    171 |      */
>>  172 |     function transferFromAndCall(address from, address to, uint256 value, bytes calldata data) external returns (bool);
    173 | 
    174 |     /**
    175 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 181 行
- **函数**: `approveAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    178 |      * @param value The amount of tokens to be spent.
    179 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    180 |      */
>>  181 |     function approveAndCall(address spender, uint256 value) external returns (bool);
    182 | 
    183 |     /**
    184 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 191 行
- **函数**: `approveAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    188 |      * @param data Additional data with no specified format, sent in call to `spender`.
    189 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
    190 |      */
>>  191 |     function approveAndCall(address spender, uint256 value, bytes calldata data) external returns (bool);
    192 | }
    193 | 
    194 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 243 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    240 |     /**
    241 |      * @dev Returns the value of tokens in existence.
    242 |      */
>>  243 |     function totalSupply() external view returns (uint256);
    244 | 
    245 |     /**
    246 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 248 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    245 |     /**
    246 |      * @dev Returns the value of tokens owned by `account`.
    247 |      */
>>  248 |     function balanceOf(address account) external view returns (uint256);
    249 | 
    250 |     /**
    251 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 257 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    254 |      *
    255 |      * Emits a {Transfer} event.
    256 |      */
>>  257 |     function transfer(address to, uint256 value) external returns (bool);
    258 | 
    259 |     /**
    260 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 266 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    263 |      *
    264 |      * This value changes when {approve} or {transferFrom} are called.
    265 |      */
>>  266 |     function allowance(address owner, address spender) external view returns (uint256);
    267 | 
    268 |     /**
    269 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 283 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    280 |      *
    281 |      * Emits an {Approval} event.
    282 |      */
>>  283 |     function approve(address spender, uint256 value) external returns (bool);
    284 | 
    285 |     /**
    286 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 294 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    291 |      *
    292 |      * Emits a {Transfer} event.
    293 |      */
>>  294 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    295 | }
    296 | 
    297 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 1397 行
- **函数**: `supportsInterface()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1394 |      *
   1395 |      * This function call must use less than 30 000 gas.
   1396 |      */
>> 1397 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   1398 | }
   1399 | 
   1400 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 3906 行
- **函数**: `changeDidMgr()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3903 |         mystery = _m;
   3904 |     }
   3905 | 
>> 3906 |     function changeDidMgr(address newR) external {        
   3907 |         if (msg.sender != didMgr) {
   3908 |             revert NoRight();
   3909 |         }
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 3950 行
- **函数**: `claim()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3947 |         }
   3948 |     }
   3949 | 
>> 3950 |     function claim(address account, uint256 day, uint256 amount) external {
   3951 |         if (msg.sender != mystery) {
   3952 |             revert NoRight();
   3953 |         }
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 3973 行
- **函数**: `parents()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3970 | pragma solidity ^0.8.0;
   3971 | 
   3972 | interface IBinding { 
>> 3973 |     function parents(address) external view returns (address);
   3974 | }
   3975 | 
   3976 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 3983 行
- **函数**: `price()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3980 | pragma solidity ^0.8.0;
   3981 | 
   3982 | interface ILpd { 
>> 3983 |     function price() external view returns (uint256);
   3984 |     function burn(uint256 value) external;
   3985 | }
   3986 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4171 行
- **函数**: `addMgr()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4168 |         weekDividend = address(new WeekDividend(m, address(this)));
   4169 |     }
   4170 | 
>> 4171 |     function addMgr(address mgr) external {
   4172 |         if (!checkMgr(msg.sender)) {
   4173 |             revert NoRight();
   4174 |         }
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4179 行
- **函数**: `delMgr()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4176 |         emit AddMgr(mgr);
   4177 |     }
   4178 | 
>> 4179 |     function delMgr(address mgr) external {
   4180 |         if (!checkMgr(msg.sender)) {
   4181 |             revert NoRight();
   4182 |         }
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4187 行
- **函数**: `checkMgr()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4184 |         emit DelMgr(mgr);
   4185 |     }
   4186 | 
>> 4187 |     function checkMgr(address mgr) public view returns (bool) {
   4188 |         return mgrMap.get(uint256(uint160(mgr)));
   4189 |     }
   4190 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4191 行
- **函数**: `addBox()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4188 |         return mgrMap.get(uint256(uint160(mgr)));
   4189 |     }
   4190 | 
>> 4191 |     function addBox(uint256[] memory ids, uint256[] memory uAmounts) external {
   4192 |         if (!checkMgr(msg.sender)) {
   4193 |             revert NoRight();
   4194 |         }
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4213 行
- **函数**: `delBox()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4210 |         }
   4211 |     }
   4212 | 
>> 4213 |     function delBox(uint256[] memory ids) external {
   4214 |         if (!checkMgr(msg.sender)) {
   4215 |             revert NoRight();
   4216 |         }
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4782 行
- **函数**: `changeDidMgr()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4779 |         mystery = _m;
   4780 |     }
   4781 | 
>> 4782 |     function changeDidMgr(address newR) external {
   4783 |         if (msg.sender != didMgr) {
   4784 |             revert NoRight();
   4785 |         }
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4826 行
- **函数**: `claim()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4823 |         }
   4824 |     }
   4825 | 
>> 4826 |     function claim(address account, uint256 day, uint256 amount) external {
   4827 |         if (msg.sender != mystery) {
   4828 |             revert NoRight();
   4829 |         }
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4889 行
- **函数**: `changeDidMgr()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4886 |         mystery = _m;
   4887 |     }
   4888 | 
>> 4889 |     function changeDidMgr(address newR) external {
   4890 |         if (msg.sender != didMgr) {
   4891 |             revert NoRight();
   4892 |         }
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4933 行
- **函数**: `claim()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4930 |         }
   4931 |     }
   4932 | 
>> 4933 |     function claim(address account, uint256 day, uint256 amount) external {
   4934 |         if (msg.sender != mystery) {
   4935 |             revert NoRight();
   4936 |         }
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4996 行
- **函数**: `changeDidMgr()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4993 |         mystery = _m;
   4994 |     }
   4995 | 
>> 4996 |     function changeDidMgr(address newR) external {
   4997 |         if (msg.sender != didMgr) {
   4998 |             revert NoRight();
   4999 |         }
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 5040 行
- **函数**: `claim()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5037 |         }
   5038 |     }
   5039 | 
>> 5040 |     function claim(address account, uint256 week, uint256 amount) external {
   5041 |         if (msg.sender != mystery) {
   5042 |             revert NoRight();
   5043 |         }
```

---

### 32. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 22 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     17 |  *
     18 |  * This module is used through inheritance. It will make available the modifier
     19 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     20 |  * the owner.
     21 |  */
>>   22 | abstract contract Ownable is Context {
     23 |     address private _owner;
     24 | 
     25 |     /**
     26 |      * @dev The caller account is not authorized to perform an operation.
     27 |      */
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 94 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     89 |         }
     90 |         _transferOwnership(newOwner);
     91 |     }
     92 | 
     93 |     /**
>>   94 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     95 |      * Internal function without access restriction.
     96 |      */
     97 |     function _transferOwnership(address newOwner) internal virtual {
     98 |         address oldOwner = _owner;
     99 |         _owner = newOwner;
```

---

### 34. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 311 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    306 | import {IERC1363} from "../../../interfaces/IERC1363.sol";
    307 | 
    308 | /**
    309 |  * @title SafeERC20
    310 |  * @dev Wrappers around ERC-20 operations that throw on failure (when the token
>>  311 |  * contract returns false). Tokens that return no value (and instead revert or
    312 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    313 |  * successful.
    314 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    315 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    316 |  */
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 1921 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1916 |      * Requirements:
   1917 |      * - modulus can't be zero
   1918 |      * - underlying staticcall to precompile must succeed
   1919 |      *
   1920 |      * IMPORTANT: The result is only valid if the underlying call succeeds. When using this function, make
>> 1921 |      * sure the chain you're using it on supports the precompiled contract for modular exponentiation
   1922 |      * at address 0x05 as specified in https://eips.ethereum.org/EIPS/eip-198[EIP-198]. Otherwise,
   1923 |      * the underlying function will succeed given the lack of a revert, but the result may be incorrectly
   1924 |      * interpreted as 0.
   1925 |      */
   1926 |     function modExp(uint256 b, uint256 e, uint256 m) internal view returns (uint256) {
```

---

### 36. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 3869 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3864 | 
   3865 | import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
   3866 | import "@openzeppelin/contracts/utils/cryptography/MerkleProof.sol";
   3867 | import "@openzeppelin/contracts/access/Ownable.sol";
   3868 | 
>> 3869 | contract DynStakingDividend is Ownable {
   3870 |     using SafeERC20 for IERC20;
   3871 | 
   3872 |     error NoRight();
   3873 |     error AlreadyUpdated();
   3874 |     error DayNotUpdated();
```

---

### 37. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4007 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4002 | import "./DynStakingDividend.sol";
   4003 | import "./NodeDividend.sol";
   4004 | import "./RebateDividend.sol";
   4005 | import "./WeekDividend.sol";
   4006 | 
>> 4007 | contract Mystery is ReentrancyGuard, Ownable {
   4008 |     using BitMaps for BitMaps.BitMap;
   4009 |     using SafeERC20 for IERC20;
   4010 | 
   4011 |     error NoBinding();
   4012 |     error NoRight();
```

---

### 38. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4745 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4740 | 
   4741 | import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
   4742 | import "@openzeppelin/contracts/utils/cryptography/MerkleProof.sol";
   4743 | import "@openzeppelin/contracts/access/Ownable.sol";
   4744 | 
>> 4745 | contract NodeDividend is Ownable {
   4746 |     using SafeERC20 for IERC20;
   4747 | 
   4748 |     error NoRight();
   4749 |     error AlreadyUpdated();
   4750 |     error DayNotUpdated();
```

---

### 39. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4852 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4847 | 
   4848 | import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
   4849 | import "@openzeppelin/contracts/utils/cryptography/MerkleProof.sol";
   4850 | import "@openzeppelin/contracts/access/Ownable.sol";
   4851 | 
>> 4852 | contract RebateDividend is Ownable {
   4853 |     using SafeERC20 for IERC20;
   4854 | 
   4855 |     error NoRight();
   4856 |     error AlreadyUpdated();
   4857 |     error DayNotUpdated();
```

---

### 40. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4959 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4954 | 
   4955 | import "@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol";
   4956 | import "@openzeppelin/contracts/utils/cryptography/MerkleProof.sol";
   4957 | import "@openzeppelin/contracts/access/Ownable.sol";
   4958 | 
>> 4959 | contract WeekDividend is Ownable {
   4960 |     using SafeERC20 for IERC20;
   4961 | 
   4962 |     error NoRight();
   4963 |     error AlreadyUpdated();
   4964 |     error WeekNotUpdated();
```

---

### 41. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4249 行
- **函数**: `stake()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4246 |         stakingPerAccount[msg.sender][orderIndex] = StakingInfo({
   4247 |             uAmount: uAmount,
   4248 |             tokenAmount: tokenAmount,
>> 4249 |             timestamp: uint64(block.timestamp),
   4250 |             claimed: 0
   4251 |         });
   4252 |         stakingOrderMaxIndexPerAccount[msg.sender]++;
```

---

### 42. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4263 行
- **函数**: `claimablePoints()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4260 |         while (orderIndex < stakingOrderMaxIndexPerAccount[account]) {
   4261 |             StakingInfo memory info = stakingPerAccount[account][orderIndex];
   4262 |             if (info.claimed < MAX_CLAIM) {
>> 4263 |                 uint64 diff = (uint64(block.timestamp) - info.timestamp) /
   4264 |                     PERIOD;
   4265 |                 if (diff > MAX_CLAIM) {
   4266 |                     diff = MAX_CLAIM;
```

---

### 43. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4288 行
- **函数**: `claim()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4285 |         if (info.claimed >= MAX_CLAIM) {
   4286 |             revert ClaimFinished();
   4287 |         }
>> 4288 |         diff = (uint64(block.timestamp) - info.timestamp) / PERIOD;
   4289 |         if (diff > MAX_CLAIM) {
   4290 |             diff = MAX_CLAIM;
   4291 |         }
```

---

### 44. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4369 行
- **函数**: `buy()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4366 |                 uAmount: uAmount,
   4367 |                 openAmount: 0,
   4368 |                 status: BoxOrderStatus.Bought,
>> 4369 |                 boughtTimestamp: uint64(block.timestamp),
   4370 |                 openTimestamp: 0,
   4371 |                 swappingTimestamp: 0,
   4372 |                 swappedTimestamp: 0,
```

---

### 45. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4430 行
- **函数**: `open()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4427 |                 revert StatusError();
   4428 |             }
   4429 |             order.openAmount = openAmounts[i];
>> 4430 |             order.openTimestamp = uint64(block.timestamp);
   4431 |             order.status = BoxOrderStatus.Open;
   4432 |             emit Open(accounts[i], orderIndexs[i], openAmounts[i]);
   4433 |         }
```

---

### 46. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4461 行
- **函数**: `pay()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4458 |                 if (order.status != BoxOrderStatus.Open) {
   4459 |                     revert StatusError();
   4460 |                 }
>> 4461 |                 order.payTimestamp = uint64(block.timestamp);
   4462 |                 order.status = BoxOrderStatus.Paid;
   4463 |                 totalU += order.openAmount;
   4464 |             }
```

---

### 47. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4545 行
- **函数**: `swapped()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4542 |                 revert InvalidAmount();
   4543 |             }
   4544 |             order.status = BoxOrderStatus.Swapped;
>> 4545 |             order.swappedTimestamp = uint64(block.timestamp);
   4546 |             withdrawablePointsPerAccount[accounts[i]] +=
   4547 |                 (order.openAmount * 9) /
   4548 |                 10;
```

---

### 48. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 2189 行
- **函数**: `log2()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2186 |         //
   2187 |         // The lookup table is represented as a 32-byte value with the MSB positions for 0-15 in the first 16 bytes (most significant half).
   2188 |         assembly ("memory-safe") {
>> 2189 |             r := or(r, byte(shr(r, x), 0x0000010102020202030303030303030300000000000000000000000000000000))
   2190 |         }
   2191 |     }
   2192 | 
```

---

### 49. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 3564 行
- **函数**: `panic()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3561 | 
   3562 |     // keccak256(abi.encode(uint256(keccak256("openzeppelin.storage.ReentrancyGuard")) - 1)) & ~bytes32(uint256(0xff))
   3563 |     bytes32 private constant REENTRANCY_GUARD_STORAGE =
>> 3564 |         0x9b779b17422d0df92223018b32b4d1fa46e071723d6817e2486d003becc55f00;
   3565 | 
   3566 |     // Booleans are more expensive than uint256 or any type that takes up a full
   3567 |     // word because each write operation emits an extra SLOAD to first read the
```

---

### 50. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4107 行
- **函数**: `burn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4104 |     }
   4105 | 
   4106 |     IBinding public constant binding =
>> 4107 |         IBinding(0x902768873a5733870288E96371bC2ca33D4bF916);
   4108 | 
   4109 |     struct StakingInfo {
   4110 |         uint256 uAmount;
```

---

### 51. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4133 行
- **函数**: `burn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4130 |     uint256 public constant CLAIM_RATE = 2;
   4131 |     uint64 public constant MAX_CLAIM = 100;
   4132 |     uint256 public constant MAX_STAKE_ORDER = 100;
>> 4133 |     address public constant TOKEN = 0x99b3857a8181371C50C35676e5D189228B7DcEDb;
   4134 | 
   4135 |     address public immutable dynStakingDividend;
   4136 |     address public immutable nodeDividend;
```

---

### 52. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4164 行
- **函数**: `burn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4161 |         receiver = r;
   4162 |         didMgr = m;
   4163 |         mgrMap.set(uint256(uint160(b)));
>> 4164 |         mgrMap.set(uint256(uint160(0x69F041dC78BFb9263bc01C2c8555Fa4A5bABF3CD)));
   4165 |         dynStakingDividend = address(new DynStakingDividend(m, address(this)));
   4166 |         nodeDividend = address(new NodeDividend(m, address(this)));
   4167 |         rebateDividend = address(new RebateDividend(m, address(this)));
```

---

### 53. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x862b8280bB53fDAD231760B6dDC75ED6BF3b0351` 第 4728 行
- **函数**: `_isContract()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4725 | 
   4726 |     function _isContract(address account) private view returns (bool) {
   4727 |         uint256 size;
>> 4728 |         assembly {
   4729 |             size := extcodesize(account)
   4730 |         }
   4731 |         return size > 0;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*