# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:31:22
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x777281a1134A4693cB64b67A699E7A51EC3479b5` |
| contract_name | `FlowXProtocol` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/interfaces/IERC1363.sol', '@openzeppelin/contracts/interfaces/IERC165.sol', '@openzeppelin/contracts/interfaces/IERC20.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/utils/cryptography/ECDSA.sol', '@openzeppelin/contracts/utils/introspection/IERC165.sol', '@openzeppelin/contracts/utils/Pausable.sol', '@openzeppelin/contracts/utils/ReentrancyGuard.sol', '@openzeppelin/contracts/utils/StorageSlot.sol', 'contracts/FlowXDex.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655011` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 29 |
| 🟢 LOW | 27 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1691 行
- **函数**: `_accrueSIPROI()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1688 |         // ROI accrues only for the 7-day window ending at `lastSipTime + 7 * TIME_UNIT`,
   1689 |         // in whole-day increments.
   1690 |         uint256 capTime = s.lastSipTime + (7 * TIME_UNIT);
>> 1691 |         uint256 effectiveNow = block.timestamp < capTime ? block.timestamp : capTime;
   1692 |         if (effectiveNow <= s.lastClaimTime) return;
   1693 | 
   1694 |         uint256 periodsPassed = (effectiveNow - s.lastClaimTime) / TIME_UNIT;
```

---

### 2. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1961 行
- **函数**: `updateStakeRewards()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1958 |             if (s.totalRoi <= s.claimedRoi) continue;
   1959 | 
   1960 |             uint256 stakeEnd = s.startTime + (s.totalDays * TIME_UNIT);
>> 1961 |             uint256 effectiveNow = block.timestamp < stakeEnd ? block.timestamp : stakeEnd;
   1962 |             if (effectiveNow <= s.lastClaimTime) continue;
   1963 | 
   1964 |             uint256 periodsPassed = (effectiveNow - s.lastClaimTime) / TIME_UNIT;
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 37 行
- **函数**: `transferAndCall()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     34 |      * @param value The amount of tokens to be transferred.
     35 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
     36 |      */
>>   37 |     function transferAndCall(address to, uint256 value) external returns (bool);
     38 | 
     39 |     /**
     40 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 47 行
- **函数**: `transferAndCall()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     44 |      * @param data Additional data with no specified format, sent in call to `to`.
     45 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
     46 |      */
>>   47 |     function transferAndCall(address to, uint256 value, bytes calldata data) external returns (bool);
     48 | 
     49 |     /**
     50 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 57 行
- **函数**: `transferFromAndCall()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     54 |      * @param value The amount of tokens to be transferred.
     55 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
     56 |      */
>>   57 |     function transferFromAndCall(address from, address to, uint256 value) external returns (bool);
     58 | 
     59 |     /**
     60 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the allowance mechanism
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 68 行
- **函数**: `transferFromAndCall()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     65 |      * @param data Additional data with no specified format, sent in call to `to`.
     66 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
     67 |      */
>>   68 |     function transferFromAndCall(address from, address to, uint256 value, bytes calldata data) external returns (bool);
     69 | 
     70 |     /**
     71 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 77 行
- **函数**: `approveAndCall()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     74 |      * @param value The amount of tokens to be spent.
     75 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
     76 |      */
>>   77 |     function approveAndCall(address spender, uint256 value) external returns (bool);
     78 | 
     79 |     /**
     80 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 87 行
- **函数**: `approveAndCall()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     84 |      * @param data Additional data with no specified format, sent in call to `spender`.
     85 |      * @return A boolean value indicating whether the operation succeeded unless throwing.
     86 |      */
>>   87 |     function approveAndCall(address spender, uint256 value, bytes calldata data) external returns (bool);
     88 | }
     89 | 
     90 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 139 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    136 |     /**
    137 |      * @dev Returns the value of tokens in existence.
    138 |      */
>>  139 |     function totalSupply() external view returns (uint256);
    140 | 
    141 |     /**
    142 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 144 行
- **函数**: `balanceOf()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    141 |     /**
    142 |      * @dev Returns the value of tokens owned by `account`.
    143 |      */
>>  144 |     function balanceOf(address account) external view returns (uint256);
    145 | 
    146 |     /**
    147 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 153 行
- **函数**: `transfer()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    150 |      *
    151 |      * Emits a {Transfer} event.
    152 |      */
>>  153 |     function transfer(address to, uint256 value) external returns (bool);
    154 | 
    155 |     /**
    156 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 162 行
- **函数**: `allowance()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    159 |      *
    160 |      * This value changes when {approve} or {transferFrom} are called.
    161 |      */
>>  162 |     function allowance(address owner, address spender) external view returns (uint256);
    163 | 
    164 |     /**
    165 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 179 行
- **函数**: `approve()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    176 |      *
    177 |      * Emits an {Approval} event.
    178 |      */
>>  179 |     function approve(address spender, uint256 value) external returns (bool);
    180 | 
    181 |     /**
    182 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 190 行
- **函数**: `transferFrom()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    187 |      *
    188 |      * Emits a {Transfer} event.
    189 |      */
>>  190 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    191 | }
    192 | 
    193 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 823 行
- **函数**: `supportsInterface()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    820 |      *
    821 |      * This function call must use less than 30 000 gas.
    822 |      */
>>  823 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
    824 | }
    825 | 
    826 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 895 行
- **函数**: `paused()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    892 |     /**
    893 |      * @dev Returns true if the contract is paused, and false otherwise.
    894 |      */
>>  895 |     function paused() public view virtual returns (bool) {
    896 |         return _paused;
    897 |     }
    898 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1228 行
- **函数**: `balanceOf()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1225 | interface IFlowX {
   1226 |     function mint(address to, uint256 amount) external;
   1227 |     function burn(address from, uint256 amount) external;
>> 1228 |     function balanceOf(address account) external view returns (uint256);
   1229 |     function totalSupply() external view returns (uint256);
   1230 | }
   1231 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1229 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1226 |     function mint(address to, uint256 amount) external;
   1227 |     function burn(address from, uint256 amount) external;
   1228 |     function balanceOf(address account) external view returns (uint256);
>> 1229 |     function totalSupply() external view returns (uint256);
   1230 | }
   1231 | 
   1232 | /// @title FlowXProtocol — investment platform with referral registration, SIP, ROI & price mechanics
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1946 行
- **函数**: `updateStakeRewards()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1943 |     // ═══════════════════════════════ ROI (Oracle) ════════════════════════
   1944 | 
   1945 |     /// @notice Oracle calls this to accrue linear daily ROI across all active stakes.
>> 1946 |     function updateStakeRewards(address _user) external onlyOracle {
   1947 |         User storage u = users[_user];
   1948 |         if (!u.isActive || u.totalInvestment == 0) return;
   1949 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1994 行
- **函数**: `updateSipRewards()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1991 |     }
   1992 | 
   1993 |     /// @notice Oracle calls this daily to accrue SIP ROI for active SIPs.
>> 1994 |     function updateSipRewards(address _user) external onlyOracle {
   1995 |         User storage u = users[_user];
   1996 |         if (!u.isActive) return;
   1997 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 2006 行
- **函数**: `updateRewardIncome()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2003 | 
   2004 |     /// @notice Oracle updates external reward income for a user (capped by max payout).
   2005 |     /// @dev No loops and no external calls. Exits early if user already reached cap.
>> 2006 |     function updateRewardIncome(address user, uint256 amount) external onlyOracle {
   2007 |         if (user == address(0)) revert ZeroAddress();
   2008 |         if (amount == 0) revert InvalidAmount();
   2009 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 2072 行
- **函数**: `isUserActive()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2069 | 
   2070 |     // ═══════════════════════════════ View Helpers ════════════════════════
   2071 | 
>> 2072 |     function isUserActive(address _user) external view returns (bool) {
   2073 |         return users[_user].isActive;
   2074 |     }
   2075 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 2076 行
- **函数**: `isUserRegistered()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2073 |         return users[_user].isActive;
   2074 |     }
   2075 | 
>> 2076 |     function isUserRegistered(address _user) external view returns (bool) {
   2077 |         return users[_user].isRegistered;
   2078 |     }
   2079 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 2080 行
- **函数**: `getReferralCount()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2077 |         return users[_user].isRegistered;
   2078 |     }
   2079 | 
>> 2080 |     function getReferralCount(address _user) external view returns (uint256) {
   2081 |         return users[_user].totalReferralCount;
   2082 |     }
   2083 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 2084 行
- **函数**: `getPrice()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2081 |         return users[_user].totalReferralCount;
   2082 |     }
   2083 | 
>> 2084 |     function getPrice() external view returns (uint256) {
   2085 |         if (totalSupply == 0) return BASE_PRICE;
   2086 |         return (liquidityPool * PRICE_PRECISION) / totalSupply;
   2087 |     }
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 2205 行
- **函数**: `setOracle()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2202 |         require(valid == 2, "Not enough signatures");
   2203 |     }
   2204 | 
>> 2205 |     function setOracle(address _newOracle, bytes[] calldata sigs) external {
   2206 |         if (_newOracle == address(0)) revert ZeroAddress();
   2207 |         bytes32 hash = keccak256(abi.encodePacked(address(this), block.chainid, adminSigNonce, "setOracle", _newOracle));
   2208 |         _verifyAdminSignatures(hash, sigs);
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 207 行
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    202 | import {IERC1363} from "../../../interfaces/IERC1363.sol";
    203 | 
    204 | /**
    205 |  * @title SafeERC20
    206 |  * @dev Wrappers around ERC-20 operations that throw on failure (when the token
>>  207 |  * contract returns false). Tokens that return no value (and instead revert or
    208 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    209 |  * successful.
    210 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    211 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    212 |  */
```

---

### 28. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 845 行
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    840 |  * This module is used through inheritance. It will make available the
    841 |  * modifiers `whenNotPaused` and `whenPaused`, which can be applied to
    842 |  * the functions of your contract. Note that they will not be pausable by
    843 |  * simply including this module, only once the modifiers are put in place.
    844 |  */
>>  845 | abstract contract Pausable is Context {
    846 |     bool private _paused;
    847 | 
    848 |     /**
    849 |      * @dev Emitted when the pause is triggered by `account`.
    850 |      */
```

---

### 29. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1233 行
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1228 |     function balanceOf(address account) external view returns (uint256);
   1229 |     function totalSupply() external view returns (uint256);
   1230 | }
   1231 | 
   1232 | /// @title FlowXProtocol — investment platform with referral registration, SIP, ROI & price mechanics
>> 1233 | contract FlowXProtocol is ReentrancyGuard, Pausable {
   1234 |     using SafeERC20 for IERC20;
   1235 |     using ECDSA for bytes32;
   1236 | 
   1237 |     // ═══════════════════════════════ Types ═══════════════════════════════
   1238 | 
```

---

### 30. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1594 行
- **函数**: `stakeTokens()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1591 | 
   1592 |         if (!u.isActive) {
   1593 |             u.isActive      = true;
>> 1594 |             u.lastRoiUpdate = block.timestamp;
   1595 |         }
   1596 | 
   1597 |         // Mint principal tokens to the contract (escrow).
```

---

### 31. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1622 行
- **函数**: `stakeTokens()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1619 |                 totalRoi:        totalRoi,
   1620 |                 totalDays:       totalDays,
   1621 |                 claimedRoi:      0,
>> 1622 |                 startTime:       block.timestamp,
   1623 |                 lastClaimTime:   block.timestamp
   1624 |             })
   1625 |         );
```

---

### 32. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1623 行
- **函数**: `stakeTokens()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1620 |                 totalDays:       totalDays,
   1621 |                 claimedRoi:      0,
   1622 |                 startTime:       block.timestamp,
>> 1623 |                 lastClaimTime:   block.timestamp
   1624 |             })
   1625 |         );
   1626 | 
```

---

### 33. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1657 行
- **函数**: `sellTokens()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1654 |         if (usdt.balanceOf(address(this)) < payout) revert InsufficientLiquidity();
   1655 | 
   1656 |         // --- 24-hour sell limit ---
>> 1657 |         if (block.timestamp >= sellWindowStart[msg.sender] + 1 days) {
   1658 |             sellWindowStart[msg.sender] = block.timestamp;
   1659 |             dailySellTotal[msg.sender]  = 0;
   1660 |         }
```

---

### 34. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1658 行
- **函数**: `sellTokens()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1655 | 
   1656 |         // --- 24-hour sell limit ---
   1657 |         if (block.timestamp >= sellWindowStart[msg.sender] + 1 days) {
>> 1658 |             sellWindowStart[msg.sender] = block.timestamp;
   1659 |             dailySellTotal[msg.sender]  = 0;
   1660 |         }
   1661 |         dailySellTotal[msg.sender] += payout;
```

---

### 35. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1691 行
- **函数**: `_accrueSIPROI()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1688 |         // ROI accrues only for the 7-day window ending at `lastSipTime + 7 * TIME_UNIT`,
   1689 |         // in whole-day increments.
   1690 |         uint256 capTime = s.lastSipTime + (7 * TIME_UNIT);
>> 1691 |         uint256 effectiveNow = block.timestamp < capTime ? block.timestamp : capTime;
   1692 |         if (effectiveNow <= s.lastClaimTime) return;
   1693 | 
   1694 |         uint256 periodsPassed = (effectiveNow - s.lastClaimTime) / TIME_UNIT;
```

---

### 36. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1713 行
- **函数**: `_accrueSIPROI()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1710 |         u.remainingCap = remainingCap - earned;
   1711 |         s.claimedRoi += earned;
   1712 |         s.lastClaimTime += periodsPassed * TIME_UNIT;
>> 1713 |         u.lastRoiUpdate = block.timestamp;
   1714 | 
   1715 |         emit sipRewardUpdated(_user, earned);
   1716 |     }
```

---

### 37. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1841 行
- **函数**: `startSIP()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1838 | 
   1839 |         if (!u.isActive) {
   1840 |             u.isActive = true;
>> 1841 |             u.lastRoiUpdate = block.timestamp;
   1842 |         }
   1843 | 
   1844 |         // --- interactions: mint principal escrow + pay admin fee ---
```

---

### 38. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1858 行
- **函数**: `startSIP()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1855 |         s.totalInvestSIP = usdtAmount;
   1856 |         s.mintedTokens    = tokens;
   1857 | 
>> 1858 |         s.lastSipTime = block.timestamp;
   1859 |         s.startTime   = block.timestamp;
   1860 |         s.lastClaimTime = block.timestamp;
   1861 | 
```

---

### 39. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1859 行
- **函数**: `startSIP()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1856 |         s.mintedTokens    = tokens;
   1857 | 
   1858 |         s.lastSipTime = block.timestamp;
>> 1859 |         s.startTime   = block.timestamp;
   1860 |         s.lastClaimTime = block.timestamp;
   1861 | 
   1862 |         s.roiBase  = mintValue;
```

---

### 40. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1860 行
- **函数**: `startSIP()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1857 | 
   1858 |         s.lastSipTime = block.timestamp;
   1859 |         s.startTime   = block.timestamp;
>> 1860 |         s.lastClaimTime = block.timestamp;
   1861 | 
   1862 |         s.roiBase  = mintValue;
   1863 |         s.dailyRoi = (s.roiBase * 2) / 100;
```

---

### 41. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1876 行
- **函数**: `paySIP()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1873 |         if (!s.active) revert SIPNotActive();
   1874 |         if (s.sipCount >= 25) revert SIPComplete();
   1875 | 
>> 1876 |         if (block.timestamp < s.lastSipTime + (7 * TIME_UNIT)) revert SIPNotDue();
   1877 |         // Accrue ROI credited for the previous 7-day window.
   1878 |         _accrueSIPROI(msg.sender);
   1879 | 
```

---

### 42. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1920 行
- **函数**: `paySIP()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1917 |         s.roiBase  = (s.totalInvestSIP * 72) / 100;
   1918 |         s.dailyRoi = (s.roiBase * 2) / 100;
   1919 | 
>> 1920 |         s.lastSipTime = block.timestamp;
   1921 |         s.lastClaimTime = block.timestamp;
   1922 |         if (s.sipCount == 25) {
   1923 |             s.active = false;
```

---

### 43. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1921 行
- **函数**: `paySIP()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1918 |         s.dailyRoi = (s.roiBase * 2) / 100;
   1919 | 
   1920 |         s.lastSipTime = block.timestamp;
>> 1921 |         s.lastClaimTime = block.timestamp;
   1922 |         if (s.sipCount == 25) {
   1923 |             s.active = false;
   1924 |             uint256 finalRoi = 7 * s.dailyRoi;
```

---

### 44. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1961 行
- **函数**: `updateStakeRewards()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1958 |             if (s.totalRoi <= s.claimedRoi) continue;
   1959 | 
   1960 |             uint256 stakeEnd = s.startTime + (s.totalDays * TIME_UNIT);
>> 1961 |             uint256 effectiveNow = block.timestamp < stakeEnd ? block.timestamp : stakeEnd;
   1962 |             if (effectiveNow <= s.lastClaimTime) continue;
   1963 | 
   1964 |             uint256 periodsPassed = (effectiveNow - s.lastClaimTime) / TIME_UNIT;
```

---

### 45. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1988 行
- **函数**: `updateStakeRewards()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1985 |         u.balance += totalEarned;
   1986 |         u.totalStakeRoi += totalEarned;
   1987 |         u.remainingCap = remainingCap;
>> 1988 |         u.lastRoiUpdate = block.timestamp;
   1989 | 
   1990 |         emit stakeRewardUpdated(_user, totalEarned);
   1991 |     }
```

---

### 46. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 661 行
- **函数**: `tryRecover()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    658 |         bytes32 vs
    659 |     ) internal pure returns (address recovered, RecoverError err, bytes32 errArg) {
    660 |         unchecked {
>>  661 |             bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
    662 |             // We do not check for an overflow here since the shift operation results in 0 or 1.
    663 |             uint8 v = uint8((uint256(vs) >> 255) + 27);
    664 |             return tryRecover(hash, v, r, s);
```

---

### 47. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 696 行
- **函数**: `tryRecover()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    693 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
    694 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
    695 |         // these malleable signatures as well.
>>  696 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
    697 |             return (address(0), RecoverError.InvalidSignatureS, s);
    698 |         }
    699 | 
```

---

### 48. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 981 行
- **函数**: `_unpause()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    978 | 
    979 |     // keccak256(abi.encode(uint256(keccak256("openzeppelin.storage.ReentrancyGuard")) - 1)) & ~bytes32(uint256(0xff))
    980 |     bytes32 private constant REENTRANCY_GUARD_STORAGE =
>>  981 |         0x9b779b17422d0df92223018b32b4d1fa46e071723d6817e2486d003becc55f00;
    982 | 
    983 |     // Booleans are more expensive than uint256 or any type that takes up a full
    984 |     // word because each write operation emits an extra SLOAD to first read the
```

---

### 49. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1338 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1335 |     uint256 public constant MINT_PCT        = 80;    // 80% of post-fee USDT determines token amount
   1336 |     uint256 public constant SELL_PAYOUT_PCT = 85;
   1337 |     uint256 public constant DAILY_SELL_LIMIT = 1000e18;
>> 1338 |     address public constant WALLET_WITHDRAW_FEE1 = 0xC9532084f37c23002860Ec353Bfd79CADF291B18;
   1339 |     address public constant WALLET_WITHDRAW_FEE2 = 0x5EA52319841B21B0B3B517436dd6Bda5d9059F79;
   1340 |     // ═══════════════════════ Fixed reward wallets (deposit fee split) ═══════════════════════
   1341 |     // Percentages are expressed in BPS out of 1000, because adminFee is 10% of deposit.
```

---

### 50. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1339 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1336 |     uint256 public constant SELL_PAYOUT_PCT = 85;
   1337 |     uint256 public constant DAILY_SELL_LIMIT = 1000e18;
   1338 |     address public constant WALLET_WITHDRAW_FEE1 = 0xC9532084f37c23002860Ec353Bfd79CADF291B18;
>> 1339 |     address public constant WALLET_WITHDRAW_FEE2 = 0x5EA52319841B21B0B3B517436dd6Bda5d9059F79;
   1340 |     // ═══════════════════════ Fixed reward wallets (deposit fee split) ═══════════════════════
   1341 |     // Percentages are expressed in BPS out of 1000, because adminFee is 10% of deposit.
   1342 |     uint256 private constant _REWARD_BPS_DENOM = 1000;
```

---

### 51. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1343 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1340 |     // ═══════════════════════ Fixed reward wallets (deposit fee split) ═══════════════════════
   1341 |     // Percentages are expressed in BPS out of 1000, because adminFee is 10% of deposit.
   1342 |     uint256 private constant _REWARD_BPS_DENOM = 1000;
>> 1343 |     address private constant _REWARD_WALLET_1 = 0x1Ea547040b0924212C07cF570884fEBF1f9B4DD4; // 2%
   1344 |     address private constant _REWARD_WALLET_2 = 0x35D52c80651ccAFAAD9465438cbd11e0be299a47; // 1.5%
   1345 |     address private constant _REWARD_WALLET_3 = 0x4f58A6e9F86908a6E6F190110E3A40952Fe99029; // 1.5%
   1346 |     address private constant _REWARD_WALLET_4 = 0xE965b33232e512DbCc7DFE11287282A5d7b255D3; // 2%
```

---

### 52. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1344 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1341 |     // Percentages are expressed in BPS out of 1000, because adminFee is 10% of deposit.
   1342 |     uint256 private constant _REWARD_BPS_DENOM = 1000;
   1343 |     address private constant _REWARD_WALLET_1 = 0x1Ea547040b0924212C07cF570884fEBF1f9B4DD4; // 2%
>> 1344 |     address private constant _REWARD_WALLET_2 = 0x35D52c80651ccAFAAD9465438cbd11e0be299a47; // 1.5%
   1345 |     address private constant _REWARD_WALLET_3 = 0x4f58A6e9F86908a6E6F190110E3A40952Fe99029; // 1.5%
   1346 |     address private constant _REWARD_WALLET_4 = 0xE965b33232e512DbCc7DFE11287282A5d7b255D3; // 2%
   1347 |     address private constant _REWARD_WALLET_5 = 0xe758c049FB608FCe71653B3ef108dbbA525801d3; // 1.5%
```

---

### 53. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1345 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1342 |     uint256 private constant _REWARD_BPS_DENOM = 1000;
   1343 |     address private constant _REWARD_WALLET_1 = 0x1Ea547040b0924212C07cF570884fEBF1f9B4DD4; // 2%
   1344 |     address private constant _REWARD_WALLET_2 = 0x35D52c80651ccAFAAD9465438cbd11e0be299a47; // 1.5%
>> 1345 |     address private constant _REWARD_WALLET_3 = 0x4f58A6e9F86908a6E6F190110E3A40952Fe99029; // 1.5%
   1346 |     address private constant _REWARD_WALLET_4 = 0xE965b33232e512DbCc7DFE11287282A5d7b255D3; // 2%
   1347 |     address private constant _REWARD_WALLET_5 = 0xe758c049FB608FCe71653B3ef108dbbA525801d3; // 1.5%
   1348 |     address private constant _REWARD_WALLET_6 = 0x89a72F5804e416222756b5672Df7409912DEd4E1; // 1.5%
```

---

### 54. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1346 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1343 |     address private constant _REWARD_WALLET_1 = 0x1Ea547040b0924212C07cF570884fEBF1f9B4DD4; // 2%
   1344 |     address private constant _REWARD_WALLET_2 = 0x35D52c80651ccAFAAD9465438cbd11e0be299a47; // 1.5%
   1345 |     address private constant _REWARD_WALLET_3 = 0x4f58A6e9F86908a6E6F190110E3A40952Fe99029; // 1.5%
>> 1346 |     address private constant _REWARD_WALLET_4 = 0xE965b33232e512DbCc7DFE11287282A5d7b255D3; // 2%
   1347 |     address private constant _REWARD_WALLET_5 = 0xe758c049FB608FCe71653B3ef108dbbA525801d3; // 1.5%
   1348 |     address private constant _REWARD_WALLET_6 = 0x89a72F5804e416222756b5672Df7409912DEd4E1; // 1.5%
   1349 | 
```

---

### 55. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1347 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1344 |     address private constant _REWARD_WALLET_2 = 0x35D52c80651ccAFAAD9465438cbd11e0be299a47; // 1.5%
   1345 |     address private constant _REWARD_WALLET_3 = 0x4f58A6e9F86908a6E6F190110E3A40952Fe99029; // 1.5%
   1346 |     address private constant _REWARD_WALLET_4 = 0xE965b33232e512DbCc7DFE11287282A5d7b255D3; // 2%
>> 1347 |     address private constant _REWARD_WALLET_5 = 0xe758c049FB608FCe71653B3ef108dbbA525801d3; // 1.5%
   1348 |     address private constant _REWARD_WALLET_6 = 0x89a72F5804e416222756b5672Df7409912DEd4E1; // 1.5%
   1349 | 
   1350 |     uint256 private constant _REWARD_WALLET_1_BPS = 200;
```

---

### 56. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x777281a1134A4693cB64b67A699E7A51EC3479b5` 第 1348 行
- **函数**: `totalSupply()`
- **合约**: `after`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1345 |     address private constant _REWARD_WALLET_3 = 0x4f58A6e9F86908a6E6F190110E3A40952Fe99029; // 1.5%
   1346 |     address private constant _REWARD_WALLET_4 = 0xE965b33232e512DbCc7DFE11287282A5d7b255D3; // 2%
   1347 |     address private constant _REWARD_WALLET_5 = 0xe758c049FB608FCe71653B3ef108dbbA525801d3; // 1.5%
>> 1348 |     address private constant _REWARD_WALLET_6 = 0x89a72F5804e416222756b5672Df7409912DEd4E1; // 1.5%
   1349 | 
   1350 |     uint256 private constant _REWARD_WALLET_1_BPS = 200;
   1351 |     uint256 private constant _REWARD_WALLET_2_BPS = 150;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*