# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:21:45
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x850026ad9Ece0505A45148b843CC338a77405555` |
| contract_name | `FIFTHToken` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646144` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 51 |
| 🟢 LOW | 18 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2447 行
- **函数**: `getReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2444 | 
   2445 | interface IPancakePair {
   2446 |     function sync() external;
>> 2447 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2448 |     function token0() external view returns (address);
   2449 |     function token1() external view returns (address);
   2450 |     function totalSupply() external view returns (uint256);
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 28 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     25 |     /**
     26 |      * @dev Returns the value of tokens in existence.
     27 |      */
>>   28 |     function totalSupply() external view returns (uint256);
     29 | 
     30 |     /**
     31 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 33 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     30 |     /**
     31 |      * @dev Returns the value of tokens owned by `account`.
     32 |      */
>>   33 |     function balanceOf(address account) external view returns (uint256);
     34 | 
     35 |     /**
     36 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 42 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     39 |      *
     40 |      * Emits a {Transfer} event.
     41 |      */
>>   42 |     function transfer(address to, uint256 value) external returns (bool);
     43 | 
     44 |     /**
     45 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 51 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     48 |      *
     49 |      * This value changes when {approve} or {transferFrom} are called.
     50 |      */
>>   51 |     function allowance(address owner, address spender) external view returns (uint256);
     52 | 
     53 |     /**
     54 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 68 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     65 |      *
     66 |      * Emits an {Approval} event.
     67 |      */
>>   68 |     function approve(address spender, uint256 value) external returns (bool);
     69 | 
     70 |     /**
     71 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 79 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     76 |      *
     77 |      * Emits a {Transfer} event.
     78 |      */
>>   79 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
     80 | }
     81 | 
     82 | // File: @openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 97 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     94 |     /**
     95 |      * @dev Returns the name of the token.
     96 |      */
>>   97 |     function name() external view returns (string memory);
     98 | 
     99 |     /**
    100 |      * @dev Returns the symbol of the token.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 102 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     99 |     /**
    100 |      * @dev Returns the symbol of the token.
    101 |      */
>>  102 |     function symbol() external view returns (string memory);
    103 | 
    104 |     /**
    105 |      * @dev Returns the decimals places of the token.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 107 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    104 |     /**
    105 |      * @dev Returns the decimals places of the token.
    106 |      */
>>  107 |     function decimals() external view returns (uint8);
    108 | }
    109 | 
    110 | // File: @openzeppelin/contracts/utils/Context.sol
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 354 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    351 |     /**
    352 |      * @dev Returns the name of the token.
    353 |      */
>>  354 |     function name() public view virtual returns (string memory) {
    355 |         return _name;
    356 |     }
    357 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 362 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    359 |      * @dev Returns the symbol of the token, usually a shorter version of the
    360 |      * name.
    361 |      */
>>  362 |     function symbol() public view virtual returns (string memory) {
    363 |         return _symbol;
    364 |     }
    365 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 379 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    376 |      * no way affects any of the arithmetic of the contract, including
    377 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    378 |      */
>>  379 |     function decimals() public view virtual returns (uint8) {
    380 |         return 18;
    381 |     }
    382 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 384 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    381 |     }
    382 | 
    383 |     /// @inheritdoc IERC20
>>  384 |     function totalSupply() public view virtual returns (uint256) {
    385 |         return _totalSupply;
    386 |     }
    387 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 389 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    386 |     }
    387 | 
    388 |     /// @inheritdoc IERC20
>>  389 |     function balanceOf(address account) public view virtual returns (uint256) {
    390 |         return _balances[account];
    391 |     }
    392 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 401 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    398 |      * - `to` cannot be the zero address.
    399 |      * - the caller must have a balance of at least `value`.
    400 |      */
>>  401 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    402 |         address owner = _msgSender();
    403 |         _transfer(owner, to, value);
    404 |         return true;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 408 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    405 |     }
    406 | 
    407 |     /// @inheritdoc IERC20
>>  408 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    409 |         return _allowances[owner][spender];
    410 |     }
    411 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 422 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    419 |      *
    420 |      * - `spender` cannot be the zero address.
    421 |      */
>>  422 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    423 |         address owner = _msgSender();
    424 |         _approve(owner, spender, value);
    425 |         return true;
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 444 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    441 |      * - the caller must have allowance for ``from``'s tokens of at least
    442 |      * `value`.
    443 |      */
>>  444 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    445 |         address spender = _msgSender();
    446 |         _spendAllowance(from, spender, value);
    447 |         _transfer(from, to, value);
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 665 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    662 |     /**
    663 |      * @dev Returns the address of the current owner.
    664 |      */
>>  665 |     function owner() public view virtual returns (address) {
    666 |         return _owner;
    667 |     }
    668 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 932 行
- **函数**: `getHourlyCycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    929 |     /**
    930 |      * @notice 获取当前周期（用于静态奖励和底池燃烧）
    931 |      */
>>  932 |     function getHourlyCycle() public view returns (uint256) {
    933 |         return (block.timestamp - launchTime) / 1 hours;
    934 |     }
    935 |     
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 939 行
- **函数**: `getDailyCycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    936 |     /**
    937 |      * @notice 获取当前周期（用于动态奖励和节点奖励
    938 |      */
>>  939 |     function getDailyCycle() public view returns (uint256) {
    940 |         return (block.timestamp - launchTime) / 1 days;
    941 |     }
    942 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 1446 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1443 |     /**
   1444 |      * @notice 重写余额查询方法（显示虚拟余额：实际余额 + 待领取奖励）
   1445 |      */
>> 1446 |     function balanceOf(address account) public view override returns (uint256) {
   1447 |         uint256 actualBalance = super.balanceOf(account);
   1448 |         (uint256 staticReward,) = ITokenExt(tokenExt)._calculateStaticReward(account);
   1449 |         uint256 dynamicReward = ITokenExt(tokenExt)._calculateDynamicReward(account);
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 1456 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1453 |     /**
   1454 |      * @notice 重写转账函数
   1455 |      */
>> 1456 |     function transfer(address to, uint256 amount) public override returns (bool) {
   1457 |         return _transferWithLogic(msg.sender, to, amount);
   1458 |     }
   1459 |     
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 1463 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1460 |     /**
   1461 |      * @notice 重写授权转账函数
   1462 |      */
>> 1463 |     function transferFrom(address from, address to, uint256 amount) public override returns (bool) {
   1464 |         address spender = msg.sender;
   1465 |         _spendAllowance(from, spender, amount);
   1466 |         
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2405 行
- **函数**: `factory()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2402 | // ============ 接口定义 ============
   2403 | 
   2404 | interface IPancakeRouter {
>> 2405 |     function factory() external pure returns (address);
   2406 |     function getAmountsOut(uint256 amountIn, address[] calldata path) external view returns (uint256[] memory amounts);
   2407 |     function addLiquidity(
   2408 |         address tokenA,
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2406 行
- **函数**: `getAmountsOut()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2403 | 
   2404 | interface IPancakeRouter {
   2405 |     function factory() external pure returns (address);
>> 2406 |     function getAmountsOut(uint256 amountIn, address[] calldata path) external view returns (uint256[] memory amounts);
   2407 |     function addLiquidity(
   2408 |         address tokenA,
   2409 |         address tokenB,
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2442 行
- **函数**: `createPair()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2439 | }
   2440 | 
   2441 | interface IPancakeFactory {
>> 2442 |     function createPair(address tokenA, address tokenB) external returns (address pair);
   2443 | }
   2444 | 
   2445 | interface IPancakePair {
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2447 行
- **函数**: `getReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2444 | 
   2445 | interface IPancakePair {
   2446 |     function sync() external;
>> 2447 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2448 |     function token0() external view returns (address);
   2449 |     function token1() external view returns (address);
   2450 |     function totalSupply() external view returns (uint256);
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2448 行
- **函数**: `token0()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2445 | interface IPancakePair {
   2446 |     function sync() external;
   2447 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>> 2448 |     function token0() external view returns (address);
   2449 |     function token1() external view returns (address);
   2450 |     function totalSupply() external view returns (uint256);
   2451 | }
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2449 行
- **函数**: `token1()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2446 |     function sync() external;
   2447 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2448 |     function token0() external view returns (address);
>> 2449 |     function token1() external view returns (address);
   2450 |     function totalSupply() external view returns (uint256);
   2451 | }
   2452 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2450 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2447 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2448 |     function token0() external view returns (address);
   2449 |     function token1() external view returns (address);
>> 2450 |     function totalSupply() external view returns (uint256);
   2451 | }
   2452 | 
   2453 | interface IFeeSwapper {
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2454 行
- **函数**: `swapFIFTHForWBNB()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2451 | }
   2452 | 
   2453 | interface IFeeSwapper {
>> 2454 |     function swapFIFTHForWBNB(uint256 fifthAmount) external returns (uint256);
   2455 |     function _getWBNBAmountOut(uint256 amountIn) external view returns(uint256);
   2456 |     function getFIFTHBalance()external view returns(uint256);
   2457 |     function _getFIFTHAmountOut(uint256 amountIn) external view returns(uint256);
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2455 行
- **函数**: `_getWBNBAmountOut()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2452 | 
   2453 | interface IFeeSwapper {
   2454 |     function swapFIFTHForWBNB(uint256 fifthAmount) external returns (uint256);
>> 2455 |     function _getWBNBAmountOut(uint256 amountIn) external view returns(uint256);
   2456 |     function getFIFTHBalance()external view returns(uint256);
   2457 |     function _getFIFTHAmountOut(uint256 amountIn) external view returns(uint256);
   2458 |     function _getFIFTHAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2457 行
- **函数**: `_getFIFTHAmountOut()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2454 |     function swapFIFTHForWBNB(uint256 fifthAmount) external returns (uint256);
   2455 |     function _getWBNBAmountOut(uint256 amountIn) external view returns(uint256);
   2456 |     function getFIFTHBalance()external view returns(uint256);
>> 2457 |     function _getFIFTHAmountOut(uint256 amountIn) external view returns(uint256);
   2458 |     function _getFIFTHAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
   2459 |     function transferToken(address token, address to, uint256 amount) external returns (bool);
   2460 |     function earleirUser(address user) external view returns(bool);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2458 行
- **函数**: `_getFIFTHAmountOutOfUSDT()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2455 |     function _getWBNBAmountOut(uint256 amountIn) external view returns(uint256);
   2456 |     function getFIFTHBalance()external view returns(uint256);
   2457 |     function _getFIFTHAmountOut(uint256 amountIn) external view returns(uint256);
>> 2458 |     function _getFIFTHAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
   2459 |     function transferToken(address token, address to, uint256 amount) external returns (bool);
   2460 |     function earleirUser(address user) external view returns(bool);
   2461 | }
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2459 行
- **函数**: `transferToken()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2456 |     function getFIFTHBalance()external view returns(uint256);
   2457 |     function _getFIFTHAmountOut(uint256 amountIn) external view returns(uint256);
   2458 |     function _getFIFTHAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
>> 2459 |     function transferToken(address token, address to, uint256 amount) external returns (bool);
   2460 |     function earleirUser(address user) external view returns(bool);
   2461 | }
   2462 | interface IWETH {
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2460 行
- **函数**: `earleirUser()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2457 |     function _getFIFTHAmountOut(uint256 amountIn) external view returns(uint256);
   2458 |     function _getFIFTHAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
   2459 |     function transferToken(address token, address to, uint256 amount) external returns (bool);
>> 2460 |     function earleirUser(address user) external view returns(bool);
   2461 | }
   2462 | interface IWETH {
   2463 |     function deposit() external payable;
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2463 行
- **函数**: `deposit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2460 |     function earleirUser(address user) external view returns(bool);
   2461 | }
   2462 | interface IWETH {
>> 2463 |     function deposit() external payable;
   2464 |     function withdraw(uint256 amount) external;
   2465 | }
   2466 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2468 行
- **函数**: `_calculateBurnRate()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2465 | }
   2466 | 
   2467 | interface ITokenExt{
>> 2468 |     function _calculateBurnRate() external view returns (uint256);
   2469 |     function _simulateNodeFIFTHRewardsWithBalance(
   2470 |         uint256 poolBalance
   2471 |     ) external view returns (uint256[10] memory nodeRewards, uint256 newPoolBalance);
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2472 行
- **函数**: `_calculateStaticReward()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2469 |     function _simulateNodeFIFTHRewardsWithBalance(
   2470 |         uint256 poolBalance
   2471 |     ) external view returns (uint256[10] memory nodeRewards, uint256 newPoolBalance);
>> 2472 |     function _calculateStaticReward(address user) external view returns (uint256,uint256);
   2473 |     function _calculateDynamicReward(address user) external view returns (uint256);
   2474 |     function _calculateNodeWBNBReward(address user) external view returns (uint256);
   2475 |     function _calculateNodeFIFTHReward(address user) external view returns (uint256);
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2473 行
- **函数**: `_calculateDynamicReward()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2470 |         uint256 poolBalance
   2471 |     ) external view returns (uint256[10] memory nodeRewards, uint256 newPoolBalance);
   2472 |     function _calculateStaticReward(address user) external view returns (uint256,uint256);
>> 2473 |     function _calculateDynamicReward(address user) external view returns (uint256);
   2474 |     function _calculateNodeWBNBReward(address user) external view returns (uint256);
   2475 |     function _calculateNodeFIFTHReward(address user) external view returns (uint256);
   2476 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2474 行
- **函数**: `_calculateNodeWBNBReward()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2471 |     ) external view returns (uint256[10] memory nodeRewards, uint256 newPoolBalance);
   2472 |     function _calculateStaticReward(address user) external view returns (uint256,uint256);
   2473 |     function _calculateDynamicReward(address user) external view returns (uint256);
>> 2474 |     function _calculateNodeWBNBReward(address user) external view returns (uint256);
   2475 |     function _calculateNodeFIFTHReward(address user) external view returns (uint256);
   2476 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
   2477 |     function despositForEarlyUser(uint256 total,address user,uint8 control) external returns(uint256);
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2475 行
- **函数**: `_calculateNodeFIFTHReward()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2472 |     function _calculateStaticReward(address user) external view returns (uint256,uint256);
   2473 |     function _calculateDynamicReward(address user) external view returns (uint256);
   2474 |     function _calculateNodeWBNBReward(address user) external view returns (uint256);
>> 2475 |     function _calculateNodeFIFTHReward(address user) external view returns (uint256);
   2476 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
   2477 |     function despositForEarlyUser(uint256 total,address user,uint8 control) external returns(uint256);
   2478 |     function _gethighPrice(uint256 currentCycle)external view returns(uint256 highPrice);
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2477 行
- **函数**: `despositForEarlyUser()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2474 |     function _calculateNodeWBNBReward(address user) external view returns (uint256);
   2475 |     function _calculateNodeFIFTHReward(address user) external view returns (uint256);
   2476 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
>> 2477 |     function despositForEarlyUser(uint256 total,address user,uint8 control) external returns(uint256);
   2478 |     function _gethighPrice(uint256 currentCycle)external view returns(uint256 highPrice);
   2479 |     function _buyFIFTH(uint256 bnbAmount) external returns (uint256);
   2480 |     function _buyWBNB(uint256 fifthAmount) external returns (uint256);
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2479 行
- **函数**: `_buyFIFTH()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2476 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
   2477 |     function despositForEarlyUser(uint256 total,address user,uint8 control) external returns(uint256);
   2478 |     function _gethighPrice(uint256 currentCycle)external view returns(uint256 highPrice);
>> 2479 |     function _buyFIFTH(uint256 bnbAmount) external returns (uint256);
   2480 |     function _buyWBNB(uint256 fifthAmount) external returns (uint256);
   2481 | }
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2480 行
- **函数**: `_buyWBNB()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2477 |     function despositForEarlyUser(uint256 total,address user,uint8 control) external returns(uint256);
   2478 |     function _gethighPrice(uint256 currentCycle)external view returns(uint256 highPrice);
   2479 |     function _buyFIFTH(uint256 bnbAmount) external returns (uint256);
>> 2480 |     function _buyWBNB(uint256 fifthAmount) external returns (uint256);
   2481 | }
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 334 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    329 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    330 |  * instead returning `false` on failure. This behavior is nonetheless
    331 |  * conventional and does not conflict with the expectations of ERC-20
    332 |  * applications.
    333 |  */
>>  334 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    335 |     mapping(address account => uint256) private _balances;
    336 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    337 |     uint256 private _totalSupply;
    338 |     string private _name;
    339 |     string private _symbol;
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 629 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    624 |  *
    625 |  * This module is used through inheritance. It will make available the modifier
    626 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    627 |  * the owner.
    628 |  */
>>  629 | abstract contract Ownable is Context {
    630 |     address private _owner;
    631 | 
    632 |     /**
    633 |      * @dev The caller account is not authorized to perform an operation.
    634 |      */
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 701 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    696 |         }
    697 |         _transferOwnership(newOwner);
    698 |     }
    699 | 
    700 |     /**
>>  701 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    702 |      * Internal function without access restriction.
    703 |      */
    704 |     function _transferOwnership(address newOwner) internal virtual {
    705 |         address oldOwner = _owner;
    706 |         _owner = newOwner;
```

---

### 51. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 725 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    720 |  * @notice FIFTH 是一个创新的 BEP-20 代币，具有算力挖矿、节点奖励、邀请系统等功能
    721 |  * @dev 实现了完整的 LP 管理、自动底池燃烧、自动奖励分配等机制
    722 |  * @dev 生产环境：静态+燃烧使用小时周期；动态+节点使用一天周期
    723 |  */
    724 | 
>>  725 | contract FIFTHToken is ERC20,Ownable {
    726 |     
    727 |     // ============ 常量定义 ============
    728 |     address public tokenExt; //代币逻辑扩展合约
    729 |     address public feeSwapper;  // 手续费兑换合约地址
    730 |     
```

---

### 52. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 912 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    909 |     
    910 |     constructor() ERC20("5THelement", "5TH") Ownable(baiAddress) {
    911 |         // 设置启动时间
>>  912 |         launchTime = block.timestamp / 1 hours * 1 hours;
    913 |         // 铸造总供应量
    914 |         _mint(baiAddress, 130_000_000 ether);
    915 |         _mint(INITIAL_SUPERIOR,100 ether);
```

---

### 53. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 933 行
- **函数**: `getHourlyCycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    930 |      * @notice 获取当前周期（用于静态奖励和底池燃烧）
    931 |      */
    932 |     function getHourlyCycle() public view returns (uint256) {
>>  933 |         return (block.timestamp - launchTime) / 1 hours;
    934 |     }
    935 |     
    936 |     /**
```

---

### 54. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 940 行
- **函数**: `getDailyCycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    937 |      * @notice 获取当前周期（用于动态奖励和节点奖励
    938 |      */
    939 |     function getDailyCycle() public view returns (uint256) {
>>  940 |         return (block.timestamp - launchTime) / 1 days;
    941 |     }
    942 | 
    943 |     function setFeeSwapper(address _feeSwapper) public  onlyOwner(){
```

---

### 55. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 1271 行
- **函数**: `_redeem()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1268 |             0,                 // 🔥 最小FIFTH数量（5%滑点保护）
   1269 |             0,                // 🔥 最小WBNB数量（5%滑点保护）
   1270 |             feeSwapper,             // 代币先到feeSwapper中间合约
>> 1271 |             block.timestamp + 300   // 5分钟有效期
   1272 |         );
   1273 |         
   1274 |         // 9. 从feeSwapper将FIFTH转移到合约（使用_transfer内部函数）
```

---

### 56. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2367 行
- **函数**: `_addLiquidity()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2364 |             0,                      // amountAMin: FIFTH最小数量
   2365 |             0,                      // amountBMin: WBNB最小数量
   2366 |             lpReceiver,             // to: LP代币接收地址（改为用户地址）
>> 2367 |             block.timestamp + 300   // deadline: 截止时间
   2368 |         );
   2369 |         
   2370 |         return (usedFIFTH, usedWBNB, liquidity);
```

---

### 57. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 1109 行
- **函数**: `_processBuildLP()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1106 |         uint256 buyFIFTHAmount = lpbnb / 2;  // 30% 的总金额
   1107 |         
   1108 |         // 用 wbnb 在 PancakeSwap 上购买 FIFTH 代币
>> 1109 |         IERC20(WBNB).transfer(tokenExt, buyFIFTHAmount);
   1110 |         uint256 fifthAmount = ITokenExt(tokenExt)._buyFIFTH(buyFIFTHAmount);
   1111 |         // 转回合约
   1112 |         _transfer(tokenExt, address(this), fifthAmount);
```

---

### 58. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 2376 行
- **函数**: `_transferWBNB()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   2373 |     
   2374 |     function _transferWBNB(address to, uint256 amount) internal {
   2375 |         if (amount > 0) {
>> 2376 |             IERC20(WBNB).transfer(to, amount);
   2377 |         }
   2378 |     }
   2379 |     
```

---

### 59. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 732 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    729 |     address public feeSwapper;  // 手续费兑换合约地址
    730 |     
    731 |     /// @notice 黑洞地址，用于接收销毁的代币
>>  732 |     address public constant DEAD = 0x000000000000000000000000000000000000dEaD;
    733 |     
    734 |     /// @notice 基础比例分母
    735 |     uint256 private constant BASE = 100000;
```

---

### 60. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 739 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    736 |     
    737 |     // ============ DEX 相关 ============
    738 |     /// @notice PancakeSwap Router V2 (BSC Mainnet)
>>  739 |     address public constant ROUTER = 0x10ED43C718714eb63d5aA57B78B54704E256024E;
    740 |     
    741 |     /// @notice USDT 代币地址 (BSC)
    742 |     address public constant USDT = 0x55d398326f99059fF775485246999027B3197955;
```

---

### 61. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 742 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    739 |     address public constant ROUTER = 0x10ED43C718714eb63d5aA57B78B54704E256024E;
    740 |     
    741 |     /// @notice USDT 代币地址 (BSC)
>>  742 |     address public constant USDT = 0x55d398326f99059fF775485246999027B3197955;
    743 |     
    744 |     /// @notice WBNB 代币地址 (BSC)
    745 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
```

---

### 62. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 745 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    742 |     address public constant USDT = 0x55d398326f99059fF775485246999027B3197955;
    743 |     
    744 |     /// @notice WBNB 代币地址 (BSC)
>>  745 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
    746 |         
    747 |     /// @notice FIFTH-WBNB LP 池地址
    748 |     address public pancakePair;
```

---

### 63. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 751 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    748 |     address public pancakePair;
    749 | 
    750 |     /// @notice 初始上级地址（创世推荐人）
>>  751 |     address public constant INITIAL_SUPERIOR = 0xA732DF2AA28a402e06eFaf22e724a4476372555b;
    752 |     
    753 |     // ============ 地址配置 ============
    754 |     
```

---

### 64. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 756 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    753 |     // ============ 地址配置 ============
    754 |     
    755 |     /// @notice 生态地址
>>  756 |     address public constant operationsAddress = 0x3D7A18BF8AC42D81057e18BD3e495Efd5E3a961D;
    757 |     
    758 |     address public constant evnAddress = 0xf24E96791087029A0B0EE787C4D02a4d47B479ca;
    759 | 
```

---

### 65. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 758 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    755 |     /// @notice 生态地址
    756 |     address public constant operationsAddress = 0x3D7A18BF8AC42D81057e18BD3e495Efd5E3a961D;
    757 |     
>>  758 |     address public constant evnAddress = 0xf24E96791087029A0B0EE787C4D02a4d47B479ca;
    759 | 
    760 |     address public constant techAddress = 0xc5129B25fB124a7b4a7B1955A885a95F7295C6e1;
    761 |     
```

---

### 66. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 760 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    757 |     
    758 |     address public constant evnAddress = 0xf24E96791087029A0B0EE787C4D02a4d47B479ca;
    759 | 
>>  760 |     address public constant techAddress = 0xc5129B25fB124a7b4a7B1955A885a95F7295C6e1;
    761 |     
    762 |     /// @notice 创世节点地址
    763 |     address public constant genesisNodeAddress = 0x03A8571702c85abbE52F92873206bC191fd02222;
```

---

### 67. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 763 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    760 |     address public constant techAddress = 0xc5129B25fB124a7b4a7B1955A885a95F7295C6e1;
    761 |     
    762 |     /// @notice 创世节点地址
>>  763 |     address public constant genesisNodeAddress = 0x03A8571702c85abbE52F92873206bC191fd02222;
    764 | 
    765 |     /// @notice 白名单地址
    766 |     address public constant baiAddress = 0x0c479Ce06a6A18F6748BCD7179f01f65A3241083;
```

---

### 68. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 766 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    763 |     address public constant genesisNodeAddress = 0x03A8571702c85abbE52F92873206bC191fd02222;
    764 | 
    765 |     /// @notice 白名单地址
>>  766 |     address public constant baiAddress = 0x0c479Ce06a6A18F6748BCD7179f01f65A3241083;
    767 | 
    768 |     /// @notice 归集地址
    769 |     address public constant guijiAddress = 0x3D7A18BF8AC42D81057e18BD3e495Efd5E3a961D;
```

---

### 69. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x850026ad9Ece0505A45148b843CC338a77405555` 第 769 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    766 |     address public constant baiAddress = 0x0c479Ce06a6A18F6748BCD7179f01f65A3241083;
    767 | 
    768 |     /// @notice 归集地址
>>  769 |     address public constant guijiAddress = 0x3D7A18BF8AC42D81057e18BD3e495Efd5E3a961D;
    770 |     
    771 |     // ============ 用户信息结构 ============
    772 |     
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*