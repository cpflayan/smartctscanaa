# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:28:29
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` |
| contract_name | `SimpleProxy11` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `None` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655010` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 4 |
| 🟢 LOW | 5 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` 第 87 行
- **函数**: `_delegate()`
- **合约**: `SimpleProxy11`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
     84 |         assembly {
     85 |             calldatacopy(0, 0, calldatasize())
     86 | 
>>   87 |             let ok := delegatecall(gas(), impl_, 0, calldatasize(), 0, 0)
     88 | 
     89 |             returndatacopy(0, 0, returndatasize())
     90 | 
```

---

### 2. 🟡 [MEDIUM] locked-ether

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_qla8dd_k/0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD.sol` 第 7 行
- **合约**: `SimpleProxy11`
- **扫描工具**: slither
- **综合评分**: 0.560

**工具描述**: Contract locking ether found:
	Contract SimpleProxy11 (../../../tmp/slither_scan_qla8dd_k/0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD.sol#7-109) has payable functions:
	 - SimpleProxy11.fallback() (../../../tmp/slither_scan_qla8dd_k/0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD.sol#71-73)
	 - SimpleProxy11.receive() (../../../tmp/slither_scan_qla8dd_k/0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD.sol#75-77)
	But does not have a function to withdraw the ether

**代码片段**:
```solidity
      4 | /**
      5 |  * @title SimpleProxy
      6 |  */
>>    7 | contract SimpleProxy11 {
      8 | 
      9 |     // ─── Storage Slots (EIP-1967) ────────────────────────────────────────────
     10 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` 第 46 行
- **函数**: `owner()`
- **合约**: `SimpleProxy11`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     43 | 
     44 |     // ─── External Views ──────────────────────────────────────────────────────
     45 | 
>>   46 |     function owner() external view returns (address) {
     47 |         return _readSlot(OWNER_SLOT);
     48 |     }
     49 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` 第 50 行
- **函数**: `implementation()`
- **合约**: `SimpleProxy11`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     47 |         return _readSlot(OWNER_SLOT);
     48 |     }
     49 | 
>>   50 |     function implementation() external view returns (address) {
     51 |         return _readSlot(IMPL_SLOT);
     52 |     }
     53 | 
```

---

### 5. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` 第 7 行
- **合约**: `SimpleProxy11`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      2 | pragma solidity ^0.8.20;
      3 | 
      4 | /**
      5 |  * @title SimpleProxy
      6 |  */
>>    7 | contract SimpleProxy11 {
      8 | 
      9 |     // ─── Storage Slots (EIP-1967) ────────────────────────────────────────────
     10 | 
     11 |     // keccak256("owner.proxy.slot") - 1
     12 |     bytes32 private constant OWNER_SLOT =
```

---

### 6. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` 第 13 行
- **合约**: `SimpleProxy11`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     10 | 
     11 |     // keccak256("owner.proxy.slot") - 1
     12 |     bytes32 private constant OWNER_SLOT =
>>   13 |         0xa7b53796fd2d99cb1f5ae019b54f9e024446c3d12b483f733ccc62ed04eb126a;
     14 | 
     15 |     // keccak256("eip1967.proxy.implementation") - 1
     16 |     bytes32 private constant IMPL_SLOT =
```

---

### 7. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` 第 17 行
- **合约**: `SimpleProxy11`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     14 | 
     15 |     // keccak256("eip1967.proxy.implementation") - 1
     16 |     bytes32 private constant IMPL_SLOT =
>>   17 |         0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
     18 | 
     19 |     // ─── Events ──────────────────────────────────────────────────────────────
     20 | 
```

---

### 8. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` 第 84 行
- **函数**: `_delegate()`
- **合约**: `SimpleProxy11`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     81 |     function _delegate(address impl_) internal {
     82 |         if (impl_ == address(0)) revert ImplementationNotSet();
     83 | 
>>   84 |         assembly {
     85 |             calldatacopy(0, 0, calldatasize())
     86 | 
     87 |             let ok := delegatecall(gas(), impl_, 0, calldatasize(), 0, 0)
```

---

### 9. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` 第 98 行
- **函数**: `_readSlot()`
- **合约**: `SimpleProxy11`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     95 |     }
     96 | 
     97 |     function _readSlot(bytes32 slot) internal view returns (address value) {
>>   98 |         assembly {
     99 |             value := sload(slot)
    100 |         }
    101 |     }
```

---

### 10. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xB9a38651C80FEB365217CB5aAa73f8162B86B9BD` 第 104 行
- **函数**: `_writeSlot()`
- **合约**: `SimpleProxy11`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    101 |     }
    102 | 
    103 |     function _writeSlot(bytes32 slot, address value) internal {
>>  104 |         assembly {
    105 |             sstore(slot, value)
    106 |         }
    107 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*