# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:02:34
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xdb953299588b7A7C38044bcD004b4b1892026333` |
| contract_name | `AiFiToken` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `Unlicense` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/interfaces/draft-IERC6093.sol', '@openzeppelin/contracts/token/ERC20/ERC20.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/utils/Context.sol', 'contracts/AiFiToken.sol', 'contracts/interfaces/ICalculateReward.sol', 'contracts/interfaces/IDividendCalculator.sol', 'contracts/interfaces/IPancakePair.sol', 'contracts/interfaces/IUniswapV2Factory.sol', 'contracts/interfaces/IUniswapV2Router.sol', 'contracts/interfaces/IWrappedToken.sol', 'contracts/Math.sol', 'contracts/TokenDistributor.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655006` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 3 |
| 🟡 MEDIUM | 66 |
| 🟢 LOW | 22 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 910 行
- **函数**: `_beforeTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    907 |                 isAddLP = true;
    908 |                 userInfo[user].lpAmount += addLPLiquidity;
    909 |                 userInfo[user].lastAddLPTime = block.timestamp;
>>  910 |                 require(user == tx.origin, "not owner1");
    911 |                 require(!isContract(user), "not owner2");
    912 |                 lpDividendTracker.setAccount(user, userInfo[user].lpAmount);
    913 |             }
```

---

### 2. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 919 行
- **函数**: `_beforeTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    916 |             (uint256 removeLPLiquidity,) = _isRemoveLiquidity(from, value);
    917 |             if (removeLPLiquidity > 0) {
    918 |                 address user = to;
>>  919 |                 require(user == tx.origin, "not owner1");
    920 |                 require(!isContract(user), "not owner2");
    921 |                 require(from == usdtPair && startTradeBlock > 0, "not remove");
    922 |                 isRemoveLP = true;
```

---

### 3. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1517 行
- **函数**: `sqrt()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
   1514 |     mapping(address => bool) private _feeWhiteList;
   1515 |     constructor () {
   1516 |         _feeWhiteList[msg.sender] = true;
>> 1517 |         _feeWhiteList[tx.origin] = true;
   1518 |     }
   1519 | 
   1520 |     function claimToken(address token, address to, uint256 amount) public {
```

---

### 4. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 857 行
- **函数**: `_autoDividendDaily()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    854 | 
    855 |     function _autoDividendDaily() internal {
    856 |         uint256 round = 1;
>>  857 |         uint256 day = block.timestamp / 1 days;
    858 |         uint256 sec = block.timestamp - (day * 1 days);
    859 |         if (sec >= 43200) {
    860 |             round = 2;
```

---

### 5. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 858 行
- **函数**: `_autoDividendDaily()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    855 |     function _autoDividendDaily() internal {
    856 |         uint256 round = 1;
    857 |         uint256 day = block.timestamp / 1 days;
>>  858 |         uint256 sec = block.timestamp - (day * 1 days);
    859 |         if (sec >= 43200) {
    860 |             round = 2;
    861 |         }
```

---

### 6. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1091 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1088 | 
   1089 |     function _getReserves(address pair) public view returns (uint256 rOther, uint256 rThis, uint256 balanceOther){
   1090 |         IPancakePair mainPair = IPancakePair(pair);
>> 1091 |         (uint r0, uint256 r1,) = mainPair.getReserves();
   1092 | 
   1093 |         address tokenOther = mainPair.token0() == address(this) ? mainPair.token1() : mainPair.token0();
   1094 |         if (tokenOther < address(this)) {
```

---

### 7. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1340 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1337 | 
   1338 |     function token1() external view returns (address);
   1339 | 
>> 1340 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1341 | 
   1342 |     function kLast() external view returns (uint);
   1343 | 
```

---

### 8. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1537 行
- **函数**: `_safeTransferETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1534 |     }
   1535 | 
   1536 |     function _safeTransferETH(address to, uint value) internal {
>> 1537 |         (bool success,) = to.call{value: value}(new bytes(0));
   1538 |         if (success) {}
   1539 |     }
   1540 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 58 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     55 |     /**
     56 |      * @dev Returns the address of the current owner.
     57 |      */
>>   58 |     function owner() public view virtual returns (address) {
     59 |         return _owner;
     60 |     }
     61 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 323 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    320 |     /**
    321 |      * @dev Returns the name of the token.
    322 |      */
>>  323 |     function name() public view virtual returns (string memory) {
    324 |         return _name;
    325 |     }
    326 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 331 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    328 |      * @dev Returns the symbol of the token, usually a shorter version of the
    329 |      * name.
    330 |      */
>>  331 |     function symbol() public view virtual returns (string memory) {
    332 |         return _symbol;
    333 |     }
    334 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 348 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    345 |      * no way affects any of the arithmetic of the contract, including
    346 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    347 |      */
>>  348 |     function decimals() public view virtual returns (uint8) {
    349 |         return 18;
    350 |     }
    351 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 353 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    350 |     }
    351 | 
    352 |     /// @inheritdoc IERC20
>>  353 |     function totalSupply() public view virtual returns (uint256) {
    354 |         return _totalSupply;
    355 |     }
    356 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 358 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    355 |     }
    356 | 
    357 |     /// @inheritdoc IERC20
>>  358 |     function balanceOf(address account) public view virtual returns (uint256) {
    359 |         return _balances[account];
    360 |     }
    361 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 370 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    367 |      * - `to` cannot be the zero address.
    368 |      * - the caller must have a balance of at least `value`.
    369 |      */
>>  370 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    371 |         address owner = _msgSender();
    372 |         _transfer(owner, to, value);
    373 |         return true;
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 377 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    374 |     }
    375 | 
    376 |     /// @inheritdoc IERC20
>>  377 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    378 |         return _allowances[owner][spender];
    379 |     }
    380 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 391 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    388 |      *
    389 |      * - `spender` cannot be the zero address.
    390 |      */
>>  391 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    392 |         address owner = _msgSender();
    393 |         _approve(owner, spender, value);
    394 |         return true;
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 413 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    410 |      * - the caller must have allowance for ``from``'s tokens of at least
    411 |      * `value`.
    412 |      */
>>  413 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    414 |         address spender = _msgSender();
    415 |         _spendAllowance(from, spender, value);
    416 |         _transfer(from, to, value);
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 595 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    592 |     /**
    593 |      * @dev Returns the name of the token.
    594 |      */
>>  595 |     function name() external view returns (string memory);
    596 | 
    597 |     /**
    598 |      * @dev Returns the symbol of the token.
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 600 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    597 |     /**
    598 |      * @dev Returns the symbol of the token.
    599 |      */
>>  600 |     function symbol() external view returns (string memory);
    601 | 
    602 |     /**
    603 |      * @dev Returns the decimals places of the token.
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 605 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    602 |     /**
    603 |      * @dev Returns the decimals places of the token.
    604 |      */
>>  605 |     function decimals() external view returns (uint8);
    606 | }
    607 | 
    608 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 637 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    634 |     /**
    635 |      * @dev Returns the value of tokens in existence.
    636 |      */
>>  637 |     function totalSupply() external view returns (uint256);
    638 | 
    639 |     /**
    640 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 642 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    639 |     /**
    640 |      * @dev Returns the value of tokens owned by `account`.
    641 |      */
>>  642 |     function balanceOf(address account) external view returns (uint256);
    643 | 
    644 |     /**
    645 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 651 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    648 |      *
    649 |      * Emits a {Transfer} event.
    650 |      */
>>  651 |     function transfer(address to, uint256 value) external returns (bool);
    652 | 
    653 |     /**
    654 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 660 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    657 |      *
    658 |      * This value changes when {approve} or {transferFrom} are called.
    659 |      */
>>  660 |     function allowance(address owner, address spender) external view returns (uint256);
    661 | 
    662 |     /**
    663 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 677 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    674 |      *
    675 |      * Emits an {Approval} event.
    676 |      */
>>  677 |     function approve(address spender, uint256 value) external returns (bool);
    678 | 
    679 |     /**
    680 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 688 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    685 |      *
    686 |      * Emits a {Transfer} event.
    687 |      */
>>  688 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    689 | }
    690 | 
    691 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 827 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    824 |         dividendLowAmount = 1000 * 1 ether;
    825 |     }
    826 | 
>>  827 |     function transferFrom(address from, address to, uint256 value) public virtual override returns (bool) {
    828 |         address spender = _msgSender();
    829 |         _spendAllowance(from, spender, value);
    830 |         uint256 newValue = _beforeTransfer(from, to, value);
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 835 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    832 |         return true;
    833 |     }
    834 | 
>>  835 |     function transfer(address to, uint256 value) public virtual override returns (bool) {
    836 |         address owner = _msgSender();
    837 |         uint256 newValue = _beforeTransfer(owner, to, value);
    838 |         _transfer(owner, to, newValue);
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 842 行
- **函数**: `setLock()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    839 |         return true;
    840 |     }
    841 | 
>>  842 |     function setLock(bool v) external {
    843 |         require(_msgSender() == dappContract, "only dapp");
    844 |         inLaunchBuyLock = v;
    845 |     }
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 847 行
- **函数**: `recycleByDapp()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    844 |         inLaunchBuyLock = v;
    845 |     }
    846 | 
>>  847 |     function recycleByDapp(uint256 amount) external {
    848 |         require(_msgSender() == dappContract, "only dapp");
    849 |         uint256 maxBurn = balanceOf(mainPair) / 3;
    850 |         uint256 burnAmount = amount >= maxBurn ? maxBurn : amount;
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1089 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1086 |         }
   1087 |     }
   1088 | 
>> 1089 |     function _getReserves(address pair) public view returns (uint256 rOther, uint256 rThis, uint256 balanceOther){
   1090 |         IPancakePair mainPair = IPancakePair(pair);
   1091 |         (uint r0, uint256 r1,) = mainPair.getReserves();
   1092 | 
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1265 行
- **函数**: `getReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1262 | 
   1263 | interface ICalculateReward {
   1264 | 
>> 1265 |     function getReward(address account, uint256 removeLp) external view returns (uint256);
   1266 | 
   1267 |     function claimReward(address account, uint256 removeLp) external returns (uint256);
   1268 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1267 行
- **函数**: `claimReward()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1264 | 
   1265 |     function getReward(address account, uint256 removeLp) external view returns (uint256);
   1266 | 
>> 1267 |     function claimReward(address account, uint256 removeLp) external returns (uint256);
   1268 | 
   1269 |     function setAccount(address account, uint256 amount) external;
   1270 | 
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1281 行
- **函数**: `tokenHoldersMapLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1278 | 
   1279 |     function setEpochRewards(uint256 rewards, uint256 round) external;
   1280 | 
>> 1281 |     function tokenHoldersMapLength() external view returns (uint256);
   1282 | 
   1283 |     function _totalSupply() external view returns(uint256);
   1284 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1283 行
- **函数**: `_totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1280 | 
   1281 |     function tokenHoldersMapLength() external view returns (uint256);
   1282 | 
>> 1283 |     function _totalSupply() external view returns(uint256);
   1284 | 
   1285 | 
   1286 | }
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1295 行
- **函数**: `getNftAndLpDividendAmount()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1292 | pragma solidity ^0.8.0;
   1293 | 
   1294 | interface IDividendCalculator {
>> 1295 |     function getNftAndLpDividendAmount(uint256 currentAmount) external view returns (uint256 lpRewardsAmount, uint256 nftRewardsAmount);
   1296 | }
   1297 | 
   1298 | 
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1306 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1303 | 
   1304 | interface IPancakePair {
   1305 | 
>> 1306 |     function name() external pure returns (string memory);
   1307 | 
   1308 |     function symbol() external pure returns (string memory);
   1309 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1308 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1305 | 
   1306 |     function name() external pure returns (string memory);
   1307 | 
>> 1308 |     function symbol() external pure returns (string memory);
   1309 | 
   1310 |     function decimals() external pure returns (uint8);
   1311 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1310 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1307 | 
   1308 |     function symbol() external pure returns (string memory);
   1309 | 
>> 1310 |     function decimals() external pure returns (uint8);
   1311 | 
   1312 |     function totalSupply() external view returns (uint);
   1313 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1312 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1309 | 
   1310 |     function decimals() external pure returns (uint8);
   1311 | 
>> 1312 |     function totalSupply() external view returns (uint);
   1313 | 
   1314 |     function balanceOf(address owner) external view returns (uint);
   1315 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1314 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1311 | 
   1312 |     function totalSupply() external view returns (uint);
   1313 | 
>> 1314 |     function balanceOf(address owner) external view returns (uint);
   1315 | 
   1316 |     function allowance(address owner, address spender) external view returns (uint);
   1317 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1316 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1313 | 
   1314 |     function balanceOf(address owner) external view returns (uint);
   1315 | 
>> 1316 |     function allowance(address owner, address spender) external view returns (uint);
   1317 | 
   1318 |     function approve(address spender, uint value) external returns (bool);
   1319 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1318 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1315 | 
   1316 |     function allowance(address owner, address spender) external view returns (uint);
   1317 | 
>> 1318 |     function approve(address spender, uint value) external returns (bool);
   1319 | 
   1320 |     function transfer(address to, uint value) external returns (bool);
   1321 | 
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1320 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1317 | 
   1318 |     function approve(address spender, uint value) external returns (bool);
   1319 | 
>> 1320 |     function transfer(address to, uint value) external returns (bool);
   1321 | 
   1322 |     function transferFrom(address from, address to, uint value) external returns (bool);
   1323 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1322 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1319 | 
   1320 |     function transfer(address to, uint value) external returns (bool);
   1321 | 
>> 1322 |     function transferFrom(address from, address to, uint value) external returns (bool);
   1323 | 
   1324 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1325 | 
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1324 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1321 | 
   1322 |     function transferFrom(address from, address to, uint value) external returns (bool);
   1323 | 
>> 1324 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1325 | 
   1326 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   1327 | 
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1326 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1323 | 
   1324 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1325 | 
>> 1326 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   1327 | 
   1328 |     function nonces(address owner) external view returns (uint);
   1329 | 
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1328 行
- **函数**: `nonces()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1325 | 
   1326 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   1327 | 
>> 1328 |     function nonces(address owner) external view returns (uint);
   1329 | 
   1330 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
   1331 | 
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1332 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1329 | 
   1330 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
   1331 | 
>> 1332 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   1333 | 
   1334 |     function factory() external view returns (address);
   1335 | 
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1334 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1331 | 
   1332 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   1333 | 
>> 1334 |     function factory() external view returns (address);
   1335 | 
   1336 |     function token0() external view returns (address);
   1337 | 
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1336 行
- **函数**: `token0()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1333 | 
   1334 |     function factory() external view returns (address);
   1335 | 
>> 1336 |     function token0() external view returns (address);
   1337 | 
   1338 |     function token1() external view returns (address);
   1339 | 
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1338 行
- **函数**: `token1()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1335 | 
   1336 |     function token0() external view returns (address);
   1337 | 
>> 1338 |     function token1() external view returns (address);
   1339 | 
   1340 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1341 | 
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1340 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1337 | 
   1338 |     function token1() external view returns (address);
   1339 | 
>> 1340 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1341 | 
   1342 |     function kLast() external view returns (uint);
   1343 | 
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1342 行
- **函数**: `kLast()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1339 | 
   1340 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1341 | 
>> 1342 |     function kLast() external view returns (uint);
   1343 | 
   1344 |     function mint(address to) external returns (uint liquidity);
   1345 | 
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1344 行
- **函数**: `mint()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1341 | 
   1342 |     function kLast() external view returns (uint);
   1343 | 
>> 1344 |     function mint(address to) external returns (uint liquidity);
   1345 | 
   1346 |     function burn(address to) external returns (uint amount0, uint amount1);
   1347 | 
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1346 行
- **函数**: `burn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1343 | 
   1344 |     function mint(address to) external returns (uint liquidity);
   1345 | 
>> 1346 |     function burn(address to) external returns (uint amount0, uint amount1);
   1347 | 
   1348 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
   1349 | 
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1372 行
- **函数**: `feeTo()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1369 |         address tokenB
   1370 |     ) external view returns (address);
   1371 | 
>> 1372 |     function feeTo() external view returns (address);
   1373 | }
   1374 | 
   1375 | // ── contracts/interfaces/IUniswapV2Router.sol ──────────────────────────────
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1381 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1378 | pragma solidity ^0.8.10;
   1379 | 
   1380 | interface IUniswapV2Router {
>> 1381 |     function factory() external pure returns (address);
   1382 | 
   1383 |     function WETH() external pure returns (address);
   1384 | 
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1383 行
- **函数**: `WETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1380 | interface IUniswapV2Router {
   1381 |     function factory() external pure returns (address);
   1382 | 
>> 1383 |     function WETH() external pure returns (address);
   1384 | 
   1385 |     function addLiquidity(
   1386 |         address tokenA,
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1396 行
- **函数**: `getAmountsOut()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1393 |         uint256 deadline
   1394 |     ) external returns (uint256 amountA, uint256 amountB, uint256 liquidity);
   1395 | 
>> 1396 |     function getAmountsOut(uint256 amountIn, address[] calldata path) external view returns (uint256[] memory amounts);
   1397 | 
   1398 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
   1399 | 
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1398 行
- **函数**: `getAmountsIn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1395 | 
   1396 |     function getAmountsOut(uint256 amountIn, address[] calldata path) external view returns (uint256[] memory amounts);
   1397 | 
>> 1398 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
   1399 | 
   1400 |     function swapExactTokensForTokensSupportingFeeOnTransferTokens(
   1401 |         uint256 amountIn,
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1463 行
- **函数**: `getAmountOut()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1460 |         uint deadline
   1461 |     ) external returns (uint[] memory amounts);
   1462 | 
>> 1463 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
   1464 | }
   1465 | 
   1466 | 
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1477 行
- **函数**: `deposit()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1474 | interface IWrappedToken is IERC20 {
   1475 |     function withdraw(uint wad) external;
   1476 | 
>> 1477 |     function deposit() external payable;
   1478 | }
   1479 | 
   1480 | 
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1520 行
- **函数**: `claimToken()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1517 |         _feeWhiteList[tx.origin] = true;
   1518 |     }
   1519 | 
>> 1520 |     function claimToken(address token, address to, uint256 amount) public {
   1521 |         if (_feeWhiteList[msg.sender]) {
   1522 |             IERC20(token).transfer(to, amount);
   1523 |         }
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1526 行
- **函数**: `claimBalance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1523 |         }
   1524 |     }
   1525 | 
>> 1526 |     function claimBalance(address to, uint256 amount) public {
   1527 |         if (_feeWhiteList[msg.sender]) {
   1528 |             IWrappedToken wbnb = IWrappedToken(0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c);
   1529 |             if (wbnb.balanceOf(address(this)) > 0) {
```

---

### 67. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 22 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     17 |  *
     18 |  * This module is used through inheritance. It will make available the modifier
     19 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     20 |  * the owner.
     21 |  */
>>   22 | abstract contract Ownable is Context {
     23 |     address private _owner;
     24 | 
     25 |     /**
     26 |      * @dev The caller account is not authorized to perform an operation.
     27 |      */
```

---

### 68. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 94 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     89 |         }
     90 |         _transferOwnership(newOwner);
     91 |     }
     92 | 
     93 |     /**
>>   94 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     95 |      * Internal function without access restriction.
     96 |      */
     97 |     function _transferOwnership(address newOwner) internal virtual {
     98 |         address oldOwner = _owner;
     99 |         _owner = newOwner;
```

---

### 69. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 300 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    295 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    296 |  * instead returning `false` on failure. This behavior is nonetheless
    297 |  * conventional and does not conflict with the expectations of ERC-20
    298 |  * applications.
    299 |  */
>>  300 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    301 |     mapping(address account => uint256) private _balances;
    302 | 
    303 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    304 | 
    305 |     uint256 private _totalSupply;
```

---

### 70. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 857 行
- **函数**: `_autoDividendDaily()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    854 | 
    855 |     function _autoDividendDaily() internal {
    856 |         uint256 round = 1;
>>  857 |         uint256 day = block.timestamp / 1 days;
    858 |         uint256 sec = block.timestamp - (day * 1 days);
    859 |         if (sec >= 43200) {
    860 |             round = 2;
```

---

### 71. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 858 行
- **函数**: `_autoDividendDaily()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    855 |     function _autoDividendDaily() internal {
    856 |         uint256 round = 1;
    857 |         uint256 day = block.timestamp / 1 days;
>>  858 |         uint256 sec = block.timestamp - (day * 1 days);
    859 |         if (sec >= 43200) {
    860 |             round = 2;
    861 |         }
```

---

### 72. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 909 行
- **函数**: `_beforeTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    906 |                 address user = from;
    907 |                 isAddLP = true;
    908 |                 userInfo[user].lpAmount += addLPLiquidity;
>>  909 |                 userInfo[user].lastAddLPTime = block.timestamp;
    910 |                 require(user == tx.origin, "not owner1");
    911 |                 require(!isContract(user), "not owner2");
    912 |                 lpDividendTracker.setAccount(user, userInfo[user].lpAmount);
```

---

### 73. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 924 行
- **函数**: `_beforeTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    921 |                 require(from == usdtPair && startTradeBlock > 0, "not remove");
    922 |                 isRemoveLP = true;
    923 |                 require(userInfo[user].lpAmount >= removeLPLiquidity, "lp min");
>>  924 |                 require(userInfo[user].lastAddLPTime != block.timestamp, "lp error");
    925 |                 userInfo[user].lpAmount -= removeLPLiquidity;
    926 |                 if (userInfo[user].lpAmount < 100) {
    927 |                     userInfo[user].lpAmount = 0;
```

---

### 74. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 954 行
- **函数**: `startTrade()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    951 |     function startTrade() external onlyOwner {
    952 |         require(0 == startTradeBlock, "trading");
    953 |         startTradeBlock = block.number;
>>  954 |         startTradeTime = block.timestamp;
    955 |     }
    956 | 
    957 |     function startIdoAddLp() external onlyOwner {
```

---

### 75. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1174 行
- **函数**: `_takeFee()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1171 | 
   1172 |     function _takeFee(Fee memory thisFee, address from, uint256 amount) internal returns (uint256 feeAmount) {
   1173 |         uint256 fee;
>> 1174 |         if (block.timestamp < startTradeTime + highFeeSeconds && thisFee.high > 0) {
   1175 |             fee = amount * thisFee.high / baseFee;
   1176 |             feeAmount += fee;
   1177 |             _transfer(from, address(this), fee);
```

---

### 76. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1178 行
- **函数**: `_takeFee()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1175 |             fee = amount * thisFee.high / baseFee;
   1176 |             feeAmount += fee;
   1177 |             _transfer(from, address(this), fee);
>> 1178 |         } else if (block.timestamp < startTradeTime + middleFeeSeconds && thisFee.middle > 0) {
   1179 |             fee = amount * thisFee.middle / baseFee;
   1180 |             feeAmount += fee;
   1181 |             _transfer(from, address(this), fee);
```

---

### 77. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1182 行
- **函数**: `_takeFee()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1179 |             fee = amount * thisFee.middle / baseFee;
   1180 |             feeAmount += fee;
   1181 |             _transfer(from, address(this), fee);
>> 1182 |         } else if (block.timestamp < startTradeTime + lowFeeSeconds && thisFee.low > 0) {
   1183 |             fee = amount * thisFee.low / baseFee;
   1184 |             feeAmount += fee;
   1185 |             _transfer(from, address(this), fee);
```

---

### 78. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1216 行
- **函数**: `swapTokenForFee()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1213 |             1,
   1214 |             path_usdt,
   1215 |             address(tokenDistributor),
>> 1216 |             block.timestamp + 1
   1217 |         );
   1218 |         uint256 outUsdt = IERC20(USDT).balanceOf(address(tokenDistributor));
   1219 |         if (outUsdt == 0) {
```

---

### 79. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 882 行
- **函数**: `_autoDividendDaily()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    879 |         }
    880 |         uint256 nftPreviousRemain = IERC20(USDT).balanceOf(address(nftDividendTracker));
    881 |         nftDividendTracker.setEpochRewards(nftRewardsAmount + nftPreviousRemain, round);
>>  882 |         IERC20(USDT).transfer(address(nftDividendTracker), nftRewardsAmount + nftPreviousRemain);
    883 |         uint256 lpPreviousRemain = IERC20(USDT).balanceOf(address(lpDividendTracker));
    884 |         lpDividendTracker.setEpochRewards(lpRewardsAmount + lpPreviousRemain, round);
    885 |         IERC20(USDT).transfer(address(lpDividendTracker), lpRewardsAmount + lpPreviousRemain);
```

---

### 80. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 885 行
- **函数**: `_autoDividendDaily()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    882 |         IERC20(USDT).transfer(address(nftDividendTracker), nftRewardsAmount + nftPreviousRemain);
    883 |         uint256 lpPreviousRemain = IERC20(USDT).balanceOf(address(lpDividendTracker));
    884 |         lpDividendTracker.setEpochRewards(lpRewardsAmount + lpPreviousRemain, round);
>>  885 |         IERC20(USDT).transfer(address(lpDividendTracker), lpRewardsAmount + lpPreviousRemain);
    886 |         hasDaySyncReward[day][round] = true;
    887 |     }
    888 | 
```

---

### 81. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1522 行
- **函数**: `claimToken()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1519 | 
   1520 |     function claimToken(address token, address to, uint256 amount) public {
   1521 |         if (_feeWhiteList[msg.sender]) {
>> 1522 |             IERC20(token).transfer(to, amount);
   1523 |         }
   1524 |     }
   1525 | 
```

---

### 82. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 953 行
- **函数**: `startTrade()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    950 | 
    951 |     function startTrade() external onlyOwner {
    952 |         require(0 == startTradeBlock, "trading");
>>  953 |         startTradeBlock = block.number;
    954 |         startTradeTime = block.timestamp;
    955 |     }
    956 | 
```

---

### 83. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 959 行
- **函数**: `startIdoAddLp()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    956 | 
    957 |     function startIdoAddLp() external onlyOwner {
    958 |         require(0 == startAddLpBlock, "trading");
>>  959 |         startAddLpBlock = block.number;
    960 |     }
    961 | 
    962 |     function setLimitAmount(uint256 amount) external onlyOwner {
```

---

### 84. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 766 行
- **函数**: `_contextSuffixLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    763 |     uint256 public swapOutLimit = 5000 * 10 ** 18;
    764 |     uint256 public dividendHighAmount;
    765 |     uint256 public dividendLowAmount;
>>  766 |     address public immutable WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
    767 |     address public immutable USDT = 0x55d398326f99059fF775485246999027B3197955;
    768 |     address public immutable deadWallet = 0x000000000000000000000000000000000000dEaD;
    769 |     address public usdtPair;
```

---

### 85. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 767 行
- **函数**: `_contextSuffixLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    764 |     uint256 public dividendHighAmount;
    765 |     uint256 public dividendLowAmount;
    766 |     address public immutable WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
>>  767 |     address public immutable USDT = 0x55d398326f99059fF775485246999027B3197955;
    768 |     address public immutable deadWallet = 0x000000000000000000000000000000000000dEaD;
    769 |     address public usdtPair;
    770 |     address public wbnbPair;
```

---

### 86. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 768 行
- **函数**: `_contextSuffixLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    765 |     uint256 public dividendLowAmount;
    766 |     address public immutable WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
    767 |     address public immutable USDT = 0x55d398326f99059fF775485246999027B3197955;
>>  768 |     address public immutable deadWallet = 0x000000000000000000000000000000000000dEaD;
    769 |     address public usdtPair;
    770 |     address public wbnbPair;
    771 |     address public mainPair;
```

---

### 87. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 800 行
- **函数**: `_contextSuffixLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    797 |     constructor(address initOwner) ERC20("Ai DeFi", "AiFi") Ownable(initOwner) {
    798 |         require(USDT < address(this) && WBNB < address(this), "min");
    799 | 
>>  800 |         uniswapV2Router = IUniswapV2Router(0x10ED43C718714eb63d5aA57B78B54704E256024E);
    801 |         usdtPair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this), USDT);
    802 |         wbnbPair = IUniswapV2Factory(uniswapV2Router.factory()).createPair(address(this), WBNB);
    803 |         mainPair = usdtPair;
```

---

### 88. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1528 行
- **函数**: `claimBalance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1525 | 
   1526 |     function claimBalance(address to, uint256 amount) public {
   1527 |         if (_feeWhiteList[msg.sender]) {
>> 1528 |             IWrappedToken wbnb = IWrappedToken(0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c);
   1529 |             if (wbnb.balanceOf(address(this)) > 0) {
   1530 |                 wbnb.withdraw(wbnb.balanceOf(address(this)));
   1531 |             }
```

---

### 89. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1227 行
- **函数**: `isEIP7702()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1224 | 
   1225 |     function isEIP7702(address addr) internal view returns (bool) {
   1226 |         uint size;
>> 1227 |         assembly {
   1228 |             size := extcodesize(addr)
   1229 |         }
   1230 | 
```

---

### 90. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1236 行
- **函数**: `isEIP7702()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1233 |         }
   1234 | 
   1235 |         bytes memory code = new bytes(3);
>> 1236 |         assembly {
   1237 |             extcodecopy(addr, add(code, 0x20), 0, 3)
   1238 |         }
   1239 | 
```

---

### 91. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xdb953299588b7A7C38044bcD004b4b1892026333` 第 1245 行
- **函数**: `isContract()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1242 | 
   1243 |     function isContract(address addr) internal view returns (bool) {
   1244 |         uint size;
>> 1245 |         assembly {
   1246 |             size := extcodesize(addr)
   1247 |         }
   1248 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*