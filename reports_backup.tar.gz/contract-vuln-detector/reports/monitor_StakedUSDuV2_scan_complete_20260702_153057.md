# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:30:57
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x385C279445581a186a4182a5503094eBb652EC71` |
| contract_name | `StakedUSDuV2` |
| compiler_version | `v0.8.27+commit.40a35a09` |
| optimization_used | `True` |
| runs | `20` |
| evm_version | `paris` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/access/AccessControl.sol', '@openzeppelin/contracts/access/IAccessControl.sol', '@openzeppelin/contracts/interfaces/IERC4626.sol', '@openzeppelin/contracts/interfaces/IERC5267.sol', '@openzeppelin/contracts/interfaces/IERC5313.sol', '@openzeppelin/contracts/security/ReentrancyGuard.sol', '@openzeppelin/contracts/token/ERC20/ERC20.sol', '@openzeppelin/contracts/token/ERC20/extensions/draft-ERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/extensions/ERC4626.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', '@openzeppelin/contracts/utils/Address.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/utils/Counters.sol', '@openzeppelin/contracts/utils/cryptography/ECDSA.sol', '@openzeppelin/contracts/utils/cryptography/EIP712.sol', '@openzeppelin/contracts/utils/introspection/ERC165.sol', '@openzeppelin/contracts/utils/introspection/IERC165.sol', '@openzeppelin/contracts/utils/math/Math.sol', '@openzeppelin/contracts/utils/math/SignedMath.sol', '@openzeppelin/contracts/utils/ShortStrings.sol', '@openzeppelin/contracts/utils/StorageSlot.sol', '@openzeppelin/contracts/utils/Strings.sol', 'contracts/interfaces/ISingleAdminAccessControl.sol', 'contracts/interfaces/IStakedUSDu.sol', 'contracts/interfaces/IStakedUSDuCooldown.sol', 'contracts/interfaces/IUSDuSiloDefinitions.sol', 'contracts/SingleAdminAccessControl.sol', 'contracts/StakedUSDu.sol', 'contracts/StakedUSDuV2.sol', 'contracts/USDuSilo.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655011` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 94 |
| 🟢 LOW | 27 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1967 行
- **函数**: `functionDelegateCall()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1964 |         bytes memory data,
   1965 |         string memory errorMessage
   1966 |     ) internal returns (bytes memory) {
>> 1967 |         (bool success, bytes memory returndata) = target.delegatecall(data);
   1968 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
   1969 |     }
   1970 | 
```

---

### 2. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3640 行
- **函数**: `getUnvestedAmount()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   3637 |    * @notice Returns the amount of USDu tokens that are unvested in the contract.
   3638 |    */
   3639 |   function getUnvestedAmount() public view returns (uint256) {
>> 3640 |     uint256 timeSinceLastDistribution = block.timestamp - lastDistributionTimestamp;
   3641 | 
   3642 |     if (timeSinceLastDistribution >= VESTING_PERIOD) {
   3643 |       return 0;
```

---

### 3. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1774 行
- **函数**: `_callOptionalReturnBool()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1771 |         // we're implementing it ourselves. We cannot use {Address-functionCall} here since this should return false
   1772 |         // and not revert is the subcall reverts.
   1773 | 
>> 1774 |         (bool success, bytes memory returndata) = address(token).call(data);
   1775 |         return
   1776 |             success && (returndata.length == 0 || abi.decode(returndata, (bool))) && Address.isContract(address(token));
   1777 |     }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1849 行
- **函数**: `sendValue()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1846 |     function sendValue(address payable recipient, uint256 amount) internal {
   1847 |         require(address(this).balance >= amount, "Address: insufficient balance");
   1848 | 
>> 1849 |         (bool success, ) = recipient.call{value: amount}("");
   1850 |         require(success, "Address: unable to send value, recipient may have reverted");
   1851 |     }
   1852 | 
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1917 行
- **函数**: `functionCallWithValue()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1914 |         string memory errorMessage
   1915 |     ) internal returns (bytes memory) {
   1916 |         require(address(this).balance >= value, "Address: insufficient balance for call");
>> 1917 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
   1918 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
   1919 |     }
   1920 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 80 行
- **函数**: `supportsInterface()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     77 |     /**
     78 |      * @dev See {IERC165-supportsInterface}.
     79 |      */
>>   80 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
     81 |         return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
     82 |     }
     83 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 87 行
- **函数**: `hasRole()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     84 |     /**
     85 |      * @dev Returns `true` if `account` has been granted `role`.
     86 |      */
>>   87 |     function hasRole(bytes32 role, address account) public view virtual override returns (bool) {
     88 |         return _roles[role].members[account];
     89 |     }
     90 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 131 行
- **函数**: `getRoleAdmin()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    128 |      *
    129 |      * To change a role's admin, use {_setRoleAdmin}.
    130 |      */
>>  131 |     function getRoleAdmin(bytes32 role) public view virtual override returns (bytes32) {
    132 |         return _roles[role].adminRole;
    133 |     }
    134 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 182 行
- **函数**: `renounceRole()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    179 |      *
    180 |      * May emit a {RoleRevoked} event.
    181 |      */
>>  182 |     function renounceRole(bytes32 role, address account) public virtual override {
    183 |         require(account == _msgSender(), "AccessControl: can only renounce roles for self");
    184 | 
    185 |         _revokeRole(role, account);
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 294 行
- **函数**: `hasRole()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    291 |     /**
    292 |      * @dev Returns `true` if `account` has been granted `role`.
    293 |      */
>>  294 |     function hasRole(bytes32 role, address account) external view returns (bool);
    295 | 
    296 |     /**
    297 |      * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 302 行
- **函数**: `getRoleAdmin()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    299 |      *
    300 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
    301 |      */
>>  302 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
    303 | 
    304 |     /**
    305 |      * @dev Grants `role` to `account`.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 378 行
- **函数**: `asset()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    375 |      * - MUST be an ERC-20 token contract.
    376 |      * - MUST NOT revert.
    377 |      */
>>  378 |     function asset() external view returns (address assetTokenAddress);
    379 | 
    380 |     /**
    381 |      * @dev Returns the total amount of the underlying asset that is “managed” by Vault.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 387 行
- **函数**: `totalAssets()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    384 |      * - MUST be inclusive of any fees that are charged against assets in the Vault.
    385 |      * - MUST NOT revert.
    386 |      */
>>  387 |     function totalAssets() external view returns (uint256 totalManagedAssets);
    388 | 
    389 |     /**
    390 |      * @dev Returns the amount of shares that the Vault would exchange for the amount of assets provided, in an ideal
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 402 行
- **函数**: `convertToShares()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    399 |      * “average-user’s” price-per-share, meaning what the average user should expect to see when exchanging to and
    400 |      * from.
    401 |      */
>>  402 |     function convertToShares(uint256 assets) external view returns (uint256 shares);
    403 | 
    404 |     /**
    405 |      * @dev Returns the amount of assets that the Vault would exchange for the amount of shares provided, in an ideal
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 417 行
- **函数**: `convertToAssets()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    414 |      * “average-user’s” price-per-share, meaning what the average user should expect to see when exchanging to and
    415 |      * from.
    416 |      */
>>  417 |     function convertToAssets(uint256 shares) external view returns (uint256 assets);
    418 | 
    419 |     /**
    420 |      * @dev Returns the maximum amount of the underlying asset that can be deposited into the Vault for the receiver,
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 427 行
- **函数**: `maxDeposit()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    424 |      * - MUST return 2 ** 256 - 1 if there is no limit on the maximum amount of assets that may be deposited.
    425 |      * - MUST NOT revert.
    426 |      */
>>  427 |     function maxDeposit(address receiver) external view returns (uint256 maxAssets);
    428 | 
    429 |     /**
    430 |      * @dev Allows an on-chain or off-chain user to simulate the effects of their deposit at the current block, given
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 444 行
- **函数**: `previewDeposit()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    441 |      * NOTE: any unfavorable discrepancy between convertToShares and previewDeposit SHOULD be considered slippage in
    442 |      * share price or some other type of condition, meaning the depositor will lose assets by depositing.
    443 |      */
>>  444 |     function previewDeposit(uint256 assets) external view returns (uint256 shares);
    445 | 
    446 |     /**
    447 |      * @dev Mints shares Vault shares to receiver by depositing exactly amount of underlying tokens.
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 457 行
- **函数**: `deposit()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    454 |      *
    455 |      * NOTE: most implementations will require pre-approval of the Vault with the Vault’s underlying asset token.
    456 |      */
>>  457 |     function deposit(uint256 assets, address receiver) external returns (uint256 shares);
    458 | 
    459 |     /**
    460 |      * @dev Returns the maximum amount of the Vault shares that can be minted for the receiver, through a mint call.
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 465 行
- **函数**: `maxMint()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    462 |      * - MUST return 2 ** 256 - 1 if there is no limit on the maximum amount of shares that may be minted.
    463 |      * - MUST NOT revert.
    464 |      */
>>  465 |     function maxMint(address receiver) external view returns (uint256 maxShares);
    466 | 
    467 |     /**
    468 |      * @dev Allows an on-chain or off-chain user to simulate the effects of their mint at the current block, given
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 482 行
- **函数**: `previewMint()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    479 |      * NOTE: any unfavorable discrepancy between convertToAssets and previewMint SHOULD be considered slippage in
    480 |      * share price or some other type of condition, meaning the depositor will lose assets by minting.
    481 |      */
>>  482 |     function previewMint(uint256 shares) external view returns (uint256 assets);
    483 | 
    484 |     /**
    485 |      * @dev Mints exactly shares Vault shares to receiver by depositing amount of underlying tokens.
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 495 行
- **函数**: `mint()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    492 |      *
    493 |      * NOTE: most implementations will require pre-approval of the Vault with the Vault’s underlying asset token.
    494 |      */
>>  495 |     function mint(uint256 shares, address receiver) external returns (uint256 assets);
    496 | 
    497 |     /**
    498 |      * @dev Returns the maximum amount of the underlying asset that can be withdrawn from the owner balance in the
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 504 行
- **函数**: `maxWithdraw()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    501 |      * - MUST return a limited value if owner is subject to some withdrawal limit or timelock.
    502 |      * - MUST NOT revert.
    503 |      */
>>  504 |     function maxWithdraw(address owner) external view returns (uint256 maxAssets);
    505 | 
    506 |     /**
    507 |      * @dev Allows an on-chain or off-chain user to simulate the effects of their withdrawal at the current block,
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 522 行
- **函数**: `previewWithdraw()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    519 |      * NOTE: any unfavorable discrepancy between convertToShares and previewWithdraw SHOULD be considered slippage in
    520 |      * share price or some other type of condition, meaning the depositor will lose assets by depositing.
    521 |      */
>>  522 |     function previewWithdraw(uint256 assets) external view returns (uint256 shares);
    523 | 
    524 |     /**
    525 |      * @dev Burns shares from owner and sends exactly assets of underlying tokens to receiver.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 536 行
- **函数**: `withdraw()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    533 |      * Note that some implementations will require pre-requesting to the Vault before a withdrawal may be performed.
    534 |      * Those methods should be performed separately.
    535 |      */
>>  536 |     function withdraw(uint256 assets, address receiver, address owner) external returns (uint256 shares);
    537 | 
    538 |     /**
    539 |      * @dev Returns the maximum amount of Vault shares that can be redeemed from the owner balance in the Vault,
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 546 行
- **函数**: `maxRedeem()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    543 |      * - MUST return balanceOf(owner) if owner is not subject to any withdrawal limit or timelock.
    544 |      * - MUST NOT revert.
    545 |      */
>>  546 |     function maxRedeem(address owner) external view returns (uint256 maxShares);
    547 | 
    548 |     /**
    549 |      * @dev Allows an on-chain or off-chain user to simulate the effects of their redeemption at the current block,
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 563 行
- **函数**: `previewRedeem()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    560 |      * NOTE: any unfavorable discrepancy between convertToAssets and previewRedeem SHOULD be considered slippage in
    561 |      * share price or some other type of condition, meaning the depositor will lose assets by redeeming.
    562 |      */
>>  563 |     function previewRedeem(uint256 shares) external view returns (uint256 assets);
    564 | 
    565 |     /**
    566 |      * @dev Burns exactly shares from owner and sends assets of underlying tokens to receiver.
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 577 行
- **函数**: `redeem()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    574 |      * NOTE: some implementations will require pre-requesting to the Vault before a withdrawal may be performed.
    575 |      * Those methods should be performed separately.
    576 |      */
>>  577 |     function redeem(uint256 shares, address receiver, address owner) external returns (uint256 assets);
    578 | }
    579 | 
    580 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 631 行
- **函数**: `owner()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    628 |     /**
    629 |      * @dev Gets the address of the owner.
    630 |      */
>>  631 |     function owner() external view returns (address);
    632 | }
    633 | 
    634 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 779 行
- **函数**: `name()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    776 |     /**
    777 |      * @dev Returns the name of the token.
    778 |      */
>>  779 |     function name() public view virtual override returns (string memory) {
    780 |         return _name;
    781 |     }
    782 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 787 行
- **函数**: `symbol()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    784 |      * @dev Returns the symbol of the token, usually a shorter version of the
    785 |      * name.
    786 |      */
>>  787 |     function symbol() public view virtual override returns (string memory) {
    788 |         return _symbol;
    789 |     }
    790 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 804 行
- **函数**: `decimals()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    801 |      * no way affects any of the arithmetic of the contract, including
    802 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    803 |      */
>>  804 |     function decimals() public view virtual override returns (uint8) {
    805 |         return 18;
    806 |     }
    807 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 811 行
- **函数**: `totalSupply()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    808 |     /**
    809 |      * @dev See {IERC20-totalSupply}.
    810 |      */
>>  811 |     function totalSupply() public view virtual override returns (uint256) {
    812 |         return _totalSupply;
    813 |     }
    814 | 
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 818 行
- **函数**: `balanceOf()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    815 |     /**
    816 |      * @dev See {IERC20-balanceOf}.
    817 |      */
>>  818 |     function balanceOf(address account) public view virtual override returns (uint256) {
    819 |         return _balances[account];
    820 |     }
    821 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 830 行
- **函数**: `transfer()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    827 |      * - `to` cannot be the zero address.
    828 |      * - the caller must have a balance of at least `amount`.
    829 |      */
>>  830 |     function transfer(address to, uint256 amount) public virtual override returns (bool) {
    831 |         address owner = _msgSender();
    832 |         _transfer(owner, to, amount);
    833 |         return true;
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 839 行
- **函数**: `allowance()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    836 |     /**
    837 |      * @dev See {IERC20-allowance}.
    838 |      */
>>  839 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    840 |         return _allowances[owner][spender];
    841 |     }
    842 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 853 行
- **函数**: `approve()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    850 |      *
    851 |      * - `spender` cannot be the zero address.
    852 |      */
>>  853 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    854 |         address owner = _msgSender();
    855 |         _approve(owner, spender, amount);
    856 |         return true;
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 875 行
- **函数**: `transferFrom()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    872 |      * - the caller must have allowance for ``from``'s tokens of at least
    873 |      * `amount`.
    874 |      */
>>  875 |     function transferFrom(address from, address to, uint256 amount) public virtual override returns (bool) {
    876 |         address spender = _msgSender();
    877 |         _spendAllowance(from, spender, amount);
    878 |         _transfer(from, to, amount);
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 894 行
- **函数**: `increaseAllowance()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    891 |      *
    892 |      * - `spender` cannot be the zero address.
    893 |      */
>>  894 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    895 |         address owner = _msgSender();
    896 |         _approve(owner, spender, allowance(owner, spender) + addedValue);
    897 |         return true;
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 914 行
- **函数**: `decreaseAllowance()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    911 |      * - `spender` must have allowance for the caller of at least
    912 |      * `subtractedValue`.
    913 |      */
>>  914 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    915 |         address owner = _msgSender();
    916 |         uint256 currentAllowance = allowance(owner, spender);
    917 |         require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1171 行
- **函数**: `nonces()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1168 |     /**
   1169 |      * @dev See {IERC20Permit-nonces}.
   1170 |      */
>> 1171 |     function nonces(address owner) public view virtual override returns (uint256) {
   1172 |         return _nonces[owner].current();
   1173 |     }
   1174 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1179 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1176 |      * @dev See {IERC20Permit-DOMAIN_SEPARATOR}.
   1177 |      */
   1178 |     // solhint-disable-next-line func-name-mixedcase
>> 1179 |     function DOMAIN_SEPARATOR() external view override returns (bytes32) {
   1180 |         return _domainSeparatorV4();
   1181 |     }
   1182 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1285 行
- **函数**: `decimals()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1282 |      *
   1283 |      * See {IERC20Metadata-decimals}.
   1284 |      */
>> 1285 |     function decimals() public view virtual override(IERC20Metadata, ERC20) returns (uint8) {
   1286 |         return _underlyingDecimals + _decimalsOffset();
   1287 |     }
   1288 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1290 行
- **函数**: `asset()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1287 |     }
   1288 | 
   1289 |     /** @dev See {IERC4626-asset}. */
>> 1290 |     function asset() public view virtual override returns (address) {
   1291 |         return address(_asset);
   1292 |     }
   1293 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1295 行
- **函数**: `totalAssets()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1292 |     }
   1293 | 
   1294 |     /** @dev See {IERC4626-totalAssets}. */
>> 1295 |     function totalAssets() public view virtual override returns (uint256) {
   1296 |         return _asset.balanceOf(address(this));
   1297 |     }
   1298 | 
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1300 行
- **函数**: `convertToShares()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1297 |     }
   1298 | 
   1299 |     /** @dev See {IERC4626-convertToShares}. */
>> 1300 |     function convertToShares(uint256 assets) public view virtual override returns (uint256) {
   1301 |         return _convertToShares(assets, Math.Rounding.Down);
   1302 |     }
   1303 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1305 行
- **函数**: `convertToAssets()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1302 |     }
   1303 | 
   1304 |     /** @dev See {IERC4626-convertToAssets}. */
>> 1305 |     function convertToAssets(uint256 shares) public view virtual override returns (uint256) {
   1306 |         return _convertToAssets(shares, Math.Rounding.Down);
   1307 |     }
   1308 | 
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1310 行
- **函数**: `maxDeposit()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1307 |     }
   1308 | 
   1309 |     /** @dev See {IERC4626-maxDeposit}. */
>> 1310 |     function maxDeposit(address) public view virtual override returns (uint256) {
   1311 |         return type(uint256).max;
   1312 |     }
   1313 | 
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1315 行
- **函数**: `maxMint()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1312 |     }
   1313 | 
   1314 |     /** @dev See {IERC4626-maxMint}. */
>> 1315 |     function maxMint(address) public view virtual override returns (uint256) {
   1316 |         return type(uint256).max;
   1317 |     }
   1318 | 
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1320 行
- **函数**: `maxWithdraw()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1317 |     }
   1318 | 
   1319 |     /** @dev See {IERC4626-maxWithdraw}. */
>> 1320 |     function maxWithdraw(address owner) public view virtual override returns (uint256) {
   1321 |         return _convertToAssets(balanceOf(owner), Math.Rounding.Down);
   1322 |     }
   1323 | 
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1325 行
- **函数**: `maxRedeem()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1322 |     }
   1323 | 
   1324 |     /** @dev See {IERC4626-maxRedeem}. */
>> 1325 |     function maxRedeem(address owner) public view virtual override returns (uint256) {
   1326 |         return balanceOf(owner);
   1327 |     }
   1328 | 
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1330 行
- **函数**: `previewDeposit()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1327 |     }
   1328 | 
   1329 |     /** @dev See {IERC4626-previewDeposit}. */
>> 1330 |     function previewDeposit(uint256 assets) public view virtual override returns (uint256) {
   1331 |         return _convertToShares(assets, Math.Rounding.Down);
   1332 |     }
   1333 | 
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1335 行
- **函数**: `previewMint()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1332 |     }
   1333 | 
   1334 |     /** @dev See {IERC4626-previewMint}. */
>> 1335 |     function previewMint(uint256 shares) public view virtual override returns (uint256) {
   1336 |         return _convertToAssets(shares, Math.Rounding.Up);
   1337 |     }
   1338 | 
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1340 行
- **函数**: `previewWithdraw()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1337 |     }
   1338 | 
   1339 |     /** @dev See {IERC4626-previewWithdraw}. */
>> 1340 |     function previewWithdraw(uint256 assets) public view virtual override returns (uint256) {
   1341 |         return _convertToShares(assets, Math.Rounding.Up);
   1342 |     }
   1343 | 
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1345 行
- **函数**: `previewRedeem()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1342 |     }
   1343 | 
   1344 |     /** @dev See {IERC4626-previewRedeem}. */
>> 1345 |     function previewRedeem(uint256 shares) public view virtual override returns (uint256) {
   1346 |         return _convertToAssets(shares, Math.Rounding.Down);
   1347 |     }
   1348 | 
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1350 行
- **函数**: `deposit()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1347 |     }
   1348 | 
   1349 |     /** @dev See {IERC4626-deposit}. */
>> 1350 |     function deposit(uint256 assets, address receiver) public virtual override returns (uint256) {
   1351 |         require(assets <= maxDeposit(receiver), "ERC4626: deposit more than max");
   1352 | 
   1353 |         uint256 shares = previewDeposit(assets);
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1364 行
- **函数**: `mint()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1361 |      * As opposed to {deposit}, minting is allowed even if the vault is in a state where the price of a share is zero.
   1362 |      * In this case, the shares will be minted without requiring any assets to be deposited.
   1363 |      */
>> 1364 |     function mint(uint256 shares, address receiver) public virtual override returns (uint256) {
   1365 |         require(shares <= maxMint(receiver), "ERC4626: mint more than max");
   1366 | 
   1367 |         uint256 assets = previewMint(shares);
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1374 行
- **函数**: `withdraw()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1371 |     }
   1372 | 
   1373 |     /** @dev See {IERC4626-withdraw}. */
>> 1374 |     function withdraw(uint256 assets, address receiver, address owner) public virtual override returns (uint256) {
   1375 |         require(assets <= maxWithdraw(owner), "ERC4626: withdraw more than max");
   1376 | 
   1377 |         uint256 shares = previewWithdraw(assets);
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1384 行
- **函数**: `redeem()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1381 |     }
   1382 | 
   1383 |     /** @dev See {IERC4626-redeem}. */
>> 1384 |     function redeem(uint256 shares, address receiver, address owner) public virtual override returns (uint256) {
   1385 |         require(shares <= maxRedeem(owner), "ERC4626: redeem more than max");
   1386 | 
   1387 |         uint256 assets = previewRedeem(shares);
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1474 行
- **函数**: `name()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1471 |     /**
   1472 |      * @dev Returns the name of the token.
   1473 |      */
>> 1474 |     function name() external view returns (string memory);
   1475 | 
   1476 |     /**
   1477 |      * @dev Returns the symbol of the token.
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1479 行
- **函数**: `symbol()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1476 |     /**
   1477 |      * @dev Returns the symbol of the token.
   1478 |      */
>> 1479 |     function symbol() external view returns (string memory);
   1480 | 
   1481 |     /**
   1482 |      * @dev Returns the decimals places of the token.
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1484 行
- **函数**: `decimals()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1481 |     /**
   1482 |      * @dev Returns the decimals places of the token.
   1483 |      */
>> 1484 |     function decimals() external view returns (uint8);
   1485 | }
   1486 | 
   1487 | 
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1542 行
- **函数**: `nonces()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1539 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   1540 |      * prevents a signature from being used multiple times.
   1541 |      */
>> 1542 |     function nonces(address owner) external view returns (uint256);
   1543 | 
   1544 |     /**
   1545 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1548 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1545 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
   1546 |      */
   1547 |     // solhint-disable-next-line func-name-mixedcase
>> 1548 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1549 | }
   1550 | 
   1551 | 
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1580 行
- **函数**: `totalSupply()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1577 |     /**
   1578 |      * @dev Returns the amount of tokens in existence.
   1579 |      */
>> 1580 |     function totalSupply() external view returns (uint256);
   1581 | 
   1582 |     /**
   1583 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1585 行
- **函数**: `balanceOf()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1582 |     /**
   1583 |      * @dev Returns the amount of tokens owned by `account`.
   1584 |      */
>> 1585 |     function balanceOf(address account) external view returns (uint256);
   1586 | 
   1587 |     /**
   1588 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1594 行
- **函数**: `transfer()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1591 |      *
   1592 |      * Emits a {Transfer} event.
   1593 |      */
>> 1594 |     function transfer(address to, uint256 amount) external returns (bool);
   1595 | 
   1596 |     /**
   1597 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1603 行
- **函数**: `allowance()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1600 |      *
   1601 |      * This value changes when {approve} or {transferFrom} are called.
   1602 |      */
>> 1603 |     function allowance(address owner, address spender) external view returns (uint256);
   1604 | 
   1605 |     /**
   1606 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1619 行
- **函数**: `approve()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1616 |      *
   1617 |      * Emits an {Approval} event.
   1618 |      */
>> 1619 |     function approve(address spender, uint256 amount) external returns (bool);
   1620 | 
   1621 |     /**
   1622 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1630 行
- **函数**: `transferFrom()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1627 |      *
   1628 |      * Emits a {Transfer} event.
   1629 |      */
>> 1630 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
   1631 | }
   1632 | 
   1633 | 
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2498 行
- **函数**: `supportsInterface()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2495 |     /**
   2496 |      * @dev See {IERC165-supportsInterface}.
   2497 |      */
>> 2498 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
   2499 |         return interfaceId == type(IERC165).interfaceId;
   2500 |     }
   2501 | }
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2529 行
- **函数**: `supportsInterface()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2526 |      *
   2527 |      * This function call must use less than 30 000 gas.
   2528 |      */
>> 2529 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   2530 | }
   2531 | 
   2532 | 
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3329 行
- **函数**: `getUnvestedAmount()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3326 | 
   3327 |   function rescueTokens(address token, uint256 amount, address to) external;
   3328 | 
>> 3329 |   function getUnvestedAmount() external view returns (uint256);
   3330 | }
   3331 | 
   3332 | 
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3361 行
- **函数**: `cooldownAssets()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3358 |   /// @notice Error emitted when cooldown value is invalid
   3359 |   error InvalidCooldown();
   3360 | 
>> 3361 |   function cooldownAssets(uint256 assets) external returns (uint256 shares);
   3362 | 
   3363 |   function cooldownShares(uint256 shares) external returns (uint256 assets);
   3364 | 
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3363 行
- **函数**: `cooldownShares()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3360 | 
   3361 |   function cooldownAssets(uint256 assets) external returns (uint256 shares);
   3362 | 
>> 3363 |   function cooldownShares(uint256 shares) external returns (uint256 assets);
   3364 | 
   3365 |   function unstake(address receiver) external;
   3366 | 
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3414 行
- **函数**: `acceptAdmin()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3411 |     emit AdminTransferRequested(_currentDefaultAdmin, newAdmin);
   3412 |   }
   3413 | 
>> 3414 |   function acceptAdmin() external {
   3415 |     if (msg.sender != _pendingDefaultAdmin) revert NotPendingAdmin();
   3416 |     _grantRole(DEFAULT_ADMIN_ROLE, msg.sender);
   3417 |   }
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3441 行
- **函数**: `renounceRole()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3438 |   /// @notice admin role cannot be renounced
   3439 |   /// @param role bytes32
   3440 |   /// @param account address
>> 3441 |   function renounceRole(bytes32 role, address account) public virtual override notAdmin(role) {
   3442 |     super.renounceRole(role, account);
   3443 |   }
   3444 | 
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3448 行
- **函数**: `owner()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3445 |   /**
   3446 |    * @dev See {IERC5313-owner}.
   3447 |    */
>> 3448 |   function owner() public view virtual returns (address) {
   3449 |     return _currentDefaultAdmin;
   3450 |   }
   3451 | 
```

---

### 78. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3632 行
- **函数**: `totalAssets()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3629 |   /**
   3630 |    * @notice Returns the amount of USDu tokens that are vested in the contract.
   3631 |    */
>> 3632 |   function totalAssets() public view override returns (uint256) {
   3633 |     return IERC20(asset()).balanceOf(address(this)) - getUnvestedAmount();
   3634 |   }
   3635 | 
```

---

### 79. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3639 行
- **函数**: `getUnvestedAmount()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3636 |   /**
   3637 |    * @notice Returns the amount of USDu tokens that are unvested in the contract.
   3638 |    */
>> 3639 |   function getUnvestedAmount() public view returns (uint256) {
   3640 |     uint256 timeSinceLastDistribution = block.timestamp - lastDistributionTimestamp;
   3641 | 
   3642 |     if (timeSinceLastDistribution >= VESTING_PERIOD) {
```

---

### 80. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3650 行
- **函数**: `decimals()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3647 |   }
   3648 | 
   3649 |   /// @dev Necessary because both ERC20 (from ERC20Permit) and ERC4626 declare decimals()
>> 3650 |   function decimals() public pure override(ERC4626, ERC20) returns (uint8) {
   3651 |     return 18;
   3652 |   }
   3653 | 
```

---

### 81. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3736 行
- **函数**: `renounceRole()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3733 |   /**
   3734 |    * @dev Remove renounce role access from AccessControl, to prevent users to resign roles.
   3735 |    */
>> 3736 |   function renounceRole(bytes32, address) public virtual override {
   3737 |     revert OperationNotAllowed();
   3738 |   }
   3739 | }
```

---

### 82. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3817 行
- **函数**: `unstake()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3814 |   /// @notice Claim the staking amount after the cooldown has finished. The address can only retire the full amount of assets.
   3815 |   /// @dev unstake can be called after cooldown have been set to 0, to let accounts to be able to claim remaining assets locked at Silo
   3816 |   /// @param receiver Address to send the assets by the staker
>> 3817 |   function unstake(address receiver) external {
   3818 |     if (hasRole(FULL_RESTRICTED_STAKER_ROLE, _msgSender()) || hasRole(FULL_RESTRICTED_STAKER_ROLE, receiver)) {
   3819 |       revert OperationNotAllowed();
   3820 |     }
```

---

### 83. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3837 行
- **函数**: `cooldownAssets()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3834 | 
   3835 |   /// @notice redeem assets and starts a cooldown to claim the converted underlying asset
   3836 |   /// @param assets assets to redeem
>> 3837 |   function cooldownAssets(uint256 assets) external ensureCooldownOn returns (uint256) {
   3838 |     if (assets > maxWithdraw(_msgSender())) revert ExcessiveWithdrawAmount();
   3839 | 
   3840 |     uint256 shares = previewWithdraw(assets);
```

---

### 84. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3852 行
- **函数**: `cooldownShares()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3849 | 
   3850 |   /// @notice redeem shares into assets and starts a cooldown to claim the converted underlying asset
   3851 |   /// @param shares shares to redeem
>> 3852 |   function cooldownShares(uint256 shares) external ensureCooldownOn returns (uint256) {
   3853 |     if (shares > maxRedeem(_msgSender())) revert ExcessiveRedeemAmount();
   3854 | 
   3855 |     uint256 assets = previewRedeem(shares);
```

---

### 85. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3908 行
- **函数**: `withdraw()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3905 |     _;
   3906 |   }
   3907 | 
>> 3908 |   function withdraw(address to, uint256 amount) external onlyStakingVault {
   3909 |     USDU.transfer(to, amount);
   3910 |   }
   3911 | }
```

---

### 86. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 450 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    445 | 
    446 |     /**
    447 |      * @dev Mints shares Vault shares to receiver by depositing exactly amount of underlying tokens.
    448 |      *
    449 |      * - MUST emit the Deposit event.
>>  450 |      * - MAY support an additional flow in which the underlying tokens are owned by the Vault contract before the
    451 |      *   deposit execution, and are accounted for during deposit.
    452 |      * - MUST revert if all of assets cannot be deposited (due to deposit limit being reached, slippage, the user not
    453 |      *   approving enough underlying tokens to the Vault contract, etc).
    454 |      *
    455 |      * NOTE: most implementations will require pre-approval of the Vault with the Vault’s underlying asset token.
```

---

### 87. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 755 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    750 |  *
    751 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    752 |  * functions have been added to mitigate the well-known issues around setting
    753 |  * allowances. See {IERC20-approve}.
    754 |  */
>>  755 | contract ERC20 is Context, IERC20, IERC20Metadata {
    756 |     mapping(address => uint256) private _balances;
    757 | 
    758 |     mapping(address => mapping(address => uint256)) private _allowances;
    759 | 
    760 |     uint256 private _totalSupply;
```

---

### 88. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1120 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1115 |  * presenting a message signed by the account. By not relying on `{IERC20-approve}`, the token holder account doesn't
   1116 |  * need to send a transaction, and thus is not required to hold Ether at all.
   1117 |  *
   1118 |  * _Available since v3.4._
   1119 |  */
>> 1120 | abstract contract ERC20Permit is ERC20, IERC20Permit, EIP712 {
   1121 |     using Counters for Counters.Counter;
   1122 | 
   1123 |     mapping(address => Counters.Counter) private _nonces;
   1124 | 
   1125 |     // solhint-disable-next-line var-name-mixedcase
```

---

### 89. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1213 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1208 | /**
   1209 |  * @dev Implementation of the ERC4626 "Tokenized Vault Standard" as defined in
   1210 |  * https://eips.ethereum.org/EIPS/eip-4626[EIP-4626].
   1211 |  *
   1212 |  * This extension allows the minting and burning of "shares" (represented using the ERC20 inheritance) in exchange for
>> 1213 |  * underlying "assets" through standardized {deposit}, {mint}, {redeem} and {burn} workflows. This contract extends
   1214 |  * the ERC20 standard. Any additional extensions included along it would affect the "shares" token represented by this
   1215 |  * contract and not the "assets" token which is an independent contract.
   1216 |  *
   1217 |  * [CAUTION]
   1218 |  * ====
```

---

### 90. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1648 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1643 | import "../../../utils/Address.sol";
   1644 | 
   1645 | /**
   1646 |  * @title SafeERC20
   1647 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>> 1648 |  * contract returns false). Tokens that return no value (and instead revert or
   1649 |  * throw on failure) are also supported, non-reverting calls are assumed to be
   1650 |  * successful.
   1651 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
   1652 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
   1653 |  */
```

---

### 91. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2350 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2345 |  * ({_hashTypedDataV4}).
   2346 |  *
   2347 |  * The implementation of the domain separator was designed to be as efficient as possible while still properly updating
   2348 |  * the chain id to protect against replay attacks on an eventual fork of the chain.
   2349 |  *
>> 2350 |  * NOTE: This contract implements the version of the encoding known as "v4", as implemented by the JSON RPC method
   2351 |  * https://docs.metamask.io/guide/signing-data.html[`eth_signTypedDataV4` in MetaMask].
   2352 |  *
   2353 |  * NOTE: In the upgradeable version of this contract, the cached values will correspond to the address, and the domain
   2354 |  * separator of the implementation contract. This will cause the `_domainSeparatorV4` function to always rebuild the
   2355 |  * separator from the immutable values, which is cheaper than accessing a cached version in cold storage.
```

---

### 92. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2948 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2943 |  * fallback mechanism can be used for every other case.
   2944 |  *
   2945 |  * Usage example:
   2946 |  *
   2947 |  * ```solidity
>> 2948 |  * contract Named {
   2949 |  *     using ShortStrings for *;
   2950 |  *
   2951 |  *     ShortString private immutable _name;
   2952 |  *     string private _nameFallback;
   2953 |  *
```

---

### 93. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3393 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3388 | import "@openzeppelin/contracts/interfaces/IERC5313.sol";
   3389 | import "./interfaces/ISingleAdminAccessControl.sol";
   3390 | 
   3391 | /**
   3392 |  * @title SingleAdminAccessControl
>> 3393 |  * @notice SingleAdminAccessControl is a contract that provides a single admin role
   3394 |  * @notice This contract is a simplified alternative to OpenZeppelin's AccessControlDefaultAdminRules
   3395 |  */
   3396 | abstract contract SingleAdminAccessControl is IERC5313, ISingleAdminAccessControl, AccessControl {
   3397 |   address private _currentDefaultAdmin;
   3398 |   address private _pendingDefaultAdmin;
```

---

### 94. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3484 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3479 | import "./SingleAdminAccessControl.sol";
   3480 | import "./interfaces/IStakedUSDu.sol";
   3481 | 
   3482 | /**
   3483 |  * @title StakedUSDu
>> 3484 |  * @notice The StakedUSDu contract allows users to stake USDu tokens and earn a portion of protocol LST and perpetual yield that is allocated
   3485 |  * to stakers by the Unitas DAO governance voted yield distribution algorithm.  The algorithm seeks to balance the stability of the protocol by funding
   3486 |  * the protocol's insurance fund, DAO activities, and rewarding stakers with a portion of the protocol's yield.
   3487 |  */
   3488 | contract StakedUSDu is SingleAdminAccessControl, ReentrancyGuard, ERC20Permit, ERC4626, IStakedUSDu {
   3489 |   using SafeERC20 for IERC20;
```

---

### 95. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3892 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3887 | 
   3888 | /**
   3889 |  * @title USDuSilo
   3890 |  * @notice The Silo allows to store USDu during the stake cooldown process.
   3891 |  */
>> 3892 | contract USDuSilo is IUSDuSiloDefinitions {
   3893 |   using SafeERC20 for IERC20;
   3894 | 
   3895 |   address immutable STAKING_VAULT;
   3896 |   IERC20 immutable USDU;
   3897 | 
```

---

### 96. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 1156 行
- **函数**: `permit()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1153 |         bytes32 r,
   1154 |         bytes32 s
   1155 |     ) public virtual override {
>> 1156 |         require(block.timestamp <= deadline, "ERC20Permit: expired deadline");
   1157 | 
   1158 |         bytes32 structHash = keccak256(abi.encode(_PERMIT_TYPEHASH, owner, spender, value, _useNonce(owner), deadline));
   1159 | 
```

---

### 97. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3640 行
- **函数**: `getUnvestedAmount()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   3637 |    * @notice Returns the amount of USDu tokens that are unvested in the contract.
   3638 |    */
   3639 |   function getUnvestedAmount() public view returns (uint256) {
>> 3640 |     uint256 timeSinceLastDistribution = block.timestamp - lastDistributionTimestamp;
   3641 | 
   3642 |     if (timeSinceLastDistribution >= VESTING_PERIOD) {
   3643 |       return 0;
```

---

### 98. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3717 行
- **函数**: `_updateVestingAmount()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   3714 |     if (getUnvestedAmount() > 0) revert StillVesting();
   3715 | 
   3716 |     vestingAmount = newVestingAmount;
>> 3717 |     lastDistributionTimestamp = block.timestamp;
   3718 |   }
   3719 | 
   3720 |   /**
```

---

### 99. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3825 行
- **函数**: `unstake()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   3822 |     UserCooldown storage userCooldown = cooldowns[msg.sender];
   3823 |     uint256 assets = userCooldown.underlyingAmount;
   3824 | 
>> 3825 |     if (block.timestamp >= userCooldown.cooldownEnd || cooldownDuration == 0) {
   3826 |       userCooldown.cooldownEnd = 0;
   3827 |       userCooldown.underlyingAmount = 0;
   3828 | 
```

---

### 100. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3842 行
- **函数**: `cooldownAssets()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   3839 | 
   3840 |     uint256 shares = previewWithdraw(assets);
   3841 | 
>> 3842 |     cooldowns[_msgSender()].cooldownEnd = uint104(block.timestamp) + cooldownDuration;
   3843 |     cooldowns[_msgSender()].underlyingAmount += assets;
   3844 | 
   3845 |     _withdraw(_msgSender(), address(silo), _msgSender(), assets, shares);
```

---

### 101. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3857 行
- **函数**: `cooldownShares()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   3854 | 
   3855 |     uint256 assets = previewRedeem(shares);
   3856 | 
>> 3857 |     cooldowns[_msgSender()].cooldownEnd = uint104(block.timestamp) + cooldownDuration;
   3858 |     cooldowns[_msgSender()].underlyingAmount += assets;
   3859 | 
   3860 |     _withdraw(_msgSender(), address(silo), _msgSender(), assets, shares);
```

---

### 102. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3909 行
- **函数**: `withdraw()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   3906 |   }
   3907 | 
   3908 |   function withdraw(address to, uint256 amount) external onlyStakingVault {
>> 3909 |     USDU.transfer(to, amount);
   3910 |   }
   3911 | }
   3912 | 
```

---

### 103. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2207 行
- **函数**: `tryRecover()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2204 |      * _Available since v4.3._
   2205 |      */
   2206 |     function tryRecover(bytes32 hash, bytes32 r, bytes32 vs) internal pure returns (address, RecoverError) {
>> 2207 |         bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
   2208 |         uint8 v = uint8((uint256(vs) >> 255) + 27);
   2209 |         return tryRecover(hash, v, r, s);
   2210 |     }
```

---

### 104. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2239 行
- **函数**: `tryRecover()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2236 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
   2237 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
   2238 |         // these malleable signatures as well.
>> 2239 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
   2240 |             return (address(0), RecoverError.InvalidSignatureS);
   2241 |         }
   2242 | 
```

---

### 105. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2018 行
- **函数**: `_revert()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2015 |         if (returndata.length > 0) {
   2016 |             // The easiest way to bubble the revert reason is using memory via assembly
   2017 |             /// @solidity memory-safe-assembly
>> 2018 |             assembly {
   2019 |                 let returndata_size := mload(returndata)
   2020 |                 revert(add(32, returndata), returndata_size)
   2021 |             }
```

---

### 106. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2168 行
- **函数**: `tryRecover()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2165 |             // ecrecover takes the signature parameters, and the only way to get them
   2166 |             // currently is to use assembly.
   2167 |             /// @solidity memory-safe-assembly
>> 2168 |             assembly {
   2169 |                 r := mload(add(signature, 0x20))
   2170 |                 s := mload(add(signature, 0x40))
   2171 |                 v := byte(0, mload(add(signature, 0x60)))
```

---

### 107. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2274 行
- **函数**: `toEthSignedMessageHash()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2271 |         // 32 is the length in bytes of hash,
   2272 |         // enforced by the type signature above
   2273 |         /// @solidity memory-safe-assembly
>> 2274 |         assembly {
   2275 |             mstore(0x00, "\x19Ethereum Signed Message:\n32")
   2276 |             mstore(0x1c, hash)
   2277 |             message := keccak256(0x00, 0x3c)
```

---

### 108. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2304 行
- **函数**: `toTypedDataHash()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2301 |      */
   2302 |     function toTypedDataHash(bytes32 domainSeparator, bytes32 structHash) internal pure returns (bytes32 data) {
   2303 |         /// @solidity memory-safe-assembly
>> 2304 |         assembly {
   2305 |             let ptr := mload(0x40)
   2306 |             mstore(ptr, "\x19\x01")
   2307 |             mstore(add(ptr, 0x02), domainSeparator)
```

---

### 109. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2596 行
- **函数**: `mulDiv()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2593 |             // variables such that product = prod1 * 2^256 + prod0.
   2594 |             uint256 prod0; // Least significant 256 bits of the product
   2595 |             uint256 prod1; // Most significant 256 bits of the product
>> 2596 |             assembly {
   2597 |                 let mm := mulmod(x, y, not(0))
   2598 |                 prod0 := mul(x, y)
   2599 |                 prod1 := sub(sub(mm, prod0), lt(mm, prod0))
```

---

### 110. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2619 行
- **函数**: `mulDiv()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2616 | 
   2617 |             // Make division exact by subtracting the remainder from [prod1 prod0].
   2618 |             uint256 remainder;
>> 2619 |             assembly {
   2620 |                 // Compute remainder using mulmod.
   2621 |                 remainder := mulmod(x, y, denominator)
   2622 | 
```

---

### 111. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2633 行
- **函数**: `mulDiv()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2630 | 
   2631 |             // Does not overflow because the denominator cannot be zero at this stage in the function.
   2632 |             uint256 twos = denominator & (~denominator + 1);
>> 2633 |             assembly {
   2634 |                 // Divide denominator by twos.
   2635 |                 denominator := div(denominator, twos)
   2636 | 
```

---

### 112. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 2992 行
- **函数**: `toString()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2989 |         // using `new string(len)` would work locally but is not memory safe.
   2990 |         string memory str = new string(32);
   2991 |         /// @solidity memory-safe-assembly
>> 2992 |         assembly {
   2993 |             mstore(str, len)
   2994 |             mstore(add(str, 0x20), sstr)
   2995 |         }
```

---

### 113. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3114 行
- **函数**: `getAddressSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3111 |      */
   3112 |     function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
   3113 |         /// @solidity memory-safe-assembly
>> 3114 |         assembly {
   3115 |             r.slot := slot
   3116 |         }
   3117 |     }
```

---

### 114. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3124 行
- **函数**: `getBooleanSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3121 |      */
   3122 |     function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
   3123 |         /// @solidity memory-safe-assembly
>> 3124 |         assembly {
   3125 |             r.slot := slot
   3126 |         }
   3127 |     }
```

---

### 115. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3134 行
- **函数**: `getBytes32Slot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3131 |      */
   3132 |     function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
   3133 |         /// @solidity memory-safe-assembly
>> 3134 |         assembly {
   3135 |             r.slot := slot
   3136 |         }
   3137 |     }
```

---

### 116. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3144 行
- **函数**: `getUint256Slot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3141 |      */
   3142 |     function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
   3143 |         /// @solidity memory-safe-assembly
>> 3144 |         assembly {
   3145 |             r.slot := slot
   3146 |         }
   3147 |     }
```

---

### 117. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3154 行
- **函数**: `getStringSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3151 |      */
   3152 |     function getStringSlot(bytes32 slot) internal pure returns (StringSlot storage r) {
   3153 |         /// @solidity memory-safe-assembly
>> 3154 |         assembly {
   3155 |             r.slot := slot
   3156 |         }
   3157 |     }
```

---

### 118. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3164 行
- **函数**: `getStringSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3161 |      */
   3162 |     function getStringSlot(string storage store) internal pure returns (StringSlot storage r) {
   3163 |         /// @solidity memory-safe-assembly
>> 3164 |         assembly {
   3165 |             r.slot := store.slot
   3166 |         }
   3167 |     }
```

---

### 119. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3174 行
- **函数**: `getBytesSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3171 |      */
   3172 |     function getBytesSlot(bytes32 slot) internal pure returns (BytesSlot storage r) {
   3173 |         /// @solidity memory-safe-assembly
>> 3174 |         assembly {
   3175 |             r.slot := slot
   3176 |         }
   3177 |     }
```

---

### 120. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3184 行
- **函数**: `getBytesSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3181 |      */
   3182 |     function getBytesSlot(bytes storage store) internal pure returns (BytesSlot storage r) {
   3183 |         /// @solidity memory-safe-assembly
>> 3184 |         assembly {
   3185 |             r.slot := store.slot
   3186 |         }
   3187 |     }
```

---

### 121. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3217 行
- **函数**: `toString()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3214 |             string memory buffer = new string(length);
   3215 |             uint256 ptr;
   3216 |             /// @solidity memory-safe-assembly
>> 3217 |             assembly {
   3218 |                 ptr := add(buffer, add(32, length))
   3219 |             }
   3220 |             while (true) {
```

---

### 122. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x385C279445581a186a4182a5503094eBb652EC71` 第 3223 行
- **函数**: `toString()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3220 |             while (true) {
   3221 |                 ptr--;
   3222 |                 /// @solidity memory-safe-assembly
>> 3223 |                 assembly {
   3224 |                     mstore8(ptr, byte(mod(value, 10), _SYMBOLS))
   3225 |                 }
   3226 |                 value /= 10;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*