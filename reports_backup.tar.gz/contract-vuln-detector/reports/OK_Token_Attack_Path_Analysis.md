# OK Token 攻擊路徑分析報告

> 生成時間: 2026-07-02
> 分析工具: contract-vuln-detector (Slither + Pattern Scanner)
> 風險等級: **CRITICAL**

---

## 合約基本資訊

| 項目 | 值 |
|------|-----|
| 合約名稱 | OK |
| 地址 | `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` |
| 鏈別 | BSC (Chain ID: 56) |
| 編譯器 | v0.8.31+commit.fd3a2265 |
| 總發現數 | 92 |
| HIGH 數量 | 8 (7 個 Slither 確認) |
| MEDIUM 數量 | 45 |
| LOW 數量 | 39 |

---

## 漏洞總覽

### 嚴重 (HIGH) - Slither 確認

| # | 漏洞類型 | 函數 | 行號 | 置信度 |
|---|---------|------|------|--------|
| 1 | Reentrancy | `_transfer()` | 459 | 0.7 |
| 2 | Reentrancy | `_transfer()` | 459 | 0.7 |
| 3 | Reentrancy | `_processLiquidityAndBuy()` | 1010 | 0.7 |
| 4 | Reentrancy | `_sell()` | 657 | 0.7 |
| 5 | Reentrancy | `transferFrom()` | 442 | 0.7 |
| 6 | Reentrancy | `_transfer()` | 459 | 0.7 |
| 7 | Arbitrary Send ETH | `_executeSwapAndBurn()` | 793 | 0.7 |
| 8 | tx.origin Auth | `_enforceBlockAndCooldown()` | 614 | 0.85 |

### 中危 (MEDIUM) - 關鍵項

| 漏洞類型 | 出現次數 | 相關函數 |
|---------|---------|---------|
| predictable-random | 7 | `_checkDailyLimit`, `_claim`, `processDailyLogic`, `_calculatePanicFee` |
| reentrancy-risk (pattern) | 8 | `withdrawBNB`, `_executeSwapAndBurn`, `deposit`, `_distributeReferral`, `processDailyLogic` |
| uniswap-reserve-oracle | 4 | `getReserves`, `_isAddLiquidity`, `_getOkSpotPriceUSDT` |
| missing-access-control | 25 | `withdrawToken`, `withdrawBNB`, `deposit` 等 |

---

## 攻擊路徑分析

### 攻擊路徑 1: 重入攻擊 - Token Transfer (最嚴重)

**風險等級: CRITICAL**
**可利用性: 高**
**潛在影響: 資金竊取 / Balance 操縱**

#### 漏洞描述

`_transfer()` 函數 (line 459-569) 在執行 PancakeSwap swap 和 ETH 轉帳等**外部調用之後**，才更新 `_balances` 狀態變量。這違反了 Checks-Effects-Interactions 模式。

#### 攻擊流程

```
攻擊者                     OK Token Contract              PancakeSwap Router
   |                              |                              |
   |-- transfer(attacker, X) --->|                              |
   |                              |-- _transfer() 開始          |
   |                              |                              |
   |                              |-- processDailyLogic() ------>|
   |                              |   (外部調用: pair.sync())    |
   |                              |                              |
   |                              |-- _swapAndLiquify() -------->|
   |                              |   (外部調用: router.swap)    |
   |                              |   (外部調用: addLiquidityETH)|
   |                              |   (外部調用: communityFund   |
   |                              |    .call{value: balance}())  |
   |                              |                              |
   |<=========== 此時 _balances 尚未更新! ============|          |
   |                              |                              |
   |  [重入窗口 - 攻擊者合約可在此時回調]                         |
   |                              |                              |
   |-- transfer(attacker2, Y) -->|  (重入! 用舊 balance 計算)   |
   |                              |   _balances 仍是 transfer    |
   |                              |   前的值，可重複提取          |
   |                              |                              |
   |                              |-- _balances 最終更新         |
   |                              |   (但已被多次扣款)            |
```

#### 觸發條件

1. Token transfer 觸發 `_swapAndLiquify()` (當交易涉及 swap 邏輯時)
2. `_swapAndLiquify` 內部呼叫 router.swap / addLiquidityETH / communityFund.call
3. 這些外部調用返回後，`_balances` 才在 line 836-837 更新
4. `inSwap` 鎖 (line 256) 在多個位置被設為 false (line 1497, 1504, 1562)，存在繞過可能

#### 關鍵代碼

```solidity
// line 459-569: _transfer()
function _transfer(address sender, address recipient, uint256 amount) internal {
    // ... 前置邏輯 ...
    
    processDailyLogic();           // 外部調用 (line 488)
    _claim(sender);                // 可能觸發更多外部調用 (line 497)
    
    if (shouldSwap) {
        _swapAndLiquify(panicFee); // 外部調用: swap + liquidity (line 562)
        _basicTransfer(sender, address(this), amount); // balance 更新在此!
    }
    
    _basicTransfer(sender, recipient, amount); // line 568: balance 最終更新
}

// line 836-837: _basicTransfer() 中的 balance 更新
_balances[sender] -= amount;    // 狀態更新在外部調用之後!
_balances[recipient] += amount;
```

#### PoC 概念驗證

```solidity
contract Attacker {
    OK token;
    uint256 public callCount;
    
    function attack() external payable {
        callCount = 0;
        // 1. 買入 OK token
        // 2. 觸發 transfer 使 _swapAndLiquify 被調用
        token.transfer(address(token), 1000 * 1e18);
    }
    
    receive() external payable {
        if (callCount < 3) {
            callCount++;
            // 重入: 在 _balances 更新前再次調用
            token.transfer(address(token), 1000 * 1e18);
        }
    }
}
```

---

### 攻擊路徑 2: 跨函數重入 (Cross-Function Reentrancy)

**風險等級: HIGH**
**可利用性: 中高**
**潛在影響: Balance 操縱 / 雙重提取**

#### 漏洞描述

`_balances` 和 `inSwap` 狀態變量在多個函數間共享，且多個函數都存在外部調用後才更新狀態的問題。攻擊者可以利用函數間的重入進行跨函數攻擊。

#### 受影響的函數鏈

```
_transfer() ──> _swapAndLiquify() ──> _balances 更新
     │
     ├──> _sell() ──> _executeSwapAndBurn() ──> _balances 更新
     │         │
     │         └──> _swapAndLiquify() ──> _balances 更新
     │
     ├──> _claim() ──> _payoutWithCap() ──> _balances 更新
     │
     └──> _processLiquidityAndBuy() ──> router.swap ──> _balances 更新
```

#### 攻擊場景

1. 攻擊者觸發 `_sell()` → 進入 `_executeSwapAndBurn()`
2. `_executeSwapAndBurn` 發送 ETH 給 user: `user.call{value: bnbReceived}()` (line 814)
3. 攻擊者合約的 `receive()` 被調用
4. 在 `receive()` 中重入 `_claim()` 或 `transferFrom()`
5. 此時 `_balances` 仍是 `_sell` 執行前的值
6. 可以用舊的 balance 進行 claim 或 transfer

---

### 攻擊路徑 3: 任意 ETH 發送 (Arbitrary Send ETH)

**風險等級: HIGH**
**可利用性: 中**
**潛在影響: 資金重定向**

#### 漏洞描述

`_executeSwapAndBurn()` (line 793-828) 將 ETH 發送到可變地址:

```solidity
// line 814
(success,None) = user.call{value: bnbReceived}();
```

`user` 參數來自函數輸入，如果攻擊者能控制 `user` 地址，可以將合約中的 ETH 重定向到自己。

#### 攻擊條件

1. 需要能觸發 `_executeSwapAndBurn()` 並控制 `user` 參數
2. `_executeSwapAndBurn` 在 `_sell()` 中被調用 (line 710)
3. `user` 來自 `_sell()` 的第一個參數
4. 如果 `_sell` 的調用鏈允許攻擊者指定接收者，則可竊取 ETH

---

### 攻擊路徑 4: tx.origin 釣魚攻擊

**風險等級: MEDIUM**
**可利用性: 低-中**
**潛在影響: 繞過 anti-bot 機制**

#### 漏洞描述

```solidity
// line 614
address origin = tx.origin;
if (
    origin != address(0) &&
    origin != address(this) &&
    // ... 使用 tx.origin 做判斷
```

合約使用 `tx.origin` 進行交易限制判斷（anti-bot），而非 `msg.sender`。

#### 攻擊方式

1. **釣魚攻擊**: 誘騙合約 owner 調用惡意合約，惡意合約再以 `tx.origin` (owner 的地址) 調用 OK Token
2. **Anti-bot 繞過**: 透過中間合約調用，`tx.origin` 和 `msg.sender` 不同，可能繞過同區塊交易限制:
   ```solidity
   // line 1844 (BcoinToken 同模式)
   require(lastTradeBlock[tx.origin] != block.number, "o");
   ```

---

### 攻擊路徑 5: 價格操縱 (Oracle Manipulation)

**風險等級: MEDIUM**
**可利用性: 中**
**潛在影響: 價格餵價不準 / 套利**

#### 漏洞描述

合約直接使用 `getReserves()` 作為價格源 (4 處):
- line 76: `getReserves()` interface
- line 636: `_isAddLiquidity()` 
- line 648: `_isRemoveLiquidity()`
- line 1431: `_getOkSpotPriceUSDT()`

#### 攻擊方式

1. 使用閃電貸大量買入/賣出，操縱 PancakeSwap 儲備量
2. 合約使用被操縱的價格計算交易金額
3. 在價格被操縱的狀態下進行交易獲利
4. 歸還閃電貸，鎖定利潤

---

### 攻擊路徑 6: 可預測隨機數

**風險等級: MEDIUM**
**可利用性: 高 (在特定場景)**
**潛在影響: 操縱每日限額 / 利率 / 恐慌費**

#### 漏洞描述

7 個函數使用區塊屬性生成隨機數:

```
_checkDailyLimit()      - line 721  (每日交易限額)
_checkDailySellUsdtLimit() - line 737 (每日賣出 USDT 限額)
getDailyRate()          - line 1108 (每日利率)
_claim()                - line 1137 (申領獎勵)
processDailyLogic()     - line 1359 (每日邏輯)
_calculatePanicFee()    - line 1447 (恐慌賣出費用)
getSellLimitRate()      - line 1477 (賣出限制比率)
```

#### 攻擊方式

礦工/驗證者可以預測或操縱 `blockhash`、`block.timestamp` 等值，從而:
1. 預測 `_calculatePanicFee()` 的結果，選擇最佳賣出時機
2. 操縱 `getDailyRate()` 獲取更高利率
3. 繞過 `_checkDailyLimit()` 的限制

---

## 綜合攻擊策略

### 最優攻擊路徑 (推薦)

```
Step 1: 部署攻擊者合約
         ↓
Step 2: 買入 OK Token (正常交易)
         ↓
Step 3: 觸發 transfer → _transfer() → _swapAndLiquify()
         ↓
Step 4: 在 _swapAndLiquify 的外部調用中重入
         ↓
Step 5: 利用舊 _balances 進行多次 transfer/claim
         ↓
Step 6: 提取超額 ETH/Token
```

### 前置條件

- 需要一定數量的 OK Token 觸發 swap 邏輯
- 需要理解 `_swapAndLiquify` 的觸發條件
- 需要計算 gas 以確保重入在 call depth 限制內

### 預期收益

- 透過重入可重複提取，理論上可提取合約中大量 ETH
- `_executeSwapAndBurn` 中的 `user.call{value: bnbReceived}()` 直接發送 ETH
- `processDailyLogic()` 中的 `communityFund.call{value: balance}()` 也可被利用

---

## 修復建議

### 緊急修復

1. **重入保護**: 在所有外部調用前更新狀態變量，或添加 `nonReentrant` modifier
   ```solidity
   modifier nonReentrant() {
       require(!inSwap, "Reentrant call");
       inSwap = true;
       _;
       inSwap = false;
   }
   ```

2. **CEI 模式**: 嚴格遵循 Checks-Effects-Interactions 模式
   ```solidity
   // 先更新 balance
   _balances[sender] -= amount;
   _balances[recipient] += amount;
   // 再執行外部調用
   _swapAndLiquify(fee);
   ```

3. **移除 tx.origin**: 改用 `msg.sender`
   ```solidity
   address origin = msg.sender; // 不是 tx.origin
   ```

### 中期修復

4. **價格預言機**: 使用 TWAP 或 Chainlink 替代 `getReserves()`
5. **隨機數**: 使用 Chainlink VRF 替代區塊屬性隨機數
6. **訪問控制**: 為 `withdrawToken`、`withdrawBNB` 等敏感函數添加權限控制

---

## 結論

OK Token 合約存在**多個嚴重的重入漏洞**，已被 Slither 靜態分析工具確認。最關鍵的問題是 `_transfer()` 函數在外部調用（PancakeSwap swap、ETH 轉帳）之後才更新 `_balances`，攻擊者可利用此漏洞進行重入攻擊，在 balance 更新前重複提取資金。

**建議立即停止與該合約交互，直到漏洞修復。**

---

*報告由 contract-vuln-detector 自動生成*
*Slither 分析 + Pattern Scanner + 攻擊路徑推演*
