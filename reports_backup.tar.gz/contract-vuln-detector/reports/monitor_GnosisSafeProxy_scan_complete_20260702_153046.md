# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:30:46
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B` |
| contract_name | `GnosisSafeProxy` |
| compiler_version | `v0.7.6+commit.7338295f` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `GNU LGPLv3` |
| proxy | `True` |
| implementation | `0x3e5c63644e683549055b9be8653de26e0b4cd36e` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655011` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 3 |
| 🟢 LOW | 3 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B` 第 36 行
- **函数**: `masterCopy()`
- **合约**: `allows`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
     33 |                 return(0, 0x20)
     34 |             }
     35 |             calldatacopy(0, 0, calldatasize())
>>   36 |             let success := delegatecall(gas(), _singleton, 0, calldatasize(), 0, 0)
     37 |             returndatacopy(0, 0, returndatasize())
     38 |             if eq(success, 0) {
     39 |                 revert(0, returndatasize())
```

---

### 2. 🟡 [MEDIUM] locked-ether

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_yy52igeh/0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B.sol` 第 13 行
- **合约**: `GnosisSafeProxy`
- **扫描工具**: slither
- **综合评分**: 0.560

**工具描述**: Contract locking ether found:
	Contract GnosisSafeProxy (../../../tmp/slither_scan_yy52igeh/0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B.sol#13-45) has payable functions:
	 - GnosisSafeProxy.fallback() (../../../tmp/slither_scan_yy52igeh/0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B.sol#26-43)
	But does not have a function to withdraw the ether

**代码片段**:
```solidity
     10 | /// @title GnosisSafeProxy - Generic proxy contract allows to execute all transactions applying the code of a master contract.
     11 | /// @author Stefan George - <stefan@gnosis.io>
     12 | /// @author Richard Meissner - <richard@gnosis.io>
>>   13 | contract GnosisSafeProxy {
     14 |     // singleton always needs to be first declared variable, to ensure that it is at the same location in the contracts to which calls are delegated.
     15 |     // To reduce deployment costs this variable is internal and needs to be retrieved via `getStorageAt`
     16 |     address internal singleton;
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B` 第 7 行
- **函数**: `masterCopy()`
- **合约**: `allows`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      4 | /// @title IProxy - Helper interface to access masterCopy of the Proxy on-chain
      5 | /// @author Richard Meissner - <richard@gnosis.io>
      6 | interface IProxy {
>>    7 |     function masterCopy() external view returns (address);
      8 | }
      9 | 
     10 | /// @title GnosisSafeProxy - Generic proxy contract allows to execute all transactions applying the code of a master contract.
```

---

### 4. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B` 第 10 行
- **合约**: `allows`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      5 | /// @author Richard Meissner - <richard@gnosis.io>
      6 | interface IProxy {
      7 |     function masterCopy() external view returns (address);
      8 | }
      9 | 
>>   10 | /// @title GnosisSafeProxy - Generic proxy contract allows to execute all transactions applying the code of a master contract.
     11 | /// @author Stefan George - <stefan@gnosis.io>
     12 | /// @author Richard Meissner - <richard@gnosis.io>
     13 | contract GnosisSafeProxy {
     14 |     // singleton always needs to be first declared variable, to ensure that it is at the same location in the contracts to which calls are delegated.
     15 |     // To reduce deployment costs this variable is internal and needs to be retrieved via `getStorageAt`
```

---

### 5. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B` 第 29 行
- **函数**: `masterCopy()`
- **合约**: `allows`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     26 |     fallback() external payable {
     27 |         // solhint-disable-next-line no-inline-assembly
     28 |         assembly {
>>   29 |             let _singleton := and(sload(0), 0xffffffffffffffffffffffffffffffffffffffff)
     30 |             // 0xa619486e == keccak("masterCopy()"). The value is right padded to 32-bytes with 0s
     31 |             if eq(calldataload(0), 0xa619486e00000000000000000000000000000000000000000000000000000000) {
     32 |                 mstore(0, _singleton)
```

---

### 6. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B` 第 31 行
- **函数**: `masterCopy()`
- **合约**: `allows`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     28 |         assembly {
     29 |             let _singleton := and(sload(0), 0xffffffffffffffffffffffffffffffffffffffff)
     30 |             // 0xa619486e == keccak("masterCopy()"). The value is right padded to 32-bytes with 0s
>>   31 |             if eq(calldataload(0), 0xa619486e00000000000000000000000000000000000000000000000000000000) {
     32 |                 mstore(0, _singleton)
     33 |                 return(0, 0x20)
     34 |             }
```

---

### 7. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6B37677ceB05cA05F29433cBc2f3359080Fe3C7B` 第 28 行
- **函数**: `masterCopy()`
- **合约**: `allows`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     25 |     /// @dev Fallback function forwards all transactions and returns all received return data.
     26 |     fallback() external payable {
     27 |         // solhint-disable-next-line no-inline-assembly
>>   28 |         assembly {
     29 |             let _singleton := and(sload(0), 0xffffffffffffffffffffffffffffffffffffffff)
     30 |             // 0xa619486e == keccak("masterCopy()"). The value is right padded to 32-bytes with 0s
     31 |             if eq(calldataload(0), 0xa619486e00000000000000000000000000000000000000000000000000000000) {
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*