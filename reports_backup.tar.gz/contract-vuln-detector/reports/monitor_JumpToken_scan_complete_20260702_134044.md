# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:40:44
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` |
| contract_name | `JumpToken` |
| compiler_version | `v0.8.9+commit.e5eed63a` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['/contracts/JumpToken.sol', '/contracts/lib/Context.sol', '/contracts/lib/Address.sol', '/contracts/BEP20/IBEP20.sol', '/contracts/BEP20/BEP20Burnable.sol', '/contracts/BEP20/BEP20.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646139` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 26 |
| 🟢 LOW | 3 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 104 行
- **函数**: `sendValue()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    101 |         require(address(this).balance >= amount, 'Address: insufficient balance');
    102 | 
    103 |         // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
>>  104 |         (bool success, ) = recipient.call{value: amount}('');
    105 |         require(success, 'Address: unable to send value, recipient may have reverted');
    106 |     }
    107 | 
```

---

### 2. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 188 行
- **函数**: `_functionCallWithValue()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    185 |         require(isContract(target), 'Address: call to non-contract');
    186 | 
    187 |         // solhint-disable-next-line avoid-low-level-calls
>>  188 |         (bool success, bytes memory returndata) = target.call{value: weiValue}(data);
    189 |         if (success) {
    190 |             return returndata;
    191 |         } else {
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 219 行
- **函数**: `totalSupply()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    216 |     /**
    217 |      * @dev Returns the amount of tokens in existence.
    218 |      */
>>  219 |     function totalSupply() external view returns (uint256);
    220 | 
    221 |     /**
    222 |      * @dev Returns the token decimals.
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 224 行
- **函数**: `decimals()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    221 |     /**
    222 |      * @dev Returns the token decimals.
    223 |      */
>>  224 |     function decimals() external view returns (uint8);
    225 | 
    226 |     /**
    227 |      * @dev Returns the token symbol.
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 229 行
- **函数**: `symbol()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    226 |     /**
    227 |      * @dev Returns the token symbol.
    228 |      */
>>  229 |     function symbol() external view returns (string memory);
    230 | 
    231 |     /**
    232 |      * @dev Returns the token name.
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 234 行
- **函数**: `name()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    231 |     /**
    232 |      * @dev Returns the token name.
    233 |      */
>>  234 |     function name() external view returns (string memory);
    235 | 
    236 |     /**
    237 |      * @dev Returns the bep token owner.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 239 行
- **函数**: `getOwner()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    236 |     /**
    237 |      * @dev Returns the bep token owner.
    238 |      */
>>  239 |     function getOwner() external view returns (address);
    240 | 
    241 |     /**
    242 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 244 行
- **函数**: `balanceOf()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    241 |     /**
    242 |      * @dev Returns the amount of tokens owned by `account`.
    243 |      */
>>  244 |     function balanceOf(address account) external view returns (uint256);
    245 | 
    246 |     /**
    247 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 253 行
- **函数**: `transfer()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    250 |      *
    251 |      * Emits a {Transfer} event.
    252 |      */
>>  253 |     function transfer(address recipient, uint256 amount) external returns (bool);
    254 | 
    255 |     /**
    256 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 262 行
- **函数**: `allowance()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    259 |      *
    260 |      * This value changes when {approve} or {transferFrom} are called.
    261 |      */
>>  262 |     function allowance(address _owner, address spender) external view returns (uint256);
    263 | 
    264 |     /**
    265 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 278 行
- **函数**: `approve()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    275 |      *
    276 |      * Emits an {Approval} event.
    277 |      */
>>  278 |     function approve(address spender, uint256 amount) external returns (bool);
    279 | 
    280 |     /**
    281 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 331 行
- **函数**: `burn()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    328 |      *
    329 |      * See {BEP20-_burn}.
    330 |      */
>>  331 |     function burn(uint256 amount) public virtual {
    332 |         _burn(_msgSender(), amount);
    333 |     }
    334 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 346 行
- **函数**: `burnFrom()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    343 |      * - the caller must have allowance for ``accounts``'s tokens of at least
    344 |      * `amount`.
    345 |      */
>>  346 |     function burnFrom(address account, uint256 amount) public virtual {
    347 |         uint256 currentAllowance = allowance(account, _msgSender());
    348 |         require(currentAllowance >= amount, "BEP20: burn amount exceeds allowance");
    349 |     unchecked {
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 421 行
- **函数**: `getOwner()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    418 |     /**
    419 |      * @dev Returns the bep token owner.
    420 |      */
>>  421 |     function getOwner() external override view returns (address) {
    422 |         return address(0);
    423 |     }
    424 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 428 行
- **函数**: `name()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    425 |     /**
    426 |      * @dev Returns the token name.
    427 |      */
>>  428 |     function name() public override view returns (string memory) {
    429 |         return _name;
    430 |     }
    431 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 435 行
- **函数**: `decimals()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    432 |     /**
    433 |      * @dev Returns the token decimals.
    434 |      */
>>  435 |     function decimals() public override view returns (uint8) {
    436 |         return _decimals;
    437 |     }
    438 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 442 行
- **函数**: `symbol()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    439 |     /**
    440 |      * @dev Returns the token symbol.
    441 |      */
>>  442 |     function symbol() public override view returns (string memory) {
    443 |         return _symbol;
    444 |     }
    445 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 449 行
- **函数**: `totalSupply()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    446 |     /**
    447 |      * @dev See {BEP20-totalSupply}.
    448 |      */
>>  449 |     function totalSupply() public override view returns (uint256) {
    450 |         return _totalSupply;
    451 |     }
    452 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 456 行
- **函数**: `balanceOf()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    453 |     /**
    454 |      * @dev See {BEP20-balanceOf}.
    455 |      */
>>  456 |     function balanceOf(address account) public override view returns (uint256) {
    457 |         return _balances[account];
    458 |     }
    459 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 468 行
- **函数**: `transfer()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    465 |      * - `recipient` cannot be the zero address.
    466 |      * - the caller must have a balance of at least `amount`.
    467 |      */
>>  468 |     function transfer(address recipient, uint256 amount) public override returns (bool) {
    469 |         _transfer(_msgSender(), recipient, amount);
    470 |         return true;
    471 |     }
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 476 行
- **函数**: `allowance()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    473 |     /**
    474 |      * @dev See {BEP20-allowance}.
    475 |      */
>>  476 |     function allowance(address owner, address spender) public override view returns (uint256) {
    477 |         return _allowances[owner][spender];
    478 |     }
    479 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 487 行
- **函数**: `approve()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    484 |      *
    485 |      * - `spender` cannot be the zero address.
    486 |      */
>>  487 |     function approve(address spender, uint256 amount) public override returns (bool) {
    488 |         _approve(_msgSender(), spender, amount);
    489 |         return true;
    490 |     }
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 537 行
- **函数**: `increaseAllowance()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    534 |      *
    535 |      * - `spender` cannot be the zero address.
    536 |      */
>>  537 |     function increaseAllowance(address spender, uint256 addedValue) public returns (bool) {
    538 |         _approve(_msgSender(), spender, _allowances[_msgSender()][spender] + addedValue);
    539 |         return true;
    540 |     }
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 556 行
- **函数**: `decreaseAllowance()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    553 |      * - `spender` must have allowance for the caller of at least
    554 |      * `subtractedValue`.
    555 |      */
>>  556 |     function decreaseAllowance(address spender, uint256 subtractedValue) public returns (bool) {
    557 |         uint256 currentAllowance = _allowances[_msgSender()][spender];
    558 |         require(currentAllowance >= subtractedValue, "BEP20: decreased allowance below zero");
    559 |         unchecked {
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 9 行
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      4 | 
      5 | pragma solidity 0.8.9;
      6 | 
      7 | import "./BEP20/BEP20Burnable.sol";
      8 | 
>>    9 | contract JumpToken is BEP20Burnable {
     10 |     constructor() BEP20("JumpToken", "JMPT") {
     11 |         // Mint 100M tokens to creator address
     12 |         _mint(msg.sender, 100000000 * 10 ** decimals());
     13 |     }
     14 | }
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 390 行
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    385 |  *
    386 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    387 |  * functions have been added to mitigate the well-known issues around setting
    388 |  * allowances. See {IBEP20-approve}.
    389 |  */
>>  390 | contract BEP20 is Context, IBEP20 {
    391 |     using Address for address;
    392 | 
    393 |     mapping(address => uint256) private _balances;
    394 | 
    395 |     mapping(address => mapping(address => uint256)) private _allowances;
```

---

### 27. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 76 行
- **函数**: `isContract()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
     73 |         // and 0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470 is returned
     74 |         // for accounts without code, i.e. `keccak256('')`
     75 |         bytes32 codehash;
>>   76 |         bytes32 accountHash = 0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470;
     77 |         // solhint-disable-next-line no-inline-assembly
     78 |         assembly {
     79 |             codehash := extcodehash(account)
```

---

### 28. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 78 行
- **函数**: `isContract()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
     75 |         bytes32 codehash;
     76 |         bytes32 accountHash = 0xc5d2460186f7233c927e7db2dcc703c0e500b653ca82273b7bfad8045d85a470;
     77 |         // solhint-disable-next-line no-inline-assembly
>>   78 |         assembly {
     79 |             codehash := extcodehash(account)
     80 |         }
     81 |         return (codehash != accountHash && codehash != 0x0);
```

---

### 29. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x88D7e9B65dC24Cf54f5eDEF929225FC3E1580C25` 第 197 行
- **函数**: `_functionCallWithValue()`
- **合约**: `JumpToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    194 |                 // The easiest way to bubble the revert reason is using memory via assembly
    195 | 
    196 |                 // solhint-disable-next-line no-inline-assembly
>>  197 |                 assembly {
    198 |                     let returndata_size := mload(returndata)
    199 |                     revert(add(32, returndata), returndata_size)
    200 |                 }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*