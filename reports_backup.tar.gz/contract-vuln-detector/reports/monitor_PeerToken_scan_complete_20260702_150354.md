# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:03:54
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` |
| contract_name | `PeerToken` |
| compiler_version | `v0.8.35+commit.47b9dedd` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `osaka` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/PeerToken.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/ERC20.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/extensions/ERC20Burnable.sol', 'src/BaseToken.sol', 'lib/openzeppelin-contracts/contracts/access/Ownable.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/extensions/IERC20Metadata.sol', 'lib/openzeppelin-contracts/contracts/utils/Context.sol', 'lib/openzeppelin-contracts/contracts/interfaces/draft-IERC6093.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/extensions/ERC20Permit.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/extensions/ERC20Votes.sol', 'lib/openzeppelin-contracts/contracts/utils/Nonces.sol', 'lib/openzeppelin-contracts/contracts/utils/types/Time.sol', 'lib/openzeppelin-contracts/contracts/governance/utils/Votes.sol', 'lib/openzeppelin-contracts/contracts/token/ERC20/extensions/IERC20Permit.sol', 'lib/openzeppelin-contracts/contracts/utils/cryptography/ECDSA.sol', 'lib/openzeppelin-contracts/contracts/utils/cryptography/EIP712.sol', 'lib/openzeppelin-contracts/contracts/utils/structs/Checkpoints.sol', 'lib/openzeppelin-contracts/contracts/utils/math/Math.sol', 'lib/openzeppelin-contracts/contracts/utils/math/SafeCast.sol', 'lib/openzeppelin-contracts/contracts/interfaces/IERC5805.sol', 'lib/openzeppelin-contracts/contracts/utils/cryptography/MessageHashUtils.sol', 'lib/openzeppelin-contracts/contracts/utils/ShortStrings.sol', 'lib/openzeppelin-contracts/contracts/interfaces/IERC5267.sol', 'lib/openzeppelin-contracts/contracts/governance/utils/IVotes.sol', 'lib/openzeppelin-contracts/contracts/interfaces/IERC6372.sol', 'lib/openzeppelin-contracts/contracts/utils/Strings.sol', 'lib/openzeppelin-contracts/contracts/utils/StorageSlot.sol', 'lib/openzeppelin-contracts/contracts/utils/math/SignedMath.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 55 |
| 🟢 LOW | 26 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 33 行
- **函数**: `mint()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     30 |         minter = _minter;
     31 |     }
     32 | 
>>   33 |     function mint(address _account, uint256 _amount) external onlyMinter {
     34 |         _mint(_account, _amount);
     35 |     }
     36 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 110 行
- **函数**: `name()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    107 |     /**
    108 |      * @dev Returns the name of the token.
    109 |      */
>>  110 |     function name() public view virtual returns (string memory) {
    111 |         return _name;
    112 |     }
    113 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 118 行
- **函数**: `symbol()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    115 |      * @dev Returns the symbol of the token, usually a shorter version of the
    116 |      * name.
    117 |      */
>>  118 |     function symbol() public view virtual returns (string memory) {
    119 |         return _symbol;
    120 |     }
    121 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 135 行
- **函数**: `decimals()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    132 |      * no way affects any of the arithmetic of the contract, including
    133 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    134 |      */
>>  135 |     function decimals() public view virtual returns (uint8) {
    136 |         return 18;
    137 |     }
    138 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 142 行
- **函数**: `totalSupply()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    139 |     /**
    140 |      * @dev See {IERC20-totalSupply}.
    141 |      */
>>  142 |     function totalSupply() public view virtual returns (uint256) {
    143 |         return _totalSupply;
    144 |     }
    145 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 149 行
- **函数**: `balanceOf()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    146 |     /**
    147 |      * @dev See {IERC20-balanceOf}.
    148 |      */
>>  149 |     function balanceOf(address account) public view virtual returns (uint256) {
    150 |         return _balances[account];
    151 |     }
    152 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 161 行
- **函数**: `transfer()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    158 |      * - `to` cannot be the zero address.
    159 |      * - the caller must have a balance of at least `value`.
    160 |      */
>>  161 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    162 |         address owner = _msgSender();
    163 |         _transfer(owner, to, value);
    164 |         return true;
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 170 行
- **函数**: `allowance()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    167 |     /**
    168 |      * @dev See {IERC20-allowance}.
    169 |      */
>>  170 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    171 |         return _allowances[owner][spender];
    172 |     }
    173 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 184 行
- **函数**: `approve()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    181 |      *
    182 |      * - `spender` cannot be the zero address.
    183 |      */
>>  184 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    185 |         address owner = _msgSender();
    186 |         _approve(owner, spender, value);
    187 |         return true;
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 206 行
- **函数**: `transferFrom()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    203 |      * - the caller must have allowance for ``from``'s tokens of at least
    204 |      * `value`.
    205 |      */
>>  206 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    207 |         address spender = _msgSender();
    208 |         _spendAllowance(from, spender, value);
    209 |         _transfer(from, to, value);
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 392 行
- **函数**: `burn()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    389 |      *
    390 |      * See {ERC20-_burn}.
    391 |      */
>>  392 |     function burn(uint256 value) public virtual {
    393 |         _burn(_msgSender(), value);
    394 |     }
    395 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 407 行
- **函数**: `burnFrom()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    404 |      * - the caller must have allowance for ``accounts``'s tokens of at least
    405 |      * `value`.
    406 |      */
>>  407 |     function burnFrom(address account, uint256 value) public virtual {
    408 |         _spendAllowance(account, _msgSender(), value);
    409 |         _burn(account, value);
    410 |     }
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 432 行
- **函数**: `clock()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    429 | 
    430 |     constructor(string memory _name, string memory _symbol) ERC20Permit(_name) ERC20(_name, _symbol) {}
    431 | 
>>  432 |     function clock() public view virtual override returns (uint48) {
    433 |         return Time.timestamp();
    434 |     }
    435 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 436 行
- **函数**: `CLOCK_MODE()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    433 |         return Time.timestamp();
    434 |     }
    435 | 
>>  436 |     function CLOCK_MODE() public view virtual override returns (string memory) {
    437 |         // Check that the clock was not modified
    438 |         if (clock() != Time.timestamp()) {
    439 |             revert Votes.ERC6372InconsistentClock();
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 448 行
- **函数**: `nonces()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    445 |         return MAX_SUPPLY;
    446 |     }
    447 | 
>>  448 |     function nonces(address _owner) public view override(ERC20Permit, Nonces) returns (uint256) {
    449 |         return Nonces.nonces(_owner);
    450 |     }
    451 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 515 行
- **函数**: `owner()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    512 |     /**
    513 |      * @dev Returns the address of the current owner.
    514 |      */
>>  515 |     function owner() public view virtual returns (address) {
    516 |         return _owner;
    517 |     }
    518 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 590 行
- **函数**: `totalSupply()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    587 |     /**
    588 |      * @dev Returns the value of tokens in existence.
    589 |      */
>>  590 |     function totalSupply() external view returns (uint256);
    591 | 
    592 |     /**
    593 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 595 行
- **函数**: `balanceOf()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    592 |     /**
    593 |      * @dev Returns the value of tokens owned by `account`.
    594 |      */
>>  595 |     function balanceOf(address account) external view returns (uint256);
    596 | 
    597 |     /**
    598 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 604 行
- **函数**: `transfer()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    601 |      *
    602 |      * Emits a {Transfer} event.
    603 |      */
>>  604 |     function transfer(address to, uint256 value) external returns (bool);
    605 | 
    606 |     /**
    607 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 613 行
- **函数**: `allowance()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    610 |      *
    611 |      * This value changes when {approve} or {transferFrom} are called.
    612 |      */
>>  613 |     function allowance(address owner, address spender) external view returns (uint256);
    614 | 
    615 |     /**
    616 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 630 行
- **函数**: `approve()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    627 |      *
    628 |      * Emits an {Approval} event.
    629 |      */
>>  630 |     function approve(address spender, uint256 value) external returns (bool);
    631 | 
    632 |     /**
    633 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 641 行
- **函数**: `transferFrom()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    638 |      *
    639 |      * Emits a {Transfer} event.
    640 |      */
>>  641 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    642 | }
    643 | 
    644 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 661 行
- **函数**: `name()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    658 |     /**
    659 |      * @dev Returns the name of the token.
    660 |      */
>>  661 |     function name() external view returns (string memory);
    662 | 
    663 |     /**
    664 |      * @dev Returns the symbol of the token.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 666 行
- **函数**: `symbol()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    663 |     /**
    664 |      * @dev Returns the symbol of the token.
    665 |      */
>>  666 |     function symbol() external view returns (string memory);
    667 | 
    668 |     /**
    669 |      * @dev Returns the decimals places of the token.
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 671 行
- **函数**: `decimals()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    668 |     /**
    669 |      * @dev Returns the decimals places of the token.
    670 |      */
>>  671 |     function decimals() external view returns (uint8);
    672 | }
    673 | 
    674 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 945 行
- **函数**: `nonces()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    942 |     /**
    943 |      * @inheritdoc IERC20Permit
    944 |      */
>>  945 |     function nonces(address owner) public view virtual override(IERC20Permit, Nonces) returns (uint256) {
    946 |         return super.nonces(owner);
    947 |     }
    948 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 953 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    950 |      * @inheritdoc IERC20Permit
    951 |      */
    952 |     // solhint-disable-next-line func-name-mixedcase
>>  953 |     function DOMAIN_SEPARATOR() external view virtual returns (bytes32) {
    954 |         return _domainSeparatorV4();
    955 |     }
    956 | }
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1033 行
- **函数**: `numCheckpoints()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1030 |     /**
   1031 |      * @dev Get number of checkpoints for `account`.
   1032 |      */
>> 1033 |     function numCheckpoints(address account) public view virtual returns (uint32) {
   1034 |         return _numCheckpoints(account);
   1035 |     }
   1036 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1040 行
- **函数**: `checkpoints()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1037 |     /**
   1038 |      * @dev Get the `pos`-th checkpoint for `account`.
   1039 |      */
>> 1040 |     function checkpoints(address account, uint32 pos) public view virtual returns (Checkpoints.Checkpoint208 memory) {
   1041 |         return _checkpoints(account, pos);
   1042 |     }
   1043 | }
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1066 行
- **函数**: `nonces()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1063 |     /**
   1064 |      * @dev Returns the next unused nonce for an address.
   1065 |      */
>> 1066 |     function nonces(address owner) public view virtual returns (uint256) {
   1067 |         return _nonces[owner];
   1068 |     }
   1069 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1289 行
- **函数**: `clock()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1286 |      * @dev Clock used for flagging checkpoints. Can be overridden to implement timestamp based
   1287 |      * checkpoints (and voting), in which case {CLOCK_MODE} should be overridden as well to match.
   1288 |      */
>> 1289 |     function clock() public view virtual returns (uint48) {
   1290 |         return Time.blockNumber();
   1291 |     }
   1292 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1297 行
- **函数**: `CLOCK_MODE()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1294 |      * @dev Machine-readable description of the clock as specified in EIP-6372.
   1295 |      */
   1296 |     // solhint-disable-next-line func-name-mixedcase
>> 1297 |     function CLOCK_MODE() public view virtual returns (string memory) {
   1298 |         // Check that the clock was not modified
   1299 |         if (clock() != Time.blockNumber()) {
   1300 |             revert ERC6372InconsistentClock();
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1308 行
- **函数**: `getVotes()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1305 |     /**
   1306 |      * @dev Returns the current amount of votes that `account` has.
   1307 |      */
>> 1308 |     function getVotes(address account) public view virtual returns (uint256) {
   1309 |         return _delegateCheckpoints[account].latest();
   1310 |     }
   1311 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1320 行
- **函数**: `getPastVotes()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1317 |      *
   1318 |      * - `timepoint` must be in the past. If operating using block numbers, the block must be already mined.
   1319 |      */
>> 1320 |     function getPastVotes(address account, uint256 timepoint) public view virtual returns (uint256) {
   1321 |         uint48 currentTimepoint = clock();
   1322 |         if (timepoint >= currentTimepoint) {
   1323 |             revert ERC5805FutureLookup(timepoint, currentTimepoint);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1340 行
- **函数**: `getPastTotalSupply()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1337 |      *
   1338 |      * - `timepoint` must be in the past. If operating using block numbers, the block must be already mined.
   1339 |      */
>> 1340 |     function getPastTotalSupply(uint256 timepoint) public view virtual returns (uint256) {
   1341 |         uint48 currentTimepoint = clock();
   1342 |         if (timepoint >= currentTimepoint) {
   1343 |             revert ERC5805FutureLookup(timepoint, currentTimepoint);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1358 行
- **函数**: `delegates()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1355 |     /**
   1356 |      * @dev Returns the delegate that `account` has chosen.
   1357 |      */
>> 1358 |     function delegates(address account) public view virtual returns (address) {
   1359 |         return _delegatee[account];
   1360 |     }
   1361 | 
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1365 行
- **函数**: `delegate()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1362 |     /**
   1363 |      * @dev Delegates votes from the sender to `delegatee`.
   1364 |      */
>> 1365 |     function delegate(address delegatee) public virtual {
   1366 |         address account = _msgSender();
   1367 |         _delegate(account, delegatee);
   1368 |     }
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1569 行
- **函数**: `nonces()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1566 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   1567 |      * prevents a signature from being used multiple times.
   1568 |      */
>> 1569 |     function nonces(address owner) external view returns (uint256);
   1570 | 
   1571 |     /**
   1572 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1575 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1572 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
   1573 |      */
   1574 |     // solhint-disable-next-line func-name-mixedcase
>> 1575 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1576 | }
   1577 | 
   1578 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4394 行
- **函数**: `getVotes()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4391 |     /**
   4392 |      * @dev Returns the current amount of votes that `account` has.
   4393 |      */
>> 4394 |     function getVotes(address account) external view returns (uint256);
   4395 | 
   4396 |     /**
   4397 |      * @dev Returns the amount of votes that `account` had at a specific moment in the past. If the `clock()` is
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4400 行
- **函数**: `getPastVotes()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4397 |      * @dev Returns the amount of votes that `account` had at a specific moment in the past. If the `clock()` is
   4398 |      * configured to use block numbers, this will return the value at the end of the corresponding block.
   4399 |      */
>> 4400 |     function getPastVotes(address account, uint256 timepoint) external view returns (uint256);
   4401 | 
   4402 |     /**
   4403 |      * @dev Returns the total supply of votes available at a specific moment in the past. If the `clock()` is
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4410 行
- **函数**: `getPastTotalSupply()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4407 |      * Votes that have not been delegated are still part of total supply, even though they would not participate in a
   4408 |      * vote.
   4409 |      */
>> 4410 |     function getPastTotalSupply(uint256 timepoint) external view returns (uint256);
   4411 | 
   4412 |     /**
   4413 |      * @dev Returns the delegate that `account` has chosen.
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4415 行
- **函数**: `delegates()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4412 |     /**
   4413 |      * @dev Returns the delegate that `account` has chosen.
   4414 |      */
>> 4415 |     function delegates(address account) external view returns (address);
   4416 | 
   4417 |     /**
   4418 |      * @dev Delegates votes from the sender to `delegatee`.
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4440 行
- **函数**: `clock()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4437 |     /**
   4438 |      * @dev Clock used for flagging checkpoints. Can be overridden to implement timestamp based checkpoints (and voting).
   4439 |      */
>> 4440 |     function clock() external view returns (uint48);
   4441 | 
   4442 |     /**
   4443 |      * @dev Description of the clock
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4446 行
- **函数**: `CLOCK_MODE()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4443 |      * @dev Description of the clock
   4444 |      */
   4445 |     // solhint-disable-next-line func-name-mixedcase
>> 4446 |     function CLOCK_MODE() external view returns (string memory);
   4447 | }
   4448 | 
   4449 | 
```

---

### 46. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 11 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      6 | import {ERC20} from "openzeppelin-contracts/contracts/token/ERC20/ERC20.sol";
      7 | import {ERC20Burnable} from "openzeppelin-contracts/contracts/token/ERC20/extensions/ERC20Burnable.sol";
      8 | import {BaseToken} from "src/BaseToken.sol";
      9 | import {Ownable} from "openzeppelin-contracts/contracts/access/Ownable.sol";
     10 | 
>>   11 | contract PeerToken is BaseToken, ERC20Burnable, Ownable {
     12 |     error CallerNotMinter(address caller);
     13 |     error InvalidMinterZeroAddress();
     14 | 
     15 |     event NewMinter(address newMinter);
     16 | 
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 86 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     81 |  * Additionally, an {Approval} event is emitted on calls to {transferFrom}.
     82 |  * This allows applications to reconstruct the allowance for all accounts just
     83 |  * by listening to said events. Other implementations of the EIP may not emit
     84 |  * these events, as it isn't required by the specification.
     85 |  */
>>   86 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
     87 |     mapping(address account => uint256) private _balances;
     88 | 
     89 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
     90 | 
     91 |     uint256 private _totalSupply;
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 427 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    422 | import {ERC20Votes} from "openzeppelin-contracts/contracts/token/ERC20/extensions/ERC20Votes.sol";
    423 | import {Nonces} from "openzeppelin-contracts/contracts/utils/Nonces.sol";
    424 | import {Time} from "openzeppelin-contracts/contracts/utils/types/Time.sol";
    425 | import {Votes} from "openzeppelin-contracts/contracts/governance/utils/Votes.sol";
    426 | 
>>  427 | contract BaseToken is ERC20, ERC20Permit, ERC20Votes {
    428 |     uint256 public constant MAX_SUPPLY = 10_000_000_000e18;
    429 | 
    430 |     constructor(string memory _name, string memory _symbol) ERC20Permit(_name) ERC20(_name, _symbol) {}
    431 | 
    432 |     function clock() public view virtual override returns (uint48) {
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 479 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    474 |  *
    475 |  * This module is used through inheritance. It will make available the modifier
    476 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    477 |  * the owner.
    478 |  */
>>  479 | abstract contract Ownable is Context {
    480 |     address private _owner;
    481 | 
    482 |     /**
    483 |      * @dev The caller account is not authorized to perform an operation.
    484 |      */
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 551 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    546 |         }
    547 |         _transferOwnership(newOwner);
    548 |     }
    549 | 
    550 |     /**
>>  551 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    552 |      * Internal function without access restriction.
    553 |      */
    554 |     function _transferOwnership(address newOwner) internal virtual {
    555 |         address oldOwner = _owner;
    556 |         _owner = newOwner;
```

---

### 51. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 893 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    888 |  *
    889 |  * Adds the {permit} method, which can be used to change an account's ERC20 allowance (see {IERC20-allowance}) by
    890 |  * presenting a message signed by the account. By not relying on `{IERC20-approve}`, the token holder account doesn't
    891 |  * need to send a transaction, and thus is not required to hold Ether at all.
    892 |  */
>>  893 | abstract contract ERC20Permit is ERC20, IERC20Permit, EIP712, Nonces {
    894 |     bytes32 private constant PERMIT_TYPEHASH =
    895 |         keccak256("Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)");
    896 | 
    897 |     /**
    898 |      * @dev Permit deadline has expired.
```

---

### 52. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1055 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1050 | pragma solidity ^0.8.20;
   1051 | 
   1052 | /**
   1053 |  * @dev Provides tracking nonces for addresses. Nonces will only increment.
   1054 |  */
>> 1055 | abstract contract Nonces {
   1056 |     /**
   1057 |      * @dev The nonce used for an `account` is not the expected current nonce.
   1058 |      */
   1059 |     error InvalidAccountNonce(address account, uint256 currentNonce);
   1060 | 
```

---

### 53. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1263 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1258 |  *
   1259 |  * When using this module the derived contract must implement {_getVotingUnits} (for example, make it return
   1260 |  * {ERC721-balanceOf}), and can use {_transferVotingUnits} to track a change in the distribution of those units (in the
   1261 |  * previous example, it would be included in {ERC721-_update}).
   1262 |  */
>> 1263 | abstract contract Votes is Context, EIP712, Nonces, IERC5805 {
   1264 |     using Checkpoints for Checkpoints.Trace208;
   1265 | 
   1266 |     bytes32 private constant DELEGATION_TYPEHASH =
   1267 |         keccak256("Delegation(address delegatee,uint256 nonce,uint256 expiry)");
   1268 | 
```

---

### 54. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1792 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1787 |  * separator of the implementation contract. This will cause the {_domainSeparatorV4} function to always rebuild the
   1788 |  * separator from the immutable values, which is cheaper than accessing a cached version in cold storage.
   1789 |  *
   1790 |  * @custom:oz-upgrades-unsafe-allow state-variable-immutable
   1791 |  */
>> 1792 | abstract contract EIP712 is IERC5267 {
   1793 |     using ShortStrings for *;
   1794 | 
   1795 |     bytes32 private constant TYPE_HASH =
   1796 |         keccak256("EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)");
   1797 | 
```

---

### 55. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4232 行
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4227 |  * fallback mechanism can be used for every other case.
   4228 |  *
   4229 |  * Usage example:
   4230 |  *
   4231 |  * ```solidity
>> 4232 |  * contract Named {
   4233 |  *     using ShortStrings for *;
   4234 |  *
   4235 |  *     ShortString private immutable _name;
   4236 |  *     string private _nameFallback;
   4237 |  *
```

---

### 56. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 926 行
- **函数**: `permit()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    923 |         bytes32 r,
    924 |         bytes32 s
    925 |     ) public virtual {
>>  926 |         if (block.timestamp > deadline) {
    927 |             revert ERC2612ExpiredSignature(deadline);
    928 |         }
    929 | 
```

---

### 57. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1124 行
- **函数**: `timestamp()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1121 |      * @dev Get the block timestamp as a Timepoint.
   1122 |      */
   1123 |     function timestamp() internal view returns (uint48) {
>> 1124 |         return SafeCast.toUint48(block.timestamp);
   1125 |     }
   1126 | 
   1127 |     /**
```

---

### 58. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1381 行
- **函数**: `delegateBySig()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1378 |         bytes32 r,
   1379 |         bytes32 s
   1380 |     ) public virtual {
>> 1381 |         if (block.timestamp > expiry) {
   1382 |             revert VotesExpiredSignature(expiry);
   1383 |         }
   1384 |         address signer = ECDSA.recover(
```

---

### 59. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1131 行
- **函数**: `blockNumber()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
   1128 |      * @dev Get the block number as a Timepoint.
   1129 |      */
   1130 |     function blockNumber() internal view returns (uint48) {
>> 1131 |         return SafeCast.toUint48(block.number);
   1132 |     }
   1133 | 
   1134 |     // ==================================================== Delay =====================================================
```

---

### 60. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1682 行
- **函数**: `tryRecover()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1679 |      */
   1680 |     function tryRecover(bytes32 hash, bytes32 r, bytes32 vs) internal pure returns (address, RecoverError, bytes32) {
   1681 |         unchecked {
>> 1682 |             bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
   1683 |             // We do not check for an overflow here since the shift operation results in 0 or 1.
   1684 |             uint8 v = uint8((uint256(vs) >> 255) + 27);
   1685 |             return tryRecover(hash, v, r, s);
```

---

### 61. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1717 行
- **函数**: `tryRecover()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1714 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
   1715 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
   1716 |         // these malleable signatures as well.
>> 1717 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
   1718 |             return (address(0), RecoverError.InvalidSignatureS, s);
   1719 |         }
   1720 | 
```

---

### 62. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 1644 行
- **函数**: `tryRecover()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1641 |             // ecrecover takes the signature parameters, and the only way to get them
   1642 |             // currently is to use assembly.
   1643 |             /// @solidity memory-safe-assembly
>> 1644 |             assembly {
   1645 |                 r := mload(add(signature, 0x20))
   1646 |                 s := mload(add(signature, 0x40))
   1647 |                 v := byte(0, mload(add(signature, 0x60)))
```

---

### 63. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 2132 行
- **函数**: `_unsafeAccess()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2129 |         Checkpoint224[] storage self,
   2130 |         uint256 pos
   2131 |     ) private pure returns (Checkpoint224 storage result) {
>> 2132 |         assembly {
   2133 |             mstore(0, self.slot)
   2134 |             result.slot := add(keccak256(0, 0x20), pos)
   2135 |         }
```

---

### 64. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 2326 行
- **函数**: `_unsafeAccess()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2323 |         Checkpoint208[] storage self,
   2324 |         uint256 pos
   2325 |     ) private pure returns (Checkpoint208 storage result) {
>> 2326 |         assembly {
   2327 |             mstore(0, self.slot)
   2328 |             result.slot := add(keccak256(0, 0x20), pos)
   2329 |         }
```

---

### 65. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 2520 行
- **函数**: `_unsafeAccess()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2517 |         Checkpoint160[] storage self,
   2518 |         uint256 pos
   2519 |     ) private pure returns (Checkpoint160 storage result) {
>> 2520 |         assembly {
   2521 |             mstore(0, self.slot)
   2522 |             result.slot := add(keccak256(0, 0x20), pos)
   2523 |         }
```

---

### 66. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 2659 行
- **函数**: `mulDiv()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2656 |             // variables such that product = prod1 * 2^256 + prod0.
   2657 |             uint256 prod0 = x * y; // Least significant 256 bits of the product
   2658 |             uint256 prod1; // Most significant 256 bits of the product
>> 2659 |             assembly {
   2660 |                 let mm := mulmod(x, y, not(0))
   2661 |                 prod1 := sub(sub(mm, prod0), lt(mm, prod0))
   2662 |             }
```

---

### 67. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 2683 行
- **函数**: `mulDiv()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2680 | 
   2681 |             // Make division exact by subtracting the remainder from [prod1 prod0].
   2682 |             uint256 remainder;
>> 2683 |             assembly {
   2684 |                 // Compute remainder using mulmod.
   2685 |                 remainder := mulmod(x, y, denominator)
   2686 | 
```

---

### 68. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 2696 行
- **函数**: `mulDiv()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2693 |             // Always >= 1. See https://cs.stackexchange.com/q/138556/92363.
   2694 | 
   2695 |             uint256 twos = denominator & (0 - denominator);
>> 2696 |             assembly {
   2697 |                 // Divide denominator by twos.
   2698 |                 denominator := div(denominator, twos)
   2699 | 
```

---

### 69. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4150 行
- **函数**: `toEthSignedMessageHash()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4147 |      */
   4148 |     function toEthSignedMessageHash(bytes32 messageHash) internal pure returns (bytes32 digest) {
   4149 |         /// @solidity memory-safe-assembly
>> 4150 |         assembly {
   4151 |             mstore(0x00, "\x19Ethereum Signed Message:\n32") // 32 is the bytes-length of messageHash
   4152 |             mstore(0x1c, messageHash) // 0x1c (28) is the length of the prefix
   4153 |             digest := keccak256(0x00, 0x3c) // 0x3c is the length of the prefix (0x1c) + messageHash (0x20)
```

---

### 70. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4196 行
- **函数**: `toTypedDataHash()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4193 |      */
   4194 |     function toTypedDataHash(bytes32 domainSeparator, bytes32 structHash) internal pure returns (bytes32 digest) {
   4195 |         /// @solidity memory-safe-assembly
>> 4196 |         assembly {
   4197 |             let ptr := mload(0x40)
   4198 |             mstore(ptr, hex"19_01")
   4199 |             mstore(add(ptr, 0x02), domainSeparator)
```

---

### 71. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4276 行
- **函数**: `toString()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4273 |         // using `new string(len)` would work locally but is not memory safe.
   4274 |         string memory str = new string(32);
   4275 |         /// @solidity memory-safe-assembly
>> 4276 |         assembly {
   4277 |             mstore(str, len)
   4278 |             mstore(add(str, 0x20), sstr)
   4279 |         }
```

---

### 72. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4481 行
- **函数**: `toString()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4478 |             string memory buffer = new string(length);
   4479 |             uint256 ptr;
   4480 |             /// @solidity memory-safe-assembly
>> 4481 |             assembly {
   4482 |                 ptr := add(buffer, add(32, length))
   4483 |             }
   4484 |             while (true) {
```

---

### 73. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4487 行
- **函数**: `toString()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4484 |             while (true) {
   4485 |                 ptr--;
   4486 |                 /// @solidity memory-safe-assembly
>> 4487 |                 assembly {
   4488 |                     mstore8(ptr, byte(mod(value, 10), HEX_DIGITS))
   4489 |                 }
   4490 |                 value /= 10;
```

---

### 74. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4610 行
- **函数**: `getAddressSlot()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4607 |      */
   4608 |     function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
   4609 |         /// @solidity memory-safe-assembly
>> 4610 |         assembly {
   4611 |             r.slot := slot
   4612 |         }
   4613 |     }
```

---

### 75. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4620 行
- **函数**: `getBooleanSlot()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4617 |      */
   4618 |     function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
   4619 |         /// @solidity memory-safe-assembly
>> 4620 |         assembly {
   4621 |             r.slot := slot
   4622 |         }
   4623 |     }
```

---

### 76. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4630 行
- **函数**: `getBytes32Slot()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4627 |      */
   4628 |     function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
   4629 |         /// @solidity memory-safe-assembly
>> 4630 |         assembly {
   4631 |             r.slot := slot
   4632 |         }
   4633 |     }
```

---

### 77. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4640 行
- **函数**: `getUint256Slot()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4637 |      */
   4638 |     function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
   4639 |         /// @solidity memory-safe-assembly
>> 4640 |         assembly {
   4641 |             r.slot := slot
   4642 |         }
   4643 |     }
```

---

### 78. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4650 行
- **函数**: `getStringSlot()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4647 |      */
   4648 |     function getStringSlot(bytes32 slot) internal pure returns (StringSlot storage r) {
   4649 |         /// @solidity memory-safe-assembly
>> 4650 |         assembly {
   4651 |             r.slot := slot
   4652 |         }
   4653 |     }
```

---

### 79. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4660 行
- **函数**: `getStringSlot()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4657 |      */
   4658 |     function getStringSlot(string storage store) internal pure returns (StringSlot storage r) {
   4659 |         /// @solidity memory-safe-assembly
>> 4660 |         assembly {
   4661 |             r.slot := store.slot
   4662 |         }
   4663 |     }
```

---

### 80. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4670 行
- **函数**: `getBytesSlot()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4667 |      */
   4668 |     function getBytesSlot(bytes32 slot) internal pure returns (BytesSlot storage r) {
   4669 |         /// @solidity memory-safe-assembly
>> 4670 |         assembly {
   4671 |             r.slot := slot
   4672 |         }
   4673 |     }
```

---

### 81. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd5f6ef5dEabE61E6d5CDB49BFB6f156F2c1cA715` 第 4680 行
- **函数**: `getBytesSlot()`
- **合约**: `PeerToken`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4677 |      */
   4678 |     function getBytesSlot(bytes storage store) internal pure returns (BytesSlot storage r) {
   4679 |         /// @solidity memory-safe-assembly
>> 4680 |         assembly {
   4681 |             r.slot := store.slot
   4682 |         }
   4683 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*