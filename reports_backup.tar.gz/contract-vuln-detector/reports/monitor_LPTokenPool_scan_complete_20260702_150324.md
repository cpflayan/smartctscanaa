# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:03:24
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x5001fA16F04AcdD246d41784e71370Db07262981` |
| contract_name | `LPTokenPool` |
| compiler_version | `v0.8.4+commit.c7e474f2` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/LPTokenPool.sol', '@openzeppelin/contracts/utils/math/Math.sol', '@openzeppelin/contracts/utils/math/SafeMath.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', '@openzeppelin/contracts/utils/Address.sol', '@openzeppelin/contracts-upgradeable/utils/math/SafeMathUpgradeable.sol', '@openzeppelin/contracts-upgradeable/proxy/utils/Initializable.sol', '@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol', '@openzeppelin/contracts-upgradeable/token/ERC20/utils/SafeERC20Upgradeable.sol', '@openzeppelin/contracts-upgradeable/token/ERC20/IERC20Upgradeable.sol', '@openzeppelin/contracts-upgradeable/utils/AddressUpgradeable.sol', '@openzeppelin/contracts-upgradeable/utils/ContextUpgradeable.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655006` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 34 |
| 🟢 LOW | 13 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 971 行
- **函数**: `functionDelegateCall()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    968 |     ) internal returns (bytes memory) {
    969 |         require(isContract(target), "Address: delegate call to non-contract");
    970 | 
>>  971 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    972 |         return verifyCallResult(success, returndata, errorMessage);
    973 |     }
    974 | 
```

---

### 2. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 258 行
- **函数**: `notifyRewardAmount()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    255 | 
    256 |         if (block.timestamp > starttime){
    257 |             if (block.timestamp >= periodFinish) {
>>  258 |                 uint256 period = block.timestamp.sub(starttime).div(duration).add(1);
    259 |                 periodFinish = starttime.add(period.mul(duration));
    260 |                 rewardRate = reward.div(periodFinish.sub(block.timestamp));
    261 |             } else {
```

---

### 3. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 262 行
- **函数**: `notifyRewardAmount()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    259 |                 periodFinish = starttime.add(period.mul(duration));
    260 |                 rewardRate = reward.div(periodFinish.sub(block.timestamp));
    261 |             } else {
>>  262 |                 uint256 remaining = periodFinish.sub(block.timestamp);
    263 |                 uint256 leftover = remaining.mul(rewardRate);
    264 |                 rewardRate = reward.add(leftover).div(remaining);
    265 |             }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 843 行
- **函数**: `sendValue()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    840 |     function sendValue(address payable recipient, uint256 amount) internal {
    841 |         require(address(this).balance >= amount, "Address: insufficient balance");
    842 | 
>>  843 |         (bool success, ) = recipient.call{value: amount}("");
    844 |         require(success, "Address: unable to send value, recipient may have reverted");
    845 |     }
    846 | 
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 917 行
- **函数**: `functionCallWithValue()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    914 |         require(address(this).balance >= value, "Address: insufficient balance for call");
    915 |         require(isContract(target), "Address: call to non-contract");
    916 | 
>>  917 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    918 |         return verifyCallResult(success, returndata, errorMessage);
    919 |     }
    920 | 
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1665 行
- **函数**: `sendValue()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1662 |     function sendValue(address payable recipient, uint256 amount) internal {
   1663 |         require(address(this).balance >= amount, "Address: insufficient balance");
   1664 | 
>> 1665 |         (bool success, ) = recipient.call{value: amount}("");
   1666 |         require(success, "Address: unable to send value, recipient may have reverted");
   1667 |     }
   1668 | 
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1739 行
- **函数**: `functionCallWithValue()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1736 |         require(address(this).balance >= value, "Address: insufficient balance for call");
   1737 |         require(isContract(target), "Address: call to non-contract");
   1738 | 
>> 1739 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
   1740 |         return verifyCallResult(success, returndata, errorMessage);
   1741 |     }
   1742 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 149 行
- **函数**: `totalSupply()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    146 |     }
    147 | 
    148 | 
>>  149 |     function totalSupply() public view returns (uint256) {
    150 |         return _totalSupply;
    151 |     }
    152 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 153 行
- **函数**: `balanceOf()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    150 |         return _totalSupply;
    151 |     }
    152 | 
>>  153 |     function balanceOf(address account) public view returns (uint256) {
    154 |         return _balances[account];
    155 |     }
    156 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 158 行
- **函数**: `lastTimeRewardApplicable()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    155 |     }
    156 | 
    157 | 
>>  158 |     function lastTimeRewardApplicable() public view returns (uint256) {
    159 |         return Math.min(block.timestamp, periodFinish);
    160 |     }
    161 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 162 行
- **函数**: `rewardPerToken()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    159 |         return Math.min(block.timestamp, periodFinish);
    160 |     }
    161 | 
>>  162 |     function rewardPerToken() public view returns (uint256) {
    163 |         if (totalSupply() == 0) {
    164 |             return rewardPerTokenStored;
    165 |         }
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 176 行
- **函数**: `earned()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    173 |         );
    174 |     }
    175 | 
>>  176 |     function earned(address account) public view returns (uint256) {
    177 |         return
    178 |         balanceOf(account)
    179 |         .mul(rewardPerToken().sub(userRewardPerTokenPaid[account]))
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 224 行
- **函数**: `exit()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    221 |         emit Withdrawn(msg.sender, amount);
    222 |     }
    223 | 
>>  224 |     function exit() external {
    225 |         withdraw(balanceOf(msg.sender));
    226 |         getReward();
    227 |     }
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 229 行
- **函数**: `getReward()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    226 |         getReward();
    227 |     }
    228 | 
>>  229 |     function getReward() public updateReward(msg.sender) checkStart {
    230 |         //
    231 |         uint256 reward = earned(msg.sender);
    232 |         if (reward > 0) {
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 283 行
- **函数**: `unfrozenStakeTime()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    280 |         return duration.mul(rewardRate).mul(1e18);
    281 |     }
    282 | 
>>  283 |     function unfrozenStakeTime(address account) public view returns (uint256) {
    284 |         return lastStakeTime[account] + frozenStakingTime;
    285 |     }
    286 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 302 行
- **函数**: `setFrozenStakingTime()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    299 |         description = _dataInfo.description;
    300 |     }
    301 | 
>>  302 |     function setFrozenStakingTime(uint256 frozenStakingTime_) external onlyPSIPadFactory {
    303 |         frozenStakingTime = frozenStakingTime_;
    304 |     }
    305 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 306 行
- **函数**: `setPercent()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    303 |         frozenStakingTime = frozenStakingTime_;
    304 |     }
    305 | 
>>  306 |     function setPercent(uint256 percent_) external onlyPSIPadFactory {
    307 |         percent = percent_;
    308 |     }
    309 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 310 行
- **函数**: `setLpToken()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    307 |         percent = percent_;
    308 |     }
    309 | 
>>  310 |     function setLpToken(bool isLpToken_) external onlyPSIPadFactory {
    311 |         isLpToken = isLpToken_;
    312 |     }
    313 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 609 行
- **函数**: `totalSupply()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    606 |     /**
    607 |      * @dev Returns the amount of tokens in existence.
    608 |      */
>>  609 |     function totalSupply() external view returns (uint256);
    610 | 
    611 |     /**
    612 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 614 行
- **函数**: `balanceOf()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    611 |     /**
    612 |      * @dev Returns the amount of tokens owned by `account`.
    613 |      */
>>  614 |     function balanceOf(address account) external view returns (uint256);
    615 | 
    616 |     /**
    617 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 623 行
- **函数**: `transfer()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    620 |      *
    621 |      * Emits a {Transfer} event.
    622 |      */
>>  623 |     function transfer(address recipient, uint256 amount) external returns (bool);
    624 | 
    625 |     /**
    626 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 632 行
- **函数**: `allowance()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    629 |      *
    630 |      * This value changes when {approve} or {transferFrom} are called.
    631 |      */
>>  632 |     function allowance(address owner, address spender) external view returns (uint256);
    633 | 
    634 |     /**
    635 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 648 行
- **函数**: `approve()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    645 |      *
    646 |      * Emits an {Approval} event.
    647 |      */
>>  648 |     function approve(address spender, uint256 amount) external returns (bool);
    649 | 
    650 |     /**
    651 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1361 行
- **函数**: `owner()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1358 |     /**
   1359 |      * @dev Returns the address of the current owner.
   1360 |      */
>> 1361 |     function owner() public view virtual returns (address) {
   1362 |         return _owner;
   1363 |     }
   1364 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1529 行
- **函数**: `totalSupply()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1526 |     /**
   1527 |      * @dev Returns the amount of tokens in existence.
   1528 |      */
>> 1529 |     function totalSupply() external view returns (uint256);
   1530 | 
   1531 |     /**
   1532 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1534 行
- **函数**: `balanceOf()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1531 |     /**
   1532 |      * @dev Returns the amount of tokens owned by `account`.
   1533 |      */
>> 1534 |     function balanceOf(address account) external view returns (uint256);
   1535 | 
   1536 |     /**
   1537 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1543 行
- **函数**: `transfer()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1540 |      *
   1541 |      * Emits a {Transfer} event.
   1542 |      */
>> 1543 |     function transfer(address to, uint256 amount) external returns (bool);
   1544 | 
   1545 |     /**
   1546 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1552 行
- **函数**: `allowance()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1549 |      *
   1550 |      * This value changes when {approve} or {transferFrom} are called.
   1551 |      */
>> 1552 |     function allowance(address owner, address spender) external view returns (uint256);
   1553 | 
   1554 |     /**
   1555 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1568 行
- **函数**: `approve()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1565 |      *
   1566 |      * Emits an {Approval} event.
   1567 |      */
>> 1568 |     function approve(address spender, uint256 amount) external returns (bool);
   1569 | 
   1570 |     /**
   1571 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 30. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 18 行
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     13 | import '@openzeppelin/contracts-upgradeable/access/OwnableUpgradeable.sol';
     14 | import '@openzeppelin/contracts-upgradeable/token/ERC20/utils/SafeERC20Upgradeable.sol';
     15 | import '@openzeppelin/contracts-upgradeable/token/ERC20/IERC20Upgradeable.sol';
     16 | 
     17 | 
>>   18 | contract LPTokenPool is Initializable, OwnableUpgradeable {
     19 |     using SafeMathUpgradeable for uint256;
     20 |     using SafeERC20Upgradeable for IERC20Upgradeable;
     21 | 
     22 | 
     23 |     struct PoolDataInfo{
```

---

### 31. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 694 行
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    689 | import "../../../utils/Address.sol";
    690 | 
    691 | /**
    692 |  * @title SafeERC20
    693 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>>  694 |  * contract returns false). Tokens that return no value (and instead revert or
    695 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    696 |  * successful.
    697 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    698 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    699 |  */
```

---

### 32. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1272 行
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1267 |  * /// @custom:oz-upgrades-unsafe-allow constructor
   1268 |  * constructor() initializer {}
   1269 |  * ```
   1270 |  * ====
   1271 |  */
>> 1272 | abstract contract Initializable {
   1273 |     /**
   1274 |      * @dev Indicates that the contract has been initialized.
   1275 |      */
   1276 |     bool private _initialized;
   1277 | 
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1342 行
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1337 |  *
   1338 |  * This module is used through inheritance. It will make available the modifier
   1339 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
   1340 |  * the owner.
   1341 |  */
>> 1342 | abstract contract OwnableUpgradeable is Initializable, ContextUpgradeable {
   1343 |     address private _owner;
   1344 | 
   1345 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
   1346 | 
   1347 |     /**
```

---

### 34. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1394 行
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1389 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
   1390 |         _transferOwnership(newOwner);
   1391 |     }
   1392 | 
   1393 |     /**
>> 1394 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
   1395 |      * Internal function without access restriction.
   1396 |      */
   1397 |     function _transferOwnership(address newOwner) internal virtual {
   1398 |         address oldOwner = _owner;
   1399 |         _owner = newOwner;
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1425 行
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1420 | import "../../../utils/AddressUpgradeable.sol";
   1421 | 
   1422 | /**
   1423 |  * @title SafeERC20
   1424 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>> 1425 |  * contract returns false). Tokens that return no value (and instead revert or
   1426 |  * throw on failure) are also supported, non-reverting calls are assumed to be
   1427 |  * successful.
   1428 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
   1429 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
   1430 |  */
```

---

### 36. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 85 行
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     82 |     event DevFundRewardPaid(address indexed user, uint256 reward);
     83 | 
     84 |     modifier checkStart() {
>>   85 |         require(block.timestamp >= starttime, 'LPTokenPool: not start');
     86 |         _;
     87 |     }
     88 | 
```

---

### 37. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 159 行
- **函数**: `lastTimeRewardApplicable()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    156 | 
    157 | 
    158 |     function lastTimeRewardApplicable() public view returns (uint256) {
>>  159 |         return Math.min(block.timestamp, periodFinish);
    160 |     }
    161 | 
    162 |     function rewardPerToken() public view returns (uint256) {
```

---

### 38. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 203 行
- **函数**: `stake()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    200 |         _totalSupply = _totalSupply.add(amount);
    201 |         _balances[msg.sender] = _balances[msg.sender].add(amount);
    202 |         IERC20Upgradeable(lpt).safeTransferFrom(msg.sender, address(this), amount);
>>  203 |         lastStakeTime[msg.sender] = block.timestamp;
    204 |         emit Staked(msg.sender, amount);
    205 |     }
    206 | 
```

---

### 39. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 215 行
- **函数**: `withdraw()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    212 | 
    213 |         require(amount > 0, 'LPTokenPool: Cannot withdraw 0');
    214 | 
>>  215 |         require(block.timestamp >= unfrozenStakeTime(msg.sender), "LPTokenPool: Cannot withdrawal during freezing");
    216 | 
    217 |         deposits[msg.sender] = deposits[msg.sender].sub(amount);
    218 |         _totalSupply = _totalSupply.sub(amount);
```

---

### 40. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 256 行
- **函数**: `notifyRewardAmount()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    253 |     updateReward(address(0))
    254 |     {
    255 | 
>>  256 |         if (block.timestamp > starttime){
    257 |             if (block.timestamp >= periodFinish) {
    258 |                 uint256 period = block.timestamp.sub(starttime).div(duration).add(1);
    259 |                 periodFinish = starttime.add(period.mul(duration));
```

---

### 41. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 257 行
- **函数**: `notifyRewardAmount()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    254 |     {
    255 | 
    256 |         if (block.timestamp > starttime){
>>  257 |             if (block.timestamp >= periodFinish) {
    258 |                 uint256 period = block.timestamp.sub(starttime).div(duration).add(1);
    259 |                 periodFinish = starttime.add(period.mul(duration));
    260 |                 rewardRate = reward.div(periodFinish.sub(block.timestamp));
```

---

### 42. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 258 行
- **函数**: `notifyRewardAmount()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    255 | 
    256 |         if (block.timestamp > starttime){
    257 |             if (block.timestamp >= periodFinish) {
>>  258 |                 uint256 period = block.timestamp.sub(starttime).div(duration).add(1);
    259 |                 periodFinish = starttime.add(period.mul(duration));
    260 |                 rewardRate = reward.div(periodFinish.sub(block.timestamp));
    261 |             } else {
```

---

### 43. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 260 行
- **函数**: `notifyRewardAmount()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    257 |             if (block.timestamp >= periodFinish) {
    258 |                 uint256 period = block.timestamp.sub(starttime).div(duration).add(1);
    259 |                 periodFinish = starttime.add(period.mul(duration));
>>  260 |                 rewardRate = reward.div(periodFinish.sub(block.timestamp));
    261 |             } else {
    262 |                 uint256 remaining = periodFinish.sub(block.timestamp);
    263 |                 uint256 leftover = remaining.mul(rewardRate);
```

---

### 44. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 262 行
- **函数**: `notifyRewardAmount()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    259 |                 periodFinish = starttime.add(period.mul(duration));
    260 |                 rewardRate = reward.div(periodFinish.sub(block.timestamp));
    261 |             } else {
>>  262 |                 uint256 remaining = periodFinish.sub(block.timestamp);
    263 |                 uint256 leftover = remaining.mul(rewardRate);
    264 |                 rewardRate = reward.add(leftover).div(remaining);
    265 |             }
```

---

### 45. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 266 行
- **函数**: `notifyRewardAmount()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    263 |                 uint256 leftover = remaining.mul(rewardRate);
    264 |                 rewardRate = reward.add(leftover).div(remaining);
    265 |             }
>>  266 |             lastUpdateTime = block.timestamp;
    267 |             emit RewardAdded(reward);
    268 |         }else {
    269 |             rewardRate = reward.div(duration);
```

---

### 46. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 818 行
- **函数**: `isContract()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    815 |         // constructor execution.
    816 | 
    817 |         uint256 size;
>>  818 |         assembly {
    819 |             size := extcodesize(account)
    820 |         }
    821 |         return size > 0;
```

---

### 47. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 993 行
- **函数**: `verifyCallResult()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    990 |             if (returndata.length > 0) {
    991 |                 // The easiest way to bubble the revert reason is using memory via assembly
    992 | 
>>  993 |                 assembly {
    994 |                     let returndata_size := mload(returndata)
    995 |                     revert(add(32, returndata), returndata_size)
    996 |                 }
```

---

### 48. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x5001fA16F04AcdD246d41784e71370Db07262981` 第 1788 行
- **函数**: `verifyCallResult()`
- **合约**: `LPTokenPool`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1785 |             if (returndata.length > 0) {
   1786 |                 // The easiest way to bubble the revert reason is using memory via assembly
   1787 | 
>> 1788 |                 assembly {
   1789 |                     let returndata_size := mload(returndata)
   1790 |                     revert(add(32, returndata), returndata_size)
   1791 |                 }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*