# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:51:16
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x0000000071727De22E5E9d8BAf0edAc6f37da032` |
| contract_name | `EntryPoint` |
| compiler_version | `v0.8.23+commit.f704f362` |
| optimization_used | `True` |
| runs | `1000000` |
| evm_version | `paris` |
| license_type | `GNU GPLv3` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/utils/introspection/ERC165.sol', '@openzeppelin/contracts/utils/introspection/IERC165.sol', '@openzeppelin/contracts/utils/ReentrancyGuard.sol', 'contracts/core/EntryPoint.sol', 'contracts/core/Helpers.sol', 'contracts/core/NonceManager.sol', 'contracts/core/SenderCreator.sol', 'contracts/core/StakeManager.sol', 'contracts/core/UserOperationLib.sol', 'contracts/interfaces/IAccount.sol', 'contracts/interfaces/IAccountExecute.sol', 'contracts/interfaces/IAggregator.sol', 'contracts/interfaces/IEntryPoint.sol', 'contracts/interfaces/INonceManager.sol', 'contracts/interfaces/IPaymaster.sol', 'contracts/interfaces/IStakeManager.sol', 'contracts/interfaces/PackedUserOperation.sol', 'contracts/utils/Exec.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646140` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 25 |
| 🟢 LOW | 6 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 947 行
- **函数**: `delegateAndRevert()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    944 | 
    945 |     /// @inheritdoc IEntryPoint
    946 |     function delegateAndRevert(address target, bytes calldata data) external {
>>  947 |         (bool success, bytes memory ret) = target.delegatecall(data);
    948 |         revert DelegateAndRevert(success, ret);
    949 |     }
    950 | }
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 2070 行
- **函数**: `delegateCall()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   2067 |         uint256 txGas
   2068 |     ) internal returns (bool success) {
   2069 |         assembly ("memory-safe") {
>> 2070 |             success := delegatecall(txGas, to, add(data, 0x20), mload(data), 0, 0)
   2071 |         }
   2072 |     }
   2073 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 215 行
- **函数**: `_compensate()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    212 |      */
    213 |     function _compensate(address payable beneficiary, uint256 amount) internal {
    214 |         require(beneficiary != address(0), "AA90 invalid beneficiary");
>>  215 |         (bool success, ) = beneficiary.call{value: amount}("");
    216 |         require(success, "AA91 failed send to beneficiary");
    217 |     }
    218 | 
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 491 行
- **函数**: `innerHandleOp()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    488 | 
    489 |         IPaymaster.PostOpMode mode = IPaymaster.PostOpMode.opSucceeded;
    490 |         if (callData.length > 0) {
>>  491 |             bool success = Exec.call(mUserOp.sender, 0, callData, callGasLimit);
    492 |             if (!success) {
    493 |                 bytes memory result = Exec.getReturnData(REVERT_REASON_MAX_LEN);
    494 |                 if (result.length > 0) {
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1278 行
- **函数**: `withdrawStake()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1275 |         info.withdrawTime = 0;
   1276 |         info.stake = 0;
   1277 |         emit StakeWithdrawn(msg.sender, withdrawAddress, stake);
>> 1278 |         (bool success,) = withdrawAddress.call{value: stake}("");
   1279 |         require(success, "failed to withdraw stake");
   1280 |     }
   1281 | 
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1295 行
- **函数**: `withdrawTo()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1292 |         require(withdrawAmount <= info.deposit, "Withdraw amount too large");
   1293 |         info.deposit = info.deposit - withdrawAmount;
   1294 |         emit Withdrawn(msg.sender, withdrawAddress, withdrawAmount);
>> 1295 |         (bool success,) = withdrawAddress.call{value: withdrawAmount}("");
   1296 |         require(success, "failed to withdraw");
   1297 |     }
   1298 | }
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 26 行
- **函数**: `supportsInterface()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     23 |     /**
     24 |      * @dev See {IERC165-supportsInterface}.
     25 |      */
>>   26 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
     27 |         return interfaceId == type(IERC165).interfaceId;
     28 |     }
     29 | }
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 57 行
- **函数**: `supportsInterface()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     54 |      *
     55 |      * This function call must use less than 30 000 gas.
     56 |      */
>>   57 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
     58 | }
     59 | 
     60 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 199 行
- **函数**: `supportsInterface()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    196 |     uint256 private constant PENALTY_PERCENT = 10;
    197 | 
    198 |     /// @inheritdoc IERC165
>>  199 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
    200 |         // note: solidity "type(IEntryPoint).interfaceId" is without inherited methods but we want to check everything
    201 |         return interfaceId == (type(IEntryPoint).interfaceId ^ type(IStakeManager).interfaceId ^ type(INonceManager).interfaceId) ||
    202 |             interfaceId == type(IEntryPoint).interfaceId ||
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 601 行
- **函数**: `getSenderAddress()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    598 |     }
    599 | 
    600 |     /// @inheritdoc IEntryPoint
>>  601 |     function getSenderAddress(bytes calldata initCode) public {
    602 |         address sender = senderCreator().createSender(initCode);
    603 |         revert SenderAddressResult(sender);
    604 |     }
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 946 行
- **函数**: `delegateAndRevert()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    943 |     }
    944 | 
    945 |     /// @inheritdoc IEntryPoint
>>  946 |     function delegateAndRevert(address target, bytes calldata data) external {
    947 |         (bool success, bytes memory ret) = target.delegatecall(data);
    948 |         revert DelegateAndRevert(success, ret);
    949 |     }
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1090 行
- **函数**: `incrementNonce()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1087 |     // (mainly so that during construction nonce can be made non-zero,
   1088 |     // to "absorb" the gas cost of first nonce increment to 1st transaction (construction),
   1089 |     // not to 2nd transaction)
>> 1090 |     function incrementNonce(uint192 key) public override {
   1091 |         nonceSequenceNumber[msg.sender][key]++;
   1092 |     }
   1093 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1191 行
- **函数**: `balanceOf()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1188 |     }
   1189 | 
   1190 |     /// @inheritdoc IStakeManager
>> 1191 |     function balanceOf(address account) public view returns (uint256) {
   1192 |         return deposits[account].deposit;
   1193 |     }
   1194 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1216 行
- **函数**: `depositTo()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1213 |      * Add to the deposit of the given account.
   1214 |      * @param account - The account to add to.
   1215 |      */
>> 1216 |     function depositTo(address account) public virtual payable {
   1217 |         uint256 newDeposit = _incrementDeposit(account, msg.value);
   1218 |         emit Deposited(account, newDeposit);
   1219 |     }
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1226 行
- **函数**: `addStake()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1223 |      * any pending unstake is first cancelled.
   1224 |      * @param unstakeDelaySec The new lock duration before the deposit can be withdrawn.
   1225 |      */
>> 1226 |     function addStake(uint32 unstakeDelaySec) public payable {
   1227 |         DepositInfo storage info = deposits[msg.sender];
   1228 |         require(unstakeDelaySec > 0, "must specify unstake delay");
   1229 |         require(
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1250 行
- **函数**: `unlockStake()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1247 |      * Attempt to unlock the stake.
   1248 |      * The value can be withdrawn (using withdrawStake) after the unstake delay.
   1249 |      */
>> 1250 |     function unlockStake() external {
   1251 |         DepositInfo storage info = deposits[msg.sender];
   1252 |         require(info.unstakeDelaySec != 0, "not staked");
   1253 |         require(info.staked, "already unstaking");
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1265 行
- **函数**: `withdrawStake()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1262 |      * Must first call unlockStake and wait for the unstakeDelay to pass.
   1263 |      * @param withdrawAddress - The address to send withdrawn value.
   1264 |      */
>> 1265 |     function withdrawStake(address payable withdrawAddress) external {
   1266 |         DepositInfo storage info = deposits[msg.sender];
   1267 |         uint256 stake = info.stake;
   1268 |         require(stake > 0, "No stake to withdraw");
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1959 行
- **函数**: `balanceOf()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1956 |      * @param account - The account to query.
   1957 |      * @return        - The deposit (for gas payment) of the account.
   1958 |      */
>> 1959 |     function balanceOf(address account) external view returns (uint256);
   1960 | 
   1961 |     /**
   1962 |      * Add to the deposit of the given account.
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1965 行
- **函数**: `depositTo()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1962 |      * Add to the deposit of the given account.
   1963 |      * @param account - The account to add to.
   1964 |      */
>> 1965 |     function depositTo(address account) external payable;
   1966 | 
   1967 |     /**
   1968 |      * Add to the account's stake - amount and delay
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1972 行
- **函数**: `addStake()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1969 |      * any pending unstake is first cancelled.
   1970 |      * @param _unstakeDelaySec - The new lock duration before the deposit can be withdrawn.
   1971 |      */
>> 1972 |     function addStake(uint32 _unstakeDelaySec) external payable;
   1973 | 
   1974 |     /**
   1975 |      * Attempt to unlock the stake.
```

---

### 21. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 567 行
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    562 |             requiredPrefund = requiredGas * mUserOp.maxFeePerGas;
    563 |         }
    564 |     }
    565 | 
    566 |     /**
>>  567 |      * Create sender smart contract account if init code is provided.
    568 |      * @param opIndex  - The operation index.
    569 |      * @param opInfo   - The operation info.
    570 |      * @param initCode - The init code for the smart contract account.
    571 |      */
    572 |     function _createSenderIfNeeded(
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1073 行
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1068 | import "../interfaces/INonceManager.sol";
   1069 | 
   1070 | /**
   1071 |  * nonce management functionality
   1072 |  */
>> 1073 | abstract contract NonceManager is INonceManager {
   1074 | 
   1075 |     /**
   1076 |      * The next valid sequence number for a given nonce key.
   1077 |      */
   1078 |     mapping(address => mapping(uint192 => uint256)) public nonceSequenceNumber;
```

---

### 23. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1116 行
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1111 | 
   1112 | // SPDX-License-Identifier: GPL-3.0
   1113 | pragma solidity ^0.8.23;
   1114 | 
   1115 | /**
>> 1116 |  * Helper contract for EntryPoint, to call userOp.initCode from a "neutral" address,
   1117 |  * which is explicitly not the entryPoint itself.
   1118 |  */
   1119 | contract SenderCreator {
   1120 |     /**
   1121 |      * Call the "initCode" factory to create and return the sender account address.
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1167 行
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1162 | /**
   1163 |  * Manage deposits and stakes.
   1164 |  * Deposit is just a balance used to pay for UserOperations (either by a paymaster or an account).
   1165 |  * Stake is value locked for at least "unstakeDelay" by a paymaster.
   1166 |  */
>> 1167 | abstract contract StakeManager is IStakeManager {
   1168 |     /// maps paymaster to their deposits and stakes
   1169 |     mapping(address => DepositInfo) public deposits;
   1170 | 
   1171 |     /// @inheritdoc IStakeManager
   1172 |     function getDepositInfo(
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1766 行
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1761 |         StakeInfo stakeInfo;
   1762 |     }
   1763 | 
   1764 |     /**
   1765 |      * Get counterfactual sender address.
>> 1766 |      * Calculate the sender contract address that will be generated by the initCode and salt in the UserOperation.
   1767 |      * This method always revert, and returns the address in SenderAddressResult error
   1768 |      * @param initCode - The constructor code to be passed into the UserOperation.
   1769 |      */
   1770 |     function getSenderAddress(bytes memory initCode) external;
   1771 | 
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 2008 行
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2003 | 
   2004 | /**
   2005 |  * User Operation struct
   2006 |  * @param sender                - The sender account of this request.
   2007 |  * @param nonce                 - Unique value the sender uses to verify it is not a replay.
>> 2008 |  * @param initCode              - If set, the account contract will be created by this constructor/
   2009 |  * @param callData              - The method call to execute on this account.
   2010 |  * @param accountGasLimits      - Packed gas limits for validateUserOp and gas limit passed to the callData method call.
   2011 |  * @param preVerificationGas    - Gas not calculated by the handleOps method, but added to the gas paid.
   2012 |  *                                Covers batch overhead.
   2013 |  * @param gasFees               - packed gas fields maxPriorityFeePerGas and maxFeePerGas - Same as EIP-1559 gas parameters.
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 2039 行
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2034 | pragma solidity ^0.8.23;
   2035 | 
   2036 | // solhint-disable no-inline-assembly
   2037 | 
   2038 | /**
>> 2039 |  * Utility functions helpful when making different kinds of contract calls in Solidity.
   2040 |  */
   2041 | library Exec {
   2042 | 
   2043 |     function call(
   2044 |         address to,
```

---

### 28. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 755 行
- **函数**: `_getValidationData()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    752 |         }
    753 |         ValidationData memory data = _parseValidationData(validationData);
    754 |         // solhint-disable-next-line not-rely-on-time
>>  755 |         outOfTimeRange = block.timestamp > data.validUntil || block.timestamp < data.validAfter;
    756 |         aggregator = data.aggregator;
    757 |     }
    758 | 
```

---

### 29. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1254 行
- **函数**: `unlockStake()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1251 |         DepositInfo storage info = deposits[msg.sender];
   1252 |         require(info.unstakeDelaySec != 0, "not staked");
   1253 |         require(info.staked, "already unstaking");
>> 1254 |         uint48 withdrawTime = uint48(block.timestamp) + info.unstakeDelaySec;
   1255 |         info.withdrawTime = withdrawTime;
   1256 |         info.staked = false;
   1257 |         emit StakeUnlocked(msg.sender, withdrawTime);
```

---

### 30. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1271 行
- **函数**: `withdrawStake()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1268 |         require(stake > 0, "No stake to withdraw");
   1269 |         require(info.withdrawTime > 0, "must call unlockStake() first");
   1270 |         require(
>> 1271 |             info.withdrawTime <= block.timestamp,
   1272 |             "Stake withdrawal is not due"
   1273 |         );
   1274 |         info.unstakeDelaySec = 0;
```

---

### 31. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 245 行
- **函数**: `_executeUserOp()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    242 |             bytes calldata callData = userOp.callData;
    243 |             bytes memory innerCall;
    244 |             bytes4 methodSig;
>>  245 |             assembly {
    246 |                 let len := callData.length
    247 |                 if gt(len, 3) {
    248 |                     methodSig := calldataload(callData.offset)
```

---

### 32. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 928 行
- **函数**: `getOffsetOfMemoryBytes()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    925 |     function getOffsetOfMemoryBytes(
    926 |         bytes memory data
    927 |     ) internal pure returns (uint256 offset) {
>>  928 |         assembly {
    929 |             offset := data
    930 |         }
    931 |     }
```

---

### 33. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x0000000071727De22E5E9d8BAf0edAc6f37da032` 第 1328 行
- **函数**: `getSender()`
- **合约**: `and`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1325 |     ) internal pure returns (address) {
   1326 |         address data;
   1327 |         //read sender from userOp, which is first userOp member (saves 800 gas...)
>> 1328 |         assembly {
   1329 |             data := calldataload(userOp)
   1330 |         }
   1331 |         return address(uint160(data));
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*