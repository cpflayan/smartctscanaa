# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:27:14
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` |
| contract_name | `Aggregator` |
| compiler_version | `v0.8.26+commit.8a97fa7a` |
| optimization_used | `True` |
| runs | `100000` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/Aggregator.sol', 'lib/v4-core/lib/openzeppelin-contracts/contracts/access/Ownable.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IVault.sol', 'lib/infinity-periphery/src/interfaces/external/IWETH9.sol', 'lib/infinity-periphery/src/base/ReentrancyLock.sol', 'src/base/NativeWrapper.sol', 'src/base/ImmutableState.sol', 'src/base/PausableOwner.sol', 'src/libraries/FeeHelper.sol', 'src/interfaces/IAdapter.sol', 'src/interfaces/IAggregator.sol', 'src/libraries/CommonUtils.sol', 'src/adapters/UniV2StyledAdapter.sol', 'src/adapters/UniV3StyledAdapter.sol', 'src/adapters/InfinitySwapPoolAdapter.sol', 'src/libraries/PathRawDataHelper.sol', 'src/libraries/PathAdapterHelper.sol', 'src/base/Payment.sol', 'src/adapters/UniV4Adapter.sol', 'lib/v4-core/lib/openzeppelin-contracts/contracts/utils/Context.sol', 'lib/infinity-periphery/lib/infinity-core/src/types/Currency.sol', 'lib/infinity-periphery/lib/infinity-core/src/types/BalanceDelta.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IVaultToken.sol', 'lib/v4-core/lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'lib/infinity-periphery/lib/infinity-core/src/Vault.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/interfaces/ICLPoolManager.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/interfaces/IBinPoolManager.sol', 'lib/v4-core/src/interfaces/IPoolManager.sol', 'lib/v4-core/lib/openzeppelin-contracts/contracts/access/Ownable2Step.sol', 'lib/v4-core/lib/openzeppelin-contracts/contracts/utils/Pausable.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/FullMath.sol', 'lib/infinity-periphery/lib/infinity-core/lib/solmate/src/utils/SafeTransferLib.sol', 'src/interfaces/IUniV2StyledPool.sol', 'src/interfaces/IUniV3StyledPool.sol', 'src/interfaces/IUniV3StyledSwapCallback.sol', 'src/libraries/TransientStorage.sol', 'src/libraries/UniV3TickMath.sol', 'lib/infinity-periphery/lib/infinity-core/lib/openzeppelin-contracts/contracts/utils/math/SafeCast.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/ILockCallback.sol', 'lib/infinity-periphery/lib/infinity-core/src/types/PoolKey.sol', 'lib/infinity-periphery/src/libraries/SafeCast.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/SafeCast.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/TickMath.sol', 'lib/v4-core/src/interfaces/callback/IUnlockCallback.sol', 'lib/v4-core/src/types/BalanceDelta.sol', 'lib/v4-core/src/types/PoolKey.sol', 'lib/v4-core/src/types/Currency.sol', 'lib/v4-core/src/libraries/SafeCast.sol', 'lib/v4-core/src/libraries/TickMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IERC20Minimal.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/CustomRevert.sol', 'lib/infinity-periphery/lib/infinity-core/src/types/PoolId.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IPoolManager.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/SettlementGuard.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/VaultReserve.sol', 'lib/infinity-periphery/lib/infinity-core/src/VaultToken.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/CLPool.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IHooks.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IProtocolFees.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/CLPosition.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IExtsload.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/Tick.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/BinPool.sol', 'lib/v4-core/src/interfaces/IHooks.sol', 'lib/v4-core/src/interfaces/external/IERC6909Claims.sol', 'lib/v4-core/src/interfaces/IProtocolFees.sol', 'lib/v4-core/src/types/PoolId.sol', 'lib/v4-core/src/interfaces/IExtsload.sol', 'lib/v4-core/src/interfaces/IExttload.sol', 'lib/infinity-periphery/lib/infinity-core/lib/solmate/src/tokens/ERC20.sol', 'lib/v4-core/src/interfaces/external/IERC20Minimal.sol', 'lib/v4-core/src/libraries/CustomRevert.sol', 'lib/v4-core/src/libraries/BitMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/types/CLSlot0.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/TickBitmap.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/SqrtPriceMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/FixedPoint128.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/math/UnsafeMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/SwapMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/LiquidityMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/ProtocolFeeLibrary.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/LPFeeLibrary.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IProtocolFeeController.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/types/BinSlot0.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/LiquidityConfigurations.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/PackedUint128Math.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/Uint256x256Math.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/TreeMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/PriceHelper.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/BinHelper.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/BinPosition.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/SafeCast.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/Constants.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/FeeHelper.sol', 'lib/v4-core/src/types/BeforeSwapDelta.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/BitMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/FixedPoint96.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/math/Encoded.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/BitMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/Uint128x128Math.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/BinPoolParametersHelper.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655010` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 126 |
| 🟢 LOW | 97 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1215 行
- **函数**: `uniV2StyledSwapExactZeroForOne()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1212 | 
   1213 |     function uniV2StyledSwapExactZeroForOne(address to, address pool, uint256 excludingFeeRatio) internal {
   1214 |         address baseToken = IUniV2StyledPool(pool).token0();
>> 1215 |         (uint256 reserveIn, uint256 reserveOut,) = IUniV2StyledPool(pool).getReserves();
   1216 |         if (reserveIn == 0 || reserveOut == 0) revert UNIV2_STYLED_ADAPTER_INSUFFICIENT_LIQUIDITY();
   1217 | 
   1218 |         uint256 balance0 = IERC20(baseToken).balanceOf(pool);
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1230 行
- **函数**: `uniV2StyledSwapExactOneForZero()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1227 | 
   1228 |     function uniV2StyledSwapExactOneForZero(address to, address pool, uint256 excludingFeeRatio) internal {
   1229 |         address quoteToken = IUniV2StyledPool(pool).token1();
>> 1230 |         (uint256 reserveOut, uint256 reserveIn,) = IUniV2StyledPool(pool).getReserves();
   1231 |         if (reserveIn == 0 || reserveOut == 0) revert UNIV2_STYLED_ADAPTER_INSUFFICIENT_LIQUIDITY();
   1232 | 
   1233 |         uint256 balance1 = IERC20(quoteToken).balanceOf(pool);
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3466 行
- **函数**: `getReserves()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   3463 | 
   3464 |     function swap(uint256 amount0Out, uint256 amount1Out, address to, bytes calldata data) external;
   3465 | 
>> 3466 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   3467 | 
   3468 |     function token0() external view returns (address);
   3469 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 501 行
- **函数**: `sweep()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    498 | 
    499 |     /// @notice the aggregation contract is not expected to hold tokens
    500 |     ///         this function helps to rescue tokens left in the contract for any reasons
>>  501 |     function sweep(address token, address recipient, uint256 amountMinimum) external isNotLocked {
    502 |         uint256 balance = token.balanceOf(address(this));
    503 |         if (balance < amountMinimum) revert InsufficientToken();
    504 |         if (balance > 0) _transferInternal(address(this), recipient, token, balance);
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 566 行
- **函数**: `owner()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    563 |     /**
    564 |      * @dev Returns the address of the current owner.
    565 |      */
>>  566 |     function owner() public view virtual returns (address) {
    567 |         return _owner;
    568 |     }
    569 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 647 行
- **函数**: `isAppRegistered()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    644 |     /// @notice Thrown when collectFee is attempted on a token that is synced.
    645 |     error FeeCurrencySynced();
    646 | 
>>  647 |     function isAppRegistered(address app) external returns (bool);
    648 | 
    649 |     /// @notice Returns the reserves for a a given pool type and currency
    650 |     function reservesOfApp(address app, Currency currency) external view returns (uint256);
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 650 行
- **函数**: `reservesOfApp()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    647 |     function isAppRegistered(address app) external returns (bool);
    648 | 
    649 |     /// @notice Returns the reserves for a a given pool type and currency
>>  650 |     function reservesOfApp(address app, Currency currency) external view returns (uint256);
    651 | 
    652 |     /// @notice register an app so that it can perform accounting base on vault
    653 |     function registerApp(address app) external;
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 656 行
- **函数**: `getLocker()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    653 |     function registerApp(address app) external;
    654 | 
    655 |     /// @notice Returns the locker who is locking the vault
>>  656 |     function getLocker() external view returns (address locker);
    657 | 
    658 |     /// @notice Returns the reserve and its amount that is currently being stored in trnasient storage
    659 |     function getVaultReserve() external view returns (Currency, uint256);
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 659 行
- **函数**: `getVaultReserve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    656 |     function getLocker() external view returns (address locker);
    657 | 
    658 |     /// @notice Returns the reserve and its amount that is currently being stored in trnasient storage
>>  659 |     function getVaultReserve() external view returns (Currency, uint256);
    660 | 
    661 |     /// @notice Returns lock data
    662 |     function getUnsettledDeltasCount() external view returns (uint256 count);
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 662 行
- **函数**: `getUnsettledDeltasCount()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    659 |     function getVaultReserve() external view returns (Currency, uint256);
    660 | 
    661 |     /// @notice Returns lock data
>>  662 |     function getUnsettledDeltasCount() external view returns (uint256 count);
    663 | 
    664 |     /// @notice Get the current delta for a locker in the given currency
    665 |     /// @param currency The currency for which to lookup the delta
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 666 行
- **函数**: `currencyDelta()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    663 | 
    664 |     /// @notice Get the current delta for a locker in the given currency
    665 |     /// @param currency The currency for which to lookup the delta
>>  666 |     function currencyDelta(address settler, Currency currency) external view returns (int256);
    667 | 
    668 |     /// @notice All operations go through this function
    669 |     /// @param data Any data to pass to the callback, via `ILockCallback(msg.sender).lockCallback(data)`
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 671 行
- **函数**: `lock()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    668 |     /// @notice All operations go through this function
    669 |     /// @param data Any data to pass to the callback, via `ILockCallback(msg.sender).lockCallback(data)`
    670 |     /// @return The data returned by the call to `ILockCallback(msg.sender).lockCallback(data)`
>>  671 |     function lock(bytes calldata data) external returns (bytes memory);
    672 | 
    673 |     /// @notice Called by registered app to account for a change in the pool balance,
    674 |     /// convenient for AMM pool manager, typically after modifyLiquidity, swap, donate,
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 720 行
- **函数**: `settle()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    717 |     function sync(Currency token0) external;
    718 | 
    719 |     /// @notice Called by the user to pay what is owed
>>  720 |     function settle() external payable returns (uint256 paid);
    721 | 
    722 |     /// @notice Called by the user to pay on behalf of another address
    723 |     /// @param recipient The address to credit for the payment
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 725 行
- **函数**: `settleFor()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    722 |     /// @notice Called by the user to pay on behalf of another address
    723 |     /// @param recipient The address to credit for the payment
    724 |     /// @return paid The amount of currency settled
>>  725 |     function settleFor(address recipient) external payable returns (uint256 paid);
    726 | 
    727 |     /// @notice WARNING - Any currency that is cleared, will be non-retreivable, and locked in the contract permanently.
    728 |     /// A call to clear will zero out a positive balance WITHOUT a corresponding transfer.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 756 行
- **函数**: `deposit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    753 | /// @notice Interface for WETH9
    754 | interface IWETH9 is IERC20 {
    755 |     /// @notice Deposit ether to get wrapped ether
>>  756 |     function deposit() external payable;
    757 | 
    758 |     /// @notice Withdraw wrapped ether to get ether
    759 |     function withdraw(uint256) external;
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1299 行
- **函数**: `pancakeV3SwapCallback()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1296 |     }
   1297 | 
   1298 |     /// @notice for PancakeSwap V3
>> 1299 |     function pancakeV3SwapCallback(int256 amount0Delta, int256 amount1Delta, bytes calldata _data) external override {
   1300 |         if (msg.sender != TransientStorage.loadAddress(_TEMP_POOL_ADDRESS_SLOT)) revert V3InvalidCaller();
   1301 |         (address tokenIn, address tokenOut, uint24 fee, address payer, uint256 amountIn, address refundTo) =
   1302 |             abi.decode(_data, (address, address, uint24, address, uint256, address));
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1311 行
- **函数**: `uniswapV3SwapCallback()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1308 |     }
   1309 | 
   1310 |     /// @notice for Uniswap V3 and Aerodrome SlipStream (both use the uniswapV3SwapCallback selector)
>> 1311 |     function uniswapV3SwapCallback(int256 amount0Delta, int256 amount1Delta, bytes calldata _data) external override {
   1312 |         if (msg.sender != TransientStorage.loadAddress(_TEMP_POOL_ADDRESS_SLOT)) revert V3InvalidCaller();
   1313 |         (address tokenIn, address tokenOut, uint24 fee, address payer, uint256 amountIn, address refundTo) =
   1314 |             abi.decode(_data, (address, address, uint24, address, uint256, address));
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1417 行
- **函数**: `lockAcquired()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1414 |     }
   1415 | 
   1416 |     /// @inheritdoc ILockCallback
>> 1417 |     function lockAcquired(bytes calldata data) external onlyByVault returns (bytes memory) {
   1418 |         (uint256 amountIn, address from, address to, address poolManager, bytes memory extraData, address refundTo) =
   1419 |             abi.decode(data, (uint256, address, address, address, bytes, address));
   1420 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1680 行
- **函数**: `unlockCallback()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1677 |     }
   1678 | 
   1679 |     /// @inheritdoc IUnlockCallback
>> 1680 |     function unlockCallback(bytes calldata data) external onlyByPoolManager returns (bytes memory) {
   1681 |         (uint256 amountIn, address from, address to, bytes memory extraData, address refundTo) =
   1682 |             abi.decode(data, (uint256, address, address, bytes, address));
   1683 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2018 行
- **函数**: `balanceOf()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2015 |     /// @param owner The address you want to query the balance of
   2016 |     /// @param currency The currency you want to query the balance of
   2017 |     /// @return balance The balance of the specified address
>> 2018 |     function balanceOf(address owner, Currency currency) external view returns (uint256 balance);
   2019 | 
   2020 |     /// @notice get the amount that owner has authorized for spender to use
   2021 |     /// @param owner The address of the owner
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2025 行
- **函数**: `allowance()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2022 |     /// @param spender The address who is allowed to spend the owner's token
   2023 |     /// @param currency The currency the spender is allowed to spend
   2024 |     /// @return amount The amount of token the spender is allowed to spend
>> 2025 |     function allowance(address owner, address spender, Currency currency) external view returns (uint256 amount);
   2026 | 
   2027 |     /// @notice approve spender for using user's token
   2028 |     /// @param spender The address msg.sender is approving to spend the his token
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2032 行
- **函数**: `approve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2029 |     /// @param currency The currency the spender is allowed to spend
   2030 |     /// @param amount The amount of token the spender is allowed to spend
   2031 |     /// @return bool Whether the approval was successful or not
>> 2032 |     function approve(address spender, Currency currency, uint256 amount) external returns (bool);
   2033 | 
   2034 |     /// @notice transfer msg.sender's token to someone else
   2035 |     /// @param to The address to transfer the token to
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2039 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2036 |     /// @param currency The currency to transfer
   2037 |     /// @param amount The amount of token to transfer
   2038 |     /// @return bool Whether the transfer was successful or not
>> 2039 |     function transfer(address to, Currency currency, uint256 amount) external returns (bool);
   2040 | 
   2041 |     /// @notice transfer from address's token on behalf of him
   2042 |     /// @param from The address to transfer the token from
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2047 行
- **函数**: `transferFrom()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2044 |     /// @param currency The currency to transfer
   2045 |     /// @param amount The amount of token to transfer
   2046 |     /// @return bool Whether the transfer was successful or not
>> 2047 |     function transferFrom(address from, address to, Currency currency, uint256 amount) external returns (bool);
   2048 | }
   2049 | 
   2050 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2079 行
- **函数**: `totalSupply()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2076 |     /**
   2077 |      * @dev Returns the value of tokens in existence.
   2078 |      */
>> 2079 |     function totalSupply() external view returns (uint256);
   2080 | 
   2081 |     /**
   2082 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2084 行
- **函数**: `balanceOf()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2081 |     /**
   2082 |      * @dev Returns the value of tokens owned by `account`.
   2083 |      */
>> 2084 |     function balanceOf(address account) external view returns (uint256);
   2085 | 
   2086 |     /**
   2087 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2093 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2090 |      *
   2091 |      * Emits a {Transfer} event.
   2092 |      */
>> 2093 |     function transfer(address to, uint256 value) external returns (bool);
   2094 | 
   2095 |     /**
   2096 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2102 行
- **函数**: `allowance()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2099 |      *
   2100 |      * This value changes when {approve} or {transferFrom} are called.
   2101 |      */
>> 2102 |     function allowance(address owner, address spender) external view returns (uint256);
   2103 | 
   2104 |     /**
   2105 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2119 行
- **函数**: `approve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2116 |      *
   2117 |      * Emits an {Approval} event.
   2118 |      */
>> 2119 |     function approve(address spender, uint256 value) external returns (bool);
   2120 | 
   2121 |     /**
   2122 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2130 行
- **函数**: `transferFrom()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2127 |      *
   2128 |      * Emits a {Transfer} event.
   2129 |      */
>> 2130 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   2131 | }
   2132 | 
   2133 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2182 行
- **函数**: `getLocker()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2179 |     }
   2180 | 
   2181 |     /// @inheritdoc IVault
>> 2182 |     function getLocker() external view override returns (address) {
   2183 |         return SettlementGuard.getLocker();
   2184 |     }
   2185 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2187 行
- **函数**: `getUnsettledDeltasCount()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2184 |     }
   2185 | 
   2186 |     /// @inheritdoc IVault
>> 2187 |     function getUnsettledDeltasCount() external view override returns (uint256) {
   2188 |         return SettlementGuard.getUnsettledDeltasCount();
   2189 |     }
   2190 | 
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2192 行
- **函数**: `currencyDelta()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2189 |     }
   2190 | 
   2191 |     /// @inheritdoc IVault
>> 2192 |     function currencyDelta(address settler, Currency currency) external view override returns (int256) {
   2193 |         return SettlementGuard.getCurrencyDelta(settler, currency);
   2194 |     }
   2195 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2198 行
- **函数**: `lock()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2195 | 
   2196 |     /// @dev interaction must start from lock
   2197 |     /// @inheritdoc IVault
>> 2198 |     function lock(bytes calldata data) external override returns (bytes memory result) {
   2199 |         /// @dev only one locker at a time
   2200 |         SettlementGuard.setLocker(msg.sender);
   2201 | 
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2265 行
- **函数**: `take()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2262 |     }
   2263 | 
   2264 |     /// @inheritdoc IVault
>> 2265 |     function take(Currency currency, address to, uint256 amount) external override isLocked {
   2266 |         unchecked {
   2267 |             SettlementGuard.accountDelta(msg.sender, currency, -(amount.toInt128()));
   2268 |             currency.transfer(to, amount);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2273 行
- **函数**: `mint()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2270 |     }
   2271 | 
   2272 |     /// @inheritdoc IVault
>> 2273 |     function mint(address to, Currency currency, uint256 amount) external override isLocked {
   2274 |         unchecked {
   2275 |             SettlementGuard.accountDelta(msg.sender, currency, -(amount.toInt128()));
   2276 |             _mint(to, currency, amount);
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2280 行
- **函数**: `sync()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2277 |         }
   2278 |     }
   2279 | 
>> 2280 |     function sync(Currency currency) public override {
   2281 |         if (currency.isNative()) {
   2282 |             VaultReserve.setVaultReserve(CurrencyLibrary.NATIVE, 0);
   2283 |         } else {
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2290 行
- **函数**: `settle()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2287 |     }
   2288 | 
   2289 |     /// @inheritdoc IVault
>> 2290 |     function settle() external payable override isLocked returns (uint256) {
   2291 |         return _settle(msg.sender);
   2292 |     }
   2293 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2295 行
- **函数**: `settleFor()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2292 |     }
   2293 | 
   2294 |     /// @inheritdoc IVault
>> 2295 |     function settleFor(address recipient) external payable override isLocked returns (uint256) {
   2296 |         return _settle(recipient);
   2297 |     }
   2298 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2300 行
- **函数**: `clear()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2297 |     }
   2298 | 
   2299 |     /// @inheritdoc IVault
>> 2300 |     function clear(Currency currency, uint256 amount) external isLocked {
   2301 |         int256 existingDelta = SettlementGuard.getCurrencyDelta(msg.sender, currency);
   2302 |         int128 amountDelta = amount.toInt128();
   2303 |         /// @dev since amount is uint256, existingDelta must be positive otherwise revert
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2311 行
- **函数**: `burn()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2308 |     }
   2309 | 
   2310 |     /// @inheritdoc IVault
>> 2311 |     function burn(address from, Currency currency, uint256 amount) external override isLocked {
   2312 |         SettlementGuard.accountDelta(msg.sender, currency, amount.toInt128());
   2313 |         _burnFrom(from, currency, amount);
   2314 |     }
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2317 行
- **函数**: `collectFee()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2314 |     }
   2315 | 
   2316 |     /// @inheritdoc IVault
>> 2317 |     function collectFee(Currency currency, uint256 amount, address recipient) external onlyRegisteredApp {
   2318 |         // prevent transfer between the sync and settle balanceOfs (native settle uses msg.value)
   2319 |         (Currency syncedCurrency,) = VaultReserve.getVaultReserve();
   2320 |         if (!currency.isNative() && syncedCurrency == currency) revert FeeCurrencySynced();
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2326 行
- **函数**: `getVaultReserve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2323 |     }
   2324 | 
   2325 |     /// @inheritdoc IVault
>> 2326 |     function getVaultReserve() external view returns (Currency, uint256) {
   2327 |         return VaultReserve.getVaultReserve();
   2328 |     }
   2329 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2460 行
- **函数**: `getLiquidity()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2457 |         returns (uint160 sqrtPriceX96, int24 tick, uint24 protocolFee, uint24 lpFee);
   2458 | 
   2459 |     /// @notice Get the current value of liquidity of the given pool
>> 2460 |     function getLiquidity(PoolId id) external view returns (uint128 liquidity);
   2461 | 
   2462 |     /// @notice Get the current value of liquidity for the specified pool and position
   2463 |     function getLiquidity(PoolId id, address owner, int24 tickLower, int24 tickUpper, bytes32 salt)
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2469 行
- **函数**: `getPoolTickInfo()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2466 |         returns (uint128 liquidity);
   2467 | 
   2468 |     /// @notice Get the tick info about a specific tick in the pool
>> 2469 |     function getPoolTickInfo(PoolId id, int24 tick) external view returns (Tick.Info memory);
   2470 | 
   2471 |     /// @notice Get the tick bitmap info about a specific range (a word range) in the pool
   2472 |     function getPoolBitmapInfo(PoolId id, int16 word) external view returns (uint256 tickBitmap);
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2472 行
- **函数**: `getPoolBitmapInfo()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2469 |     function getPoolTickInfo(PoolId id, int24 tick) external view returns (Tick.Info memory);
   2470 | 
   2471 |     /// @notice Get the tick bitmap info about a specific range (a word range) in the pool
>> 2472 |     function getPoolBitmapInfo(PoolId id, int16 word) external view returns (uint256 tickBitmap);
   2473 | 
   2474 |     /// @notice Get the fee growth global for the given pool
   2475 |     /// @return feeGrowthGlobal0x128 The global fee growth for token0
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2492 行
- **函数**: `initialize()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2489 |         returns (CLPosition.Info memory position);
   2490 | 
   2491 |     /// @notice Initialize the state for a given pool ID
>> 2492 |     function initialize(PoolKey memory key, uint160 sqrtPriceX96) external returns (int24 tick);
   2493 | 
   2494 |     struct ModifyLiquidityParams {
   2495 |         // the lower and upper tick of the position
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2586 行
- **函数**: `maxBinStep()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2583 | 
   2584 |     /// @notice Returns the constant representing the max bin step
   2585 |     /// @return maxBinStep a value of 100 would represent a 1% price jump between bin (limit can be raised by owner)
>> 2586 |     function maxBinStep() external view returns (uint16);
   2587 | 
   2588 |     /// @notice Returns the constant representing the min bin step
   2589 |     /// @dev 1 would represent a 0.01% price jump between bin
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2590 行
- **函数**: `MIN_BIN_STEP()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2587 | 
   2588 |     /// @notice Returns the constant representing the min bin step
   2589 |     /// @dev 1 would represent a 0.01% price jump between bin
>> 2590 |     function MIN_BIN_STEP() external view returns (uint16);
   2591 | 
   2592 |     /// @notice min share in bin before donate is allowed in current bin
   2593 |     function minBinShareForDonate() external view returns (uint256);
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2593 行
- **函数**: `minBinShareForDonate()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2590 |     function MIN_BIN_STEP() external view returns (uint16);
   2591 | 
   2592 |     /// @notice min share in bin before donate is allowed in current bin
>> 2593 |     function minBinShareForDonate() external view returns (uint256);
   2594 | 
   2595 |     /// @notice Emitted when a new pool is initialized
   2596 |     /// @param id The abi encoded hash of the pool key struct for the new pool
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2689 行
- **函数**: `getSlot0()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2686 |     }
   2687 | 
   2688 |     /// @notice Get the current value in slot0 of the given pool
>> 2689 |     function getSlot0(PoolId id) external view returns (uint24 activeId, uint24 protocolFee, uint24 lpFee);
   2690 | 
   2691 |     /// @notice Returns the reserves of a bin
   2692 |     /// @param id The id of the bin
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2718 行
- **函数**: `getNextNonEmptyBin()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2715 |     /// @param swapForY Whether the swap is for token Y (true) or token X (false)
   2716 |     /// @param id The id of the bin
   2717 |     /// @return nextId The id of the next non-empty bin
>> 2718 |     function getNextNonEmptyBin(PoolId id, bool swapForY, uint24 binId) external view returns (uint24 nextId);
   2719 | 
   2720 |     /// @notice Initialize a new pool
   2721 |     function initialize(PoolKey memory key, uint24 activeId) external;
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2885 行
- **函数**: `unlock()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2882 |     /// @dev The only functions callable without an unlocking are `initialize` and `updateDynamicLPFee`
   2883 |     /// @param data Any data to pass to the callback, via `IUnlockCallback(msg.sender).unlockCallback(data)`
   2884 |     /// @return The data returned by the call to `IUnlockCallback(msg.sender).unlockCallback(data)`
>> 2885 |     function unlock(bytes calldata data) external returns (bytes memory);
   2886 | 
   2887 |     /// @notice Initialize the state for a given pool ID
   2888 |     /// @dev A swap fee totaling MAX_SWAP_FEE (100%) makes exact output swaps impossible since the input is entirely consumed by the fee
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2892 行
- **函数**: `initialize()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2889 |     /// @param key The pool key for the pool to initialize
   2890 |     /// @param sqrtPriceX96 The initial square root price
   2891 |     /// @return tick The initial tick of the pool
>> 2892 |     function initialize(PoolKey memory key, uint160 sqrtPriceX96) external returns (int24 tick);
   2893 | 
   2894 |     struct ModifyLiquidityParams {
   2895 |         // the lower and upper tick of the position
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2973 行
- **函数**: `settle()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2970 | 
   2971 |     /// @notice Called by the user to pay what is owed
   2972 |     /// @return paid The amount of currency settled
>> 2973 |     function settle() external payable returns (uint256 paid);
   2974 | 
   2975 |     /// @notice Called by the user to pay on behalf of another address
   2976 |     /// @param recipient The address to credit for the payment
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2978 行
- **函数**: `settleFor()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2975 |     /// @notice Called by the user to pay on behalf of another address
   2976 |     /// @param recipient The address to credit for the payment
   2977 |     /// @return paid The amount of currency settled
>> 2978 |     function settleFor(address recipient) external payable returns (uint256 paid);
   2979 | 
   2980 |     /// @notice WARNING - Any currency that is cleared, will be non-retrievable, and locked in the contract permanently.
   2981 |     /// A call to clear will zero out a positive balance WITHOUT a corresponding transfer.
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3038 行
- **函数**: `pendingOwner()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3035 |     /**
   3036 |      * @dev Returns the address of the pending owner.
   3037 |      */
>> 3038 |     function pendingOwner() public view virtual returns (address) {
   3039 |         return _pendingOwner;
   3040 |     }
   3041 | 
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3063 行
- **函数**: `acceptOwnership()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3060 |     /**
   3061 |      * @dev The new owner accepts the ownership transfer.
   3062 |      */
>> 3063 |     function acceptOwnership() public virtual {
   3064 |         address sender = _msgSender();
   3065 |         if (pendingOwner() != sender) {
   3066 |             revert OwnableUnauthorizedAccount(sender);
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3148 行
- **函数**: `paused()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3145 |     /**
   3146 |      * @dev Returns true if the contract is paused, and false otherwise.
   3147 |      */
>> 3148 |     function paused() public view virtual returns (bool) {
   3149 |         return _paused;
   3150 |     }
   3151 | 
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3466 行
- **函数**: `getReserves()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3463 | 
   3464 |     function swap(uint256 amount0Out, uint256 amount1Out, address to, bytes calldata data) external;
   3465 | 
>> 3466 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   3467 | 
   3468 |     function token0() external view returns (address);
   3469 | 
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3468 行
- **函数**: `token0()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3465 | 
   3466 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   3467 | 
>> 3468 |     function token0() external view returns (address);
   3469 | 
   3470 |     function token1() external view returns (address);
   3471 | }
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3470 行
- **函数**: `token1()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3467 | 
   3468 |     function token0() external view returns (address);
   3469 | 
>> 3470 |     function token1() external view returns (address);
   3471 | }
   3472 | 
   3473 | 
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3501 行
- **函数**: `token0()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3498 |             bool unlocked
   3499 |         );
   3500 | 
>> 3501 |     function token0() external view returns (address);
   3502 | 
   3503 |     function token1() external view returns (address);
   3504 | 
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3503 行
- **函数**: `token1()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3500 | 
   3501 |     function token0() external view returns (address);
   3502 | 
>> 3503 |     function token1() external view returns (address);
   3504 | 
   3505 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   3506 |     /// @return The fee
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3507 行
- **函数**: `fee()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3504 | 
   3505 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   3506 |     /// @return The fee
>> 3507 |     function fee() external view returns (uint24);
   3508 | }
   3509 | 
   3510 | 
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 4985 行
- **函数**: `lockAcquired()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4982 |     /// @notice Called by the pool manager on `msg.sender` when a lock is acquired
   4983 |     /// @param data The data that was passed to the call to lock
   4984 |     /// @return Any data that you want to be returned from the lock call
>> 4985 |     function lockAcquired(bytes calldata data) external returns (bytes memory);
   4986 | }
   4987 | 
   4988 | 
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 5395 行
- **函数**: `unlockCallback()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5392 |     /// @notice Called by the pool manager on `msg.sender` when the manager is unlocked
   5393 |     /// @param data The data that was passed to the call to unlock
   5394 |     /// @return Any data that you want to be returned from the unlock call
>> 5395 |     function unlockCallback(bytes calldata data) external returns (bytes memory);
   5396 | }
   5397 | 
   5398 | 
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 5941 行
- **函数**: `balanceOf()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5938 |     /// @notice Returns the balance of a token
   5939 |     /// @param account The account for which to look up the number of tokens it has, i.e. its balance
   5940 |     /// @return The number of tokens held by the account
>> 5941 |     function balanceOf(address account) external view returns (uint256);
   5942 | 
   5943 |     /// @notice Transfers the amount of token from the `msg.sender` to the recipient
   5944 |     /// @param recipient The account that will receive the amount transferred
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 5947 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5944 |     /// @param recipient The account that will receive the amount transferred
   5945 |     /// @param amount The number of tokens to send from the sender to the recipient
   5946 |     /// @return Returns true for a successful transfer, false for an unsuccessful transfer
>> 5947 |     function transfer(address recipient, uint256 amount) external returns (bool);
   5948 | 
   5949 |     /// @notice Returns the current allowance given to a spender by an owner
   5950 |     /// @param owner The account of the token owner
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 5953 行
- **函数**: `allowance()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5950 |     /// @param owner The account of the token owner
   5951 |     /// @param spender The account of the token spender
   5952 |     /// @return The current allowance granted by `owner` to `spender`
>> 5953 |     function allowance(address owner, address spender) external view returns (uint256);
   5954 | 
   5955 |     /// @notice Sets the allowance of a spender from the `msg.sender` to the value `amount`
   5956 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 5959 行
- **函数**: `approve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5956 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
   5957 |     /// @param amount The amount of tokens allowed to be used by `spender`
   5958 |     /// @return Returns true for a successful approval, false for unsuccessful
>> 5959 |     function approve(address spender, uint256 amount) external returns (bool);
   5960 | 
   5961 |     /// @notice Transfers `amount` tokens from `sender` to `recipient` up to the allowance given to the `msg.sender`
   5962 |     /// @param sender The account from which the transfer will be initiated
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 5966 行
- **函数**: `transferFrom()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5963 |     /// @param recipient The recipient of the transfer
   5964 |     /// @param amount The amount of the transfer
   5965 |     /// @return Returns true for a successful transfer, false for unsuccessful
>> 5966 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
   5967 | 
   5968 |     /// @notice Event emitted when tokens are transferred from one address to another, either via `#transfer` or `#transferFrom`.
   5969 |     /// @param from The account from which the tokens were sent, i.e. the balance decreased
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6276 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6273 |                               ERC6909 LOGIC
   6274 |     //////////////////////////////////////////////////////////////*/
   6275 | 
>> 6276 |     function transfer(address receiver, Currency currency, uint256 amount) public virtual returns (bool) {
   6277 |         balanceOf[msg.sender][currency] -= amount;
   6278 | 
   6279 |         balanceOf[receiver][currency] += amount;
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6305 行
- **函数**: `approve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6302 |         return true;
   6303 |     }
   6304 | 
>> 6305 |     function approve(address spender, Currency currency, uint256 amount) public virtual returns (bool) {
   6306 |         allowance[msg.sender][spender][currency] = amount;
   6307 | 
   6308 |         emit Approval(msg.sender, spender, currency, amount);
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6313 行
- **函数**: `setOperator()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6310 |         return true;
   6311 |     }
   6312 | 
>> 6313 |     function setOperator(address operator, bool approved) public virtual returns (bool) {
   6314 |         isOperator[msg.sender][operator] = approved;
   6315 | 
   6316 |         emit OperatorSet(msg.sender, operator, approved);
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6325 行
- **函数**: `supportsInterface()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6322 |                               ERC165 LOGIC
   6323 |     //////////////////////////////////////////////////////////////*/
   6324 | 
>> 6325 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   6326 |         return interfaceId == 0x01ffc9a7 // ERC165 Interface ID for ERC165
   6327 |             || interfaceId == 0xb2e69f8a; // ERC165 Interface ID for ERC6909
   6328 |     }
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6856 行
- **函数**: `getHooksRegistrationBitmap()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6853 | pragma solidity ^0.8.0;
   6854 | 
   6855 | interface IHooks {
>> 6856 |     function getHooksRegistrationBitmap() external view returns (uint16);
   6857 | }
   6858 | 
   6859 | 
```

---

### 78. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6893 行
- **函数**: `protocolFeesAccrued()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6890 |     /// @notice Given a currency address, returns the protocol fees accrued in that currency
   6891 |     /// @param currency The currency to check
   6892 |     /// @return amount The amount of protocol fees accrued in the given currency
>> 6893 |     function protocolFeesAccrued(Currency currency) external view returns (uint256 amount);
   6894 | 
   6895 |     /// @notice Returns the current protocol fee controller address
   6896 |     /// @return IProtocolFeeController The currency protocol fee controller
```

---

### 79. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6897 行
- **函数**: `protocolFeeController()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6894 | 
   6895 |     /// @notice Returns the current protocol fee controller address
   6896 |     /// @return IProtocolFeeController The currency protocol fee controller
>> 6897 |     function protocolFeeController() external view returns (IProtocolFeeController);
   6898 | 
   6899 |     /// @notice Sets the protocol's swap fee for the given pool
   6900 |     /// @param key The pool key for which to set the protocol fee
```

---

### 80. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6920 行
- **函数**: `vault()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6917 | 
   6918 |     /// @notice Returns the vault where the protocol fees are safely stored
   6919 |     /// @return IVault The address of the vault
>> 6920 |     function vault() external view returns (IVault);
   6921 | }
   6922 | 
   6923 | 
```

---

### 81. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 7039 行
- **函数**: `extsload()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7036 |     /// @notice Called by external contracts to access granular pool state
   7037 |     /// @param slot Key of slot to sload
   7038 |     /// @return value The value of the slot as bytes32
>> 7039 |     function extsload(bytes32 slot) external view returns (bytes32 value);
   7040 | 
   7041 |     /// @notice Called by external contracts to access sparse pool state
   7042 |     /// @param slots List of slots to SLOAD from.
```

---

### 82. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 7044 行
- **函数**: `extsload()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7041 |     /// @notice Called by external contracts to access sparse pool state
   7042 |     /// @param slots List of slots to SLOAD from.
   7043 |     /// @return values List of loaded values.
>> 7044 |     function extsload(bytes32[] calldata slots) external view returns (bytes32[] memory values);
   7045 | }
   7046 | 
   7047 | 
```

---

### 83. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 7811 行
- **函数**: `beforeInitialize()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7808 |     /// @param key The key for the pool being initialized
   7809 |     /// @param sqrtPriceX96 The sqrt(price) of the pool as a Q64.96
   7810 |     /// @return bytes4 The function selector for the hook
>> 7811 |     function beforeInitialize(address sender, PoolKey calldata key, uint160 sqrtPriceX96) external returns (bytes4);
   7812 | 
   7813 |     /// @notice The hook called after the state of a pool is initialized
   7814 |     /// @param sender The initial msg.sender for the initialize call
```

---

### 84. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 7973 行
- **函数**: `balanceOf()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7970 |     /// @param owner The address of the owner.
   7971 |     /// @param id The id of the token.
   7972 |     /// @return amount The balance of the token.
>> 7973 |     function balanceOf(address owner, uint256 id) external view returns (uint256 amount);
   7974 | 
   7975 |     /// @notice Spender allowance of an id.
   7976 |     /// @param owner The address of the owner.
```

---

### 85. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 7980 行
- **函数**: `allowance()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7977 |     /// @param spender The address of the spender.
   7978 |     /// @param id The id of the token.
   7979 |     /// @return amount The allowance of the token.
>> 7980 |     function allowance(address owner, address spender, uint256 id) external view returns (uint256 amount);
   7981 | 
   7982 |     /// @notice Checks if a spender is approved by an owner as an operator
   7983 |     /// @param owner The address of the owner.
```

---

### 86. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 7986 行
- **函数**: `isOperator()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7983 |     /// @param owner The address of the owner.
   7984 |     /// @param spender The address of the spender.
   7985 |     /// @return approved The approval status.
>> 7986 |     function isOperator(address owner, address spender) external view returns (bool approved);
   7987 | 
   7988 |     /// @notice Transfers an amount of an id from the caller to a receiver.
   7989 |     /// @param receiver The address of the receiver.
```

---

### 87. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 7993 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7990 |     /// @param id The id of the token.
   7991 |     /// @param amount The amount of the token.
   7992 |     /// @return bool True, always, unless the function reverts
>> 7993 |     function transfer(address receiver, uint256 id, uint256 amount) external returns (bool);
   7994 | 
   7995 |     /// @notice Transfers an amount of an id from a sender to a receiver.
   7996 |     /// @param sender The address of the sender.
```

---

### 88. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8001 行
- **函数**: `transferFrom()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7998 |     /// @param id The id of the token.
   7999 |     /// @param amount The amount of the token.
   8000 |     /// @return bool True, always, unless the function reverts
>> 8001 |     function transferFrom(address sender, address receiver, uint256 id, uint256 amount) external returns (bool);
   8002 | 
   8003 |     /// @notice Approves an amount of an id to a spender.
   8004 |     /// @param spender The address of the spender.
```

---

### 89. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8008 行
- **函数**: `approve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8005 |     /// @param id The id of the token.
   8006 |     /// @param amount The amount of the token.
   8007 |     /// @return bool True, always
>> 8008 |     function approve(address spender, uint256 id, uint256 amount) external returns (bool);
   8009 | 
   8010 |     /// @notice Sets or removes an operator for the caller.
   8011 |     /// @param operator The address of the operator.
```

---

### 90. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8014 行
- **函数**: `setOperator()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8011 |     /// @param operator The address of the operator.
   8012 |     /// @param approved The approval status.
   8013 |     /// @return bool True, always
>> 8014 |     function setOperator(address operator, bool approved) external returns (bool);
   8015 | }
   8016 | 
   8017 | 
```

---

### 91. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8047 行
- **函数**: `protocolFeesAccrued()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8044 |     /// @notice Given a currency address, returns the protocol fees accrued in that currency
   8045 |     /// @param currency The currency to check
   8046 |     /// @return amount The amount of protocol fees accrued in the currency
>> 8047 |     function protocolFeesAccrued(Currency currency) external view returns (uint256 amount);
   8048 | 
   8049 |     /// @notice Sets the protocol fee for the given pool
   8050 |     /// @param key The key of the pool to set a protocol fee for
```

---

### 92. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8070 行
- **函数**: `protocolFeeController()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8067 | 
   8068 |     /// @notice Returns the current protocol fee controller address
   8069 |     /// @return address The current protocol fee controller address
>> 8070 |     function protocolFeeController() external view returns (address);
   8071 | }
   8072 | 
   8073 | 
```

---

### 93. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8105 行
- **函数**: `extsload()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8102 |     /// @notice Called by external contracts to access granular pool state
   8103 |     /// @param slot Key of slot to sload
   8104 |     /// @return value The value of the slot as bytes32
>> 8105 |     function extsload(bytes32 slot) external view returns (bytes32 value);
   8106 | 
   8107 |     /// @notice Called by external contracts to access granular pool state
   8108 |     /// @param startSlot Key of slot to start sloading from
```

---

### 94. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8111 行
- **函数**: `extsload()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8108 |     /// @param startSlot Key of slot to start sloading from
   8109 |     /// @param nSlots Number of slots to load into return value
   8110 |     /// @return values List of loaded values.
>> 8111 |     function extsload(bytes32 startSlot, uint256 nSlots) external view returns (bytes32[] memory values);
   8112 | 
   8113 |     /// @notice Called by external contracts to access sparse pool state
   8114 |     /// @param slots List of slots to SLOAD from.
```

---

### 95. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8116 行
- **函数**: `extsload()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8113 |     /// @notice Called by external contracts to access sparse pool state
   8114 |     /// @param slots List of slots to SLOAD from.
   8115 |     /// @return values List of loaded values.
>> 8116 |     function extsload(bytes32[] calldata slots) external view returns (bytes32[] memory values);
   8117 | }
   8118 | 
   8119 | 
```

---

### 96. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8130 行
- **函数**: `exttload()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8127 |     /// @notice Called by external contracts to access transient storage of the contract
   8128 |     /// @param slot Key of slot to tload
   8129 |     /// @return value The value of the slot as bytes32
>> 8130 |     function exttload(bytes32 slot) external view returns (bytes32 value);
   8131 | 
   8132 |     /// @notice Called by external contracts to access sparse transient pool state
   8133 |     /// @param slots List of slots to tload
```

---

### 97. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8135 行
- **函数**: `exttload()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8132 |     /// @notice Called by external contracts to access sparse transient pool state
   8133 |     /// @param slots List of slots to tload
   8134 |     /// @return values List of loaded values
>> 8135 |     function exttload(bytes32[] calldata slots) external view returns (bytes32[] memory values);
   8136 | }
   8137 | 
   8138 | 
```

---

### 98. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8208 行
- **函数**: `approve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8205 |                                ERC20 LOGIC
   8206 |     //////////////////////////////////////////////////////////////*/
   8207 | 
>> 8208 |     function approve(address spender, uint256 amount) public virtual returns (bool) {
   8209 |         allowance[msg.sender][spender] = amount;
   8210 | 
   8211 |         emit Approval(msg.sender, spender, amount);
```

---

### 99. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8216 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8213 |         return true;
   8214 |     }
   8215 | 
>> 8216 |     function transfer(address to, uint256 amount) public virtual returns (bool) {
   8217 |         balanceOf[msg.sender] -= amount;
   8218 | 
   8219 |         // Cannot overflow because the sum of all user
```

---

### 100. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8302 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8299 |         emit Approval(owner, spender, value);
   8300 |     }
   8301 | 
>> 8302 |     function DOMAIN_SEPARATOR() public view virtual returns (bytes32) {
   8303 |         return block.chainid == INITIAL_CHAIN_ID ? INITIAL_DOMAIN_SEPARATOR : computeDomainSeparator();
   8304 |     }
   8305 | 
```

---

### 101. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8360 行
- **函数**: `balanceOf()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8357 |     /// @notice Returns an account's balance in the token
   8358 |     /// @param account The account for which to look up the number of tokens it has, i.e. its balance
   8359 |     /// @return The number of tokens held by the account
>> 8360 |     function balanceOf(address account) external view returns (uint256);
   8361 | 
   8362 |     /// @notice Transfers the amount of token from the `msg.sender` to the recipient
   8363 |     /// @param recipient The account that will receive the amount transferred
```

---

### 102. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8366 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8363 |     /// @param recipient The account that will receive the amount transferred
   8364 |     /// @param amount The number of tokens to send from the sender to the recipient
   8365 |     /// @return Returns true for a successful transfer, false for an unsuccessful transfer
>> 8366 |     function transfer(address recipient, uint256 amount) external returns (bool);
   8367 | 
   8368 |     /// @notice Returns the current allowance given to a spender by an owner
   8369 |     /// @param owner The account of the token owner
```

---

### 103. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8372 行
- **函数**: `allowance()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8369 |     /// @param owner The account of the token owner
   8370 |     /// @param spender The account of the token spender
   8371 |     /// @return The current allowance granted by `owner` to `spender`
>> 8372 |     function allowance(address owner, address spender) external view returns (uint256);
   8373 | 
   8374 |     /// @notice Sets the allowance of a spender from the `msg.sender` to the value `amount`
   8375 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
```

---

### 104. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8378 行
- **函数**: `approve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8375 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
   8376 |     /// @param amount The amount of tokens allowed to be used by `spender`
   8377 |     /// @return Returns true for a successful approval, false for unsuccessful
>> 8378 |     function approve(address spender, uint256 amount) external returns (bool);
   8379 | 
   8380 |     /// @notice Transfers `amount` tokens from `sender` to `recipient` up to the allowance given to the `msg.sender`
   8381 |     /// @param sender The account from which the transfer will be initiated
```

---

### 105. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8385 行
- **函数**: `transferFrom()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8382 |     /// @param recipient The recipient of the transfer
   8383 |     /// @param amount The amount of the transfer
   8384 |     /// @return Returns true for a successful transfer, false for unsuccessful
>> 8385 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
   8386 | 
   8387 |     /// @notice Event emitted when tokens are transferred from one address to another, either via `#transfer` or `#transferFrom`.
   8388 |     /// @param from The account from which the tokens were sent, i.e. the balance decreased
```

---

### 106. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 9447 行
- **函数**: `protocolFeeForPool()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   9444 |     /// @return protocolFee The pool's protocol fee, expressed in hundredths of a bip. The upper 12 bits are for 1->0
   9445 |     /// and the lower 12 are for 0->1. The maximum is 4000 - meaning the maximum protocol fee is 0.4%.
   9446 |     /// the protocolFee is taken from the input first, then the lpFee is taken from the remaining input
>> 9447 |     function protocolFeeForPool(PoolKey memory poolKey) external view returns (uint24 protocolFee);
   9448 | }
   9449 | 
   9450 | 
```

---

### 107. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 27 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     22 | import {PathRawDataHelper} from "./libraries/PathRawDataHelper.sol";
     23 | import {PathAdapterHelper} from "./libraries/PathAdapterHelper.sol";
     24 | import {Payment} from "./base/Payment.sol";
     25 | import {UniV4Adapter} from "./adapters/UniV4Adapter.sol";
     26 | 
>>   27 | contract Aggregator is
     28 |     IAggregator,
     29 |     Payment,
     30 |     NativeWrapper,
     31 |     PausableOwner,
     32 |     ReentrancyLock,
```

---

### 108. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 353 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    348 |                 // if next hop has only one fork and wrap/unwrap is not needed, send output to next hop directly to save one transfer
    349 |                 to = hops[i + 1].assetTo[0];
    350 |                 tokenAlreadySentToNextHop = true;
    351 |             } else {
    352 |                 // if we have multiple forks in the next hop, we need to mannually split the output token
>>  353 |                 // so we need to send the output token back to this contract first
    354 |                 // address to = address(this);
    355 |                 tokenAlreadySentToNextHop = false;
    356 |             }
    357 | 
    358 |             // if not the last hop, and next hop fromToken is ETH/WETH, record the current balance of ETH/WETH before next hop
```

---

### 109. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 530 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    525 |  *
    526 |  * This module is used through inheritance. It will make available the modifier
    527 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    528 |  * the owner.
    529 |  */
>>  530 | abstract contract Ownable is Context {
    531 |     address private _owner;
    532 | 
    533 |     /**
    534 |      * @dev The caller account is not authorized to perform an operation.
    535 |      */
```

---

### 110. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 602 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    597 |         }
    598 |         _transferOwnership(newOwner);
    599 |     }
    600 | 
    601 |     /**
>>  602 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    603 |      * Internal function without access restriction.
    604 |      */
    605 |     function _transferOwnership(address newOwner) internal virtual {
    606 |         address oldOwner = _owner;
    607 |         _owner = newOwner;
```

---

### 111. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 808 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    803 | import {IWETH9} from "infinity-periphery/src/interfaces/external/IWETH9.sol";
    804 | import {ImmutableState} from "./ImmutableState.sol";
    805 | 
    806 | /// @title Native Wrapper
    807 | /// @notice Used for wrapping and unwrapping native
>>  808 | abstract contract NativeWrapper {
    809 |     /// @notice The address for WETH9
    810 |     IWETH9 public immutable WETH9;
    811 | 
    812 |     /// @notice Thrown when the contract does not have enough ETH to wrap
    813 |     error InsufficientETH();
```

---

### 112. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 872 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    867 | import {IBinPoolManager} from "infinity-periphery/lib/infinity-core/src/pool-bin/interfaces/IBinPoolManager.sol";
    868 | import {IPoolManager} from "uniswap-v4-core/src/interfaces/IPoolManager.sol";
    869 | /// @title Immutable State
    870 | /// @notice A collection of immutable state variables, commonly used across multiple contracts
    871 | 
>>  872 | contract ImmutableState {
    873 |     /// @notice Throw when the pass in address is zero
    874 |     error ZeroAddress();
    875 | 
    876 |     /// @notice Throw when the init code hash is invalid
    877 |     error InvalidInitCodeHash();
```

---

### 113. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1201 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1196 | 
   1197 | import {IUniV2StyledPool} from "../interfaces/IUniV2StyledPool.sol";
   1198 | import {IERC20} from "@openzeppelin/contracts/token/ERC20/IERC20.sol";
   1199 | 
   1200 | /// @title UniV2StyledAdapter
>> 1201 | /// @notice This contract can used to swap tokens on any Uniswap V2 compatible pools including PancakeSwap, UniSwap, etc.
   1202 | /// @dev It's designed to be inlined into Aggregator contract to reduce gas costs, and it's not meant to be deployed on its own.
   1203 | ///      Also it will be complying with IAdapter interface to avoid naming conflicts.
   1204 | abstract contract UniV2StyledAdapter {
   1205 |     /// @dev this is the percentage of principal amount that will be used for swap after charging fee
   1206 |     ///      10000 means no swap fee i.e. 100% of principal amount will be used for swap
```

---

### 114. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1260 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1255 | import {Payment} from "../base/Payment.sol";
   1256 | import {SafeCast} from "openzeppelin-contracts/contracts/utils/math/SafeCast.sol";
   1257 | import {ImmutableState} from "../base/ImmutableState.sol";
   1258 | 
   1259 | /// @title UniV3StyledAdapter
>> 1260 | /// @notice This contract can used to swap tokens on any Uniswap V3 compatible pools which include: PancakeSwap, UniSwap and Aerodrome SlipStream. Any other protocol to be added require code changes to this file
   1261 | /// @dev It's designed to be inlined into Aggregator contract to reduce gas costs, and it's not meant to be deployed on its own.
   1262 | ///      Also it will not comply with IAdapter interface to avoid naming conflicts.
   1263 | abstract contract UniV3StyledAdapter is IUniV3StyledSwapCallback, Payment, ImmutableState {
   1264 |     using SafeCast for uint256;
   1265 | 
```

---

### 115. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1397 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1392 | import {SafeCastTemp} from "infinity-periphery/src/libraries/SafeCast.sol";
   1393 | import {SafeCast} from "infinity-periphery/lib/infinity-core/src/libraries/SafeCast.sol";
   1394 | import {TickMath} from "infinity-periphery/lib/infinity-core/src/pool-cl/libraries/TickMath.sol";
   1395 | 
   1396 | /// @title InfinitySwapPoolAdapter
>> 1397 | /// @notice This contract can used to swap tokens in Infinity Swap Pool i.e. Infinity CL Pool or Infinity Bin Pool
   1398 | /// @dev It's designed to be inlined into Aggregator contract to reduce gas costs, and it's not meant to be deployed on its own.
   1399 | ///      Also it will not comply with IAdapter interface to avoid naming conflicts.
   1400 | abstract contract InfinitySwapPoolAdapter is ILockCallback, Payment, ImmutableState {
   1401 |     using SafeCast for uint256;
   1402 |     using SafeCastTemp for int128;
```

---

### 116. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1621 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1616 | 
   1617 | import {SafeTransferLib, ERC20} from "solmate/src/utils/SafeTransferLib.sol";
   1618 | import {ImmutableState} from "./ImmutableState.sol";
   1619 | import {CommonUtils} from "../libraries/CommonUtils.sol";
   1620 | 
>> 1621 | abstract contract Payment {
   1622 |     using SafeTransferLib for *;
   1623 |     using CommonUtils for address;
   1624 | 
   1625 |     /// @notice Transfers tokens internally within the contract
   1626 |     /// @param payer The address of the payer.
```

---

### 117. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2566 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2561 | import {IExtsload} from "../../interfaces/IExtsload.sol";
   2562 | import {IHooks} from "../../interfaces/IHooks.sol";
   2563 | import {BinPosition, BinPool} from "../libraries/BinPool.sol";
   2564 | 
   2565 | interface IBinPoolManager is IProtocolFees, IPoolManager, IExtsload {
>> 2566 |     /// @notice PoolManagerMismatch is thrown when pool manager specified in the pool key does not match current contract
   2567 |     error PoolManagerMismatch();
   2568 | 
   2569 |     /// @notice Pool binStep cannot be lesser than 1. Otherwise there will be no price jump between bin
   2570 |     error BinStepTooSmall(uint16 binStep);
   2571 | 
```

---

### 118. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3030 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3025 |  * can later be changed with {transferOwnership} and {acceptOwnership}.
   3026 |  *
   3027 |  * This module is used through inheritance. It will make available all functions
   3028 |  * from parent (Ownable).
   3029 |  */
>> 3030 | abstract contract Ownable2Step is Ownable {
   3031 |     address private _pendingOwner;
   3032 | 
   3033 |     event OwnershipTransferStarted(address indexed previousOwner, address indexed newOwner);
   3034 | 
   3035 |     /**
```

---

### 119. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3091 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3086 |  * This module is used through inheritance. It will make available the
   3087 |  * modifiers `whenNotPaused` and `whenPaused`, which can be applied to
   3088 |  * the functions of your contract. Note that they will not be pausable by
   3089 |  * simply including this module, only once the modifiers are put in place.
   3090 |  */
>> 3091 | abstract contract Pausable is Context {
   3092 |     bool private _paused;
   3093 | 
   3094 |     /**
   3095 |      * @dev Emitted when the pause is triggered by `account`.
   3096 |      */
```

---

### 120. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3516 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3511 | // ── src/interfaces/IUniV3StyledSwapCallback.sol ──────────────────────────────
   3512 | 
   3513 | // SPDX-License-Identifier: MIT
   3514 | pragma solidity ^0.8.0;
   3515 | 
>> 3516 | /// @notice Any contract that calls IUniV3StyledPool#swap must implement this interface
   3517 | interface IUniV3StyledSwapCallback {
   3518 |     /// @notice Called to `msg.sender` after executing a swap via IUniV3StyledPool#swap.
   3519 |     /// @dev In the implementation you must pay the pool tokens owed for the swap.
   3520 |     /// The caller of this method must be checked to be a UniswapV3Pool deployed by the canonical UniswapV3Factory.
   3521 |     /// amount0Delta and amount1Delta can both be 0 if no tokens were swapped.
```

---

### 121. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6252 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   6247 | pragma solidity ^0.8.0;
   6248 | 
   6249 | import {Currency} from "./types/Currency.sol";
   6250 | import {IVaultToken} from "./interfaces/IVaultToken.sol";
   6251 | 
>> 6252 | /// @dev This contract is a modified version of the ERC6909 implementation:
   6253 | /// 1. totalSupply is removed
   6254 | /// 2. tokenId is changed to Currency to fit our use case
   6255 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC6909.sol)
   6256 | 
   6257 | /// @notice Users are allowed to store their surplus tokens i.e. unsettled balance that the pool
```

---

### 122. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 7800 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   7795 | import {BalanceDelta} from "../types/BalanceDelta.sol";
   7796 | import {IPoolManager} from "./IPoolManager.sol";
   7797 | import {BeforeSwapDelta} from "../types/BeforeSwapDelta.sol";
   7798 | 
   7799 | /// @notice V4 decides whether to invoke specific hooks by inspecting the least significant bits
>> 7800 | /// of the address that the hooks contract is deployed to.
   7801 | /// For example, a hooks contract deployed to address: 0x0000000000000000000000000000000000002400
   7802 | /// has the lowest bits '10 0100 0000 0000' which would cause the 'before initialize' and 'after add liquidity' hooks to be used.
   7803 | /// See the Hooks library for the full spec.
   7804 | /// @dev Should only be callable by the v4 PoolManager.
   7805 | interface IHooks {
```

---

### 123. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 7953 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   7948 | // ── lib/v4-core/src/interfaces/external/IERC6909Claims.sol ──────────────────────────────
   7949 | 
   7950 | // SPDX-License-Identifier: MIT
   7951 | pragma solidity ^0.8.0;
   7952 | 
>> 7953 | /// @notice Interface for claims over a contract balance, wrapped as a ERC6909
   7954 | interface IERC6909Claims {
   7955 |     /*//////////////////////////////////////////////////////////////
   7956 |                                  EVENTS
   7957 |     //////////////////////////////////////////////////////////////*/
   7958 | 
```

---

### 124. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8148 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   8143 | 
   8144 | /// @notice Modern and gas efficient ERC20 + EIP-2612 implementation.
   8145 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC20.sol)
   8146 | /// @author Modified from Uniswap (https://github.com/Uniswap/uniswap-v2-core/blob/master/contracts/UniswapV2ERC20.sol)
   8147 | /// @dev Do not manually set balances without updating totalSupply, as the sum of all user balances must not exceed it.
>> 8148 | abstract contract ERC20 {
   8149 |     /*//////////////////////////////////////////////////////////////
   8150 |                                  EVENTS
   8151 |     //////////////////////////////////////////////////////////////*/
   8152 | 
   8153 |     event Transfer(address indexed from, address indexed to, uint256 amount);
```

---

### 125. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 9887 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   9882 | 
   9883 | // SPDX-License-Identifier: GPL-2.0-or-later
   9884 | // Copyright (C) 2024 PancakeSwap
   9885 | pragma solidity ^0.8.0;
   9886 | 
>> 9887 | /// @notice Helper contract used for full precision calculations
   9888 | library Uint256x256Math {
   9889 |     error Uint256x256Math__MulShiftOverflow();
   9890 |     error Uint256x256Math__MulDivOverflow();
   9891 | 
   9892 |     /// @notice Calculates floor(x*y/denominator) with full precision
```

---

### 126. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 11447 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   11442 | pragma solidity ^0.8.0;
   11443 | 
   11444 | import {Constants} from "../Constants.sol";
   11445 | import {BitMath} from "./BitMath.sol";
   11446 | 
>> 11447 | /// @notice Helper contract used for power and log calculations
   11448 | library Uint128x128Math {
   11449 |     using BitMath for uint256;
   11450 | 
   11451 |     error Uint128x128Math__LogUnderflow();
   11452 |     error Uint128x128Math__PowUnderflow(uint256 x, int256 y);
```

---

### 127. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 104 行
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    101 |     }
    102 | 
    103 |     modifier checkDeadline(uint256 deadline) {
>>  104 |         if (block.timestamp > deadline) revert TransactionDeadlinePassed();
    105 |         _;
    106 |     }
    107 | 
```

---

### 128. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8265 行
- **函数**: `permit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   8262 |         bytes32 r,
   8263 |         bytes32 s
   8264 |     ) public virtual {
>> 8265 |         require(deadline >= block.timestamp, "PERMIT_DEADLINE_EXPIRED");
   8266 | 
   8267 |         // Unchecked because the only math done is incrementing
   8268 |         // the owner's nonce which cannot realistically overflow.
```

---

### 129. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2268 行
- **函数**: `take()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   2265 |     function take(Currency currency, address to, uint256 amount) external override isLocked {
   2266 |         unchecked {
   2267 |             SettlementGuard.accountDelta(msg.sender, currency, -(amount.toInt128()));
>> 2268 |             currency.transfer(to, amount);
   2269 |         }
   2270 |     }
   2271 | 
```

---

### 130. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 2322 行
- **函数**: `collectFee()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   2319 |         (Currency syncedCurrency,) = VaultReserve.getVaultReserve();
   2320 |         if (!currency.isNative() && syncedCurrency == currency) revert FeeCurrencySynced();
   2321 |         reservesOfApp[msg.sender][currency] -= amount;
>> 2322 |         currency.transfer(recipient, amount);
   2323 |     }
   2324 | 
   2325 |     /// @inheritdoc IVault
```

---

### 131. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 772 行
- **函数**: `withdraw()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    769 | /// @notice A transient reentrancy lock, that stores the caller's address as the lock
    770 | contract ReentrancyLock {
    771 |     // The slot holding the locker state, transiently. bytes32(uint256(keccak256("LockedBy")) - 1)
>>  772 |     bytes32 constant LOCKED_BY_SLOT = 0x0aedd6bde10e3aa2adec092b02a3e3e805795516cda41f27aa145b8f300af87a;
    773 | 
    774 |     error ContractLocked();
    775 | 
```

---

### 132. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 995 行
- **函数**: `unpause()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    992 | 
    993 |     /// @dev Mask for extracting the lower 240 bits (quotedAmount field) from feeConfig.
    994 |     // bits 239-0: sixty hex f's = 240 bits
>>  995 |     uint256 private constant QUOTED_AMOUNT_MASK = 0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff;
    996 | 
    997 |     /// @notice Extract quotedAmount from feeConfig (bits 239-0).
    998 |     /// @param feeConfig  Packed as [feePercentage << 240 | quotedAmount]
```

---

### 133. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1177 行
- **函数**: `balanceOf()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1174 |         }
   1175 |     }
   1176 | 
>> 1177 |     uint256 private constant ADDRESS_MASK = 0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
   1178 |     /// @notice Converts a uint256 value into an address.
   1179 |     /// @param param The uint256 value to be converted.
   1180 |     /// @return result The address obtained from the conversion.
```

---

### 134. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1528 行
- **函数**: `infinityExactInSwap()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1525 | ///  |  0 - 159 bits  |   160 - 175 bits  |  255    |
   1526 | ///  |  pool address  |   weight          | reverse |
   1527 | library PathRawDataHelper {
>> 1528 |     uint256 private constant RAWDATA_ADDRESS_MASK = 0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
   1529 |     uint256 private constant RAWDATA_REVERSE_MASK = 0x8000000000000000000000000000000000000000000000000000000000000000;
   1530 |     uint256 private constant RAWDATA_WEIGHT_MASK = 0x00000000000000000000ffff0000000000000000000000000000000000000000;
   1531 | 
```

---

### 135. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1529 行
- **函数**: `infinityExactInSwap()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1526 | ///  |  pool address  |   weight          | reverse |
   1527 | library PathRawDataHelper {
   1528 |     uint256 private constant RAWDATA_ADDRESS_MASK = 0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
>> 1529 |     uint256 private constant RAWDATA_REVERSE_MASK = 0x8000000000000000000000000000000000000000000000000000000000000000;
   1530 |     uint256 private constant RAWDATA_WEIGHT_MASK = 0x00000000000000000000ffff0000000000000000000000000000000000000000;
   1531 | 
   1532 |     function decodePathRawData(uint256 rawData) internal pure returns (address poolAddr, uint256 weight, bool reverse) {
```

---

### 136. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1530 行
- **函数**: `infinityExactInSwap()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1527 | library PathRawDataHelper {
   1528 |     uint256 private constant RAWDATA_ADDRESS_MASK = 0x000000000000000000000000ffffffffffffffffffffffffffffffffffffffff;
   1529 |     uint256 private constant RAWDATA_REVERSE_MASK = 0x8000000000000000000000000000000000000000000000000000000000000000;
>> 1530 |     uint256 private constant RAWDATA_WEIGHT_MASK = 0x00000000000000000000ffff0000000000000000000000000000000000000000;
   1531 | 
   1532 |     function decodePathRawData(uint256 rawData) internal pure returns (address poolAddr, uint256 weight, bool reverse) {
   1533 |         assembly {
```

---

### 137. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1558 行
- **函数**: `decodePathRawData()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1555 | library PathAdapterHelper {
   1556 |     /// @notice used to signal that whether the input token of current fork should be wrapped/unwrapped
   1557 |     /// @dev it's the highest two bits of the adapter
>> 1558 |     uint256 public constant INPUT_WRAP_MASK = 0x8000000000000000000000000000000000000000000000000000000000000000;
   1559 |     uint256 public constant INPUT_UNWRAP_MASK = 0x4000000000000000000000000000000000000000000000000000000000000000;
   1560 | 
   1561 |     function shouldInputWrapped(uint256 adapter) internal pure returns (bool) {
```

---

### 138. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1559 行
- **函数**: `decodePathRawData()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1556 |     /// @notice used to signal that whether the input token of current fork should be wrapped/unwrapped
   1557 |     /// @dev it's the highest two bits of the adapter
   1558 |     uint256 public constant INPUT_WRAP_MASK = 0x8000000000000000000000000000000000000000000000000000000000000000;
>> 1559 |     uint256 public constant INPUT_UNWRAP_MASK = 0x4000000000000000000000000000000000000000000000000000000000000000;
   1560 | 
   1561 |     function shouldInputWrapped(uint256 adapter) internal pure returns (bool) {
   1562 |         return (adapter & INPUT_WRAP_MASK) != 0;
```

---

### 139. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1572 行
- **函数**: `shouldInputUnwrapped()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1569 |     /// @dev the following constants are used to signal those inlined adapters
   1570 | 
   1571 |     /// @notice used to signal that the interface of the pool should conform to the Uniswap V2
>> 1572 |     uint256 public constant UNIV2_ADAPTER_MASK = 0x0800000000000000000000000000000000000000000000000000000000000000;
   1573 | 
   1574 |     /// @notice used to signal that the interface of the pool should conform to the PancakeSwap V2
   1575 |     uint256 public constant PCSV2_ADAPTER_MASK = 0x0400000000000000000000000000000000000000000000000000000000000000;
```

---

### 140. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1575 行
- **函数**: `shouldInputUnwrapped()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1572 |     uint256 public constant UNIV2_ADAPTER_MASK = 0x0800000000000000000000000000000000000000000000000000000000000000;
   1573 | 
   1574 |     /// @notice used to signal that the interface of the pool should conform to the PancakeSwap V2
>> 1575 |     uint256 public constant PCSV2_ADAPTER_MASK = 0x0400000000000000000000000000000000000000000000000000000000000000;
   1576 | 
   1577 |     /// @notice used to signal that the interface of the pool should conform to the Uniswap V3
   1578 |     ///         for example Uniswap V3 or PancakeSwap V3
```

---

### 141. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1580 行
- **函数**: `shouldInputUnwrapped()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1577 |     /// @notice used to signal that the interface of the pool should conform to the Uniswap V3
   1578 |     ///         for example Uniswap V3 or PancakeSwap V3
   1579 |     uint256 public constant UNIV3_STYLED_ADAPTER_MASK =
>> 1580 |         0x0200000000000000000000000000000000000000000000000000000000000000;
   1581 | 
   1582 |     /// @notice used to signal that the interface of the pool should conform to Uniswap V4
   1583 |     uint256 public constant UNIV4_STYLED_ADAPTER_MASK =
```

---

### 142. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1584 行
- **函数**: `shouldInputUnwrapped()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1581 | 
   1582 |     /// @notice used to signal that the interface of the pool should conform to Uniswap V4
   1583 |     uint256 public constant UNIV4_STYLED_ADAPTER_MASK =
>> 1584 |         0x0100000000000000000000000000000000000000000000000000000000000000;
   1585 | 
   1586 |     /// @notice used to signal that the interface of the pool should conform to Infinity CL Pool Swap
   1587 |     uint256 public constant INFINITY_SWAP_ADAPTER_MASK =
```

---

### 143. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1588 行
- **函数**: `shouldInputUnwrapped()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1585 | 
   1586 |     /// @notice used to signal that the interface of the pool should conform to Infinity CL Pool Swap
   1587 |     uint256 public constant INFINITY_SWAP_ADAPTER_MASK =
>> 1588 |         0x0080000000000000000000000000000000000000000000000000000000000000;
   1589 | 
   1590 |     function isUniV2Adapter(uint256 adapter) internal pure returns (bool) {
   1591 |         return (adapter & UNIV2_ADAPTER_MASK) != 0;
```

---

### 144. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1856 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1853 |                 let fmp := mload(0x40)
   1854 | 
   1855 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 1856 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   1857 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1858 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1859 | 
```

---

### 145. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1857 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1854 | 
   1855 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
   1856 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>> 1857 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   1858 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   1859 | 
   1860 |                 success :=
```

---

### 146. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3364 行
- **函数**: `safeTransferFrom()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3361 |             let freeMemoryPointer := mload(0x40)
   3362 | 
   3363 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3364 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   3365 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
   3366 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3367 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
```

---

### 147. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3365 行
- **函数**: `safeTransferFrom()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3362 | 
   3363 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   3364 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
>> 3365 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
   3366 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3367 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3368 | 
```

---

### 148. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3366 行
- **函数**: `safeTransferFrom()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3363 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   3364 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   3365 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
>> 3366 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3367 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3368 | 
   3369 |             success := and(
```

---

### 149. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3397 行
- **函数**: `safeTransfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3394 |             let freeMemoryPointer := mload(0x40)
   3395 | 
   3396 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3397 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   3398 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3399 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3400 | 
```

---

### 150. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3398 行
- **函数**: `safeTransfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3395 | 
   3396 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   3397 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>> 3398 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3399 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3400 | 
   3401 |             success := and(
```

---

### 151. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3429 行
- **函数**: `safeApprove()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3426 |             let freeMemoryPointer := mload(0x40)
   3427 | 
   3428 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3429 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
   3430 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3431 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3432 | 
```

---

### 152. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3430 行
- **函数**: `safeApprove()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3427 | 
   3428 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   3429 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
>> 3430 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3431 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3432 | 
   3433 |             success := and(
```

---

### 153. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 5562 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5559 |                 let fmp := mload(0x40)
   5560 | 
   5561 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 5562 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   5563 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   5564 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   5565 | 
```

---

### 154. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 5563 行
- **函数**: `transfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5560 | 
   5561 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
   5562 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>> 5563 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   5564 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   5565 | 
   5566 |                 success :=
```

---

### 155. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6010 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6007 | 
   6008 |             // Encode wrapped error selector, address, function selector, offset, additional context, size, revert reason
   6009 |             mstore(fmp, wrappedErrorSelector)
>> 6010 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   6011 |             mstore(
   6012 |                 add(fmp, 0x24),
   6013 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
```

---

### 156. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6013 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6010 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   6011 |             mstore(
   6012 |                 add(fmp, 0x24),
>> 6013 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   6014 |             )
   6015 |             // offset revert reason
   6016 |             mstore(add(fmp, 0x44), 0x80)
```

---

### 157. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6028 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6025 |             // additional context
   6026 |             mstore(
   6027 |                 add(fmp, add(0xc4, encodedDataSize)),
>> 6028 |                 and(additionalContext, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   6029 |             )
   6030 |             revert(fmp, add(0xe4, encodedDataSize))
   6031 |         }
```

---

### 158. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6118 行
- **函数**: `poolIdToPoolKey()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6115 | ///  - 2: mapping(address, mapping(Currency => int256)) currencyDelta
   6116 | library SettlementGuard {
   6117 |     /// @dev uint256 internal constant LOCKER_SLOT = uint256(keccak256("SETTLEMENT_LOCKER")) - 1;
>> 6118 |     uint256 internal constant LOCKER_SLOT = 0xedda7c051899c54dd66eaf5e13c031326ab4729812a579bed198ab93fd313d70;
   6119 | 
   6120 |     /// @dev uint256 internal constant UNSETTLED_DELTAS_COUNT = uint256(keccak256("SETTLEMENT_UNSETTLEMENTD_DELTAS_COUNT")) - 1;
   6121 |     uint256 internal constant UNSETTLED_DELTAS_COUNT =
```

---

### 159. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6122 行
- **函数**: `poolIdToPoolKey()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6119 | 
   6120 |     /// @dev uint256 internal constant UNSETTLED_DELTAS_COUNT = uint256(keccak256("SETTLEMENT_UNSETTLEMENTD_DELTAS_COUNT")) - 1;
   6121 |     uint256 internal constant UNSETTLED_DELTAS_COUNT =
>> 6122 |         0xa88ffc6a483ae852b901fb1c3a0df606e2e4461b493434e6643ebdc3ffabd151;
   6123 | 
   6124 |     /// @dev uint256 internal constant CURRENCY_DELTA = uint256(keccak256("SETTLEMENT_CURRENCY_DELTA")) - 1;
   6125 |     uint256 internal constant CURRENCY_DELTA = 0x6dc13502b9ba2a9e8e42c53a1856d632b29d5aab3bcb4a2476bfec06cbd9cf22;
```

---

### 160. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6125 行
- **函数**: `poolIdToPoolKey()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6122 |         0xa88ffc6a483ae852b901fb1c3a0df606e2e4461b493434e6643ebdc3ffabd151;
   6123 | 
   6124 |     /// @dev uint256 internal constant CURRENCY_DELTA = uint256(keccak256("SETTLEMENT_CURRENCY_DELTA")) - 1;
>> 6125 |     uint256 internal constant CURRENCY_DELTA = 0x6dc13502b9ba2a9e8e42c53a1856d632b29d5aab3bcb4a2476bfec06cbd9cf22;
   6126 | 
   6127 |     /// @notice Update the locker address stored in the transient store
   6128 |     /// @param newLocker The new locker address
```

---

### 161. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6136 行
- **函数**: `setLocker()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6133 |         if (currentLocker != address(0) && newLocker != address(0)) revert IVault.LockerAlreadySet(currentLocker);
   6134 | 
   6135 |         assembly ("memory-safe") {
>> 6136 |             tstore(LOCKER_SLOT, and(newLocker, 0xffffffffffffffffffffffffffffffffffffffff))
   6137 |         }
   6138 |     }
   6139 | 
```

---

### 162. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6215 行
- **函数**: `getCurrencyDelta()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6212 | /// calculating how many tokens has been transferred to the vault right after the sync
   6213 | library VaultReserve {
   6214 |     // uint256 constant RESERVE_TYPE_SLOT = uint256(keccak256("reserveType")) - 1;
>> 6215 |     uint256 internal constant RESERVE_TYPE_SLOT = 0x52a1be34b47478d7c75e2b6c3eea1e05dcb8dbb8c6a42c6482d0dca0df53cb27;
   6216 | 
   6217 |     // uint256 constant RESERVE_AMOUNT_SLOT = uint256(keccak256("reserveAmount")) - 1;
   6218 |     uint256 internal constant RESERVE_AMOUNT_SLOT = 0xb0879d96d58bcff08d1fd45590200072d5a8c380da0b5aa1052b48b84e115207;
```

---

### 163. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6218 行
- **函数**: `getCurrencyDelta()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6215 |     uint256 internal constant RESERVE_TYPE_SLOT = 0x52a1be34b47478d7c75e2b6c3eea1e05dcb8dbb8c6a42c6482d0dca0df53cb27;
   6216 | 
   6217 |     // uint256 constant RESERVE_AMOUNT_SLOT = uint256(keccak256("reserveAmount")) - 1;
>> 6218 |     uint256 internal constant RESERVE_AMOUNT_SLOT = 0xb0879d96d58bcff08d1fd45590200072d5a8c380da0b5aa1052b48b84e115207;
   6219 | 
   6220 |     /// @notice Transient store the currency reserve
   6221 |     /// @param currency The currency to be saved
```

---

### 164. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6226 行
- **函数**: `setVaultReserve()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6223 |     function setVaultReserve(Currency currency, uint256 amount) internal {
   6224 |         assembly ("memory-safe") {
   6225 |             // record <currency, amount> in transient storage
>> 6226 |             tstore(RESERVE_TYPE_SLOT, and(currency, 0xffffffffffffffffffffffffffffffffffffffff))
   6227 |             tstore(RESERVE_AMOUNT_SLOT, amount)
   6228 |         }
   6229 |     }
```

---

### 165. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 6967 行
- **函数**: `calculatePositionKey()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6964 |                 0x0,
   6965 |                 or(
   6966 |                     shl(160, and(0xFFFFFF, tickUpper)),
>> 6967 |                     or(shl(184, tickLower), and(owner, 0xffffffffffffffffffffffffffffffffffffffff))
   6968 |                 )
   6969 |             ) // tickLower at [0x06, 0x09), tickUpper at [0x09,0x0c), owner at [0x0c, 0x20)
   6970 |             mstore(0x20, salt) // salt at [0x20, 0x40)
```

---

### 166. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8427 行
- **函数**: `revertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8424 |     function revertWith(bytes4 selector, address addr) internal pure {
   8425 |         assembly ("memory-safe") {
   8426 |             mstore(0, selector)
>> 8427 |             mstore(0x04, and(addr, 0xffffffffffffffffffffffffffffffffffffffff))
   8428 |             revert(0, 0x24)
   8429 |         }
   8430 |     }
```

---

### 167. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8445 行
- **函数**: `revertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8442 |     function revertWith(bytes4 selector, uint160 value) internal pure {
   8443 |         assembly ("memory-safe") {
   8444 |             mstore(0, selector)
>> 8445 |             mstore(0x04, and(value, 0xffffffffffffffffffffffffffffffffffffffff))
   8446 |             revert(0, 0x24)
   8447 |         }
   8448 |     }
```

---

### 168. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8466 行
- **函数**: `revertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8463 |         assembly ("memory-safe") {
   8464 |             let fmp := mload(0x40)
   8465 |             mstore(fmp, selector)
>> 8466 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
   8467 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   8468 |             revert(fmp, 0x44)
   8469 |         }
```

---

### 169. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8467 行
- **函数**: `revertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8464 |             let fmp := mload(0x40)
   8465 |             mstore(fmp, selector)
   8466 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
>> 8467 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   8468 |             revert(fmp, 0x44)
   8469 |         }
   8470 |     }
```

---

### 170. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8477 行
- **函数**: `revertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8474 |         assembly ("memory-safe") {
   8475 |             let fmp := mload(0x40)
   8476 |             mstore(fmp, selector)
>> 8477 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
   8478 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   8479 |             revert(fmp, 0x44)
   8480 |         }
```

---

### 171. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8478 行
- **函数**: `revertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8475 |             let fmp := mload(0x40)
   8476 |             mstore(fmp, selector)
   8477 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
>> 8478 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   8479 |             revert(fmp, 0x44)
   8480 |         }
   8481 |     }
```

---

### 172. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8499 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8496 | 
   8497 |             // Encode wrapped error selector, address, function selector, offset, additional context, size, revert reason
   8498 |             mstore(fmp, wrappedErrorSelector)
>> 8499 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   8500 |             mstore(
   8501 |                 add(fmp, 0x24),
   8502 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
```

---

### 173. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8502 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8499 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   8500 |             mstore(
   8501 |                 add(fmp, 0x24),
>> 8502 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   8503 |             )
   8504 |             // offset revert reason
   8505 |             mstore(add(fmp, 0x44), 0x80)
```

---

### 174. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8517 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8514 |             // additional context
   8515 |             mstore(
   8516 |                 add(fmp, add(0xc4, encodedDataSize)),
>> 8517 |                 and(additionalContext, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   8518 |             )
   8519 |             revert(fmp, add(0xe4, encodedDataSize))
   8520 |         }
```

---

### 175. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8549 行
- **函数**: `mostSignificantBit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8546 |             r := or(r, shl(3, lt(0xff, shr(r, x))))
   8547 |             // forgefmt: disable-next-item
   8548 |             r := or(r, byte(and(0x1f, shr(shr(r, x), 0x8421084210842108cc6318c6db6d54be)),
>> 8549 |                 0x0706060506020500060203020504000106050205030304010505030400000000))
   8550 |         }
   8551 |     }
   8552 | 
```

---

### 176. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8567 行
- **函数**: `leastSignificantBit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8564 |             // Credit to adhusson: https://blog.adhusson.com/cheap-find-first-set-evm/
   8565 |             // forgefmt: disable-next-item
   8566 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
>> 8567 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
   8568 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   8569 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   8570 |             // forgefmt: disable-next-item
```

---

### 177. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8568 行
- **函数**: `leastSignificantBit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8565 |             // forgefmt: disable-next-item
   8566 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
   8567 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
>> 8568 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   8569 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   8570 |             // forgefmt: disable-next-item
   8571 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
```

---

### 178. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8572 行
- **函数**: `leastSignificantBit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8569 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   8570 |             // forgefmt: disable-next-item
   8571 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
>> 8572 |                 0x001f0d1e100c1d070f090b19131c1706010e11080a1a141802121b1503160405))
   8573 |         }
   8574 |     }
   8575 | }
```

---

### 179. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8612 行
- **函数**: `leastSignificantBit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8609 | 
   8610 | /// @notice Library for getting and setting values in the Slot0 type
   8611 | library CLSlot0Library {
>> 8612 |     uint160 internal constant MASK_160_BITS = 0x00FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF;
   8613 |     uint24 internal constant MASK_24_BITS = 0xFFFFFF;
   8614 | 
   8615 |     uint8 internal constant TICK_OFFSET = 160;
```

---

### 180. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8874 行
- **函数**: `getNextSqrtPriceFromAmount0RoundingUp()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8871 |                 assembly ("memory-safe") {
   8872 |                     if iszero(
   8873 |                         and(
>> 8874 |                             eq(div(product, amount), and(sqrtPX96, 0xffffffffffffffffffffffffffffffffffffffff)),
   8875 |                             gt(numerator1, product)
   8876 |                         )
   8877 |                     ) {
```

---

### 181. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8922 行
- **函数**: `getNextSqrtPriceFromAmount1RoundingDown()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8919 | 
   8920 |             // equivalent: if (sqrtPX96 <= quotient) revert NotEnoughLiquidity();
   8921 |             assembly ("memory-safe") {
>> 8922 |                 if iszero(gt(and(sqrtPX96, 0xffffffffffffffffffffffffffffffffffffffff), quotient)) {
   8923 |                     mstore(0, 0x4323a555) // selector for NotEnoughLiquidity()
   8924 |                     revert(0x1c, 0x04)
   8925 |                 }
```

---

### 182. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8949 行
- **函数**: `getNextSqrtPriceFromInput()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8946 |         // equivalent: if (sqrtPX96 == 0 || liquidity == 0) revert InvalidPriceOrLiquidity();
   8947 |         assembly ("memory-safe") {
   8948 |             if or(
>> 8949 |                 iszero(and(sqrtPX96, 0xffffffffffffffffffffffffffffffffffffffff)),
   8950 |                 iszero(and(liquidity, 0xffffffffffffffffffffffffffffffff))
   8951 |             ) {
   8952 |                 mstore(0, 0x4f2461b8) // selector for InvalidPriceOrLiquidity()
```

---

### 183. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 8978 行
- **函数**: `getNextSqrtPriceFromOutput()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8975 |         // equivalent: if (sqrtPX96 == 0 || liquidity == 0) revert InvalidPriceOrLiquidity();
   8976 |         assembly ("memory-safe") {
   8977 |             if or(
>> 8978 |                 iszero(and(sqrtPX96, 0xffffffffffffffffffffffffffffffffffffffff)),
   8979 |                 iszero(and(liquidity, 0xffffffffffffffffffffffffffffffff))
   8980 |             ) {
   8981 |                 mstore(0, 0x4f2461b8) // selector for InvalidPriceOrLiquidity()
```

---

### 184. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 9010 行
- **函数**: `getAmount0Delta()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   9007 | 
   9008 |             // equivalent: if (sqrtRatioAX96 == 0) revert InvalidPrice();
   9009 |             assembly ("memory-safe") {
>> 9010 |                 if iszero(and(sqrtRatioAX96, 0xffffffffffffffffffffffffffffffffffffffff)) {
   9011 |                     mstore(0, 0x00bfc921) // selector for InvalidPrice()
   9012 |                     revert(0x1c, 0x04)
   9013 |                 }
```

---

### 185. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 9029 行
- **函数**: `absDiff()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   9026 |     function absDiff(uint160 a, uint160 b) internal pure returns (uint256 res) {
   9027 |         assembly ("memory-safe") {
   9028 |             let diff :=
>> 9029 |                 sub(and(a, 0xffffffffffffffffffffffffffffffffffffffff), and(b, 0xffffffffffffffffffffffffffffffffffffffff))
   9030 |             // mask = 0 if a >= b else -1 (all 1s)
   9031 |             let mask := sar(255, diff)
   9032 |             // if a >= b, res = a - b = 0 ^ (a - b)
```

---

### 186. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 9182 行
- **函数**: `getSqrtPriceTarget()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   9179 |             // sqrtPriceTargetX96 = max(sqrtPriceNextX96, sqrtPriceLimitX96)
   9180 |             // when zeroForOne == false, nextOrLimit reduces to sqrtPriceNextX96 < sqrtPriceLimitX96
   9181 |             // sqrtPriceTargetX96 = min(sqrtPriceNextX96, sqrtPriceLimitX96)
>> 9182 |             sqrtPriceNextX96 := and(sqrtPriceNextX96, 0xffffffffffffffffffffffffffffffffffffffff)
   9183 |             sqrtPriceLimitX96 := and(sqrtPriceLimitX96, 0xffffffffffffffffffffffffffffffffffffffff)
   9184 |             let nextOrLimit := xor(lt(sqrtPriceNextX96, sqrtPriceLimitX96), and(zeroForOne, 0x1))
   9185 |             let symDiff := xor(sqrtPriceNextX96, sqrtPriceLimitX96)
```

---

### 187. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 9183 行
- **函数**: `getSqrtPriceTarget()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   9180 |             // when zeroForOne == false, nextOrLimit reduces to sqrtPriceNextX96 < sqrtPriceLimitX96
   9181 |             // sqrtPriceTargetX96 = min(sqrtPriceNextX96, sqrtPriceLimitX96)
   9182 |             sqrtPriceNextX96 := and(sqrtPriceNextX96, 0xffffffffffffffffffffffffffffffffffffffff)
>> 9183 |             sqrtPriceLimitX96 := and(sqrtPriceLimitX96, 0xffffffffffffffffffffffffffffffffffffffff)
   9184 |             let nextOrLimit := xor(lt(sqrtPriceNextX96, sqrtPriceLimitX96), and(zeroForOne, 0x1))
   9185 |             let symDiff := xor(sqrtPriceNextX96, sqrtPriceLimitX96)
   9186 |             sqrtPriceTargetX96 := xor(sqrtPriceLimitX96, mul(symDiff, nextOrLimit))
```

---

### 188. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 10742 行
- **函数**: `calculatePositionKey()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   10739 |         // dev same as `positionKey = keccak256(abi.encodePacked(binId, owner, salt))`
   10740 |         // make salt, binId, owner to be tightly packed in memory
   10741 |         assembly ("memory-safe") {
>> 10742 |             mstore(0x0, or(shl(160, binId), and(owner, 0xffffffffffffffffffffffffffffffffffffffff))) // binId at [0x09,0x0c), owner at [0x0c, 0x20)
   10743 |             mstore(0x20, salt) // salt at [0x20, 0x40)
   10744 |             key := keccak256(0x09, 0x37)
   10745 |         }
```

---

### 189. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 11160 行
- **函数**: `mostSignificantBit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   11157 |             r := or(r, shl(3, lt(0xff, shr(r, x))))
   11158 |             // forgefmt: disable-next-item
   11159 |             r := or(r, byte(and(0x1f, shr(shr(r, x), 0x8421084210842108cc6318c6db6d54be)),
>> 11160 |                 0x0706060506020504060203020504030106050205030304010505030400000000))
   11161 |         }
   11162 |     }
   11163 | 
```

---

### 190. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 11178 行
- **函数**: `leastSignificantBit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   11175 |             // Credit to adhusson: https://blog.adhusson.com/cheap-find-first-set-evm/
   11176 |             // forgefmt: disable-next-item
   11177 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
>> 11178 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
   11179 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   11180 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   11181 |             // forgefmt: disable-next-item
```

---

### 191. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 11179 行
- **函数**: `leastSignificantBit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   11176 |             // forgefmt: disable-next-item
   11177 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
   11178 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
>> 11179 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   11180 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   11181 |             // forgefmt: disable-next-item
   11182 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
```

---

### 192. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 11183 行
- **函数**: `leastSignificantBit()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   11180 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   11181 |             // forgefmt: disable-next-item
   11182 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
>> 11183 |                 0x001f0d1e100c1d070f090b19131c1706010e11080a1a141802121b1503160405))
   11184 |         }
   11185 |     }
   11186 | }
```

---

### 193. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1185 行
- **函数**: `bytes32ToAddress()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1182 |     /// typically used when dealing with low-level data operations or when addresses are packed into larger data types.
   1183 | 
   1184 |     function bytes32ToAddress(uint256 param) internal pure returns (address result) {
>> 1185 |         assembly {
   1186 |             result := and(param, ADDRESS_MASK)
   1187 |         }
   1188 |     }
```

---

### 194. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 1533 行
- **函数**: `decodePathRawData()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1530 |     uint256 private constant RAWDATA_WEIGHT_MASK = 0x00000000000000000000ffff0000000000000000000000000000000000000000;
   1531 | 
   1532 |     function decodePathRawData(uint256 rawData) internal pure returns (address poolAddr, uint256 weight, bool reverse) {
>> 1533 |         assembly {
   1534 |             /// @notice poolAddress is the address of the pool where the swap will be executed
   1535 |             poolAddr := and(rawData, RAWDATA_ADDRESS_MASK)
   1536 |             /// @notice by default swap token0 for token1, this field is used to reverse the direction
```

---

### 195. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3338 行
- **函数**: `safeTransferETH()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3335 |         bool success;
   3336 | 
   3337 |         /// @solidity memory-safe-assembly
>> 3338 |         assembly {
   3339 |             // Transfer the ETH and store if it succeeded or not.
   3340 |             success := call(gas(), to, amount, 0, 0, 0, 0)
   3341 |         }
```

---

### 196. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3359 行
- **函数**: `safeTransferFrom()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3356 |         bool success;
   3357 | 
   3358 |         /// @solidity memory-safe-assembly
>> 3359 |         assembly {
   3360 |             // Get a pointer to some free memory.
   3361 |             let freeMemoryPointer := mload(0x40)
   3362 | 
```

---

### 197. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3392 行
- **函数**: `safeTransfer()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3389 |         bool success;
   3390 | 
   3391 |         /// @solidity memory-safe-assembly
>> 3392 |         assembly {
   3393 |             // Get a pointer to some free memory.
   3394 |             let freeMemoryPointer := mload(0x40)
   3395 | 
```

---

### 198. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3424 行
- **函数**: `safeApprove()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3421 |         bool success;
   3422 | 
   3423 |         /// @solidity memory-safe-assembly
>> 3424 |         assembly {
   3425 |             // Get a pointer to some free memory.
   3426 |             let freeMemoryPointer := mload(0x40)
   3427 | 
```

---

### 199. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3545 行
- **函数**: `loadAddress()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3542 | library TransientStorage {
   3543 |     /// @notice Load an address from transient storage.
   3544 |     function loadAddress(uint256 slot) internal view returns (address value) {
>> 3545 |         assembly {
   3546 |             value := tload(slot)
   3547 |         }
   3548 |     }
```

---

### 200. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3552 行
- **函数**: `storeAddress()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3549 | 
   3550 |     /// @notice Store an address in transient storage.
   3551 |     function storeAddress(uint256 slot, address value) internal {
>> 3552 |         assembly {
   3553 |             tstore(slot, value)
   3554 |         }
   3555 |     }
```

---

### 201. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3669 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3666 |         uint256 r = ratio;
   3667 |         uint256 msb = 0;
   3668 | 
>> 3669 |         assembly {
   3670 |             let f := shl(7, gt(r, 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF))
   3671 |             msb := or(msb, f)
   3672 |             r := shr(f, r)
```

---

### 202. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3674 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3671 |             msb := or(msb, f)
   3672 |             r := shr(f, r)
   3673 |         }
>> 3674 |         assembly {
   3675 |             let f := shl(6, gt(r, 0xFFFFFFFFFFFFFFFF))
   3676 |             msb := or(msb, f)
   3677 |             r := shr(f, r)
```

---

### 203. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3679 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3676 |             msb := or(msb, f)
   3677 |             r := shr(f, r)
   3678 |         }
>> 3679 |         assembly {
   3680 |             let f := shl(5, gt(r, 0xFFFFFFFF))
   3681 |             msb := or(msb, f)
   3682 |             r := shr(f, r)
```

---

### 204. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3684 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3681 |             msb := or(msb, f)
   3682 |             r := shr(f, r)
   3683 |         }
>> 3684 |         assembly {
   3685 |             let f := shl(4, gt(r, 0xFFFF))
   3686 |             msb := or(msb, f)
   3687 |             r := shr(f, r)
```

---

### 205. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3689 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3686 |             msb := or(msb, f)
   3687 |             r := shr(f, r)
   3688 |         }
>> 3689 |         assembly {
   3690 |             let f := shl(3, gt(r, 0xFF))
   3691 |             msb := or(msb, f)
   3692 |             r := shr(f, r)
```

---

### 206. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3694 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3691 |             msb := or(msb, f)
   3692 |             r := shr(f, r)
   3693 |         }
>> 3694 |         assembly {
   3695 |             let f := shl(2, gt(r, 0xF))
   3696 |             msb := or(msb, f)
   3697 |             r := shr(f, r)
```

---

### 207. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3699 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3696 |             msb := or(msb, f)
   3697 |             r := shr(f, r)
   3698 |         }
>> 3699 |         assembly {
   3700 |             let f := shl(1, gt(r, 0x3))
   3701 |             msb := or(msb, f)
   3702 |             r := shr(f, r)
```

---

### 208. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3704 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3701 |             msb := or(msb, f)
   3702 |             r := shr(f, r)
   3703 |         }
>> 3704 |         assembly {
   3705 |             let f := gt(r, 0x1)
   3706 |             msb := or(msb, f)
   3707 |         }
```

---

### 209. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3714 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3711 | 
   3712 |         int256 log_2 = (int256(msb) - 128) << 64;
   3713 | 
>> 3714 |         assembly {
   3715 |             r := shr(127, mul(r, r))
   3716 |             let f := shr(128, r)
   3717 |             log_2 := or(log_2, shl(63, f))
```

---

### 210. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3720 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3717 |             log_2 := or(log_2, shl(63, f))
   3718 |             r := shr(f, r)
   3719 |         }
>> 3720 |         assembly {
   3721 |             r := shr(127, mul(r, r))
   3722 |             let f := shr(128, r)
   3723 |             log_2 := or(log_2, shl(62, f))
```

---

### 211. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3726 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3723 |             log_2 := or(log_2, shl(62, f))
   3724 |             r := shr(f, r)
   3725 |         }
>> 3726 |         assembly {
   3727 |             r := shr(127, mul(r, r))
   3728 |             let f := shr(128, r)
   3729 |             log_2 := or(log_2, shl(61, f))
```

---

### 212. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3732 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3729 |             log_2 := or(log_2, shl(61, f))
   3730 |             r := shr(f, r)
   3731 |         }
>> 3732 |         assembly {
   3733 |             r := shr(127, mul(r, r))
   3734 |             let f := shr(128, r)
   3735 |             log_2 := or(log_2, shl(60, f))
```

---

### 213. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3738 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3735 |             log_2 := or(log_2, shl(60, f))
   3736 |             r := shr(f, r)
   3737 |         }
>> 3738 |         assembly {
   3739 |             r := shr(127, mul(r, r))
   3740 |             let f := shr(128, r)
   3741 |             log_2 := or(log_2, shl(59, f))
```

---

### 214. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3744 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3741 |             log_2 := or(log_2, shl(59, f))
   3742 |             r := shr(f, r)
   3743 |         }
>> 3744 |         assembly {
   3745 |             r := shr(127, mul(r, r))
   3746 |             let f := shr(128, r)
   3747 |             log_2 := or(log_2, shl(58, f))
```

---

### 215. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3750 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3747 |             log_2 := or(log_2, shl(58, f))
   3748 |             r := shr(f, r)
   3749 |         }
>> 3750 |         assembly {
   3751 |             r := shr(127, mul(r, r))
   3752 |             let f := shr(128, r)
   3753 |             log_2 := or(log_2, shl(57, f))
```

---

### 216. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3756 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3753 |             log_2 := or(log_2, shl(57, f))
   3754 |             r := shr(f, r)
   3755 |         }
>> 3756 |         assembly {
   3757 |             r := shr(127, mul(r, r))
   3758 |             let f := shr(128, r)
   3759 |             log_2 := or(log_2, shl(56, f))
```

---

### 217. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3762 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3759 |             log_2 := or(log_2, shl(56, f))
   3760 |             r := shr(f, r)
   3761 |         }
>> 3762 |         assembly {
   3763 |             r := shr(127, mul(r, r))
   3764 |             let f := shr(128, r)
   3765 |             log_2 := or(log_2, shl(55, f))
```

---

### 218. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3768 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3765 |             log_2 := or(log_2, shl(55, f))
   3766 |             r := shr(f, r)
   3767 |         }
>> 3768 |         assembly {
   3769 |             r := shr(127, mul(r, r))
   3770 |             let f := shr(128, r)
   3771 |             log_2 := or(log_2, shl(54, f))
```

---

### 219. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3774 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3771 |             log_2 := or(log_2, shl(54, f))
   3772 |             r := shr(f, r)
   3773 |         }
>> 3774 |         assembly {
   3775 |             r := shr(127, mul(r, r))
   3776 |             let f := shr(128, r)
   3777 |             log_2 := or(log_2, shl(53, f))
```

---

### 220. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3780 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3777 |             log_2 := or(log_2, shl(53, f))
   3778 |             r := shr(f, r)
   3779 |         }
>> 3780 |         assembly {
   3781 |             r := shr(127, mul(r, r))
   3782 |             let f := shr(128, r)
   3783 |             log_2 := or(log_2, shl(52, f))
```

---

### 221. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3786 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3783 |             log_2 := or(log_2, shl(52, f))
   3784 |             r := shr(f, r)
   3785 |         }
>> 3786 |         assembly {
   3787 |             r := shr(127, mul(r, r))
   3788 |             let f := shr(128, r)
   3789 |             log_2 := or(log_2, shl(51, f))
```

---

### 222. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 3792 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3789 |             log_2 := or(log_2, shl(51, f))
   3790 |             r := shr(f, r)
   3791 |         }
>> 3792 |         assembly {
   3793 |             r := shr(127, mul(r, r))
   3794 |             let f := shr(128, r)
   3795 |             log_2 := or(log_2, shl(50, f))
```

---

### 223. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x40A1Fe393A7F566F27dF6acE18e6773be844dAfc` 第 4968 行
- **函数**: `toUint()`
- **合约**: `Aggregator`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4965 |      */
   4966 |     function toUint(bool b) internal pure returns (uint256 u) {
   4967 |         /// @solidity memory-safe-assembly
>> 4968 |         assembly {
   4969 |             u := iszero(iszero(b))
   4970 |         }
   4971 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*