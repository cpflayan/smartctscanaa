# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:02:20
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` |
| contract_name | `BTitanXMatrix` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/test.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655006` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 22 |
| 🟢 LOW | 12 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 188 行
- **函数**: `initializePartners()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in BTitanXMatrix.initializePartners(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#188-203):
	External calls:
	- _registerPartner(partner2,2) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#195)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(TREASURY_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#603)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(ROYAL_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#593)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(receiver,amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#576)
		- IRoyaltyCardNFT(ROYAL_RANK1_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#522)
		- IRoyaltyCardNFT(ROYAL_RANK2_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#524)
		- IRoyaltyCardNFT(ROYAL_RANK3_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#526)
		- IRoyaltyCardNFT(ROYAL_RANK4_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#528)
		- IRegistrationPassNFT(REGISTRATION_PASS_NFT_CONTRACT).mint(userAddress,currentUserId) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#226)
	- _registerPartner(partner3,3) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#198)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(TREASURY_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#603)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(ROYAL_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#593)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(receiver,amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#576)
		- IRoyaltyCardNFT(ROYAL_RANK1_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#522)
		- IRoyaltyCardNFT(ROYAL_RANK2_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#524)
		- IRoyaltyCardNFT(ROYAL_RANK3_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#526)
		- IRoyaltyCardNFT(ROYAL_RANK4_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#528)
		- IRegistrationPassNFT(REGISTRATION_PASS_NFT_CONTRACT).mint(userAddress,currentUserId) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#226)
	State variables written after the call(s):
	- _registerPartner(partner3,3) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#198)
		- idToAddress[currentUserId] = userAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#216)
	BTitanXMatrix.idToAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#65) can be used in cross function reentrancies:
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.idToAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#65)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.registrationSys(uint256,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#177-185)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- partnersInitialized = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#202)
	BTitanXMatrix.partnersInitialized (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#69) can be used in cross function reentrancies:
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix.initializePartners(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#188-203)
	- BTitanXMatrix.partnersInitialized (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#69)
	- _registerPartner(partner3,3) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#198)
		- users[userAddress].activeLevels[nextLevel] = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#508)
		- matrix.referrals = new address[](0) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#536)
		- matrix.reinvestCount ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#537)
		- users[userAddress].xMatrix[nextLevel].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#511)
		- users[userAddress].id = currentUserId (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#213)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#538)
		- users[userAddress].referrer = referrerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#214)
		- matrix.lastSpillUnderReceiverIndex = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#539)
		- users[userAddress].referrerId = referrerId (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#215)
		- matrix.referrals.push(_newUser) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#392)
		- users[userAddress].xMatrix[level].currentReferrer = freeReferrerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#542)
		- users[receiver].totalIncome += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#585)
		- users[_referrer].teamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#395)
		- users[receiver].xMatrix[level].totalEarning += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#586)
		- users[userAddress].activeLevels[1] = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#218)
		- matrix.totalTeamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#397)
		- users[userAddress].registrationTimestamp = block.timestamp (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#219)
		- users[referrerAddress].directReferrals.push(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#222)
		- matrix.lastSpillUnderReceiverIndex = (idx + 1) % directs.length (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#647)
		- users[userAddress].xMatrix[1].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#235)
		- matrix.heldTokenForUpgrade = amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#433)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#443)
	BTitanXMatrix.users (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#64) can be used in cross function reentrancies:
	- BTitanXMatrix._findEligibleDownlineUser(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#636-672)
	- BTitanXMatrix._findEligibleUplineTarget(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#614-633)
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._isEligibleForSelfPayment(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#499-504)
	- BTitanXMatrix._processNewPlacement(address,address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#379-494)
	- BTitanXMatrix._recycleCurrentLevel(address,uint8,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#533-546)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix._sendToRoyalPool(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#592-599)
	- BTitanXMatrix._sendTokenDividends(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#572-589)
	- BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getActiveLevelsCount(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#676-682)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.isUserExists(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#728-730)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- BTitanXMatrix.usersXMatrix(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#737-751)
	- BTitanXMatrix.usersXMatrixReferrals(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#753-757)

**代码片段**:
```solidity
    185 |     }
    186 | 
    187 |     // Function to initialize partners (ID 2 and ID 3) and lock the Owner's direct referral slot
>>  188 |     function initializePartners(address partner2, address partner3) external onlyOwner {
    189 |         require(!partnersInitialized, "Partners already initialized.");
    190 |         require(!isUserExists(partner2), "Partner 2 exists.");
    191 |         require(!isUserExists(partner3), "Partner 3 exists.");
```

---

### 2. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 177 行
- **函数**: `registrationSys()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in BTitanXMatrix.registrationSys(uint256,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#177-185):
	External calls:
	- require(bool,string)(IERC20(BTCB_TOKEN_ADDRESS).transferFrom(msg.sender,address(this),levelTokenCost[1]),BTC transfer failed for registration) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#182)
	- _registration(userAddress,referrerAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#184)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(TREASURY_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#603)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(ROYAL_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#593)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(receiver,amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#576)
		- IRoyaltyCardNFT(ROYAL_RANK1_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#522)
		- IRoyaltyCardNFT(ROYAL_RANK2_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#524)
		- IRoyaltyCardNFT(ROYAL_RANK3_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#526)
		- IRoyaltyCardNFT(ROYAL_RANK4_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#528)
		- IRegistrationPassNFT(REGISTRATION_PASS_NFT_CONTRACT).mint(userAddress,currentUserId) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#359)
	State variables written after the call(s):
	- _registration(userAddress,referrerAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#184)
		- idToAddress[currentUserId] = userAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#352)
	BTitanXMatrix.idToAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#65) can be used in cross function reentrancies:
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.idToAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#65)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.registrationSys(uint256,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#177-185)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- _registration(userAddress,referrerAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#184)
		- users[userAddress].activeLevels[nextLevel] = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#508)
		- matrix.referrals = new address[](0) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#536)
		- matrix.reinvestCount ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#537)
		- users[userAddress].xMatrix[nextLevel].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#511)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#538)
		- matrix.lastSpillUnderReceiverIndex = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#539)
		- users[userAddress].id = currentUserId (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#349)
		- matrix.referrals.push(_newUser) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#392)
		- users[userAddress].xMatrix[level].currentReferrer = freeReferrerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#542)
		- users[userAddress].referrer = referrerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#350)
		- users[receiver].totalIncome += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#585)
		- users[_referrer].teamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#395)
		- users[userAddress].referrerId = referrerId (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#351)
		- users[receiver].xMatrix[level].totalEarning += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#586)
		- matrix.totalTeamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#397)
		- users[userAddress].activeLevels[1] = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#354)
		- users[userAddress].registrationTimestamp = block.timestamp (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#355)
		- matrix.lastSpillUnderReceiverIndex = (idx + 1) % directs.length (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#647)
		- users[referrerAddress].directReferrals.push(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#366)
		- users[userAddress].xMatrix[1].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#373)
		- matrix.heldTokenForUpgrade = amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#433)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#443)
	BTitanXMatrix.users (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#64) can be used in cross function reentrancies:
	- BTitanXMatrix._findEligibleDownlineUser(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#636-672)
	- BTitanXMatrix._findEligibleUplineTarget(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#614-633)
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._isEligibleForSelfPayment(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#499-504)
	- BTitanXMatrix._processNewPlacement(address,address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#379-494)
	- BTitanXMatrix._recycleCurrentLevel(address,uint8,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#533-546)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix._sendToRoyalPool(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#592-599)
	- BTitanXMatrix._sendTokenDividends(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#572-589)
	- BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getActiveLevelsCount(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#676-682)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.isUserExists(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#728-730)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- BTitanXMatrix.usersXMatrix(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#737-751)
	- BTitanXMatrix.usersXMatrixReferrals(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#753-757)

**代码片段**:
```solidity
    174 |     }
    175 | 
    176 |     // External registration function for owner
>>  177 |     function registrationSys(uint referrerId, address userAddress) external onlyOwner {
    178 |         address referrerAddress = idToAddress[referrerId];
    179 |         require(isUserExists(referrerAddress), "Referrer does not exist");
    180 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 206 行
- **函数**: `_registerPartner()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237):
	External calls:
	- IRegistrationPassNFT(REGISTRATION_PASS_NFT_CONTRACT).mint(userAddress,currentUserId) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#226)
	- _processNewPlacement(userAddress,newReferrer,1) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#236)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(TREASURY_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#603)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(ROYAL_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#593)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(receiver,amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#576)
		- IRoyaltyCardNFT(ROYAL_RANK1_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#522)
		- IRoyaltyCardNFT(ROYAL_RANK2_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#524)
		- IRoyaltyCardNFT(ROYAL_RANK3_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#526)
		- IRoyaltyCardNFT(ROYAL_RANK4_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#528)
	State variables written after the call(s):
	- _processNewPlacement(userAddress,newReferrer,1) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#236)
		- users[userAddress].activeLevels[nextLevel] = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#508)
		- matrix.referrals = new address[](0) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#536)
		- users[userAddress].xMatrix[nextLevel].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#511)
		- matrix.reinvestCount ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#537)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#538)
		- matrix.lastSpillUnderReceiverIndex = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#539)
		- users[userAddress].xMatrix[level].currentReferrer = freeReferrerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#542)
		- users[receiver].totalIncome += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#585)
		- matrix.referrals.push(_newUser) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#392)
		- users[_referrer].teamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#395)
		- users[receiver].xMatrix[level].totalEarning += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#586)
		- matrix.totalTeamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#397)
		- matrix.lastSpillUnderReceiverIndex = (idx + 1) % directs.length (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#647)
		- matrix.heldTokenForUpgrade = amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#433)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#443)
	BTitanXMatrix.users (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#64) can be used in cross function reentrancies:
	- BTitanXMatrix._findEligibleDownlineUser(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#636-672)
	- BTitanXMatrix._findEligibleUplineTarget(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#614-633)
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._isEligibleForSelfPayment(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#499-504)
	- BTitanXMatrix._processNewPlacement(address,address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#379-494)
	- BTitanXMatrix._recycleCurrentLevel(address,uint8,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#533-546)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix._sendToRoyalPool(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#592-599)
	- BTitanXMatrix._sendTokenDividends(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#572-589)
	- BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getActiveLevelsCount(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#676-682)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.isUserExists(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#728-730)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- BTitanXMatrix.usersXMatrix(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#737-751)
	- BTitanXMatrix.usersXMatrixReferrals(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#753-757)

**代码片段**:
```solidity
    203 |     }
    204 | 
    205 |     // Helper function for partner registration (no token transfer, only state/placement)
>>  206 |     function _registerPartner(address userAddress, uint partnerId) private {
    207 |         // ID 1 (Owner) is the initial referrer for both
    208 |         address referrerAddress = owner;
    209 |         uint referrerId = 1;
```

---

### 4. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 206 行
- **函数**: `_registerPartner()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237):
	External calls:
	- IRegistrationPassNFT(REGISTRATION_PASS_NFT_CONTRACT).mint(userAddress,currentUserId) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#226)
	State variables written after the call(s):
	- users[userAddress].xMatrix[1].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#235)
	BTitanXMatrix.users (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#64) can be used in cross function reentrancies:
	- BTitanXMatrix._findEligibleDownlineUser(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#636-672)
	- BTitanXMatrix._findEligibleUplineTarget(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#614-633)
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._isEligibleForSelfPayment(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#499-504)
	- BTitanXMatrix._processNewPlacement(address,address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#379-494)
	- BTitanXMatrix._recycleCurrentLevel(address,uint8,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#533-546)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix._sendToRoyalPool(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#592-599)
	- BTitanXMatrix._sendTokenDividends(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#572-589)
	- BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getActiveLevelsCount(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#676-682)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.isUserExists(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#728-730)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- BTitanXMatrix.usersXMatrix(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#737-751)
	- BTitanXMatrix.usersXMatrixReferrals(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#753-757)

**代码片段**:
```solidity
    203 |     }
    204 | 
    205 |     // Helper function for partner registration (no token transfer, only state/placement)
>>  206 |     function _registerPartner(address userAddress, uint partnerId) private {
    207 |         // ID 1 (Owner) is the initial referrer for both
    208 |         address referrerAddress = owner;
    209 |         uint referrerId = 1;
```

---

### 5. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 507 行
- **函数**: `_upgradeLevel()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517):
	External calls:
	- _checkForRoyalCardMint(userAddress,nextLevel) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#513)
		- IRoyaltyCardNFT(ROYAL_RANK1_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#522)
		- IRoyaltyCardNFT(ROYAL_RANK2_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#524)
		- IRoyaltyCardNFT(ROYAL_RANK3_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#526)
		- IRoyaltyCardNFT(ROYAL_RANK4_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#528)
	- _processNewPlacement(userAddress,newReferrer,nextLevel) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#514)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(TREASURY_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#603)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(ROYAL_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#593)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(receiver,amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#576)
		- IRoyaltyCardNFT(ROYAL_RANK1_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#522)
		- IRoyaltyCardNFT(ROYAL_RANK2_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#524)
		- IRoyaltyCardNFT(ROYAL_RANK3_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#526)
		- IRoyaltyCardNFT(ROYAL_RANK4_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#528)
	State variables written after the call(s):
	- _processNewPlacement(userAddress,newReferrer,nextLevel) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#514)
		- users[userAddress].activeLevels[nextLevel] = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#508)
		- matrix.referrals = new address[](0) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#536)
		- users[userAddress].xMatrix[nextLevel].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#511)
		- matrix.reinvestCount ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#537)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#538)
		- matrix.lastSpillUnderReceiverIndex = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#539)
		- users[userAddress].xMatrix[level].currentReferrer = freeReferrerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#542)
		- users[receiver].totalIncome += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#585)
		- matrix.referrals.push(_newUser) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#392)
		- users[_referrer].teamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#395)
		- users[receiver].xMatrix[level].totalEarning += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#586)
		- matrix.totalTeamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#397)
		- matrix.lastSpillUnderReceiverIndex = (idx + 1) % directs.length (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#647)
		- matrix.heldTokenForUpgrade = amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#433)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#443)
	BTitanXMatrix.users (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#64) can be used in cross function reentrancies:
	- BTitanXMatrix._findEligibleDownlineUser(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#636-672)
	- BTitanXMatrix._findEligibleUplineTarget(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#614-633)
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._isEligibleForSelfPayment(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#499-504)
	- BTitanXMatrix._processNewPlacement(address,address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#379-494)
	- BTitanXMatrix._recycleCurrentLevel(address,uint8,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#533-546)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix._sendToRoyalPool(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#592-599)
	- BTitanXMatrix._sendTokenDividends(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#572-589)
	- BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getActiveLevelsCount(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#676-682)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.isUserExists(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#728-730)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- BTitanXMatrix.usersXMatrix(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#737-751)
	- BTitanXMatrix.usersXMatrixReferrals(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#753-757)

**代码片段**:
```solidity
    504 |     }
    505 | 
    506 |     // Handles level activation, Royalty Card check, and placement in the new matrix
>>  507 |     function _upgradeLevel(address userAddress, uint8 nextLevel) private {
    508 |         users[userAddress].activeLevels[nextLevel] = true;
    509 |         
    510 |         address newReferrer = _findFreeReferrer(userAddress, nextLevel);
```

---

### 6. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 166 行
- **函数**: `registrationExt()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in BTitanXMatrix.registrationExt(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#166-174):
	External calls:
	- require(bool,string)(IERC20(BTCB_TOKEN_ADDRESS).transferFrom(msg.sender,address(this),levelTokenCost[1]),BTC transfer failed for registration) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#171)
	- _registration(msg.sender,referrerAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#173)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(TREASURY_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#603)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(ROYAL_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#593)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(receiver,amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#576)
		- IRoyaltyCardNFT(ROYAL_RANK1_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#522)
		- IRoyaltyCardNFT(ROYAL_RANK2_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#524)
		- IRoyaltyCardNFT(ROYAL_RANK3_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#526)
		- IRoyaltyCardNFT(ROYAL_RANK4_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#528)
		- IRegistrationPassNFT(REGISTRATION_PASS_NFT_CONTRACT).mint(userAddress,currentUserId) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#359)
	State variables written after the call(s):
	- _registration(msg.sender,referrerAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#173)
		- idToAddress[currentUserId] = userAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#352)
	BTitanXMatrix.idToAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#65) can be used in cross function reentrancies:
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.idToAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#65)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.registrationSys(uint256,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#177-185)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- _registration(msg.sender,referrerAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#173)
		- users[userAddress].activeLevels[nextLevel] = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#508)
		- matrix.referrals = new address[](0) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#536)
		- matrix.reinvestCount ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#537)
		- users[userAddress].xMatrix[nextLevel].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#511)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#538)
		- matrix.lastSpillUnderReceiverIndex = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#539)
		- users[userAddress].id = currentUserId (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#349)
		- matrix.referrals.push(_newUser) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#392)
		- users[userAddress].xMatrix[level].currentReferrer = freeReferrerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#542)
		- users[userAddress].referrer = referrerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#350)
		- users[receiver].totalIncome += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#585)
		- users[_referrer].teamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#395)
		- users[userAddress].referrerId = referrerId (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#351)
		- users[receiver].xMatrix[level].totalEarning += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#586)
		- matrix.totalTeamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#397)
		- users[userAddress].activeLevels[1] = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#354)
		- users[userAddress].registrationTimestamp = block.timestamp (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#355)
		- matrix.lastSpillUnderReceiverIndex = (idx + 1) % directs.length (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#647)
		- users[referrerAddress].directReferrals.push(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#366)
		- users[userAddress].xMatrix[1].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#373)
		- matrix.heldTokenForUpgrade = amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#433)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#443)
	BTitanXMatrix.users (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#64) can be used in cross function reentrancies:
	- BTitanXMatrix._findEligibleDownlineUser(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#636-672)
	- BTitanXMatrix._findEligibleUplineTarget(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#614-633)
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._isEligibleForSelfPayment(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#499-504)
	- BTitanXMatrix._processNewPlacement(address,address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#379-494)
	- BTitanXMatrix._recycleCurrentLevel(address,uint8,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#533-546)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix._sendToRoyalPool(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#592-599)
	- BTitanXMatrix._sendTokenDividends(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#572-589)
	- BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getActiveLevelsCount(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#676-682)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.isUserExists(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#728-730)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- BTitanXMatrix.usersXMatrix(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#737-751)
	- BTitanXMatrix.usersXMatrixReferrals(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#753-757)

**代码片段**:
```solidity
    163 |     // --- PUBLIC FUNCTIONS ---
    164 | 
    165 |     // External registration function for public - protected against reentrancy
>>  166 |     function registrationExt(uint referrerId) external nonReentrant {
    167 |         address referrerAddress = idToAddress[referrerId];
    168 |         require(isUserExists(referrerAddress), "Referrer does not exist");
    169 | 
```

---

### 7. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 339 行
- **函数**: `_registration()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376):
	External calls:
	- IRegistrationPassNFT(REGISTRATION_PASS_NFT_CONTRACT).mint(userAddress,currentUserId) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#359)
	State variables written after the call(s):
	- users[referrerAddress].directReferrals.push(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#366)
	BTitanXMatrix.users (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#64) can be used in cross function reentrancies:
	- BTitanXMatrix._findEligibleDownlineUser(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#636-672)
	- BTitanXMatrix._findEligibleUplineTarget(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#614-633)
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._isEligibleForSelfPayment(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#499-504)
	- BTitanXMatrix._processNewPlacement(address,address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#379-494)
	- BTitanXMatrix._recycleCurrentLevel(address,uint8,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#533-546)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix._sendToRoyalPool(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#592-599)
	- BTitanXMatrix._sendTokenDividends(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#572-589)
	- BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getActiveLevelsCount(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#676-682)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.isUserExists(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#728-730)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- BTitanXMatrix.usersXMatrix(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#737-751)
	- BTitanXMatrix.usersXMatrixReferrals(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#753-757)
	- users[userAddress].xMatrix[1].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#373)
	BTitanXMatrix.users (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#64) can be used in cross function reentrancies:
	- BTitanXMatrix._findEligibleDownlineUser(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#636-672)
	- BTitanXMatrix._findEligibleUplineTarget(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#614-633)
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._isEligibleForSelfPayment(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#499-504)
	- BTitanXMatrix._processNewPlacement(address,address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#379-494)
	- BTitanXMatrix._recycleCurrentLevel(address,uint8,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#533-546)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix._sendToRoyalPool(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#592-599)
	- BTitanXMatrix._sendTokenDividends(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#572-589)
	- BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getActiveLevelsCount(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#676-682)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.isUserExists(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#728-730)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- BTitanXMatrix.usersXMatrix(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#737-751)
	- BTitanXMatrix.usersXMatrixReferrals(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#753-757)

**代码片段**:
```solidity
    336 |     // --- CORE LOGIC FUNCTIONS ---
    337 |     
    338 |     // Internal function handles the core registration logic
>>  339 |     function _registration(address userAddress, address referrerAddress) private {
    340 |         // Track total investment
    341 |         uint256 cost = levelTokenCost[1];
    342 |         totalProjectInvestment += cost;
```

---

### 8. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 339 行
- **函数**: `_registration()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376):
	External calls:
	- IRegistrationPassNFT(REGISTRATION_PASS_NFT_CONTRACT).mint(userAddress,currentUserId) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#359)
	- _processNewPlacement(userAddress,newReferrer,1) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#375)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(TREASURY_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#603)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(ROYAL_POOL_ADDRESS,_amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#593)
		- success = IERC20(BTCB_TOKEN_ADDRESS).transfer(receiver,amount) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#576)
		- IRoyaltyCardNFT(ROYAL_RANK1_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#522)
		- IRoyaltyCardNFT(ROYAL_RANK2_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#524)
		- IRoyaltyCardNFT(ROYAL_RANK3_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#526)
		- IRoyaltyCardNFT(ROYAL_RANK4_NFT_CONTRACT).mint(userAddress) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#528)
	State variables written after the call(s):
	- _processNewPlacement(userAddress,newReferrer,1) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#375)
		- users[userAddress].activeLevels[nextLevel] = true (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#508)
		- matrix.referrals = new address[](0) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#536)
		- users[userAddress].xMatrix[nextLevel].currentReferrer = newReferrer (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#511)
		- matrix.reinvestCount ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#537)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#538)
		- matrix.lastSpillUnderReceiverIndex = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#539)
		- users[userAddress].xMatrix[level].currentReferrer = freeReferrerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#542)
		- users[receiver].totalIncome += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#585)
		- matrix.referrals.push(_newUser) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#392)
		- users[_referrer].teamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#395)
		- users[receiver].xMatrix[level].totalEarning += amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#586)
		- matrix.totalTeamSize ++ (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#397)
		- matrix.lastSpillUnderReceiverIndex = (idx + 1) % directs.length (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#647)
		- matrix.heldTokenForUpgrade = amount (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#433)
		- matrix.heldTokenForUpgrade = 0 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#443)
	BTitanXMatrix.users (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#64) can be used in cross function reentrancies:
	- BTitanXMatrix._findEligibleDownlineUser(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#636-672)
	- BTitanXMatrix._findEligibleUplineTarget(address,address,uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#614-633)
	- BTitanXMatrix._findFreeReferrer(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#549-568)
	- BTitanXMatrix._isEligibleForSelfPayment(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#499-504)
	- BTitanXMatrix._processNewPlacement(address,address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#379-494)
	- BTitanXMatrix._recycleCurrentLevel(address,uint8,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#533-546)
	- BTitanXMatrix._registerPartner(address,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#206-237)
	- BTitanXMatrix._registration(address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#339-376)
	- BTitanXMatrix._sendToRoyalPool(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#592-599)
	- BTitanXMatrix._sendTokenDividends(address,address,uint8,uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#572-589)
	- BTitanXMatrix._upgradeLevel(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#507-517)
	- BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#108-161)
	- BTitanXMatrix.getActiveLevelsCount(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#676-682)
	- BTitanXMatrix.getDirectPartnerAddresses(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#710-714)
	- BTitanXMatrix.getDirectPartnerIds(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#716-726)
	- BTitanXMatrix.getUserDetails(uint256) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#684-708)
	- BTitanXMatrix.isUserExists(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#728-730)
	- BTitanXMatrix.isUserSlotActive(uint256,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#732-735)
	- BTitanXMatrix.transferOwnership(address) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#241-299)
	- BTitanXMatrix.usersXMatrix(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#737-751)
	- BTitanXMatrix.usersXMatrixReferrals(address,uint8) (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#753-757)

**代码片段**:
```solidity
    336 |     // --- CORE LOGIC FUNCTIONS ---
    337 |     
    338 |     // Internal function handles the core registration logic
>>  339 |     function _registration(address userAddress, address referrerAddress) private {
    340 |         // Track total investment
    341 |         uint256 cost = levelTokenCost[1];
    342 |         totalProjectInvestment += cost;
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 8 行
- **函数**: `transfer()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      5 | 
      6 | // Standard ERC-20 Interface for the BTC Token (BEP-20)
      7 | interface IERC20 {
>>    8 |     function transfer(address recipient, uint256 amount) external returns (bool);
      9 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     10 | }
     11 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 9 行
- **函数**: `transferFrom()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      6 | // Standard ERC-20 Interface for the BTC Token (BEP-20)
      7 | interface IERC20 {
      8 |     function transfer(address recipient, uint256 amount) external returns (bool);
>>    9 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     10 | }
     11 | 
     12 | // --- NFT INTERFACES ---
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 549 行
- **函数**: `_findFreeReferrer()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    546 |     }
    547 |     
    548 |     // Finds the next available spot in the matrix chain, falls back to owner
>>  549 |     function _findFreeReferrer(address userAddress, uint8 level) public view returns(address referrer) {
    550 |         uint currentReferrerId = users[userAddress].referrerId;
    551 |         
    552 |         while (true) {
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 676 行
- **函数**: `getActiveLevelsCount()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    673 | 
    674 |     // --- VIEW FUNCTIONS ---
    675 | 
>>  676 |     function getActiveLevelsCount(address userAddress) public view returns (uint8 count) {
    677 |         for (uint8 i = 1; i <= LAST_LEVEL; i++) {
    678 |             if (users[userAddress].activeLevels[i]) {
    679 |                 count++;
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 684 行
- **函数**: `getUserDetails()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    681 |         }
    682 |     }
    683 |     
>>  684 |     function getUserDetails(uint userId) public view returns (
    685 |         address userAddress,
    686 |         address referrerAddress,
    687 |         uint referrerId,
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 710 行
- **函数**: `getDirectPartnerAddresses()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    707 |         );
    708 |     }
    709 |     
>>  710 |     function getDirectPartnerAddresses(uint userId) public view returns (address[] memory) {
    711 |         address userAddress = idToAddress[userId];
    712 |         require(isUserExists(userAddress), "User does not exist");
    713 |         return users[userAddress].directReferrals;
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 716 行
- **函数**: `getDirectPartnerIds()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    713 |         return users[userAddress].directReferrals;
    714 |     }
    715 |     
>>  716 |     function getDirectPartnerIds(uint userId) public view returns (uint[] memory) {
    717 |         address userAddress = idToAddress[userId];
    718 |         require(isUserExists(userAddress), "User does not exist");
    719 |         address[] memory directAddresses = users[userAddress].directReferrals;
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 728 行
- **函数**: `isUserExists()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    725 |         return directIds;
    726 |     }
    727 |     
>>  728 |     function isUserExists(address user) public view returns (bool) {
    729 |         return (users[user].id != 0);
    730 |     }
    731 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 732 行
- **函数**: `isUserSlotActive()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    729 |         return (users[user].id != 0);
    730 |     }
    731 | 
>>  732 |     function isUserSlotActive(uint256 userId, uint8 slot) public view returns (bool) {
    733 |         address userAddress = idToAddress[userId];
    734 |         return users[userAddress].activeLevels[slot];
    735 |     }
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 737 行
- **函数**: `usersXMatrix()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    734 |         return users[userAddress].activeLevels[slot];
    735 |     }
    736 |     
>>  737 |     function usersXMatrix(address userAddress, uint8 level) public view returns(
    738 |         address currentReferrer, 
    739 |         uint reinvestCount, 
    740 |         uint heldTokenForUpgrade, 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 753 行
- **函数**: `usersXMatrixReferrals()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    750 |                 users[userAddress].xMatrix[level].totalEarning);
    751 |     }
    752 | 
>>  753 |     function usersXMatrixReferrals(address userAddress, uint8 level) public view returns(
    754 |         address[] memory referrals
    755 |     ) {
    756 |         return (users[userAddress].xMatrix[level].referrals);
```

---

### 20. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 16 行
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     11 | 
     12 | // --- NFT INTERFACES ---
     13 | 
     14 | // 1. Interface for the Registration Pass (requires userId as tokenId, URI managed internally)
     15 | interface IRegistrationPassNFT {
>>   16 |     // URI is now managed internally by the NFT contract
     17 |     function mint(address to, uint256 tokenId) external;
     18 | }
     19 | 
     20 | // 2. Interface for the Royalty Cards (manages tokenId and URI internally, only requires 'to' address)
     21 | interface IRoyaltyCardNFT {
```

---

### 21. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 25 行
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     20 | // 2. Interface for the Royalty Cards (manages tokenId and URI internally, only requires 'to' address)
     21 | interface IRoyaltyCardNFT {
     22 |     function mint(address to) external; 
     23 | }
     24 | 
>>   25 | contract BTitanXMatrix {
     26 |     
     27 |     // --- SECURITY: REENTRANCY GUARD ---
     28 |     bool private locked;
     29 |     modifier nonReentrant() {
     30 |         require(!locked, "BTitan: Reentrant call detected");
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 580 行
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    575 |         // 1. Interaction: Perform the external token transfer first
    576 |         bool success = IERC20(BTCB_TOKEN_ADDRESS).transfer(receiver, amount);
    577 |         
    578 |         // 2. Check: Revert if transfer failed
    579 |         if (!success) {
>>  580 |             emit TokenTransferFailed(receiver, amount, "BTC transfer failed from contract balance");
    581 |             revert("BTitan: Token transfer failed to receiver.");
    582 |         }
    583 |         
    584 |         // 3. Effects: Update state only after successful transfer
    585 |         users[receiver].totalIncome += amount;
```

---

### 23. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 322 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: BTitanXMatrix.ChangeTitanPassNftaddress(address).new1 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#322) lacks a zero-check on :
		- REGISTRATION_PASS_NFT_CONTRACT = new1 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#323)

**代码片段**:
```solidity
    319 |     }
    320 | 
    321 |     // Update Registration Pass NFT address
>>  322 |     function ChangeTitanPassNftaddress(address new1) external onlyOwner{
    323 |         REGISTRATION_PASS_NFT_CONTRACT = new1;
    324 |         emit RegistrationPassNftAddressUpdated(new1);
    325 |     }
```

---

### 24. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 328 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: BTitanXMatrix.ChangeRoyalNftaddresses(address,address,address,address).new3 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#328) lacks a zero-check on :
		- ROYAL_RANK3_NFT_CONTRACT = new3 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#331)

**代码片段**:
```solidity
    325 |     }
    326 | 
    327 |     // Update Royal Card NFT addresses
>>  328 |     function ChangeRoyalNftaddresses(address new1, address new2, address new3, address new4) external onlyOwner{
    329 |         ROYAL_RANK1_NFT_CONTRACT = new1; 
    330 |         ROYAL_RANK2_NFT_CONTRACT = new2;
    331 |         ROYAL_RANK3_NFT_CONTRACT = new3;
```

---

### 25. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 328 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: BTitanXMatrix.ChangeRoyalNftaddresses(address,address,address,address).new2 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#328) lacks a zero-check on :
		- ROYAL_RANK2_NFT_CONTRACT = new2 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#330)

**代码片段**:
```solidity
    325 |     }
    326 | 
    327 |     // Update Royal Card NFT addresses
>>  328 |     function ChangeRoyalNftaddresses(address new1, address new2, address new3, address new4) external onlyOwner{
    329 |         ROYAL_RANK1_NFT_CONTRACT = new1; 
    330 |         ROYAL_RANK2_NFT_CONTRACT = new2;
    331 |         ROYAL_RANK3_NFT_CONTRACT = new3;
```

---

### 26. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 328 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: BTitanXMatrix.ChangeRoyalNftaddresses(address,address,address,address).new1 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#328) lacks a zero-check on :
		- ROYAL_RANK1_NFT_CONTRACT = new1 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#329)

**代码片段**:
```solidity
    325 |     }
    326 | 
    327 |     // Update Royal Card NFT addresses
>>  328 |     function ChangeRoyalNftaddresses(address new1, address new2, address new3, address new4) external onlyOwner{
    329 |         ROYAL_RANK1_NFT_CONTRACT = new1; 
    330 |         ROYAL_RANK2_NFT_CONTRACT = new2;
    331 |         ROYAL_RANK3_NFT_CONTRACT = new3;
```

---

### 27. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 109 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: BTitanXMatrix.constructor(address,address,address,address,address,address,address,address,address).ownerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#109) lacks a zero-check on :
		- owner = ownerAddress (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#129)

**代码片段**:
```solidity
    106 | 
    107 |     // --- Constructor ---
    108 |     constructor(
>>  109 |         address ownerAddress, 
    110 |         address btcTokenAddress, 
    111 |         address treasuryPoolAddress, 
    112 |         address platformAddress,
```

---

### 28. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol` 第 328 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: BTitanXMatrix.ChangeRoyalNftaddresses(address,address,address,address).new4 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#328) lacks a zero-check on :
		- ROYAL_RANK4_NFT_CONTRACT = new4 (../../../tmp/slither_scan_oqu6ruuz/0xD6759d47Fccdef7b8E318479cEC4D128366f2a44.sol#332)

**代码片段**:
```solidity
    325 |     }
    326 | 
    327 |     // Update Royal Card NFT addresses
>>  328 |     function ChangeRoyalNftaddresses(address new1, address new2, address new3, address new4) external onlyOwner{
    329 |         ROYAL_RANK1_NFT_CONTRACT = new1; 
    330 |         ROYAL_RANK2_NFT_CONTRACT = new2;
    331 |         ROYAL_RANK3_NFT_CONTRACT = new3;
```

---

### 29. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 153 行
- **函数**: `mint()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    150 |         users[ownerAddress].id = 1;
    151 |         users[ownerAddress].referrer = address(0);
    152 |         users[ownerAddress].referrerId = 0;
>>  153 |         users[ownerAddress].registrationTimestamp = block.timestamp;
    154 |         idToAddress[1] = ownerAddress;
    155 |         addressToId[ownerAddress] = 1; // Populate new mapping for owner
    156 |         
```

---

### 30. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 219 行
- **函数**: `_registerPartner()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    216 |         idToAddress[currentUserId] = userAddress;
    217 |         addressToId[userAddress] = currentUserId;
    218 |         users[userAddress].activeLevels[1] = true; // Activate L1
>>  219 |         users[userAddress].registrationTimestamp = block.timestamp; 
    220 | 
    221 |         // Add new user to initial referrer's direct referrals list (ID 1's list)
    222 |         users[referrerAddress].directReferrals.push(userAddress);
```

---

### 31. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 355 行
- **函数**: `_registration()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    352 |         idToAddress[currentUserId] = userAddress;
    353 |         addressToId[userAddress] = currentUserId; // Populate new mapping for new user
    354 |         users[userAddress].activeLevels[1] = true;
>>  355 |         users[userAddress].registrationTimestamp = block.timestamp; 
    356 |         lastUserId++;
    357 |         
    358 |         // 3. NFT Minting (Registration Pass)
```

---

### 32. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 576 行
- **函数**: `_sendTokenDividends()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    573 |         address receiver = userAddress;
    574 | 
    575 |         // 1. Interaction: Perform the external token transfer first
>>  576 |         bool success = IERC20(BTCB_TOKEN_ADDRESS).transfer(receiver, amount);
    577 |         
    578 |         // 2. Check: Revert if transfer failed
    579 |         if (!success) {
```

---

### 33. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 593 行
- **函数**: `_sendToRoyalPool()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    590 | 
    591 |     // Sends payment to the Royal Pool
    592 |     function _sendToRoyalPool(address _ref, address _user, uint8 _level, uint256 _amount) private {
>>  593 |         bool success = IERC20(BTCB_TOKEN_ADDRESS).transfer(ROYAL_POOL_ADDRESS, _amount);
    594 |         if (!success) {
    595 |             emit TokenTransferFailed(ROYAL_POOL_ADDRESS, _amount, "BTC transfer failed to Royal Pool");
    596 |             revert("BTitan: Royal Pool transfer failed.");
```

---

### 34. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xD6759d47Fccdef7b8E318479cEC4D128366f2a44` 第 603 行
- **函数**: `_sendToPlatformTreasury()`
- **合约**: `function`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    600 |     
    601 |     // Sends payment to the Platform Treasury
    602 |     function _sendToPlatformTreasury(uint256 _amount) private {
>>  603 |         bool success = IERC20(BTCB_TOKEN_ADDRESS).transfer(TREASURY_POOL_ADDRESS, _amount);
    604 |         if (!success) {
    605 |             emit TokenTransferFailed(TREASURY_POOL_ADDRESS, _amount, "BTC transfer failed to Platform Treasury");
    606 |             revert("BTitan: Platform Treasury transfer failed.");
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*