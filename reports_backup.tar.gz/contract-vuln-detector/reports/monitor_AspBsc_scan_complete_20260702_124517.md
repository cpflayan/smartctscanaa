# 智能合约安全审计报告

> 生成时间: 2026-07-02 12:45:17
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` |
| contract_name | `AspBsc` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107638938` |

## 安全摘要

**整体风险等级**: UNKNOWN

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 13 |
| 🟢 LOW | 1 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 26 行
- **函数**: `owner()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     23 |         emit OwnershipTransferred(address(0), msgSender);
     24 |     }
     25 | 
>>   26 |     function owner() public view returns (address) {
     27 |         return _owner;
     28 |     }
     29 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 52 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     49 |     /**
     50 |      * @dev Returns the amount of tokens in existence.
     51 |      */
>>   52 |     function totalSupply() external view returns (uint256);
     53 | 
     54 |     /**
     55 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 57 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     54 |     /**
     55 |      * @dev Returns the amount of tokens owned by `account`.
     56 |      */
>>   57 |     function balanceOf(address account) external view returns (uint256);
     58 | 
     59 |     /**
     60 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 66 行
- **函数**: `transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     63 |      *
     64 |      * Emits a {Transfer} event.
     65 |      */
>>   66 |     function transfer(address recipient, uint256 amount) external returns (bool);
     67 | 
     68 |     /**
     69 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 75 行
- **函数**: `allowance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     72 |      *
     73 |      * This value changes when {approve} or {transferFrom} are called.
     74 |      */
>>   75 |     function allowance(address owner, address spender) external view returns (uint256);
     76 | 
     77 |     /**
     78 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 91 行
- **函数**: `approve()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     88 |      *
     89 |      * Emits an {Approval} event.
     90 |      */
>>   91 |     function approve(address spender, uint256 amount) external returns (bool);
     92 | 
     93 |     /**
     94 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 157 行
- **函数**: `withdraw()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    154 |    *   different wallet
    155 |    * @return The final amount withdrawn
    156 |    */
>>  157 |     function withdraw(address asset, uint256 amount, address to) external returns (uint256);
    158 | 
    159 |     function getReserveAToken(address asset) external view returns (address);
    160 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 159 行
- **函数**: `getReserveAToken()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    156 |    */
    157 |     function withdraw(address asset, uint256 amount, address to) external returns (uint256);
    158 | 
>>  159 |     function getReserveAToken(address asset) external view returns (address);
    160 | 
    161 | }
    162 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 175 行
- **函数**: `getPool()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    172 |      * @notice Returns the address of the Pool proxy.
    173 |    * @return The Pool proxy address
    174 |    */
>>  175 |     function getPool() external view returns (address);
    176 | 
    177 | }
    178 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 191 行
- **函数**: `recharge()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    188 |         transferOwnership(_msgSender());
    189 |     }
    190 | 
>>  191 |     function recharge(address token, uint256 amount) public  {
    192 |         IERC20(token).transferFrom(msg.sender, address(this), amount);
    193 |         IERC20(token).approve(address(lendingPool), amount);
    194 |         lendingPool.supply(token, amount, collect, 0);
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 212 行
- **函数**: `getAToken()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    209 |         lendingPool.withdraw(token, amount, account);
    210 |     }
    211 | 
>>  212 |     function getAToken(address token) public view returns(address){
    213 |         return lendingPool.getReserveAToken(token);
    214 |     }
    215 | }
```

---

### 12. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 15 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     10 |     function _msgData() internal view virtual returns (bytes calldata) {
     11 |         return msg.data;
     12 |     }
     13 | }
     14 | 
>>   15 | contract Ownable is Context {
     16 |     address private _owner;
     17 | 
     18 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     19 | 
     20 |     constructor () {
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 179 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    174 |    */
    175 |     function getPool() external view returns (address);
    176 | 
    177 | }
    178 | 
>>  179 | contract AspBsc is  Ownable {
    180 | 
    181 |     address public collect;
    182 |     IPool private lendingPool;
    183 | 
    184 | 
```

---

### 14. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x96Ba9413a83b95Eb9f28C2D002ec136Bdf8E10F6` 第 187 行
- **函数**: `getPool()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    184 | 
    185 |     constructor()  {
    186 |         collect = _msgSender();
>>  187 |         lendingPool= IPool(IPoolAddressesProvider(address(0xff75B6da14FfbbfD355Daf7a2731456b3562Ba6D)).getPool());
    188 |         transferOwnership(_msgSender());
    189 |     }
    190 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*