# 智能合约安全审计报告

> 生成时间: 2026-07-02 12:29:50
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` |
| contract_name | `UniversalRouter` |
| compiler_version | `v0.8.26+commit.8a97fa7a` |
| optimization_used | `True` |
| runs | `20000` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/UniversalRouter.sol', 'src/base/Dispatcher.sol', 'src/base/RouterImmutables.sol', 'src/modules/pancakeswap/infinity/InfinitySwapRouter.sol', 'src/libraries/Commands.sol', 'src/libraries/Constants.sol', 'src/interfaces/IUniversalRouter.sol', 'src/modules/pancakeswap/StableSwapRouter.sol', 'lib/infinity-periphery/lib/infinity-core/lib/openzeppelin-contracts/contracts/utils/Pausable.sol', 'src/modules/pancakeswap/v2/V2SwapRouter.sol', 'src/modules/pancakeswap/v3/V3SwapRouter.sol', 'src/modules/Payments.sol', 'src/modules/V3ToInfinityMigrator.sol', 'src/libraries/BytesLib.sol', 'src/base/Lock.sol', 'lib/infinity-periphery/lib/infinity-core/lib/solmate/src/tokens/ERC20.sol', 'lib/infinity-periphery/lib/permit2/src/interfaces/IAllowanceTransfer.sol', 'lib/infinity-periphery/src/libraries/ActionConstants.sol', 'lib/infinity-periphery/src/base/BaseActionsRouter.sol', 'lib/infinity-periphery/src/libraries/CalldataDecoder.sol', 'lib/infinity-periphery/lib/infinity-core/src/types/PoolKey.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/interfaces/ICLPoolManager.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/interfaces/IBinPoolManager.sol', 'lib/infinity-periphery/lib/permit2/src/interfaces/IPermit2.sol', 'lib/infinity-periphery/src/interfaces/external/IV3NonfungiblePositionManager.sol', 'lib/infinity-periphery/src/interfaces/IPositionManager.sol', 'lib/infinity-periphery/src/interfaces/external/IWETH9.sol', 'src/modules/Permit2Payments.sol', 'lib/infinity-periphery/src/InfinityRouter.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IVault.sol', 'lib/infinity-periphery/lib/infinity-core/src/types/Currency.sol', 'src/libraries/UniversalRouterHelper.sol', 'lib/infinity-periphery/lib/infinity-core/lib/solmate/src/utils/SafeTransferLib.sol', 'lib/infinity-periphery/lib/infinity-core/lib/openzeppelin-contracts/contracts/access/Ownable2Step.sol', 'src/interfaces/IStableSwap.sol', 'lib/infinity-periphery/lib/infinity-core/lib/openzeppelin-contracts/contracts/utils/Context.sol', 'src/modules/pancakeswap/v2/interfaces/IPancakeV2Pair.sol', 'src/modules/pancakeswap/v3/SafeCast.sol', 'src/modules/pancakeswap/v3/interfaces/IPancakeV3Pool.sol', 'src/modules/pancakeswap/v3/interfaces/IPancakeV3SwapCallback.sol', 'src/libraries/MaxInputAmount.sol', 'lib/infinity-periphery/src/libraries/BipsLibrary.sol', 'lib/infinity-periphery/lib/infinity-core/lib/solmate/src/tokens/ERC721.sol', 'lib/infinity-periphery/lib/infinity-core/lib/solmate/src/tokens/ERC1155.sol', 'lib/infinity-periphery/src/libraries/Actions.sol', 'lib/infinity-periphery/src/interfaces/IERC721Permit.sol', 'src/libraries/Locker.sol', 'lib/infinity-periphery/lib/permit2/src/interfaces/IEIP712.sol', 'lib/infinity-periphery/src/base/SafeCallback.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IPoolManager.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IHooks.sol', 'lib/infinity-periphery/lib/infinity-core/src/types/PoolId.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/CLPool.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IProtocolFees.sol', 'lib/infinity-periphery/lib/infinity-core/src/types/BalanceDelta.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/CLPosition.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IExtsload.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/Tick.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/BinPool.sol', 'lib/infinity-periphery/lib/permit2/src/interfaces/ISignatureTransfer.sol', 'lib/infinity-periphery/src/interfaces/IImmutableState.sol', 'lib/infinity-periphery/lib/infinity-core/lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'lib/infinity-periphery/lib/permit2/src/libraries/SafeCast160.sol', 'lib/infinity-periphery/src/interfaces/IInfinityRouter.sol', 'lib/infinity-periphery/src/base/DeltaResolver.sol', 'lib/infinity-periphery/src/pool-cl/libraries/CLCalldataDecoder.sol', 'lib/infinity-periphery/src/pool-bin/libraries/BinCalldataDecoder.sol', 'lib/infinity-periphery/src/pool-cl/CLRouterBase.sol', 'lib/infinity-periphery/src/pool-bin/BinRouterBase.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IVaultToken.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IERC20Minimal.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/CustomRevert.sol', 'src/interfaces/IStableSwapFactory.sol', 'src/interfaces/IStableSwapInfo.sol', 'lib/infinity-periphery/lib/infinity-core/lib/openzeppelin-contracts/contracts/access/Ownable.sol', 'src/modules/pancakeswap/v3/interfaces/pool/IPancakeV3PoolImmutables.sol', 'src/modules/pancakeswap/v3/interfaces/pool/IPancakeV3PoolState.sol', 'src/modules/pancakeswap/v3/interfaces/pool/IPancakeV3PoolDerivedState.sol', 'src/modules/pancakeswap/v3/interfaces/pool/IPancakeV3PoolActions.sol', 'src/modules/pancakeswap/v3/interfaces/pool/IPancakeV3PoolOwnerActions.sol', 'src/modules/pancakeswap/v3/interfaces/pool/IPancakeV3PoolEvents.sol', 'lib/infinity-periphery/lib/infinity-core/lib/openzeppelin-contracts/contracts/token/ERC721/IERC721.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/ILockCallback.sol', 'lib/infinity-periphery/src/base/ImmutableState.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/TickMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/types/CLSlot0.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/TickBitmap.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/SqrtPriceMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/SafeCast.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/FixedPoint128.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/math/UnsafeMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/SwapMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/LiquidityMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/ProtocolFeeLibrary.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/LPFeeLibrary.sol', 'lib/infinity-periphery/lib/infinity-core/src/interfaces/IProtocolFeeController.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/FullMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/types/BinSlot0.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/LiquidityConfigurations.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/PackedUint128Math.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/Uint256x256Math.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/TreeMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/PriceHelper.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/BinHelper.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/BinPosition.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/SafeCast.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/Constants.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/FeeHelper.sol', 'lib/infinity-periphery/src/libraries/PathKey.sol', 'lib/infinity-periphery/src/pool-cl/interfaces/ICLRouterBase.sol', 'lib/infinity-periphery/src/pool-bin/interfaces/IBinRouterBase.sol', 'lib/infinity-periphery/src/pool-bin/interfaces/IBinPositionManager.sol', 'lib/infinity-periphery/src/libraries/SafeCast.sol', 'lib/infinity-periphery/lib/infinity-core/lib/openzeppelin-contracts/contracts/utils/introspection/IERC165.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/BitMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-cl/libraries/FixedPoint96.sol', 'lib/infinity-periphery/lib/infinity-core/src/libraries/math/Encoded.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/BitMath.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/math/Uint128x128Math.sol', 'lib/infinity-periphery/lib/infinity-core/src/pool-bin/libraries/BinPoolParametersHelper.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107636924` |

## 安全摘要

**整体风险等级**: UNKNOWN

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 165 |
| 🟢 LOW | 65 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 983 行
- **函数**: `_v2Swap()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    980 |             uint256 penultimatePairIndex = finalPairIndex - 1;
    981 |             for (uint256 i; i < finalPairIndex; i++) {
    982 |                 (address input, address output) = (path[i], path[i + 1]);
>>  983 |                 (uint256 reserve0, uint256 reserve1,) = IPancakeV2Pair(pair).getReserves();
    984 |                 (uint256 reserveInput, uint256 reserveOutput) =
    985 |                     input == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
    986 |                 uint256 amountInput = ERC20(input).balanceOf(pair) - reserveInput;
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3548 行
- **函数**: `pairAndReservesFor()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   3545 |     {
   3546 |         address token0;
   3547 |         (pair, token0) = pairAndToken0For(factory, initCodeHash, tokenA, tokenB);
>> 3548 |         (uint256 reserve0, uint256 reserve1,) = IPancakeV2Pair(pair).getReserves();
   3549 |         (reserveA, reserveB) = tokenA == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
   3550 |     }
   3551 | 
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3965 行
- **函数**: `getReserves()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   3962 |     function factory() external view returns (address);
   3963 |     function token0() external view returns (address);
   3964 |     function token1() external view returns (address);
>> 3965 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   3966 |     function price0CumulativeLast() external view returns (uint256);
   3967 |     function price1CumulativeLast() external view returns (uint256);
   3968 |     function kLast() external view returns (uint256);
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 215 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    212 |                             permitBatch := add(inputs.offset, calldataload(inputs.offset))
    213 |                         }
    214 |                         bytes calldata data = inputs.toBytes(1);
>>  215 |                         (success, output) = address(PERMIT2).call(
    216 |                             abi.encodeWithSignature(
    217 |                                 "permit(address,((address,uint160,uint48,uint48)[],address,uint256),bytes)",
    218 |                                 msgSender(),
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 307 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    304 |                             permitSingle := inputs.offset
    305 |                         }
    306 |                         bytes calldata data = inputs.toBytes(6); // PermitSingle takes first 6 slots (0..5)
>>  307 |                         (success, output) = address(PERMIT2).call(
    308 |                             abi.encodeWithSignature(
    309 |                                 "permit(address,((address,uint160,uint48,uint48),address,uint256),bytes)",
    310 |                                 msgSender(),
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 372 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    369 |                     // This contract MUST be approved to spend the token since its going to be doing the call on the position manager
    370 |                 } else if (command == Commands.V3_POSITION_MANAGER_PERMIT) {
    371 |                     _checkV3PermitCall(inputs);
>>  372 |                     (success, output) = address(V3_POSITION_MANAGER).call(inputs);
    373 |                     return (success, output);
    374 |                 } else if (command == Commands.V3_POSITION_MANAGER_CALL) {
    375 |                     _checkV3PositionManagerCall(inputs, msgSender());
```

---

### 7. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 377 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    374 |                 } else if (command == Commands.V3_POSITION_MANAGER_CALL) {
    375 |                     _checkV3PositionManagerCall(inputs, msgSender());
    376 |                     /// @dev ensure there's follow-up action if v3 position's removed token are sent to router contract
>>  377 |                     (success, output) = address(V3_POSITION_MANAGER).call(inputs);
    378 |                     return (success, output);
    379 |                 } else if (command == Commands.INFI_CL_INITIALIZE_POOL) {
    380 |                     // equivalent: abi.decode(inputs, (PoolKey, uint160)) where PoolKey is
```

---

### 8. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 389 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    386 |                         sqrtPriceX96 := calldataload(add(inputs.offset, 0xc0)) // poolKey has 6 variable, so it takes 192 space = 0xc0
    387 |                     }
    388 |                     (success, output) =
>>  389 |                         address(clPoolManager).call(abi.encodeCall(ICLPoolManager.initialize, (poolKey, sqrtPriceX96)));
    390 |                 } else if (command == Commands.INFI_BIN_INITIALIZE_POOL) {
    391 |                     // equivalent: abi.decode(inputs, (PoolKey, uint24)) where PoolKey is
    392 |                     // (Currency currency0, Currency currency1, IHooks hooks, IPoolManager poolManager, uint24 fee, bytes32 parameters)
```

---

### 9. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 400 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    397 |                         activeId := calldataload(add(inputs.offset, 0xc0)) // poolKey has 6 variable, so it takes 192 space = 0xc0
    398 |                     }
    399 |                     (success, output) =
>>  400 |                         address(binPoolManager).call(abi.encodeCall(IBinPoolManager.initialize, (poolKey, activeId)));
    401 |                 } else if (command == Commands.INFI_CL_POSITION_CALL) {
    402 |                     _checkInfiClPositionManagerCall(inputs);
    403 |                     (success, output) = address(INFI_CL_POSITION_MANAGER).call{value: address(this).balance}(inputs);
```

---

### 10. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 403 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    400 |                         address(binPoolManager).call(abi.encodeCall(IBinPoolManager.initialize, (poolKey, activeId)));
    401 |                 } else if (command == Commands.INFI_CL_POSITION_CALL) {
    402 |                     _checkInfiClPositionManagerCall(inputs);
>>  403 |                     (success, output) = address(INFI_CL_POSITION_MANAGER).call{value: address(this).balance}(inputs);
    404 |                     return (success, output);
    405 |                 } else if (command == Commands.INFI_BIN_POSITION_CALL) {
    406 |                     _checkInfiBinPositionManagerCall(inputs);
```

---

### 11. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 407 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    404 |                     return (success, output);
    405 |                 } else if (command == Commands.INFI_BIN_POSITION_CALL) {
    406 |                     _checkInfiBinPositionManagerCall(inputs);
>>  407 |                     (success, output) = address(INFI_BIN_POSITION_MANAGER).call{value: address(this).balance}(inputs);
    408 |                     return (success, output);
    409 |                 } else {
    410 |                     // placeholder area for commands 0x15-0x20
```

---

### 12. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 418 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    415 |             // 0x21 <= command
    416 |             if (command == Commands.EXECUTE_SUB_PLAN) {
    417 |                 (bytes calldata _commands, bytes[] calldata _inputs) = inputs.decodeCommandsAndInputs();
>>  418 |                 (success, output) = (address(this)).call(abi.encodeCall(Dispatcher.execute, (_commands, _inputs)));
    419 |                 return (success, output);
    420 |             } else if (command == Commands.STABLE_SWAP_EXACT_IN) {
    421 |                 // equivalent: abi.decode(inputs, (address, uint256, uint256, bytes, bytes, bool))
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 134 行
- **函数**: `execute()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    131 |     /// @notice Executes encoded commands along with provided inputs.
    132 |     /// @param commands A set of concatenated commands, each 1 byte in length
    133 |     /// @param inputs An array of byte strings containing abi encoded inputs for each command
>>  134 |     function execute(bytes calldata commands, bytes[] calldata inputs) external payable virtual;
    135 | 
    136 |     /// @notice Public view function to be used instead of msg.sender, as the contract performs self-reentrancy and at
    137 |     /// times msg.sender == address(this). Instead msgSender() returns the initiator of the lock
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 138 行
- **函数**: `msgSender()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    135 | 
    136 |     /// @notice Public view function to be used instead of msg.sender, as the contract performs self-reentrancy and at
    137 |     /// times msg.sender == address(this). Instead msgSender() returns the initiator of the lock
>>  138 |     function msgSender() public view override(BaseActionsRouter) returns (address) {
    139 |         return _getLocker();
    140 |     }
    141 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 699 行
- **函数**: `execute()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    696 |     /// @param commands A set of concatenated commands, each 1 byte in length
    697 |     /// @param inputs An array of byte strings containing abi encoded inputs for each command
    698 |     /// @param deadline The deadline by which the transaction must be executed
>>  699 |     function execute(bytes calldata commands, bytes[] calldata inputs, uint256 deadline) external payable;
    700 | }
    701 | 
    702 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 906 行
- **函数**: `paused()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    903 |     /**
    904 |      * @dev Returns true if the contract is paused, and false otherwise.
    905 |      */
>>  906 |     function paused() public view virtual returns (bool) {
    907 |         return _paused;
    908 |     }
    909 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1094 行
- **函数**: `pancakeV3SwapCallback()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1091 |     /// @dev The maximum value that can be returned from #getSqrtRatioAtTick. Equivalent to getSqrtRatioAtTick(MAX_TICK)
   1092 |     uint160 internal constant MAX_SQRT_RATIO = 1461446703485210103287273052203988822378723970342;
   1093 | 
>> 1094 |     function pancakeV3SwapCallback(int256 amount0Delta, int256 amount1Delta, bytes calldata data) external {
   1095 |         if (amount0Delta <= 0 && amount1Delta <= 0) revert V3InvalidSwap(); // swaps entirely within 0-liquidity regions are not supported
   1096 |         (, address payer) = abi.decode(data, (bytes, address));
   1097 |         bytes calldata path = data.toBytes(0);
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1674 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1671 |                                ERC20 LOGIC
   1672 |     //////////////////////////////////////////////////////////////*/
   1673 | 
>> 1674 |     function approve(address spender, uint256 amount) public virtual returns (bool) {
   1675 |         allowance[msg.sender][spender] = amount;
   1676 | 
   1677 |         emit Approval(msg.sender, spender, amount);
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1682 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1679 |         return true;
   1680 |     }
   1681 | 
>> 1682 |     function transfer(address to, uint256 amount) public virtual returns (bool) {
   1683 |         balanceOf[msg.sender] -= amount;
   1684 | 
   1685 |         // Cannot overflow because the sum of all user
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1768 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1765 |         emit Approval(owner, spender, value);
   1766 |     }
   1767 | 
>> 1768 |     function DOMAIN_SEPARATOR() public view virtual returns (bytes32) {
   1769 |         return block.chainid == INITIAL_CHAIN_ID ? INITIAL_DOMAIN_SEPARATOR : computeDomainSeparator();
   1770 |     }
   1771 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2068 行
- **函数**: `msgSender()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2065 |     /// In many contracts this will be the address that calls the initial entry point that calls `_executeActions`
   2066 |     /// `msg.sender` shouldnt be used, as this will be the vault contract that calls `lockAcquired`
   2067 |     /// If using ReentrancyLock.sol, this function can return _getLocker()
>> 2068 |     function msgSender() public view virtual returns (address);
   2069 | 
   2070 |     /// @notice Calculates the address for a action
   2071 |     function _mapRecipient(address recipient) internal view returns (address) {
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2432 行
- **函数**: `getLiquidity()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2429 |         returns (uint160 sqrtPriceX96, int24 tick, uint24 protocolFee, uint24 lpFee);
   2430 | 
   2431 |     /// @notice Get the current value of liquidity of the given pool
>> 2432 |     function getLiquidity(PoolId id) external view returns (uint128 liquidity);
   2433 | 
   2434 |     /// @notice Get the current value of liquidity for the specified pool and position
   2435 |     function getLiquidity(PoolId id, address owner, int24 tickLower, int24 tickUpper, bytes32 salt)
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2441 行
- **函数**: `getPoolTickInfo()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2438 |         returns (uint128 liquidity);
   2439 | 
   2440 |     /// @notice Get the tick info about a specific tick in the pool
>> 2441 |     function getPoolTickInfo(PoolId id, int24 tick) external view returns (Tick.Info memory);
   2442 | 
   2443 |     /// @notice Get the tick bitmap info about a specific range (a word range) in the pool
   2444 |     function getPoolBitmapInfo(PoolId id, int16 word) external view returns (uint256 tickBitmap);
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2444 行
- **函数**: `getPoolBitmapInfo()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2441 |     function getPoolTickInfo(PoolId id, int24 tick) external view returns (Tick.Info memory);
   2442 | 
   2443 |     /// @notice Get the tick bitmap info about a specific range (a word range) in the pool
>> 2444 |     function getPoolBitmapInfo(PoolId id, int16 word) external view returns (uint256 tickBitmap);
   2445 | 
   2446 |     /// @notice Get the fee growth global for the given pool
   2447 |     /// @return feeGrowthGlobal0x128 The global fee growth for token0
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2464 行
- **函数**: `initialize()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2461 |         returns (CLPosition.Info memory position);
   2462 | 
   2463 |     /// @notice Initialize the state for a given pool ID
>> 2464 |     function initialize(PoolKey memory key, uint160 sqrtPriceX96) external returns (int24 tick);
   2465 | 
   2466 |     struct ModifyLiquidityParams {
   2467 |         // the lower and upper tick of the position
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2558 行
- **函数**: `maxBinStep()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2555 | 
   2556 |     /// @notice Returns the constant representing the max bin step
   2557 |     /// @return maxBinStep a value of 100 would represent a 1% price jump between bin (limit can be raised by owner)
>> 2558 |     function maxBinStep() external view returns (uint16);
   2559 | 
   2560 |     /// @notice Returns the constant representing the min bin step
   2561 |     /// @dev 1 would represent a 0.01% price jump between bin
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2562 行
- **函数**: `MIN_BIN_STEP()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2559 | 
   2560 |     /// @notice Returns the constant representing the min bin step
   2561 |     /// @dev 1 would represent a 0.01% price jump between bin
>> 2562 |     function MIN_BIN_STEP() external view returns (uint16);
   2563 | 
   2564 |     /// @notice min share in bin before donate is allowed in current bin
   2565 |     function minBinShareForDonate() external view returns (uint256);
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2565 行
- **函数**: `minBinShareForDonate()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2562 |     function MIN_BIN_STEP() external view returns (uint16);
   2563 | 
   2564 |     /// @notice min share in bin before donate is allowed in current bin
>> 2565 |     function minBinShareForDonate() external view returns (uint256);
   2566 | 
   2567 |     /// @notice Emitted when a new pool is initialized
   2568 |     /// @param id The abi encoded hash of the pool key struct for the new pool
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2661 行
- **函数**: `getSlot0()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2658 |     }
   2659 | 
   2660 |     /// @notice Get the current value in slot0 of the given pool
>> 2661 |     function getSlot0(PoolId id) external view returns (uint24 activeId, uint24 protocolFee, uint24 lpFee);
   2662 | 
   2663 |     /// @notice Returns the reserves of a bin
   2664 |     /// @param id The id of the bin
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2690 行
- **函数**: `getNextNonEmptyBin()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2687 |     /// @param swapForY Whether the swap is for token Y (true) or token X (false)
   2688 |     /// @param id The id of the bin
   2689 |     /// @return nextId The id of the next non-empty bin
>> 2690 |     function getNextNonEmptyBin(PoolId id, bool swapForY, uint24 binId) external view returns (uint24 nextId);
   2691 | 
   2692 |     /// @notice Initialize a new pool
   2693 |     function initialize(PoolKey memory key, uint24 activeId) external;
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2910 行
- **函数**: `collect()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2907 |     /// amount1Max The maximum amount of token1 to collect
   2908 |     /// @return amount0 The amount of fees collected in token0
   2909 |     /// @return amount1 The amount of fees collected in token1
>> 2910 |     function collect(CollectParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
   2911 | 
   2912 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   2913 |     /// must be collected first.
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2915 行
- **函数**: `burn()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2912 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   2913 |     /// must be collected first.
   2914 |     /// @param tokenId The ID of the token that is being burned
>> 2915 |     function burn(uint256 tokenId) external payable;
   2916 | 
   2917 |     function createAndInitializePoolIfNecessary(address token0, address token1, uint24 fee, uint160 sqrtPriceX96)
   2918 |         external
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2949 行
- **函数**: `modifyLiquidities()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2946 |     /// @dev This is the standard entrypoint for the PositionManager
   2947 |     /// @param payload is an encoding of actions, and parameters for those actions
   2948 |     /// @param deadline is the deadline for the batched actions to be executed
>> 2949 |     function modifyLiquidities(bytes calldata payload, uint256 deadline) external payable;
   2950 | 
   2951 |     /// @notice Batches actions for modifying liquidity without getting a lock from vault
   2952 |     /// @dev This must be called by a contract that has already locked the vault
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2955 行
- **函数**: `modifyLiquiditiesWithoutLock()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2952 |     /// @dev This must be called by a contract that has already locked the vault
   2953 |     /// @param actions the actions to perform
   2954 |     /// @param params the parameters to provide for the actions
>> 2955 |     function modifyLiquiditiesWithoutLock(bytes calldata actions, bytes[] calldata params) external payable;
   2956 | }
   2957 | 
   2958 | 
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2970 行
- **函数**: `deposit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2967 | /// @notice Interface for WETH9
   2968 | interface IWETH9 is IERC20 {
   2969 |     /// @notice Deposit ether to get wrapped ether
>> 2970 |     function deposit() external payable;
   2971 | 
   2972 |     /// @notice Withdraw wrapped ether to get ether
   2973 |     function withdraw(uint256) external;
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3173 行
- **函数**: `isAppRegistered()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3170 |     /// @notice Thrown when collectFee is attempted on a token that is synced.
   3171 |     error FeeCurrencySynced();
   3172 | 
>> 3173 |     function isAppRegistered(address app) external returns (bool);
   3174 | 
   3175 |     /// @notice Returns the reserves for a a given pool type and currency
   3176 |     function reservesOfApp(address app, Currency currency) external view returns (uint256);
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3176 行
- **函数**: `reservesOfApp()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3173 |     function isAppRegistered(address app) external returns (bool);
   3174 | 
   3175 |     /// @notice Returns the reserves for a a given pool type and currency
>> 3176 |     function reservesOfApp(address app, Currency currency) external view returns (uint256);
   3177 | 
   3178 |     /// @notice register an app so that it can perform accounting base on vault
   3179 |     function registerApp(address app) external;
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3182 行
- **函数**: `getLocker()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3179 |     function registerApp(address app) external;
   3180 | 
   3181 |     /// @notice Returns the locker who is locking the vault
>> 3182 |     function getLocker() external view returns (address locker);
   3183 | 
   3184 |     /// @notice Returns the reserve and its amount that is currently being stored in trnasient storage
   3185 |     function getVaultReserve() external view returns (Currency, uint256);
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3185 行
- **函数**: `getVaultReserve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3182 |     function getLocker() external view returns (address locker);
   3183 | 
   3184 |     /// @notice Returns the reserve and its amount that is currently being stored in trnasient storage
>> 3185 |     function getVaultReserve() external view returns (Currency, uint256);
   3186 | 
   3187 |     /// @notice Returns lock data
   3188 |     function getUnsettledDeltasCount() external view returns (uint256 count);
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3188 行
- **函数**: `getUnsettledDeltasCount()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3185 |     function getVaultReserve() external view returns (Currency, uint256);
   3186 | 
   3187 |     /// @notice Returns lock data
>> 3188 |     function getUnsettledDeltasCount() external view returns (uint256 count);
   3189 | 
   3190 |     /// @notice Get the current delta for a locker in the given currency
   3191 |     /// @param currency The currency for which to lookup the delta
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3192 行
- **函数**: `currencyDelta()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3189 | 
   3190 |     /// @notice Get the current delta for a locker in the given currency
   3191 |     /// @param currency The currency for which to lookup the delta
>> 3192 |     function currencyDelta(address settler, Currency currency) external view returns (int256);
   3193 | 
   3194 |     /// @notice All operations go through this function
   3195 |     /// @param data Any data to pass to the callback, via `ILockCallback(msg.sender).lockCallback(data)`
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3197 行
- **函数**: `lock()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3194 |     /// @notice All operations go through this function
   3195 |     /// @param data Any data to pass to the callback, via `ILockCallback(msg.sender).lockCallback(data)`
   3196 |     /// @return The data returned by the call to `ILockCallback(msg.sender).lockCallback(data)`
>> 3197 |     function lock(bytes calldata data) external returns (bytes memory);
   3198 | 
   3199 |     /// @notice Called by registered app to account for a change in the pool balance,
   3200 |     /// convenient for AMM pool manager, typically after modifyLiquidity, swap, donate,
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3246 行
- **函数**: `settle()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3243 |     function sync(Currency token0) external;
   3244 | 
   3245 |     /// @notice Called by the user to pay what is owed
>> 3246 |     function settle() external payable returns (uint256 paid);
   3247 | 
   3248 |     /// @notice Called by the user to pay on behalf of another address
   3249 |     /// @param recipient The address to credit for the payment
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3251 行
- **函数**: `settleFor()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3248 |     /// @notice Called by the user to pay on behalf of another address
   3249 |     /// @param recipient The address to credit for the payment
   3250 |     /// @return paid The amount of currency settled
>> 3251 |     function settleFor(address recipient) external payable returns (uint256 paid);
   3252 | 
   3253 |     /// @notice WARNING - Any currency that is cleared, will be non-retreivable, and locked in the contract permanently.
   3254 |     /// A call to clear will zero out a positive balance WITHOUT a corresponding transfer.
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3829 行
- **函数**: `pendingOwner()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3826 |     /**
   3827 |      * @dev Returns the address of the pending owner.
   3828 |      */
>> 3829 |     function pendingOwner() public view virtual returns (address) {
   3830 |         return _pendingOwner;
   3831 |     }
   3832 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3854 行
- **函数**: `acceptOwnership()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3851 |     /**
   3852 |      * @dev The new owner accepts the ownership transfer.
   3853 |      */
>> 3854 |     function acceptOwnership() public virtual {
   3855 |         address sender = _msgSender();
   3856 |         if (pendingOwner() != sender) {
   3857 |             revert OwnableUnauthorizedAccount(sender);
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3871 行
- **函数**: `get_dy()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3868 | 
   3869 | interface IStableSwap {
   3870 |     // solium-disable-next-line mixedcase
>> 3871 |     function get_dy(uint256 i, uint256 j, uint256 dx) external view returns (uint256 dy);
   3872 | 
   3873 |     // solium-disable-next-line mixedcase
   3874 |     function exchange(uint256 i, uint256 j, uint256 dx, uint256 minDy) external payable;
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3874 行
- **函数**: `exchange()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3871 |     function get_dy(uint256 i, uint256 j, uint256 dx) external view returns (uint256 dy);
   3872 | 
   3873 |     // solium-disable-next-line mixedcase
>> 3874 |     function exchange(uint256 i, uint256 j, uint256 dx, uint256 minDy) external payable;
   3875 | 
   3876 |     // solium-disable-next-line mixedcase
   3877 |     function coins(uint256 i) external view returns (address);
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3877 行
- **函数**: `coins()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3874 |     function exchange(uint256 i, uint256 j, uint256 dx, uint256 minDy) external payable;
   3875 | 
   3876 |     // solium-disable-next-line mixedcase
>> 3877 |     function coins(uint256 i) external view returns (address);
   3878 | 
   3879 |     // solium-disable-next-line mixedcase
   3880 |     function balances(uint256 i) external view returns (uint256);
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3880 行
- **函数**: `balances()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3877 |     function coins(uint256 i) external view returns (address);
   3878 | 
   3879 |     // solium-disable-next-line mixedcase
>> 3880 |     function balances(uint256 i) external view returns (uint256);
   3881 | 
   3882 |     // solium-disable-next-line mixedcase
   3883 |     function A() external view returns (uint256);
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3883 行
- **函数**: `A()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3880 |     function balances(uint256 i) external view returns (uint256);
   3881 | 
   3882 |     // solium-disable-next-line mixedcase
>> 3883 |     function A() external view returns (uint256);
   3884 | 
   3885 |     // solium-disable-next-line mixedcase
   3886 |     function fee() external view returns (uint256);
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3886 行
- **函数**: `fee()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3883 |     function A() external view returns (uint256);
   3884 | 
   3885 |     // solium-disable-next-line mixedcase
>> 3886 |     function fee() external view returns (uint256);
   3887 | }
   3888 | 
   3889 | 
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3931 行
- **函数**: `name()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3928 |     event Approval(address indexed owner, address indexed spender, uint256 value);
   3929 |     event Transfer(address indexed from, address indexed to, uint256 value);
   3930 | 
>> 3931 |     function name() external pure returns (string memory);
   3932 |     function symbol() external pure returns (string memory);
   3933 |     function decimals() external pure returns (uint8);
   3934 |     function totalSupply() external view returns (uint256);
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3932 行
- **函数**: `symbol()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3929 |     event Transfer(address indexed from, address indexed to, uint256 value);
   3930 | 
   3931 |     function name() external pure returns (string memory);
>> 3932 |     function symbol() external pure returns (string memory);
   3933 |     function decimals() external pure returns (uint8);
   3934 |     function totalSupply() external view returns (uint256);
   3935 |     function balanceOf(address owner) external view returns (uint256);
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3933 行
- **函数**: `decimals()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3930 | 
   3931 |     function name() external pure returns (string memory);
   3932 |     function symbol() external pure returns (string memory);
>> 3933 |     function decimals() external pure returns (uint8);
   3934 |     function totalSupply() external view returns (uint256);
   3935 |     function balanceOf(address owner) external view returns (uint256);
   3936 |     function allowance(address owner, address spender) external view returns (uint256);
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3934 行
- **函数**: `totalSupply()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3931 |     function name() external pure returns (string memory);
   3932 |     function symbol() external pure returns (string memory);
   3933 |     function decimals() external pure returns (uint8);
>> 3934 |     function totalSupply() external view returns (uint256);
   3935 |     function balanceOf(address owner) external view returns (uint256);
   3936 |     function allowance(address owner, address spender) external view returns (uint256);
   3937 | 
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3935 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3932 |     function symbol() external pure returns (string memory);
   3933 |     function decimals() external pure returns (uint8);
   3934 |     function totalSupply() external view returns (uint256);
>> 3935 |     function balanceOf(address owner) external view returns (uint256);
   3936 |     function allowance(address owner, address spender) external view returns (uint256);
   3937 | 
   3938 |     function approve(address spender, uint256 value) external returns (bool);
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3936 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3933 |     function decimals() external pure returns (uint8);
   3934 |     function totalSupply() external view returns (uint256);
   3935 |     function balanceOf(address owner) external view returns (uint256);
>> 3936 |     function allowance(address owner, address spender) external view returns (uint256);
   3937 | 
   3938 |     function approve(address spender, uint256 value) external returns (bool);
   3939 |     function transfer(address to, uint256 value) external returns (bool);
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3938 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3935 |     function balanceOf(address owner) external view returns (uint256);
   3936 |     function allowance(address owner, address spender) external view returns (uint256);
   3937 | 
>> 3938 |     function approve(address spender, uint256 value) external returns (bool);
   3939 |     function transfer(address to, uint256 value) external returns (bool);
   3940 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   3941 | 
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3939 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3936 |     function allowance(address owner, address spender) external view returns (uint256);
   3937 | 
   3938 |     function approve(address spender, uint256 value) external returns (bool);
>> 3939 |     function transfer(address to, uint256 value) external returns (bool);
   3940 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   3941 | 
   3942 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3940 行
- **函数**: `transferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3937 | 
   3938 |     function approve(address spender, uint256 value) external returns (bool);
   3939 |     function transfer(address to, uint256 value) external returns (bool);
>> 3940 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   3941 | 
   3942 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   3943 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3942 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3939 |     function transfer(address to, uint256 value) external returns (bool);
   3940 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   3941 | 
>> 3942 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   3943 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   3944 |     function nonces(address owner) external view returns (uint256);
   3945 | 
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3943 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3940 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   3941 | 
   3942 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>> 3943 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   3944 |     function nonces(address owner) external view returns (uint256);
   3945 | 
   3946 |     function permit(address owner, address spender, uint256 value, uint256 deadline, uint8 v, bytes32 r, bytes32 s)
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3944 行
- **函数**: `nonces()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3941 | 
   3942 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   3943 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>> 3944 |     function nonces(address owner) external view returns (uint256);
   3945 | 
   3946 |     function permit(address owner, address spender, uint256 value, uint256 deadline, uint8 v, bytes32 r, bytes32 s)
   3947 |         external;
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3961 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3958 |     );
   3959 |     event Sync(uint112 reserve0, uint112 reserve1);
   3960 | 
>> 3961 |     function MINIMUM_LIQUIDITY() external pure returns (uint256);
   3962 |     function factory() external view returns (address);
   3963 |     function token0() external view returns (address);
   3964 |     function token1() external view returns (address);
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3962 行
- **函数**: `factory()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3959 |     event Sync(uint112 reserve0, uint112 reserve1);
   3960 | 
   3961 |     function MINIMUM_LIQUIDITY() external pure returns (uint256);
>> 3962 |     function factory() external view returns (address);
   3963 |     function token0() external view returns (address);
   3964 |     function token1() external view returns (address);
   3965 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3963 行
- **函数**: `token0()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3960 | 
   3961 |     function MINIMUM_LIQUIDITY() external pure returns (uint256);
   3962 |     function factory() external view returns (address);
>> 3963 |     function token0() external view returns (address);
   3964 |     function token1() external view returns (address);
   3965 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   3966 |     function price0CumulativeLast() external view returns (uint256);
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3964 行
- **函数**: `token1()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3961 |     function MINIMUM_LIQUIDITY() external pure returns (uint256);
   3962 |     function factory() external view returns (address);
   3963 |     function token0() external view returns (address);
>> 3964 |     function token1() external view returns (address);
   3965 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   3966 |     function price0CumulativeLast() external view returns (uint256);
   3967 |     function price1CumulativeLast() external view returns (uint256);
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3965 行
- **函数**: `getReserves()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3962 |     function factory() external view returns (address);
   3963 |     function token0() external view returns (address);
   3964 |     function token1() external view returns (address);
>> 3965 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   3966 |     function price0CumulativeLast() external view returns (uint256);
   3967 |     function price1CumulativeLast() external view returns (uint256);
   3968 |     function kLast() external view returns (uint256);
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3966 行
- **函数**: `price0CumulativeLast()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3963 |     function token0() external view returns (address);
   3964 |     function token1() external view returns (address);
   3965 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>> 3966 |     function price0CumulativeLast() external view returns (uint256);
   3967 |     function price1CumulativeLast() external view returns (uint256);
   3968 |     function kLast() external view returns (uint256);
   3969 | 
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3967 行
- **函数**: `price1CumulativeLast()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3964 |     function token1() external view returns (address);
   3965 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   3966 |     function price0CumulativeLast() external view returns (uint256);
>> 3967 |     function price1CumulativeLast() external view returns (uint256);
   3968 |     function kLast() external view returns (uint256);
   3969 | 
   3970 |     function mint(address to) external returns (uint256 liquidity);
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3968 行
- **函数**: `kLast()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3965 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   3966 |     function price0CumulativeLast() external view returns (uint256);
   3967 |     function price1CumulativeLast() external view returns (uint256);
>> 3968 |     function kLast() external view returns (uint256);
   3969 | 
   3970 |     function mint(address to) external returns (uint256 liquidity);
   3971 |     function burn(address to) external returns (uint256 amount0, uint256 amount1);
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3970 行
- **函数**: `mint()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3967 |     function price1CumulativeLast() external view returns (uint256);
   3968 |     function kLast() external view returns (uint256);
   3969 | 
>> 3970 |     function mint(address to) external returns (uint256 liquidity);
   3971 |     function burn(address to) external returns (uint256 amount0, uint256 amount1);
   3972 |     function swap(uint256 amount0Out, uint256 amount1Out, address to, bytes calldata data) external;
   3973 |     function skim(address to) external;
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3971 行
- **函数**: `burn()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3968 |     function kLast() external view returns (uint256);
   3969 | 
   3970 |     function mint(address to) external returns (uint256 liquidity);
>> 3971 |     function burn(address to) external returns (uint256 amount0, uint256 amount1);
   3972 |     function swap(uint256 amount0Out, uint256 amount1Out, address to, bytes calldata data) external;
   3973 |     function skim(address to) external;
   3974 |     function sync() external;
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4133 行
- **函数**: `tokenURI()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4130 | 
   4131 |     string public symbol;
   4132 | 
>> 4133 |     function tokenURI(uint256 id) public view virtual returns (string memory);
   4134 | 
   4135 |     /*//////////////////////////////////////////////////////////////
   4136 |                       ERC721 BALANCE/OWNER STORAGE
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4143 行
- **函数**: `ownerOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4140 | 
   4141 |     mapping(address => uint256) internal _balanceOf;
   4142 | 
>> 4143 |     function ownerOf(uint256 id) public view virtual returns (address owner) {
   4144 |         require((owner = _ownerOf[id]) != address(0), "NOT_MINTED");
   4145 |     }
   4146 | 
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4147 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4144 |         require((owner = _ownerOf[id]) != address(0), "NOT_MINTED");
   4145 |     }
   4146 | 
>> 4147 |     function balanceOf(address owner) public view virtual returns (uint256) {
   4148 |         require(owner != address(0), "ZERO_ADDRESS");
   4149 | 
   4150 |         return _balanceOf[owner];
```

---

### 78. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4174 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4171 |                               ERC721 LOGIC
   4172 |     //////////////////////////////////////////////////////////////*/
   4173 | 
>> 4174 |     function approve(address spender, uint256 id) public virtual {
   4175 |         address owner = _ownerOf[id];
   4176 | 
   4177 |         require(msg.sender == owner || isApprovedForAll[owner][msg.sender], "NOT_AUTHORIZED");
```

---

### 79. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4184 行
- **函数**: `setApprovalForAll()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4181 |         emit Approval(owner, spender, id);
   4182 |     }
   4183 | 
>> 4184 |     function setApprovalForAll(address operator, bool approved) public virtual {
   4185 |         isApprovedForAll[msg.sender][operator] = approved;
   4186 | 
   4187 |         emit ApprovalForAll(msg.sender, operator, approved);
```

---

### 80. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4254 行
- **函数**: `supportsInterface()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4251 |                               ERC165 LOGIC
   4252 |     //////////////////////////////////////////////////////////////*/
   4253 | 
>> 4254 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   4255 |         return
   4256 |             interfaceId == 0x01ffc9a7 || // ERC165 Interface ID for ERC165
   4257 |             interfaceId == 0x80ac58cd || // ERC165 Interface ID for ERC721
```

---

### 81. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4386 行
- **函数**: `uri()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4383 |                              METADATA LOGIC
   4384 |     //////////////////////////////////////////////////////////////*/
   4385 | 
>> 4386 |     function uri(uint256 id) public view virtual returns (string memory);
   4387 | 
   4388 |     /*//////////////////////////////////////////////////////////////
   4389 |                               ERC1155 LOGIC
```

---

### 82. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4392 行
- **函数**: `setApprovalForAll()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4389 |                               ERC1155 LOGIC
   4390 |     //////////////////////////////////////////////////////////////*/
   4391 | 
>> 4392 |     function setApprovalForAll(address operator, bool approved) public virtual {
   4393 |         isApprovedForAll[msg.sender][operator] = approved;
   4394 | 
   4395 |         emit ApprovalForAll(msg.sender, operator, approved);
```

---

### 83. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4484 行
- **函数**: `supportsInterface()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4481 |                               ERC165 LOGIC
   4482 |     //////////////////////////////////////////////////////////////*/
   4483 | 
>> 4484 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   4485 |         return
   4486 |             interfaceId == 0x01ffc9a7 || // ERC165 Interface ID for ERC165
   4487 |             interfaceId == 0xd9b67a26 || // ERC165 Interface ID for ERC1155
```

---

### 84. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4681 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4678 | interface IERC721Permit is IERC721 {
   4679 |     /// @notice The permit typehash used in the permit signature
   4680 |     /// @return The typehash for the permit
>> 4681 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   4682 | 
   4683 |     /// @notice The domain separator used in the permit signature
   4684 |     /// @return The domain seperator used in encoding of permit signature
```

---

### 85. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4685 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4682 | 
   4683 |     /// @notice The domain separator used in the permit signature
   4684 |     /// @return The domain seperator used in encoding of permit signature
>> 4685 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   4686 | 
   4687 |     /// @notice Approve of a specific token ID for spending by spender via signature
   4688 |     /// @param spender The account that is being approved
```

---

### 86. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4737 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4734 | pragma solidity ^0.8.17;
   4735 | 
   4736 | interface IEIP712 {
>> 4737 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   4738 | }
   4739 | 
   4740 | 
```

---

### 87. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4767 行
- **函数**: `lockAcquired()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4764 | 
   4765 |     /// @inheritdoc ILockCallback
   4766 |     /// @dev We force the onlyByVault modifier by exposing a virtual function after the onlyByVault check.
>> 4767 |     function lockAcquired(bytes calldata data) external onlyByVault returns (bytes memory) {
   4768 |         return _lockAcquired(data);
   4769 |     }
   4770 | 
```

---

### 88. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4829 行
- **函数**: `getHooksRegistrationBitmap()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4826 | pragma solidity ^0.8.0;
   4827 | 
   4828 | interface IHooks {
>> 4829 |     function getHooksRegistrationBitmap() external view returns (uint16);
   4830 | }
   4831 | 
   4832 | 
```

---

### 89. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 5379 行
- **函数**: `protocolFeesAccrued()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5376 |     /// @notice Given a currency address, returns the protocol fees accrued in that currency
   5377 |     /// @param currency The currency to check
   5378 |     /// @return amount The amount of protocol fees accrued in the given currency
>> 5379 |     function protocolFeesAccrued(Currency currency) external view returns (uint256 amount);
   5380 | 
   5381 |     /// @notice Returns the current protocol fee controller address
   5382 |     /// @return IProtocolFeeController The currency protocol fee controller
```

---

### 90. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 5383 行
- **函数**: `protocolFeeController()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5380 | 
   5381 |     /// @notice Returns the current protocol fee controller address
   5382 |     /// @return IProtocolFeeController The currency protocol fee controller
>> 5383 |     function protocolFeeController() external view returns (IProtocolFeeController);
   5384 | 
   5385 |     /// @notice Sets the protocol's swap fee for the given pool
   5386 |     /// @param key The pool key for which to set the protocol fee
```

---

### 91. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 5406 行
- **函数**: `vault()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5403 | 
   5404 |     /// @notice Returns the vault where the protocol fees are safely stored
   5405 |     /// @return IVault The address of the vault
>> 5406 |     function vault() external view returns (IVault);
   5407 | }
   5408 | 
   5409 | 
```

---

### 92. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 5601 行
- **函数**: `extsload()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5598 |     /// @notice Called by external contracts to access granular pool state
   5599 |     /// @param slot Key of slot to sload
   5600 |     /// @return value The value of the slot as bytes32
>> 5601 |     function extsload(bytes32 slot) external view returns (bytes32 value);
   5602 | 
   5603 |     /// @notice Called by external contracts to access sparse pool state
   5604 |     /// @param slots List of slots to SLOAD from.
```

---

### 93. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 5606 行
- **函数**: `extsload()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5603 |     /// @notice Called by external contracts to access sparse pool state
   5604 |     /// @param slots List of slots to SLOAD from.
   5605 |     /// @return values List of loaded values.
>> 5606 |     function extsload(bytes32[] calldata slots) external view returns (bytes32[] memory values);
   5607 | }
   5608 | 
   5609 | 
```

---

### 94. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6417 行
- **函数**: `nonceBitmap()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6414 |     /// @dev The mapping is indexed first by the token owner, then by an index specified in the nonce
   6415 |     /// @dev It returns a uint256 bitmap
   6416 |     /// @dev The index, or wordPosition is capped at type(uint248).max
>> 6417 |     function nonceBitmap(address, uint256) external view returns (uint256);
   6418 | 
   6419 |     /// @notice Transfers a token using a signed permit message
   6420 |     /// @dev Reverts if the requested amount is greater than the permitted signed amount
```

---

### 95. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6500 行
- **函数**: `vault()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6497 | /// @notice Interface for the ImmutableState contract
   6498 | interface IImmutableState {
   6499 |     /// @notice The Pancakeswap Infinity Vault contract
>> 6500 |     function vault() external view returns (IVault);
   6501 | }
   6502 | 
   6503 | 
```

---

### 96. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6532 行
- **函数**: `totalSupply()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6529 |     /**
   6530 |      * @dev Returns the value of tokens in existence.
   6531 |      */
>> 6532 |     function totalSupply() external view returns (uint256);
   6533 | 
   6534 |     /**
   6535 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 97. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6537 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6534 |     /**
   6535 |      * @dev Returns the value of tokens owned by `account`.
   6536 |      */
>> 6537 |     function balanceOf(address account) external view returns (uint256);
   6538 | 
   6539 |     /**
   6540 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 98. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6546 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6543 |      *
   6544 |      * Emits a {Transfer} event.
   6545 |      */
>> 6546 |     function transfer(address to, uint256 value) external returns (bool);
   6547 | 
   6548 |     /**
   6549 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 99. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6555 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6552 |      *
   6553 |      * This value changes when {approve} or {transferFrom} are called.
   6554 |      */
>> 6555 |     function allowance(address owner, address spender) external view returns (uint256);
   6556 | 
   6557 |     /**
   6558 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 100. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6572 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6569 |      *
   6570 |      * Emits an {Approval} event.
   6571 |      */
>> 6572 |     function approve(address spender, uint256 value) external returns (bool);
   6573 | 
   6574 |     /**
   6575 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 101. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6583 行
- **函数**: `transferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6580 |      *
   6581 |      * Emits a {Transfer} event.
   6582 |      */
>> 6583 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   6584 | }
   6585 | 
   6586 | 
```

---

### 102. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7356 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7353 |     /// @param owner The address you want to query the balance of
   7354 |     /// @param currency The currency you want to query the balance of
   7355 |     /// @return balance The balance of the specified address
>> 7356 |     function balanceOf(address owner, Currency currency) external view returns (uint256 balance);
   7357 | 
   7358 |     /// @notice get the amount that owner has authorized for spender to use
   7359 |     /// @param owner The address of the owner
```

---

### 103. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7363 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7360 |     /// @param spender The address who is allowed to spend the owner's token
   7361 |     /// @param currency The currency the spender is allowed to spend
   7362 |     /// @return amount The amount of token the spender is allowed to spend
>> 7363 |     function allowance(address owner, address spender, Currency currency) external view returns (uint256 amount);
   7364 | 
   7365 |     /// @notice approve spender for using user's token
   7366 |     /// @param spender The address msg.sender is approving to spend the his token
```

---

### 104. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7370 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7367 |     /// @param currency The currency the spender is allowed to spend
   7368 |     /// @param amount The amount of token the spender is allowed to spend
   7369 |     /// @return bool Whether the approval was successful or not
>> 7370 |     function approve(address spender, Currency currency, uint256 amount) external returns (bool);
   7371 | 
   7372 |     /// @notice transfer msg.sender's token to someone else
   7373 |     /// @param to The address to transfer the token to
```

---

### 105. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7377 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7374 |     /// @param currency The currency to transfer
   7375 |     /// @param amount The amount of token to transfer
   7376 |     /// @return bool Whether the transfer was successful or not
>> 7377 |     function transfer(address to, Currency currency, uint256 amount) external returns (bool);
   7378 | 
   7379 |     /// @notice transfer from address's token on behalf of him
   7380 |     /// @param from The address to transfer the token from
```

---

### 106. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7385 行
- **函数**: `transferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7382 |     /// @param currency The currency to transfer
   7383 |     /// @param amount The amount of token to transfer
   7384 |     /// @return bool Whether the transfer was successful or not
>> 7385 |     function transferFrom(address from, address to, Currency currency, uint256 amount) external returns (bool);
   7386 | }
   7387 | 
   7388 | 
```

---

### 107. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7400 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7397 |     /// @notice Returns the balance of a token
   7398 |     /// @param account The account for which to look up the number of tokens it has, i.e. its balance
   7399 |     /// @return The number of tokens held by the account
>> 7400 |     function balanceOf(address account) external view returns (uint256);
   7401 | 
   7402 |     /// @notice Transfers the amount of token from the `msg.sender` to the recipient
   7403 |     /// @param recipient The account that will receive the amount transferred
```

---

### 108. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7406 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7403 |     /// @param recipient The account that will receive the amount transferred
   7404 |     /// @param amount The number of tokens to send from the sender to the recipient
   7405 |     /// @return Returns true for a successful transfer, false for an unsuccessful transfer
>> 7406 |     function transfer(address recipient, uint256 amount) external returns (bool);
   7407 | 
   7408 |     /// @notice Returns the current allowance given to a spender by an owner
   7409 |     /// @param owner The account of the token owner
```

---

### 109. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7412 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7409 |     /// @param owner The account of the token owner
   7410 |     /// @param spender The account of the token spender
   7411 |     /// @return The current allowance granted by `owner` to `spender`
>> 7412 |     function allowance(address owner, address spender) external view returns (uint256);
   7413 | 
   7414 |     /// @notice Sets the allowance of a spender from the `msg.sender` to the value `amount`
   7415 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
```

---

### 110. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7418 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7415 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
   7416 |     /// @param amount The amount of tokens allowed to be used by `spender`
   7417 |     /// @return Returns true for a successful approval, false for unsuccessful
>> 7418 |     function approve(address spender, uint256 amount) external returns (bool);
   7419 | 
   7420 |     /// @notice Transfers `amount` tokens from `sender` to `recipient` up to the allowance given to the `msg.sender`
   7421 |     /// @param sender The account from which the transfer will be initiated
```

---

### 111. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7425 行
- **函数**: `transferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7422 |     /// @param recipient The recipient of the transfer
   7423 |     /// @param amount The amount of the transfer
   7424 |     /// @return Returns true for a successful transfer, false for unsuccessful
>> 7425 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
   7426 | 
   7427 |     /// @notice Event emitted when tokens are transferred from one address to another, either via `#transfer` or `#transferFrom`.
   7428 |     /// @param from The account from which the tokens were sent, i.e. the balance decreased
```

---

### 112. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7517 行
- **函数**: `pairLength()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7514 |     }
   7515 | 
   7516 |     // solium-disable-next-line mixedcase
>> 7517 |     function pairLength() external view returns (uint256);
   7518 | 
   7519 |     function getPairInfo(address _tokenA, address _tokenB) external view returns (StableSwapPairInfo memory info);
   7520 | 
```

---

### 113. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7519 行
- **函数**: `getPairInfo()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7516 |     // solium-disable-next-line mixedcase
   7517 |     function pairLength() external view returns (uint256);
   7518 | 
>> 7519 |     function getPairInfo(address _tokenA, address _tokenB) external view returns (StableSwapPairInfo memory info);
   7520 | 
   7521 |     function getThreePoolPairInfo(address _tokenA, address _tokenB)
   7522 |         external
```

---

### 114. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7534 行
- **函数**: `get_dx()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7531 | pragma solidity ^0.8.0;
   7532 | 
   7533 | interface IStableSwapInfo {
>> 7534 |     function get_dx(address _swap, uint256 i, uint256 j, uint256 dy, uint256 max_dx) external view returns (uint256);
   7535 | }
   7536 | 
   7537 | 
```

---

### 115. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7595 行
- **函数**: `owner()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7592 |     /**
   7593 |      * @dev Returns the address of the current owner.
   7594 |      */
>> 7595 |     function owner() public view virtual returns (address) {
   7596 |         return _owner;
   7597 |     }
   7598 | 
```

---

### 116. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7652 行
- **函数**: `factory()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7649 | interface IPancakeV3PoolImmutables {
   7650 |     /// @notice The contract that deployed the pool, which must adhere to the IPancakeV3Factory interface
   7651 |     /// @return The contract address
>> 7652 |     function factory() external view returns (address);
   7653 | 
   7654 |     /// @notice The first of the two tokens of the pool, sorted by address
   7655 |     /// @return The token contract address
```

---

### 117. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7656 行
- **函数**: `token0()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7653 | 
   7654 |     /// @notice The first of the two tokens of the pool, sorted by address
   7655 |     /// @return The token contract address
>> 7656 |     function token0() external view returns (address);
   7657 | 
   7658 |     /// @notice The second of the two tokens of the pool, sorted by address
   7659 |     /// @return The token contract address
```

---

### 118. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7660 行
- **函数**: `token1()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7657 | 
   7658 |     /// @notice The second of the two tokens of the pool, sorted by address
   7659 |     /// @return The token contract address
>> 7660 |     function token1() external view returns (address);
   7661 | 
   7662 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   7663 |     /// @return The fee
```

---

### 119. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7664 行
- **函数**: `fee()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7661 | 
   7662 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   7663 |     /// @return The fee
>> 7664 |     function fee() external view returns (uint24);
   7665 | 
   7666 |     /// @notice The pool tick spacing
   7667 |     /// @dev Ticks can only be used at multiples of this value, minimum of 1 and always positive
```

---

### 120. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7671 行
- **函数**: `tickSpacing()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7668 |     /// e.g.: a tickSpacing of 3 means ticks can be initialized every 3rd tick, i.e., ..., -6, -3, 0, 3, 6, ...
   7669 |     /// This value is an int24 to avoid casting even though it is always positive.
   7670 |     /// @return The tick spacing
>> 7671 |     function tickSpacing() external view returns (int24);
   7672 | 
   7673 |     /// @notice The maximum amount of position liquidity that can use any tick in the range
   7674 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
```

---

### 121. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7677 行
- **函数**: `maxLiquidityPerTick()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7674 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
   7675 |     /// also prevents out-of-range liquidity from being used to prevent adding in-range liquidity to a pool
   7676 |     /// @return The max amount of liquidity per tick
>> 7677 |     function maxLiquidityPerTick() external view returns (uint128);
   7678 | }
   7679 | 
   7680 | 
```

---

### 122. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7718 行
- **函数**: `feeGrowthGlobal0X128()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7715 | 
   7716 |     /// @notice The fee growth as a Q128.128 fees of token0 collected per unit of liquidity for the entire life of the pool
   7717 |     /// @dev This value can overflow the uint256
>> 7718 |     function feeGrowthGlobal0X128() external view returns (uint256);
   7719 | 
   7720 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   7721 |     /// @dev This value can overflow the uint256
```

---

### 123. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7722 行
- **函数**: `feeGrowthGlobal1X128()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7719 | 
   7720 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   7721 |     /// @dev This value can overflow the uint256
>> 7722 |     function feeGrowthGlobal1X128() external view returns (uint256);
   7723 | 
   7724 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   7725 |     /// @dev Protocol fees will never exceed uint128 max in either token
```

---

### 124. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7726 行
- **函数**: `protocolFees()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7723 | 
   7724 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   7725 |     /// @dev Protocol fees will never exceed uint128 max in either token
>> 7726 |     function protocolFees() external view returns (uint128 token0, uint128 token1);
   7727 | 
   7728 |     /// @notice The currently in range liquidity available to the pool
   7729 |     /// @dev This value has no relationship to the total liquidity across all ticks
```

---

### 125. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7730 行
- **函数**: `liquidity()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7727 | 
   7728 |     /// @notice The currently in range liquidity available to the pool
   7729 |     /// @dev This value has no relationship to the total liquidity across all ticks
>> 7730 |     function liquidity() external view returns (uint128);
   7731 | 
   7732 |     /// @notice Look up information about a specific tick in the pool
   7733 |     /// @param tick The tick to look up
```

---

### 126. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7761 行
- **函数**: `tickBitmap()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   7758 |         );
   7759 | 
   7760 |     /// @notice Returns 256 packed tick initialized boolean values. See TickBitmap for more information
>> 7761 |     function tickBitmap(int16 wordPosition) external view returns (uint256);
   7762 | 
   7763 |     /// @notice Returns the information about a position by the position's key
   7764 |     /// @param key The position's key is a hash of a preimage composed by the owner, tickLower and tickUpper
```

---

### 127. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8126 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8123 |     /**
   8124 |      * @dev Returns the number of tokens in ``owner``'s account.
   8125 |      */
>> 8126 |     function balanceOf(address owner) external view returns (uint256 balance);
   8127 | 
   8128 |     /**
   8129 |      * @dev Returns the owner of the `tokenId` token.
```

---

### 128. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8135 行
- **函数**: `ownerOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8132 |      *
   8133 |      * - `tokenId` must exist.
   8134 |      */
>> 8135 |     function ownerOf(uint256 tokenId) external view returns (address owner);
   8136 | 
   8137 |     /**
   8138 |      * @dev Safely transfers `tokenId` token from `from` to `to`.
```

---

### 129. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8223 行
- **函数**: `getApproved()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8220 |      *
   8221 |      * - `tokenId` must exist.
   8222 |      */
>> 8223 |     function getApproved(uint256 tokenId) external view returns (address operator);
   8224 | 
   8225 |     /**
   8226 |      * @dev Returns if the `operator` is allowed to manage all of the assets of `owner`.
```

---

### 130. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8230 行
- **函数**: `isApprovedForAll()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8227 |      *
   8228 |      * See {setApprovalForAll}
   8229 |      */
>> 8230 |     function isApprovedForAll(address owner, address operator) external view returns (bool);
   8231 | }
   8232 | 
   8233 | 
```

---

### 131. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8244 行
- **函数**: `lockAcquired()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   8241 |     /// @notice Called by the pool manager on `msg.sender` when a lock is acquired
   8242 |     /// @param data The data that was passed to the call to lock
   8243 |     /// @return Any data that you want to be returned from the lock call
>> 8244 |     function lockAcquired(bytes calldata data) external returns (bytes memory);
   8245 | }
   8246 | 
   8247 | 
```

---

### 132. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 9467 行
- **函数**: `protocolFeeForPool()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   9464 |     /// @return protocolFee The pool's protocol fee, expressed in hundredths of a bip. The upper 12 bits are for 1->0
   9465 |     /// and the lower 12 are for 0->1. The maximum is 4000 - meaning the maximum protocol fee is 0.4%.
   9466 |     /// the protocolFee is taken from the input first, then the lpFee is taken from the remaining input
>> 9467 |     function protocolFeeForPool(PoolKey memory poolKey) external view returns (uint24 protocolFee);
   9468 | }
   9469 | 
   9470 | 
```

---

### 133. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 11451 行
- **函数**: `binPoolManager()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   11448 |         bytes hookData;
   11449 |     }
   11450 | 
>> 11451 |     function binPoolManager() external view returns (IBinPoolManager);
   11452 | 
   11453 |     /// @notice Initialize a infinity PCS bin pool
   11454 |     /// @dev If the pool is already initialized, this function will not revert
```

---

### 134. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 11457 行
- **函数**: `initializePool()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   11454 |     /// @dev If the pool is already initialized, this function will not revert
   11455 |     /// @param key the PoolKey of the pool to initialize
   11456 |     /// @param activeId the active bin id of the pool
>> 11457 |     function initializePool(PoolKey memory key, uint24 activeId) external payable;
   11458 | 
   11459 |     /// @notice Return the position information associated with a given tokenId
   11460 |     /// @dev Revert if non-existent tokenId
```

---

### 135. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 11464 行
- **函数**: `positions()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   11461 |     /// @param tokenId Id of the token that represent position
   11462 |     /// @return poolKey the pool key of the position
   11463 |     /// @return binId the binId of the position
>> 11464 |     function positions(uint256 tokenId) external view returns (PoolKey memory poolKey, uint24 binId);
   11465 | }
   11466 | 
   11467 | 
```

---

### 136. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 11531 行
- **函数**: `supportsInterface()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   11528 |      *
   11529 |      * This function call must use less than 30 000 gas.
   11530 |      */
>> 11531 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   11532 | }
   11533 | 
   11534 | 
```

---

### 137. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 115 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    110 | import {PoolKey} from "infinity-core/src/types/PoolKey.sol";
    111 | import {ICLPoolManager} from "infinity-core/src/pool-cl/interfaces/ICLPoolManager.sol";
    112 | import {IBinPoolManager} from "infinity-core/src/pool-bin/interfaces/IBinPoolManager.sol";
    113 | 
    114 | /// @title Decodes and Executes Commands
>>  115 | /// @notice Called by the UniversalRouter contract to efficiently decode and execute a singular command
    116 | abstract contract Dispatcher is
    117 |     Payments,
    118 |     V2SwapRouter,
    119 |     V3SwapRouter,
    120 |     StableSwapRouter,
```

---

### 138. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 505 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    500 |     address v3Deployer;
    501 |     bytes32 v2InitCodeHash;
    502 |     bytes32 v3InitCodeHash;
    503 |     address stableFactory;
    504 |     address stableInfo;
>>  505 |     // PCS infinity swapping parameters, param not in this contract as stored in infiSwapRouter
    506 |     address infiVault;
    507 |     address infiClPoolManager;
    508 |     address infiBinPoolManager;
    509 |     // PCS v3->infinity migration parameters
    510 |     address v3NFTPositionManager;
```

---

### 139. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 577 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    572 | import {ICLPoolManager} from "infinity-core/src/pool-cl/interfaces/ICLPoolManager.sol";
    573 | import {IBinPoolManager} from "infinity-core/src/pool-bin/interfaces/IBinPoolManager.sol";
    574 | import {Currency} from "infinity-core/src/types/Currency.sol";
    575 | 
    576 | /// @title Router for PCS Infinity Trades
>>  577 | abstract contract InfinitySwapRouter is InfinityRouter, Permit2Payments {
    578 |     constructor(address _vault, address _clPoolManager, address _binPoolManager)
    579 |         InfinityRouter(IVault(_vault), ICLPoolManager(_clPoolManager), IBinPoolManager(_binPoolManager))
    580 |     {}
    581 | 
    582 |     function _pay(Currency token, address payer, uint256 amount) internal override {
```

---

### 140. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 721 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    716 | import {SafeTransferLib} from "solmate/src/utils/SafeTransferLib.sol";
    717 | import {Ownable, Ownable2Step} from "@openzeppelin/contracts/access/Ownable2Step.sol";
    718 | import {IStableSwap} from "../../interfaces/IStableSwap.sol";
    719 | 
    720 | /// @title Router for PancakeSwap Stable Trades
>>  721 | abstract contract StableSwapRouter is RouterImmutables, Permit2Payments, Ownable2Step {
    722 |     using SafeTransferLib for ERC20;
    723 |     using UniversalRouterHelper for address;
    724 | 
    725 |     error StableTooLittleReceived();
    726 |     error StableTooMuchRequested();
```

---

### 141. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 849 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    844 |  * This module is used through inheritance. It will make available the
    845 |  * modifiers `whenNotPaused` and `whenPaused`, which can be applied to
    846 |  * the functions of your contract. Note that they will not be pausable by
    847 |  * simply including this module, only once the modifiers are put in place.
    848 |  */
>>  849 | abstract contract Pausable is Context {
    850 |     bool private _paused;
    851 | 
    852 |     /**
    853 |      * @dev Emitted when the pause is triggered by `account`.
    854 |      */
```

---

### 142. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 968 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    963 | import {Constants} from "../../../libraries/Constants.sol";
    964 | import {UniversalRouterHelper} from "../../../libraries/UniversalRouterHelper.sol";
    965 | import {ERC20} from "solmate/src/tokens/ERC20.sol";
    966 | 
    967 | /// @title Router for PancakeSwap v2 Trades
>>  968 | abstract contract V2SwapRouter is RouterImmutables, Permit2Payments {
    969 |     error V2TooLittleReceived();
    970 |     error V2TooMuchRequested();
    971 |     error V2InvalidPath();
    972 | 
    973 |     function _v2Swap(address[] calldata path, address recipient, address pair) private {
```

---

### 143. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1076 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1071 | import {MaxInputAmount} from "../../../libraries/MaxInputAmount.sol";
   1072 | import {ERC20} from "solmate/src/tokens/ERC20.sol";
   1073 | import {CalldataDecoder} from "infinity-periphery/src/libraries/CalldataDecoder.sol";
   1074 | 
   1075 | /// @title Router for PancakeSwap v3 Trades
>> 1076 | abstract contract V3SwapRouter is RouterImmutables, Permit2Payments, IPancakeV3SwapCallback {
   1077 |     using UniversalRouterHelper for bytes;
   1078 |     using BytesLib for bytes;
   1079 |     using CalldataDecoder for bytes;
   1080 |     using SafeCast for uint256;
   1081 | 
```

---

### 144. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1141 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1136 |         uint256 amountIn,
   1137 |         uint256 amountOutMinimum,
   1138 |         bytes calldata path,
   1139 |         address payer
   1140 |     ) internal {
>> 1141 |         // use amountIn == ActionConstants.CONTRACT_BALANCE as a flag to swap the entire balance of the contract
   1142 |         if (amountIn == ActionConstants.CONTRACT_BALANCE) {
   1143 |             address tokenIn = path.decodeFirstToken();
   1144 |             amountIn = ERC20(tokenIn).balanceOf(address(this));
   1145 |         }
   1146 | 
```

---

### 145. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1241 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1236 | import {ERC721} from "solmate/src/tokens/ERC721.sol";
   1237 | import {ERC1155} from "solmate/src/tokens/ERC1155.sol";
   1238 | 
   1239 | /// @title Payments contract
   1240 | /// @notice Performs various operations around the payment of ETH and tokens
>> 1241 | abstract contract Payments is RouterImmutables {
   1242 |     using SafeTransferLib for ERC20;
   1243 |     using SafeTransferLib for address;
   1244 |     using BipsLibrary for uint256;
   1245 | 
   1246 |     error InsufficientToken();
```

---

### 146. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1614 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1609 | 
   1610 | /// @notice Modern and gas efficient ERC20 + EIP-2612 implementation.
   1611 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC20.sol)
   1612 | /// @author Modified from Uniswap (https://github.com/Uniswap/uniswap-v2-core/blob/master/contracts/UniswapV2ERC20.sol)
   1613 | /// @dev Do not manually set balances without updating totalSupply, as the sum of all user balances must not exceed it.
>> 1614 | abstract contract ERC20 {
   1615 |     /*//////////////////////////////////////////////////////////////
   1616 |                                  EVENTS
   1617 |     //////////////////////////////////////////////////////////////*/
   1618 | 
   1619 |     event Transfer(address indexed from, address indexed to, uint256 amount);
```

---

### 147. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1824 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1819 | 
   1820 | import {IEIP712} from "./IEIP712.sol";
   1821 | 
   1822 | /// @title AllowanceTransfer
   1823 | /// @notice Handles ERC20 token permissions through signature based allowance setting and ERC20 token transfers by checking allowed amounts
>> 1824 | /// @dev Requires user's token approval on the Permit2 contract
   1825 | interface IAllowanceTransfer is IEIP712 {
   1826 |     /// @notice Thrown when an allowance on a token has expired.
   1827 |     /// @param deadline The timestamp at which the allowed amount is no longer valid
   1828 |     error AllowanceExpired(uint256 deadline);
   1829 | 
```

---

### 148. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2538 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2533 | import {IExtsload} from "../../interfaces/IExtsload.sol";
   2534 | import {IHooks} from "../../interfaces/IHooks.sol";
   2535 | import {BinPosition, BinPool} from "../libraries/BinPool.sol";
   2536 | 
   2537 | interface IBinPoolManager is IProtocolFees, IPoolManager, IExtsload {
>> 2538 |     /// @notice PoolManagerMismatch is thrown when pool manager specified in the pool key does not match current contract
   2539 |     error PoolManagerMismatch();
   2540 | 
   2541 |     /// @notice Pool binStep cannot be lesser than 1. Otherwise there will be no price jump between bin
   2542 |     error BinStepTooSmall(uint16 binStep);
   2543 | 
```

---

### 149. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2932 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2927 | pragma solidity ^0.8.24;
   2928 | 
   2929 | import {IImmutableState} from "./IImmutableState.sol";
   2930 | 
   2931 | /// @title IPositionManager
>> 2932 | /// @notice Interface for the PositionManager contract
   2933 | interface IPositionManager is IImmutableState {
   2934 |     /// @notice Thrown when the block.timestamp exceeds the user-provided deadline
   2935 |     error DeadlinePassed(uint256 deadline);
   2936 | 
   2937 |     /// @notice Thrown when calling transfer, subscribe, or unsubscribe on CLPositionManager
```

---

### 150. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 2989 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2984 | import {SafeCast160} from "permit2/src/libraries/SafeCast160.sol";
   2985 | import {Payments} from "./Payments.sol";
   2986 | 
   2987 | /// @title Payments through Permit2
   2988 | /// @notice Performs interactions with Permit2 to transfer tokens
>> 2989 | abstract contract Permit2Payments is Payments {
   2990 |     using SafeCast160 for uint256;
   2991 | 
   2992 |     error FromAddressIsNotOwner();
   2993 | 
   2994 |     /// @notice Performs a transferFrom on Permit2
```

---

### 151. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3821 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3816 |  * can later be changed with {transferOwnership} and {acceptOwnership}.
   3817 |  *
   3818 |  * This module is used through inheritance. It will make available all functions
   3819 |  * from parent (Ownable).
   3820 |  */
>> 3821 | abstract contract Ownable2Step is Ownable {
   3822 |     address private _pendingOwner;
   3823 | 
   3824 |     event OwnershipTransferStarted(address indexed previousOwner, address indexed newOwner);
   3825 | 
   3826 |     /**
```

---

### 152. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4045 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4040 | 
   4041 | // SPDX-License-Identifier: MIT
   4042 | pragma solidity ^0.8.0;
   4043 | 
   4044 | /// @title Callback for IPancakeV3PoolActions#swap
>> 4045 | /// @notice Any contract that calls IPancakeV3PoolActions#swap must implement this interface
   4046 | interface IPancakeV3SwapCallback {
   4047 |     /// @notice Called to `msg.sender` after executing a swap via IPancakeV3Pool#swap.
   4048 |     /// @dev In the implementation you must pay the pool tokens owed for the swap.
   4049 |     /// The caller of this method must be checked to be a PancakeV3Pool deployed by the canonical PancakeV3Factory.
   4050 |     /// amount0Delta and amount1Delta can both be 0 if no tokens were swapped.
```

---

### 153. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4114 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4109 | // SPDX-License-Identifier: AGPL-3.0-only
   4110 | pragma solidity >=0.8.0;
   4111 | 
   4112 | /// @notice Modern, minimalist, and gas efficient ERC-721 implementation.
   4113 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC721.sol)
>> 4114 | abstract contract ERC721 {
   4115 |     /*//////////////////////////////////////////////////////////////
   4116 |                                  EVENTS
   4117 |     //////////////////////////////////////////////////////////////*/
   4118 | 
   4119 |     event Transfer(address indexed from, address indexed to, uint256 indexed id);
```

---

### 154. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4328 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4323 |             "UNSAFE_RECIPIENT"
   4324 |         );
   4325 |     }
   4326 | }
   4327 | 
>> 4328 | /// @notice A generic interface for a contract which properly accepts ERC721 tokens.
   4329 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC721.sol)
   4330 | abstract contract ERC721TokenReceiver {
   4331 |     function onERC721Received(
   4332 |         address,
   4333 |         address,
```

---

### 155. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4349 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4344 | // SPDX-License-Identifier: AGPL-3.0-only
   4345 | pragma solidity >=0.8.0;
   4346 | 
   4347 | /// @notice Minimalist and gas efficient standard ERC1155 implementation.
   4348 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC1155.sol)
>> 4349 | abstract contract ERC1155 {
   4350 |     /*//////////////////////////////////////////////////////////////
   4351 |                                  EVENTS
   4352 |     //////////////////////////////////////////////////////////////*/
   4353 | 
   4354 |     event TransferSingle(
```

---

### 156. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4578 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4573 | 
   4574 |         emit TransferSingle(msg.sender, from, address(0), id, amount);
   4575 |     }
   4576 | }
   4577 | 
>> 4578 | /// @notice A generic interface for a contract which properly accepts ERC1155 tokens.
   4579 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC1155.sol)
   4580 | abstract contract ERC1155TokenReceiver {
   4581 |     function onERC1155Received(
   4582 |         address,
   4583 |         address,
```

---

### 157. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4706 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4701 | 
   4702 | // SPDX-License-Identifier: GPL-3.0-or-later
   4703 | pragma solidity ^0.8.24;
   4704 | 
   4705 | /// @notice A library to implement a reentrancy lock in transient storage.
>> 4706 | /// @dev Instead of storing a boolean, the locker's address is stored to allow the contract to know who locked the contract
   4707 | /// TODO: This library can be deleted when we have the transient keyword support in solidity.
   4708 | library Locker {
   4709 |     // The slot holding the locker state, transiently. bytes32(uint256(keccak256("Locker")) - 1)
   4710 |     bytes32 constant LOCKER_SLOT = 0x0e87e1788ebd9ed6a7e63c70a374cd3283e41cad601d21fbe27863899ed4a708;
   4711 | 
```

---

### 158. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6360 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   6355 | 
   6356 | import {IEIP712} from "./IEIP712.sol";
   6357 | 
   6358 | /// @title SignatureTransfer
   6359 | /// @notice Handles ERC20 token transfers through signature based actions
>> 6360 | /// @dev Requires user's token approval on the Permit2 contract
   6361 | interface ISignatureTransfer is IEIP712 {
   6362 |     /// @notice Thrown when the requested amount for a transfer is larger than the permissioned amount
   6363 |     /// @param maxAmount The maximum amount a spender can request to transfer
   6364 |     error InvalidAmount(uint256 maxAmount);
   6365 | 
```

---

### 159. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6499 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   6494 | import {IVault} from "infinity-core/src/interfaces/IVault.sol";
   6495 | 
   6496 | /// @title IImmutableState
   6497 | /// @notice Interface for the ImmutableState contract
   6498 | interface IImmutableState {
>> 6499 |     /// @notice The Pancakeswap Infinity Vault contract
   6500 |     function vault() external view returns (IVault);
   6501 | }
   6502 | 
   6503 | 
   6504 | // ── lib/infinity-periphery/lib/infinity-core/lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol ──────────────────────────────
```

---

### 160. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 6636 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   6631 | 
   6632 | import {Currency} from "infinity-core/src/types/Currency.sol";
   6633 | import {ImmutableState} from "./ImmutableState.sol";
   6634 | import {ActionConstants} from "../libraries/ActionConstants.sol";
   6635 | 
>> 6636 | /// @notice Abstract contract used to sync, send, and settle funds to the vault
   6637 | /// @dev Note that sync() is called before any erc-20 transfer in `settle`.
   6638 | abstract contract DeltaResolver is ImmutableState {
   6639 |     /// @notice Emitted trying to settle a positive delta.
   6640 |     error DeltaNotPositive(Currency currency);
   6641 |     /// @notice Emitted trying to take a negative delta.
```

---

### 161. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7559 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   7554 |  *
   7555 |  * This module is used through inheritance. It will make available the modifier
   7556 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
   7557 |  * the owner.
   7558 |  */
>> 7559 | abstract contract Ownable is Context {
   7560 |     address private _owner;
   7561 | 
   7562 |     /**
   7563 |      * @dev The caller account is not authorized to perform an operation.
   7564 |      */
```

---

### 162. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7631 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   7626 |         }
   7627 |         _transferOwnership(newOwner);
   7628 |     }
   7629 | 
   7630 |     /**
>> 7631 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
   7632 |      * Internal function without access restriction.
   7633 |      */
   7634 |     function _transferOwnership(address newOwner) internal virtual {
   7635 |         address oldOwner = _owner;
   7636 |         _owner = newOwner;
```

---

### 163. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7650 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   7645 | pragma solidity ^0.8.0;
   7646 | 
   7647 | /// @title Pool state that never changes
   7648 | /// @notice These parameters are fixed for a pool forever, i.e., the methods will always return the same values
   7649 | interface IPancakeV3PoolImmutables {
>> 7650 |     /// @notice The contract that deployed the pool, which must adhere to the IPancakeV3Factory interface
   7651 |     /// @return The contract address
   7652 |     function factory() external view returns (address);
   7653 | 
   7654 |     /// @notice The first of the two tokens of the pool, sorted by address
   7655 |     /// @return The token contract address
```

---

### 164. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 10029 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   10024 | 
   10025 | // SPDX-License-Identifier: GPL-2.0-or-later
   10026 | // Copyright (C) 2024 PancakeSwap
   10027 | pragma solidity ^0.8.0;
   10028 | 
>> 10029 | /// @notice Helper contract used for full precision calculations
   10030 | library Uint256x256Math {
   10031 |     error Uint256x256Math__MulShiftOverflow();
   10032 |     error Uint256x256Math__MulDivOverflow();
   10033 | 
   10034 |     /// @notice Calculates floor(x*y/denominator) with full precision
```

---

### 165. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 11847 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   11842 | pragma solidity ^0.8.0;
   11843 | 
   11844 | import {Constants} from "../Constants.sol";
   11845 | import {BitMath} from "./BitMath.sol";
   11846 | 
>> 11847 | /// @notice Helper contract used for power and log calculations
   11848 | library Uint128x128Math {
   11849 |     using BitMath for uint256;
   11850 | 
   11851 |     error Uint128x128Math__LogUnderflow();
   11852 |     error Uint128x128Math__PowUnderflow(uint256 x, int256 y);
```

---

### 166. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 25 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     22 |     {}
     23 | 
     24 |     modifier checkDeadline(uint256 deadline) {
>>   25 |         if (block.timestamp > deadline) revert TransactionDeadlinePassed();
     26 |         _;
     27 |     }
     28 | 
```

---

### 167. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1731 行
- **函数**: `permit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1728 |         bytes32 r,
   1729 |         bytes32 s
   1730 |     ) public virtual {
>> 1731 |         require(deadline >= block.timestamp, "PERMIT_DEADLINE_EXPIRED");
   1732 | 
   1733 |         // Unchecked because the only math done is incrementing
   1734 |         // the owner's nonce which cannot realistically overflow.
```

---

### 168. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1310 行
- **函数**: `wrapETH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1307 |         if (amount > 0) {
   1308 |             WETH9.deposit{value: amount}();
   1309 |             if (recipient != address(this)) {
>> 1310 |                 WETH9.transfer(recipient, amount);
   1311 |             }
   1312 |         }
   1313 |     }
```

---

### 169. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1999 行
- **函数**: `invalidateNonces()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1996 |     uint128 internal constant OPEN_DELTA = 0;
   1997 |     /// @notice used to signal that an action should use the contract's entire balance of a currency
   1998 |     /// This value is equivalent to 1<<255, i.e. a singular 1 in the most significant bit.
>> 1999 |     uint256 internal constant CONTRACT_BALANCE = 0x8000000000000000000000000000000000000000000000000000000000000000;
   2000 | 
   2001 |     /// @notice used to signal that the recipient of an action should be the msgSender
   2002 |     address internal constant MSG_SENDER = address(1);
```

---

### 170. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3332 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3329 |                 let fmp := mload(0x40)
   3330 | 
   3331 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3332 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   3333 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3334 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3335 | 
```

---

### 171. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3333 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3330 | 
   3331 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
   3332 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>> 3333 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3334 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3335 | 
   3336 |                 success :=
```

---

### 172. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3709 行
- **函数**: `safeTransferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3706 |             let freeMemoryPointer := mload(0x40)
   3707 | 
   3708 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3709 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   3710 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
   3711 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3712 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
```

---

### 173. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3710 行
- **函数**: `safeTransferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3707 | 
   3708 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   3709 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
>> 3710 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
   3711 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3712 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3713 | 
```

---

### 174. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3711 行
- **函数**: `safeTransferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3708 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   3709 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   3710 |             mstore(add(freeMemoryPointer, 4), and(from, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "from" argument.
>> 3711 |             mstore(add(freeMemoryPointer, 36), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3712 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3713 | 
   3714 |             success := and(
```

---

### 175. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3742 行
- **函数**: `safeTransfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3739 |             let freeMemoryPointer := mload(0x40)
   3740 | 
   3741 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3742 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   3743 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3744 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3745 | 
```

---

### 176. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3743 行
- **函数**: `safeTransfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3740 | 
   3741 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   3742 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>> 3743 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3744 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3745 | 
   3746 |             success := and(
```

---

### 177. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3774 行
- **函数**: `safeApprove()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3771 |             let freeMemoryPointer := mload(0x40)
   3772 | 
   3773 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3774 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
   3775 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3776 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3777 | 
```

---

### 178. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3775 行
- **函数**: `safeApprove()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3772 | 
   3773 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
   3774 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
>> 3775 |             mstore(add(freeMemoryPointer, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   3776 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   3777 | 
   3778 |             success := and(
```

---

### 179. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4068 行
- **函数**: `pancakeV3SwapCallback()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4065 | /// @notice A library used to store the maximum desired amount of input tokens for exact output swaps; used for checking slippage
   4066 | library MaxInputAmount {
   4067 |     // The slot holding the the maximum desired amount of input tokens, transiently. bytes32(uint256(keccak256("MaxAmountIn")) - 1)
>> 4068 |     bytes32 constant MAX_AMOUNT_IN_SLOT = 0xaf28d9864a81dfdf71cab65f4e5d79a0cf9b083905fb8971425e6cb581b3f692;
   4069 | 
   4070 |     function set(uint256 maxAmountIn) internal {
   4071 |         assembly ("memory-safe") {
```

---

### 180. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 4710 行
- **函数**: `permit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4707 | /// TODO: This library can be deleted when we have the transient keyword support in solidity.
   4708 | library Locker {
   4709 |     // The slot holding the locker state, transiently. bytes32(uint256(keccak256("Locker")) - 1)
>> 4710 |     bytes32 constant LOCKER_SLOT = 0x0e87e1788ebd9ed6a7e63c70a374cd3283e41cad601d21fbe27863899ed4a708;
   4711 | 
   4712 |     function set(address locker) internal {
   4713 |         // The locker is always msg.sender or address(0) so does not need to be cleaned
```

---

### 181. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 5529 行
- **函数**: `calculatePositionKey()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5526 |                 0x0,
   5527 |                 or(
   5528 |                     shl(160, and(0xFFFFFF, tickUpper)),
>> 5529 |                     or(shl(184, tickLower), and(owner, 0xffffffffffffffffffffffffffffffffffffffff))
   5530 |                 )
   5531 |             ) // tickLower at [0x06, 0x09), tickUpper at [0x09,0x0c), owner at [0x0c, 0x20)
   5532 |             mstore(0x20, salt) // salt at [0x20, 0x40)
```

---

### 182. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7469 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   7466 | 
   7467 |             // Encode wrapped error selector, address, function selector, offset, additional context, size, revert reason
   7468 |             mstore(fmp, wrappedErrorSelector)
>> 7469 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   7470 |             mstore(
   7471 |                 add(fmp, 0x24),
   7472 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
```

---

### 183. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7472 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   7469 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   7470 |             mstore(
   7471 |                 add(fmp, 0x24),
>> 7472 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   7473 |             )
   7474 |             // offset revert reason
   7475 |             mstore(add(fmp, 0x44), 0x80)
```

---

### 184. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 7487 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   7484 |             // additional context
   7485 |             mstore(
   7486 |                 add(fmp, add(0xc4, encodedDataSize)),
>> 7487 |                 and(additionalContext, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   7488 |             )
   7489 |             revert(fmp, add(0xe4, encodedDataSize))
   7490 |         }
```

---

### 185. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8570 行
- **函数**: `getTickAtSqrtRatio()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8567 | 
   8568 | /// @notice Library for getting and setting values in the Slot0 type
   8569 | library CLSlot0Library {
>> 8570 |     uint160 internal constant MASK_160_BITS = 0x00FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF;
   8571 |     uint24 internal constant MASK_24_BITS = 0xFFFFFF;
   8572 | 
   8573 |     uint8 internal constant TICK_OFFSET = 160;
```

---

### 186. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8832 行
- **函数**: `getNextSqrtPriceFromAmount0RoundingUp()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8829 |                 assembly ("memory-safe") {
   8830 |                     if iszero(
   8831 |                         and(
>> 8832 |                             eq(div(product, amount), and(sqrtPX96, 0xffffffffffffffffffffffffffffffffffffffff)),
   8833 |                             gt(numerator1, product)
   8834 |                         )
   8835 |                     ) {
```

---

### 187. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8880 行
- **函数**: `getNextSqrtPriceFromAmount1RoundingDown()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8877 | 
   8878 |             // equivalent: if (sqrtPX96 <= quotient) revert NotEnoughLiquidity();
   8879 |             assembly ("memory-safe") {
>> 8880 |                 if iszero(gt(and(sqrtPX96, 0xffffffffffffffffffffffffffffffffffffffff), quotient)) {
   8881 |                     mstore(0, 0x4323a555) // selector for NotEnoughLiquidity()
   8882 |                     revert(0x1c, 0x04)
   8883 |                 }
```

---

### 188. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8907 行
- **函数**: `getNextSqrtPriceFromInput()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8904 |         // equivalent: if (sqrtPX96 == 0 || liquidity == 0) revert InvalidPriceOrLiquidity();
   8905 |         assembly ("memory-safe") {
   8906 |             if or(
>> 8907 |                 iszero(and(sqrtPX96, 0xffffffffffffffffffffffffffffffffffffffff)),
   8908 |                 iszero(and(liquidity, 0xffffffffffffffffffffffffffffffff))
   8909 |             ) {
   8910 |                 mstore(0, 0x4f2461b8) // selector for InvalidPriceOrLiquidity()
```

---

### 189. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8936 行
- **函数**: `getNextSqrtPriceFromOutput()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8933 |         // equivalent: if (sqrtPX96 == 0 || liquidity == 0) revert InvalidPriceOrLiquidity();
   8934 |         assembly ("memory-safe") {
   8935 |             if or(
>> 8936 |                 iszero(and(sqrtPX96, 0xffffffffffffffffffffffffffffffffffffffff)),
   8937 |                 iszero(and(liquidity, 0xffffffffffffffffffffffffffffffff))
   8938 |             ) {
   8939 |                 mstore(0, 0x4f2461b8) // selector for InvalidPriceOrLiquidity()
```

---

### 190. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8968 行
- **函数**: `getAmount0Delta()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8965 | 
   8966 |             // equivalent: if (sqrtRatioAX96 == 0) revert InvalidPrice();
   8967 |             assembly ("memory-safe") {
>> 8968 |                 if iszero(and(sqrtRatioAX96, 0xffffffffffffffffffffffffffffffffffffffff)) {
   8969 |                     mstore(0, 0x00bfc921) // selector for InvalidPrice()
   8970 |                     revert(0x1c, 0x04)
   8971 |                 }
```

---

### 191. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 8987 行
- **函数**: `absDiff()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   8984 |     function absDiff(uint160 a, uint160 b) internal pure returns (uint256 res) {
   8985 |         assembly ("memory-safe") {
   8986 |             let diff :=
>> 8987 |                 sub(and(a, 0xffffffffffffffffffffffffffffffffffffffff), and(b, 0xffffffffffffffffffffffffffffffffffffffff))
   8988 |             // mask = 0 if a >= b else -1 (all 1s)
   8989 |             let mask := sar(255, diff)
   8990 |             // if a >= b, res = a - b = 0 ^ (a - b)
```

---

### 192. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 9202 行
- **函数**: `getSqrtPriceTarget()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   9199 |             // sqrtPriceTargetX96 = max(sqrtPriceNextX96, sqrtPriceLimitX96)
   9200 |             // when zeroForOne == false, nextOrLimit reduces to sqrtPriceNextX96 < sqrtPriceLimitX96
   9201 |             // sqrtPriceTargetX96 = min(sqrtPriceNextX96, sqrtPriceLimitX96)
>> 9202 |             sqrtPriceNextX96 := and(sqrtPriceNextX96, 0xffffffffffffffffffffffffffffffffffffffff)
   9203 |             sqrtPriceLimitX96 := and(sqrtPriceLimitX96, 0xffffffffffffffffffffffffffffffffffffffff)
   9204 |             let nextOrLimit := xor(lt(sqrtPriceNextX96, sqrtPriceLimitX96), and(zeroForOne, 0x1))
   9205 |             let symDiff := xor(sqrtPriceNextX96, sqrtPriceLimitX96)
```

---

### 193. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 9203 行
- **函数**: `getSqrtPriceTarget()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   9200 |             // when zeroForOne == false, nextOrLimit reduces to sqrtPriceNextX96 < sqrtPriceLimitX96
   9201 |             // sqrtPriceTargetX96 = min(sqrtPriceNextX96, sqrtPriceLimitX96)
   9202 |             sqrtPriceNextX96 := and(sqrtPriceNextX96, 0xffffffffffffffffffffffffffffffffffffffff)
>> 9203 |             sqrtPriceLimitX96 := and(sqrtPriceLimitX96, 0xffffffffffffffffffffffffffffffffffffffff)
   9204 |             let nextOrLimit := xor(lt(sqrtPriceNextX96, sqrtPriceLimitX96), and(zeroForOne, 0x1))
   9205 |             let symDiff := xor(sqrtPriceNextX96, sqrtPriceLimitX96)
   9206 |             sqrtPriceTargetX96 := xor(sqrtPriceLimitX96, mul(symDiff, nextOrLimit))
```

---

### 194. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 10884 行
- **函数**: `calculatePositionKey()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   10881 |         // dev same as `positionKey = keccak256(abi.encodePacked(binId, owner, salt))`
   10882 |         // make salt, binId, owner to be tightly packed in memory
   10883 |         assembly ("memory-safe") {
>> 10884 |             mstore(0x0, or(shl(160, binId), and(owner, 0xffffffffffffffffffffffffffffffffffffffff))) // binId at [0x09,0x0c), owner at [0x0c, 0x20)
   10885 |             mstore(0x20, salt) // salt at [0x20, 0x40)
   10886 |             key := keccak256(0x09, 0x37)
   10887 |         }
```

---

### 195. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 11560 行
- **函数**: `mostSignificantBit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   11557 |             r := or(r, shl(3, lt(0xff, shr(r, x))))
   11558 |             // forgefmt: disable-next-item
   11559 |             r := or(r, byte(and(0x1f, shr(shr(r, x), 0x8421084210842108cc6318c6db6d54be)),
>> 11560 |                 0x0706060506020504060203020504030106050205030304010505030400000000))
   11561 |         }
   11562 |     }
   11563 | 
```

---

### 196. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 11578 行
- **函数**: `leastSignificantBit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   11575 |             // Credit to adhusson: https://blog.adhusson.com/cheap-find-first-set-evm/
   11576 |             // forgefmt: disable-next-item
   11577 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
>> 11578 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
   11579 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   11580 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   11581 |             // forgefmt: disable-next-item
```

---

### 197. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 11579 行
- **函数**: `leastSignificantBit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   11576 |             // forgefmt: disable-next-item
   11577 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
   11578 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
>> 11579 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   11580 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   11581 |             // forgefmt: disable-next-item
   11582 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
```

---

### 198. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 11583 行
- **函数**: `leastSignificantBit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   11580 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   11581 |             // forgefmt: disable-next-item
   11582 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
>> 11583 |                 0x001f0d1e100c1d070f090b19131c1706010e11080a1a141802121b1503160405))
   11584 |         }
   11585 |     }
   11586 | }
```

---

### 199. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 167 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    164 |                         uint256 amountIn;
    165 |                         uint256 amountOutMin;
    166 |                         bool payerIsUser;
>>  167 |                         assembly {
    168 |                             recipient := calldataload(inputs.offset)
    169 |                             amountIn := calldataload(add(inputs.offset, 0x20))
    170 |                             amountOutMin := calldataload(add(inputs.offset, 0x40))
```

---

### 200. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 184 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    181 |                         uint256 amountOut;
    182 |                         uint256 amountInMax;
    183 |                         bool payerIsUser;
>>  184 |                         assembly {
    185 |                             recipient := calldataload(inputs.offset)
    186 |                             amountOut := calldataload(add(inputs.offset, 0x20))
    187 |                             amountInMax := calldataload(add(inputs.offset, 0x40))
```

---

### 201. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 200 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    197 |                         address token;
    198 |                         address recipient;
    199 |                         uint160 amount;
>>  200 |                         assembly {
    201 |                             token := calldataload(inputs.offset)
    202 |                             recipient := calldataload(add(inputs.offset, 0x20))
    203 |                             amount := calldataload(add(inputs.offset, 0x40))
```

---

### 202. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 209 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    206 |                         return (success, output);
    207 |                     } else if (command == Commands.PERMIT2_PERMIT_BATCH) {
    208 |                         IAllowanceTransfer.PermitBatch calldata permitBatch;
>>  209 |                         assembly {
    210 |                             // this is a variable length struct, so calldataload(inputs.offset) contains the
    211 |                             // offset from inputs.offset at which the struct begins
    212 |                             permitBatch := add(inputs.offset, calldataload(inputs.offset))
```

---

### 203. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 229 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    226 |                         address token;
    227 |                         address recipient;
    228 |                         uint160 amountMin;
>>  229 |                         assembly {
    230 |                             token := calldataload(inputs.offset)
    231 |                             recipient := calldataload(add(inputs.offset, 0x20))
    232 |                             amountMin := calldataload(add(inputs.offset, 0x40))
```

---

### 204. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 241 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    238 |                         address token;
    239 |                         address recipient;
    240 |                         uint256 value;
>>  241 |                         assembly {
    242 |                             token := calldataload(inputs.offset)
    243 |                             recipient := calldataload(add(inputs.offset, 0x20))
    244 |                             value := calldataload(add(inputs.offset, 0x40))
```

---

### 205. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 253 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    250 |                         address token;
    251 |                         address recipient;
    252 |                         uint256 bips;
>>  253 |                         assembly {
    254 |                             token := calldataload(inputs.offset)
    255 |                             recipient := calldataload(add(inputs.offset, 0x20))
    256 |                             bips := calldataload(add(inputs.offset, 0x40))
```

---

### 206. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 272 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    269 |                         uint256 amountIn;
    270 |                         uint256 amountOutMin;
    271 |                         bool payerIsUser;
>>  272 |                         assembly {
    273 |                             recipient := calldataload(inputs.offset)
    274 |                             amountIn := calldataload(add(inputs.offset, 0x20))
    275 |                             amountOutMin := calldataload(add(inputs.offset, 0x40))
```

---

### 207. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 289 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    286 |                         uint256 amountOut;
    287 |                         uint256 amountInMax;
    288 |                         bool payerIsUser;
>>  289 |                         assembly {
    290 |                             recipient := calldataload(inputs.offset)
    291 |                             amountOut := calldataload(add(inputs.offset, 0x20))
    292 |                             amountInMax := calldataload(add(inputs.offset, 0x40))
```

---

### 208. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 303 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    300 |                     } else if (command == Commands.PERMIT2_PERMIT) {
    301 |                         // equivalent: abi.decode(inputs, (IAllowanceTransfer.PermitSingle, bytes))
    302 |                         IAllowanceTransfer.PermitSingle calldata permitSingle;
>>  303 |                         assembly {
    304 |                             permitSingle := inputs.offset
    305 |                         }
    306 |                         bytes calldata data = inputs.toBytes(6); // PermitSingle takes first 6 slots (0..5)
```

---

### 209. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 320 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    317 |                         // equivalent: abi.decode(inputs, (address, uint256))
    318 |                         address recipient;
    319 |                         uint256 amount;
>>  320 |                         assembly {
    321 |                             recipient := calldataload(inputs.offset)
    322 |                             amount := calldataload(add(inputs.offset, 0x20))
    323 |                         }
```

---

### 210. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 330 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    327 |                         // equivalent: abi.decode(inputs, (address, uint256))
    328 |                         address recipient;
    329 |                         uint256 amountMin;
>>  330 |                         assembly {
    331 |                             recipient := calldataload(inputs.offset)
    332 |                             amountMin := calldataload(add(inputs.offset, 0x20))
    333 |                         }
```

---

### 211. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 339 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    336 |                     } else if (command == Commands.PERMIT2_TRANSFER_FROM_BATCH) {
    337 |                         IAllowanceTransfer.AllowanceTransferDetails[] calldata batchDetails;
    338 |                         (uint256 length, uint256 offset) = inputs.toLengthOffset(0);
>>  339 |                         assembly {
    340 |                             batchDetails.length := length
    341 |                             batchDetails.offset := offset
    342 |                         }
```

---

### 212. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 350 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    347 |                         address owner;
    348 |                         address token;
    349 |                         uint256 minBalance;
>>  350 |                         assembly {
    351 |                             owner := calldataload(inputs.offset)
    352 |                             token := calldataload(add(inputs.offset, 0x20))
    353 |                             minBalance := calldataload(add(inputs.offset, 0x40))
```

---

### 213. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 384 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    381 |                     // (Currency currency0, Currency currency1, IHooks hooks, IPoolManager poolManager, uint24 fee, bytes32 parameters)
    382 |                     PoolKey calldata poolKey;
    383 |                     uint160 sqrtPriceX96;
>>  384 |                     assembly {
    385 |                         poolKey := inputs.offset
    386 |                         sqrtPriceX96 := calldataload(add(inputs.offset, 0xc0)) // poolKey has 6 variable, so it takes 192 space = 0xc0
    387 |                     }
```

---

### 214. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 395 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    392 |                     // (Currency currency0, Currency currency1, IHooks hooks, IPoolManager poolManager, uint24 fee, bytes32 parameters)
    393 |                     PoolKey calldata poolKey;
    394 |                     uint24 activeId;
>>  395 |                     assembly {
    396 |                         poolKey := inputs.offset
    397 |                         activeId := calldataload(add(inputs.offset, 0xc0)) // poolKey has 6 variable, so it takes 192 space = 0xc0
    398 |                     }
```

---

### 215. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 426 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    423 |                 uint256 amountIn;
    424 |                 uint256 amountOutMin;
    425 |                 bool payerIsUser;
>>  426 |                 assembly {
    427 |                     recipient := calldataload(inputs.offset)
    428 |                     amountIn := calldataload(add(inputs.offset, 0x20))
    429 |                     amountOutMin := calldataload(add(inputs.offset, 0x40))
```

---

### 216. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 444 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    441 |                 uint256 amountOut;
    442 |                 uint256 amountInMax;
    443 |                 bool payerIsUser;
>>  444 |                 assembly {
    445 |                     recipient := calldataload(inputs.offset)
    446 |                     amountOut := calldataload(add(inputs.offset, 0x20))
    447 |                     amountInMax := calldataload(add(inputs.offset, 0x40))
```

---

### 217. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1374 行
- **函数**: `_checkV3PermitCall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1371 |     /// @dev check that a call is to the ERC721 permit function
   1372 |     function _checkV3PermitCall(bytes calldata inputs) internal pure {
   1373 |         bytes4 selector;
>> 1374 |         assembly {
   1375 |             selector := calldataload(inputs.offset)
   1376 |         }
   1377 | 
```

---

### 218. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1386 行
- **函数**: `_checkV3PositionManagerCall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1383 |     /// @dev check that the v3 position manager call is a safe call
   1384 |     function _checkV3PositionManagerCall(bytes calldata inputs, address caller) internal view {
   1385 |         bytes4 selector;
>> 1386 |         assembly {
   1387 |             selector := calldataload(inputs.offset)
   1388 |         }
   1389 | 
```

---

### 219. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1395 行
- **函数**: `_checkV3PositionManagerCall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1392 |         }
   1393 | 
   1394 |         uint256 tokenId;
>> 1395 |         assembly {
   1396 |             // tokenId is always the first parameter in the valid actions
   1397 |             tokenId := calldataload(add(inputs.offset, 0x04))
   1398 |         }
```

---

### 220. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1414 行
- **函数**: `_checkInfiClPositionManagerCall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1411 |     /// their position, an attacker could take their fees, or drain their entire position
   1412 |     function _checkInfiClPositionManagerCall(bytes calldata inputs) internal view {
   1413 |         bytes4 selector;
>> 1414 |         assembly {
   1415 |             selector := calldataload(inputs.offset)
   1416 |         }
   1417 |         if (selector != INFI_CL_POSITION_MANAGER.modifyLiquidities.selector) {
```

---

### 221. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1448 行
- **函数**: `_checkInfiBinPositionManagerCall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1445 |     /// their position, an attacker could drain their entire position
   1446 |     function _checkInfiBinPositionManagerCall(bytes calldata inputs) internal view {
   1447 |         bytes4 selector;
>> 1448 |         assembly {
   1449 |             selector := calldataload(inputs.offset)
   1450 |         }
   1451 |         if (selector != INFI_BIN_POSITION_MANAGER.modifyLiquidities.selector) {
```

---

### 222. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1495 行
- **函数**: `toAddress()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1492 |     /// @return _address The address starting at byte 0
   1493 |     function toAddress(bytes calldata _bytes) internal pure returns (address _address) {
   1494 |         if (_bytes.length < Constants.ADDR_SIZE) revert SliceOutOfBounds();
>> 1495 |         assembly {
   1496 |             _address := shr(96, calldataload(_bytes.offset))
   1497 |         }
   1498 |     }
```

---

### 223. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1513 行
- **函数**: `toLengthOffset()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1510 |         returns (uint256 length, uint256 offset)
   1511 |     {
   1512 |         uint256 relativeOffset;
>> 1513 |         assembly {
   1514 |             // The offset of the `_arg`-th element is `32 * arg`, which stores the offset of the length pointer.
   1515 |             // shl(5, x) is equivalent to mul(32, x)
   1516 |             let lengthPtr := add(_bytes.offset, calldataload(add(_bytes.offset, shl(5, _arg))))
```

---

### 224. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1532 行
- **函数**: `toPool()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1529 |     /// @return token1 The address at byte 23
   1530 |     function toPool(bytes calldata _bytes) internal pure returns (address token0, uint24 fee, address token1) {
   1531 |         if (_bytes.length < Constants.V3_POP_OFFSET) revert SliceOutOfBounds();
>> 1532 |         assembly {
   1533 |             let firstWord := calldataload(_bytes.offset)
   1534 |             token0 := shr(96, firstWord)
   1535 |             fee := and(shr(72, firstWord), 0xffffff)
```

---

### 225. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1545 行
- **函数**: `toAddressArray()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1542 |     /// @param _arg The index of the argument to extract
   1543 |     function toAddressArray(bytes calldata _bytes, uint256 _arg) internal pure returns (address[] calldata res) {
   1544 |         (uint256 length, uint256 offset) = toLengthOffset(_bytes, _arg);
>> 1545 |         assembly {
   1546 |             res.length := length
   1547 |             res.offset := offset
   1548 |         }
```

---

### 226. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 1556 行
- **函数**: `toUintArray()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1553 |     /// @param _arg The index of the argument to extract
   1554 |     function toUintArray(bytes calldata _bytes, uint256 _arg) internal pure returns (uint256[] calldata res) {
   1555 |         (uint256 length, uint256 offset) = toLengthOffset(_bytes, _arg);
>> 1556 |         assembly {
   1557 |             res.length := length
   1558 |             res.offset := offset
   1559 |         }
```

---

### 227. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3683 行
- **函数**: `safeTransferETH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3680 |         bool success;
   3681 | 
   3682 |         /// @solidity memory-safe-assembly
>> 3683 |         assembly {
   3684 |             // Transfer the ETH and store if it succeeded or not.
   3685 |             success := call(gas(), to, amount, 0, 0, 0, 0)
   3686 |         }
```

---

### 228. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3704 行
- **函数**: `safeTransferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3701 |         bool success;
   3702 | 
   3703 |         /// @solidity memory-safe-assembly
>> 3704 |         assembly {
   3705 |             // Get a pointer to some free memory.
   3706 |             let freeMemoryPointer := mload(0x40)
   3707 | 
```

---

### 229. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3737 行
- **函数**: `safeTransfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3734 |         bool success;
   3735 | 
   3736 |         /// @solidity memory-safe-assembly
>> 3737 |         assembly {
   3738 |             // Get a pointer to some free memory.
   3739 |             let freeMemoryPointer := mload(0x40)
   3740 | 
```

---

### 230. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xd9C500DfF816a1Da21A48A732d3498Bf09dc9AEB` 第 3769 行
- **函数**: `safeApprove()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3766 |         bool success;
   3767 | 
   3768 |         /// @solidity memory-safe-assembly
>> 3769 |         assembly {
   3770 |             // Get a pointer to some free memory.
   3771 |             let freeMemoryPointer := mload(0x40)
   3772 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*