# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:04:12
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` |
| contract_name | `YieldBearingConditionalTokens` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/YieldBearing/YieldBearingConditionalTokens.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/IERC20.sol', 'contracts/ConditionalTokens/CTHelpers.sol', 'contracts/ConditionalTokens/WhitelistedERC1155.sol', 'contracts/YieldBearing/Venus.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/ERC1155.sol', 'node_modules/@openzeppelin/contracts/access/AccessControl.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', 'contracts/YieldBearing/interfaces/IComptroller.sol', 'contracts/YieldBearing/interfaces/IVToken.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/IERC1155.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/IERC1155Receiver.sol', 'node_modules/@openzeppelin/contracts/token/ERC1155/extensions/IERC1155MetadataURI.sol', 'node_modules/@openzeppelin/contracts/utils/Context.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/ERC165.sol', 'node_modules/@openzeppelin/contracts/utils/Arrays.sol', 'node_modules/@openzeppelin/contracts/interfaces/draft-IERC6093.sol', 'node_modules/@openzeppelin/contracts/access/IAccessControl.sol', 'node_modules/@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol', 'node_modules/@openzeppelin/contracts/utils/Address.sol', 'node_modules/@openzeppelin/contracts/utils/introspection/IERC165.sol', 'node_modules/@openzeppelin/contracts/utils/StorageSlot.sol', 'node_modules/@openzeppelin/contracts/utils/math/Math.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 51 |
| 🟢 LOW | 25 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3211 行
- **函数**: `functionDelegateCall()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   3208 |      * but performing a delegate call.
   3209 |      */
   3210 |     function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
>> 3211 |         (bool success, bytes memory returndata) = target.delegatecall(data);
   3212 |         return verifyCallResultFromTarget(target, success, returndata);
   3213 |     }
   3214 | 
```

---

### 2. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2296 行
- **函数**: `_callOptionalReturnBool()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   2293 |         // we're implementing it ourselves. We cannot use {Address-functionCall} here since this should return false
   2294 |         // and not revert is the subcall reverts.
   2295 | 
>> 2296 |         (bool success, bytes memory returndata) = address(token).call(data);
   2297 |         return success && (returndata.length == 0 || abi.decode(returndata, (bool))) && address(token).code.length > 0;
   2298 |     }
   2299 | }
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3152 行
- **函数**: `sendValue()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   3149 |             revert AddressInsufficientBalance(address(this));
   3150 |         }
   3151 | 
>> 3152 |         (bool success, ) = recipient.call{value: amount}("");
   3153 |         if (!success) {
   3154 |             revert FailedInnerCall();
   3155 |         }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3193 行
- **函数**: `functionCallWithValue()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   3190 |         if (address(this).balance < value) {
   3191 |             revert AddressInsufficientBalance(address(this));
   3192 |         }
>> 3193 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
   3194 |         return verifyCallResultFromTarget(target, success, returndata);
   3195 |     }
   3196 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 164 行
- **函数**: `prepareCondition()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    161 |     ///
    162 |     /// @param questionId An identifier for the question to be answered by the oracle.
    163 |     /// @param outcomeSlotCount The number of outcome slots which should be used for this condition. Must not exceed 256.
>>  164 |     function prepareCondition(bytes32 questionId, uint outcomeSlotCount) external {
    165 |         // Limit of 256 because we use a partition array that is a number of 256 bits.
    166 |         require(outcomeSlotCount <= 256, "too many outcome slots");
    167 |         require(outcomeSlotCount > 1, "there should be more than one outcome slot");
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 177 行
- **函数**: `reportPayouts()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    174 |     /// @dev Called by the oracle for reporting results of conditions. Will set the payout vector for the condition with the ID ``keccak256(abi.encodePacked(oracle, questionId, outcomeSlotCount))``, where oracle is the message sender, questionId is one of the parameters of this function, and outcomeSlotCount is the length of the payouts parameter, which contains the payoutNumerators for each outcome slot of the condition.
    175 |     /// @param questionId The question ID the oracle is answering for
    176 |     /// @param payouts The oracle's answer
>>  177 |     function reportPayouts(bytes32 questionId, uint[] calldata payouts) external {
    178 |         uint outcomeSlotCount = payouts.length;
    179 |         require(outcomeSlotCount > 1, "there should be more than one outcome slot");
    180 |         // IMPORTANT, the oracle is enforced to be the sender because it's part of the hash.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 402 行
- **函数**: `getOutcomeSlotCount()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    399 |     /// @dev Gets the outcome slot count of a condition.
    400 |     /// @param conditionId ID of the condition.
    401 |     /// @return Number of outcome slots associated with a condition, or zero if condition has not been prepared yet.
>>  402 |     function getOutcomeSlotCount(bytes32 conditionId) external view returns (uint) {
    403 |         return payoutNumerators[conditionId].length;
    404 |     }
    405 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 410 行
- **函数**: `getConditionId()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    407 |     /// @param oracle The account assigned to report the result for the prepared condition.
    408 |     /// @param questionId An identifier for the question to be answered by the oracle.
    409 |     /// @param outcomeSlotCount The number of outcome slots which should be used for this condition. Must not exceed 256.
>>  410 |     function getConditionId(address oracle, bytes32 questionId, uint outcomeSlotCount) external pure returns (bytes32) {
    411 |         return CTHelpers.getConditionId(oracle, questionId, outcomeSlotCount);
    412 |     }
    413 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 429 行
- **函数**: `getPositionId()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    426 |     /// @dev Constructs a position ID from a collateral token and an outcome collection. These IDs are used as the ERC-1155 ID for this contract.
    427 |     /// @param collateralToken Collateral token which backs the position.
    428 |     /// @param collectionId ID of the outcome collection associated with this position.
>>  429 |     function getPositionId(IERC20 collateralToken, bytes32 collectionId) external pure returns (uint) {
    430 |         return CTHelpers.getPositionId(collateralToken, collectionId);
    431 |     }
    432 | }
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 463 行
- **函数**: `totalSupply()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    460 |     /**
    461 |      * @dev Returns the value of tokens in existence.
    462 |      */
>>  463 |     function totalSupply() external view returns (uint256);
    464 | 
    465 |     /**
    466 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 468 行
- **函数**: `balanceOf()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    465 |     /**
    466 |      * @dev Returns the value of tokens owned by `account`.
    467 |      */
>>  468 |     function balanceOf(address account) external view returns (uint256);
    469 | 
    470 |     /**
    471 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 477 行
- **函数**: `transfer()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    474 |      *
    475 |      * Emits a {Transfer} event.
    476 |      */
>>  477 |     function transfer(address to, uint256 value) external returns (bool);
    478 | 
    479 |     /**
    480 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 486 行
- **函数**: `allowance()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    483 |      *
    484 |      * This value changes when {approve} or {transferFrom} are called.
    485 |      */
>>  486 |     function allowance(address owner, address spender) external view returns (uint256);
    487 | 
    488 |     /**
    489 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 503 行
- **函数**: `approve()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    500 |      *
    501 |      * Emits an {Approval} event.
    502 |      */
>>  503 |     function approve(address spender, uint256 value) external returns (bool);
    504 | 
    505 |     /**
    506 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 514 行
- **函数**: `transferFrom()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    511 |      *
    512 |      * Emits a {Transfer} event.
    513 |      */
>>  514 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    515 | }
    516 | 
    517 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1063 行
- **函数**: `supportsInterface()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1060 |                             OVERRIDES
   1061 |     //////////////////////////////////////////////////////////////////*/
   1062 | 
>> 1063 |     function supportsInterface(bytes4 interfaceId) public view virtual override(ERC1155, AccessControl) returns (bool) {
   1064 |         return
   1065 |             interfaceId == type(ERC1155).interfaceId ||
   1066 |             interfaceId == type(AccessControl).interfaceId ||
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1191 行
- **函数**: `splitPrincipalAndYield()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1188 |      * @return principal The principal amount
   1189 |      * @return yield The yield amount
   1190 |      */
>> 1191 |     function splitPrincipalAndYield(address underlying) public returns (uint256 principal, uint256 yield) {
   1192 |         address vToken = _getVToken(underlying);
   1193 |         uint256 exchangeRateCurrent = IVToken(vToken).exchangeRateCurrent();
   1194 |         (, principal) = divScalarByExpTruncate(depositedAmount[underlying], Exp({mantissa: exchangeRateCurrent}));
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1536 行
- **函数**: `supportsInterface()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1533 |     /**
   1534 |      * @dev See {IERC165-supportsInterface}.
   1535 |      */
>> 1536 |     function supportsInterface(bytes4 interfaceId) public view virtual override(ERC165, IERC165) returns (bool) {
   1537 |         return
   1538 |             interfaceId == type(IERC1155).interfaceId ||
   1539 |             interfaceId == type(IERC1155MetadataURI).interfaceId ||
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1553 行
- **函数**: `uri()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1550 |      * Clients calling this function must replace the `\{id\}` substring with the
   1551 |      * actual token type ID.
   1552 |      */
>> 1553 |     function uri(uint256 /* id */) public view virtual returns (string memory) {
   1554 |         return _uri;
   1555 |     }
   1556 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1560 行
- **函数**: `balanceOf()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1557 |     /**
   1558 |      * @dev See {IERC1155-balanceOf}.
   1559 |      */
>> 1560 |     function balanceOf(address account, uint256 id) public view virtual returns (uint256) {
   1561 |         return _balances[id][account];
   1562 |     }
   1563 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1591 行
- **函数**: `setApprovalForAll()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1588 |     /**
   1589 |      * @dev See {IERC1155-setApprovalForAll}.
   1590 |      */
>> 1591 |     function setApprovalForAll(address operator, bool approved) public virtual {
   1592 |         _setApprovalForAll(_msgSender(), operator, approved);
   1593 |     }
   1594 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1598 行
- **函数**: `isApprovedForAll()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1595 |     /**
   1596 |      * @dev See {IERC1155-isApprovedForAll}.
   1597 |      */
>> 1598 |     function isApprovedForAll(address account, address operator) public view virtual returns (bool) {
   1599 |         return _operatorApprovals[account][operator];
   1600 |     }
   1601 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1605 行
- **函数**: `safeTransferFrom()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1602 |     /**
   1603 |      * @dev See {IERC1155-safeTransferFrom}.
   1604 |      */
>> 1605 |     function safeTransferFrom(address from, address to, uint256 id, uint256 value, bytes memory data) public virtual {
   1606 |         address sender = _msgSender();
   1607 |         if (from != sender && !isApprovedForAll(from, sender)) {
   1608 |             revert ERC1155MissingApprovalForAll(sender, from);
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2039 行
- **函数**: `supportsInterface()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2036 |     /**
   2037 |      * @dev See {IERC165-supportsInterface}.
   2038 |      */
>> 2039 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
   2040 |         return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
   2041 |     }
   2042 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2046 行
- **函数**: `hasRole()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2043 |     /**
   2044 |      * @dev Returns `true` if `account` has been granted `role`.
   2045 |      */
>> 2046 |     function hasRole(bytes32 role, address account) public view virtual returns (bool) {
   2047 |         return _roles[role].hasRole[account];
   2048 |     }
   2049 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2074 行
- **函数**: `getRoleAdmin()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2071 |      *
   2072 |      * To change a role's admin, use {_setRoleAdmin}.
   2073 |      */
>> 2074 |     function getRoleAdmin(bytes32 role) public view virtual returns (bytes32) {
   2075 |         return _roles[role].adminRole;
   2076 |     }
   2077 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2125 行
- **函数**: `renounceRole()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2122 |      *
   2123 |      * May emit a {RoleRevoked} event.
   2124 |      */
>> 2125 |     function renounceRole(bytes32 role, address callerConfirmation) public virtual {
   2126 |         if (callerConfirmation != _msgSender()) {
   2127 |             revert AccessControlBadConfirmation();
   2128 |         }
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2308 行
- **函数**: `treasuryPercent()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2305 | pragma solidity 0.8.24;
   2306 | 
   2307 | interface IComptroller {
>> 2308 |     function treasuryPercent() external view returns (uint256);
   2309 | }
   2310 | 
   2311 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2318 行
- **函数**: `balanceOfUnderlying()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2315 | pragma solidity 0.8.24;
   2316 | 
   2317 | interface IVToken {
>> 2318 |     function balanceOfUnderlying(address _owner) external returns (uint256);
   2319 |     function mint(uint256 _amount) external returns (uint256);
   2320 |     function redeem(uint256 _amount) external returns (uint256);
   2321 |     function redeemUnderlying(uint256 _amount) external returns (uint256);
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2319 行
- **函数**: `mint()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2316 | 
   2317 | interface IVToken {
   2318 |     function balanceOfUnderlying(address _owner) external returns (uint256);
>> 2319 |     function mint(uint256 _amount) external returns (uint256);
   2320 |     function redeem(uint256 _amount) external returns (uint256);
   2321 |     function redeemUnderlying(uint256 _amount) external returns (uint256);
   2322 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2320 行
- **函数**: `redeem()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2317 | interface IVToken {
   2318 |     function balanceOfUnderlying(address _owner) external returns (uint256);
   2319 |     function mint(uint256 _amount) external returns (uint256);
>> 2320 |     function redeem(uint256 _amount) external returns (uint256);
   2321 |     function redeemUnderlying(uint256 _amount) external returns (uint256);
   2322 | 
   2323 |     function balanceOf(address _owner) external view returns (uint256);
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2321 行
- **函数**: `redeemUnderlying()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2318 |     function balanceOfUnderlying(address _owner) external returns (uint256);
   2319 |     function mint(uint256 _amount) external returns (uint256);
   2320 |     function redeem(uint256 _amount) external returns (uint256);
>> 2321 |     function redeemUnderlying(uint256 _amount) external returns (uint256);
   2322 | 
   2323 |     function balanceOf(address _owner) external view returns (uint256);
   2324 |     function exchangeRateCurrent() external returns (uint256);
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2323 行
- **函数**: `balanceOf()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2320 |     function redeem(uint256 _amount) external returns (uint256);
   2321 |     function redeemUnderlying(uint256 _amount) external returns (uint256);
   2322 | 
>> 2323 |     function balanceOf(address _owner) external view returns (uint256);
   2324 |     function exchangeRateCurrent() external returns (uint256);
   2325 |     function isVToken() external view returns (bool);
   2326 |     function underlying() external view returns (address);
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2324 行
- **函数**: `exchangeRateCurrent()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2321 |     function redeemUnderlying(uint256 _amount) external returns (uint256);
   2322 | 
   2323 |     function balanceOf(address _owner) external view returns (uint256);
>> 2324 |     function exchangeRateCurrent() external returns (uint256);
   2325 |     function isVToken() external view returns (bool);
   2326 |     function underlying() external view returns (address);
   2327 | 
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2325 行
- **函数**: `isVToken()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2322 | 
   2323 |     function balanceOf(address _owner) external view returns (uint256);
   2324 |     function exchangeRateCurrent() external returns (uint256);
>> 2325 |     function isVToken() external view returns (bool);
   2326 |     function underlying() external view returns (address);
   2327 | 
   2328 |     function comptroller() external view returns (address);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2326 行
- **函数**: `underlying()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2323 |     function balanceOf(address _owner) external view returns (uint256);
   2324 |     function exchangeRateCurrent() external returns (uint256);
   2325 |     function isVToken() external view returns (bool);
>> 2326 |     function underlying() external view returns (address);
   2327 | 
   2328 |     function comptroller() external view returns (address);
   2329 | }
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2328 行
- **函数**: `comptroller()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2325 |     function isVToken() external view returns (bool);
   2326 |     function underlying() external view returns (address);
   2327 | 
>> 2328 |     function comptroller() external view returns (address);
   2329 | }
   2330 | 
   2331 | 
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2385 行
- **函数**: `balanceOf()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2382 |      *
   2383 |      * - `account` cannot be the zero address.
   2384 |      */
>> 2385 |     function balanceOf(address account, uint256 id) external view returns (uint256);
   2386 | 
   2387 |     /**
   2388 |      * @dev xref:ROOT:erc1155.adoc#batch-operations[Batched] version of {balanceOf}.
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2415 行
- **函数**: `isApprovedForAll()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2412 |      *
   2413 |      * See {setApprovalForAll}.
   2414 |      */
>> 2415 |     function isApprovedForAll(address account, address operator) external view returns (bool);
   2416 | 
   2417 |     /**
   2418 |      * @dev Transfers a `value` amount of tokens of type `id` from `from` to `to`.
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2546 行
- **函数**: `uri()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2543 |      * If the `\{id\}` substring is present in the URI, it must be replaced by
   2544 |      * clients with the actual token type ID.
   2545 |      */
>> 2546 |     function uri(uint256 id) external view returns (string memory);
   2547 | }
   2548 | 
   2549 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2607 行
- **函数**: `supportsInterface()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2604 |     /**
   2605 |      * @dev See {IERC165-supportsInterface}.
   2606 |      */
>> 2607 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   2608 |         return interfaceId == type(IERC165).interfaceId;
   2609 |     }
   2610 | }
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2960 行
- **函数**: `hasRole()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2957 |     /**
   2958 |      * @dev Returns `true` if `account` has been granted `role`.
   2959 |      */
>> 2960 |     function hasRole(bytes32 role, address account) external view returns (bool);
   2961 | 
   2962 |     /**
   2963 |      * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2968 行
- **函数**: `getRoleAdmin()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2965 |      *
   2966 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
   2967 |      */
>> 2968 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
   2969 | 
   2970 |     /**
   2971 |      * @dev Grants `role` to `account`.
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3095 行
- **函数**: `nonces()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3092 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   3093 |      * prevents a signature from being used multiple times.
   3094 |      */
>> 3095 |     function nonces(address owner) external view returns (uint256);
   3096 | 
   3097 |     /**
   3098 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3101 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3098 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
   3099 |      */
   3100 |     // solhint-disable-next-line func-name-mixedcase
>> 3101 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   3102 | }
   3103 | 
   3104 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3293 行
- **函数**: `supportsInterface()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3290 |      *
   3291 |      * This function call must use less than 30 000 gas.
   3292 |      */
>> 3293 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   3294 | }
   3295 | 
   3296 | 
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 14 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      9 | import {WhitelistedERC1155} from "../ConditionalTokens/WhitelistedERC1155.sol";
     10 | import {Venus} from "./Venus.sol";
     11 | 
     12 | /**
     13 |  * @title YieldBearingConditionalTokens
>>   14 |  * @notice A contract for creating and managing conditional tokens that generate yield using Venus
     15 |  * @author predict.fun protocol team
     16 |  */
     17 | contract YieldBearingConditionalTokens is WhitelistedERC1155, Venus {
     18 |     bytes32 public constant SPLIT_POSITION_ROLE = keccak256("SPLIT_POSITION_ROLE");
     19 |     bytes32 public constant MERGE_POSITIONS_ROLE = keccak256("MERGE_POSITIONS_ROLE");
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 968 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    963 | 
    964 | /**
    965 |  * @title WhitelistedERC1155
    966 |  * @notice ERC1155 extension with optional transfer whitelist control
    967 |  */
>>  968 | contract WhitelistedERC1155 is ERC1155, AccessControl {
    969 |     /**
    970 |      * @notice Enable or disable CTF transfers.
    971 |      *         It is enabled by default, but if something breaks, it can be disabled as it
    972 |      *         is the default behavior of the original implementation.
    973 |      */
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1085 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1080 | import {IComptroller} from "./interfaces/IComptroller.sol";
   1081 | import {IVToken} from "./interfaces/IVToken.sol";
   1082 | 
   1083 | /**
   1084 |  * @title Venus
>> 1085 |  * @notice A contract for depositing underlying tokens to Venus for yield
   1086 |  * @dev This contract is meant to be inherited by other contracts that need to deposit underlying tokens to Venus for yield.
   1087 |  *      Some functions need to be access controlled by the child contract.
   1088 |  * @author predict.fun protocol team
   1089 |  */
   1090 | contract Venus {
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1515 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1510 | /**
   1511 |  * @dev Implementation of the basic standard multi-token.
   1512 |  * See https://eips.ethereum.org/EIPS/eip-1155
   1513 |  * Originally based on code by Enjin: https://github.com/enjin/erc-1155
   1514 |  */
>> 1515 | abstract contract ERC1155 is Context, ERC165, IERC1155, IERC1155MetadataURI, IERC1155Errors {
   1516 |     using Arrays for uint256[];
   1517 |     using Arrays for address[];
   1518 | 
   1519 |     mapping(uint256 id => mapping(address account => uint256)) private _balances;
   1520 | 
```

---

### 51. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2017 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2012 |  * WARNING: The `DEFAULT_ADMIN_ROLE` is also its own admin: it has permission to
   2013 |  * grant and revoke this role. Extra precautions should be taken to secure
   2014 |  * accounts that have been granted it. We recommend using {AccessControlDefaultAdminRules}
   2015 |  * to enforce additional security measures for this role.
   2016 |  */
>> 2017 | abstract contract AccessControl is Context, IAccessControl, ERC165 {
   2018 |     struct RoleData {
   2019 |         mapping(address account => bool) hasRole;
   2020 |         bytes32 adminRole;
   2021 |     }
   2022 | 
```

---

### 52. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2194 行
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2189 | import {Address} from "../../../utils/Address.sol";
   2190 | 
   2191 | /**
   2192 |  * @title SafeERC20
   2193 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>> 2194 |  * contract returns false). Tokens that return no value (and instead revert or
   2195 |  * throw on failure) are also supported, non-reverting calls are assumed to be
   2196 |  * successful.
   2197 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
   2198 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
   2199 |  */
```

---

### 53. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 317 行
- **函数**: `mergePositions()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    314 |             if (parentCollectionId == bytes32(0)) {
    315 |                 if (underlyingIsEnabled[address(collateralToken)]) {
    316 |                     uint256 amountRedeemed = _redeemUnderlying(address(collateralToken), amount);
>>  317 |                     require(collateralToken.transfer(msg.sender, amountRedeemed), "could not send collateral tokens");
    318 |                 } else {
    319 |                     require(collateralToken.transfer(msg.sender, amount), "could not send collateral tokens");
    320 |                 }
```

---

### 54. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 319 行
- **函数**: `mergePositions()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    316 |                     uint256 amountRedeemed = _redeemUnderlying(address(collateralToken), amount);
    317 |                     require(collateralToken.transfer(msg.sender, amountRedeemed), "could not send collateral tokens");
    318 |                 } else {
>>  319 |                     require(collateralToken.transfer(msg.sender, amount), "could not send collateral tokens");
    320 |                 }
    321 |             } else {
    322 |                 _mint(msg.sender, CTHelpers.getPositionId(collateralToken, parentCollectionId), amount, "");
```

---

### 55. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 383 行
- **函数**: `redeemPositions()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    380 |                 if (underlyingIsEnabled[address(collateralToken)]) {
    381 |                     uint256 amountRedeemed = _redeemUnderlying(address(collateralToken), totalPayout);
    382 |                     require(
>>  383 |                         collateralToken.transfer(msg.sender, amountRedeemed),
    384 |                         "could not transfer payout to message sender"
    385 |                     );
    386 |                 } else {
```

---

### 56. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 388 行
- **函数**: `redeemPositions()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    385 |                     );
    386 |                 } else {
    387 |                     require(
>>  388 |                         collateralToken.transfer(msg.sender, totalPayout),
    389 |                         "could not transfer payout to message sender"
    390 |                     );
    391 |                 }
```

---

### 57. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 540 行
- **函数**: `sqrt()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    537 |     function sqrt(uint x) private pure returns (uint y) {
    538 |         uint p = P;
    539 |         // solium-disable-next-line security/no-inline-assembly
>>  540 |         assembly {
    541 |             // add chain generated via https://crypto.stackexchange.com/q/27179/71252
    542 |             // and transformed to the following program:
    543 | 
```

---

### 58. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1897 行
- **函数**: `_doSafeTransferAcceptanceCheck()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1894 |                     revert ERC1155InvalidReceiver(to);
   1895 |                 } else {
   1896 |                     /// @solidity memory-safe-assembly
>> 1897 |                     assembly {
   1898 |                         revert(add(32, reason), mload(reason))
   1899 |                     }
   1900 |                 }
```

---

### 59. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1931 行
- **函数**: `_doSafeBatchTransferAcceptanceCheck()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1928 |                     revert ERC1155InvalidReceiver(to);
   1929 |                 } else {
   1930 |                     /// @solidity memory-safe-assembly
>> 1931 |                     assembly {
   1932 |                         revert(add(32, reason), mload(reason))
   1933 |                     }
   1934 |                 }
```

---

### 60. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 1947 行
- **函数**: `_asSingletonArrays()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1944 |         uint256 element2
   1945 |     ) private pure returns (uint256[] memory array1, uint256[] memory array2) {
   1946 |         /// @solidity memory-safe-assembly
>> 1947 |         assembly {
   1948 |             // Load the free memory pointer
   1949 |             array1 := mload(0x40)
   1950 |             // Set array length to 1
```

---

### 61. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2677 行
- **函数**: `unsafeAccess()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2674 |         // following https://docs.soliditylang.org/en/v0.8.20/internals/layout_in_storage.html#mappings-and-dynamic-arrays.
   2675 | 
   2676 |         /// @solidity memory-safe-assembly
>> 2677 |         assembly {
   2678 |             mstore(0, arr.slot)
   2679 |             slot := add(keccak256(0, 0x20), pos)
   2680 |         }
```

---

### 62. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2695 行
- **函数**: `unsafeAccess()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2692 |         // following https://docs.soliditylang.org/en/v0.8.20/internals/layout_in_storage.html#mappings-and-dynamic-arrays.
   2693 | 
   2694 |         /// @solidity memory-safe-assembly
>> 2695 |         assembly {
   2696 |             mstore(0, arr.slot)
   2697 |             slot := add(keccak256(0, 0x20), pos)
   2698 |         }
```

---

### 63. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2713 行
- **函数**: `unsafeAccess()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2710 |         // following https://docs.soliditylang.org/en/v0.8.20/internals/layout_in_storage.html#mappings-and-dynamic-arrays.
   2711 | 
   2712 |         /// @solidity memory-safe-assembly
>> 2713 |         assembly {
   2714 |             mstore(0, arr.slot)
   2715 |             slot := add(keccak256(0, 0x20), pos)
   2716 |         }
```

---

### 64. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2726 行
- **函数**: `unsafeMemoryAccess()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2723 |      * WARNING: Only use if you are certain `pos` is lower than the array length.
   2724 |      */
   2725 |     function unsafeMemoryAccess(uint256[] memory arr, uint256 pos) internal pure returns (uint256 res) {
>> 2726 |         assembly {
   2727 |             res := mload(add(add(arr, 0x20), mul(pos, 0x20)))
   2728 |         }
   2729 |     }
```

---

### 65. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 2737 行
- **函数**: `unsafeMemoryAccess()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2734 |      * WARNING: Only use if you are certain `pos` is lower than the array length.
   2735 |      */
   2736 |     function unsafeMemoryAccess(address[] memory arr, uint256 pos) internal pure returns (address res) {
>> 2737 |         assembly {
   2738 |             res := mload(add(add(arr, 0x20), mul(pos, 0x20)))
   2739 |         }
   2740 |     }
```

---

### 66. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3257 行
- **函数**: `_revert()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3254 |         if (returndata.length > 0) {
   3255 |             // The easiest way to bubble the revert reason is using memory via assembly
   3256 |             /// @solidity memory-safe-assembly
>> 3257 |             assembly {
   3258 |                 let returndata_size := mload(returndata)
   3259 |                 revert(add(32, returndata), returndata_size)
   3260 |             }
```

---

### 67. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3359 行
- **函数**: `getAddressSlot()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3356 |      */
   3357 |     function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
   3358 |         /// @solidity memory-safe-assembly
>> 3359 |         assembly {
   3360 |             r.slot := slot
   3361 |         }
   3362 |     }
```

---

### 68. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3369 行
- **函数**: `getBooleanSlot()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3366 |      */
   3367 |     function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
   3368 |         /// @solidity memory-safe-assembly
>> 3369 |         assembly {
   3370 |             r.slot := slot
   3371 |         }
   3372 |     }
```

---

### 69. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3379 行
- **函数**: `getBytes32Slot()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3376 |      */
   3377 |     function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
   3378 |         /// @solidity memory-safe-assembly
>> 3379 |         assembly {
   3380 |             r.slot := slot
   3381 |         }
   3382 |     }
```

---

### 70. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3389 行
- **函数**: `getUint256Slot()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3386 |      */
   3387 |     function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
   3388 |         /// @solidity memory-safe-assembly
>> 3389 |         assembly {
   3390 |             r.slot := slot
   3391 |         }
   3392 |     }
```

---

### 71. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3399 行
- **函数**: `getStringSlot()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3396 |      */
   3397 |     function getStringSlot(bytes32 slot) internal pure returns (StringSlot storage r) {
   3398 |         /// @solidity memory-safe-assembly
>> 3399 |         assembly {
   3400 |             r.slot := slot
   3401 |         }
   3402 |     }
```

---

### 72. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3409 行
- **函数**: `getStringSlot()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3406 |      */
   3407 |     function getStringSlot(string storage store) internal pure returns (StringSlot storage r) {
   3408 |         /// @solidity memory-safe-assembly
>> 3409 |         assembly {
   3410 |             r.slot := store.slot
   3411 |         }
   3412 |     }
```

---

### 73. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3419 行
- **函数**: `getBytesSlot()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3416 |      */
   3417 |     function getBytesSlot(bytes32 slot) internal pure returns (BytesSlot storage r) {
   3418 |         /// @solidity memory-safe-assembly
>> 3419 |         assembly {
   3420 |             r.slot := slot
   3421 |         }
   3422 |     }
```

---

### 74. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3429 行
- **函数**: `getBytesSlot()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3426 |      */
   3427 |     function getBytesSlot(bytes storage store) internal pure returns (BytesSlot storage r) {
   3428 |         /// @solidity memory-safe-assembly
>> 3429 |         assembly {
   3430 |             r.slot := store.slot
   3431 |         }
   3432 |     }
```

---

### 75. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3567 行
- **函数**: `mulDiv()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3564 |             // variables such that product = prod1 * 2^256 + prod0.
   3565 |             uint256 prod0 = x * y; // Least significant 256 bits of the product
   3566 |             uint256 prod1; // Most significant 256 bits of the product
>> 3567 |             assembly {
   3568 |                 let mm := mulmod(x, y, not(0))
   3569 |                 prod1 := sub(sub(mm, prod0), lt(mm, prod0))
   3570 |             }
```

---

### 76. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3591 行
- **函数**: `mulDiv()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3588 | 
   3589 |             // Make division exact by subtracting the remainder from [prod1 prod0].
   3590 |             uint256 remainder;
>> 3591 |             assembly {
   3592 |                 // Compute remainder using mulmod.
   3593 |                 remainder := mulmod(x, y, denominator)
   3594 | 
```

---

### 77. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x9400F8Ad57e9e0F352345935d6D3175975eb1d9F` 第 3604 行
- **函数**: `mulDiv()`
- **合约**: `for`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3601 |             // Always >= 1. See https://cs.stackexchange.com/q/138556/92363.
   3602 | 
   3603 |             uint256 twos = denominator & (0 - denominator);
>> 3604 |             assembly {
   3605 |                 // Divide denominator by twos.
   3606 |                 denominator := div(denominator, twos)
   3607 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*