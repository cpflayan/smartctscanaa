# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:04:40
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` |
| contract_name | `PositionManager` |
| compiler_version | `v0.8.26+commit.8a97fa7a` |
| optimization_used | `True` |
| runs | `30000` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/pkgs/v4-periphery/src/PositionManager.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/interfaces/IPoolManager.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/types/PoolKey.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/types/Currency.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/types/BalanceDelta.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/SafeCast.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/Position.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/StateLibrary.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/TransientStateLibrary.sol', 'src/pkgs/permit2/src/interfaces/IAllowanceTransfer.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/TickMath.sol', 'src/pkgs/v4-periphery/src/interfaces/IPositionDescriptor.sol', 'src/pkgs/v4-periphery/src/base/ERC721Permit_v4.sol', 'src/pkgs/v4-periphery/src/base/ReentrancyLock.sol', 'src/pkgs/v4-periphery/src/interfaces/IPositionManager.sol', 'src/pkgs/v4-periphery/src/base/Multicall_v4.sol', 'src/pkgs/v4-periphery/src/base/PoolInitializer_v4.sol', 'src/pkgs/v4-periphery/src/base/DeltaResolver.sol', 'src/pkgs/v4-periphery/src/base/BaseActionsRouter.sol', 'src/pkgs/v4-periphery/src/libraries/Actions.sol', 'src/pkgs/v4-periphery/src/base/Notifier.sol', 'src/pkgs/v4-periphery/src/libraries/CalldataDecoder.sol', 'src/pkgs/v4-periphery/src/base/Permit2Forwarder.sol', 'src/pkgs/v4-periphery/src/libraries/SlippageCheck.sol', 'src/pkgs/v4-periphery/src/libraries/PositionInfoLibrary.sol', 'src/pkgs/v4-periphery/src/libraries/LiquidityAmounts.sol', 'src/pkgs/v4-periphery/src/base/NativeWrapper.sol', 'src/pkgs/v4-periphery/src/interfaces/external/IWETH9.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/interfaces/IHooks.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/interfaces/external/IERC6909Claims.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/interfaces/IProtocolFees.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/types/PoolId.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/interfaces/IExtsload.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/interfaces/IExttload.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/interfaces/external/IERC20Minimal.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/CustomRevert.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/FullMath.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/FixedPoint128.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/LiquidityMath.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/CurrencyReserves.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/NonzeroDeltaCount.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/Lock.sol', 'src/pkgs/permit2/src/interfaces/IEIP712.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/BitMath.sol', 'src/pkgs/v4-periphery/lib/v4-core/lib/solmate/src/tokens/ERC721.sol', 'src/pkgs/v4-periphery/src/base/EIP712_v4.sol', 'src/pkgs/v4-periphery/src/libraries/ERC721PermitHash.sol', 'src/pkgs/permit2/src/libraries/SignatureVerification.sol', 'src/pkgs/v4-periphery/src/interfaces/IERC721Permit_v4.sol', 'src/pkgs/v4-periphery/src/base/UnorderedNonce.sol', 'src/pkgs/v4-periphery/src/libraries/Locker.sol', 'src/pkgs/v4-periphery/src/interfaces/INotifier.sol', 'src/pkgs/v4-periphery/src/interfaces/IImmutableState.sol', 'src/pkgs/v4-periphery/src/interfaces/IEIP712_v4.sol', 'src/pkgs/v4-periphery/src/interfaces/IMulticall_v4.sol', 'src/pkgs/v4-periphery/src/interfaces/IPoolInitializer_v4.sol', 'src/pkgs/v4-periphery/src/interfaces/IUnorderedNonce.sol', 'src/pkgs/v4-periphery/src/interfaces/IPermit2Forwarder.sol', 'src/pkgs/v4-periphery/src/base/ImmutableState.sol', 'src/pkgs/v4-periphery/src/libraries/ActionConstants.sol', 'src/pkgs/v4-periphery/src/base/SafeCallback.sol', 'src/pkgs/v4-periphery/src/interfaces/ISubscriber.sol', 'src/pkgs/v4-periphery/src/interfaces/IV4Router.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/libraries/FixedPoint96.sol', 'src/pkgs/v4-periphery/lib/v4-core/lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/types/BeforeSwapDelta.sol', 'src/pkgs/permit2/src/interfaces/IERC1271.sol', 'src/pkgs/v4-periphery/lib/v4-core/src/interfaces/callback/IUnlockCallback.sol', 'src/pkgs/v4-periphery/src/libraries/PathKey.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 94 |
| 🟢 LOW | 40 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2267 行
- **函数**: `multicall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   2264 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results) {
   2265 |         results = new bytes[](data.length);
   2266 |         for (uint256 i = 0; i < data.length; i++) {
>> 2267 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
   2268 | 
   2269 |             if (!success) {
   2270 |                 // bubble up the revert reason
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 168 行
- **函数**: `tokenURI()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    165 |         _;
    166 |     }
    167 | 
>>  168 |     function tokenURI(uint256 tokenId) public view override returns (string memory) {
    169 |         return IPositionDescriptor(tokenDescriptor).tokenURI(this, tokenId);
    170 |     }
    171 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 192 行
- **函数**: `msgSender()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    189 |     }
    190 | 
    191 |     /// @inheritdoc BaseActionsRouter
>>  192 |     function msgSender() public view override returns (address) {
    193 |         return _getLocker();
    194 |     }
    195 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 537 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    534 | 
    535 |     /// @dev overrides solmate transferFrom in case a notification to subscribers is needed
    536 |     /// @dev will revert if pool manager is locked
>>  537 |     function transferFrom(address from, address to, uint256 id) public virtual override onlyIfPoolManagerLocked {
    538 |         super.transferFrom(from, to, id);
    539 |         if (positionInfo[id].hasSubscriber()) _unsubscribe(id);
    540 |     }
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 543 行
- **函数**: `getPoolAndPositionInfo()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    540 |     }
    541 | 
    542 |     /// @inheritdoc IPositionManager
>>  543 |     function getPoolAndPositionInfo(uint256 tokenId) public view returns (PoolKey memory poolKey, PositionInfo info) {
    544 |         info = positionInfo[tokenId];
    545 |         poolKey = poolKeys[info.poolId()];
    546 |     }
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 549 行
- **函数**: `getPositionLiquidity()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    546 |     }
    547 | 
    548 |     /// @inheritdoc IPositionManager
>>  549 |     function getPositionLiquidity(uint256 tokenId) external view returns (uint128 liquidity) {
    550 |         (PoolKey memory poolKey, PositionInfo info) = getPoolAndPositionInfo(tokenId);
    551 |         liquidity = _getLiquidity(tokenId, poolKey, info.tickLower(), info.tickUpper());
    552 |     }
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 679 行
- **函数**: `unlock()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    676 |     /// @dev The only functions callable without an unlocking are `initialize` and `updateDynamicLPFee`
    677 |     /// @param data Any data to pass to the callback, via `IUnlockCallback(msg.sender).unlockCallback(data)`
    678 |     /// @return The data returned by the call to `IUnlockCallback(msg.sender).unlockCallback(data)`
>>  679 |     function unlock(bytes calldata data) external returns (bytes memory);
    680 | 
    681 |     /// @notice Initialize the state for a given pool ID
    682 |     /// @dev A swap fee totaling MAX_SWAP_FEE (100%) makes exact output swaps impossible since the input is entirely consumed by the fee
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 686 行
- **函数**: `initialize()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    683 |     /// @param key The pool key for the pool to initialize
    684 |     /// @param sqrtPriceX96 The initial square root price
    685 |     /// @return tick The initial tick of the pool
>>  686 |     function initialize(PoolKey memory key, uint160 sqrtPriceX96) external returns (int24 tick);
    687 | 
    688 |     struct ModifyLiquidityParams {
    689 |         // the lower and upper tick of the position
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 764 行
- **函数**: `settle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    761 | 
    762 |     /// @notice Called by the user to pay what is owed
    763 |     /// @return paid The amount of currency settled
>>  764 |     function settle() external payable returns (uint256 paid);
    765 | 
    766 |     /// @notice Called by the user to pay on behalf of another address
    767 |     /// @param recipient The address to credit for the payment
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 769 行
- **函数**: `settleFor()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    766 |     /// @notice Called by the user to pay on behalf of another address
    767 |     /// @param recipient The address to credit for the payment
    768 |     /// @return paid The amount of currency settled
>>  769 |     function settleFor(address recipient) external payable returns (uint256 paid);
    770 | 
    771 |     /// @notice WARNING - Any currency that is cleared, will be non-retrievable, and locked in the contract permanently.
    772 |     /// A call to clear will zero out a positive balance WITHOUT a corresponding transfer.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2029 行
- **函数**: `tokenURI()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2026 |     /// @param positionManager The position manager for which to describe the token
   2027 |     /// @param tokenId The ID of the token for which to produce a description, which may not be valid
   2028 |     /// @return The URI of the ERC721-compliant metadata
>> 2029 |     function tokenURI(IPositionManager positionManager, uint256 tokenId) external view returns (string memory);
   2030 | 
   2031 |     /// @notice Returns true if currency0 has higher priority than currency1
   2032 |     /// @param currency0 The first currency address
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2035 行
- **函数**: `flipRatio()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2032 |     /// @param currency0 The first currency address
   2033 |     /// @param currency1 The second currency address
   2034 |     /// @return True if currency0 has higher priority than currency1
>> 2035 |     function flipRatio(address currency0, address currency1) external view returns (bool);
   2036 | 
   2037 |     /// @notice Returns the priority of a currency.
   2038 |     /// For certain currencies on mainnet, the smaller the currency, the higher the priority
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2042 行
- **函数**: `currencyRatioPriority()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2039 |     /// And those with the higher priority values (more positive values) will be in the numerator of the price ratio
   2040 |     /// @param currency The currency address
   2041 |     /// @return The priority of the currency
>> 2042 |     function currencyRatioPriority(address currency) external view returns (int256);
   2043 | 
   2044 |     /// @return The wrapped native token for this descriptor
   2045 |     function wrappedNative() external view returns (address);
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2045 行
- **函数**: `wrappedNative()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2042 |     function currencyRatioPriority(address currency) external view returns (int256);
   2043 | 
   2044 |     /// @return The wrapped native token for this descriptor
>> 2045 |     function wrappedNative() external view returns (address);
   2046 | 
   2047 |     /// @return The native currency label for this descriptor
   2048 |     function nativeCurrencyLabel() external view returns (string memory);
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2048 行
- **函数**: `nativeCurrencyLabel()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2045 |     function wrappedNative() external view returns (address);
   2046 | 
   2047 |     /// @return The native currency label for this descriptor
>> 2048 |     function nativeCurrencyLabel() external view returns (string memory);
   2049 | 
   2050 |     /// @return The pool manager for this descriptor
   2051 |     function poolManager() external view returns (IPoolManager);
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2051 行
- **函数**: `poolManager()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2048 |     function nativeCurrencyLabel() external view returns (string memory);
   2049 | 
   2050 |     /// @return The pool manager for this descriptor
>> 2051 |     function poolManager() external view returns (IPoolManager);
   2052 | }
   2053 | 
   2054 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2121 行
- **函数**: `setApprovalForAll()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2118 |     /// @dev Override Solmate's ERC721 setApprovalForAll so setApprovalForAll() and permit() share the _approveForAll method
   2119 |     /// @param operator Address to add to the set of authorized operators
   2120 |     /// @param approved True if the operator is approved, false to revoke approval
>> 2121 |     function setApprovalForAll(address operator, bool approved) public override {
   2122 |         _approveForAll(msg.sender, operator, approved);
   2123 |     }
   2124 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2137 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2134 |     /// or an authorized operator of the current owner.
   2135 |     /// @param spender The new approved NFT controller
   2136 |     /// @param id The tokenId of the NFT to approve
>> 2137 |     function approve(address spender, uint256 id) public override {
   2138 |         address owner = _ownerOf[id];
   2139 | 
   2140 |         if (msg.sender != owner && !isApprovedForAll[owner][msg.sender]) revert Unauthorized();
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2222 行
- **函数**: `modifyLiquidities()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2219 |     /// @dev This is the standard entrypoint for the PositionManager
   2220 |     /// @param unlockData is an encoding of actions, and parameters for those actions
   2221 |     /// @param deadline is the deadline for the batched actions to be executed
>> 2222 |     function modifyLiquidities(bytes calldata unlockData, uint256 deadline) external payable;
   2223 | 
   2224 |     /// @notice Batches actions for modifying liquidity without unlocking v4 PoolManager
   2225 |     /// @dev This must be called by a contract that has already unlocked the v4 PoolManager
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2228 行
- **函数**: `modifyLiquiditiesWithoutUnlock()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2225 |     /// @dev This must be called by a contract that has already unlocked the v4 PoolManager
   2226 |     /// @param actions the actions to perform
   2227 |     /// @param params the parameters to provide for the actions
>> 2228 |     function modifyLiquiditiesWithoutUnlock(bytes calldata actions, bytes[] calldata params) external payable;
   2229 | 
   2230 |     /// @notice Used to get the ID that will be used for the next minted liquidity position
   2231 |     /// @return uint256 The next token ID
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2232 行
- **函数**: `nextTokenId()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2229 | 
   2230 |     /// @notice Used to get the ID that will be used for the next minted liquidity position
   2231 |     /// @return uint256 The next token ID
>> 2232 |     function nextTokenId() external view returns (uint256);
   2233 | 
   2234 |     /// @notice Returns the liquidity of a position
   2235 |     /// @param tokenId the ERC721 tokenId
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2238 行
- **函数**: `getPositionLiquidity()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2235 |     /// @param tokenId the ERC721 tokenId
   2236 |     /// @return liquidity the position's liquidity, as a liquidityAmount
   2237 |     /// @dev this value can be processed as an amount0 and amount1 by using the LiquidityAmounts library
>> 2238 |     function getPositionLiquidity(uint256 tokenId) external view returns (uint128 liquidity);
   2239 | 
   2240 |     /// @notice Returns the pool key and position info of a position
   2241 |     /// @param tokenId the ERC721 tokenId
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2244 行
- **函数**: `getPoolAndPositionInfo()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2241 |     /// @param tokenId the ERC721 tokenId
   2242 |     /// @return poolKey the pool key of the position
   2243 |     /// @return PositionInfo a uint256 packed value holding information about the position including the range (tickLower, tickUpper)
>> 2244 |     function getPoolAndPositionInfo(uint256 tokenId) external view returns (PoolKey memory, PositionInfo);
   2245 | 
   2246 |     /// @notice Returns the position info of a position
   2247 |     /// @param tokenId the ERC721 tokenId
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2249 行
- **函数**: `positionInfo()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2246 |     /// @notice Returns the position info of a position
   2247 |     /// @param tokenId the ERC721 tokenId
   2248 |     /// @return a uint256 packed value holding information about the position including the range (tickLower, tickUpper)
>> 2249 |     function positionInfo(uint256 tokenId) external view returns (PositionInfo);
   2250 | }
   2251 | 
   2252 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2264 行
- **函数**: `multicall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2261 | /// @notice Enables calling multiple methods in a single call to the contract
   2262 | abstract contract Multicall_v4 is IMulticall_v4 {
   2263 |     /// @inheritdoc IMulticall_v4
>> 2264 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results) {
   2265 |         results = new bytes[](data.length);
   2266 |         for (uint256 i = 0; i < data.length; i++) {
   2267 |             (bool success, bytes memory result) = address(this).delegatecall(data[i]);
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2296 行
- **函数**: `initializePool()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2293 | /// @dev Enables create pool + mint liquidity in a single transaction with multicall
   2294 | abstract contract PoolInitializer_v4 is ImmutableState, IPoolInitializer_v4 {
   2295 |     /// @inheritdoc IPoolInitializer_v4
>> 2296 |     function initializePool(PoolKey calldata key, uint160 sqrtPriceX96) external payable returns (int24) {
   2297 |         try poolManager.initialize(key, sqrtPriceX96) returns (int24 tick) {
   2298 |             return tick;
   2299 |         } catch {
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2491 行
- **函数**: `msgSender()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2488 |     /// In many contracts this will be the address that calls the initial entry point that calls `_executeActions`
   2489 |     /// `msg.sender` shouldn't be used, as this will be the v4 pool manager contract that calls `unlockCallback`
   2490 |     /// If using ReentrancyLock.sol, this function can return _getLocker()
>> 2491 |     function msgSender() public view virtual returns (address);
   2492 | 
   2493 |     /// @notice Calculates the address for a action
   2494 |     function _mapRecipient(address recipient) internal view returns (address) {
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3433 行
- **函数**: `deposit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3430 | /// @title IWETH9
   3431 | interface IWETH9 is IERC20 {
   3432 |     /// @notice Deposit ether to get wrapped ether
>> 3433 |     function deposit() external payable;
   3434 | 
   3435 |     /// @notice Withdraw wrapped ether to get ether
   3436 |     function withdraw(uint256) external;
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3462 行
- **函数**: `beforeInitialize()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3459 |     /// @param key The key for the pool being initialized
   3460 |     /// @param sqrtPriceX96 The sqrt(price) of the pool as a Q64.96
   3461 |     /// @return bytes4 The function selector for the hook
>> 3462 |     function beforeInitialize(address sender, PoolKey calldata key, uint160 sqrtPriceX96) external returns (bytes4);
   3463 | 
   3464 |     /// @notice The hook called after the state of a pool is initialized
   3465 |     /// @param sender The initial msg.sender for the initialize call
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3624 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3621 |     /// @param owner The address of the owner.
   3622 |     /// @param id The id of the token.
   3623 |     /// @return amount The balance of the token.
>> 3624 |     function balanceOf(address owner, uint256 id) external view returns (uint256 amount);
   3625 | 
   3626 |     /// @notice Spender allowance of an id.
   3627 |     /// @param owner The address of the owner.
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3631 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3628 |     /// @param spender The address of the spender.
   3629 |     /// @param id The id of the token.
   3630 |     /// @return amount The allowance of the token.
>> 3631 |     function allowance(address owner, address spender, uint256 id) external view returns (uint256 amount);
   3632 | 
   3633 |     /// @notice Checks if a spender is approved by an owner as an operator
   3634 |     /// @param owner The address of the owner.
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3637 行
- **函数**: `isOperator()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3634 |     /// @param owner The address of the owner.
   3635 |     /// @param spender The address of the spender.
   3636 |     /// @return approved The approval status.
>> 3637 |     function isOperator(address owner, address spender) external view returns (bool approved);
   3638 | 
   3639 |     /// @notice Transfers an amount of an id from the caller to a receiver.
   3640 |     /// @param receiver The address of the receiver.
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3644 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3641 |     /// @param id The id of the token.
   3642 |     /// @param amount The amount of the token.
   3643 |     /// @return bool True, always, unless the function reverts
>> 3644 |     function transfer(address receiver, uint256 id, uint256 amount) external returns (bool);
   3645 | 
   3646 |     /// @notice Transfers an amount of an id from a sender to a receiver.
   3647 |     /// @param sender The address of the sender.
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3652 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3649 |     /// @param id The id of the token.
   3650 |     /// @param amount The amount of the token.
   3651 |     /// @return bool True, always, unless the function reverts
>> 3652 |     function transferFrom(address sender, address receiver, uint256 id, uint256 amount) external returns (bool);
   3653 | 
   3654 |     /// @notice Approves an amount of an id to a spender.
   3655 |     /// @param spender The address of the spender.
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3659 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3656 |     /// @param id The id of the token.
   3657 |     /// @param amount The amount of the token.
   3658 |     /// @return bool True, always
>> 3659 |     function approve(address spender, uint256 id, uint256 amount) external returns (bool);
   3660 | 
   3661 |     /// @notice Sets or removes an operator for the caller.
   3662 |     /// @param operator The address of the operator.
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3665 行
- **函数**: `setOperator()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3662 |     /// @param operator The address of the operator.
   3663 |     /// @param approved The approval status.
   3664 |     /// @return bool True, always
>> 3665 |     function setOperator(address operator, bool approved) external returns (bool);
   3666 | }
   3667 | 
   3668 | 
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3698 行
- **函数**: `protocolFeesAccrued()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3695 |     /// @notice Given a currency address, returns the protocol fees accrued in that currency
   3696 |     /// @param currency The currency to check
   3697 |     /// @return amount The amount of protocol fees accrued in the currency
>> 3698 |     function protocolFeesAccrued(Currency currency) external view returns (uint256 amount);
   3699 | 
   3700 |     /// @notice Sets the protocol fee for the given pool
   3701 |     /// @param key The key of the pool to set a protocol fee for
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3721 行
- **函数**: `protocolFeeController()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3718 | 
   3719 |     /// @notice Returns the current protocol fee controller address
   3720 |     /// @return address The current protocol fee controller address
>> 3721 |     function protocolFeeController() external view returns (address);
   3722 | }
   3723 | 
   3724 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3756 行
- **函数**: `extsload()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3753 |     /// @notice Called by external contracts to access granular pool state
   3754 |     /// @param slot Key of slot to sload
   3755 |     /// @return value The value of the slot as bytes32
>> 3756 |     function extsload(bytes32 slot) external view returns (bytes32 value);
   3757 | 
   3758 |     /// @notice Called by external contracts to access granular pool state
   3759 |     /// @param startSlot Key of slot to start sloading from
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3762 行
- **函数**: `extsload()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3759 |     /// @param startSlot Key of slot to start sloading from
   3760 |     /// @param nSlots Number of slots to load into return value
   3761 |     /// @return values List of loaded values.
>> 3762 |     function extsload(bytes32 startSlot, uint256 nSlots) external view returns (bytes32[] memory values);
   3763 | 
   3764 |     /// @notice Called by external contracts to access sparse pool state
   3765 |     /// @param slots List of slots to SLOAD from.
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3767 行
- **函数**: `extsload()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3764 |     /// @notice Called by external contracts to access sparse pool state
   3765 |     /// @param slots List of slots to SLOAD from.
   3766 |     /// @return values List of loaded values.
>> 3767 |     function extsload(bytes32[] calldata slots) external view returns (bytes32[] memory values);
   3768 | }
   3769 | 
   3770 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3781 行
- **函数**: `exttload()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3778 |     /// @notice Called by external contracts to access transient storage of the contract
   3779 |     /// @param slot Key of slot to tload
   3780 |     /// @return value The value of the slot as bytes32
>> 3781 |     function exttload(bytes32 slot) external view returns (bytes32 value);
   3782 | 
   3783 |     /// @notice Called by external contracts to access sparse transient pool state
   3784 |     /// @param slots List of slots to tload
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3786 行
- **函数**: `exttload()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3783 |     /// @notice Called by external contracts to access sparse transient pool state
   3784 |     /// @param slots List of slots to tload
   3785 |     /// @return values List of loaded values
>> 3786 |     function exttload(bytes32[] calldata slots) external view returns (bytes32[] memory values);
   3787 | }
   3788 | 
   3789 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3801 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3798 |     /// @notice Returns an account's balance in the token
   3799 |     /// @param account The account for which to look up the number of tokens it has, i.e. its balance
   3800 |     /// @return The number of tokens held by the account
>> 3801 |     function balanceOf(address account) external view returns (uint256);
   3802 | 
   3803 |     /// @notice Transfers the amount of token from the `msg.sender` to the recipient
   3804 |     /// @param recipient The account that will receive the amount transferred
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3807 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3804 |     /// @param recipient The account that will receive the amount transferred
   3805 |     /// @param amount The number of tokens to send from the sender to the recipient
   3806 |     /// @return Returns true for a successful transfer, false for an unsuccessful transfer
>> 3807 |     function transfer(address recipient, uint256 amount) external returns (bool);
   3808 | 
   3809 |     /// @notice Returns the current allowance given to a spender by an owner
   3810 |     /// @param owner The account of the token owner
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3813 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3810 |     /// @param owner The account of the token owner
   3811 |     /// @param spender The account of the token spender
   3812 |     /// @return The current allowance granted by `owner` to `spender`
>> 3813 |     function allowance(address owner, address spender) external view returns (uint256);
   3814 | 
   3815 |     /// @notice Sets the allowance of a spender from the `msg.sender` to the value `amount`
   3816 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3819 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3816 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
   3817 |     /// @param amount The amount of tokens allowed to be used by `spender`
   3818 |     /// @return Returns true for a successful approval, false for unsuccessful
>> 3819 |     function approve(address spender, uint256 amount) external returns (bool);
   3820 | 
   3821 |     /// @notice Transfers `amount` tokens from `sender` to `recipient` up to the allowance given to the `msg.sender`
   3822 |     /// @param sender The account from which the transfer will be initiated
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3826 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3823 |     /// @param recipient The recipient of the transfer
   3824 |     /// @param amount The amount of the transfer
   3825 |     /// @return Returns true for a successful transfer, false for unsuccessful
>> 3826 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
   3827 | 
   3828 |     /// @notice Event emitted when tokens are transferred from one address to another, either via `#transfer` or `#transferFrom`.
   3829 |     /// @param from The account from which the tokens were sent, i.e. the balance decreased
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4243 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4240 | pragma solidity ^0.8.0;
   4241 | 
   4242 | interface IEIP712 {
>> 4243 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   4244 | }
   4245 | 
   4246 | 
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4326 行
- **函数**: `tokenURI()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4323 | 
   4324 |     string public symbol;
   4325 | 
>> 4326 |     function tokenURI(uint256 id) public view virtual returns (string memory);
   4327 | 
   4328 |     /*//////////////////////////////////////////////////////////////
   4329 |                       ERC721 BALANCE/OWNER STORAGE
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4336 行
- **函数**: `ownerOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4333 | 
   4334 |     mapping(address => uint256) internal _balanceOf;
   4335 | 
>> 4336 |     function ownerOf(uint256 id) public view virtual returns (address owner) {
   4337 |         require((owner = _ownerOf[id]) != address(0), "NOT_MINTED");
   4338 |     }
   4339 | 
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4340 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4337 |         require((owner = _ownerOf[id]) != address(0), "NOT_MINTED");
   4338 |     }
   4339 | 
>> 4340 |     function balanceOf(address owner) public view virtual returns (uint256) {
   4341 |         require(owner != address(0), "ZERO_ADDRESS");
   4342 | 
   4343 |         return _balanceOf[owner];
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4367 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4364 |                               ERC721 LOGIC
   4365 |     //////////////////////////////////////////////////////////////*/
   4366 | 
>> 4367 |     function approve(address spender, uint256 id) public virtual {
   4368 |         address owner = _ownerOf[id];
   4369 | 
   4370 |         require(msg.sender == owner || isApprovedForAll[owner][msg.sender], "NOT_AUTHORIZED");
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4377 行
- **函数**: `setApprovalForAll()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4374 |         emit Approval(owner, spender, id);
   4375 |     }
   4376 | 
>> 4377 |     function setApprovalForAll(address operator, bool approved) public virtual {
   4378 |         isApprovedForAll[msg.sender][operator] = approved;
   4379 | 
   4380 |         emit ApprovalForAll(msg.sender, operator, approved);
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4447 行
- **函数**: `supportsInterface()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4444 |                               ERC165 LOGIC
   4445 |     //////////////////////////////////////////////////////////////*/
   4446 | 
>> 4447 |     function supportsInterface(bytes4 interfaceId) public view virtual returns (bool) {
   4448 |         return
   4449 |             interfaceId == 0x01ffc9a7 || // ERC165 Interface ID for ERC165
   4450 |             interfaceId == 0x80ac58cd || // ERC165 Interface ID for ERC721
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4565 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4562 |     }
   4563 | 
   4564 |     /// @inheritdoc IEIP712_v4
>> 4565 |     function DOMAIN_SEPARATOR() public view returns (bytes32) {
   4566 |         // uses cached version if chainid is unchanged from construction
   4567 |         return block.chainid == _CACHED_CHAIN_ID ? _CACHED_DOMAIN_SEPARATOR : _buildDomainSeparator();
   4568 |     }
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4788 行
- **函数**: `revokeNonce()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4785 |     }
   4786 | 
   4787 |     /// @inheritdoc IUnorderedNonce
>> 4788 |     function revokeNonce(uint256 nonce) external payable {
   4789 |         _useUnorderedNonce(msg.sender, nonce);
   4790 |     }
   4791 | }
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4852 行
- **函数**: `subscriber()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4849 |     /// @notice Returns the subscriber for a respective position
   4850 |     /// @param tokenId the ERC721 tokenId
   4851 |     /// @return subscriber the subscriber contract
>> 4852 |     function subscriber(uint256 tokenId) external view returns (ISubscriber subscriber);
   4853 | 
   4854 |     /// @notice Enables the subscriber to receive notifications for a respective position
   4855 |     /// @param tokenId the ERC721 tokenId
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4861 行
- **函数**: `subscribe()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4858 |     /// @dev Calling subscribe when a position is already subscribed will revert
   4859 |     /// @dev payable so it can be multicalled with NATIVE related actions
   4860 |     /// @dev will revert if pool manager is locked
>> 4861 |     function subscribe(uint256 tokenId, address newSubscriber, bytes calldata data) external payable;
   4862 | 
   4863 |     /// @notice Removes the subscriber from receiving notifications for a respective position
   4864 |     /// @param tokenId the ERC721 tokenId
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4869 行
- **函数**: `unsubscribe()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4866 |     /// @dev payable so it can be multicalled with NATIVE related actions
   4867 |     /// @dev Must always allow a user to unsubscribe. In the case of a malicious subscriber, a user can always unsubscribe safely, ensuring liquidity is always modifiable.
   4868 |     /// @dev will revert if pool manager is locked
>> 4869 |     function unsubscribe(uint256 tokenId) external payable;
   4870 | 
   4871 |     /// @notice Returns and determines the maximum allowable gas-used for notifying unsubscribe
   4872 |     /// @return uint256 the maximum gas limit when notifying a subscriber's `notifyUnsubscribe` function
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4873 行
- **函数**: `unsubscribeGasLimit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4870 | 
   4871 |     /// @notice Returns and determines the maximum allowable gas-used for notifying unsubscribe
   4872 |     /// @return uint256 the maximum gas limit when notifying a subscriber's `notifyUnsubscribe` function
>> 4873 |     function unsubscribeGasLimit() external view returns (uint256);
   4874 | }
   4875 | 
   4876 | 
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4888 行
- **函数**: `poolManager()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4885 | /// @notice Interface for the ImmutableState contract
   4886 | interface IImmutableState {
   4887 |     /// @notice The Uniswap v4 PoolManager contract
>> 4888 |     function poolManager() external view returns (IPoolManager);
   4889 | }
   4890 | 
   4891 | 
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4902 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4899 | interface IEIP712_v4 {
   4900 |     /// @notice Returns the domain separator for the current chain.
   4901 |     /// @return bytes32 The domain separator
>> 4902 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   4903 | }
   4904 | 
   4905 | 
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4919 行
- **函数**: `multicall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4916 |     /// Subcalls can instead use `address(this).value` to see the available ETH, and consume it using {value: x}.
   4917 |     /// @param data The encoded function data for each of the calls to make to this contract
   4918 |     /// @return results The results from each of the calls passed in via data
>> 4919 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results);
   4920 | }
   4921 | 
   4922 | 
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4938 行
- **函数**: `initializePool()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4935 |     /// @param key The PoolKey of the pool to initialize
   4936 |     /// @param sqrtPriceX96 The initial starting price of the pool, expressed as a sqrtPriceX96
   4937 |     /// @return The current tick of the pool, or type(int24).max if the pool creation failed, or the pool already existed
>> 4938 |     function initializePool(PoolKey calldata key, uint160 sqrtPriceX96) external payable returns (int24);
   4939 | }
   4940 | 
   4941 | 
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4954 行
- **函数**: `nonces()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4951 | 
   4952 |     /// @notice mapping of nonces consumed by each address, where a nonce is a single bit on the 256-bit bitmap
   4953 |     /// @dev word is at most type(uint248).max
>> 4954 |     function nonces(address owner, uint256 word) external view returns (uint256);
   4955 | 
   4956 |     /// @notice Revoke a nonce by spending it, preventing it from being used again
   4957 |     /// @dev Used in cases where a valid nonce has not been broadcasted onchain, and the owner wants to revoke the validity of the nonce
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4959 行
- **函数**: `revokeNonce()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4956 |     /// @notice Revoke a nonce by spending it, preventing it from being used again
   4957 |     /// @dev Used in cases where a valid nonce has not been broadcasted onchain, and the owner wants to revoke the validity of the nonce
   4958 |     /// @dev payable so it can be multicalled with native-token related actions
>> 4959 |     function revokeNonce(uint256 nonce) external payable;
   4960 | }
   4961 | 
   4962 | 
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5066 行
- **函数**: `unlockCallback()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5063 | 
   5064 |     /// @inheritdoc IUnlockCallback
   5065 |     /// @dev We force the onlyPoolManager modifier by exposing a virtual function after the onlyPoolManager check.
>> 5066 |     function unlockCallback(bytes calldata data) external onlyPoolManager returns (bytes memory) {
   5067 |         return _unlockCallback(data);
   5068 |     }
   5069 | 
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5213 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5210 |     /**
   5211 |      * @dev Returns the value of tokens in existence.
   5212 |      */
>> 5213 |     function totalSupply() external view returns (uint256);
   5214 | 
   5215 |     /**
   5216 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5218 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5215 |     /**
   5216 |      * @dev Returns the value of tokens owned by `account`.
   5217 |      */
>> 5218 |     function balanceOf(address account) external view returns (uint256);
   5219 | 
   5220 |     /**
   5221 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5227 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5224 |      *
   5225 |      * Emits a {Transfer} event.
   5226 |      */
>> 5227 |     function transfer(address to, uint256 value) external returns (bool);
   5228 | 
   5229 |     /**
   5230 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5236 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5233 |      *
   5234 |      * This value changes when {approve} or {transferFrom} are called.
   5235 |      */
>> 5236 |     function allowance(address owner, address spender) external view returns (uint256);
   5237 | 
   5238 |     /**
   5239 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5253 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5250 |      *
   5251 |      * Emits an {Approval} event.
   5252 |      */
>> 5253 |     function approve(address spender, uint256 value) external returns (bool);
   5254 | 
   5255 |     /**
   5256 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5264 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5261 |      *
   5262 |      * Emits a {Transfer} event.
   5263 |      */
>> 5264 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   5265 | }
   5266 | 
   5267 | 
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5320 行
- **函数**: `isValidSignature()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5317 |     /// @param hash      Hash of the data to be signed
   5318 |     /// @param signature Signature byte array associated with _data
   5319 |     /// @return magicValue The bytes4 magic value 0x1626ba7e
>> 5320 |     function isValidSignature(bytes32 hash, bytes memory signature) external view returns (bytes4 magicValue);
   5321 | }
   5322 | 
   5323 | 
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5334 行
- **函数**: `unlockCallback()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5331 |     /// @notice Called by the pool manager on `msg.sender` when the manager is unlocked
   5332 |     /// @param data The data that was passed to the call to unlock
   5333 |     /// @return Any data that you want to be returned from the unlock call
>> 5334 |     function unlockCallback(bytes calldata data) external returns (bytes memory);
   5335 | }
   5336 | 
   5337 | 
```

---

### 77. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 1609 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1604 | 
   1605 | import {IEIP712} from "./IEIP712.sol";
   1606 | 
   1607 | /// @title AllowanceTransfer
   1608 | /// @notice Handles ERC20 token permissions through signature based allowance setting and ERC20 token transfers by checking allowed amounts
>> 1609 | /// @dev Requires user's token approval on the Permit2 contract
   1610 | interface IAllowanceTransfer is IEIP712 {
   1611 |     /// @notice Thrown when an allowance on a token has expired.
   1612 |     /// @param deadline The timestamp at which the allowed amount is no longer valid
   1613 |     error AllowanceExpired(uint256 deadline);
   1614 | 
```

---

### 78. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2020 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2015 | 
   2016 | import "./IPositionManager.sol";
   2017 | import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
   2018 | 
   2019 | /// @title IPositionDescriptor
>> 2020 | /// @notice Interface for the PositionDescriptor contract
   2021 | interface IPositionDescriptor {
   2022 |     error InvalidTokenId(uint256 tokenId);
   2023 | 
   2024 |     /// @notice Produces the URI describing a particular token ID
   2025 |     /// @dev Note this URI may be a data: URI with the JSON contents directly inlined
```

---

### 79. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2070 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2065 | import {IERC721Permit_v4} from "../interfaces/IERC721Permit_v4.sol";
   2066 | import {UnorderedNonce} from "./UnorderedNonce.sol";
   2067 | 
   2068 | /// @title ERC721 with permit
   2069 | /// @notice Nonfungible tokens that support an approve via signature, i.e. permit
>> 2070 | abstract contract ERC721Permit_v4 is ERC721, IERC721Permit_v4, EIP712_v4, UnorderedNonce {
   2071 |     using SignatureVerification for bytes;
   2072 | 
   2073 |     /// @notice Computes the nameHash and versionHash
   2074 |     constructor(string memory name_, string memory symbol_) ERC721(name_, symbol_) EIP712_v4(name_) {}
   2075 | 
```

---

### 80. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2199 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2194 | import {IPoolInitializer_v4} from "./IPoolInitializer_v4.sol";
   2195 | import {IUnorderedNonce} from "./IUnorderedNonce.sol";
   2196 | import {IPermit2Forwarder} from "./IPermit2Forwarder.sol";
   2197 | 
   2198 | /// @title IPositionManager
>> 2199 | /// @notice Interface for the PositionManager contract
   2200 | interface IPositionManager is
   2201 |     INotifier,
   2202 |     IImmutableState,
   2203 |     IERC721Permit_v4,
   2204 |     IEIP712_v4,
```

---

### 81. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2261 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2256 | pragma solidity ^0.8.0;
   2257 | 
   2258 | import {IMulticall_v4} from "../interfaces/IMulticall_v4.sol";
   2259 | 
   2260 | /// @title Multicall_v4
>> 2261 | /// @notice Enables calling multiple methods in a single call to the contract
   2262 | abstract contract Multicall_v4 is IMulticall_v4 {
   2263 |     /// @inheritdoc IMulticall_v4
   2264 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results) {
   2265 |         results = new bytes[](data.length);
   2266 |         for (uint256 i = 0; i < data.length; i++) {
```

---

### 82. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2317 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2312 | import {TransientStateLibrary} from "@uniswap/v4-core/src/libraries/TransientStateLibrary.sol";
   2313 | import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
   2314 | import {ImmutableState} from "./ImmutableState.sol";
   2315 | import {ActionConstants} from "../libraries/ActionConstants.sol";
   2316 | 
>> 2317 | /// @notice Abstract contract used to sync, send, and settle funds to the pool manager
   2318 | /// @dev Note that sync() is called before any erc-20 transfer in `settle`.
   2319 | abstract contract DeltaResolver is ImmutableState {
   2320 |     using TransientStateLibrary for IPoolManager;
   2321 | 
   2322 |     /// @notice Emitted trying to settle a positive delta.
```

---

### 83. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3396 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3391 | import {ActionConstants} from "../libraries/ActionConstants.sol";
   3392 | import {ImmutableState} from "./ImmutableState.sol";
   3393 | 
   3394 | /// @title Native Wrapper
   3395 | /// @notice Used for wrapping and unwrapping native
>> 3396 | abstract contract NativeWrapper is ImmutableState {
   3397 |     /// @notice The address for WETH9
   3398 |     IWETH9 public immutable WETH9;
   3399 | 
   3400 |     /// @notice Thrown when an unexpected address sends ETH to this contract
   3401 |     error InvalidEthSender();
```

---

### 84. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3451 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3446 | import {BalanceDelta} from "../types/BalanceDelta.sol";
   3447 | import {IPoolManager} from "./IPoolManager.sol";
   3448 | import {BeforeSwapDelta} from "../types/BeforeSwapDelta.sol";
   3449 | 
   3450 | /// @notice V4 decides whether to invoke specific hooks by inspecting the least significant bits
>> 3451 | /// of the address that the hooks contract is deployed to.
   3452 | /// For example, a hooks contract deployed to address: 0x0000000000000000000000000000000000002400
   3453 | /// has the lowest bits '10 0100 0000 0000' which would cause the 'before initialize' and 'after add liquidity' hooks to be used.
   3454 | /// See the Hooks library for the full spec.
   3455 | /// @dev Should only be callable by the v4 PoolManager.
   3456 | interface IHooks {
```

---

### 85. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3604 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3599 | // ── src/pkgs/v4-periphery/lib/v4-core/src/interfaces/external/IERC6909Claims.sol ──────────────────────────────
   3600 | 
   3601 | // SPDX-License-Identifier: MIT
   3602 | pragma solidity ^0.8.0;
   3603 | 
>> 3604 | /// @notice Interface for claims over a contract balance, wrapped as a ERC6909
   3605 | interface IERC6909Claims {
   3606 |     /*//////////////////////////////////////////////////////////////
   3607 |                                  EVENTS
   3608 |     //////////////////////////////////////////////////////////////*/
   3609 | 
```

---

### 86. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4307 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4302 | // SPDX-License-Identifier: AGPL-3.0-only
   4303 | pragma solidity >=0.8.0;
   4304 | 
   4305 | /// @notice Modern, minimalist, and gas efficient ERC-721 implementation.
   4306 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC721.sol)
>> 4307 | abstract contract ERC721 {
   4308 |     /*//////////////////////////////////////////////////////////////
   4309 |                                  EVENTS
   4310 |     //////////////////////////////////////////////////////////////*/
   4311 | 
   4312 |     event Transfer(address indexed from, address indexed to, uint256 indexed id);
```

---

### 87. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4521 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4516 |             "UNSAFE_RECIPIENT"
   4517 |         );
   4518 |     }
   4519 | }
   4520 | 
>> 4521 | /// @notice A generic interface for a contract which properly accepts ERC721 tokens.
   4522 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC721.sol)
   4523 | abstract contract ERC721TokenReceiver {
   4524 |     function onERC721Received(
   4525 |         address,
   4526 |         address,
```

---

### 88. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4547 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4542 | /// @notice Generic EIP712 implementation
   4543 | /// @dev Maintains cross-chain replay protection in the event of a fork
   4544 | /// @dev Should not be delegatecall'd because DOMAIN_SEPARATOR returns the cached hash and does not recompute with the delegatecallers address
   4545 | /// @dev Reference: https://github.com/Uniswap/permit2/blob/3f17e8db813189a03950dc7fc8382524a095c053/src/EIP712.sol
   4546 | /// @dev Reference: https://github.com/OpenZeppelin/openzeppelin-contracts/blob/7bd2b2aaf68c21277097166a9a51eb72ae239b34/contracts/utils/cryptography/EIP712.sol
>> 4547 | contract EIP712_v4 is IEIP712_v4 {
   4548 |     // Cache the domain separator as an immutable value, but also store the chain id that it
   4549 |     // corresponds to, in order to invalidate the cached domain separator if the chain id changes.
   4550 |     bytes32 private immutable _CACHED_DOMAIN_SEPARATOR;
   4551 |     uint256 private immutable _CACHED_CHAIN_ID;
   4552 |     bytes32 private immutable _HASHED_NAME;
```

---

### 89. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4726 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4721 | 
   4722 | // SPDX-License-Identifier: MIT
   4723 | pragma solidity ^0.8.0;
   4724 | 
   4725 | /// @title IERC721Permit_v4
>> 4726 | /// @notice Interface for the ERC721Permit_v4 contract
   4727 | interface IERC721Permit_v4 {
   4728 |     error SignatureDeadlineExpired();
   4729 |     error NoSelfPermit();
   4730 |     error Unauthorized();
   4731 | 
```

---

### 90. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4771 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4766 | 
   4767 | import {IUnorderedNonce} from "../interfaces/IUnorderedNonce.sol";
   4768 | 
   4769 | /// @title Unordered Nonce
   4770 | /// @notice Contract state and methods for using unordered nonces in signatures
>> 4771 | contract UnorderedNonce is IUnorderedNonce {
   4772 |     /// @inheritdoc IUnorderedNonce
   4773 |     mapping(address owner => mapping(uint256 word => uint256 bitmap)) public nonces;
   4774 | 
   4775 |     /// @notice Consume a nonce, reverting if it has already been used
   4776 |     /// @param owner address, the owner/signer of the nonce
```

---

### 91. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4827 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4822 | pragma solidity ^0.8.0;
   4823 | 
   4824 | import {ISubscriber} from "./ISubscriber.sol";
   4825 | 
   4826 | /// @title INotifier
>> 4827 | /// @notice Interface for the Notifier contract
   4828 | interface INotifier {
   4829 |     /// @notice Thrown when unsubscribing without a subscriber
   4830 |     error NotSubscribed();
   4831 |     /// @notice Thrown when a subscriber does not have code
   4832 |     error NoCodeSubscriber();
```

---

### 92. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4948 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4943 | 
   4944 | // SPDX-License-Identifier: MIT
   4945 | pragma solidity ^0.8.0;
   4946 | 
   4947 | /// @title IUnorderedNonce
>> 4948 | /// @notice Interface for the UnorderedNonce contract
   4949 | interface IUnorderedNonce {
   4950 |     error NonceAlreadyUsed();
   4951 | 
   4952 |     /// @notice mapping of nonces consumed by each address, where a nonce is a single bit on the 256-bit bitmap
   4953 |     /// @dev word is at most type(uint248).max
```

---

### 93. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4971 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4966 | pragma solidity ^0.8.0;
   4967 | 
   4968 | import {IAllowanceTransfer} from "permit2/src/interfaces/IAllowanceTransfer.sol";
   4969 | 
   4970 | /// @title IPermit2Forwarder
>> 4971 | /// @notice Interface for the Permit2Forwarder contract
   4972 | interface IPermit2Forwarder {
   4973 |     /// @notice allows forwarding a single permit to permit2
   4974 |     /// @dev this function is payable to allow multicall with NATIVE based actions
   4975 |     /// @param owner the owner of the tokens
   4976 |     /// @param permitSingle the permit data
```

---

### 94. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5084 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5079 | 
   5080 | import {BalanceDelta} from "@uniswap/v4-core/src/types/BalanceDelta.sol";
   5081 | import {PositionInfo} from "../libraries/PositionInfoLibrary.sol";
   5082 | 
   5083 | /// @title ISubscriber
>> 5084 | /// @notice Interface that a Subscriber contract should implement to receive updates from the v4 position manager
   5085 | interface ISubscriber {
   5086 |     /// @notice Called when a position subscribes to this subscriber contract
   5087 |     /// @param tokenId the token ID of the position
   5088 |     /// @param data additional data passed in by the caller
   5089 |     function notifySubscribe(uint256 tokenId, bytes memory data) external;
```

---

### 95. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5128 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5123 | import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
   5124 | import {PathKey} from "../libraries/PathKey.sol";
   5125 | import {IImmutableState} from "./IImmutableState.sol";
   5126 | 
   5127 | /// @title IV4Router
>> 5128 | /// @notice Interface for the V4Router contract
   5129 | interface IV4Router is IImmutableState {
   5130 |     /// @notice Emitted when an exactInput swap does not receive its minAmountOut
   5131 |     error V4TooLittleReceived(uint256 minAmountOutReceived, uint256 amountReceived);
   5132 |     /// @notice Emitted when an exactOutput is asked for more than its maxAmountIn
   5133 |     error V4TooMuchRequested(uint256 maxAmountInRequested, uint256 amountRequested);
```

---

### 96. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 148 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    145 |     /// @notice Reverts if the deadline has passed
    146 |     /// @param deadline The timestamp at which the call is no longer valid, passed in by the caller
    147 |     modifier checkDeadline(uint256 deadline) {
>>  148 |         if (block.timestamp > deadline) revert DeadlinePassed(deadline);
    149 |         _;
    150 |     }
    151 | 
```

---

### 97. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2078 行
- **函数**: `poolManager()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2075 | 
   2076 |     /// @notice Checks if the block's timestamp is before a signature's deadline
   2077 |     modifier checkSignatureDeadline(uint256 deadline) {
>> 2078 |         if (block.timestamp > deadline) revert SignatureDeadlineExpired();
   2079 |         _;
   2080 |     }
   2081 | 
```

---

### 98. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 488 行
- **函数**: `_sweep()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    485 |     /// @notice Sweeps the entire contract balance of specified currency to the recipient
    486 |     function _sweep(Currency currency, address to) internal {
    487 |         uint256 balance = currency.balanceOfSelf();
>>  488 |         if (balance > 0) currency.transfer(to, balance);
    489 |     }
    490 | 
    491 |     /// @dev if there is a subscriber attached to the position, this function will notify the subscriber
```

---

### 99. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 518 行
- **函数**: `_pay()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    515 |     // implementation of abstract function DeltaResolver._pay
    516 |     function _pay(Currency currency, address payer, uint256 amount) internal override {
    517 |         if (payer == address(this)) {
>>  518 |             currency.transfer(address(poolManager), amount);
    519 |         } else {
    520 |             // Casting from uint256 to uint160 is safe due to limits on the total supply of a pool
    521 |             permit2.transferFrom(payer, address(poolManager), uint160(amount), Currency.unwrap(currency));
```

---

### 100. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 888 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    885 |                 let fmp := mload(0x40)
    886 | 
    887 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
>>  888 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
    889 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
    890 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
    891 | 
```

---

### 101. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 889 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    886 | 
    887 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
    888 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>>  889 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
    890 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
    891 | 
    892 |                 success :=
```

---

### 102. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 1253 行
- **函数**: `getSlot0()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1250 |         // ---------- | fee  |protocolfee | tick  | sqrtPriceX96
   1251 |         assembly ("memory-safe") {
   1252 |             // bottom 160 bits of data
>> 1253 |             sqrtPriceX96 := and(data, 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF)
   1254 |             // next 24 bits of data
   1255 |             tick := signextend(2, shr(160, data))
   1256 |             // next 24 bits of data
```

---

### 103. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 1586 行
- **函数**: `currencyDelta()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1583 |     function currencyDelta(IPoolManager manager, address target, Currency currency) internal view returns (int256) {
   1584 |         bytes32 key;
   1585 |         assembly ("memory-safe") {
>> 1586 |             mstore(0, and(target, 0xffffffffffffffffffffffffffffffffffffffff))
   1587 |             mstore(32, and(currency, 0xffffffffffffffffffffffffffffffffffffffff))
   1588 |             key := keccak256(0, 64)
   1589 |         }
```

---

### 104. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 1587 行
- **函数**: `currencyDelta()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1584 |         bytes32 key;
   1585 |         assembly ("memory-safe") {
   1586 |             mstore(0, and(target, 0xffffffffffffffffffffffffffffffffffffffff))
>> 1587 |             mstore(32, and(currency, 0xffffffffffffffffffffffffffffffffffffffff))
   1588 |             key := keccak256(0, 64)
   1589 |         }
   1590 |         return int256(uint256(manager.exttload(key)));
```

---

### 105. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3236 行
- **函数**: `validateMaxIn()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3233 | library PositionInfoLibrary {
   3234 |     PositionInfo internal constant EMPTY_POSITION_INFO = PositionInfo.wrap(0);
   3235 | 
>> 3236 |     uint256 internal constant MASK_UPPER_200_BITS = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000000000;
   3237 |     uint256 internal constant MASK_8_BITS = 0xFF;
   3238 |     uint24 internal constant MASK_24_BITS = 0xFFFFFF;
   3239 |     uint256 internal constant SET_UNSUBSCRIBE = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00;
```

---

### 106. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3239 行
- **函数**: `validateMaxIn()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3236 |     uint256 internal constant MASK_UPPER_200_BITS = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000000000;
   3237 |     uint256 internal constant MASK_8_BITS = 0xFF;
   3238 |     uint24 internal constant MASK_24_BITS = 0xFFFFFF;
>> 3239 |     uint256 internal constant SET_UNSUBSCRIBE = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00;
   3240 |     uint256 internal constant SET_SUBSCRIBE = 0x01;
   3241 |     uint8 internal constant TICK_LOWER_OFFSET = 8;
   3242 |     uint8 internal constant TICK_UPPER_OFFSET = 32;
```

---

### 107. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3868 行
- **函数**: `revertWith()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3865 |     function revertWith(bytes4 selector, address addr) internal pure {
   3866 |         assembly ("memory-safe") {
   3867 |             mstore(0, selector)
>> 3868 |             mstore(0x04, and(addr, 0xffffffffffffffffffffffffffffffffffffffff))
   3869 |             revert(0, 0x24)
   3870 |         }
   3871 |     }
```

---

### 108. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3886 行
- **函数**: `revertWith()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3883 |     function revertWith(bytes4 selector, uint160 value) internal pure {
   3884 |         assembly ("memory-safe") {
   3885 |             mstore(0, selector)
>> 3886 |             mstore(0x04, and(value, 0xffffffffffffffffffffffffffffffffffffffff))
   3887 |             revert(0, 0x24)
   3888 |         }
   3889 |     }
```

---

### 109. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3907 行
- **函数**: `revertWith()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3904 |         assembly ("memory-safe") {
   3905 |             let fmp := mload(0x40)
   3906 |             mstore(fmp, selector)
>> 3907 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
   3908 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   3909 |             revert(fmp, 0x44)
   3910 |         }
```

---

### 110. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3908 行
- **函数**: `revertWith()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3905 |             let fmp := mload(0x40)
   3906 |             mstore(fmp, selector)
   3907 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
>> 3908 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   3909 |             revert(fmp, 0x44)
   3910 |         }
   3911 |     }
```

---

### 111. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3918 行
- **函数**: `revertWith()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3915 |         assembly ("memory-safe") {
   3916 |             let fmp := mload(0x40)
   3917 |             mstore(fmp, selector)
>> 3918 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
   3919 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   3920 |             revert(fmp, 0x44)
   3921 |         }
```

---

### 112. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3919 行
- **函数**: `revertWith()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3916 |             let fmp := mload(0x40)
   3917 |             mstore(fmp, selector)
   3918 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
>> 3919 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   3920 |             revert(fmp, 0x44)
   3921 |         }
   3922 |     }
```

---

### 113. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3940 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3937 | 
   3938 |             // Encode wrapped error selector, address, function selector, offset, additional context, size, revert reason
   3939 |             mstore(fmp, wrappedErrorSelector)
>> 3940 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   3941 |             mstore(
   3942 |                 add(fmp, 0x24),
   3943 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
```

---

### 114. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3943 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3940 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   3941 |             mstore(
   3942 |                 add(fmp, 0x24),
>> 3943 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   3944 |             )
   3945 |             // offset revert reason
   3946 |             mstore(add(fmp, 0x44), 0x80)
```

---

### 115. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3958 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3955 |             // additional context
   3956 |             mstore(
   3957 |                 add(fmp, add(0xc4, encodedDataSize)),
>> 3958 |                 and(additionalContext, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   3959 |             )
   3960 |             revert(fmp, add(0xe4, encodedDataSize))
   3961 |         }
```

---

### 116. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4135 行
- **函数**: `addDelta()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4132 |     using CustomRevert for bytes4;
   4133 | 
   4134 |     /// bytes32(uint256(keccak256("ReservesOf")) - 1)
>> 4135 |     bytes32 constant RESERVES_OF_SLOT = 0x1e0745a7db1623981f0b2a5d4232364c00787266eb75ad546f190e6cebe9bd95;
   4136 |     /// bytes32(uint256(keccak256("Currency")) - 1)
   4137 |     bytes32 constant CURRENCY_SLOT = 0x27e098c505d44ec3574004bca052aabf76bd35004c182099d8c575fb238593b9;
   4138 | 
```

---

### 117. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4137 行
- **函数**: `addDelta()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4134 |     /// bytes32(uint256(keccak256("ReservesOf")) - 1)
   4135 |     bytes32 constant RESERVES_OF_SLOT = 0x1e0745a7db1623981f0b2a5d4232364c00787266eb75ad546f190e6cebe9bd95;
   4136 |     /// bytes32(uint256(keccak256("Currency")) - 1)
>> 4137 |     bytes32 constant CURRENCY_SLOT = 0x27e098c505d44ec3574004bca052aabf76bd35004c182099d8c575fb238593b9;
   4138 | 
   4139 |     function getSyncedCurrency() internal view returns (Currency currency) {
   4140 |         assembly ("memory-safe") {
```

---

### 118. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4153 行
- **函数**: `syncCurrencyAndReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4150 | 
   4151 |     function syncCurrencyAndReserves(Currency currency, uint256 value) internal {
   4152 |         assembly ("memory-safe") {
>> 4153 |             tstore(CURRENCY_SLOT, and(currency, 0xffffffffffffffffffffffffffffffffffffffff))
   4154 |             tstore(RESERVES_OF_SLOT, value)
   4155 |         }
   4156 |     }
```

---

### 119. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4177 行
- **函数**: `getSyncedReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4174 | library NonzeroDeltaCount {
   4175 |     // The slot holding the number of nonzero deltas. bytes32(uint256(keccak256("NonzeroDeltaCount")) - 1)
   4176 |     bytes32 internal constant NONZERO_DELTA_COUNT_SLOT =
>> 4177 |         0x7d4b3164c6e45b97e7d87b7125a44c5828d005af88f9d751cfd78729c5d99a0b;
   4178 | 
   4179 |     function read() internal view returns (uint256 count) {
   4180 |         assembly ("memory-safe") {
```

---

### 120. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4214 行
- **函数**: `decrement()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4211 | /// TODO: This library can be deleted when we have the transient keyword support in solidity.
   4212 | library Lock {
   4213 |     // The slot holding the unlocked state, transiently. bytes32(uint256(keccak256("Unlocked")) - 1)
>> 4214 |     bytes32 internal constant IS_UNLOCKED_SLOT = 0xc090fc4683624cfc3884e9d8de5eca132f2d0ec062aff75d43c0465d5ceeab23;
   4215 | 
   4216 |     function unlock() internal {
   4217 |         assembly ("memory-safe") {
```

---

### 121. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4271 行
- **函数**: `mostSignificantBit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4268 |             r := or(r, shl(3, lt(0xff, shr(r, x))))
   4269 |             // forgefmt: disable-next-item
   4270 |             r := or(r, byte(and(0x1f, shr(shr(r, x), 0x8421084210842108cc6318c6db6d54be)),
>> 4271 |                 0x0706060506020500060203020504000106050205030304010505030400000000))
   4272 |         }
   4273 |     }
   4274 | 
```

---

### 122. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4289 行
- **函数**: `leastSignificantBit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4286 |             // Credit to adhusson: https://blog.adhusson.com/cheap-find-first-set-evm/
   4287 |             // forgefmt: disable-next-item
   4288 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
>> 4289 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
   4290 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   4291 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   4292 |             // forgefmt: disable-next-item
```

---

### 123. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4290 行
- **函数**: `leastSignificantBit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4287 |             // forgefmt: disable-next-item
   4288 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
   4289 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
>> 4290 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   4291 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   4292 |             // forgefmt: disable-next-item
   4293 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
```

---

### 124. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4294 行
- **函数**: `leastSignificantBit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4291 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   4292 |             // forgefmt: disable-next-item
   4293 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
>> 4294 |                 0x001f0d1e100c1d070f090b19131c1706010e11080a1a141802121b1503160405))
   4295 |         }
   4296 |     }
   4297 | }
```

---

### 125. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4602 行
- **函数**: `_hashTypedData()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4599 | 
   4600 | library ERC721PermitHash {
   4601 |     /// @dev Value is equal to keccak256("Permit(address spender,uint256 tokenId,uint256 nonce,uint256 deadline)");
>> 4602 |     bytes32 constant PERMIT_TYPEHASH = 0x49ecf333e5b8c95c40fdafc95c1ad136e8914a8fb55e9dc8bb01eaa83a2df9ad;
   4603 | 
   4604 |     /// @dev Value is equal to keccak256("PermitForAll(address operator,bool approved,uint256 nonce,uint256 deadline)");
   4605 |     bytes32 constant PERMIT_FOR_ALL_TYPEHASH = 0x6673cb397ee2a50b6b8401653d3638b4ac8b3db9c28aa6870ffceb7574ec2f76;
```

---

### 126. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4605 行
- **函数**: `_hashTypedData()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4602 |     bytes32 constant PERMIT_TYPEHASH = 0x49ecf333e5b8c95c40fdafc95c1ad136e8914a8fb55e9dc8bb01eaa83a2df9ad;
   4603 | 
   4604 |     /// @dev Value is equal to keccak256("PermitForAll(address operator,bool approved,uint256 nonce,uint256 deadline)");
>> 4605 |     bytes32 constant PERMIT_FOR_ALL_TYPEHASH = 0x6673cb397ee2a50b6b8401653d3638b4ac8b3db9c28aa6870ffceb7574ec2f76;
   4606 | 
   4607 |     /// @notice Hashes the data that will be signed for IERC721Permit_v4.permit()
   4608 |     /// @param spender The address which may spend the tokenId
```

---

### 127. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4622 行
- **函数**: `hashPermit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4619 |         assembly ("memory-safe") {
   4620 |             let fmp := mload(0x40)
   4621 |             mstore(fmp, PERMIT_TYPEHASH)
>> 4622 |             mstore(add(fmp, 0x20), and(spender, 0xffffffffffffffffffffffffffffffffffffffff))
   4623 |             mstore(add(fmp, 0x40), tokenId)
   4624 |             mstore(add(fmp, 0x60), nonce)
   4625 |             mstore(add(fmp, 0x80), deadline)
```

---

### 128. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4652 行
- **函数**: `hashPermitForAll()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4649 |         assembly ("memory-safe") {
   4650 |             let fmp := mload(0x40)
   4651 |             mstore(fmp, PERMIT_FOR_ALL_TYPEHASH)
>> 4652 |             mstore(add(fmp, 0x20), and(operator, 0xffffffffffffffffffffffffffffffffffffffff))
   4653 |             mstore(add(fmp, 0x40), and(approved, 0x1))
   4654 |             mstore(add(fmp, 0x60), nonce)
   4655 |             mstore(add(fmp, 0x80), deadline)
```

---

### 129. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4689 行
- **函数**: `hashPermitForAll()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4686 |     /// @notice Thrown when the recovered contract signature is incorrect
   4687 |     error InvalidContractSignature();
   4688 | 
>> 4689 |     bytes32 constant UPPER_BIT_MASK = (0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
   4690 | 
   4691 |     function verify(bytes calldata signature, bytes32 hash, address claimedSigner) internal view {
   4692 |         bytes32 r;
```

---

### 130. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4803 行
- **函数**: `revokeNonce()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4800 | /// TODO: This library can be deleted when we have the transient keyword support in solidity.
   4801 | library Locker {
   4802 |     // The slot holding the locker state, transiently. bytes32(uint256(keccak256("LockedBy")) - 1)
>> 4803 |     bytes32 constant LOCKED_BY_SLOT = 0x0aedd6bde10e3aa2adec092b02a3e3e805795516cda41f27aa145b8f300af87a;
   4804 | 
   4805 |     function set(address locker) internal {
   4806 |         assembly {
```

---

### 131. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 5031 行
- **函数**: `permitBatch()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5028 |     uint128 internal constant OPEN_DELTA = 0;
   5029 |     /// @notice used to signal that an action should use the contract's entire balance of a currency
   5030 |     /// This value is equivalent to 1<<255, i.e. a singular 1 in the most significant bit.
>> 5031 |     uint256 internal constant CONTRACT_BALANCE = 0x8000000000000000000000000000000000000000000000000000000000000000;
   5032 | 
   5033 |     /// @notice used to signal that the recipient of an action should be the msgSender
   5034 |     address internal constant MSG_SENDER = address(1);
```

---

### 132. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 2271 行
- **函数**: `multicall()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2268 | 
   2269 |             if (!success) {
   2270 |                 // bubble up the revert reason
>> 2271 |                 assembly {
   2272 |                     revert(add(result, 0x20), mload(result))
   2273 |                 }
   2274 |             }
```

---

### 133. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 3295 行
- **函数**: `initialize()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3292 |         returns (PositionInfo info)
   3293 |     {
   3294 |         bytes25 _poolId = bytes25(PoolId.unwrap(_poolKey.toId()));
>> 3295 |         assembly {
   3296 |             info :=
   3297 |                 or(
   3298 |                     or(and(MASK_UPPER_200_BITS, _poolId), shl(TICK_UPPER_OFFSET, and(MASK_24_BITS, _tickUpper))),
```

---

### 134. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4806 行
- **函数**: `set()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4803 |     bytes32 constant LOCKED_BY_SLOT = 0x0aedd6bde10e3aa2adec092b02a3e3e805795516cda41f27aa145b8f300af87a;
   4804 | 
   4805 |     function set(address locker) internal {
>> 4806 |         assembly {
   4807 |             tstore(LOCKED_BY_SLOT, locker)
   4808 |         }
   4809 |     }
```

---

### 135. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x7A4a5c919aE2541AeD11041A1AEeE68f1287f95b` 第 4812 行
- **函数**: `get()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4809 |     }
   4810 | 
   4811 |     function get() internal view returns (address locker) {
>> 4812 |         assembly {
   4813 |             locker := tload(LOCKED_BY_SLOT)
   4814 |         }
   4815 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*