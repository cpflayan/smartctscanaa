# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:06:09
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` |
| contract_name | `AirDrop` |
| compiler_version | `v0.7.6+commit.7338295f` |
| optimization_used | `True` |
| runs | `99999` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/AirDrop.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 25 |
| 🟢 LOW | 7 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 436 行
- **函数**: `sendValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    433 |         );
    434 | 
    435 |         // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
>>  436 |         (bool success, ) = recipient.call{value: amount}("");
    437 |         require(
    438 |             success,
    439 |             "Address: unable to send value, recipient may have reverted"
```

---

### 2. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 526 行
- **函数**: `functionCallWithValue()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    523 |         require(isContract(target), "Address: call to non-contract");
    524 | 
    525 |         // solhint-disable-next-line avoid-low-level-calls
>>  526 |         (bool success, bytes memory returndata) = target.call{value: value}(
    527 |             data
    528 |         );
    529 |         return _verifyCallResult(success, returndata, errorMessage);
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 953 行
- **函数**: `multiTransfer_OST()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    950 | 
    951 |             // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
    952 |             /*(success, ) = */
>>  953 |             _addresses[i].call{value: _amounts[i]}("");
    954 |             // we do not care. caller should check sending results manually and re-send if needed.
    955 |         }
    956 |         return true;
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 977 行
- **函数**: `transfer2()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    974 | 
    975 |         // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
    976 |         /*(success, ) = */
>>  977 |         _address1.call{value: _amount1}("");
    978 | 
    979 |         // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
    980 |         /*(success, ) = */
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 981 行
- **函数**: `transfer2()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    978 | 
    979 |         // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
    980 |         /*(success, ) = */
>>  981 |         _address2.call{value: _amount2}("");
    982 | 
    983 |         return true;
    984 |     }
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1024 行
- **函数**: `multiTransferEqual_L1R()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1021 |         for (uint16 i; i < _addresses.length; i++) {
   1022 |             // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
   1023 |             /*(success, ) = */
>> 1024 |             _addresses[i].call{value: _amount}("");
   1025 |             // we do not care. caller should check sending results manually and re-send if needed.
   1026 |         }
   1027 |         return true;
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1184 行
- **函数**: `multiTransferTokenEther()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1181 | 
   1182 |             // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
   1183 |             /*(success, ) = */
>> 1184 |             _addresses[i].call{value: _amountsEther[i]}("");
   1185 |             // we do not care. caller should check sending results manually and re-send if needed.
   1186 |         }
   1187 |     }
```

---

### 8. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1240 行
- **函数**: `multiTransferTokenEtherEqual()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1237 | 
   1238 |             // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
   1239 |             /*(success, ) = */
>> 1240 |             _addresses[i].call{value: _amountEther}("");
   1241 |             // we do not care. caller should check sending results manually and re-send if needed.
   1242 |         }
   1243 |     }
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 65 行
- **函数**: `paused()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     62 |     /**
     63 |      * @dev Returns true if the contract is paused, and false otherwise.
     64 |      */
>>   65 |     function paused() public view returns (bool) {
     66 |         return _paused;
     67 |     }
     68 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 127 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    124 |     /**
    125 |      * @dev Returns the amount of tokens in existence.
    126 |      */
>>  127 |     function totalSupply() external view returns (uint256);
    128 | 
    129 |     /**
    130 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 132 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    129 |     /**
    130 |      * @dev Returns the amount of tokens owned by `account`.
    131 |      */
>>  132 |     function balanceOf(address account) external view returns (uint256);
    133 | 
    134 |     /**
    135 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 171 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    168 |      *
    169 |      * Emits an {Approval} event.
    170 |      */
>>  171 |     function approve(address spender, uint256 amount) external returns (bool);
    172 | 
    173 |     /**
    174 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 754 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    751 |     /**
    752 |      * @dev Returns the address of the current owner.
    753 |      */
>>  754 |     function owner() public view returns (address) {
    755 |         return _owner;
    756 |     }
    757 | 
```

---

### 14. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 18 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     13 |  * via msg.sender and msg.data, they should not be accessed in such a direct
     14 |  * manner, since when dealing with GSN meta-transactions the account sending and
     15 |  * paying for execution may not be the actual sender (as far as an application
     16 |  * is concerned).
     17 |  *
>>   18 |  * This contract is only required for intermediate, library-like contracts.
     19 |  */
     20 | abstract contract Context {
     21 |     function _msgSender() internal view virtual returns (address payable) {
     22 |         return msg.sender;
     23 |     }
```

---

### 15. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 42 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     37 |  * This module is used through inheritance. It will make available the
     38 |  * modifiers `whenNotPaused` and `whenPaused`, which can be applied to
     39 |  * the functions of your contract. Note that they will not be pausable by
     40 |  * simply including this module, only once the modifiers are put in place.
     41 |  */
>>   42 | abstract contract Pausable is Context {
     43 |     /**
     44 |      * @dev Emitted when the pause is triggered by `account`.
     45 |      */
     46 |     event Paused(address account);
     47 | 
```

---

### 16. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 598 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    593 | // File: @openzeppelin/contracts/token/ERC20/SafeERC20.sol
    594 | 
    595 | /**
    596 |  * @title SafeERC20
    597 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>>  598 |  * contract returns false). Tokens that return no value (and instead revert or
    599 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    600 |  * successful.
    601 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    602 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    603 |  */
```

---

### 17. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 734 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    729 |  *
    730 |  * This module is used through inheritance. It will make available the modifier
    731 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    732 |  * the owner.
    733 |  */
>>  734 | abstract contract Ownable is Context {
    735 |     address private _owner;
    736 | 
    737 |     event OwnershipTransferred(
    738 |         address indexed previousOwner,
    739 |         address indexed newOwner
```

---

### 18. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 832 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    827 |     constructor() internal {
    828 |         _status = _NOT_ENTERED;
    829 |     }
    830 | 
    831 |     /**
>>  832 |      * @dev Prevents a contract from calling itself, directly or indirectly.
    833 |      * Calling a `nonReentrant` function from another `nonReentrant`
    834 |      * function is not supported. It is possible to prevent this from happening
    835 |      * by making the `nonReentrant` function external, and make it call a
    836 |      * `private` function that does the actual work.
    837 |      */
```

---

### 19. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 878 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    873 | 
    874 | */
    875 | 
    876 | /// @dev Creates an escape hatch function that can be called in an
    877 | ///  emergency that will allow designated addresses to send any ether or tokens
>>  878 | ///  held in the contract to an `escapeHatchDestination`
    879 | contract Escapable is Ownable, ReentrancyGuard {
    880 |     using SafeERC20 for IERC20;
    881 | 
    882 |     /// @notice The `escapeHatch()` should only be called as a last resort if a
    883 |     /// security issue is uncovered or something unexpected happened
```

---

### 20. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 933 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    928 | 
    929 | 
    930 | */
    931 | 
    932 | /// @notice Transfer Ether to multiple addresses
>>  933 | contract MultiTransfer is Pausable {
    934 |     using SafeMath for uint256;
    935 | 
    936 |     /// @notice Send to multiple addresses using two arrays which
    937 |     ///  includes the address and the amount.
    938 |     ///  Payable
```

---

### 21. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1010 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1005 | 
   1006 | 
   1007 | */
   1008 | 
   1009 | /// @notice Transfer equal Ether amount to multiple addresses
>> 1010 | contract MultiTransferEqual is Pausable {
   1011 |     /// @notice Send equal Ether amount to multiple addresses.
   1012 |     ///  Payable
   1013 |     /// @param _addresses Array of addresses to send to
   1014 |     /// @param _amount Amount to send
   1015 |     function multiTransferEqual_L1R(
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1054 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1049 | 
   1050 | 
   1051 | */
   1052 | 
   1053 | /// @notice Transfer tokens to multiple addresses
>> 1054 | contract MultiTransferToken is Pausable {
   1055 |     using SafeMath for uint256;
   1056 |     using SafeERC20 for IERC20;
   1057 | 
   1058 |     /// @notice Send ERC20 tokens to multiple addresses
   1059 |     ///  using two arrays which includes the address and the amount.
```

---

### 23. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1105 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1100 | 
   1101 | 
   1102 | */
   1103 | 
   1104 | /// @notice Transfer equal tokens amount to multiple addresses
>> 1105 | contract MultiTransferTokenEqual is Pausable {
   1106 |     using SafeMath for uint256;
   1107 |     using SafeERC20 for IERC20;
   1108 | 
   1109 |     /// @notice Send equal ERC20 tokens amount to multiple contracts
   1110 |     ///
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1152 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1147 | 
   1148 | 
   1149 | */
   1150 | 
   1151 | /// @notice Transfer tokens and Ether to multiple addresses in one call
>> 1152 | contract MultiTransferTokenEther is Pausable {
   1153 |     using SafeMath for uint256;
   1154 |     using SafeERC20 for IERC20;
   1155 | 
   1156 |     /// @notice Send ERC20 tokens and Ether to multiple addresses
   1157 |     ///  using three arrays which includes the address and the amounts.
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1213 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1208 | 
   1209 | 
   1210 | */
   1211 | 
   1212 | /// @notice Transfer equal amounts of tokens and Ether to multiple addresses in one call
>> 1213 | contract MultiTransferTokenEtherEqual is Pausable {
   1214 |     using SafeMath for uint256;
   1215 |     using SafeERC20 for IERC20;
   1216 | 
   1217 |     /// @notice Send equal ERC20 tokens amount to multiple addresses
   1218 |     ///
```

---

### 26. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 896 行
- **函数**: `escapeHatch()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    893 |         /// @dev Logic for ether
    894 |         if (_token == address(0x0)) {
    895 |             balance = address(this).balance;
>>  896 |             _escapeHatchDestination.transfer(balance);
    897 |             EscapeHatchCalled(_token, balance);
    898 |             return;
    899 |         }
```

---

### 27. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1077 行
- **函数**: `multiTransferToken_a4A()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1074 |         token.safeTransferFrom(msg.sender, address(this), _amountSum);
   1075 |         for (uint16 i; i < _addresses.length; i++) {
   1076 |             _amountSum = _amountSum.sub(_amounts[i]);
>> 1077 |             token.transfer(_addresses[i], _amounts[i]);
   1078 |         }
   1079 |     }
   1080 | }
```

---

### 28. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1124 行
- **函数**: `multiTransferTokenEqual_71p()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1121 |         IERC20 token = IERC20(_token);
   1122 |         token.safeTransferFrom(msg.sender, address(this), _amountSum);
   1123 |         for (uint16 i; i < _addresses.length; i++) {
>> 1124 |             token.transfer(_addresses[i], _amount);
   1125 |         }
   1126 |     }
   1127 | }
```

---

### 29. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1180 行
- **函数**: `multiTransferTokenEther()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1177 |         for (uint16 i; i < _addresses.length; i++) {
   1178 |             _amountSum = _amountSum.sub(_amounts[i]);
   1179 |             _value = _value.sub(_amountsEther[i]);
>> 1180 |             token.transfer(_addresses[i], _amounts[i]);
   1181 | 
   1182 |             // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
   1183 |             /*(success, ) = */
```

---

### 30. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 1236 行
- **函数**: `multiTransferTokenEtherEqual()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1233 |         IERC20 token = IERC20(_token);
   1234 |         token.safeTransferFrom(msg.sender, address(this), _amountSum);
   1235 |         for (uint16 i; i < _addresses.length; i++) {
>> 1236 |             token.transfer(_addresses[i], _amount);
   1237 | 
   1238 |             // solhint-disable-next-line avoid-low-level-calls, avoid-call-value
   1239 |             /*(success, ) = */
```

---

### 31. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 407 行
- **函数**: `isContract()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    404 | 
    405 |         uint256 size;
    406 |         // solhint-disable-next-line no-inline-assembly
>>  407 |         assembly {
    408 |             size := extcodesize(account)
    409 |         }
    410 |         return size > 0;
```

---

### 32. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xBCd841ee7B34d92c82D4346c05BF23120d3D4930` 第 582 行
- **函数**: `_verifyCallResult()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    579 |                 // The easiest way to bubble the revert reason is using memory via assembly
    580 | 
    581 |                 // solhint-disable-next-line no-inline-assembly
>>  582 |                 assembly {
    583 |                     let returndata_size := mload(returndata)
    584 |                     revert(add(32, returndata), returndata_size)
    585 |                 }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*