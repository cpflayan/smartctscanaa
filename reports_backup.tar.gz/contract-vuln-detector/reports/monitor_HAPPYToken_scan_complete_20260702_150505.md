# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:05:05
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` |
| contract_name | `HAPPYToken` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655007` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 50 |
| 🟢 LOW | 21 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2477 行
- **函数**: `getReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2474 | 
   2475 | interface IPancakePair {
   2476 |     function sync() external;
>> 2477 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2478 |     function token0() external view returns (address);
   2479 |     function token1() external view returns (address);
   2480 |     function totalSupply() external view returns (uint256);
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 28 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     25 |     /**
     26 |      * @dev Returns the value of tokens in existence.
     27 |      */
>>   28 |     function totalSupply() external view returns (uint256);
     29 | 
     30 |     /**
     31 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 33 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     30 |     /**
     31 |      * @dev Returns the value of tokens owned by `account`.
     32 |      */
>>   33 |     function balanceOf(address account) external view returns (uint256);
     34 | 
     35 |     /**
     36 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 42 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     39 |      *
     40 |      * Emits a {Transfer} event.
     41 |      */
>>   42 |     function transfer(address to, uint256 value) external returns (bool);
     43 | 
     44 |     /**
     45 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 51 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     48 |      *
     49 |      * This value changes when {approve} or {transferFrom} are called.
     50 |      */
>>   51 |     function allowance(address owner, address spender) external view returns (uint256);
     52 | 
     53 |     /**
     54 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 68 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     65 |      *
     66 |      * Emits an {Approval} event.
     67 |      */
>>   68 |     function approve(address spender, uint256 value) external returns (bool);
     69 | 
     70 |     /**
     71 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 79 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     76 |      *
     77 |      * Emits a {Transfer} event.
     78 |      */
>>   79 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
     80 | }
     81 | 
     82 | // File: @openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 97 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     94 |     /**
     95 |      * @dev Returns the name of the token.
     96 |      */
>>   97 |     function name() external view returns (string memory);
     98 | 
     99 |     /**
    100 |      * @dev Returns the symbol of the token.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 102 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     99 |     /**
    100 |      * @dev Returns the symbol of the token.
    101 |      */
>>  102 |     function symbol() external view returns (string memory);
    103 | 
    104 |     /**
    105 |      * @dev Returns the decimals places of the token.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 107 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    104 |     /**
    105 |      * @dev Returns the decimals places of the token.
    106 |      */
>>  107 |     function decimals() external view returns (uint8);
    108 | }
    109 | 
    110 | // File: @openzeppelin/contracts/utils/Context.sol
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 354 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    351 |     /**
    352 |      * @dev Returns the name of the token.
    353 |      */
>>  354 |     function name() public view virtual returns (string memory) {
    355 |         return _name;
    356 |     }
    357 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 362 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    359 |      * @dev Returns the symbol of the token, usually a shorter version of the
    360 |      * name.
    361 |      */
>>  362 |     function symbol() public view virtual returns (string memory) {
    363 |         return _symbol;
    364 |     }
    365 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 379 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    376 |      * no way affects any of the arithmetic of the contract, including
    377 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    378 |      */
>>  379 |     function decimals() public view virtual returns (uint8) {
    380 |         return 18;
    381 |     }
    382 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 384 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    381 |     }
    382 | 
    383 |     /// @inheritdoc IERC20
>>  384 |     function totalSupply() public view virtual returns (uint256) {
    385 |         return _totalSupply;
    386 |     }
    387 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 389 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    386 |     }
    387 | 
    388 |     /// @inheritdoc IERC20
>>  389 |     function balanceOf(address account) public view virtual returns (uint256) {
    390 |         return _balances[account];
    391 |     }
    392 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 401 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    398 |      * - `to` cannot be the zero address.
    399 |      * - the caller must have a balance of at least `value`.
    400 |      */
>>  401 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    402 |         address owner = _msgSender();
    403 |         _transfer(owner, to, value);
    404 |         return true;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 408 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    405 |     }
    406 | 
    407 |     /// @inheritdoc IERC20
>>  408 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    409 |         return _allowances[owner][spender];
    410 |     }
    411 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 422 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    419 |      *
    420 |      * - `spender` cannot be the zero address.
    421 |      */
>>  422 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    423 |         address owner = _msgSender();
    424 |         _approve(owner, spender, value);
    425 |         return true;
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 444 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    441 |      * - the caller must have allowance for ``from``'s tokens of at least
    442 |      * `value`.
    443 |      */
>>  444 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    445 |         address spender = _msgSender();
    446 |         _spendAllowance(from, spender, value);
    447 |         _transfer(from, to, value);
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 665 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    662 |     /**
    663 |      * @dev Returns the address of the current owner.
    664 |      */
>>  665 |     function owner() public view virtual returns (address) {
    666 |         return _owner;
    667 |     }
    668 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 927 行
- **函数**: `getHourlyCycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    924 |     /**
    925 |      * @notice 获取当前周期（用于静态奖励和底池燃烧）
    926 |      */
>>  927 |     function getHourlyCycle() public view returns (uint256) {
    928 |         return (block.timestamp - launchTime) / 1 hours;
    929 |     }
    930 |     
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 934 行
- **函数**: `getDailyCycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    931 |     /**
    932 |      * @notice 获取当前周期（用于动态奖励和节点奖励
    933 |      */
>>  934 |     function getDailyCycle() public view returns (uint256) {
    935 |         return (block.timestamp - launchTime) / 1 days;
    936 |     }
    937 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 1487 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1484 |     /**
   1485 |      * @notice 重写余额查询方法（显示虚拟余额：实际余额 + 待领取奖励）
   1486 |      */
>> 1487 |     function balanceOf(address account) public view override returns (uint256) {
   1488 |         uint256 actualBalance = super.balanceOf(account);
   1489 |         (uint256 staticReward,) = ITokenExt(tokenExt)._calculateStaticReward(account);
   1490 |         uint256 dynamicReward = ITokenExt(tokenExt)._calculateDynamicReward(account);
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 1497 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1494 |     /**
   1495 |      * @notice 重写转账函数
   1496 |      */
>> 1497 |     function transfer(address to, uint256 amount) public override returns (bool) {
   1498 |         return _transferWithLogic(msg.sender, to, amount);
   1499 |     }
   1500 |     
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 1504 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1501 |     /**
   1502 |      * @notice 重写授权转账函数
   1503 |      */
>> 1504 |     function transferFrom(address from, address to, uint256 amount) public override returns (bool) {
   1505 |         address spender = msg.sender;
   1506 |         _spendAllowance(from, spender, amount);
   1507 |         
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2435 行
- **函数**: `factory()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2432 | // ============ 接口定义 ============
   2433 | 
   2434 | interface IPancakeRouter {
>> 2435 |     function factory() external pure returns (address);
   2436 |     function getAmountsOut(uint256 amountIn, address[] calldata path) external view returns (uint256[] memory amounts);
   2437 |     function addLiquidity(
   2438 |         address tokenA,
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2436 行
- **函数**: `getAmountsOut()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2433 | 
   2434 | interface IPancakeRouter {
   2435 |     function factory() external pure returns (address);
>> 2436 |     function getAmountsOut(uint256 amountIn, address[] calldata path) external view returns (uint256[] memory amounts);
   2437 |     function addLiquidity(
   2438 |         address tokenA,
   2439 |         address tokenB,
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2472 行
- **函数**: `createPair()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2469 | }
   2470 | 
   2471 | interface IPancakeFactory {
>> 2472 |     function createPair(address tokenA, address tokenB) external returns (address pair);
   2473 | }
   2474 | 
   2475 | interface IPancakePair {
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2477 行
- **函数**: `getReserves()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2474 | 
   2475 | interface IPancakePair {
   2476 |     function sync() external;
>> 2477 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2478 |     function token0() external view returns (address);
   2479 |     function token1() external view returns (address);
   2480 |     function totalSupply() external view returns (uint256);
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2478 行
- **函数**: `token0()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2475 | interface IPancakePair {
   2476 |     function sync() external;
   2477 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>> 2478 |     function token0() external view returns (address);
   2479 |     function token1() external view returns (address);
   2480 |     function totalSupply() external view returns (uint256);
   2481 | }
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2479 行
- **函数**: `token1()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2476 |     function sync() external;
   2477 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2478 |     function token0() external view returns (address);
>> 2479 |     function token1() external view returns (address);
   2480 |     function totalSupply() external view returns (uint256);
   2481 | }
   2482 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2480 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2477 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2478 |     function token0() external view returns (address);
   2479 |     function token1() external view returns (address);
>> 2480 |     function totalSupply() external view returns (uint256);
   2481 | }
   2482 | 
   2483 | interface IFeeSwapper {
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2484 行
- **函数**: `swapHAPPYForWBNB()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2481 | }
   2482 | 
   2483 | interface IFeeSwapper {
>> 2484 |     function swapHAPPYForWBNB(uint256 happyAmount) external returns (uint256);
   2485 |     function _getWBNBAmountOut(uint256 amountIn) external view returns(uint256);
   2486 |     function getHAPPYBalance()external view returns(uint256);
   2487 |     function _getHAPPYAmountOut(uint256 amountIn) external view returns(uint256);
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2485 行
- **函数**: `_getWBNBAmountOut()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2482 | 
   2483 | interface IFeeSwapper {
   2484 |     function swapHAPPYForWBNB(uint256 happyAmount) external returns (uint256);
>> 2485 |     function _getWBNBAmountOut(uint256 amountIn) external view returns(uint256);
   2486 |     function getHAPPYBalance()external view returns(uint256);
   2487 |     function _getHAPPYAmountOut(uint256 amountIn) external view returns(uint256);
   2488 |     function _getHAPPYAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2487 行
- **函数**: `_getHAPPYAmountOut()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2484 |     function swapHAPPYForWBNB(uint256 happyAmount) external returns (uint256);
   2485 |     function _getWBNBAmountOut(uint256 amountIn) external view returns(uint256);
   2486 |     function getHAPPYBalance()external view returns(uint256);
>> 2487 |     function _getHAPPYAmountOut(uint256 amountIn) external view returns(uint256);
   2488 |     function _getHAPPYAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
   2489 |     function transferToken(address token, address to, uint256 amount) external returns (bool);
   2490 |     function earleirUser(address user) external view returns(bool);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2488 行
- **函数**: `_getHAPPYAmountOutOfUSDT()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2485 |     function _getWBNBAmountOut(uint256 amountIn) external view returns(uint256);
   2486 |     function getHAPPYBalance()external view returns(uint256);
   2487 |     function _getHAPPYAmountOut(uint256 amountIn) external view returns(uint256);
>> 2488 |     function _getHAPPYAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
   2489 |     function transferToken(address token, address to, uint256 amount) external returns (bool);
   2490 |     function earleirUser(address user) external view returns(bool);
   2491 | }
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2489 行
- **函数**: `transferToken()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2486 |     function getHAPPYBalance()external view returns(uint256);
   2487 |     function _getHAPPYAmountOut(uint256 amountIn) external view returns(uint256);
   2488 |     function _getHAPPYAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
>> 2489 |     function transferToken(address token, address to, uint256 amount) external returns (bool);
   2490 |     function earleirUser(address user) external view returns(bool);
   2491 | }
   2492 | interface IWETH {
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2490 行
- **函数**: `earleirUser()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2487 |     function _getHAPPYAmountOut(uint256 amountIn) external view returns(uint256);
   2488 |     function _getHAPPYAmountOutOfUSDT(uint256 amountIn) external view returns(uint256);
   2489 |     function transferToken(address token, address to, uint256 amount) external returns (bool);
>> 2490 |     function earleirUser(address user) external view returns(bool);
   2491 | }
   2492 | interface IWETH {
   2493 |     function deposit() external payable;
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2493 行
- **函数**: `deposit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2490 |     function earleirUser(address user) external view returns(bool);
   2491 | }
   2492 | interface IWETH {
>> 2493 |     function deposit() external payable;
   2494 |     function withdraw(uint256 amount) external;
   2495 | }
   2496 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2498 行
- **函数**: `_calculateBurnRate()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2495 | }
   2496 | 
   2497 | interface ITokenExt{
>> 2498 |     function _calculateBurnRate() external view returns (uint256);
   2499 |     function _simulateNodeHAPPYRewardsWithBalance(
   2500 |         uint256 poolBalance
   2501 |     ) external view returns (uint256[10] memory nodeRewards, uint256 newPoolBalance);
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2502 行
- **函数**: `_calculateStaticReward()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2499 |     function _simulateNodeHAPPYRewardsWithBalance(
   2500 |         uint256 poolBalance
   2501 |     ) external view returns (uint256[10] memory nodeRewards, uint256 newPoolBalance);
>> 2502 |     function _calculateStaticReward(address user) external view returns (uint256,uint256);
   2503 |     function _calculateDynamicReward(address user) external view returns (uint256);
   2504 |     function _calculateNodeWBNBReward(address user) external view returns (uint256);
   2505 |     function _calculateNodeHAPPYReward(address user) external view returns (uint256);
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2503 行
- **函数**: `_calculateDynamicReward()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2500 |         uint256 poolBalance
   2501 |     ) external view returns (uint256[10] memory nodeRewards, uint256 newPoolBalance);
   2502 |     function _calculateStaticReward(address user) external view returns (uint256,uint256);
>> 2503 |     function _calculateDynamicReward(address user) external view returns (uint256);
   2504 |     function _calculateNodeWBNBReward(address user) external view returns (uint256);
   2505 |     function _calculateNodeHAPPYReward(address user) external view returns (uint256);
   2506 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2504 行
- **函数**: `_calculateNodeWBNBReward()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2501 |     ) external view returns (uint256[10] memory nodeRewards, uint256 newPoolBalance);
   2502 |     function _calculateStaticReward(address user) external view returns (uint256,uint256);
   2503 |     function _calculateDynamicReward(address user) external view returns (uint256);
>> 2504 |     function _calculateNodeWBNBReward(address user) external view returns (uint256);
   2505 |     function _calculateNodeHAPPYReward(address user) external view returns (uint256);
   2506 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
   2507 |     function _gethighPrice(uint256 currentCycle)external view returns(uint256 highPrice);
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2505 行
- **函数**: `_calculateNodeHAPPYReward()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2502 |     function _calculateStaticReward(address user) external view returns (uint256,uint256);
   2503 |     function _calculateDynamicReward(address user) external view returns (uint256);
   2504 |     function _calculateNodeWBNBReward(address user) external view returns (uint256);
>> 2505 |     function _calculateNodeHAPPYReward(address user) external view returns (uint256);
   2506 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
   2507 |     function _gethighPrice(uint256 currentCycle)external view returns(uint256 highPrice);
   2508 |     function _buyHAPPY(uint256 bnbAmount) external returns (uint256);
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2508 行
- **函数**: `_buyHAPPY()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2505 |     function _calculateNodeHAPPYReward(address user) external view returns (uint256);
   2506 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
   2507 |     function _gethighPrice(uint256 currentCycle)external view returns(uint256 highPrice);
>> 2508 |     function _buyHAPPY(uint256 bnbAmount) external returns (uint256);
   2509 |     function _buyWBNB(uint256 happyAmount) external returns (uint256);
   2510 | }
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2509 行
- **函数**: `_buyWBNB()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2506 |     function getDay(uint256 index,uint256 currentDay)external returns(uint256);
   2507 |     function _gethighPrice(uint256 currentCycle)external view returns(uint256 highPrice);
   2508 |     function _buyHAPPY(uint256 bnbAmount) external returns (uint256);
>> 2509 |     function _buyWBNB(uint256 happyAmount) external returns (uint256);
   2510 | }
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 334 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    329 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    330 |  * instead returning `false` on failure. This behavior is nonetheless
    331 |  * conventional and does not conflict with the expectations of ERC-20
    332 |  * applications.
    333 |  */
>>  334 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    335 |     mapping(address account => uint256) private _balances;
    336 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    337 |     uint256 private _totalSupply;
    338 |     string private _name;
    339 |     string private _symbol;
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 629 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    624 |  *
    625 |  * This module is used through inheritance. It will make available the modifier
    626 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    627 |  * the owner.
    628 |  */
>>  629 | abstract contract Ownable is Context {
    630 |     address private _owner;
    631 | 
    632 |     /**
    633 |      * @dev The caller account is not authorized to perform an operation.
    634 |      */
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 701 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    696 |         }
    697 |         _transferOwnership(newOwner);
    698 |     }
    699 | 
    700 |     /**
>>  701 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    702 |      * Internal function without access restriction.
    703 |      */
    704 |     function _transferOwnership(address newOwner) internal virtual {
    705 |         address oldOwner = _owner;
    706 |         _owner = newOwner;
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 719 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    714 | 
    715 | 
    716 | pragma solidity ^0.8.24;
    717 | 
    718 | 
>>  719 | contract HAPPYToken is ERC20,Ownable {
    720 |     
    721 |     // ============ 常量定义 ============
    722 |     address public tokenExt; //代币逻辑扩展合约
    723 |     address public feeSwapper;  // 手续费兑换合约地址
    724 |     
```

---

### 51. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 928 行
- **函数**: `getHourlyCycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    925 |      * @notice 获取当前周期（用于静态奖励和底池燃烧）
    926 |      */
    927 |     function getHourlyCycle() public view returns (uint256) {
>>  928 |         return (block.timestamp - launchTime) / 1 hours;
    929 |     }
    930 |     
    931 |     /**
```

---

### 52. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 935 行
- **函数**: `getDailyCycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    932 |      * @notice 获取当前周期（用于动态奖励和节点奖励
    933 |      */
    934 |     function getDailyCycle() public view returns (uint256) {
>>  935 |         return (block.timestamp - launchTime) / 1 days;
    936 |     }
    937 | 
    938 |     function setFeeSwapper(address _feeSwapper) public  onlyOwner(){
```

---

### 53. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 979 行
- **函数**: `_trySwapFees()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    976 |         require(users[msg.sender].superior != address(0), "Mb");//Must bind referrer
    977 |         require(pancakePair != address(0), "Ni");//Not initialized
    978 | 
>>  979 |         if(block.timestamp>=1777006800 && launchTime == 0){
    980 |             launchTime = block.timestamp / 1 hours * 1 hours;
    981 |         }
    982 |         require(launchTime>0,"Waiting");
```

---

### 54. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 980 行
- **函数**: `_trySwapFees()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    977 |         require(pancakePair != address(0), "Ni");//Not initialized
    978 | 
    979 |         if(block.timestamp>=1777006800 && launchTime == 0){
>>  980 |             launchTime = block.timestamp / 1 hours * 1 hours;
    981 |         }
    982 |         require(launchTime>0,"Waiting");
    983 |         //更新周期数据（必须在 swap 之前，避免在 swap 过程中重复调用）
```

---

### 55. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 997 行
- **函数**: `_queuetoDeposit()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    994 |         // 1. 检查是否已经入金过
    995 |         require(!hasDeposited[user], "oo"); // Address can only deposit once
    996 |         hasDeposited[user] = true;
>>  997 |         lastBNBDepositTime = block.timestamp;
    998 |         
    999 |         // 2. 检查是否是出局但有动态算力的用户（特权用户）
   1000 |         bool isPrivilegedUser = users[user].hashrateDynamic > 0 && users[user].hashrateStatic == 0;
```

---

### 56. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 1309 行
- **函数**: `_redeem()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1306 |             0,                 // 🔥 最小HAPPY数量（5%滑点保护）
   1307 |             0,                // 🔥 最小WBNB数量（5%滑点保护）
   1308 |             feeSwapper,             // 代币先到feeSwapper中间合约
>> 1309 |             block.timestamp + 300   // 5分钟有效期
   1310 |         );
   1311 |         
   1312 |         // 9. 从feeSwapper将HAPPY转移到合约（使用_transfer内部函数）
```

---

### 57. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 1626 行
- **函数**: `_updateCycle()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1623 |      * @dev 回溯补齐所有缺失的周期，使用历史算力，避免复利燃烧
   1624 |      */
   1625 |     function _updateCycle() internal returns(uint256 currentHour,uint256 currentDay){
>> 1626 |         if (lastBNBDepositTime != 0 && block.timestamp - lastBNBDepositTime >= 86400 && reservedPool>0) {
   1627 |             uint len = usersQueue.length - 1;
   1628 |             _transferWBNB(usersQueue[len].user, (reservedPool  * 50) / 100);
   1629 |             _transferWBNB(usersQueue[len-1].user, (reservedPool  * 30) / 100);
```

---

### 58. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2398 行
- **函数**: `_addLiquidity()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   2395 |             0,                      // amountAMin: HAPPY最小数量
   2396 |             0,                      // amountBMin: WBNB最小数量
   2397 |             lpReceiver,             // to: LP代币接收地址（改为用户地址）
>> 2398 |             block.timestamp + 300   // deadline: 截止时间
   2399 |         );
   2400 |         
   2401 |         return (usedHAPPY, usedWBNB, liquidity);
```

---

### 59. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 1139 行
- **函数**: `_processBuildLP()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1136 |         uint256 buyHAPPYAmount = lpbnb / 2;  // 25% 的总金额
   1137 |         
   1138 |         // 用 wbnb 在 PancakeSwap 上购买 HAPPY 代币
>> 1139 |         IERC20(WBNB).transfer(tokenExt, buyHAPPYAmount);
   1140 |         uint256 happyAmount = ITokenExt(tokenExt)._buyHAPPY(buyHAPPYAmount);
   1141 |         // 转回合约
   1142 |         _transfer(tokenExt, address(this), happyAmount);
```

---

### 60. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 2406 行
- **函数**: `_transferWBNB()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   2403 |     
   2404 |     function _transferWBNB(address to, uint256 amount) internal {
   2405 |         if (amount > 0) {
>> 2406 |             IERC20(WBNB).transfer(to, amount);
   2407 |         }
   2408 |     }
   2409 |     
```

---

### 61. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 726 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    723 |     address public feeSwapper;  // 手续费兑换合约地址
    724 |     
    725 |     /// @notice 黑洞地址，用于接收销毁的代币
>>  726 |     address public constant DEAD = 0x000000000000000000000000000000000000dEaD;
    727 | 
    728 |     /// @notice 基础比例分母
    729 |     uint256 private constant BASE = 100000;
```

---

### 62. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 735 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    732 | 
    733 |     // ============ DEX 相关 ============
    734 |     /// @notice PancakeSwap Router V2 (BSC Mainnet)
>>  735 |     address public constant ROUTER = 0x10ED43C718714eb63d5aA57B78B54704E256024E;
    736 |     
    737 |     /// @notice USDT 代币地址 (BSC)
    738 |     address public constant USDT = 0x55d398326f99059fF775485246999027B3197955;
```

---

### 63. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 738 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    735 |     address public constant ROUTER = 0x10ED43C718714eb63d5aA57B78B54704E256024E;
    736 |     
    737 |     /// @notice USDT 代币地址 (BSC)
>>  738 |     address public constant USDT = 0x55d398326f99059fF775485246999027B3197955;
    739 |     
    740 |     /// @notice WBNB 代币地址 (BSC)
    741 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
```

---

### 64. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 741 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    738 |     address public constant USDT = 0x55d398326f99059fF775485246999027B3197955;
    739 |     
    740 |     /// @notice WBNB 代币地址 (BSC)
>>  741 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
    742 |         
    743 |     /// @notice HAPPY-WBNB LP 池地址
    744 |     address public pancakePair;
```

---

### 65. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 747 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    744 |     address public pancakePair;
    745 | 
    746 |     /// @notice 初始上级地址（创世推荐人）
>>  747 |     address public constant INITIAL_SUPERIOR = 0xf53b02226abFe7037877a4Cf6F1A5f267C09C1B2;
    748 | 
    749 |     // ============ 地址配置 ============
    750 |     /// @notice 白名单地址
```

---

### 66. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 751 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    748 | 
    749 |     // ============ 地址配置 ============
    750 |     /// @notice 白名单地址
>>  751 |     address public constant baiAddress = 0x2126922dAe8F4d06a2c6Fdd1C59E5E49f5580232;
    752 | 
    753 |     /// @notice 归集地址
    754 |     address public constant guijiAddress = 0x5B63143C4e90bA2B0500bB5B7Ced530E03c3e6e0;
```

---

### 67. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 754 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    751 |     address public constant baiAddress = 0x2126922dAe8F4d06a2c6Fdd1C59E5E49f5580232;
    752 | 
    753 |     /// @notice 归集地址
>>  754 |     address public constant guijiAddress = 0x5B63143C4e90bA2B0500bB5B7Ced530E03c3e6e0;
    755 | 
    756 |     address public constant techAddress = 0x2126922dAe8F4d06a2c6Fdd1C59E5E49f5580232;
    757 |     // 伯乐地址 (1%)
```

---

### 68. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 756 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    753 |     /// @notice 归集地址
    754 |     address public constant guijiAddress = 0x5B63143C4e90bA2B0500bB5B7Ced530E03c3e6e0;
    755 | 
>>  756 |     address public constant techAddress = 0x2126922dAe8F4d06a2c6Fdd1C59E5E49f5580232;
    757 |     // 伯乐地址 (1%)
    758 |     address public constant BOLE_ADDRESS = 0x1277305dA6A2c8beE75C3c5b85a1055887F68D0E;
    759 |     // SwapPool 地址 (3%)
```

---

### 69. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 758 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    755 | 
    756 |     address public constant techAddress = 0x2126922dAe8F4d06a2c6Fdd1C59E5E49f5580232;
    757 |     // 伯乐地址 (1%)
>>  758 |     address public constant BOLE_ADDRESS = 0x1277305dA6A2c8beE75C3c5b85a1055887F68D0E;
    759 |     // SwapPool 地址 (3%)
    760 |     address public constant SWAP_POOL_ADDRESS = 0xe615066906583cf628A4f5ADeb94985246E3DEad;   
    761 |     // 社区地址 (0.5%)
```

---

### 70. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 760 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    757 |     // 伯乐地址 (1%)
    758 |     address public constant BOLE_ADDRESS = 0x1277305dA6A2c8beE75C3c5b85a1055887F68D0E;
    759 |     // SwapPool 地址 (3%)
>>  760 |     address public constant SWAP_POOL_ADDRESS = 0xe615066906583cf628A4f5ADeb94985246E3DEad;   
    761 |     // 社区地址 (0.5%)
    762 |     address public constant COMMUNITY_ADDRESS = 0xBeB32e79aa8D50D2A22F598b15F270377d0A4997;
    763 |     // 最后入金时间戳
```

---

### 71. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x04Eb096AD2aE6132fA55c3f4A2d349cc9d8E1313` 第 762 行
- **函数**: `_transferOwnership()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    759 |     // SwapPool 地址 (3%)
    760 |     address public constant SWAP_POOL_ADDRESS = 0xe615066906583cf628A4f5ADeb94985246E3DEad;   
    761 |     // 社区地址 (0.5%)
>>  762 |     address public constant COMMUNITY_ADDRESS = 0xBeB32e79aa8D50D2A22F598b15F270377d0A4997;
    763 |     // 最后入金时间戳
    764 |     uint256 public lastBNBDepositTime;   
    765 |     // 预留资金池 (0.5% 累积，用于最后 3 个入金平均分配)
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*