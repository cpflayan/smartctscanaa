# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:11:07
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` |
| contract_name | `TokenMessaging` |
| compiler_version | `v0.8.22+commit.4fc1097e` |
| optimization_used | `True` |
| runs | `5000` |
| evm_version | `paris` |
| license_type | `BSL 1.1` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@layerzerolabs/lz-evm-oapp-v2/contracts/oapp/OApp.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/oapp/OAppCore.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/oapp/OAppReceiver.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/oapp/OAppSender.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/oapp/interfaces/IOAppCore.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/oapp/interfaces/IOAppOptionsType3.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/oapp/interfaces/IOAppReceiver.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/oapp/libs/OAppOptionsType3.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/oft/interfaces/IOFT.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/precrime/OAppPreCrimeSimulator.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/precrime/interfaces/IOAppPreCrimeSimulator.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/precrime/interfaces/IPreCrime.sol', '@layerzerolabs/lz-evm-oapp-v2/contracts/precrime/libs/Packet.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/ILayerZeroEndpointV2.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/ILayerZeroReceiver.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessageLib.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessageLibManager.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessagingChannel.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessagingComposer.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/IMessagingContext.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/interfaces/ISendLib.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/libs/AddressCast.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/libs/Errors.sol', '@layerzerolabs/lz-evm-protocol-v2/contracts/messagelib/libs/PacketV1Codec.sol', '@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/utils/SafeERC20.sol', '@openzeppelin/contracts/utils/Address.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/utils/introspection/IERC165.sol', '@openzeppelin/contracts/utils/math/SafeCast.sol', 'src/interfaces/IStargate.sol', 'src/interfaces/ITokenMessaging.sol', 'src/interfaces/ITokenMessagingHandler.sol', 'src/libs/AddressCast.sol', 'src/libs/Bus.sol', 'src/libs/BusCodec.sol', 'src/libs/TaxiCodec.sol', 'src/libs/Transfer.sol', 'src/messaging/MessagingBase.sol', 'src/messaging/TokenMessaging.sol', 'src/messaging/TokenMessagingOptions.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655008` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 82 |
| 🟢 LOW | 4 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 2226 行
- **函数**: `functionDelegateCall()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   2223 |         bytes memory data,
   2224 |         string memory errorMessage
   2225 |     ) internal returns (bytes memory) {
>> 2226 |         (bool success, bytes memory returndata) = target.delegatecall(data);
   2227 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
   2228 |     }
   2229 | 
```

---

### 2. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 2033 行
- **函数**: `_callOptionalReturnBool()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   2030 |         // we're implementing it ourselves. We cannot use {Address-functionCall} here since this should return false
   2031 |         // and not revert is the subcall reverts.
   2032 | 
>> 2033 |         (bool success, bytes memory returndata) = address(token).call(data);
   2034 |         return
   2035 |             success && (returndata.length == 0 || abi.decode(returndata, (bool))) && Address.isContract(address(token));
   2036 |     }
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 2108 行
- **函数**: `sendValue()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   2105 |     function sendValue(address payable recipient, uint256 amount) internal {
   2106 |         require(address(this).balance >= amount, "Address: insufficient balance");
   2107 | 
>> 2108 |         (bool success, ) = recipient.call{value: amount}("");
   2109 |         require(success, "Address: unable to send value, recipient may have reverted");
   2110 |     }
   2111 | 
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 2176 行
- **函数**: `functionCallWithValue()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   2173 |         string memory errorMessage
   2174 |     ) internal returns (bytes memory) {
   2175 |         require(address(this).balance >= value, "Address: insufficient balance for call");
>> 2176 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
   2177 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
   2178 |     }
   2179 | 
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4180 行
- **函数**: `_call()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   4177 | 
   4178 |     function _call(address _token, bytes memory _data) private returns (bool success) {
   4179 |         // solhint-disable-next-line avoid-low-level-calls
>> 4180 |         (bool s, bytes memory returndata) = _token.call(_data);
   4181 |         success = s ? returndata.length == 0 || abi.decode(returndata, (bool)) : false;
   4182 |     }
   4183 | }
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 161 行
- **函数**: `oAppVersion()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    158 |      * ie. this is a RECEIVE only OApp.
    159 |      * @dev If the OApp uses both OAppSender and OAppReceiver, then this needs to be override returning the correct versions.
    160 |      */
>>  161 |     function oAppVersion() public view virtual returns (uint64 senderVersion, uint64 receiverVersion) {
    162 |         return (0, RECEIVER_VERSION);
    163 |     }
    164 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 195 行
- **函数**: `allowInitializePath()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    192 |      * @dev This defaults to assuming if a peer has been set, its initialized.
    193 |      * Can be overridden by the OApp if there is other logic to determine this.
    194 |      */
>>  195 |     function allowInitializePath(Origin calldata origin) public view virtual returns (bool) {
    196 |         return peers[origin.srcEid] == origin.sender;
    197 |     }
    198 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 210 行
- **函数**: `nextNonce()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    207 |      * @dev This is also enforced by the OApp.
    208 |      * @dev By default this is NOT enabled. ie. nextNonce is hardcoded to return 0.
    209 |      */
>>  210 |     function nextNonce(uint32 /*_srcEid*/, bytes32 /*_sender*/) public view virtual returns (uint64 nonce) {
    211 |         return 0;
    212 |     }
    213 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 291 行
- **函数**: `oAppVersion()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    288 |      * ie. this is a SEND only OApp.
    289 |      * @dev If the OApp uses both OAppSender and OAppReceiver, then this needs to be override returning the correct versions
    290 |      */
>>  291 |     function oAppVersion() public view virtual returns (uint64 senderVersion, uint64 receiverVersion) {
    292 |         return (SENDER_VERSION, 0);
    293 |     }
    294 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 411 行
- **函数**: `oAppVersion()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    408 |      * @return senderVersion The version of the OAppSender.sol contract.
    409 |      * @return receiverVersion The version of the OAppReceiver.sol contract.
    410 |      */
>>  411 |     function oAppVersion() external view returns (uint64 senderVersion, uint64 receiverVersion);
    412 | 
    413 |     /**
    414 |      * @notice Retrieves the LayerZero endpoint associated with the OApp.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 417 行
- **函数**: `endpoint()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    414 |      * @notice Retrieves the LayerZero endpoint associated with the OApp.
    415 |      * @return iEndpoint The LayerZero endpoint as an interface.
    416 |      */
>>  417 |     function endpoint() external view returns (ILayerZeroEndpointV2 iEndpoint);
    418 | 
    419 |     /**
    420 |      * @notice Retrieves the peer (OApp) associated with a corresponding endpoint.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 424 行
- **函数**: `peers()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    421 |      * @param _eid The endpoint ID.
    422 |      * @return peer The peer address (OApp instance) associated with the corresponding endpoint.
    423 |      */
>>  424 |     function peers(uint32 _eid) external view returns (bytes32 peer);
    425 | 
    426 |     /**
    427 |      * @notice Sets the peer address (OApp instance) for a corresponding endpoint.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 703 行
- **函数**: `oftVersion()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    700 |      * @dev If a new feature is added to the OFT cross-chain msg encoding, the version will be incremented.
    701 |      * ie. localOFT version(x,1) CAN send messages to remoteOFT version(x,1)
    702 |      */
>>  703 |     function oftVersion() external view returns (bytes4 interfaceId, uint64 version);
    704 | 
    705 |     /**
    706 |      * @notice Retrieves the address of the token associated with the OFT.
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 709 行
- **函数**: `token()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    706 |      * @notice Retrieves the address of the token associated with the OFT.
    707 |      * @return token The address of the ERC20 token implementation.
    708 |      */
>>  709 |     function token() external view returns (address);
    710 | 
    711 |     /**
    712 |      * @notice Indicates whether the OFT contract requires approval of the 'token()' to send.
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 718 行
- **函数**: `approvalRequired()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    715 |      * @dev Allows things like wallet implementers to determine integration requirements,
    716 |      * without understanding the underlying token implementation.
    717 |      */
>>  718 |     function approvalRequired() external view returns (bool);
    719 | 
    720 |     /**
    721 |      * @notice Retrieves the shared decimals of the OFT.
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 724 行
- **函数**: `sharedDecimals()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    721 |      * @notice Retrieves the shared decimals of the OFT.
    722 |      * @return sharedDecimals The shared decimals of the OFT.
    723 |      */
>>  724 |     function sharedDecimals() external view returns (uint8);
    725 | 
    726 |     /**
    727 |      * @notice Provides a quote for OFT-related operations.
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 747 行
- **函数**: `quoteSend()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    744 |      *  - nativeFee: The native fee.
    745 |      *  - lzTokenFee: The lzToken fee.
    746 |      */
>>  747 |     function quoteSend(SendParam calldata _sendParam, bool _payInLzToken) external view returns (MessagingFee memory);
    748 | 
    749 |     /**
    750 |      * @notice Executes the send() operation.
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 797 行
- **函数**: `oApp()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    794 |      * @dev The simulator contract is the base contract for the OApp by default.
    795 |      * @dev If the simulator is a separate contract, override this function.
    796 |      */
>>  797 |     function oApp() external view virtual returns (address) {
    798 |         return address(this);
    799 |     }
    800 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 818 行
- **函数**: `lzReceiveAndRevert()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    815 |      * @dev Gives the preCrime implementation the ability to mock sending packets to the lzReceive function,
    816 |      * WITHOUT actually executing them.
    817 |      */
>>  818 |     function lzReceiveAndRevert(InboundPacket[] calldata _packets) public payable virtual {
    819 |         for (uint256 i = 0; i < _packets.length; i++) {
    820 |             InboundPacket calldata packet = _packets[i];
    821 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 897 行
- **函数**: `isPeer()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    894 |      * @param _peer The peer to check.
    895 |      * @return Whether the peer passed is considered 'trusted' by the OApp.
    896 |      */
>>  897 |     function isPeer(uint32 _eid, bytes32 _peer) public view virtual returns (bool);
    898 | }
    899 | 
    900 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 930 行
- **函数**: `preCrime()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    927 |      * @dev Retrieves the address of the preCrime contract implementation.
    928 |      * @return The address of the preCrime contract.
    929 |      */
>>  930 |     function preCrime() external view returns (address);
    931 | 
    932 |     /**
    933 |      * @dev Retrieves the address of the OApp contract.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 936 行
- **函数**: `oApp()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    933 |      * @dev Retrieves the address of the OApp contract.
    934 |      * @return The address of the OApp contract.
    935 |      */
>>  936 |     function oApp() external view returns (address);
    937 | 
    938 |     /**
    939 |      * @dev Sets the preCrime contract address.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 948 行
- **函数**: `lzReceiveAndRevert()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    945 |      * @dev Mocks receiving a packet, then reverts with a series of data to infer the state/result.
    946 |      * @param _packets An array of LayerZero InboundPacket objects representing received packets.
    947 |      */
>>  948 |     function lzReceiveAndRevert(InboundPacket[] calldata _packets) external payable;
    949 | 
    950 |     /**
    951 |      * @dev checks if the specified peer is considered 'trusted' by the OApp.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 956 行
- **函数**: `isPeer()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    953 |      * @param _peer The peer to check.
    954 |      * @return Whether the peer passed is considered 'trusted' by the OApp.
    955 |      */
>>  956 |     function isPeer(uint32 _eid, bytes32 _peer) external view returns (bool);
    957 | }
    958 | 
    959 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 985 行
- **函数**: `getConfig()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    982 |     error InvalidSimulationResult(uint32 eid, bytes reason);
    983 |     error CrimeFound(bytes crime);
    984 | 
>>  985 |     function getConfig(bytes[] calldata _packets, uint256[] calldata _packetMsgValues) external returns (bytes memory);
    986 | 
    987 |     function simulate(
    988 |         bytes[] calldata _packets,
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 992 行
- **函数**: `buildSimulationResult()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    989 |         uint256[] calldata _packetMsgValues
    990 |     ) external payable returns (bytes memory);
    991 | 
>>  992 |     function buildSimulationResult() external view returns (bytes memory);
    993 | 
    994 |     function preCrime(
    995 |         bytes[] calldata _packets,
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1000 行
- **函数**: `version()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    997 |         bytes[] calldata _simulations
    998 |     ) external;
    999 | 
>> 1000 |     function version() external view returns (uint64 major, uint8 minor);
   1001 | }
   1002 | 
   1003 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1132 行
- **函数**: `quote()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1129 | 
   1130 |     event LzTokenSet(address token);
   1131 | 
>> 1132 |     function quote(MessagingParams calldata _params, address _sender) external view returns (MessagingFee memory);
   1133 | 
   1134 |     function send(
   1135 |         MessagingParams calldata _params,
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1148 行
- **函数**: `executable()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1145 |         bytes32 _payloadHash
   1146 |     ) external view returns (bool);
   1147 | 
>> 1148 |     function executable(Origin calldata _origin, address _receiver) external view returns (ExecutionState);
   1149 | 
   1150 |     function lzReceive(
   1151 |         Origin calldata _origin,
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1163 行
- **函数**: `lzToken()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1160 | 
   1161 |     function setLzToken(address _lzToken) external;
   1162 | 
>> 1163 |     function lzToken() external view returns (address);
   1164 | 
   1165 |     function nativeToken() external view returns (address);
   1166 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1165 行
- **函数**: `nativeToken()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1162 | 
   1163 |     function lzToken() external view returns (address);
   1164 | 
>> 1165 |     function nativeToken() external view returns (address);
   1166 | 
   1167 |     function setDelegate(address _delegate) external;
   1168 | }
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1180 行
- **函数**: `allowInitializePath()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1177 | import { Origin } from "./ILayerZeroEndpointV2.sol";
   1178 | 
   1179 | interface ILayerZeroReceiver {
>> 1180 |     function allowInitializePath(Origin calldata _origin) external view returns (bool);
   1181 | 
   1182 |     // todo: move to OAppReceiver? it is just convention for executor. we may can change it in a new Receiver version
   1183 |     function nextNonce(uint32 _eid, bytes32 _sender) external view returns (uint64);
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1183 行
- **函数**: `nextNonce()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1180 |     function allowInitializePath(Origin calldata _origin) external view returns (bool);
   1181 | 
   1182 |     // todo: move to OAppReceiver? it is just convention for executor. we may can change it in a new Receiver version
>> 1183 |     function nextNonce(uint32 _eid, bytes32 _sender) external view returns (uint64);
   1184 | 
   1185 |     function lzReceive(
   1186 |         Origin calldata _origin,
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1214 行
- **函数**: `getConfig()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1211 | interface IMessageLib is IERC165 {
   1212 |     function setConfig(address _oapp, SetConfigParam[] calldata _config) external;
   1213 | 
>> 1214 |     function getConfig(uint32 _eid, address _oapp, uint32 _configType) external view returns (bytes memory config);
   1215 | 
   1216 |     function isSupportedEid(uint32 _eid) external view returns (bool);
   1217 | 
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1216 行
- **函数**: `isSupportedEid()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1213 | 
   1214 |     function getConfig(uint32 _eid, address _oapp, uint32 _configType) external view returns (bytes memory config);
   1215 | 
>> 1216 |     function isSupportedEid(uint32 _eid) external view returns (bool);
   1217 | 
   1218 |     // message libs of same major version are compatible
   1219 |     function version() external view returns (uint64 major, uint8 minor, uint8 endpointVersion);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1219 行
- **函数**: `version()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1216 |     function isSupportedEid(uint32 _eid) external view returns (bool);
   1217 | 
   1218 |     // message libs of same major version are compatible
>> 1219 |     function version() external view returns (uint64 major, uint8 minor, uint8 endpointVersion);
   1220 | 
   1221 |     function messageLibType() external view returns (MessageLibType);
   1222 | }
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1221 行
- **函数**: `messageLibType()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1218 |     // message libs of same major version are compatible
   1219 |     function version() external view returns (uint64 major, uint8 minor, uint8 endpointVersion);
   1220 | 
>> 1221 |     function messageLibType() external view returns (MessageLibType);
   1222 | }
   1223 | 
   1224 | 
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1253 行
- **函数**: `isRegisteredLibrary()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1250 | 
   1251 |     function registerLibrary(address _lib) external;
   1252 | 
>> 1253 |     function isRegisteredLibrary(address _lib) external view returns (bool);
   1254 | 
   1255 |     function getRegisteredLibraries() external view returns (address[] memory);
   1256 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1255 行
- **函数**: `getRegisteredLibraries()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1252 | 
   1253 |     function isRegisteredLibrary(address _lib) external view returns (bool);
   1254 | 
>> 1255 |     function getRegisteredLibraries() external view returns (address[] memory);
   1256 | 
   1257 |     function setDefaultSendLibrary(uint32 _eid, address _newLib) external;
   1258 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1259 行
- **函数**: `defaultSendLibrary()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1256 | 
   1257 |     function setDefaultSendLibrary(uint32 _eid, address _newLib) external;
   1258 | 
>> 1259 |     function defaultSendLibrary(uint32 _eid) external view returns (address);
   1260 | 
   1261 |     function setDefaultReceiveLibrary(uint32 _eid, address _newLib, uint256 _timeout) external;
   1262 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1263 行
- **函数**: `defaultReceiveLibrary()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1260 | 
   1261 |     function setDefaultReceiveLibrary(uint32 _eid, address _newLib, uint256 _timeout) external;
   1262 | 
>> 1263 |     function defaultReceiveLibrary(uint32 _eid) external view returns (address);
   1264 | 
   1265 |     function setDefaultReceiveLibraryTimeout(uint32 _eid, address _lib, uint256 _expiry) external;
   1266 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1267 行
- **函数**: `defaultReceiveLibraryTimeout()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1264 | 
   1265 |     function setDefaultReceiveLibraryTimeout(uint32 _eid, address _lib, uint256 _expiry) external;
   1266 | 
>> 1267 |     function defaultReceiveLibraryTimeout(uint32 _eid) external view returns (address lib, uint256 expiry);
   1268 | 
   1269 |     function isSupportedEid(uint32 _eid) external view returns (bool);
   1270 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1269 行
- **函数**: `isSupportedEid()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1266 | 
   1267 |     function defaultReceiveLibraryTimeout(uint32 _eid) external view returns (address lib, uint256 expiry);
   1268 | 
>> 1269 |     function isSupportedEid(uint32 _eid) external view returns (bool);
   1270 | 
   1271 |     /// ------------------- OApp interfaces -------------------
   1272 |     function setSendLibrary(address _oapp, uint32 _eid, address _newLib) external;
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1274 行
- **函数**: `getSendLibrary()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1271 |     /// ------------------- OApp interfaces -------------------
   1272 |     function setSendLibrary(address _oapp, uint32 _eid, address _newLib) external;
   1273 | 
>> 1274 |     function getSendLibrary(address _sender, uint32 _eid) external view returns (address lib);
   1275 | 
   1276 |     function isDefaultSendLibrary(address _sender, uint32 _eid) external view returns (bool);
   1277 | 
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1276 行
- **函数**: `isDefaultSendLibrary()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1273 | 
   1274 |     function getSendLibrary(address _sender, uint32 _eid) external view returns (address lib);
   1275 | 
>> 1276 |     function isDefaultSendLibrary(address _sender, uint32 _eid) external view returns (bool);
   1277 | 
   1278 |     function setReceiveLibrary(address _oapp, uint32 _eid, address _newLib, uint256 _gracePeriod) external;
   1279 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1280 行
- **函数**: `getReceiveLibrary()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1277 | 
   1278 |     function setReceiveLibrary(address _oapp, uint32 _eid, address _newLib, uint256 _gracePeriod) external;
   1279 | 
>> 1280 |     function getReceiveLibrary(address _receiver, uint32 _eid) external view returns (address lib, bool isDefault);
   1281 | 
   1282 |     function setReceiveLibraryTimeout(address _oapp, uint32 _eid, address _lib, uint256 _gracePeriod) external;
   1283 | 
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1284 行
- **函数**: `receiveLibraryTimeout()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1281 | 
   1282 |     function setReceiveLibraryTimeout(address _oapp, uint32 _eid, address _lib, uint256 _gracePeriod) external;
   1283 | 
>> 1284 |     function receiveLibraryTimeout(address _receiver, uint32 _eid) external view returns (address lib, uint256 expiry);
   1285 | 
   1286 |     function setConfig(address _oapp, address _lib, SetConfigParam[] calldata _params) external;
   1287 | 
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1308 行
- **函数**: `eid()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1305 |     event PacketNilified(uint32 srcEid, bytes32 sender, address receiver, uint64 nonce, bytes32 payloadHash);
   1306 |     event PacketBurnt(uint32 srcEid, bytes32 sender, address receiver, uint64 nonce, bytes32 payloadHash);
   1307 | 
>> 1308 |     function eid() external view returns (uint32);
   1309 | 
   1310 |     // this is an emergency function if a message cannot be verified for some reasons
   1311 |     // required to provide _nextNonce to avoid race condition
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1318 行
- **函数**: `nextGuid()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1315 | 
   1316 |     function burn(address _oapp, uint32 _srcEid, bytes32 _sender, uint64 _nonce, bytes32 _payloadHash) external;
   1317 | 
>> 1318 |     function nextGuid(address _sender, uint32 _dstEid, bytes32 _receiver) external view returns (bytes32);
   1319 | 
   1320 |     function inboundNonce(address _receiver, uint32 _srcEid, bytes32 _sender) external view returns (uint64);
   1321 | 
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1320 行
- **函数**: `inboundNonce()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1317 | 
   1318 |     function nextGuid(address _sender, uint32 _dstEid, bytes32 _receiver) external view returns (bytes32);
   1319 | 
>> 1320 |     function inboundNonce(address _receiver, uint32 _srcEid, bytes32 _sender) external view returns (uint64);
   1321 | 
   1322 |     function outboundNonce(address _sender, uint32 _dstEid, bytes32 _receiver) external view returns (uint64);
   1323 | 
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1322 行
- **函数**: `outboundNonce()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1319 | 
   1320 |     function inboundNonce(address _receiver, uint32 _srcEid, bytes32 _sender) external view returns (uint64);
   1321 | 
>> 1322 |     function outboundNonce(address _sender, uint32 _dstEid, bytes32 _receiver) external view returns (uint64);
   1323 | 
   1324 |     function inboundPayloadHash(
   1325 |         address _receiver,
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1382 行
- **函数**: `isSendingMessage()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1379 | pragma solidity >=0.8.0;
   1380 | 
   1381 | interface IMessagingContext {
>> 1382 |     function isSendingMessage() external view returns (bool);
   1383 | 
   1384 |     function getSendContext() external view returns (uint32 dstEid, address sender);
   1385 | }
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1384 行
- **函数**: `getSendContext()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1381 | interface IMessagingContext {
   1382 |     function isSendingMessage() external view returns (bool);
   1383 | 
>> 1384 |     function getSendContext() external view returns (uint32 dstEid, address sender);
   1385 | }
   1386 | 
   1387 | 
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1674 行
- **函数**: `owner()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1671 |     /**
   1672 |      * @dev Returns the address of the current owner.
   1673 |      */
>> 1674 |     function owner() public view virtual returns (address) {
   1675 |         return _owner;
   1676 |     }
   1677 | 
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1745 行
- **函数**: `totalSupply()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1742 |     /**
   1743 |      * @dev Returns the amount of tokens in existence.
   1744 |      */
>> 1745 |     function totalSupply() external view returns (uint256);
   1746 | 
   1747 |     /**
   1748 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1750 行
- **函数**: `balanceOf()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1747 |     /**
   1748 |      * @dev Returns the amount of tokens owned by `account`.
   1749 |      */
>> 1750 |     function balanceOf(address account) external view returns (uint256);
   1751 | 
   1752 |     /**
   1753 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1759 行
- **函数**: `transfer()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1756 |      *
   1757 |      * Emits a {Transfer} event.
   1758 |      */
>> 1759 |     function transfer(address to, uint256 amount) external returns (bool);
   1760 | 
   1761 |     /**
   1762 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1768 行
- **函数**: `allowance()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1765 |      *
   1766 |      * This value changes when {approve} or {transferFrom} are called.
   1767 |      */
>> 1768 |     function allowance(address owner, address spender) external view returns (uint256);
   1769 | 
   1770 |     /**
   1771 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1784 行
- **函数**: `approve()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1781 |      *
   1782 |      * Emits an {Approval} event.
   1783 |      */
>> 1784 |     function approve(address spender, uint256 amount) external returns (bool);
   1785 | 
   1786 |     /**
   1787 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1795 行
- **函数**: `transferFrom()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1792 |      *
   1793 |      * Emits a {Transfer} event.
   1794 |      */
>> 1795 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
   1796 | }
   1797 | 
   1798 | 
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1883 行
- **函数**: `nonces()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1880 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   1881 |      * prevents a signature from being used multiple times.
   1882 |      */
>> 1883 |     function nonces(address owner) external view returns (uint256);
   1884 | 
   1885 |     /**
   1886 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1889 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1886 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
   1887 |      */
   1888 |     // solhint-disable-next-line func-name-mixedcase
>> 1889 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1890 | }
   1891 | 
   1892 | 
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 2345 行
- **函数**: `supportsInterface()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2342 |      *
   2343 |      * This function call must use less than 30 000 gas.
   2344 |      */
>> 2345 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   2346 | }
   2347 | 
   2348 | 
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 3522 行
- **函数**: `stargateType()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3519 |     ) external payable returns (MessagingReceipt memory msgReceipt, OFTReceipt memory oftReceipt, Ticket memory ticket);
   3520 | 
   3521 |     /// @notice Returns the Stargate implementation type.
>> 3522 |     function stargateType() external pure returns (StargateType);
   3523 | }
   3524 | 
   3525 | 
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 3575 行
- **函数**: `quoteTaxi()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3572 |     /// @param _params The taxi message payload
   3573 |     /// @param _payInLzToken Whether to pay the fee in LZ token
   3574 |     /// @return fee The MessagingFee for sending the taxi message
>> 3575 |     function quoteTaxi(TaxiParams calldata _params, bool _payInLzToken) external view returns (MessagingFee memory fee);
   3576 | 
   3577 |     /// @notice Sends a message to ride the bus, queuing the passenger in preparation for the drive.
   3578 |     /// @notice The planner will later driveBus to the destination endpoint.
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 3590 行
- **函数**: `quoteRideBus()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3587 |     /// @param _dstEid The destination LayerZero endpoint ID.
   3588 |     /// @param _nativeDrop Whether to pay for a native drop on the destination.
   3589 |     /// @return fee The MessagingFee for riding the bus
>> 3590 |     function quoteRideBus(uint32 _dstEid, bool _nativeDrop) external view returns (MessagingFee memory fee);
   3591 | 
   3592 |     /// @notice Drives the bus to the destination.
   3593 |     /// @param _dstEid The destination LayerZero endpoint ID.
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 3605 行
- **函数**: `quoteDriveBus()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3602 |     /// @param _dstEid The destination LayerZero endpoint ID.
   3603 |     /// @param _passengers The passengers to drive to the destination.
   3604 |     /// @return fee The MessagingFee for driving the bus
>> 3605 |     function quoteDriveBus(uint32 _dstEid, bytes calldata _passengers) external view returns (MessagingFee memory fee);
   3606 | }
   3607 | 
   3608 | 
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4047 行
- **函数**: `getTransferGasLimit()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4044 |     // @dev ie. empty fallbacks or EOA addresses
   4045 |     uint256 internal transferGasLimit = 2300;
   4046 | 
>> 4047 |     function getTransferGasLimit() external view returns (uint256) {
   4048 |         return transferGasLimit;
   4049 |     }
   4050 | 
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4282 行
- **函数**: `isPeer()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4279 |         _lzReceive(_origin, _guid, _message, _executor, _extraData);
   4280 |     }
   4281 | 
>> 4282 |     function isPeer(uint32 _eid, bytes32 _peer) public view override returns (bool) {
   4283 |         return _peer == peers[_eid];
   4284 |     }
   4285 | }
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4398 行
- **函数**: `setFares()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4395 |     }
   4396 | 
   4397 |     // The '_busAndNativeDropFare' is the cost for riding the bus AND the native drop
>> 4398 |     function setFares(uint32 _dstEid, uint80 _busFare, uint80 _busAndNativeDropFare) external onlyPlanner {
   4399 |         // If the planner sets the bus fare with the localEid, users can ride the bus to the local endpoint,
   4400 |         // but the bus will never be driven.
   4401 |         if (_dstEid == localEid) revert Messaging_InvalidEid();
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4435 行
- **函数**: `quoteRideBus()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4432 | 
   4433 |     // ---------------------------------- RideBus ------------------------------------------
   4434 | 
>> 4435 |     function quoteRideBus(uint32 _dstEid, bool _airdrop) external view returns (MessagingFee memory fee) {
   4436 |         fee.nativeFee = busQueues[_dstEid].safeGetFare(_airdrop);
   4437 |     }
   4438 | 
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4466 行
- **函数**: `getPassengerHash()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4463 |         receipt.fee.nativeFee = fare;
   4464 |     }
   4465 | 
>> 4466 |     function getPassengerHash(uint32 _dstEid, uint16 _index) external view returns (bytes32 hash) {
   4467 |         hash = busQueues[_dstEid].hashChain[_index];
   4468 |     }
   4469 | 
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4472 行
- **函数**: `quoteDriveBus()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4469 | 
   4470 |     // ---------------------------------- Bus ------------------------------------------
   4471 | 
>> 4472 |     function quoteDriveBus(uint32 _dstEid, bytes calldata _passengers) external view returns (MessagingFee memory fee) {
   4473 |         // Step 1: check the tickets
   4474 |         Bus memory bus = busQueues[_dstEid].checkTickets(queueCapacity, _passengers);
   4475 | 
```

---

### 74. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 17 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     12 | import { OAppReceiver, Origin } from "./OAppReceiver.sol";
     13 | import { OAppCore } from "./OAppCore.sol";
     14 | 
     15 | /**
     16 |  * @title OApp
>>   17 |  * @dev Abstract contract serving as the base for OApp implementation, combining OAppSender and OAppReceiver functionality.
     18 |  */
     19 | abstract contract OApp is OAppSender, OAppReceiver {
     20 |     /**
     21 |      * @dev Constructor to initialize the OApp with the provided endpoint and owner.
     22 |      * @param _endpoint The address of the LOCAL LayerZero endpoint.
```

---

### 75. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 55 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     50 | import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";
     51 | import { IOAppCore, ILayerZeroEndpointV2 } from "./interfaces/IOAppCore.sol";
     52 | 
     53 | /**
     54 |  * @title OAppCore
>>   55 |  * @dev Abstract contract implementing the IOAppCore interface with basic OApp configurations.
     56 |  */
     57 | abstract contract OAppCore is IOAppCore, Ownable {
     58 |     // The LayerZero endpoint associated with the given OApp
     59 |     ILayerZeroEndpointV2 public immutable endpoint;
     60 | 
```

---

### 76. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 142 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    137 | import { IOAppReceiver, Origin } from "./interfaces/IOAppReceiver.sol";
    138 | import { OAppCore } from "./OAppCore.sol";
    139 | 
    140 | /**
    141 |  * @title OAppReceiver
>>  142 |  * @dev Abstract contract implementing the ILayerZeroReceiver interface and extending OAppCore for OApp receivers.
    143 |  */
    144 | abstract contract OAppReceiver is IOAppReceiver, OAppCore {
    145 |     // Custom error message for when the caller is not the registered endpoint/
    146 |     error OnlyEndpoint(address addr);
    147 | 
```

---

### 77. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 528 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    523 | import { Ownable } from "@openzeppelin/contracts/access/Ownable.sol";
    524 | import { IOAppOptionsType3, EnforcedOptionParam } from "../interfaces/IOAppOptionsType3.sol";
    525 | 
    526 | /**
    527 |  * @title OAppOptionsType3
>>  528 |  * @dev Abstract contract implementing the IOAppOptionsType3 interface with type 3 options.
    529 |  */
    530 | abstract contract OAppOptionsType3 is IOAppOptionsType3, Ownable {
    531 |     uint16 internal constant OPTION_TYPE_3 = 3;
    532 | 
    533 |     // @dev The "msgType" should be defined in the child contract.
```

---

### 78. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 784 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    779 | import { IPreCrime } from "./interfaces/IPreCrime.sol";
    780 | import { IOAppPreCrimeSimulator, InboundPacket, Origin } from "./interfaces/IOAppPreCrimeSimulator.sol";
    781 | 
    782 | /**
    783 |  * @title OAppPreCrimeSimulator
>>  784 |  * @dev Abstract contract serving as the base for preCrime simulation functionality in an OApp.
    785 |  */
    786 | abstract contract OAppPreCrimeSimulator is IOAppPreCrimeSimulator, Ownable {
    787 |     // The address of the preCrime implementation.
    788 |     address public preCrime;
    789 | 
```

---

### 79. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1651 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1646 |  *
   1647 |  * This module is used through inheritance. It will make available the modifier
   1648 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
   1649 |  * the owner.
   1650 |  */
>> 1651 | abstract contract Ownable is Context {
   1652 |     address private _owner;
   1653 | 
   1654 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
   1655 | 
   1656 |     /**
```

---

### 80. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1706 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1701 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
   1702 |         _transferOwnership(newOwner);
   1703 |     }
   1704 | 
   1705 |     /**
>> 1706 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
   1707 |      * Internal function without access restriction.
   1708 |      */
   1709 |     function _transferOwnership(address newOwner) internal virtual {
   1710 |         address oldOwner = _owner;
   1711 |         _owner = newOwner;
```

---

### 81. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1907 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1902 | import "../../../utils/Address.sol";
   1903 | 
   1904 | /**
   1905 |  * @title SafeERC20
   1906 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>> 1907 |  * contract returns false). Tokens that return no value (and instead revert or
   1908 |  * throw on failure) are also supported, non-reverting calls are assumed to be
   1909 |  * successful.
   1910 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
   1911 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
   1912 |  */
```

---

### 82. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4194 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4189 | pragma solidity ^0.8.22;
   4190 | 
   4191 | import { OApp, Origin } from "@layerzerolabs/lz-evm-oapp-v2/contracts/oapp/OApp.sol";
   4192 | import { OAppPreCrimeSimulator } from "@layerzerolabs/lz-evm-oapp-v2/contracts/precrime/OAppPreCrimeSimulator.sol";
   4193 | 
>> 4194 | abstract contract MessagingBase is OApp, OAppPreCrimeSimulator {
   4195 |     // max asset id, for the off-chain to get the range of asset id and get the list of stargate impls
   4196 |     uint16 public maxAssetId;
   4197 |     mapping(address stargateImpl => uint16 assetId) public assetIds;
   4198 |     mapping(uint16 assetId => address stargateImpl) public stargateImpls;
   4199 | 
```

---

### 83. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4304 行
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4299 | import { TokenMessagingOptions } from "./TokenMessagingOptions.sol";
   4300 | import { MessagingBase, Origin } from "./MessagingBase.sol";
   4301 | import { TaxiCodec } from "../libs/TaxiCodec.sol";
   4302 | import { AddressCast } from "../libs/AddressCast.sol";
   4303 | 
>> 4304 | contract TokenMessaging is Transfer, MessagingBase, TokenMessagingOptions, ITokenMessaging {
   4305 |     /// @dev The maximum number of passengers is queueCapacity - 1 to avoid overwriting the hash root.
   4306 |     uint16 public immutable queueCapacity;
   4307 |     uint32 internal immutable localEid;
   4308 | 
   4309 |     mapping(uint32 dstEid => BusQueue queue) public busQueues;
```

---

### 84. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 611 行
- **函数**: `_assertOptionsType3()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    608 |      */
    609 |     function _assertOptionsType3(bytes memory _options) internal pure virtual {
    610 |         uint16 optionsType;
>>  611 |         assembly {
    612 |             optionsType := mload(add(_options, 2))
    613 |         }
    614 |         if (optionsType != OPTION_TYPE_3) revert InvalidOptions(_options);
```

---

### 85. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 1455 行
- **函数**: `toBytes()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1452 |         result = new bytes(_size);
   1453 |         unchecked {
   1454 |             uint256 offset = 256 - _size * 8;
>> 1455 |             assembly {
   1456 |                 mstore(add(result, 32), shl(offset, _addressBytes32))
   1457 |             }
   1458 |         }
```

---

### 86. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 2277 行
- **函数**: `_revert()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2274 |         if (returndata.length > 0) {
   2275 |             // The easiest way to bubble the revert reason is using memory via assembly
   2276 |             /// @solidity memory-safe-assembly
>> 2277 |             assembly {
   2278 |                 let returndata_size := mload(returndata)
   2279 |                 revert(add(32, returndata), returndata_size)
   2280 |             }
```

---

### 87. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x6E3d884C96d640526F273C61dfcF08915eBd7e2B` 第 4066 行
- **函数**: `transferNative()`
- **合约**: `serving`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   4063 |         uint256 gasForCall = _gasLimited ? transferGasLimit : gasleft();
   4064 | 
   4065 |         // @dev We dont care about the data returned here, only success or not.
>> 4066 |         assembly {
   4067 |             success := call(gasForCall, _to, _value, 0, 0, 0, 0)
   4068 |         }
   4069 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*