# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:57:25
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` |
| contract_name | `USDu` |
| compiler_version | `v0.8.27+commit.40a35a09` |
| optimization_used | `True` |
| runs | `20` |
| evm_version | `paris` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/access/Ownable2Step.sol', '@openzeppelin/contracts/interfaces/IERC5267.sol', '@openzeppelin/contracts/token/ERC20/ERC20.sol', '@openzeppelin/contracts/token/ERC20/extensions/draft-ERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/extensions/ERC20Burnable.sol', '@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/utils/Counters.sol', '@openzeppelin/contracts/utils/cryptography/ECDSA.sol', '@openzeppelin/contracts/utils/cryptography/EIP712.sol', '@openzeppelin/contracts/utils/math/Math.sol', '@openzeppelin/contracts/utils/math/SignedMath.sol', '@openzeppelin/contracts/utils/ShortStrings.sol', '@openzeppelin/contracts/utils/StorageSlot.sol', '@openzeppelin/contracts/utils/Strings.sol', 'contracts/interfaces/IUSDuDefinitions.sol', 'contracts/USDu.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646141` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 38 |
| 🟢 LOW | 20 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 45 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     42 |     /**
     43 |      * @dev Returns the address of the current owner.
     44 |      */
>>   45 |     function owner() public view virtual returns (address) {
     46 |         return _owner;
     47 |     }
     48 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 116 行
- **函数**: `pendingOwner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    113 |     /**
    114 |      * @dev Returns the address of the pending owner.
    115 |      */
>>  116 |     function pendingOwner() public view virtual returns (address) {
    117 |         return _pendingOwner;
    118 |     }
    119 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 141 行
- **函数**: `acceptOwnership()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    138 |     /**
    139 |      * @dev The new owner accepts the ownership transfer.
    140 |      */
>>  141 |     function acceptOwnership() public virtual {
    142 |         address sender = _msgSender();
    143 |         require(pendingOwner() == sender, "Ownable2Step: caller is not the new owner");
    144 |         _transferOwnership(sender);
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 244 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    241 |     /**
    242 |      * @dev Returns the name of the token.
    243 |      */
>>  244 |     function name() public view virtual override returns (string memory) {
    245 |         return _name;
    246 |     }
    247 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 252 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    249 |      * @dev Returns the symbol of the token, usually a shorter version of the
    250 |      * name.
    251 |      */
>>  252 |     function symbol() public view virtual override returns (string memory) {
    253 |         return _symbol;
    254 |     }
    255 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 269 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    266 |      * no way affects any of the arithmetic of the contract, including
    267 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    268 |      */
>>  269 |     function decimals() public view virtual override returns (uint8) {
    270 |         return 18;
    271 |     }
    272 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 276 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    273 |     /**
    274 |      * @dev See {IERC20-totalSupply}.
    275 |      */
>>  276 |     function totalSupply() public view virtual override returns (uint256) {
    277 |         return _totalSupply;
    278 |     }
    279 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 283 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    280 |     /**
    281 |      * @dev See {IERC20-balanceOf}.
    282 |      */
>>  283 |     function balanceOf(address account) public view virtual override returns (uint256) {
    284 |         return _balances[account];
    285 |     }
    286 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 295 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    292 |      * - `to` cannot be the zero address.
    293 |      * - the caller must have a balance of at least `amount`.
    294 |      */
>>  295 |     function transfer(address to, uint256 amount) public virtual override returns (bool) {
    296 |         address owner = _msgSender();
    297 |         _transfer(owner, to, amount);
    298 |         return true;
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 304 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    301 |     /**
    302 |      * @dev See {IERC20-allowance}.
    303 |      */
>>  304 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    305 |         return _allowances[owner][spender];
    306 |     }
    307 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 318 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    315 |      *
    316 |      * - `spender` cannot be the zero address.
    317 |      */
>>  318 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    319 |         address owner = _msgSender();
    320 |         _approve(owner, spender, amount);
    321 |         return true;
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 340 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    337 |      * - the caller must have allowance for ``from``'s tokens of at least
    338 |      * `amount`.
    339 |      */
>>  340 |     function transferFrom(address from, address to, uint256 amount) public virtual override returns (bool) {
    341 |         address spender = _msgSender();
    342 |         _spendAllowance(from, spender, amount);
    343 |         _transfer(from, to, amount);
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 359 行
- **函数**: `increaseAllowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    356 |      *
    357 |      * - `spender` cannot be the zero address.
    358 |      */
>>  359 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    360 |         address owner = _msgSender();
    361 |         _approve(owner, spender, allowance(owner, spender) + addedValue);
    362 |         return true;
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 379 行
- **函数**: `decreaseAllowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    376 |      * - `spender` must have allowance for the caller of at least
    377 |      * `subtractedValue`.
    378 |      */
>>  379 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    380 |         address owner = _msgSender();
    381 |         uint256 currentAllowance = allowance(owner, spender);
    382 |         require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 583 行
- **函数**: `burn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    580 |      *
    581 |      * See {ERC20-_burn}.
    582 |      */
>>  583 |     function burn(uint256 amount) public virtual {
    584 |         _burn(_msgSender(), amount);
    585 |     }
    586 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 598 行
- **函数**: `burnFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    595 |      * - the caller must have allowance for ``accounts``'s tokens of at least
    596 |      * `amount`.
    597 |      */
>>  598 |     function burnFrom(address account, uint256 amount) public virtual {
    599 |         _spendAllowance(account, _msgSender(), amount);
    600 |         _burn(account, amount);
    601 |     }
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 679 行
- **函数**: `nonces()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    676 |     /**
    677 |      * @dev See {IERC20Permit-nonces}.
    678 |      */
>>  679 |     function nonces(address owner) public view virtual override returns (uint256) {
    680 |         return _nonces[owner].current();
    681 |     }
    682 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 687 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    684 |      * @dev See {IERC20Permit-DOMAIN_SEPARATOR}.
    685 |      */
    686 |     // solhint-disable-next-line func-name-mixedcase
>>  687 |     function DOMAIN_SEPARATOR() external view override returns (bytes32) {
    688 |         return _domainSeparatorV4();
    689 |     }
    690 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 722 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    719 |     /**
    720 |      * @dev Returns the name of the token.
    721 |      */
>>  722 |     function name() external view returns (string memory);
    723 | 
    724 |     /**
    725 |      * @dev Returns the symbol of the token.
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 727 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    724 |     /**
    725 |      * @dev Returns the symbol of the token.
    726 |      */
>>  727 |     function symbol() external view returns (string memory);
    728 | 
    729 |     /**
    730 |      * @dev Returns the decimals places of the token.
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 732 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    729 |     /**
    730 |      * @dev Returns the decimals places of the token.
    731 |      */
>>  732 |     function decimals() external view returns (uint8);
    733 | }
    734 | 
    735 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 790 行
- **函数**: `nonces()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    787 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
    788 |      * prevents a signature from being used multiple times.
    789 |      */
>>  790 |     function nonces(address owner) external view returns (uint256);
    791 | 
    792 |     /**
    793 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 796 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    793 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
    794 |      */
    795 |     // solhint-disable-next-line func-name-mixedcase
>>  796 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    797 | }
    798 | 
    799 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 828 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    825 |     /**
    826 |      * @dev Returns the amount of tokens in existence.
    827 |      */
>>  828 |     function totalSupply() external view returns (uint256);
    829 | 
    830 |     /**
    831 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 833 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    830 |     /**
    831 |      * @dev Returns the amount of tokens owned by `account`.
    832 |      */
>>  833 |     function balanceOf(address account) external view returns (uint256);
    834 | 
    835 |     /**
    836 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 842 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    839 |      *
    840 |      * Emits a {Transfer} event.
    841 |      */
>>  842 |     function transfer(address to, uint256 amount) external returns (bool);
    843 | 
    844 |     /**
    845 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 851 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    848 |      *
    849 |      * This value changes when {approve} or {transferFrom} are called.
    850 |      */
>>  851 |     function allowance(address owner, address spender) external view returns (uint256);
    852 | 
    853 |     /**
    854 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 867 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    864 |      *
    865 |      * Emits an {Approval} event.
    866 |      */
>>  867 |     function approve(address spender, uint256 amount) external returns (bool);
    868 | 
    869 |     /**
    870 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 878 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    875 |      *
    876 |      * Emits a {Transfer} event.
    877 |      */
>>  878 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
    879 | }
    880 | 
    881 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 2118 行
- **函数**: `mint()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2115 |     minter = newMinter;
   2116 |   }
   2117 | 
>> 2118 |   function mint(address to, uint256 amount) external {
   2119 |     if (msg.sender != minter) revert OnlyMinter();
   2120 |     _mint(to, amount);
   2121 |   }
```

---

### 31. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 22 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     17 |  *
     18 |  * This module is used through inheritance. It will make available the modifier
     19 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     20 |  * the owner.
     21 |  */
>>   22 | abstract contract Ownable is Context {
     23 |     address private _owner;
     24 | 
     25 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     26 | 
     27 |     /**
```

---

### 32. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 77 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     72 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
     73 |         _transferOwnership(newOwner);
     74 |     }
     75 | 
     76 |     /**
>>   77 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     78 |      * Internal function without access restriction.
     79 |      */
     80 |     function _transferOwnership(address newOwner) internal virtual {
     81 |         address oldOwner = _owner;
     82 |         _owner = newOwner;
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 108 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    103 |  * can later be changed with {transferOwnership} and {acceptOwnership}.
    104 |  *
    105 |  * This module is used through inheritance. It will make available all functions
    106 |  * from parent (Ownable).
    107 |  */
>>  108 | abstract contract Ownable2Step is Ownable {
    109 |     address private _pendingOwner;
    110 | 
    111 |     event OwnershipTransferStarted(address indexed previousOwner, address indexed newOwner);
    112 | 
    113 |     /**
```

---

### 34. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 220 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    215 |  *
    216 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    217 |  * functions have been added to mitigate the well-known issues around setting
    218 |  * allowances. See {IERC20-approve}.
    219 |  */
>>  220 | contract ERC20 is Context, IERC20, IERC20Metadata {
    221 |     mapping(address => uint256) private _balances;
    222 | 
    223 |     mapping(address => mapping(address => uint256)) private _allowances;
    224 | 
    225 |     uint256 private _totalSupply;
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 628 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    623 |  * presenting a message signed by the account. By not relying on `{IERC20-approve}`, the token holder account doesn't
    624 |  * need to send a transaction, and thus is not required to hold Ether at all.
    625 |  *
    626 |  * _Available since v3.4._
    627 |  */
>>  628 | abstract contract ERC20Permit is ERC20, IERC20Permit, EIP712 {
    629 |     using Counters for Counters.Counter;
    630 | 
    631 |     mapping(address => Counters.Counter) private _nonces;
    632 | 
    633 |     // solhint-disable-next-line var-name-mixedcase
```

---

### 36. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1203 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1198 |  * ({_hashTypedDataV4}).
   1199 |  *
   1200 |  * The implementation of the domain separator was designed to be as efficient as possible while still properly updating
   1201 |  * the chain id to protect against replay attacks on an eventual fork of the chain.
   1202 |  *
>> 1203 |  * NOTE: This contract implements the version of the encoding known as "v4", as implemented by the JSON RPC method
   1204 |  * https://docs.metamask.io/guide/signing-data.html[`eth_signTypedDataV4` in MetaMask].
   1205 |  *
   1206 |  * NOTE: In the upgradeable version of this contract, the cached values will correspond to the address, and the domain
   1207 |  * separator of the implementation contract. This will cause the `_domainSeparatorV4` function to always rebuild the
   1208 |  * separator from the immutable values, which is cheaper than accessing a cached version in cold storage.
```

---

### 37. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1739 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1734 |  * fallback mechanism can be used for every other case.
   1735 |  *
   1736 |  * Usage example:
   1737 |  *
   1738 |  * ```solidity
>> 1739 |  * contract Named {
   1740 |  *     using ShortStrings for *;
   1741 |  *
   1742 |  *     ShortString private immutable _name;
   1743 |  *     string private _nameFallback;
   1744 |  *
```

---

### 38. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 2105 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2100 | /**
   2101 |  * @title USDu
   2102 |  * @notice Stable Coin Contract
   2103 |  * @dev Only a single approved minter can mint new tokens
   2104 |  */
>> 2105 | contract USDu is Ownable2Step, ERC20Burnable, ERC20Permit, IUSDuDefinitions {
   2106 |   address public minter;
   2107 | 
   2108 |   constructor(address admin) ERC20("USDu", "USDu") ERC20Permit("USDu") {
   2109 |     if (admin == address(0)) revert ZeroAddressException();
   2110 |     _transferOwnership(admin);
```

---

### 39. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 664 行
- **函数**: `permit()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    661 |         bytes32 r,
    662 |         bytes32 s
    663 |     ) public virtual override {
>>  664 |         require(block.timestamp <= deadline, "ERC20Permit: expired deadline");
    665 | 
    666 |         bytes32 structHash = keccak256(abi.encode(_PERMIT_TYPEHASH, owner, spender, value, _useNonce(owner), deadline));
    667 | 
```

---

### 40. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1060 行
- **函数**: `tryRecover()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1057 |      * _Available since v4.3._
   1058 |      */
   1059 |     function tryRecover(bytes32 hash, bytes32 r, bytes32 vs) internal pure returns (address, RecoverError) {
>> 1060 |         bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
   1061 |         uint8 v = uint8((uint256(vs) >> 255) + 27);
   1062 |         return tryRecover(hash, v, r, s);
   1063 |     }
```

---

### 41. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1092 行
- **函数**: `tryRecover()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1089 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
   1090 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
   1091 |         // these malleable signatures as well.
>> 1092 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
   1093 |             return (address(0), RecoverError.InvalidSignatureS);
   1094 |         }
   1095 | 
```

---

### 42. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1021 行
- **函数**: `tryRecover()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1018 |             // ecrecover takes the signature parameters, and the only way to get them
   1019 |             // currently is to use assembly.
   1020 |             /// @solidity memory-safe-assembly
>> 1021 |             assembly {
   1022 |                 r := mload(add(signature, 0x20))
   1023 |                 s := mload(add(signature, 0x40))
   1024 |                 v := byte(0, mload(add(signature, 0x60)))
```

---

### 43. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1127 行
- **函数**: `toEthSignedMessageHash()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1124 |         // 32 is the length in bytes of hash,
   1125 |         // enforced by the type signature above
   1126 |         /// @solidity memory-safe-assembly
>> 1127 |         assembly {
   1128 |             mstore(0x00, "\x19Ethereum Signed Message:\n32")
   1129 |             mstore(0x1c, hash)
   1130 |             message := keccak256(0x00, 0x3c)
```

---

### 44. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1157 行
- **函数**: `toTypedDataHash()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1154 |      */
   1155 |     function toTypedDataHash(bytes32 domainSeparator, bytes32 structHash) internal pure returns (bytes32 data) {
   1156 |         /// @solidity memory-safe-assembly
>> 1157 |         assembly {
   1158 |             let ptr := mload(0x40)
   1159 |             mstore(ptr, "\x19\x01")
   1160 |             mstore(add(ptr, 0x02), domainSeparator)
```

---

### 45. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1387 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1384 |             // variables such that product = prod1 * 2^256 + prod0.
   1385 |             uint256 prod0; // Least significant 256 bits of the product
   1386 |             uint256 prod1; // Most significant 256 bits of the product
>> 1387 |             assembly {
   1388 |                 let mm := mulmod(x, y, not(0))
   1389 |                 prod0 := mul(x, y)
   1390 |                 prod1 := sub(sub(mm, prod0), lt(mm, prod0))
```

---

### 46. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1410 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1407 | 
   1408 |             // Make division exact by subtracting the remainder from [prod1 prod0].
   1409 |             uint256 remainder;
>> 1410 |             assembly {
   1411 |                 // Compute remainder using mulmod.
   1412 |                 remainder := mulmod(x, y, denominator)
   1413 | 
```

---

### 47. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1424 行
- **函数**: `mulDiv()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1421 | 
   1422 |             // Does not overflow because the denominator cannot be zero at this stage in the function.
   1423 |             uint256 twos = denominator & (~denominator + 1);
>> 1424 |             assembly {
   1425 |                 // Divide denominator by twos.
   1426 |                 denominator := div(denominator, twos)
   1427 | 
```

---

### 48. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1783 行
- **函数**: `toString()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1780 |         // using `new string(len)` would work locally but is not memory safe.
   1781 |         string memory str = new string(32);
   1782 |         /// @solidity memory-safe-assembly
>> 1783 |         assembly {
   1784 |             mstore(str, len)
   1785 |             mstore(add(str, 0x20), sstr)
   1786 |         }
```

---

### 49. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1905 行
- **函数**: `getAddressSlot()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1902 |      */
   1903 |     function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
   1904 |         /// @solidity memory-safe-assembly
>> 1905 |         assembly {
   1906 |             r.slot := slot
   1907 |         }
   1908 |     }
```

---

### 50. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1915 行
- **函数**: `getBooleanSlot()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1912 |      */
   1913 |     function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
   1914 |         /// @solidity memory-safe-assembly
>> 1915 |         assembly {
   1916 |             r.slot := slot
   1917 |         }
   1918 |     }
```

---

### 51. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1925 行
- **函数**: `getBytes32Slot()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1922 |      */
   1923 |     function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
   1924 |         /// @solidity memory-safe-assembly
>> 1925 |         assembly {
   1926 |             r.slot := slot
   1927 |         }
   1928 |     }
```

---

### 52. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1935 行
- **函数**: `getUint256Slot()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1932 |      */
   1933 |     function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
   1934 |         /// @solidity memory-safe-assembly
>> 1935 |         assembly {
   1936 |             r.slot := slot
   1937 |         }
   1938 |     }
```

---

### 53. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1945 行
- **函数**: `getStringSlot()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1942 |      */
   1943 |     function getStringSlot(bytes32 slot) internal pure returns (StringSlot storage r) {
   1944 |         /// @solidity memory-safe-assembly
>> 1945 |         assembly {
   1946 |             r.slot := slot
   1947 |         }
   1948 |     }
```

---

### 54. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1955 行
- **函数**: `getStringSlot()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1952 |      */
   1953 |     function getStringSlot(string storage store) internal pure returns (StringSlot storage r) {
   1954 |         /// @solidity memory-safe-assembly
>> 1955 |         assembly {
   1956 |             r.slot := store.slot
   1957 |         }
   1958 |     }
```

---

### 55. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1965 行
- **函数**: `getBytesSlot()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1962 |      */
   1963 |     function getBytesSlot(bytes32 slot) internal pure returns (BytesSlot storage r) {
   1964 |         /// @solidity memory-safe-assembly
>> 1965 |         assembly {
   1966 |             r.slot := slot
   1967 |         }
   1968 |     }
```

---

### 56. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 1975 行
- **函数**: `getBytesSlot()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1972 |      */
   1973 |     function getBytesSlot(bytes storage store) internal pure returns (BytesSlot storage r) {
   1974 |         /// @solidity memory-safe-assembly
>> 1975 |         assembly {
   1976 |             r.slot := store.slot
   1977 |         }
   1978 |     }
```

---

### 57. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 2008 行
- **函数**: `toString()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2005 |             string memory buffer = new string(length);
   2006 |             uint256 ptr;
   2007 |             /// @solidity memory-safe-assembly
>> 2008 |             assembly {
   2009 |                 ptr := add(buffer, add(32, length))
   2010 |             }
   2011 |             while (true) {
```

---

### 58. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xeA953eA6634d55dAC6697C436B1e81A679Db5882` 第 2014 行
- **函数**: `toString()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2011 |             while (true) {
   2012 |                 ptr--;
   2013 |                 /// @solidity memory-safe-assembly
>> 2014 |                 assembly {
   2015 |                     mstore8(ptr, byte(mod(value, 10), _SYMBOLS))
   2016 |                 }
   2017 |                 value /= 10;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*