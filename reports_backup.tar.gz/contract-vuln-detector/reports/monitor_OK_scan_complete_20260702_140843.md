# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:08:43
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` |
| contract_name | `OK` |
| compiler_version | `v0.8.31+commit.fd3a2265` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['ok-original/ok.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 8 |
| 🟡 MEDIUM | 45 |
| 🟢 LOW | 39 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 614 行
- **函数**: `_enforceBlockAndCooldown()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    611 |             lastTradeSide[trader] = side;
    612 |         }
    613 | 
>>  614 |         address origin = tx.origin;
    615 |         if (
    616 |             origin != address(0) &&
    617 |             origin != address(this) &&
```

---

### 2. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol` 第 459 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569):
	External calls:
	- processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#488)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1385)
		- (success,None) = communityFund.call{value: balance}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1393)
	- _swapAndLiquify(panicFee) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#562)
		- router.swapExactTokensForETHSupportingFeeOnTransferTokens(half,minOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1516-1561)
		- _tokenReceiver.withdrawBNB(bnbGain) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1527)
		- router.addLiquidityETH{value: bnbGain}(address(this),otherHalf,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1530-1539)
		- (success,None) = address(communityFund).call{value: bnbLeft - bnbBefore}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1542-1544)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1559)
	External calls sending eth:
	- processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#488)
		- (success,None) = communityFund.call{value: balance}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1393)
	- _swapAndLiquify(panicFee) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#562)
		- router.addLiquidityETH{value: bnbGain}(address(this),otherHalf,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1530-1539)
		- (success,None) = address(communityFund).call{value: bnbLeft - bnbBefore}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1542-1544)
	State variables written after the call(s):
	- _swapAndLiquify(panicFee) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#562)
		- _balances[sender] -= amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#836)
		- _balances[recipient] += amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#837)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)
	- _basicTransfer(address(this),recipient,amount - totalFee) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#564)
		- _balances[sender] -= amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#836)
		- _balances[recipient] += amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#837)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)
	- _swapAndLiquify(panicFee) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#562)
		- inSwap = true (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1495)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1497)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1504)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1562)
	OK.inSwap (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#256) can be used in cross function reentrancies:
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.lockTheSwap() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#257-261)

**代码片段**:
```solidity
    456 |         emit Approval(owner, spender, amount);
    457 |     }
    458 | 
>>  459 |     function _transfer(
    460 |         address sender,
    461 |         address recipient,
    462 |         uint256 amount
```

---

### 3. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol` 第 459 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569):
	External calls:
	- processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#488)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1385)
		- (success,None) = communityFund.call{value: balance}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1393)
	External calls sending eth:
	- processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#488)
		- (success,None) = communityFund.call{value: balance}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1393)
	State variables written after the call(s):
	- _claim(sender) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#497)
		- _balances[sender] -= amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#836)
		- _balances[recipient] += amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#837)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)
	- _basicTransfer(address(0),recipient,1e16) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#518)
		- _balances[sender] -= amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#836)
		- _balances[recipient] += amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#837)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)
	- _basicTransfer(sender,address(this),amount) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#552)
		- _balances[sender] -= amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#836)
		- _balances[recipient] += amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#837)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)
	- baseTax = _distributeSellTax(address(this),amount) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#553)
		- _balances[sender] -= p1 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#758)
		- _balances[bigNodeNFT] += p1 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#759)
		- _balances[sender] -= p2 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#763)
		- _balances[smallNodeNFT] += p2 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#764)
		- _balances[sender] -= p3 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#768)
		- _balances[communityFund] += p3 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#769)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)
	- _basicTransfer(sender,recipient,amount) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#568)
		- _balances[sender] -= amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#836)
		- _balances[recipient] += amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#837)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)

**代码片段**:
```solidity
    456 |         emit Approval(owner, spender, amount);
    457 |     }
    458 | 
>>  459 |     function _transfer(
    460 |         address sender,
    461 |         address recipient,
    462 |         uint256 amount
```

---

### 4. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol` 第 1010 行
- **函数**: `_processLiquidityAndBuy()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in OK._processLiquidityAndBuy(uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1010-1059):
	External calls:
	- router.swapExactETHForTokens{value: buyBNB}(minBuyOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1029-1034)
	- _tokenReceiver.withdrawToken(address(this),bought) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1040)
	- router.addLiquidityETH{value: liqBNB}(address(this),bought,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1043-1050)
	External calls sending eth:
	- router.swapExactETHForTokens{value: buyBNB}(minBuyOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1029-1034)
	- router.addLiquidityETH{value: liqBNB}(address(this),bought,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1043-1050)
	State variables written after the call(s):
	- _basicTransfer(address(this),pair,leftover) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1055)
		- _balances[sender] -= amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#836)
		- _balances[recipient] += amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#837)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)

**代码片段**:
```solidity
   1007 |         emit Deposit(user, bnb, u.depositUSDT);
   1008 |     }
   1009 | 
>> 1010 |     function _processLiquidityAndBuy(uint256 buyBNB, uint256 liqBNB) internal {
   1011 |         address[] memory path = new address[](2);
   1012 |         path[0] = router.WETH();
   1013 |         path[1] = address(this);
```

---

### 5. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol` 第 657 行
- **函数**: `_sell()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716):
	External calls:
	- _executeSwapAndBurn(user,swapAmount) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#710)
		- IPancakeRouter01(router).swapExactTokensForETHSupportingFeeOnTransferTokens(swapAmount,minOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#801-827)
		- _tokenReceiver.withdrawBNB(bnbReceived) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#813-818)
		- (success,None) = user.call{value: bnbReceived}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#814)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#823)
	- _swapAndLiquify(panicFee) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#713)
		- router.swapExactTokensForETHSupportingFeeOnTransferTokens(half,minOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1516-1561)
		- _tokenReceiver.withdrawBNB(bnbGain) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1527)
		- router.addLiquidityETH{value: bnbGain}(address(this),otherHalf,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1530-1539)
		- (success,None) = address(communityFund).call{value: bnbLeft - bnbBefore}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1542-1544)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1559)
	External calls sending eth:
	- _executeSwapAndBurn(user,swapAmount) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#710)
		- (success,None) = user.call{value: bnbReceived}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#814)
	- _swapAndLiquify(panicFee) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#713)
		- router.addLiquidityETH{value: bnbGain}(address(this),otherHalf,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1530-1539)
		- (success,None) = address(communityFund).call{value: bnbLeft - bnbBefore}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1542-1544)
	State variables written after the call(s):
	- _swapAndLiquify(panicFee) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#713)
		- _balances[sender] -= amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#836)
		- _balances[recipient] += amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#837)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)
	- _swapAndLiquify(panicFee) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#713)
		- inSwap = true (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1495)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1497)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1504)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1562)
	OK.inSwap (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#256) can be used in cross function reentrancies:
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.lockTheSwap() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#257-261)
	- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#715)
	OK.inSwap (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#256) can be used in cross function reentrancies:
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.lockTheSwap() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#257-261)

**代码片段**:
```solidity
    654 |         return balanceOther <= rOther;
    655 |     }
    656 | 
>>  657 |     function _sell(
    658 |         address user,
    659 |         uint256 amount,
    660 |         bool taxExempt
```

---

### 6. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol` 第 442 行
- **函数**: `transferFrom()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in OK.transferFrom(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#442-452):
	External calls:
	- _transfer(sender,recipient,amount) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#449)
		- IPancakeRouter01(router).swapExactTokensForETHSupportingFeeOnTransferTokens(swapAmount,minOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#801-827)
		- _tokenReceiver.withdrawBNB(bnbReceived) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#813-818)
		- (success,None) = user.call{value: bnbReceived}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#814)
		- router.swapExactTokensForETHSupportingFeeOnTransferTokens(half,minOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1516-1561)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#823)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1385)
		- _tokenReceiver.withdrawBNB(bnbGain) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1527)
		- router.addLiquidityETH{value: bnbGain}(address(this),otherHalf,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1530-1539)
		- (success,None) = communityFund.call{value: balance}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1393)
		- (success,None) = address(communityFund).call{value: bnbLeft - bnbBefore}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1542-1544)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1559)
	External calls sending eth:
	- _transfer(sender,recipient,amount) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#449)
		- (success,None) = user.call{value: bnbReceived}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#814)
		- router.addLiquidityETH{value: bnbGain}(address(this),otherHalf,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1530-1539)
		- (success,None) = communityFund.call{value: balance}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1393)
		- (success,None) = address(communityFund).call{value: bnbLeft - bnbBefore}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1542-1544)
	State variables written after the call(s):
	- _approve(sender,_msgSender(),currentAllowance - amount) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#450)
		- _allowances[owner][spender] = amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#455)
	OK._allowances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#173) can be used in cross function reentrancies:
	- OK._approve(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#454-457)
	- OK.allowance(address,address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#419-424)
	- OK.transferFrom(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#442-452)

**代码片段**:
```solidity
    439 |         return true;
    440 |     }
    441 | 
>>  442 |     function transferFrom(
    443 |         address sender,
    444 |         address recipient,
    445 |         uint256 amount
```

---

### 7. 🟠 [HIGH] reentrancy

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol` 第 459 行
- **函数**: `_transfer()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: Reentrancy in OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569):
	External calls:
	- processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#488)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1385)
		- (success,None) = communityFund.call{value: balance}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1393)
	- _sell(sender,amount,isFeeExempt[sender]) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#502)
		- IPancakeRouter01(router).swapExactTokensForETHSupportingFeeOnTransferTokens(swapAmount,minOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#801-827)
		- _tokenReceiver.withdrawBNB(bnbReceived) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#813-818)
		- (success,None) = user.call{value: bnbReceived}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#814)
		- router.swapExactTokensForETHSupportingFeeOnTransferTokens(half,minOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1516-1561)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#823)
		- _tokenReceiver.withdrawBNB(bnbGain) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1527)
		- router.addLiquidityETH{value: bnbGain}(address(this),otherHalf,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1530-1539)
		- (success,None) = address(communityFund).call{value: bnbLeft - bnbBefore}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1542-1544)
		- IPancakePair(pair).sync() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1559)
	External calls sending eth:
	- processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#488)
		- (success,None) = communityFund.call{value: balance}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1393)
	- _sell(sender,amount,isFeeExempt[sender]) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#502)
		- (success,None) = user.call{value: bnbReceived}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#814)
		- router.addLiquidityETH{value: bnbGain}(address(this),otherHalf,0,0,DEAD,block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1530-1539)
		- (success,None) = address(communityFund).call{value: bnbLeft - bnbBefore}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1542-1544)
	State variables written after the call(s):
	- _sell(sender,amount,isFeeExempt[sender]) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#502)
		- _balances[sender] -= amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#836)
		- _balances[recipient] += amount (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#837)
		- _balances[sender] -= p1 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#758)
		- _balances[bigNodeNFT] += p1 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#759)
		- _balances[sender] -= p2 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#763)
		- _balances[smallNodeNFT] += p2 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#764)
		- _balances[sender] -= p3 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#768)
		- _balances[communityFund] += p3 (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#769)
	OK._balances (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#172) can be used in cross function reentrancies:
	- OK._basicTransfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#830-839)
	- OK._checkDailyLimit(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#718-731)
	- OK._claim(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1129-1171)
	- OK._distributeSellTax(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#748-773)
	- OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828)
	- OK._forceSetBalance(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#841-858)
	- OK._payoutWithCap(address,uint256,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1303-1356)
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.balanceOf(address) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#416-418)
	- OK.constructor() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#269-296)
	- OK.processDailyLogic() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1358-1396)
	- _sell(sender,amount,isFeeExempt[sender]) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#502)
		- inSwap = true (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1495)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1497)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1504)
		- inSwap = true (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#678)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1562)
		- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#715)
	OK.inSwap (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#256) can be used in cross function reentrancies:
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.lockTheSwap() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#257-261)

**代码片段**:
```solidity
    456 |         emit Approval(owner, spender, amount);
    457 |     }
    458 | 
>>  459 |     function _transfer(
    460 |         address sender,
    461 |         address recipient,
    462 |         uint256 amount
```

---

### 8. 🟠 [HIGH] arbitrary-send-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol` 第 793 行
- **函数**: `_executeSwapAndBurn()`
- **扫描工具**: slither
- **综合评分**: 0.695

**工具描述**: OK._executeSwapAndBurn(address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#793-828) sends eth to arbitrary user
	Dangerous calls:
	- (success,None) = user.call{value: bnbReceived}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#814)

**代码片段**:
```solidity
    790 |         return (out * (10000 - bps)) / 10000;
    791 |     }
    792 | 
>>  793 |     function _executeSwapAndBurn(address user, uint256 swapAmount) internal {
    794 |         if (swapAmount == 0) return;
    795 |         uint256 bnbBefore = address(_tokenReceiver).balance;
    796 |         address[] memory path = new address[](2);
```

---

### 9. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 721 行
- **函数**: `_checkDailyLimit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    718 |     function _checkDailyLimit(address user, uint256 amount) internal {
    719 |         uint256 limitRate = getSellLimitRate(user);
    720 | 
>>  721 |         uint256 day = block.timestamp / TIME_STEP;
    722 |         if (lastSellDay[user] != day) {
    723 |             dailySold[user] = 0;
    724 |             lastSellDay[user] = day;
```

---

### 10. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 737 行
- **函数**: `_checkDailySellUsdtLimit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    734 |         address user,
    735 |         uint256 sellValueUSDT
    736 |     ) internal {
>>  737 |         uint256 day = block.timestamp / TIME_STEP;
    738 |         if (lastSellDayUSDT[user] != day) {
    739 |             dailySoldUSDT[user] = 0;
    740 |             lastSellDayUSDT[user] = day;
```

---

### 11. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1108 行
- **函数**: `getDailyRate()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1105 |             return 300;
   1106 |         }
   1107 |         if (launchTime > 0) {
>> 1108 |             uint256 daysSinceLaunch = (block.timestamp - launchTime) /
   1109 |                 TIME_STEP;
   1110 |             uint256 increase = daysSinceLaunch * 2;
   1111 |             uint256 rate = 100 + increase;
```

---

### 12. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1137 行
- **函数**: `_claim()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1134 |             return;
   1135 |         }
   1136 | 
>> 1137 |         uint256 elapsed = block.timestamp - u.lastClaimTime;
   1138 |         uint256 daysPassed = elapsed / TIME_STEP;
   1139 |         if (daysPassed == 0) return;
   1140 | 
```

---

### 13. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1359 行
- **函数**: `processDailyLogic()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1356 |     }
   1357 | 
   1358 |     function processDailyLogic() internal {
>> 1359 |         uint256 elapsed = block.timestamp - lastDailyProcess;
   1360 |         uint256 daysToProcess = elapsed / TIME_STEP;
   1361 |         if (daysToProcess == 0) revert E();
   1362 |         lastDailyProcess += daysToProcess * TIME_STEP;
```

---

### 14. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1447 行
- **函数**: `_calculatePanicFee()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1444 |     ) internal returns (uint256) {
   1445 |         if (amount == 0 || currentPrice == 0) return 0;
   1446 | 
>> 1447 |         uint256 step = block.timestamp / TIME_STEP;
   1448 |         if (lastStepUpdate != step || stepStartPrice == 0) {
   1449 |             lastStepUpdate = step;
   1450 |             stepStartPrice = currentPrice;
```

---

### 15. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1477 行
- **函数**: `getSellLimitRate()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1474 |         if (!u.isActive && u.lastExitTime > 0) {
   1475 |             uint256 period = TIME_STEP * 30;
   1476 |             if (period > 0 && block.timestamp >= u.lastExitTime + period) {
>> 1477 |                 uint256 dec = (block.timestamp - u.lastExitTime) / period;
   1478 |                 if (baseRate > dec) baseRate -= dec;
   1479 |                 else baseRate = 1;
   1480 |             }
```

---

### 16. 🟡 [MEDIUM] reentrancy-no-eth

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol` 第 1493 行
- **函数**: `_swapAndLiquify()`
- **扫描工具**: slither
- **综合评分**: 0.530

**工具描述**: Reentrancy in OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563):
	External calls:
	- router.swapExactTokensForETHSupportingFeeOnTransferTokens(half,minOut,path,address(_tokenReceiver),block.timestamp) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1516-1561)
	State variables written after the call(s):
	- inSwap = false (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1562)
	OK.inSwap (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#256) can be used in cross function reentrancies:
	- OK._sell(address,uint256,bool) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#657-716)
	- OK._swapAndLiquify(uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#1493-1563)
	- OK._transfer(address,address,uint256) (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#459-569)
	- OK.lockTheSwap() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#257-261)

**代码片段**:
```solidity
   1490 |         return limitRate;
   1491 |     }
   1492 | 
>> 1493 |     function _swapAndLiquify(uint256 amount) internal {
   1494 |         bool alreadyInSwap = inSwap;
   1495 |         if (!alreadyInSwap) inSwap = true;
   1496 |         if (amount == 0) {
```

---

### 17. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 76 行
- **函数**: `getReserves()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
     73 | }
     74 | 
     75 | interface IPancakePair {
>>   76 |     function getReserves()
     77 |         external
     78 |         view
     79 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 18. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 636 行
- **函数**: `_isAddLiquidity()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    633 |     }
    634 | 
    635 |     function _isAddLiquidity(uint256 amount) internal view returns (bool) {
>>  636 |         (uint112 r0, uint112 r1, ) = IPancakePair(pair).getReserves();
    637 |         if (r0 == 0 || r1 == 0) return false;
    638 |         bool wethIsToken0 = IPancakePair(pair).token0() == wethAddress;
    639 |         uint256 rOther = wethIsToken0 ? uint256(r0) : uint256(r1);
```

---

### 19. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 648 行
- **函数**: `_isRemoveLiquidity()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    645 |     }
    646 | 
    647 |     function _isRemoveLiquidity() internal view returns (bool) {
>>  648 |         (uint112 r0, uint112 r1, ) = IPancakePair(pair).getReserves();
    649 |         if (r0 == 0 || r1 == 0) return false;
    650 |         uint256 rOther = IPancakePair(pair).token0() == wethAddress
    651 |             ? uint256(r0)
```

---

### 20. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1431 行
- **函数**: `_getOkSpotPriceUSDT()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1428 |         if (pair == address(0)) return 0;
   1429 |         uint256 bnbPrice = getBNBValueInUSDT(1e18);
   1430 |         if (bnbPrice == 0) return 0;
>> 1431 |         (uint112 r0, uint112 r1, ) = IPancakePair(pair).getReserves();
   1432 |         if (r0 == 0 || r1 == 0) return 0;
   1433 |         address t0 = IPancakePair(pair).token0();
   1434 |         uint256 okReserve = t0 == address(this) ? uint256(r0) : uint256(r1);
```

---

### 21. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 166 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    163 |     }
    164 |     function withdrawBNB(uint256 amount) external {
    165 |         if (msg.sender != owner) revert E();
>>  166 |         (bool success, ) = payable(owner).call{value: amount}("");
    167 |         if (!success) revert E();
    168 |     }
    169 | }
```

---

### 22. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 814 行
- **函数**: `_executeSwapAndBurn()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    811 |             uint256 bnbReceived = address(_tokenReceiver).balance - bnbBefore;
    812 |             if (bnbReceived > 0) {
    813 |                 try _tokenReceiver.withdrawBNB(bnbReceived) {
>>  814 |                     (bool success, ) = user.call{value: bnbReceived}("");
    815 |                     if (!success) revert E();
    816 |                 } catch {
    817 |                     revert E();
```

---

### 23. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 961 行
- **函数**: `deposit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    958 |                 curUpline = next;
    959 |             }
    960 | 
>>  961 |             (bool okPay, ) = payable(receiver).call{value: fivePercent}("");
    962 |             if (!okPay && foundLeader) {
    963 |                 (okPay, ) = payable(fallbackReceiver).call{value: fivePercent}(
    964 |                     ""
```

---

### 24. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 963 行
- **函数**: `deposit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    960 | 
    961 |             (bool okPay, ) = payable(receiver).call{value: fivePercent}("");
    962 |             if (!okPay && foundLeader) {
>>  963 |                 (okPay, ) = payable(fallbackReceiver).call{value: fivePercent}(
    964 |                     ""
    965 |                 );
    966 |             }
```

---

### 25. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 990 行
- **函数**: `deposit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    987 |             }
    988 | 
    989 |             if (remainingReward > 0) {
>>  990 |                 (bool success, ) = communityFund.call{value: remainingReward}(
    991 |                     ""
    992 |                 );
    993 |                 success;
```

---

### 26. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 999 行
- **函数**: `deposit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    996 | 
    997 |         {
    998 |             uint256 nodePart = (bnb * 5) / 100;
>>  999 |             (bool success2, ) = bigNodeNFT.call{value: nodePart / 2}("");
   1000 |             if (!success2) revert E();
   1001 |             (bool success3, ) = smallNodeNFT.call{
   1002 |                 value: nodePart - (nodePart / 2)
```

---

### 27. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1081 行
- **函数**: `_distributeReferral()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1078 |                     address target = userInfo[cur].isActive
   1079 |                         ? cur
   1080 |                         : communityFund;
>> 1081 |                     (bool success, ) = payable(target).call{value: perGen}("");
   1082 |                     if (!success) revert E();
   1083 |                     distributed += perGen;
   1084 |                 }
```

---

### 28. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1393 行
- **函数**: `processDailyLogic()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1390 | 
   1391 |         uint256 balance = address(this).balance;
   1392 |         if (balance > 0) {
>> 1393 |             (bool success, ) = communityFund.call{value: balance}("");
   1394 |             success;
   1395 |         }
   1396 |     }
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 7 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      4 | pragma solidity ^0.8.20;
      5 | 
      6 | interface IERC20 {
>>    7 |     function totalSupply() external view returns (uint256);
      8 |     function balanceOf(address account) external view returns (uint256);
      9 |     function transfer(
     10 |         address recipient,
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 8 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      5 | 
      6 | interface IERC20 {
      7 |     function totalSupply() external view returns (uint256);
>>    8 |     function balanceOf(address account) external view returns (uint256);
      9 |     function transfer(
     10 |         address recipient,
     11 |         uint256 amount
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 17 行
- **函数**: `approve()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     14 |         address owner,
     15 |         address spender
     16 |     ) external view returns (uint256);
>>   17 |     function approve(address spender, uint256 amount) external returns (bool);
     18 |     function transferFrom(
     19 |         address sender,
     20 |         address recipient,
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 32 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     29 | }
     30 | 
     31 | interface IERC721 {
>>   32 |     function balanceOf(address owner) external view returns (uint256);
     33 | }
     34 | 
     35 | interface IPancakeRouter01 {
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 36 行
- **函数**: `factory()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     33 | }
     34 | 
     35 | interface IPancakeRouter01 {
>>   36 |     function factory() external pure returns (address);
     37 |     function WETH() external pure returns (address);
     38 |     function addLiquidityETH(
     39 |         address token,
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 37 行
- **函数**: `WETH()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     34 | 
     35 | interface IPancakeRouter01 {
     36 |     function factory() external pure returns (address);
>>   37 |     function WETH() external pure returns (address);
     38 |     function addLiquidityETH(
     39 |         address token,
     40 |         uint amountTokenDesired,
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 81 行
- **函数**: `token0()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     78 |         view
     79 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     80 |     function sync() external;
>>   81 |     function token0() external view returns (address);
     82 | }
     83 | 
     84 | interface IOkOldState {
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 85 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     82 | }
     83 | 
     84 | interface IOkOldState {
>>   85 |     function balanceOf(address account) external view returns (uint256);
     86 |     function referrer(address user) external view returns (address);
     87 |     function referralCount(address user) external view returns (uint256);
     88 |     function validDirects(address user) external view returns (uint256);
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 86 行
- **函数**: `referrer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     83 | 
     84 | interface IOkOldState {
     85 |     function balanceOf(address account) external view returns (uint256);
>>   86 |     function referrer(address user) external view returns (address);
     87 |     function referralCount(address user) external view returns (uint256);
     88 |     function validDirects(address user) external view returns (uint256);
     89 |     function totalDirectPerformance(
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 87 行
- **函数**: `referralCount()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     84 | interface IOkOldState {
     85 |     function balanceOf(address account) external view returns (uint256);
     86 |     function referrer(address user) external view returns (address);
>>   87 |     function referralCount(address user) external view returns (uint256);
     88 |     function validDirects(address user) external view returns (uint256);
     89 |     function totalDirectPerformance(
     90 |         address user
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 88 行
- **函数**: `validDirects()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     85 |     function balanceOf(address account) external view returns (uint256);
     86 |     function referrer(address user) external view returns (address);
     87 |     function referralCount(address user) external view returns (uint256);
>>   88 |     function validDirects(address user) external view returns (uint256);
     89 |     function totalDirectPerformance(
     90 |         address user
     91 |     ) external view returns (uint256);
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 92 行
- **函数**: `teamPerformance()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     89 |     function totalDirectPerformance(
     90 |         address user
     91 |     ) external view returns (uint256);
>>   92 |     function teamPerformance(address user) external view returns (uint256);
     93 |     function isDirectAdded(
     94 |         address upline,
     95 |         address user
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 134 行
- **函数**: `owner()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    131 |         _transferOwnership(_msgSender());
    132 |     }
    133 | 
>>  134 |     function owner() public view virtual returns (address) {
    135 |         return _owner;
    136 |     }
    137 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 160 行
- **函数**: `withdrawToken()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    157 |         owner = msg.sender;
    158 |     }
    159 |     receive() external payable {}
>>  160 |     function withdrawToken(address token, uint256 amount) external {
    161 |         if (msg.sender != owner) revert E();
    162 |         IERC20(token).transfer(owner, amount);
    163 |     }
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 164 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    161 |         if (msg.sender != owner) revert E();
    162 |         IERC20(token).transfer(owner, amount);
    163 |     }
>>  164 |     function withdrawBNB(uint256 amount) external {
    165 |         if (msg.sender != owner) revert E();
    166 |         (bool success, ) = payable(owner).call{value: amount}("");
    167 |         if (!success) revert E();
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 404 行
- **函数**: `name()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    401 |         );
    402 |     }
    403 | 
>>  404 |     function name() public view returns (string memory) {
    405 |         return _name;
    406 |     }
    407 |     function symbol() public view returns (string memory) {
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 407 行
- **函数**: `symbol()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    404 |     function name() public view returns (string memory) {
    405 |         return _name;
    406 |     }
>>  407 |     function symbol() public view returns (string memory) {
    408 |         return _symbol;
    409 |     }
    410 |     function decimals() public view returns (uint8) {
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 410 行
- **函数**: `decimals()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    407 |     function symbol() public view returns (string memory) {
    408 |         return _symbol;
    409 |     }
>>  410 |     function decimals() public view returns (uint8) {
    411 |         return _decimals;
    412 |     }
    413 |     function totalSupply() public view override returns (uint256) {
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 413 行
- **函数**: `totalSupply()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    410 |     function decimals() public view returns (uint8) {
    411 |         return _decimals;
    412 |     }
>>  413 |     function totalSupply() public view override returns (uint256) {
    414 |         return _totalSupply;
    415 |     }
    416 |     function balanceOf(address account) public view override returns (uint256) {
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 416 行
- **函数**: `balanceOf()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    413 |     function totalSupply() public view override returns (uint256) {
    414 |         return _totalSupply;
    415 |     }
>>  416 |     function balanceOf(address account) public view override returns (uint256) {
    417 |         return _balances[account];
    418 |     }
    419 |     function allowance(
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 874 行
- **函数**: `deposit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    871 |         deposit();
    872 |     }
    873 | 
>>  874 |     function deposit() public payable lockTheSwap noReentrant {
    875 |         if (msg.value < minDeposit || msg.value > maxDeposit) revert E();
    876 |         if (referrer[msg.sender] == address(0)) revert E();
    877 | 
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1100 行
- **函数**: `getDailyRate()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1097 |         }
   1098 |     }
   1099 | 
>> 1100 |     function getDailyRate(address user) public view returns (uint256) {
   1101 |         if (
   1102 |             _safeERC721Balance(bigNodeNFT, user) > 0 ||
   1103 |             _safeERC721Balance(smallNodeNFT, user) > 0
```

---

### 51. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 123 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    118 |     function _msgSender() internal view virtual returns (address) {
    119 |         return msg.sender;
    120 |     }
    121 | }
    122 | 
>>  123 | abstract contract Ownable is Context {
    124 |     address private _owner;
    125 |     event OwnershipTransferred(
    126 |         address indexed previousOwner,
    127 |         address indexed newOwner
    128 |     );
```

---

### 52. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 154 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    149 |         _owner = newOwner;
    150 |         emit OwnershipTransferred(oldOwner, newOwner);
    151 |     }
    152 | }
    153 | 
>>  154 | contract TokenReceiver {
    155 |     address public owner;
    156 |     constructor() {
    157 |         owner = msg.sender;
    158 |     }
    159 |     receive() external payable {}
```

---

### 53. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 171 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    166 |         (bool success, ) = payable(owner).call{value: amount}("");
    167 |         if (!success) revert E();
    168 |     }
    169 | }
    170 | 
>>  171 | contract OK is Context, IERC20, Ownable {
    172 |     mapping(address => uint256) private _balances;
    173 |     mapping(address => mapping(address => uint256)) private _allowances;
    174 | 
    175 |     string private _name = "HLOK";
    176 |     string private _symbol = "HLOK";
```

---

### 54. 🟢 [LOW] missing-zero-check

- **状态**: ❓ 待确认
- **位置**: `../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol` 第 943 行
- **扫描工具**: slither
- **综合评分**: 0.393

**工具描述**: OK.deposit().fallbackReceiver (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#943) lacks a zero-check on :
		- (okPay,None) = address(fallbackReceiver).call{value: fivePercent}() (../../../tmp/slither_scan_8bf8wbmj/0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315.sol#963-965)

**代码片段**:
```solidity
    940 |         {
    941 |             uint256 fivePercent = (bnb * 5) / 100;
    942 |             address directUpline = referrer[user];
>>  943 |             address fallbackReceiver = user;
    944 |             if (directUpline != address(0)) {
    945 |                 fallbackReceiver = directUpline;
    946 |             }
```

---

### 55. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 294 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    291 |         isFeeExempt[bigNodeNFT] = true;
    292 |         isFeeExempt[smallNodeNFT] = true;
    293 | 
>>  294 |         lastDailyProcess = block.timestamp;
    295 |         launchTime = block.timestamp;
    296 |     }
    297 | 
```

---

### 56. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 295 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    292 |         isFeeExempt[smallNodeNFT] = true;
    293 | 
    294 |         lastDailyProcess = block.timestamp;
>>  295 |         launchTime = block.timestamp;
    296 |     }
    297 | 
    298 |     function setLeader(address leader, bool enabled) external onlyOwner {
```

---

### 57. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 354 行
- **函数**: `migrateUsers()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    351 |                 depositUSDT,
    352 |                 lastDepositBNB,
    353 |                 desiredBal < 1e18 && isActive ? 0 : payoutUSDT,
>>  354 |                 block.timestamp,
    355 |                 isActive,
    356 |                 exitCount,
    357 |                 lastExitTime,
```

---

### 58. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 395 行
- **函数**: `setUserInfoSingle()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    392 |             depositUSDT,
    393 |             lastDepositBNB,
    394 |             payoutUSDT,
>>  395 |             lastClaimTime == 0 ? block.timestamp : lastClaimTime,
    396 |             isActive,
    397 |             exitCount,
    398 |             lastExitTime,
```

---

### 59. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 483 行
- **函数**: `_transfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    480 |             }
    481 |         }
    482 |         if (
>>  483 |             block.timestamp >= lastDailyProcess + TIME_STEP &&
    484 |             !inSwap &&
    485 |             recipient != pair &&
    486 |             sender != pair
```

---

### 60. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 603 行
- **函数**: `_enforceBlockAndCooldown()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    600 | 
    601 |         if (!isFeeExempt[trader]) {
    602 |             uint256 t = lastTradeTime[trader];
>>  603 |             if (t != 0 && block.timestamp < t + 60) revert E();
    604 | 
    605 |             uint256 b = lastTradeBlock[trader];
    606 |             uint8 s = lastTradeSide[trader];
```

---

### 61. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 609 行
- **函数**: `_enforceBlockAndCooldown()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    606 |             uint8 s = lastTradeSide[trader];
    607 |             if (b == block.number && s != 0 && s != side) revert E();
    608 | 
>>  609 |             lastTradeTime[trader] = block.timestamp;
    610 |             lastTradeBlock[trader] = block.number;
    611 |             lastTradeSide[trader] = side;
    612 |         }
```

---

### 62. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 623 行
- **函数**: `_enforceBlockAndCooldown()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    620 |             !isFeeExempt[origin]
    621 |         ) {
    622 |             uint256 ot = lastOriginTradeTime[origin];
>>  623 |             if (ot != 0 && block.timestamp < ot + 60) revert E();
    624 | 
    625 |             uint256 ob = lastOriginTradeBlock[origin];
    626 |             uint8 os = lastOriginTradeSide[origin];
```

---

### 63. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 629 行
- **函数**: `_enforceBlockAndCooldown()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    626 |             uint8 os = lastOriginTradeSide[origin];
    627 |             if (ob == block.number && os != 0 && os != side) revert E();
    628 | 
>>  629 |             lastOriginTradeTime[origin] = block.timestamp;
    630 |             lastOriginTradeBlock[origin] = block.number;
    631 |             lastOriginTradeSide[origin] = side;
    632 |         }
```

---

### 64. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 721 行
- **函数**: `_checkDailyLimit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    718 |     function _checkDailyLimit(address user, uint256 amount) internal {
    719 |         uint256 limitRate = getSellLimitRate(user);
    720 | 
>>  721 |         uint256 day = block.timestamp / TIME_STEP;
    722 |         if (lastSellDay[user] != day) {
    723 |             dailySold[user] = 0;
    724 |             lastSellDay[user] = day;
```

---

### 65. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 737 行
- **函数**: `_checkDailySellUsdtLimit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    734 |         address user,
    735 |         uint256 sellValueUSDT
    736 |     ) internal {
>>  737 |         uint256 day = block.timestamp / TIME_STEP;
    738 |         if (lastSellDayUSDT[user] != day) {
    739 |             dailySoldUSDT[user] = 0;
    740 |             lastSellDayUSDT[user] = day;
```

---

### 66. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 808 行
- **函数**: `_executeSwapAndBurn()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    805 |                     minOut,
    806 |                     path,
    807 |                     address(_tokenReceiver),
>>  808 |                     block.timestamp
    809 |                 )
    810 |         {
    811 |             uint256 bnbReceived = address(_tokenReceiver).balance - bnbBefore;
```

---

### 67. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 897 行
- **函数**: `deposit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    894 |             u.depositUSDT = (msg.value * bnbPrice) / 1e18;
    895 |         }
    896 |         u.isActive = true;
>>  897 |         u.lastClaimTime = block.timestamp;
    898 |         u.payoutUSDT = 0;
    899 | 
    900 |         {
```

---

### 68. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1033 行
- **函数**: `_processLiquidityAndBuy()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1030 |             minBuyOut,
   1031 |             path,
   1032 |             address(_tokenReceiver),
>> 1033 |             block.timestamp
   1034 |         );
   1035 | 
   1036 |         uint256 bought = balanceOf(address(_tokenReceiver)) - rBalBefore;
```

---

### 69. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1049 行
- **函数**: `_processLiquidityAndBuy()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1046 |                 0,
   1047 |                 0,
   1048 |                 DEAD,
>> 1049 |                 block.timestamp
   1050 |             );
   1051 | 
   1052 |             uint256 balEnd = balanceOf(address(this));
```

---

### 70. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1108 行
- **函数**: `getDailyRate()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1105 |             return 300;
   1106 |         }
   1107 |         if (launchTime > 0) {
>> 1108 |             uint256 daysSinceLaunch = (block.timestamp - launchTime) /
   1109 |                 TIME_STEP;
   1110 |             uint256 increase = daysSinceLaunch * 2;
   1111 |             uint256 rate = 100 + increase;
```

---

### 71. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1132 行
- **函数**: `_claim()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1129 |     function _claim(address user) internal noReentrant {
   1130 |         UserInfo storage u = userInfo[user];
   1131 |         if (!u.isActive) return;
>> 1132 |         if (u.lastClaimTime > block.timestamp) {
   1133 |             u.lastClaimTime = block.timestamp;
   1134 |             return;
   1135 |         }
```

---

### 72. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1133 行
- **函数**: `_claim()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1130 |         UserInfo storage u = userInfo[user];
   1131 |         if (!u.isActive) return;
   1132 |         if (u.lastClaimTime > block.timestamp) {
>> 1133 |             u.lastClaimTime = block.timestamp;
   1134 |             return;
   1135 |         }
   1136 | 
```

---

### 73. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1137 行
- **函数**: `_claim()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1134 |             return;
   1135 |         }
   1136 | 
>> 1137 |         uint256 elapsed = block.timestamp - u.lastClaimTime;
   1138 |         uint256 daysPassed = elapsed / TIME_STEP;
   1139 |         if (daysPassed == 0) return;
   1140 | 
```

---

### 74. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1177 行
- **函数**: `_handleExit()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1174 |         UserInfo storage u = userInfo[user];
   1175 |         u.isActive = false;
   1176 |         u.exitCount++;
>> 1177 |         u.lastExitTime = block.timestamp;
   1178 |         u.sellRateBonus = 0;
   1179 | 
   1180 |         address upline = referrer[user];
```

---

### 75. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1359 行
- **函数**: `processDailyLogic()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1356 |     }
   1357 | 
   1358 |     function processDailyLogic() internal {
>> 1359 |         uint256 elapsed = block.timestamp - lastDailyProcess;
   1360 |         uint256 daysToProcess = elapsed / TIME_STEP;
   1361 |         if (daysToProcess == 0) revert E();
   1362 |         lastDailyProcess += daysToProcess * TIME_STEP;
```

---

### 76. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1447 行
- **函数**: `_calculatePanicFee()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1444 |     ) internal returns (uint256) {
   1445 |         if (amount == 0 || currentPrice == 0) return 0;
   1446 | 
>> 1447 |         uint256 step = block.timestamp / TIME_STEP;
   1448 |         if (lastStepUpdate != step || stepStartPrice == 0) {
   1449 |             lastStepUpdate = step;
   1450 |             stepStartPrice = currentPrice;
```

---

### 77. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1476 行
- **函数**: `getSellLimitRate()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1473 |         }
   1474 |         if (!u.isActive && u.lastExitTime > 0) {
   1475 |             uint256 period = TIME_STEP * 30;
>> 1476 |             if (period > 0 && block.timestamp >= u.lastExitTime + period) {
   1477 |                 uint256 dec = (block.timestamp - u.lastExitTime) / period;
   1478 |                 if (baseRate > dec) baseRate -= dec;
   1479 |                 else baseRate = 1;
```

---

### 78. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1477 行
- **函数**: `getSellLimitRate()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1474 |         if (!u.isActive && u.lastExitTime > 0) {
   1475 |             uint256 period = TIME_STEP * 30;
   1476 |             if (period > 0 && block.timestamp >= u.lastExitTime + period) {
>> 1477 |                 uint256 dec = (block.timestamp - u.lastExitTime) / period;
   1478 |                 if (baseRate > dec) baseRate -= dec;
   1479 |                 else baseRate = 1;
   1480 |             }
```

---

### 79. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1522 行
- **函数**: `_swapAndLiquify()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1519 |                 minOut,
   1520 |                 path,
   1521 |                 address(_tokenReceiver),
>> 1522 |                 block.timestamp
   1523 |             )
   1524 |         {
   1525 |             uint256 bnbGain = address(_tokenReceiver).balance;
```

---

### 80. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 1537 行
- **函数**: `_swapAndLiquify()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1534 |                     0,
   1535 |                     0,
   1536 |                     DEAD,
>> 1537 |                     block.timestamp
   1538 |                 )
   1539 |             {} catch {}
   1540 |             uint256 bnbLeft = address(this).balance;
```

---

### 81. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 162 行
- **函数**: `withdrawToken()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    159 |     receive() external payable {}
    160 |     function withdrawToken(address token, uint256 amount) external {
    161 |         if (msg.sender != owner) revert E();
>>  162 |         IERC20(token).transfer(owner, amount);
    163 |     }
    164 |     function withdrawBNB(uint256 amount) external {
    165 |         if (msg.sender != owner) revert E();
```

---

### 82. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 607 行
- **函数**: `_enforceBlockAndCooldown()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    604 | 
    605 |             uint256 b = lastTradeBlock[trader];
    606 |             uint8 s = lastTradeSide[trader];
>>  607 |             if (b == block.number && s != 0 && s != side) revert E();
    608 | 
    609 |             lastTradeTime[trader] = block.timestamp;
    610 |             lastTradeBlock[trader] = block.number;
```

---

### 83. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 610 行
- **函数**: `_enforceBlockAndCooldown()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    607 |             if (b == block.number && s != 0 && s != side) revert E();
    608 | 
    609 |             lastTradeTime[trader] = block.timestamp;
>>  610 |             lastTradeBlock[trader] = block.number;
    611 |             lastTradeSide[trader] = side;
    612 |         }
    613 | 
```

---

### 84. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 627 行
- **函数**: `_enforceBlockAndCooldown()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    624 | 
    625 |             uint256 ob = lastOriginTradeBlock[origin];
    626 |             uint8 os = lastOriginTradeSide[origin];
>>  627 |             if (ob == block.number && os != 0 && os != side) revert E();
    628 | 
    629 |             lastOriginTradeTime[origin] = block.timestamp;
    630 |             lastOriginTradeBlock[origin] = block.number;
```

---

### 85. 🟢 [LOW] block-number-dependence

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 630 行
- **函数**: `_enforceBlockAndCooldown()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.347

**工具描述**: 依赖 block.number，可能在分叉或重组时产生意外行为。

**代码片段**:
```solidity
    627 |             if (ob == block.number && os != 0 && os != side) revert E();
    628 | 
    629 |             lastOriginTradeTime[origin] = block.timestamp;
>>  630 |             lastOriginTradeBlock[origin] = block.number;
    631 |             lastOriginTradeSide[origin] = side;
    632 |         }
    633 |     }
```

---

### 86. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 184 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    181 |     uint256 private constant INITIAL_LP = 700000 * 1e18;
    182 | 
    183 |     address private constant ROUTER =
>>  184 |         0x10ED43C718714eb63d5aA57B78B54704E256024E;
    185 |     address private constant USDT = 0x55d398326f99059fF775485246999027B3197955;
    186 |     address private constant DEAD = 0x000000000000000000000000000000000000dEaD;
    187 | 
```

---

### 87. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 185 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    182 | 
    183 |     address private constant ROUTER =
    184 |         0x10ED43C718714eb63d5aA57B78B54704E256024E;
>>  185 |     address private constant USDT = 0x55d398326f99059fF775485246999027B3197955;
    186 |     address private constant DEAD = 0x000000000000000000000000000000000000dEaD;
    187 | 
    188 |     address private constant communityFund  = 0x9Ab091113EF489d9506a517d8f04347BD3a170d6;
```

---

### 88. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 186 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    183 |     address private constant ROUTER =
    184 |         0x10ED43C718714eb63d5aA57B78B54704E256024E;
    185 |     address private constant USDT = 0x55d398326f99059fF775485246999027B3197955;
>>  186 |     address private constant DEAD = 0x000000000000000000000000000000000000dEaD;
    187 | 
    188 |     address private constant communityFund  = 0x9Ab091113EF489d9506a517d8f04347BD3a170d6;
    189 |     address private constant bigNodeNFT     = 0x3013013C78302D01D822E2645d441F035e8845dD;
```

---

### 89. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 188 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    185 |     address private constant USDT = 0x55d398326f99059fF775485246999027B3197955;
    186 |     address private constant DEAD = 0x000000000000000000000000000000000000dEaD;
    187 | 
>>  188 |     address private constant communityFund  = 0x9Ab091113EF489d9506a517d8f04347BD3a170d6;
    189 |     address private constant bigNodeNFT     = 0x3013013C78302D01D822E2645d441F035e8845dD;
    190 |     address private constant smallNodeNFT   = 0xd26164c723aA921720EfE977a4c4aEe3f19eD52C;
    191 | 
```

---

### 90. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 189 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    186 |     address private constant DEAD = 0x000000000000000000000000000000000000dEaD;
    187 | 
    188 |     address private constant communityFund  = 0x9Ab091113EF489d9506a517d8f04347BD3a170d6;
>>  189 |     address private constant bigNodeNFT     = 0x3013013C78302D01D822E2645d441F035e8845dD;
    190 |     address private constant smallNodeNFT   = 0xd26164c723aA921720EfE977a4c4aEe3f19eD52C;
    191 | 
    192 |     TokenReceiver private immutable _tokenReceiver;
```

---

### 91. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 190 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    187 | 
    188 |     address private constant communityFund  = 0x9Ab091113EF489d9506a517d8f04347BD3a170d6;
    189 |     address private constant bigNodeNFT     = 0x3013013C78302D01D822E2645d441F035e8845dD;
>>  190 |     address private constant smallNodeNFT   = 0xd26164c723aA921720EfE977a4c4aEe3f19eD52C;
    191 | 
    192 |     TokenReceiver private immutable _tokenReceiver;
    193 |     IPancakeRouter01 private immutable router;
```

---

### 92. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x5b2fEcDBDd9DDaebB894f0b3988210bDBc6BF315` 第 223 行
- **函数**: `withdrawBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    220 |     mapping(address => UserInfo) public userInfo;
    221 | 
    222 |     address private constant MIGRATION_SOURCE =
>>  223 |         0x2fAEFFD01624433464687e53B87872fBcFf666f3;
    224 |     mapping(address => bool) private migrated;
    225 | 
    226 |     mapping(address => bool) private isFeeExempt;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*