# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:42:00
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xB685760EBD368a891F27ae547391F4E2A289895b` |
| contract_name | `Bridgers` |
| compiler_version | `v0.8.4+commit.c7e474f2` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `istanbul` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['/contracts/Bridgers.sol', '/contracts/lib/TransferHelper.sol', '@openzeppelin/contracts/utils/math/SafeMath.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/security/ReentrancyGuard.sol', '@openzeppelin/contracts/access/Ownable.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107654512` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 13 |
| 🟢 LOW | 0 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 104 行
- **函数**: `safeApprove()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    101 | library TransferHelper {
    102 |     function safeApprove(address token, address to, uint value) internal {
    103 |         // bytes4(keccak256(bytes('approve(address,uint256)')));
>>  104 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x095ea7b3, to, value));
    105 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: APPROVE_FAILED');
    106 |     }
    107 | 
```

---

### 2. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 110 行
- **函数**: `safeTransfer()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    107 | 
    108 |     function safeTransfer(address token, address to, uint value) internal {
    109 |         // bytes4(keccak256(bytes('transfer(address,uint256)')));
>>  110 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
    111 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FAILED');
    112 |     }
    113 | 
```

---

### 3. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 116 行
- **函数**: `safeTransferFrom()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    113 | 
    114 |     function safeTransferFrom(address token, address from, address to, uint value) internal {
    115 |         // bytes4(keccak256(bytes('transferFrom(address,address,uint256)')));
>>  116 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x23b872dd, from, to, value));
    117 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FROM_FAILED');
    118 |     }
    119 | 
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 121 行
- **函数**: `safeTransferETH()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    118 |     }
    119 | 
    120 |     function safeTransferETH(address to, uint value) internal {
>>  121 |         (bool success,) = to.call{value:value}(new bytes(0));
    122 |         require(success, 'TransferHelper: ETH_TRANSFER_FAILED');
    123 |     }
    124 | }
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 397 行
- **函数**: `totalSupply()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    394 |     /**
    395 |      * @dev Returns the amount of tokens in existence.
    396 |      */
>>  397 |     function totalSupply() external view returns (uint256);
    398 | 
    399 |     /**
    400 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 402 行
- **函数**: `balanceOf()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    399 |     /**
    400 |      * @dev Returns the amount of tokens owned by `account`.
    401 |      */
>>  402 |     function balanceOf(address account) external view returns (uint256);
    403 | 
    404 |     /**
    405 |      * @dev Moves `amount` tokens from the caller's account to `recipient`.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 411 行
- **函数**: `transfer()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    408 |      *
    409 |      * Emits a {Transfer} event.
    410 |      */
>>  411 |     function transfer(address recipient, uint256 amount) external returns (bool);
    412 | 
    413 |     /**
    414 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 420 行
- **函数**: `allowance()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    417 |      *
    418 |      * This value changes when {approve} or {transferFrom} are called.
    419 |      */
>>  420 |     function allowance(address owner, address spender) external view returns (uint256);
    421 | 
    422 |     /**
    423 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 436 行
- **函数**: `approve()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    433 |      *
    434 |      * Emits an {Approval} event.
    435 |      */
>>  436 |     function approve(address spender, uint256 amount) external returns (bool);
    437 | 
    438 |     /**
    439 |      * @dev Moves `amount` tokens from `sender` to `recipient` using the
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 570 行
- **函数**: `owner()`
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    567 |     /**
    568 |      * @dev Returns the address of the current owner.
    569 |      */
>>  570 |     function owner() public view virtual returns (address) {
    571 |         return _owner;
    572 |     }
    573 | 
```

---

### 11. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 14 行
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      9 | import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
     10 | import "@openzeppelin/contracts/utils/math/SafeMath.sol";
     11 | import "./lib/TransferHelper.sol";
     12 | 
     13 | 
>>   14 | contract Bridgers is ReentrancyGuard, Ownable {
     15 |     using SafeMath for uint256;
     16 | 
     17 |     string public name;
     18 | 
     19 |     string public symbol;
```

---

### 12. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 513 行
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    508 |     constructor() {
    509 |         _status = _NOT_ENTERED;
    510 |     }
    511 | 
    512 |     /**
>>  513 |      * @dev Prevents a contract from calling itself, directly or indirectly.
    514 |      * Calling a `nonReentrant` function from another `nonReentrant`
    515 |      * function is not supported. It is possible to prevent this from happening
    516 |      * by making the `nonReentrant` function external, and make it call a
    517 |      * `private` function that does the actual work.
    518 |      */
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xB685760EBD368a891F27ae547391F4E2A289895b` 第 555 行
- **合约**: `Bridgers`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    550 |  *
    551 |  * This module is used through inheritance. It will make available the modifier
    552 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    553 |  * the owner.
    554 |  */
>>  555 | abstract contract Ownable is Context {
    556 |     address private _owner;
    557 | 
    558 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
    559 | 
    560 |     /**
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*