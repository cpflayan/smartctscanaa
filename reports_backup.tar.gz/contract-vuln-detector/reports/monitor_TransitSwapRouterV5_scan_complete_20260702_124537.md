# 智能合约安全审计报告

> 生成时间: 2026-07-02 12:45:37
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x07964f135f276412b3182a3B2407b8dd45000000` |
| contract_name | `TransitSwapRouterV5` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['TransitSwapRouterV5.sol', 'CrossRouter.sol', 'AggregateRouter.sol', 'UniswapV3Router.sol', 'UniswapV2Router.sol', 'BaseCore.sol', 'interfaces/IUniswapV3Pool.sol', 'interfaces/IUniswapV2.sol', 'interfaces/IERC20.sol', 'libs/Ownable.sol', 'libs/SafeMath.sol', 'libs/RevertReasonParser.sol', 'libs/TransferHelper.sol', 'libs/ReentrancyGuard.sol', 'libs/Pausable.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107638938` |

## 安全摘要

**整体风险等级**: UNKNOWN

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 50 |
| 🟢 LOW | 8 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 450 行
- **函数**: `_swapSupportingFeeOnTransferTokens()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    447 |             uint amountInput;
    448 |             uint amountOutput;
    449 |             { // scope to avoid stack too deep errors
>>  450 |                 (uint reserve0, uint reserve1,) = pair.getReserves();
    451 |                 (uint reserveInput, uint reserveOutput) = input == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
    452 |                 amountInput = IERC20(input).balanceOf(address(pair)).sub(reserveInput);
    453 |                 amountOutput = IUniswapV2(router).getAmountOut(amountInput, reserveInput, reserveOutput);
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 796 行
- **函数**: `getReserves()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    793 | interface IUniswapV2 {
    794 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    795 |     function getAmountsOut(uint amountIn, address[] memory path) external view returns (uint[] memory amounts);
>>  796 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    797 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    798 | }
    799 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 49 行
- **函数**: `cross()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     46 |         uint256 swapAmount = executeFunds(FunctionFlag.cross, desc.srcToken, desc.wrappedToken, desc.caller, desc.amount, desc.fee, desc.signature);
     47 | 
     48 |         {
>>   49 |             (bool success, bytes memory result) = desc.caller.call{value:swapAmount}(desc.calls);
     50 |             if (!success) {
     51 |                 revert(RevertReasonParser.parse(result, "TransitCrossV5:"));
     52 |             }
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1015 行
- **函数**: `safeApprove()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1012 |     
   1013 |     function safeApprove(address token, address to, uint value) internal {
   1014 |         // bytes4(keccak256(bytes('approve(address,uint256)')));
>> 1015 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x095ea7b3, to, value));
   1016 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: APPROVE_FAILED');
   1017 |     }
   1018 | 
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1021 行
- **函数**: `safeTransfer()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1018 | 
   1019 |     function safeTransfer(address token, address to, uint value) internal {
   1020 |         // bytes4(keccak256(bytes('transfer(address,uint256)')));
>> 1021 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
   1022 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_TOKEN_FAILED');
   1023 |     }
   1024 | 
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1027 行
- **函数**: `safeTransferWithoutRequire()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1024 | 
   1025 |     function safeTransferWithoutRequire(address token, address to, uint256 value) internal returns (bool) {
   1026 |         // bytes4(keccak256(bytes('transfer(address,uint256)')));
>> 1027 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
   1028 |         return (success && (data.length == 0 || abi.decode(data, (bool))));
   1029 |     }
   1030 | 
```

---

### 7. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1033 行
- **函数**: `safeTransferFrom()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1030 | 
   1031 |     function safeTransferFrom(address token, address from, address to, uint value) internal {
   1032 |         // bytes4(keccak256(bytes('transferFrom(address,address,uint256)')));
>> 1033 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x23b872dd, from, to, value));
   1034 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FROM_FAILED');
   1035 |     }
   1036 | 
```

---

### 8. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1039 行
- **函数**: `safeTransferETH()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1036 | 
   1037 |     function safeTransferETH(address to, uint value) internal {
   1038 |         // solium-disable-next-line
>> 1039 |         (bool success,) = to.call{value:value}(new bytes(0));
   1040 |         require(success, 'TransferHelper: TRANSFER_FAILED');
   1041 |     }
   1042 | 
```

---

### 9. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1045 行
- **函数**: `safeDeposit()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1042 | 
   1043 |     function safeDeposit(address wrapped, uint value) internal {
   1044 |         // bytes4(keccak256(bytes('deposit()')));
>> 1045 |         (bool success, bytes memory data) = wrapped.call{value:value}(abi.encodeWithSelector(0xd0e30db0));
   1046 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: DEPOSIT_FAILED');
   1047 |     }
   1048 | 
```

---

### 10. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1051 行
- **函数**: `safeWithdraw()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1048 | 
   1049 |     function safeWithdraw(address wrapped, uint value) internal {
   1050 |         // bytes4(keccak256(bytes('withdraw(uint256 wad)')));
>> 1051 |         (bool success, bytes memory data) = wrapped.call{value:0}(abi.encodeWithSelector(0x2e1a7d4d, value));
   1052 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: WITHDRAW_FAILED');
   1053 |     }
   1054 | }
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 13 行
- **函数**: `withdrawTokens()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     10 | 
     11 | contract TransitSwapRouterV5 is UniswapV2Router, UniswapV3Router, AggregateRouter, CrossRouter  {
     12 | 
>>   13 |     function withdrawTokens(address[] memory tokens, address recipient) external onlyExecutor {
     14 |         for (uint index; index < tokens.length; index++) {
     15 |             uint amount;
     16 |             if (TransferHelper.isETH(tokens[index])) {
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 75 行
- **函数**: `aggregateAndGasUsed()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     72 | 
     73 |     }
     74 | 
>>   75 |     function aggregateAndGasUsed(TransitSwapDescription calldata desc, CallbytesDescription calldata callbytesDesc) external payable returns (uint256 returnAmount, uint256 gasUsed) {
     76 |         uint256 gasLeftBefore = gasleft();
     77 |         returnAmount = _executeAggregate(desc, callbytesDesc);
     78 |         gasUsed = gasLeftBefore - gasleft();
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 81 行
- **函数**: `aggregate()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     78 |         gasUsed = gasLeftBefore - gasleft();
     79 |     }
     80 | 
>>   81 |     function aggregate(TransitSwapDescription calldata desc, CallbytesDescription calldata callbytesDesc) external payable returns (uint256 returnAmount) {
     82 |         returnAmount = _executeAggregate(desc, callbytesDesc);
     83 |     }
     84 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 178 行
- **函数**: `exactInputV3SwapAndGasUsed()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    175 |         TransferHelper.safeTransfer(tokenIn, msg.sender, amountToPay);
    176 |     }
    177 | 
>>  178 |     function exactInputV3SwapAndGasUsed(ExactInputV3SwapParams calldata params) external payable returns (uint256 returnAmount, uint256 gasUsed) {
    179 |         uint256 gasLeftBefore = gasleft();
    180 |         returnAmount = _executeV3Swap(params);
    181 |         gasUsed = gasLeftBefore - gasleft();
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 185 行
- **函数**: `exactInputV3Swap()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    182 | 
    183 |     }
    184 | 
>>  185 |     function exactInputV3Swap(ExactInputV3SwapParams calldata params) external payable returns (uint256 returnAmount) {
    186 |         returnAmount = _executeV3Swap(params);
    187 |     }
    188 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 379 行
- **函数**: `exactInputV2SwapAndGasUsed()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    376 |         paths = path;
    377 |     }
    378 | 
>>  379 |     function exactInputV2SwapAndGasUsed(ExactInputV2SwapParams calldata exactInput, uint256 deadline) external payable returns (uint256 returnAmount, uint256 gasUsed) {
    380 |         uint256 gasLeftBefore = gasleft();
    381 |         returnAmount = _executeV2Swap(exactInput, deadline);
    382 |         gasUsed = gasLeftBefore - gasleft();
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 385 行
- **函数**: `exactInputV2Swap()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    382 |         gasUsed = gasLeftBefore - gasleft();
    383 |     }
    384 | 
>>  385 |     function exactInputV2Swap(ExactInputV2SwapParams calldata exactInput, uint256 deadline) external payable returns (uint256 returnAmount) {
    386 |         returnAmount = _executeV2Swap(exactInput, deadline);
    387 |     }
    388 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 612 行
- **函数**: `changeFee()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    609 |         );
    610 |     }
    611 | 
>>  612 |     function changeFee(bool[] memory isAggregate, uint256[] memory newRate) external onlyExecutor {
    613 |         for (uint i; i < isAggregate.length; i++) {
    614 |             require(newRate[i] >= 0 && newRate[i] <= 1000, "fee rate is:0-1000");
    615 |             if (isAggregate[i]) {
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 624 行
- **函数**: `changeTransitProxy()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    621 |         }
    622 |     }
    623 | 
>>  624 |     function changeTransitProxy(address aggregator, address signer, address vault) external onlyExecutor {
    625 |         if (aggregator != address(0)) {
    626 |             _aggregate_bridge = aggregator;
    627 |             emit ChangeAggregateBridge(aggregator);
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 641 行
- **函数**: `changeAllowed()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    638 |         }
    639 |     }
    640 | 
>>  641 |     function changeAllowed(address[] calldata crossCallers, address[] calldata wrappedTokens) public onlyExecutor {
    642 |         if(crossCallers.length != 0){
    643 |             for (uint i; i < crossCallers.length; i++) {
    644 |                 _cross_caller_allowed[crossCallers[i]] = !_cross_caller_allowed[crossCallers[i]];
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 658 行
- **函数**: `changeUniswapV3FactoryAllowed()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    655 |         }
    656 |     }
    657 | 
>>  658 |     function changeUniswapV3FactoryAllowed(uint[] calldata poolIndex, address[] calldata factories, bytes[] calldata initCodeHash) public onlyExecutor {
    659 |         require(poolIndex.length == initCodeHash.length, "invalid data");
    660 |         require(factories.length == initCodeHash.length, "invalid data");
    661 |         uint len = factories.length;
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 668 行
- **函数**: `changePause()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    665 |         emit ChangeV3FactoryAllowed(poolIndex, factories, initCodeHash);
    666 |     }
    667 | 
>>  668 |     function changePause(bool paused, FunctionFlag[] calldata flags) external onlyExecutor {
    669 |         uint len = flags.length;
    670 |         for (uint i; i < len; i++) {
    671 |             if (paused) {
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 679 行
- **函数**: `transitProxyAddress()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    676 |         }
    677 |     }
    678 | 
>>  679 |     function transitProxyAddress() external view returns (address bridgeProxy, address feeSigner) {
    680 |         bridgeProxy = _aggregate_bridge;
    681 |         feeSigner = _fee_signer;
    682 |     }
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 684 行
- **函数**: `transitFee()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    681 |         feeSigner = _fee_signer;
    682 |     }
    683 | 
>>  684 |     function transitFee() external view returns (uint256, uint256, address) {
    685 |         return (_aggregate_fee, _cross_fee, _vault);
    686 |     }
    687 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 688 行
- **函数**: `transitAllowedQuery()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    685 |         return (_aggregate_fee, _cross_fee, _vault);
    686 |     }
    687 | 
>>  688 |     function transitAllowedQuery(address crossCaller, address wrappedToken, uint256 poolIndex) external view returns (bool isCrossCallerAllowed, bool isWrappedAllowed, UniswapV3Pool memory pool) {
    689 |         isCrossCallerAllowed = _cross_caller_allowed[crossCaller];
    690 |         isWrappedAllowed = _wrapped_allowed[wrappedToken];
    691 |         pool = _uniswapV3_factory_allowed[poolIndex];
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 776 行
- **函数**: `token0()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    773 | pragma solidity >=0.5.0;
    774 | 
    775 | interface IUniswapV3Pool {
>>  776 |     function token0() external view returns (address);
    777 |     function token1() external view returns (address);
    778 |     function fee() external view returns (uint24);
    779 |     function swap(
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 777 行
- **函数**: `token1()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    774 | 
    775 | interface IUniswapV3Pool {
    776 |     function token0() external view returns (address);
>>  777 |     function token1() external view returns (address);
    778 |     function fee() external view returns (uint24);
    779 |     function swap(
    780 |         address recipient,
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 778 行
- **函数**: `fee()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    775 | interface IUniswapV3Pool {
    776 |     function token0() external view returns (address);
    777 |     function token1() external view returns (address);
>>  778 |     function fee() external view returns (uint24);
    779 |     function swap(
    780 |         address recipient,
    781 |         bool zeroForOne,
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 794 行
- **函数**: `getAmountOut()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    791 | pragma solidity >=0.6.9;
    792 | 
    793 | interface IUniswapV2 {
>>  794 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    795 |     function getAmountsOut(uint amountIn, address[] memory path) external view returns (uint[] memory amounts);
    796 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    797 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 795 行
- **函数**: `getAmountsOut()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    792 | 
    793 | interface IUniswapV2 {
    794 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
>>  795 |     function getAmountsOut(uint amountIn, address[] memory path) external view returns (uint[] memory amounts);
    796 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    797 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    798 | }
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 796 行
- **函数**: `getReserves()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    793 | interface IUniswapV2 {
    794 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    795 |     function getAmountsOut(uint amountIn, address[] memory path) external view returns (uint[] memory amounts);
>>  796 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
    797 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
    798 | }
    799 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 807 行
- **函数**: `totalSupply()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    804 | 
    805 | interface IERC20 {
    806 |     
>>  807 |     function totalSupply() external view returns (uint256);
    808 |     function decimals() external view returns (uint8);
    809 |     function name() external view returns (string memory);
    810 |     function symbol() external view returns (string memory);
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 808 行
- **函数**: `decimals()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    805 | interface IERC20 {
    806 |     
    807 |     function totalSupply() external view returns (uint256);
>>  808 |     function decimals() external view returns (uint8);
    809 |     function name() external view returns (string memory);
    810 |     function symbol() external view returns (string memory);
    811 |     function balanceOf(address account) external view returns (uint256);
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 809 行
- **函数**: `name()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    806 |     
    807 |     function totalSupply() external view returns (uint256);
    808 |     function decimals() external view returns (uint8);
>>  809 |     function name() external view returns (string memory);
    810 |     function symbol() external view returns (string memory);
    811 |     function balanceOf(address account) external view returns (uint256);
    812 |     function transfer(address recipient, uint256 amount) external returns (bool);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 810 行
- **函数**: `symbol()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    807 |     function totalSupply() external view returns (uint256);
    808 |     function decimals() external view returns (uint8);
    809 |     function name() external view returns (string memory);
>>  810 |     function symbol() external view returns (string memory);
    811 |     function balanceOf(address account) external view returns (uint256);
    812 |     function transfer(address recipient, uint256 amount) external returns (bool);
    813 |     function allowance(address owner, address spender) external view returns (uint256);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 811 行
- **函数**: `balanceOf()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    808 |     function decimals() external view returns (uint8);
    809 |     function name() external view returns (string memory);
    810 |     function symbol() external view returns (string memory);
>>  811 |     function balanceOf(address account) external view returns (uint256);
    812 |     function transfer(address recipient, uint256 amount) external returns (bool);
    813 |     function allowance(address owner, address spender) external view returns (uint256);
    814 |     function approve(address spender, uint256 amount) external returns (bool);
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 812 行
- **函数**: `transfer()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    809 |     function name() external view returns (string memory);
    810 |     function symbol() external view returns (string memory);
    811 |     function balanceOf(address account) external view returns (uint256);
>>  812 |     function transfer(address recipient, uint256 amount) external returns (bool);
    813 |     function allowance(address owner, address spender) external view returns (uint256);
    814 |     function approve(address spender, uint256 amount) external returns (bool);
    815 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 813 行
- **函数**: `allowance()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    810 |     function symbol() external view returns (string memory);
    811 |     function balanceOf(address account) external view returns (uint256);
    812 |     function transfer(address recipient, uint256 amount) external returns (bool);
>>  813 |     function allowance(address owner, address spender) external view returns (uint256);
    814 |     function approve(address spender, uint256 amount) external returns (bool);
    815 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    816 |  
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 814 行
- **函数**: `approve()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    811 |     function balanceOf(address account) external view returns (uint256);
    812 |     function transfer(address recipient, uint256 amount) external returns (bool);
    813 |     function allowance(address owner, address spender) external view returns (uint256);
>>  814 |     function approve(address spender, uint256 amount) external returns (bool);
    815 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    816 |  
    817 | }
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 815 行
- **函数**: `transferFrom()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    812 |     function transfer(address recipient, uint256 amount) external returns (bool);
    813 |     function allowance(address owner, address spender) external view returns (uint256);
    814 |     function approve(address spender, uint256 amount) external returns (bool);
>>  815 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
    816 |  
    817 | }
    818 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 868 行
- **函数**: `executor()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    865 |     /**
    866 |      * @dev Returns the address of the current executor.
    867 |      */
>>  868 |     function executor() public view virtual returns (address) {
    869 |         return _executor;
    870 |     }
    871 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 875 行
- **函数**: `pendingExecutor()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    872 |     /**
    873 |      * @dev Returns the address of the pending executor.
    874 |      */
>>  875 |     function pendingExecutor() public view virtual returns (address) {
    876 |         return _pendingExecutor;
    877 |     }
    878 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 890 行
- **函数**: `transferExecutorship()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    887 |      * @dev Transfers executorship of the contract to a new account (`newExecutor`).
    888 |      * Can only be called by the current executor.
    889 |      */
>>  890 |     function transferExecutorship(address newExecutor) public virtual onlyExecutor {
    891 |         _pendingExecutor = newExecutor;
    892 |         emit ExecutorshipTransferStarted(executor(), newExecutor);
    893 |     }
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 902 行
- **函数**: `acceptExecutorship()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    899 |         emit ExecutorshipTransferred(oldExecutor, newExecutor);
    900 |     }
    901 | 
>>  902 |     function acceptExecutorship() external {
    903 |         address sender = msg.sender;
    904 |         require(pendingExecutor() == sender, "Ownable: caller is not the new executor");
    905 |         _transferExecutorship(sender);
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1197 行
- **函数**: `paused()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1194 |     /**
   1195 |      * @dev Returns true if the contract is paused, and false otherwise.
   1196 |      */
>> 1197 |     function paused(FunctionFlag flag) public view virtual returns (bool) {
   1198 |         return _paused[flag];
   1199 |     }
   1200 | 
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1239 行
- **函数**: `pausedOverAll()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1236 |         emit Unpaused(msg.sender, flag);
   1237 |     }
   1238 | 
>> 1239 |     function pausedOverAll() public view virtual returns (bool executeAggregate, bool executeV2Swap, bool executeV3Swap, bool cross) {
   1240 |         executeAggregate = _paused[FunctionFlag.executeAggregate];
   1241 |         executeV2Swap = _paused[FunctionFlag.executeV2Swap];
   1242 |         executeV3Swap = _paused[FunctionFlag.executeV3Swap];
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 11 行
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      6 | import "./UniswapV2Router.sol";
      7 | import "./UniswapV3Router.sol";
      8 | import "./AggregateRouter.sol";
      9 | import "./CrossRouter.sol";
     10 | 
>>   11 | contract TransitSwapRouterV5 is UniswapV2Router, UniswapV3Router, AggregateRouter, CrossRouter  {
     12 | 
     13 |     function withdrawTokens(address[] memory tokens, address recipient) external onlyExecutor {
     14 |         for (uint index; index < tokens.length; index++) {
     15 |             uint amount;
     16 |             if (TransferHelper.isETH(tokens[index])) {
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 479 行
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    474 | import "./interfaces/IERC20.sol";
    475 | import "./interfaces/IUniswapV2.sol";
    476 | import "./interfaces/IUniswapV3Pool.sol";
    477 | 
    478 | 
>>  479 | contract BaseCore is Ownable, Pausable, ReentrancyGuard {
    480 | 
    481 |     using SafeMath for uint256;
    482 | 
    483 |     struct ExactInputV2SwapParams {
    484 |         address dstReceiver;
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 839 行
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    834 |  *
    835 |  * This module is used through inheritance. It will make available the modifier
    836 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    837 |  * the owner.
    838 |  */
>>  839 | abstract contract Ownable {
    840 | 
    841 |     address private _executor;
    842 |     address private _pendingExecutor;
    843 |     bool internal _initialized;
    844 | 
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1149 行
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1144 |  * This module is used through inheritance. It will make available the
   1145 |  * modifiers `whenNotPaused` and `whenPaused`, which can be applied to
   1146 |  * the functions of your contract. Note that they will not be pausable by
   1147 |  * simply including this module, only once the modifiers are put in place.
   1148 |  */
>> 1149 | abstract contract Pausable {
   1150 |     /**
   1151 |      * @dev Emitted when the pause is triggered by `account`.
   1152 |      */
   1153 |     event Paused(address account, FunctionFlag flag);
   1154 | 
```

---

### 51. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 191 行
- **函数**: `_executeV3Swap()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    188 | 
    189 |     function _executeV3Swap(ExactInputV3SwapParams calldata params) internal nonReentrant whenNotPaused(FunctionFlag.executeV3Swap) returns (uint256 returnAmount) {
    190 |         require(params.pools.length > 0, "Empty pools");
>>  191 |         require(params.deadline >= block.timestamp, "Expired");
    192 |         require(_wrapped_allowed[params.wrappedToken], "Invalid wrapped address");
    193 |         address tokenIn = params.srcToken;
    194 |         address tokenOut = params.dstToken;
```

---

### 52. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 390 行
- **函数**: `_executeV2Swap()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    387 |     }
    388 | 
    389 |     function _executeV2Swap(ExactInputV2SwapParams calldata exactInput, uint256 deadline) internal nonReentrant whenNotPaused(FunctionFlag.executeV2Swap) returns (uint256 returnAmount) {
>>  390 |         require(deadline >= block.timestamp, "Expired");
    391 |         
    392 |         bool supportingFeeOn = exactInput.router >> 248 & 0xf == 1;
    393 |         {
```

---

### 53. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1006 行
- **函数**: `_toHex()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1003 | 
   1004 | library TransferHelper {
   1005 |     
>> 1006 |     address private constant _ETH_ADDRESS = address(0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE);
   1007 |     address private constant _ZERO_ADDRESS = address(0);
   1008 |     
   1009 |     function isETH(address token) internal pure returns (bool) {
```

---

### 54. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 710 行
- **函数**: `splitSignature()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    707 |     function splitSignature(bytes memory _signature) internal pure returns (uint8 v, bytes32 r, bytes32 s) {
    708 |         require(bytes(_signature).length == 65, "Invalid signature length");
    709 | 
>>  710 |         assembly {
    711 |             r := mload(add(_signature, 0x20))
    712 |             s := mload(add(_signature, 0x40))
    713 |             v := byte(0, mload(add(_signature, 0x60)))
```

---

### 55. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 954 行
- **函数**: `parse()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    951 |         if (data.length >= 68 && data[0] == "\x08" && data[1] == "\xc3" && data[2] == "\x79" && data[3] == "\xa0") {
    952 |             string memory reason;
    953 |             // solhint-disable no-inline-assembly
>>  954 |             assembly {
    955 |                 // 68 = 32 bytes data length + 4-byte selector + 32 bytes offset
    956 |                 reason := add(data, 68)
    957 |             }
```

---

### 56. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 972 行
- **函数**: `parse()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    969 |         else if (data.length == 36 && data[0] == "\x4e" && data[1] == "\x48" && data[2] == "\x7b" && data[3] == "\x71") {
    970 |             uint256 code;
    971 |             // solhint-disable no-inline-assembly
>>  972 |             assembly {
    973 |                 // 36 = 32 bytes data length + 4-byte selector
    974 |                 code := mload(add(data, 36))
    975 |             }
```

---

### 57. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1109 行
- **函数**: `safeWithdraw()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1106 |      */
   1107 |     modifier nonReentrant() {
   1108 |         require(_status != _ENTERED, "ReentrancyGuard: reentrant call");
>> 1109 |         assembly {
   1110 |             sstore(_status.slot, _ENTERED)
   1111 |         }
   1112 |         _;
```

---

### 58. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x07964f135f276412b3182a3B2407b8dd45000000` 第 1113 行
- **函数**: `safeWithdraw()`
- **合约**: `TransitSwapRouterV5`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1110 |             sstore(_status.slot, _ENTERED)
   1111 |         }
   1112 |         _;
>> 1113 |         assembly {
   1114 |             sstore(_status.slot, _NOT_ENTERED)
   1115 |         }
   1116 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*