# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:20:49
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` |
| contract_name | `OdyTransparentUpgradeableProxy` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `True` |
| implementation | `0xc770383134dee7dacf4ccdbde4fe838af0748862` |
| multi_file | `True` |
| source_files | `['npm/@openzeppelin/contracts@5.4.0/access/Ownable.sol', 'npm/@openzeppelin/contracts@5.4.0/interfaces/IERC1967.sol', 'npm/@openzeppelin/contracts@5.4.0/proxy/beacon/IBeacon.sol', 'npm/@openzeppelin/contracts@5.4.0/proxy/ERC1967/ERC1967Proxy.sol', 'npm/@openzeppelin/contracts@5.4.0/proxy/ERC1967/ERC1967Utils.sol', 'npm/@openzeppelin/contracts@5.4.0/proxy/Proxy.sol', 'npm/@openzeppelin/contracts@5.4.0/proxy/transparent/ProxyAdmin.sol', 'npm/@openzeppelin/contracts@5.4.0/proxy/transparent/TransparentUpgradeableProxy.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/Address.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/Context.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/Errors.sol', 'npm/@openzeppelin/contracts@5.4.0/utils/StorageSlot.sol', 'project/contracts/proxy/TransparentUpgradeableProxy.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646143` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 2 |
| 🟡 MEDIUM | 11 |
| 🟢 LOW | 4 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 410 行
- **函数**: `_delegate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    407 | 
    408 |             // Call the implementation.
    409 |             // out and outsize are 0 because we don't know the size yet.
>>  410 |             let result := delegatecall(gas(), implementation, 0, calldatasize(), 0, 0)
    411 | 
    412 |             // Copy the returned data.
    413 |             returndatacopy(0, 0, returndatasize())
```

---

### 2. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 720 行
- **函数**: `functionDelegateCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    717 |      * but performing a delegate call.
    718 |      */
    719 |     function functionDelegateCall(address target, bytes memory data) internal returns (bytes memory) {
>>  720 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    721 |         return verifyCallResultFromTarget(target, success, returndata);
    722 |     }
    723 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 661 行
- **函数**: `sendValue()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    658 |             revert Errors.InsufficientBalance(address(this).balance, amount);
    659 |         }
    660 | 
>>  661 |         (bool success, bytes memory returndata) = recipient.call{value: amount}("");
    662 |         if (!success) {
    663 |             _revert(returndata);
    664 |         }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 702 行
- **函数**: `functionCallWithValue()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    699 |         if (address(this).balance < value) {
    700 |             revert Errors.InsufficientBalance(address(this).balance, value);
    701 |         }
>>  702 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    703 |         return verifyCallResultFromTarget(target, success, returndata);
    704 |     }
    705 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 58 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     55 |     /**
     56 |      * @dev Returns the address of the current owner.
     57 |      */
>>   58 |     function owner() public view virtual returns (address) {
     59 |         return _owner;
     60 |     }
     61 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 149 行
- **函数**: `implementation()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    146 |      *
    147 |      * {UpgradeableBeacon} will check that this address is a contract.
    148 |      */
>>  149 |     function implementation() external view returns (address);
    150 | }
    151 | 
    152 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 520 行
- **函数**: `upgradeToAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    517 |  */
    518 | interface ITransparentUpgradeableProxy is IERC1967 {
    519 |     /// @dev See {UUPSUpgradeable-upgradeToAndCall}
>>  520 |     function upgradeToAndCall(address newImplementation, bytes calldata data) external payable;
    521 | }
    522 | 
    523 | /**
```

---

### 8. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 22 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     17 |  *
     18 |  * This module is used through inheritance. It will make available the modifier
     19 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     20 |  * the owner.
     21 |  */
>>   22 | abstract contract Ownable is Context {
     23 |     address private _owner;
     24 | 
     25 |     /**
     26 |      * @dev The caller account is not authorized to perform an operation.
     27 |      */
```

---

### 9. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 94 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     89 |         }
     90 |         _transferOwnership(newOwner);
     91 |     }
     92 | 
     93 |     /**
>>   94 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     95 |      * Internal function without access restriction.
     96 |      */
     97 |     function _transferOwnership(address newOwner) internal virtual {
     98 |         address oldOwner = _owner;
     99 |         _owner = newOwner;
```

---

### 10. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 164 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    159 | 
    160 | import {Proxy} from "../Proxy.sol";
    161 | import {ERC1967Utils} from "./ERC1967Utils.sol";
    162 | 
    163 | /**
>>  164 |  * @dev This contract implements an upgradeable proxy. It is upgradeable because calls are delegated to an
    165 |  * implementation address that can be changed. This address is stored in storage in the location specified by
    166 |  * https://eips.ethereum.org/EIPS/eip-1967[ERC-1967], so that it doesn't conflict with the storage layout of the
    167 |  * implementation behind the proxy.
    168 |  */
    169 | contract ERC1967Proxy is Proxy {
```

---

### 11. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 395 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    390 |  * Additionally, delegation to the implementation can be triggered manually through the {_fallback} function, or to a
    391 |  * different contract through the {_delegate} function.
    392 |  *
    393 |  * The success and return data of the delegated call will be returned back to the caller of the proxy.
    394 |  */
>>  395 | abstract contract Proxy {
    396 |     /**
    397 |      * @dev Delegates the current call to `implementation`.
    398 |      *
    399 |      * This function does not return to its internal call site, it will return directly to the external caller.
    400 |      */
```

---

### 12. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 465 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    460 | 
    461 | /**
    462 |  * @dev This is an auxiliary contract meant to be assigned as the admin of a {TransparentUpgradeableProxy}. For an
    463 |  * explanation of why you would want to use this see the documentation for {TransparentUpgradeableProxy}.
    464 |  */
>>  465 | contract ProxyAdmin is Ownable {
    466 |     /**
    467 |      * @dev The version of the upgrade interface of the contract. If this getter is missing, both `upgrade(address,address)`
    468 |      * and `upgradeAndCall(address,address,bytes)` are present, and `upgrade` must be used if no function should be called,
    469 |      * while `upgradeAndCall` will invoke the `receive` function if the third argument is the empty byte string.
    470 |      * If the getter returns `"5.0.0"`, only `upgradeAndCall(address,address,bytes)` is present, and the third argument must
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 563 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    558 |  * WARNING: It is not recommended to extend this contract to add additional external functions. If you do so, the
    559 |  * compiler will not check that there are no selector conflicts, due to the note above. A selector clash between any new
    560 |  * function and the functions declared in {ITransparentUpgradeableProxy} will be resolved in favor of the new one. This
    561 |  * could render the `upgradeToAndCall` function inaccessible, preventing upgradeability and compromising transparency.
    562 |  */
>>  563 | contract TransparentUpgradeableProxy is ERC1967Proxy {
    564 |     // An immutable address for the admin to avoid unnecessary SLOADs before each call
    565 |     // at the expense of removing the ability to change the admin once it's set.
    566 |     // This is acceptable if the admin is always a ProxyAdmin instance or similar contract
    567 |     // with its own ability to transfer the permissions to another account.
    568 |     address private immutable _admin;
```

---

### 14. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 219 行
- **函数**: `_implementation()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    216 |      * This is the keccak-256 hash of "eip1967.proxy.implementation" subtracted by 1.
    217 |      */
    218 |     // solhint-disable-next-line private-vars-leading-underscore
>>  219 |     bytes32 internal constant IMPLEMENTATION_SLOT = 0x360894a13ba1a3210667c828492db98dca3e2076cc3735a920a3ca505d382bbc;
    220 | 
    221 |     /**
    222 |      * @dev The `implementation` of the proxy is invalid.
```

---

### 15. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 281 行
- **函数**: `upgradeToAndCall()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    278 |      * This is the keccak-256 hash of "eip1967.proxy.admin" subtracted by 1.
    279 |      */
    280 |     // solhint-disable-next-line private-vars-leading-underscore
>>  281 |     bytes32 internal constant ADMIN_SLOT = 0xb53127684a568b3173ae13b9f8a6016e243e63b6e8ee1178d6a717850b5d6103;
    282 | 
    283 |     /**
    284 |      * @dev Returns the current admin.
```

---

### 16. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 319 行
- **函数**: `changeAdmin()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    316 |      * This is the keccak-256 hash of "eip1967.proxy.beacon" subtracted by 1.
    317 |      */
    318 |     // solhint-disable-next-line private-vars-leading-underscore
>>  319 |     bytes32 internal constant BEACON_SLOT = 0xa3f0ad74e5423aebfd80d3ef4346578335a9a72aeaee59ff6cb3582b35133d50;
    320 | 
    321 |     /**
    322 |      * @dev Returns the current beacon.
```

---

### 17. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xacBf546BC90A1DF9108a216846b6509e63CF6F7B` 第 402 行
- **函数**: `_delegate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    399 |      * This function does not return to its internal call site, it will return directly to the external caller.
    400 |      */
    401 |     function _delegate(address implementation) internal virtual {
>>  402 |         assembly {
    403 |             // Copy msg.data. We take full control of memory in this inline assembly
    404 |             // block because it will not return to Solidity code. We overwrite the
    405 |             // Solidity scratch pad at memory position 0.
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*