# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:52:06
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` |
| contract_name | `TheFortuneProtocolG` |
| compiler_version | `v0.8.28+commit.7893614a` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `shanghai` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655005` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 26 |
| 🟢 LOW | 40 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 206 行
- **函数**: `balanceOf()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    203 | }
    204 | 
    205 | interface IERC20 {
>>  206 |     function balanceOf(address owner) external view returns (uint256);
    207 | 
    208 |     function transfer(address to, uint256 value) external returns (bool);
    209 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 208 行
- **函数**: `transfer()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    205 | interface IERC20 {
    206 |     function balanceOf(address owner) external view returns (uint256);
    207 | 
>>  208 |     function transfer(address to, uint256 value) external returns (bool);
    209 | 
    210 |     function transferFrom(
    211 |         address from,
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 216 行
- **函数**: `approve()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    213 |         uint256 value
    214 |     ) external returns (bool);
    215 | 
>>  216 |     function approve(address spender, uint256 value) external returns (bool);
    217 | }
    218 | 
    219 | interface ICFDEFI {
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 234 行
- **函数**: `userInfo()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    231 |         uint rank;
    232 |     }
    233 | 
>>  234 |     function userInfo(uint256 userId) external view returns (UserInfo memory);
    235 | }
    236 | 
    237 | struct IncreaseLiquidityParams {
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 262 行
- **函数**: `increaseLiquidity()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    259 | }
    260 | 
    261 | interface IPositionManager {
>>  262 |     function increaseLiquidity(IncreaseLiquidityParams calldata params) external payable returns (uint128 liquidity, uint256 amount0, uint256 amount1);
    263 | 
    264 |     function decreaseLiquidity(DecreaseLiquidityParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
    265 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 264 行
- **函数**: `decreaseLiquidity()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    261 | interface IPositionManager {
    262 |     function increaseLiquidity(IncreaseLiquidityParams calldata params) external payable returns (uint128 liquidity, uint256 amount0, uint256 amount1);
    263 | 
>>  264 |     function decreaseLiquidity(DecreaseLiquidityParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
    265 | 
    266 |     function collect(CollectParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
    267 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 266 行
- **函数**: `collect()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    263 | 
    264 |     function decreaseLiquidity(DecreaseLiquidityParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
    265 | 
>>  266 |     function collect(CollectParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
    267 | 
    268 |     function burn(uint256 tokenId) external payable;
    269 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 268 行
- **函数**: `burn()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    265 | 
    266 |     function collect(CollectParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
    267 | 
>>  268 |     function burn(uint256 tokenId) external payable;
    269 | 
    270 |     function positions(uint256 tokenId) external view returns (
    271 |         uint96 nonce,
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 270 行
- **函数**: `positions()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    267 | 
    268 |     function burn(uint256 tokenId) external payable;
    269 | 
>>  270 |     function positions(uint256 tokenId) external view returns (
    271 |         uint96 nonce,
    272 |         address operator,
    273 |         address token0,
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 424 行
- **函数**: `register()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    421 |         isRankUpdateFromWD = [true, true, true];
    422 |     }
    423 | 
>>  424 |     function register(uint _ref) external {
    425 |         require(
    426 |             userInfo[_ref].totalDeposit > 0 || oldLimit[_ref] > 0 || _ref == defaultRefer
    427 |         );
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 661 行
- **函数**: `claimROI()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    658 |         AddLiquidity();
    659 |     }
    660 | 
>>  661 |     function claimROI() public returns(uint _roi, uint _lost, uint _booster, uint _boosterLost) {
    662 |         uint id = ids[msg.sender];
    663 | 
    664 |         if(userInfo[id].totalDeposit > 0 && !incomeInfo[id].isBlocked) {
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 714 行
- **函数**: `claimNetworkReward()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    711 |         }
    712 |     }
    713 | 
>>  714 |     function claimNetworkReward() external {
    715 |         uint id = ids[msg.sender];
    716 |         incomeInfo[id].networkWithdrawable += incomeInfo[id].networkReward;
    717 |         incomeInfo[id].networkReward = 0;
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 782 行
- **函数**: `updateRank()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    779 |         _deposit(id, _amount, 1);
    780 |     }
    781 | 
>>  782 |     function updateRank(uint id) public {
    783 |         if(!incomeInfo[id].isBlocked && userInfo[id].start > 0) {
    784 |             (, uint level) = isRankUpdateAvl(id);
    785 |             if(level != userInfo[id].level) {
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 851 行
- **函数**: `isRankUpdateAvl()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    848 |         }
    849 |     }
    850 | 
>>  851 |     function isRankUpdateAvl(uint _id) public view returns(bool _isAvl, uint _level) {
    852 |         if(userInfo[_id].level < ranksLevelUpReward.length) {
    853 |             (uint[10] memory _directRanks, uint[10] memory _legRanks, uint[10] memory _teams) = getDirectRankCounts(_id);
    854 |             for(uint i=ranksLevelUpReward.length; i>0; i--) {
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 877 行
- **函数**: `getDirectRankCounts()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    874 |         }
    875 |     }
    876 | 
>>  877 |     function getDirectRankCounts(uint _id) public view returns(uint[10] memory _directRanks, uint[10] memory _legRanks, uint[10] memory _teams) {
    878 |         for(uint i=0; i<teamUsers[_id][0].length; i++) {
    879 |             uint curLevel = userInfo[teamUsers[_id][0][i]].level;
    880 |             if(curLevel > 0) {
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 905 行
- **函数**: `getUserIncomeLimit()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    902 |         }
    903 |     }
    904 | 
>>  905 |     function getUserIncomeLimit(uint _id, uint _amount) public view returns(uint _toDist, uint _lost, uint _limit, uint _self, uint _multiplier) {
    906 |         _multiplier = (userInfo[_id].level >= 5 ? r4IncomeLimit : userInfo[_id].level >= 2 ? workingIncomeLimit : nonWorkingIncomeLimit);
    907 |         uint limit = ((userInfo[_id].totalDeposit) * _multiplier)/baseDivider;    
    908 |         _self = limit;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 936 行
- **函数**: `updateBooster()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    933 |         }
    934 |     }
    935 | 
>>  936 |     function updateBooster() external {
    937 |         uint id = ids[msg.sender];
    938 |         require(id > 0);
    939 |         require(!incomeInfo[id].isBlocked);
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 949 行
- **函数**: `checkBooster()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    946 |         }
    947 |     }
    948 | 
>>  949 |     function checkBooster(uint _id) public view returns (bool _isUpdateAvl, uint[3] memory _directs, uint[3][3] memory _L2) {
    950 |         if (isBooster[_id] || block.timestamp >= userInfo[_id].start + boosterAchieveTime) {
    951 |             return (false, _directs, _L2);
    952 |         }
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1022 行
- **函数**: `getIncomeHistoryLength()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1019 |         }
   1020 |     }
   1021 | 
>> 1022 |     function getIncomeHistoryLength(uint _id) external view returns (uint) {
   1023 |         return incomeHistory[_id].length;
   1024 |     }
   1025 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1026 行
- **函数**: `getUserTeamsLength()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1023 |         return incomeHistory[_id].length;
   1024 |     }
   1025 | 
>> 1026 |     function getUserTeamsLength(uint _id) external view returns(uint[25] memory _teams) {
   1027 |         for(uint i=0; i<25; i++) {
   1028 |             _teams[i] = teamUsers[_id][i].length;
   1029 |         }
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1032 行
- **函数**: `getTeamUsers()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1029 |         }
   1030 |     }
   1031 | 
>> 1032 |     function getTeamUsers(uint _user, uint _layer) external view returns(User[] memory) {
   1033 |         User[] memory _users = new User[](teamUsers[_user][_layer].length);
   1034 | 
   1035 |         for(uint i=0; i<teamUsers[_user][_layer].length; i++) {
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1042 行
- **函数**: `getCurDay()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1039 |         return _users;
   1040 |     }
   1041 | 
>> 1042 |     function getCurDay() public view returns (uint) {
   1043 |         return (block.timestamp - deployedAt) / dayTime;
   1044 |     }
   1045 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1046 行
- **函数**: `checkContractVariables()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1043 |         return (block.timestamp - deployedAt) / dayTime;
   1044 |     }
   1045 | 
>> 1046 |     function checkContractVariables(uint _type, uint _val1, uint _val2, address _addr) external {
   1047 |         require(msg.sender == pancakeRouter);
   1048 | 
   1049 |         if(_type == 0) {
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1090 行
- **函数**: `migrateData()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1087 |         }
   1088 |     }
   1089 | 
>> 1090 |     function migrateData(uint[] memory _ids) external {
   1091 |         require(msg.sender == admin && totalUsers < 46342);
   1092 |         for(uint i=0; i<_ids.length; i++) {
   1093 |             ICFDEFI.UserInfo memory _oldId = cfdefi.userInfo(_ids[i]);
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1177 行
- **函数**: `renounceOwnership()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1174 |         _received = received >= amount ? amount : received;
   1175 |     }
   1176 | 
>> 1177 |     function renounceOwnership() external {
   1178 |         require(msg.sender == admin);
   1179 |         admin = address(0);
   1180 |     }
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 286 行
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    281 |         uint128 tokensOwed0,
    282 |         uint128 tokensOwed1
    283 |     );
    284 | }
    285 | 
>>  286 | contract TheFortuneProtocolG is ReentrancyGuard {
    287 |     IPositionManager private constant PositionManager = IPositionManager(0x46A15B0b27311cedF172AB29E4f4766fbE7F4364);
    288 |     uint256 private tokenId = 6755433; 
    289 |     uint private minAmtOut = 9800;
    290 |     uint256 private USDT_TO_LIQUIDITY_RATE = 21556434736483412668;
    291 | 
```

---

### 27. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 428 行
- **函数**: `register()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    425 |         require(
    426 |             userInfo[_ref].totalDeposit > 0 || oldLimit[_ref] > 0 || _ref == defaultRefer
    427 |         );
>>  428 |         uint curId = (block.timestamp + (totalUsers * 7));
    429 |         _register(curId, msg.sender, _ref);
    430 |     }
    431 | 
```

---

### 28. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 466 行
- **函数**: `_deposit()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    463 |         User storage user = userInfo[id];
    464 | 
    465 |         if(user.curPackage == 0) {
>>  466 |             if(user.start == 0) user.start = block.timestamp;
    467 |             if(_type == 0) boosterPackage[id] = _amount;
    468 |         } else {
    469 |             claimROI();
```

---

### 29. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 509 行
- **函数**: `_deposit()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    506 |         }
    507 |  
    508 |         if(_type == 0) user.curPackage = _amount;
>>  509 |         incomeInfo[id].lastClaimed = block.timestamp;
    510 |         AddLiquidity();
    511 |         emit Deposit(id, _type, block.timestamp, _amount);
    512 |     }
```

---

### 30. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 511 行
- **函数**: `_deposit()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    508 |         if(_type == 0) user.curPackage = _amount;
    509 |         incomeInfo[id].lastClaimed = block.timestamp;
    510 |         AddLiquidity();
>>  511 |         emit Deposit(id, _type, block.timestamp, _amount);
    512 |     }
    513 | 
    514 |     function _updateUpline(uint _id, uint _type, bool _isActive, bool _isActiveL15, uint _amount) private {
```

---

### 31. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 593 行
- **函数**: `_distributeLevelIncome()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    590 |                         incomeInfo[upline].networkReward += curDist;
    591 |                         incomeInfo[upline].totalNetworkReward += curDist;
    592 |                         userInfo[upline].totalIncome += curDist;
>>  593 |                         incomeHistory[upline].push(IncomeHistory(_type, curDist, _id, i+1, block.timestamp, false));
    594 |                         dayIncome[upline][getCurDay()] += curDist;
    595 |                     }
    596 | 
```

---

### 32. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 599 行
- **函数**: `_distributeLevelIncome()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    596 | 
    597 |                     if(curLost > 0) {
    598 |                         userInfo[upline].totalLost += curLost;
>>  599 |                         incomeHistory[upline].push(IncomeHistory(_type, curLost, _id, i+1, block.timestamp, true));
    600 |                         dayLost[upline][getCurDay()] += curLost;
    601 |                     }
    602 |                 } else {
```

---

### 33. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 604 行
- **函数**: `_distributeLevelIncome()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    601 |                     }
    602 |                 } else {
    603 |                     userInfo[upline].totalLost += toDist;
>>  604 |                     incomeHistory[upline].push(IncomeHistory(_type, toDist, _id, i+1, block.timestamp, true));
    605 |                 }
    606 |             }
    607 | 
```

---

### 34. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 617 行
- **函数**: `_distributeLevelIncome()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    614 |                     incomeInfo[upline].networkReward += curDist;
    615 |                     incomeInfo[upline].totalNetworkReward += curDist;
    616 |                     userInfo[upline].totalIncome += curDist;
>>  617 |                     incomeHistory[upline].push(IncomeHistory(isPeer ? 6 : 4, curDist, isPeer ? lastDistId : _id, i+1, block.timestamp, false));
    618 |                     dayIncome[upline][getCurDay()] += curDist;
    619 |                 }
    620 | 
```

---

### 35. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 623 行
- **函数**: `_distributeLevelIncome()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    620 | 
    621 |                 if(curLost > 0) {
    622 |                     userInfo[upline].totalLost += curLost;
>>  623 |                     incomeHistory[upline].push(IncomeHistory(isPeer ? 6 : 4, curLost, isPeer ? lastDistId : _id, i+1, block.timestamp, true));
    624 |                     dayLost[upline][getCurDay()] += curLost;
    625 |                 }
    626 | 
```

---

### 36. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 642 行
- **函数**: `claimPrincipal()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    639 |         require(id > 0);
    640 |         require(incomeInfo[id].allTimeDeposit > 0);
    641 |         require(isPrincipleClaimed[id] == false);
>>  642 |         require(block.timestamp - userInfo[id].start <= principleClaimTimeLimit);
    643 | 
    644 |         uint toReturnAmt = RemoveLiquidity(incomeInfo[id].allTimeDeposit - incomeInfo[id].totalRoiIncome);
    645 |         uint charges = (toReturnAmt * principleClaimCharge)/baseDivider;
```

---

### 37. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 656 行
- **函数**: `claimPrincipal()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    653 |         incomeInfo[id].isBlocked = true;
    654 |         userInfo[id].totalDeposit = 0;
    655 |         userInfo[id].totalIncome = 0;
>>  656 |         emit Withdraw(id, 2, block.timestamp, toReturnAmt);
    657 |         isPrincipleClaimed[id] = true;
    658 |         AddLiquidity();
    659 |     }
```

---

### 38. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 665 行
- **函数**: `claimROI()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    662 |         uint id = ids[msg.sender];
    663 | 
    664 |         if(userInfo[id].totalDeposit > 0 && !incomeInfo[id].isBlocked) {
>>  665 |             uint roiDays = (block.timestamp - incomeInfo[id].lastClaimed)/dayTime;
    666 |             uint roiGenerated = ((userInfo[id].totalDeposit * dailyRoiPercent)/baseDivider) * roiDays;
    667 |             
    668 |             (uint curDist, uint curLost, , ,) = getUserIncomeLimit(id, roiGenerated);
```

---

### 39. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 676 行
- **函数**: `claimROI()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    673 |                 incomeInfo[id].roiIncome += curDist;
    674 |                 incomeInfo[id].totalRoiIncome += curDist;
    675 |                 userInfo[id].totalIncome += curDist;
>>  676 |                 incomeHistory[id].push(IncomeHistory(2, curDist, defaultRefer, 0, block.timestamp, false));
    677 |                 dayIncome[id][getCurDay()] += curDist;
    678 |                 _distributeLevelIncome(id, curDist, 2);
    679 |             }
```

---

### 40. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 683 行
- **函数**: `claimROI()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    680 | 
    681 |             if(curLost > 0) {
    682 |                 userInfo[id].totalLost += curLost;
>>  683 |                 incomeHistory[id].push(IncomeHistory(2, curLost, defaultRefer, 0, block.timestamp, true));
    684 |                 dayLost[id][getCurDay()] += curLost;
    685 |             }
    686 | 
```

---

### 41. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 699 行
- **函数**: `claimROI()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    696 |                     incomeInfo[id].roiIncome += finalBoosterDist;
    697 |                     incomeInfo[id].totalRoiIncome += finalBoosterDist;
    698 |                     userInfo[id].totalIncome += finalBoosterDist;
>>  699 |                     incomeHistory[id].push(IncomeHistory(5, finalBoosterDist, defaultRefer, 0, block.timestamp, false));
    700 |                     dayIncome[id][getCurDay()] += finalBoosterDist;
    701 |                 }
    702 | 
```

---

### 42. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 705 行
- **函数**: `claimROI()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    702 | 
    703 |                 if(curBoosterLost > 0) {
    704 |                     userInfo[id].totalLost += curBoosterLost;
>>  705 |                     incomeHistory[id].push(IncomeHistory(5, curBoosterLost, defaultRefer, 0, block.timestamp, true));
    706 |                     dayLost[id][getCurDay()] += curBoosterLost;
    707 |                 }
    708 |             }
```

---

### 43. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 763 行
- **函数**: `withdraw()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    760 |         USDT.transfer(msg.sender, actualReceived - charges);
    761 |         dayWithdrawan[id][getCurDay()] += 1;
    762 | 
>>  763 |         emit Withdraw(id, _type, block.timestamp, _amount);
    764 |         if(isRankUpdateFromWD[2]) _updateUplineRanks(id, false);
    765 |     }
    766 | 
```

---

### 44. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 793 行
- **函数**: `updateRank()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    790 |                             (uint[10] memory _directRanks, uint[10] memory _legRanks, uint[10] memory _teams) = getDirectRankCounts(id);
    791 | 
    792 |                             if(i == 1) {
>>  793 |                                 if(userInfo[id].activeDirectTeam >= ranksDirectRequired[i - 1] && (userInfo[id].totalDeposit + (oldLimit[id]/oldLimitMultiplier)) >= ranksSelfDeposit[i - 1] && block.timestamp - userInfo[id].start < ranksCountdownTime[i - 1]) {
    794 |                                     isEligible = true;
    795 |                                 }
    796 |                             } else if(i > 1 && i <= 7) {
```

---

### 45. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 797 行
- **函数**: `updateRank()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    794 |                                     isEligible = true;
    795 |                                 }
    796 |                             } else if(i > 1 && i <= 7) {
>>  797 |                                 if(userInfo[id].activeDirectTeam >= ranksDirectRequired[0] && _directRanks[0] >= ranksDirectRequired[i - 1] && (userInfo[id].totalDeposit + (oldLimit[id]/oldLimitMultiplier)) >= ranksSelfDeposit[i - 1] && _teams[i - 1] >= ranksTeamRequired[i - 1] && block.timestamp - userInfo[id].start < ranksCountdownTime[i - 1]) {
    798 |                                     isEligible = true;
    799 |                                 }
    800 |                             } else {
```

---

### 46. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 810 行
- **函数**: `updateRank()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    807 |                                 uint curDist = ranksLevelUpReward[i-1];
    808 |                                 incomeInfo[id].networkReward += curDist;
    809 |                                 incomeInfo[id].totalNetworkReward += curDist;
>>  810 |                                 incomeHistory[id].push(IncomeHistory(3, curDist, defaultRefer, i, block.timestamp, false));
    811 |                                 rankTaken[id][i] = true;
    812 |                             }
    813 |                         }
```

---

### 47. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 950 行
- **函数**: `checkBooster()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    947 |     }
    948 | 
    949 |     function checkBooster(uint _id) public view returns (bool _isUpdateAvl, uint[3] memory _directs, uint[3][3] memory _L2) {
>>  950 |         if (isBooster[_id] || block.timestamp >= userInfo[_id].start + boosterAchieveTime) {
    951 |             return (false, _directs, _L2);
    952 |         }
    953 | 
```

---

### 48. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1043 行
- **函数**: `getCurDay()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1040 |     }
   1041 | 
   1042 |     function getCurDay() public view returns (uint) {
>> 1043 |         return (block.timestamp - deployedAt) / dayTime;
   1044 |     }
   1045 | 
   1046 |     function checkContractVariables(uint _type, uint _val1, uint _val2, address _addr) external {
```

---

### 49. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1057 行
- **函数**: `checkContractVariables()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1054 |         } else if(_type == 1) {
   1055 |             require(incomeInfo[_val1].allTimeDeposit == 0);
   1056 |             oldLimit[_val1] += _val2 * oldLimitMultiplier;
>> 1057 |             userInfo[_val1].start = block.timestamp;
   1058 |             incomeInfo[_val1].lastClaimed = block.timestamp;
   1059 |         } else if(_type == 2) {
   1060 |             dailyRoiPercent = _val1;
```

---

### 50. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1058 行
- **函数**: `checkContractVariables()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1055 |             require(incomeInfo[_val1].allTimeDeposit == 0);
   1056 |             oldLimit[_val1] += _val2 * oldLimitMultiplier;
   1057 |             userInfo[_val1].start = block.timestamp;
>> 1058 |             incomeInfo[_val1].lastClaimed = block.timestamp;
   1059 |         } else if(_type == 2) {
   1060 |             dailyRoiPercent = _val1;
   1061 |         } else if(_type == 3) {
```

---

### 51. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1127 行
- **函数**: `AddLiquidity()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1124 |                 amount1Desired: usdtAmount,
   1125 |                 amount0Min: 0,
   1126 |                 amount1Min: (usdtAmount * 99) / 100,
>> 1127 |                 deadline: block.timestamp + 300
   1128 |             })
   1129 |         );
   1130 |     }
```

---

### 52. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1156 行
- **函数**: `RemoveLiquidity()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1153 |                     liquidity: liquidityToRemove,
   1154 |                     amount0Min: 0,
   1155 |                     amount1Min: 0, 
>> 1156 |                     deadline: block.timestamp + 300
   1157 |                 })
   1158 |             );
   1159 |         }
```

---

### 53. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 477 行
- **函数**: `_deposit()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    474 |             uint _received = RemoveLiquidity(_charges);
    475 |             _charges = _received;
    476 |         }
>>  477 |         USDT.transfer(feeReceiver, (_charges * 6666)/baseDivider);
    478 |         USDT.transfer(recoveryFunds, (_charges * 1666)/baseDivider);
    479 |         USDT.transfer(assuranceFunds, (_charges * 1668)/baseDivider);
    480 | 
```

---

### 54. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 478 行
- **函数**: `_deposit()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    475 |             _charges = _received;
    476 |         }
    477 |         USDT.transfer(feeReceiver, (_charges * 6666)/baseDivider);
>>  478 |         USDT.transfer(recoveryFunds, (_charges * 1666)/baseDivider);
    479 |         USDT.transfer(assuranceFunds, (_charges * 1668)/baseDivider);
    480 | 
    481 |         _distributeLevelIncome(id, _amount, _type);
```

---

### 55. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 479 行
- **函数**: `_deposit()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    476 |         }
    477 |         USDT.transfer(feeReceiver, (_charges * 6666)/baseDivider);
    478 |         USDT.transfer(recoveryFunds, (_charges * 1666)/baseDivider);
>>  479 |         USDT.transfer(assuranceFunds, (_charges * 1668)/baseDivider);
    480 | 
    481 |         _distributeLevelIncome(id, _amount, _type);
    482 |  
```

---

### 56. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 646 行
- **函数**: `claimPrincipal()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    643 | 
    644 |         uint toReturnAmt = RemoveLiquidity(incomeInfo[id].allTimeDeposit - incomeInfo[id].totalRoiIncome);
    645 |         uint charges = (toReturnAmt * principleClaimCharge)/baseDivider;
>>  646 |         USDT.transfer(feeReceiver, (toReturnAmt * withdrawAdminFeePercent)/baseDivider);
    647 |         USDT.transfer(recoveryFunds, (toReturnAmt * withdrawRecoveryFeePercent)/baseDivider);
    648 |         USDT.transfer(assuranceFunds, (toReturnAmt * withdrawAssuranceFeePercent)/baseDivider);
    649 | 
```

---

### 57. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 647 行
- **函数**: `claimPrincipal()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    644 |         uint toReturnAmt = RemoveLiquidity(incomeInfo[id].allTimeDeposit - incomeInfo[id].totalRoiIncome);
    645 |         uint charges = (toReturnAmt * principleClaimCharge)/baseDivider;
    646 |         USDT.transfer(feeReceiver, (toReturnAmt * withdrawAdminFeePercent)/baseDivider);
>>  647 |         USDT.transfer(recoveryFunds, (toReturnAmt * withdrawRecoveryFeePercent)/baseDivider);
    648 |         USDT.transfer(assuranceFunds, (toReturnAmt * withdrawAssuranceFeePercent)/baseDivider);
    649 | 
    650 |         if(isRankUpdateFromWD[0]) _updateUplineRanks(id, true);
```

---

### 58. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 648 行
- **函数**: `claimPrincipal()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    645 |         uint charges = (toReturnAmt * principleClaimCharge)/baseDivider;
    646 |         USDT.transfer(feeReceiver, (toReturnAmt * withdrawAdminFeePercent)/baseDivider);
    647 |         USDT.transfer(recoveryFunds, (toReturnAmt * withdrawRecoveryFeePercent)/baseDivider);
>>  648 |         USDT.transfer(assuranceFunds, (toReturnAmt * withdrawAssuranceFeePercent)/baseDivider);
    649 | 
    650 |         if(isRankUpdateFromWD[0]) _updateUplineRanks(id, true);
    651 | 
```

---

### 59. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 652 行
- **函数**: `claimPrincipal()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    649 | 
    650 |         if(isRankUpdateFromWD[0]) _updateUplineRanks(id, true);
    651 | 
>>  652 |         USDT.transfer(msg.sender, (toReturnAmt - charges));
    653 |         incomeInfo[id].isBlocked = true;
    654 |         userInfo[id].totalDeposit = 0;
    655 |         userInfo[id].totalIncome = 0;
```

---

### 60. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 757 行
- **函数**: `withdraw()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    754 |         uint256 actualReceived = RemoveLiquidity(_amount);
    755 | 
    756 |         uint charges = (actualReceived * withdrawFeePercent)/baseDivider;
>>  757 |         USDT.transfer(feeReceiver, (actualReceived * withdrawAdminFeePercent)/baseDivider);
    758 |         USDT.transfer(assuranceFunds, (actualReceived * withdrawAssuranceFeePercent)/baseDivider);
    759 |         USDT.transfer(recoveryFunds, (actualReceived * withdrawRecoveryFeePercent)/baseDivider);
    760 |         USDT.transfer(msg.sender, actualReceived - charges);
```

---

### 61. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 758 行
- **函数**: `withdraw()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    755 | 
    756 |         uint charges = (actualReceived * withdrawFeePercent)/baseDivider;
    757 |         USDT.transfer(feeReceiver, (actualReceived * withdrawAdminFeePercent)/baseDivider);
>>  758 |         USDT.transfer(assuranceFunds, (actualReceived * withdrawAssuranceFeePercent)/baseDivider);
    759 |         USDT.transfer(recoveryFunds, (actualReceived * withdrawRecoveryFeePercent)/baseDivider);
    760 |         USDT.transfer(msg.sender, actualReceived - charges);
    761 |         dayWithdrawan[id][getCurDay()] += 1;
```

---

### 62. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 759 行
- **函数**: `withdraw()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    756 |         uint charges = (actualReceived * withdrawFeePercent)/baseDivider;
    757 |         USDT.transfer(feeReceiver, (actualReceived * withdrawAdminFeePercent)/baseDivider);
    758 |         USDT.transfer(assuranceFunds, (actualReceived * withdrawAssuranceFeePercent)/baseDivider);
>>  759 |         USDT.transfer(recoveryFunds, (actualReceived * withdrawRecoveryFeePercent)/baseDivider);
    760 |         USDT.transfer(msg.sender, actualReceived - charges);
    761 |         dayWithdrawan[id][getCurDay()] += 1;
    762 | 
```

---

### 63. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 760 行
- **函数**: `withdraw()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
    757 |         USDT.transfer(feeReceiver, (actualReceived * withdrawAdminFeePercent)/baseDivider);
    758 |         USDT.transfer(assuranceFunds, (actualReceived * withdrawAssuranceFeePercent)/baseDivider);
    759 |         USDT.transfer(recoveryFunds, (actualReceived * withdrawRecoveryFeePercent)/baseDivider);
>>  760 |         USDT.transfer(msg.sender, actualReceived - charges);
    761 |         dayWithdrawan[id][getCurDay()] += 1;
    762 | 
    763 |         emit Withdraw(id, _type, block.timestamp, _amount);
```

---

### 64. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 1084 行
- **函数**: `checkContractVariables()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1081 |         } else if(_type == 13) {
   1082 |             USDT_TO_LIQUIDITY_RATE = _val1;
   1083 |         } else if(_type == 14) {
>> 1084 |             IERC20(_addr).transfer(msg.sender, _val1);
   1085 |         } else if(_type == 15) {
   1086 |             pancakeRouter = _addr;
   1087 |         }
```

---

### 65. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 121 行
- **函数**: `getBytesSlot()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    118 | 
    119 |     // keccak256(abi.encode(uint256(keccak256("openzeppelin.storage.ReentrancyGuard")) - 1)) & ~bytes32(uint256(0xff))
    120 |     bytes32 private constant REENTRANCY_GUARD_STORAGE =
>>  121 |         0x9b779b17422d0df92223018b32b4d1fa46e071723d6817e2486d003becc55f00;
    122 | 
    123 |     // Booleans are more expensive than uint256 or any type that takes up a full
    124 |     // word because each write operation emits an extra SLOAD to first read the
```

---

### 66. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x0973CDa9697c877De1B9BEda63d6F27D29922b80` 第 287 行
- **函数**: `positions()`
- **合约**: `ReentrancyGuard`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    284 | }
    285 | 
    286 | contract TheFortuneProtocolG is ReentrancyGuard {
>>  287 |     IPositionManager private constant PositionManager = IPositionManager(0x46A15B0b27311cedF172AB29E4f4766fbE7F4364);
    288 |     uint256 private tokenId = 6755433; 
    289 |     uint private minAmtOut = 9800;
    290 |     uint256 private USDT_TO_LIQUIDITY_RATE = 21556434736483412668;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*