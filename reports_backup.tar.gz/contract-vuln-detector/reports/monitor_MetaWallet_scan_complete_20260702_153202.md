# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:32:02
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` |
| contract_name | `MetaWallet` |
| compiler_version | `v0.8.27+commit.40a35a09` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `istanbul` |
| license_type | `None` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/MetaWallet.sol', 'contracts/token/ERC20/utils/SafeERC20.sol', 'contracts/token/ERC20/IERC20.sol', 'contracts/token/ERC20/extensions/draft-IERC20Permit.sol', 'contracts/utils/Address.sol', 'contracts/utils/cryptography/ECDSA.sol', 'contracts/utils/Strings.sol', 'contracts/RlpEncode.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655011` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 18 |
| 🟢 LOW | 7 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 796 行
- **函数**: `functionDelegateCall()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    793 |     ) internal returns (bytes memory) {
    794 |         require(isContract(target), "Address: delegate call to non-contract");
    795 | 
>>  796 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    797 |         return verifyCallResult(success, returndata, errorMessage);
    798 |     }
    799 | 
```

---

### 2. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 64 行
- **函数**: `withdrawEth()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     61 |      * @param amount The amount of Ether to withdraw (in wei).
     62 |      */
     63 |     function withdrawEth(uint256 amount) public onlyOwner {
>>   64 |         (bool success,) = payable(owner).call{value: amount}("");
     65 |         require(success, "Transfer failed.");
     66 |     }
     67 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 73 行
- **函数**: `withdrawFees()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     70 |      * @dev Only callable by the owner. Resets the fees to zero after withdrawal.
     71 |      */
     72 |     function withdrawFees() public onlyOwner {
>>   73 |         (bool success,) = payable(owner).call{value: fees}("");
     74 |         require(success, "Transfer failed.");
     75 |         fees = 0;
     76 |     }
```

---

### 4. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 150 行
- **函数**: `withdraw()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    147 |         );
    148 |         usedNonces[nonce] = true;
    149 |         if (contract_id == NATIVE_TOKEN) {
>>  150 |             (bool success,) = payable(receiver_id).call{value: amount}("");
    151 |             require(success, "Transfer failed.");
    152 |         } else {
    153 |             IERC20(contract_id).safeTransfer(receiver_id, amount);
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 668 行
- **函数**: `sendValue()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    665 |     function sendValue(address payable recipient, uint256 amount) internal {
    666 |         require(address(this).balance >= amount, "Address: insufficient balance");
    667 | 
>>  668 |         (bool success, ) = recipient.call{value: amount}("");
    669 |         require(success, "Address: unable to send value, recipient may have reverted");
    670 |     }
    671 | 
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 742 行
- **函数**: `functionCallWithValue()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    739 |         require(address(this).balance >= value, "Address: insufficient balance for call");
    740 |         require(isContract(target), "Address: call to non-contract");
    741 | 
>>  742 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    743 |         return verifyCallResult(success, returndata, errorMessage);
    744 |     }
    745 | 
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 198 行
- **函数**: `deposit()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    195 |      *
    196 |      * @dev Records the deposit of Ether and emits a NewTransfer event.
    197 |      */
>>  198 |     function deposit(bytes memory receiver) public payable {
    199 |         uint128 nonce = uint128(block.timestamp) * NONCE_TS_SHIFT + nonceMax;
    200 | 
    201 |         bytes32 origMessageHash = getMessageHash(
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 482 行
- **函数**: `totalSupply()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    479 |     /**
    480 |      * @dev Returns the amount of tokens in existence.
    481 |      */
>>  482 |     function totalSupply() external view returns (uint256);
    483 | 
    484 |     /**
    485 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 487 行
- **函数**: `balanceOf()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    484 |     /**
    485 |      * @dev Returns the amount of tokens owned by `account`.
    486 |      */
>>  487 |     function balanceOf(address account) external view returns (uint256);
    488 | 
    489 |     /**
    490 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 496 行
- **函数**: `transfer()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    493 |      *
    494 |      * Emits a {Transfer} event.
    495 |      */
>>  496 |     function transfer(address to, uint256 amount) external returns (bool);
    497 | 
    498 |     /**
    499 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 505 行
- **函数**: `allowance()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    502 |      *
    503 |      * This value changes when {approve} or {transferFrom} are called.
    504 |      */
>>  505 |     function allowance(address owner, address spender) external view returns (uint256);
    506 | 
    507 |     /**
    508 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 521 行
- **函数**: `approve()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    518 |      *
    519 |      * Emits an {Approval} event.
    520 |      */
>>  521 |     function approve(address spender, uint256 amount) external returns (bool);
    522 | 
    523 |     /**
    524 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 594 行
- **函数**: `nonces()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    591 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
    592 |      * prevents a signature from being used multiple times.
    593 |      */
>>  594 |     function nonces(address owner) external view returns (uint256);
    595 | 
    596 |     /**
    597 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 600 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    597 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
    598 |      */
    599 |     // solhint-disable-next-line func-name-mixedcase
>>  600 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
    601 | }
    602 | 
    603 | 
```

---

### 15. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 7 行
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      2 | 
      3 | // SPDX-License-Identifier: MIT
      4 | pragma solidity ^0.8.20;
      5 | /**
      6 |  * @title Omni Token Wallet
>>    7 |  * @dev This contract was audited by Hacken (https://hacken.io) on 24/09/2024.
      8 |  *
      9 |  * Audited by: Hacken
     10 |  * Date: 24/09/2024
     11 |  * Audit: https://example.com/audit-report
     12 |  */
```

---

### 16. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 59 行
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     54 |     {
     55 |         IERC20(tokenAddress).safeTransfer(owner, amount);
     56 |     }
     57 | 
     58 |     /**
>>   59 |      * @notice Withdraw Ether from the contract to the owner's address.
     60 |      * @dev Only callable by the owner.
     61 |      * @param amount The amount of Ether to withdraw (in wei).
     62 |      */
     63 |     function withdrawEth(uint256 amount) public onlyOwner {
     64 |         (bool success,) = payable(owner).call{value: amount}("");
```

---

### 17. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 69 行
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     64 |         (bool success,) = payable(owner).call{value: amount}("");
     65 |         require(success, "Transfer failed.");
     66 |     }
     67 | 
     68 |     /**
>>   69 |      * @notice Withdraw accumulated fees from the contract to the owner's address.
     70 |      * @dev Only callable by the owner. Resets the fees to zero after withdrawal.
     71 |      */
     72 |     function withdrawFees() public onlyOwner {
     73 |         (bool success,) = payable(owner).call{value: fees}("");
     74 |         require(success, "Transfer failed.");
```

---

### 18. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 118 行
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    113 |     function changeVerifyAddress(address _verifyAddress) public onlyOwner {
    114 |         verifyAddress = _verifyAddress;
    115 |     }
    116 | 
    117 |     /**
>>  118 |      * @notice Execute a withdrawal from the contract to the specified receiver.
    119 |      * @param nonce The unique nonce associated with the withdrawal.
    120 |      * @param contract_id The address of the token contract (use address(0) for native token).
    121 |      * @param receiver_id The address of the receiver.
    122 |      * @param amount The amount to withdraw.
    123 |      * @param signature The signature proving authorization for the withdrawal.
```

---

### 19. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 348 行
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    343 | import "contracts/utils/Address.sol";
    344 | 
    345 | /**
    346 |  * @title SafeERC20
    347 |  * @dev Wrappers around ERC20 operations that throw on failure (when the token
>>  348 |  * contract returns false). Tokens that return no value (and instead revert or
    349 |  * throw on failure) are also supported, non-reverting calls are assumed to be
    350 |  * successful.
    351 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
    352 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
    353 |  */
```

---

### 20. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 177 行
- **函数**: `deposit()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    174 |             address(this),
    175 |             amount
    176 |         );
>>  177 |         uint128 nonce = uint128(block.timestamp) * NONCE_TS_SHIFT + nonceMax;
    178 |         emit NewTransfer(nonce, amount, abi.encodePacked(contract_id), receiver);
    179 | 
    180 |         bytes32 origMessageHash = getMessageHash(
```

---

### 21. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 199 行
- **函数**: `deposit()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    196 |      * @dev Records the deposit of Ether and emits a NewTransfer event.
    197 |      */
    198 |     function deposit(bytes memory receiver) public payable {
>>  199 |         uint128 nonce = uint128(block.timestamp) * NONCE_TS_SHIFT + nonceMax;
    200 | 
    201 |         bytes32 origMessageHash = getMessageHash(
    202 |             nonce,
```

---

### 22. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 939 行
- **函数**: `tryRecover()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    936 |         bytes32 r,
    937 |         bytes32 vs
    938 |     ) internal pure returns (address, RecoverError) {
>>  939 |         bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
    940 |         uint8 v = uint8((uint256(vs) >> 255) + 27);
    941 |         return tryRecover(hash, v, r, s);
    942 |     }
```

---

### 23. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 980 行
- **函数**: `tryRecover()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    977 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
    978 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
    979 |         // these malleable signatures as well.
>>  980 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
    981 |             return (address(0), RecoverError.InvalidSignatureS);
    982 |         }
    983 |         if (v != 27 && v != 28) {
```

---

### 24. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 818 行
- **函数**: `verifyCallResult()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    815 |             if (returndata.length > 0) {
    816 |                 // The easiest way to bubble the revert reason is using memory via assembly
    817 |                 /// @solidity memory-safe-assembly
>>  818 |                 assembly {
    819 |                     let returndata_size := mload(returndata)
    820 |                     revert(add(32, returndata), returndata_size)
    821 |                 }
```

---

### 25. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 896 行
- **函数**: `tryRecover()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    893 |             // ecrecover takes the signature parameters, and the only way to get them
    894 |             // currently is to use assembly.
    895 |             /// @solidity memory-safe-assembly
>>  896 |             assembly {
    897 |                 r := mload(add(signature, 0x20))
    898 |                 s := mload(add(signature, 0x40))
    899 |                 v := byte(0, mload(add(signature, 0x60)))
```

---

### 26. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x233c5370CCfb3cD7409d9A3fb98ab94dE94Cb4Cd` 第 1219 行
- **函数**: `concatenate()`
- **合约**: `was`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1216 |     function concatenate(bytes memory a, bytes memory b) internal pure returns (bytes memory) {
   1217 |         bytes memory result = new bytes(a.length + b.length);
   1218 | 
>> 1219 |         assembly {
   1220 |             let resultPtr := add(result, 0x20)
   1221 |             let aPtr := add(a, 0x20)
   1222 |             let bPtr := add(b, 0x20)
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*