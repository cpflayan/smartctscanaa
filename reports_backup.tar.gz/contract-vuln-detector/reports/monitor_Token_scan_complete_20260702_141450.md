# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:14:50
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` |
| contract_name | `Token` |
| compiler_version | `v0.8.27+commit.40a35a09` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `paris` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/utils/Context.sol', 'contracts/GCOW.sol', 'contracts/Interface.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 3 |
| 🟡 MEDIUM | 47 |
| 🟢 LOW | 14 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 565 行
- **函数**: `addOrRemove()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    562 |         view
    563 |         returns (uint256 addLPLiquidity, uint256 removeLPLiquidity)
    564 |     {
>>  565 |         if (isLiquidityPair[to] && isSwapRouter[msg.sender] && from == tx.origin) {
    566 |             uint256 addAmount = amount;
    567 |             addLPLiquidity = _isAddLiquidity(to, addAmount);
    568 |         }
```

---

### 2. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 749 行
- **函数**: `processDividendTracker()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    746 |             lastProcessedIndex,
    747 |             false,
    748 |             gas,
>>  749 |             tx.origin
    750 |         );
    751 |     }
    752 | 
```

---

### 3. 🟠 [HIGH] tx-origin-auth

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 911 行
- **函数**: `_transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.718

**工具描述**: 使用 tx.origin 进行身份验证，存在钓鱼攻击风险。应改用 msg.sender。

**代码片段**:
```solidity
    908 |                     lastProcessedIndex,
    909 |                     true,
    910 |                     gas,
>>  911 |                     tx.origin
    912 |                 );
    913 |             } catch {}
    914 | 
```

---

### 4. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 583 行
- **函数**: `_getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    580 |         returns (uint256 rOther, uint256 rThis, uint256 balanceOther)
    581 |     {
    582 |         ISwapPair mainPair = ISwapPair(pair);
>>  583 |         (uint r0, uint256 r1, ) = mainPair.getReserves();
    584 | 
    585 |         address tokenOther = mainPair.token0() == address(this)
    586 |             ? mainPair.token1()
```

---

### 5. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1227 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1224 | }
   1225 | 
   1226 | interface ISwapPair {
>> 1227 |     function getReserves()
   1228 |         external
   1229 |         view
   1230 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1570 行
- **函数**: `safeApprove()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1567 | library TransferHelper {
   1568 |     function safeApprove(address token, address to, uint value) internal {
   1569 |         // bytes4(keccak256(bytes('approve(address,uint256)')));
>> 1570 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x095ea7b3, to, value));
   1571 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: APPROVE_FAILED');
   1572 |     }
   1573 | 
```

---

### 7. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1576 行
- **函数**: `safeTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1573 | 
   1574 |     function safeTransfer(address token, address to, uint value) internal {
   1575 |         // bytes4(keccak256(bytes('transfer(address,uint256)')));
>> 1576 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
   1577 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FAILED');
   1578 |     }
   1579 | 
```

---

### 8. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1582 行
- **函数**: `safeTransferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
   1579 | 
   1580 |     function safeTransferFrom(address token, address from, address to, uint value) internal {
   1581 |         // bytes4(keccak256(bytes('transferFrom(address,address,uint256)')));
>> 1582 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0x23b872dd, from, to, value));
   1583 |         require(success && (data.length == 0 || abi.decode(data, (bool))), 'TransferHelper: TRANSFER_FROM_FAILED');
   1584 |     }
   1585 | 
```

---

### 9. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1587 行
- **函数**: `safeTransferETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1584 |     }
   1585 | 
   1586 |     function safeTransferETH(address to, uint value) internal {
>> 1587 |         (bool success,) = to.call{value:value}(new bytes(0));
   1588 |         require(success, 'TransferHelper: ETH_TRANSFER_FAILED');
   1589 |     }
   1590 | }
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 58 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     55 |     /**
     56 |      * @dev Returns the address of the current owner.
     57 |      */
>>   58 |     function owner() public view virtual returns (address) {
     59 |         return _owner;
     60 |     }
     61 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 133 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    130 |     /**
    131 |      * @dev Returns the value of tokens in existence.
    132 |      */
>>  133 |     function totalSupply() external view returns (uint256);
    134 | 
    135 |     /**
    136 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 138 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    135 |     /**
    136 |      * @dev Returns the value of tokens owned by `account`.
    137 |      */
>>  138 |     function balanceOf(address account) external view returns (uint256);
    139 | 
    140 |     /**
    141 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 147 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    144 |      *
    145 |      * Emits a {Transfer} event.
    146 |      */
>>  147 |     function transfer(address to, uint256 value) external returns (bool);
    148 | 
    149 |     /**
    150 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 156 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    153 |      *
    154 |      * This value changes when {approve} or {transferFrom} are called.
    155 |      */
>>  156 |     function allowance(address owner, address spender) external view returns (uint256);
    157 | 
    158 |     /**
    159 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 173 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    170 |      *
    171 |      * Emits an {Approval} event.
    172 |      */
>>  173 |     function approve(address spender, uint256 value) external returns (bool);
    174 | 
    175 |     /**
    176 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 184 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    181 |      *
    182 |      * Emits a {Transfer} event.
    183 |      */
>>  184 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    185 | }
    186 | 
    187 | 
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 240 行
- **函数**: `paused()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    237 |     function processLotteryEntry(address user, uint256 amount) external;
    238 |     function batchProcessLotteryResultsWhenBurn() external;
    239 |     function batchProcessLotteryResultsWhenTrade() external;
>>  240 |     function paused() external view returns (bool);
    241 | }
    242 | 
    243 | contract Token is IERC20, Ownable {
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 409 行
- **函数**: `handleWinner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    406 |         gasForProcessing = 500_000;
    407 |     }
    408 | 
>>  409 |     function handleWinner(address winner, uint256 sendAmount) external onlyPool returns(uint256, uint256, uint256){
    410 |         uint256 realAmount = sendAmount;
    411 |         if (realAmount * 2 > balanceOf(DEAD_ADDRESS)) {
    412 |             // not enough token
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 461 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    458 |      * @notice Returns the token symbol
    459 |      * @return The symbol of the token
    460 |      */
>>  461 |     function symbol() external view returns (string memory) {
    462 |         return _symbol;
    463 |     }
    464 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 469 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    466 |      * @notice Returns the token name
    467 |      * @return The name of the token
    468 |      */
>>  469 |     function name() external view returns (string memory) {
    470 |         return _name;
    471 |     }
    472 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 477 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    474 |      * @notice Returns the token decimals
    475 |      * @return The number of decimals used by the token
    476 |      */
>>  477 |     function decimals() external view returns (uint8) {
    478 |         return uint8(_decimals);
    479 |     }
    480 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 481 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    478 |         return uint8(_decimals);
    479 |     }
    480 | 
>>  481 |     function totalSupply() public view override returns (uint256) {
    482 |         return _totalSupply;
    483 |     }
    484 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 485 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    482 |         return _totalSupply;
    483 |     }
    484 | 
>>  485 |     function balanceOf(address account) public view override returns (uint256) {
    486 |         return _balances[account];
    487 |     }
    488 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 542 行
- **函数**: `getTokenUsdtValue()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    539 |         return true;
    540 |     }
    541 | 
>>  542 |     function getTokenUsdtValue(uint256 tokenAmount) public view returns(uint256) {
    543 |         address[] memory path = new address[](4);
    544 |         path[0] = address(this);
    545 |         path[1] = currencyAddr;
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 737 行
- **函数**: `processDividendTracker()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    734 |         }
    735 |     }
    736 | 
>>  737 |     function processDividendTracker(uint256 gas) external {
    738 |         (
    739 |             uint256 iterations,
    740 |             uint256 claims,
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 753 行
- **函数**: `claim()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    750 |         );
    751 |     }
    752 | 
>>  753 |     function claim() external {
    754 |         dividendTracker.processAccount(payable(msg.sender), false);
    755 |     }
    756 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 767 行
- **函数**: `lenOfInvitorRewardPercentList()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    764 |         require(getInvitorTotalShare() <= 10000 - buyRewardFee - sellRewardFee - transferFee, "invitor reward percent list is not valid");
    765 |     }
    766 | 
>>  767 |     function lenOfInvitorRewardPercentList() public view returns (uint256) {
    768 |         return invitorRewardPercentList.length;
    769 |     }
    770 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 771 行
- **函数**: `getInvitorTotalShare()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    768 |         return invitorRewardPercentList.length;
    769 |     }
    770 | 
>>  771 |     function getInvitorTotalShare() public view returns(uint256){
    772 |         uint256 totalShare;
    773 |         for (uint256 i; i < invitorRewardPercentList.length; i++) {
    774 |             totalShare += invitorRewardPercentList[i];
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 942 行
- **函数**: `min()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    939 | 
    940 |     }
    941 | 
>>  942 |     function min(uint256 a, uint256 b) public pure returns (uint256) {
    943 |         return a < b ? a : b;
    944 |     }
    945 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1192 行
- **函数**: `getAmountsOut()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1189 | }
   1190 | 
   1191 | interface ISwapRouter {
>> 1192 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
   1193 |     function factory() external pure returns (address);
   1194 |     function WETH() external pure returns (address);
   1195 |     function swapExactTokensForTokensSupportingFeeOnTransferTokens(
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1193 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1190 | 
   1191 | interface ISwapRouter {
   1192 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
>> 1193 |     function factory() external pure returns (address);
   1194 |     function WETH() external pure returns (address);
   1195 |     function swapExactTokensForTokensSupportingFeeOnTransferTokens(
   1196 |         uint256 amountIn,
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1194 行
- **函数**: `WETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1191 | interface ISwapRouter {
   1192 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
   1193 |     function factory() external pure returns (address);
>> 1194 |     function WETH() external pure returns (address);
   1195 |     function swapExactTokensForTokensSupportingFeeOnTransferTokens(
   1196 |         uint256 amountIn,
   1197 |         uint256 amountOutMin,
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1223 行
- **函数**: `feeTo()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1220 |         address tokenA,
   1221 |         address tokenB
   1222 |     ) external view returns (address pair);
>> 1223 |     function feeTo() external view returns (address);
   1224 | }
   1225 | 
   1226 | interface ISwapPair {
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1231 行
- **函数**: `token0()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1228 |         external
   1229 |         view
   1230 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>> 1231 |     function token0() external view returns (address);
   1232 |     function token1() external view returns (address);
   1233 |     function balanceOf(address account) external view returns (uint256);
   1234 |     function kLast() external view returns (uint);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1232 行
- **函数**: `token1()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1229 |         view
   1230 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1231 |     function token0() external view returns (address);
>> 1232 |     function token1() external view returns (address);
   1233 |     function balanceOf(address account) external view returns (uint256);
   1234 |     function kLast() external view returns (uint);
   1235 |     function totalSupply() external view returns (uint256);
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1233 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1230 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   1231 |     function token0() external view returns (address);
   1232 |     function token1() external view returns (address);
>> 1233 |     function balanceOf(address account) external view returns (uint256);
   1234 |     function kLast() external view returns (uint);
   1235 |     function totalSupply() external view returns (uint256);
   1236 | }
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1234 行
- **函数**: `kLast()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1231 |     function token0() external view returns (address);
   1232 |     function token1() external view returns (address);
   1233 |     function balanceOf(address account) external view returns (uint256);
>> 1234 |     function kLast() external view returns (uint);
   1235 |     function totalSupply() external view returns (uint256);
   1236 | }
   1237 | 
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1235 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1232 |     function token1() external view returns (address);
   1233 |     function balanceOf(address account) external view returns (uint256);
   1234 |     function kLast() external view returns (uint);
>> 1235 |     function totalSupply() external view returns (uint256);
   1236 | }
   1237 | 
   1238 | interface IWETH {
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1239 行
- **函数**: `deposit()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1236 | }
   1237 | 
   1238 | interface IWETH {
>> 1239 |     function deposit() external payable;
   1240 |     function withdraw(uint) external;
   1241 | }
   1242 | 
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1259 行
- **函数**: `dividendOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1256 | }
   1257 | 
   1258 | interface DividendPayingTokenInterface {
>> 1259 |     function dividendOf(address _owner) external view returns (uint256);
   1260 | 
   1261 |     function withdrawDividend() external;
   1262 | 
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1434 行
- **函数**: `get()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1431 |         mapping(address => bool) inserted;
   1432 |     }
   1433 | 
>> 1434 |     function get(Map storage map, address key) public view returns (uint256) {
   1435 |         return map.values[key];
   1436 |     }
   1437 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1455 行
- **函数**: `size()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1452 |         return map.keys[index];
   1453 |     }
   1454 | 
>> 1455 |     function size(Map storage map) public view returns (uint256) {
   1456 |         return map.keys.length;
   1457 |     }
   1458 | 
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1459 行
- **函数**: `set()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1456 |         return map.keys.length;
   1457 |     }
   1458 | 
>> 1459 |     function set(Map storage map, address key, uint256 val) public {
   1460 |         if (map.inserted[key]) {
   1461 |             map.values[key] = val;
   1462 |         } else {
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1470 行
- **函数**: `remove()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1467 |         }
   1468 |     }
   1469 | 
>> 1470 |     function remove(Map storage map, address key) public {
   1471 |         if (!map.inserted[key]) {
   1472 |             return;
   1473 |         }
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1593 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1590 | }
   1591 | 
   1592 | interface IDividendTracker {
>> 1593 |     function totalSupply() external view returns (uint256);
   1594 |     // function claimDividendTrackerToken(address token, address to, uint256 amount) external;
   1595 |     function setMinimumTokenBalanceForDividends(uint256 newValue) external;
   1596 |     function setClaimWait(uint256 newValue) external;
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1598 行
- **函数**: `process()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1595 |     function setMinimumTokenBalanceForDividends(uint256 newValue) external;
   1596 |     function setClaimWait(uint256 newValue) external;
   1597 |     function setBalance(address payable account,uint256 newBalance) external;
>> 1598 |     function process(uint256 gas) external returns (uint256, uint256, uint256);
   1599 |     function processAccount(
   1600 |         address payable account,
   1601 |         bool automatic
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 22 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     17 |  *
     18 |  * This module is used through inheritance. It will make available the modifier
     19 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     20 |  * the owner.
     21 |  */
>>   22 | abstract contract Ownable is Context {
     23 |     address private _owner;
     24 | 
     25 |     /**
     26 |      * @dev The caller account is not authorized to perform an operation.
     27 |      */
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 94 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     89 |         }
     90 |         _transferOwnership(newOwner);
     91 |     }
     92 | 
     93 |     /**
>>   94 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     95 |      * Internal function without access restriction.
     96 |      */
     97 |     function _transferOwnership(address newOwner) internal virtual {
     98 |         address oldOwner = _owner;
     99 |         _owner = newOwner;
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 229 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    224 | 
    225 | import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
    226 | import "@openzeppelin/contracts/access/Ownable.sol";
    227 | import "./Interface.sol";
    228 | 
>>  229 | contract TokenDistributor {
    230 |     constructor(address token) {
    231 |         // Approve the maximum possible amount to the deployer for distribution operations
    232 |         TransferHelper.safeApprove(token, msg.sender, type(uint256).max);
    233 |     }
    234 | }
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 243 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    238 |     function batchProcessLotteryResultsWhenBurn() external;
    239 |     function batchProcessLotteryResultsWhenTrade() external;
    240 |     function paused() external view returns (bool);
    241 | }
    242 | 
>>  243 | contract Token is IERC20, Ownable {
    244 |     string private _name;
    245 |     string private _symbol;
    246 |     uint256 private _decimals;
    247 |     uint256 private _totalSupply;
    248 | 
```

---

### 51. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 703 行
- **函数**: `isStartTrade()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    700 | 
    701 | 
    702 |     function isStartTrade() internal view returns (bool) {
>>  703 |         return startTradeTimestamp > 0 && block.timestamp >= startTradeTimestamp;
    704 |     }
    705 | 
    706 |     function setPool(address newPool) external onlyOwner {
```

---

### 52. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1011 行
- **函数**: `_tokenTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1008 |             }else{
   1009 |                 if (address(0) == _inviter[to] && tAmount > 0 && from != to && !isExcludedFromFee[to]) {
   1010 |                     _pendingBind[from][to] = true;
>> 1011 |                     emit pendingBind(from, to, block.timestamp);
   1012 |                 }
   1013 | 
   1014 |                 if (address(0) == _inviter[from] && tAmount > 0 && from != to) {
```

---

### 53. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1019 行
- **函数**: `_tokenTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1016 |                         if (to != address(0)) {
   1017 |                             _inviter[from] = to;
   1018 |                             _binders[to].push(from);
>> 1019 |                             emit bindSuccessful(to, from, block.timestamp);
   1020 |                         }
   1021 |                     }
   1022 |                 }
```

---

### 54. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1067 行
- **函数**: `_tokenTransfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1064 |             UserInfo storage userInfo = _userInfo[recipient];
   1065 | 
   1066 |             // already remove prelp burn 
>> 1067 |             bool isWithinRemoveLpBurnDays = isStartTrade() && block.timestamp < startTradeTimestamp + removeLpBurnInterval;
   1068 |             
   1069 |             if (userInfo.preLpAmount >= removeLPLiquidity) {
   1070 |                 userInfo.preLpAmount -= removeLPLiquidity;
```

---

### 55. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1124 行
- **函数**: `startLP()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1121 | 
   1122 |     function startLP() external onlyOwner {
   1123 |         require(0 == startLPTimestamp, "startedAddLP");
>> 1124 |         startLPTimestamp = block.timestamp;
   1125 |     }
   1126 | 
   1127 |     function stopLP() external onlyOwner {
```

---

### 56. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1133 行
- **函数**: `launch()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1130 | 
   1131 |     function launch() external onlyOwner {
   1132 |         require(0 == startTradeTimestamp, "already open");
>> 1133 |         startTradeTimestamp = block.timestamp;
   1134 |     }
   1135 | 
   1136 |     function setStartTradeTimestamp(uint256 newValue) external onlyOwner {
```

---

### 57. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 1137 行
- **函数**: `setStartTradeTimestamp()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1134 |     }
   1135 | 
   1136 |     function setStartTradeTimestamp(uint256 newValue) external onlyOwner {
>> 1137 |         require(newValue > block.timestamp, "new value must be greater than current timestamp");
   1138 |         startTradeTimestamp = newValue;
   1139 |     }
   1140 | 
```

---

### 58. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 257 行
- **函数**: `paused()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    254 |     mapping(address => bool) public isSwapRouter;
    255 | 
    256 |     uint256 private constant MAX = type(uint256).max;
>>  257 |     address public constant DEAD_ADDRESS = 0x000000000000000000000000000000000000dEaD;
    258 |     address public constant ZERO_ADDRESS = 0x0000000000000000000000000000000000000000;
    259 | 
    260 |     address public immutable cowTokenAddress;
```

---

### 59. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 350 行
- **函数**: `paused()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    347 |         sellRewardFee = 200;
    348 | 
    349 |         require(block.chainid == 56 || block.chainid == 97, "chain id not supported");
>>  350 |         usdtAddress             = block.chainid == 56 ? 0x55d398326f99059fF775485246999027B3197955 : 0xaB1a4d4f1D656d2450692D237fdD6C7f9146e814;
    351 |         cowTokenAddress         = block.chainid == 56 ? 0x7aAAA5B10f97321345ACd76945083141bE1C5631 : 0x7E4388f5868aB7E02BC5e5772688f76c6E462161;
    352 |         address swapRouterAddr  = block.chainid == 56 ? 0x10ED43C718714eb63d5aA57B78B54704E256024E : 0xD99D1c33F9fC3444f8101754aBC46c52416550D1;
    353 |         currencyAddr            = cowTokenAddress;
```

---

### 60. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 351 行
- **函数**: `paused()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    348 | 
    349 |         require(block.chainid == 56 || block.chainid == 97, "chain id not supported");
    350 |         usdtAddress             = block.chainid == 56 ? 0x55d398326f99059fF775485246999027B3197955 : 0xaB1a4d4f1D656d2450692D237fdD6C7f9146e814;
>>  351 |         cowTokenAddress         = block.chainid == 56 ? 0x7aAAA5B10f97321345ACd76945083141bE1C5631 : 0x7E4388f5868aB7E02BC5e5772688f76c6E462161;
    352 |         address swapRouterAddr  = block.chainid == 56 ? 0x10ED43C718714eb63d5aA57B78B54704E256024E : 0xD99D1c33F9fC3444f8101754aBC46c52416550D1;
    353 |         currencyAddr            = cowTokenAddress;
    354 | 
```

---

### 61. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 352 行
- **函数**: `paused()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    349 |         require(block.chainid == 56 || block.chainid == 97, "chain id not supported");
    350 |         usdtAddress             = block.chainid == 56 ? 0x55d398326f99059fF775485246999027B3197955 : 0xaB1a4d4f1D656d2450692D237fdD6C7f9146e814;
    351 |         cowTokenAddress         = block.chainid == 56 ? 0x7aAAA5B10f97321345ACd76945083141bE1C5631 : 0x7E4388f5868aB7E02BC5e5772688f76c6E462161;
>>  352 |         address swapRouterAddr  = block.chainid == 56 ? 0x10ED43C718714eb63d5aA57B78B54704E256024E : 0xD99D1c33F9fC3444f8101754aBC46c52416550D1;
    353 |         currencyAddr            = cowTokenAddress;
    354 | 
    355 |         address receiveAddr     = address(0x50f8f9b66859d0Dd0de4a05aB22dd7d0c0865A1D);
```

---

### 62. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 355 行
- **函数**: `paused()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    352 |         address swapRouterAddr  = block.chainid == 56 ? 0x10ED43C718714eb63d5aA57B78B54704E256024E : 0xD99D1c33F9fC3444f8101754aBC46c52416550D1;
    353 |         currencyAddr            = cowTokenAddress;
    354 | 
>>  355 |         address receiveAddr     = address(0x50f8f9b66859d0Dd0de4a05aB22dd7d0c0865A1D);
    356 | 
    357 |         require(currencyAddr < address(this),"currency address cannot be greater than token address");
    358 | 
```

---

### 63. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 644 行
- **函数**: `calLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    641 |                     uint256 denominator;
    642 |                     if (
    643 |                         address(swapRouter) ==
>>  644 |                         address(0x10ED43C718714eb63d5aA57B78B54704E256024E)
    645 |                     ) {
    646 |                         // BSC Pancake
    647 |                         numerator = pairTotalSupply * (rootK - rootKLast) * 8;
```

---

### 64. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xBB4fBE7E80f1D4c0e06428f80b4F26d9EE24B5D0` 第 651 行
- **函数**: `calLiquidity()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    648 |                         denominator = rootK * 17 + (rootKLast * 8);
    649 |                     } else if (
    650 |                         address(swapRouter) ==
>>  651 |                         address(0xD99D1c33F9fC3444f8101754aBC46c52416550D1)
    652 |                     ) {
    653 |                         //BSC testnet Pancake
    654 |                         numerator = pairTotalSupply * (rootK - rootKLast);
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*