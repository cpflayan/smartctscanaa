# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:51:08
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` |
| contract_name | `UniversalRouter` |
| compiler_version | `v0.8.26+commit.8a97fa7a` |
| optimization_used | `True` |
| runs | `44444444` |
| evm_version | `cancun` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['src/pkgs/universal-router/contracts/UniversalRouter.sol', 'src/pkgs/universal-router/contracts/base/Dispatcher.sol', 'src/pkgs/universal-router/contracts/types/RouterParameters.sol', 'src/pkgs/universal-router/contracts/modules/PaymentsImmutables.sol', 'src/pkgs/universal-router/contracts/modules/uniswap/UniswapImmutables.sol', 'src/pkgs/universal-router/contracts/modules/uniswap/v4/V4SwapRouter.sol', 'src/pkgs/universal-router/contracts/libraries/Commands.sol', 'src/pkgs/universal-router/contracts/interfaces/IUniversalRouter.sol', 'src/pkgs/universal-router/contracts/modules/MigratorImmutables.sol', 'src/pkgs/universal-router/contracts/modules/uniswap/v2/V2SwapRouter.sol', 'src/pkgs/universal-router/contracts/modules/uniswap/v3/V3SwapRouter.sol', 'src/pkgs/universal-router/contracts/modules/uniswap/v3/BytesLib.sol', 'src/pkgs/universal-router/contracts/modules/Payments.sol', 'src/pkgs/universal-router/contracts/modules/V3ToV4Migrator.sol', 'src/pkgs/universal-router/contracts/base/Lock.sol', 'src/pkgs/universal-router/lib/solmate/src/tokens/ERC20.sol', 'src/pkgs/permit2/src/interfaces/IAllowanceTransfer.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/libraries/ActionConstants.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/libraries/CalldataDecoder.sol', 'src/pkgs/v4-core/src/types/PoolKey.sol', 'src/pkgs/v4-core/src/interfaces/IPoolManager.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/external/IWETH9.sol', 'src/pkgs/permit2/src/interfaces/IPermit2.sol', 'src/pkgs/universal-router/contracts/modules/Permit2Payments.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/V4Router.sol', 'src/pkgs/v4-core/src/types/Currency.sol', 'src/pkgs/universal-router/lib/v3-periphery/contracts/interfaces/INonfungiblePositionManager.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IPositionManager.sol', 'src/pkgs/v2-core/contracts/interfaces/IUniswapV2Pair.sol', 'src/pkgs/universal-router/contracts/modules/uniswap/v2/UniswapV2Library.sol', 'src/pkgs/universal-router/contracts/libraries/Constants.sol', 'src/pkgs/universal-router/contracts/modules/uniswap/v3/V3Path.sol', 'src/pkgs/v3-core/contracts/libraries/SafeCast.sol', 'src/pkgs/v3-core/contracts/interfaces/IUniswapV3Pool.sol', 'src/pkgs/v3-core/contracts/interfaces/callback/IUniswapV3SwapCallback.sol', 'src/pkgs/universal-router/contracts/libraries/MaxInputAmount.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/libraries/BipsLibrary.sol', 'src/pkgs/universal-router/lib/solmate/src/utils/SafeTransferLib.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/libraries/Actions.sol', 'src/pkgs/universal-router/lib/v3-periphery/contracts/interfaces/IERC721Permit.sol', 'src/pkgs/universal-router/contracts/libraries/Locker.sol', 'src/pkgs/permit2/src/interfaces/IEIP712.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IV4Router.sol', 'src/pkgs/v4-core/src/interfaces/IHooks.sol', 'src/pkgs/v4-core/src/types/PoolId.sol', 'src/pkgs/v4-core/src/interfaces/external/IERC6909Claims.sol', 'src/pkgs/v4-core/src/interfaces/IProtocolFees.sol', 'src/pkgs/v4-core/src/types/BalanceDelta.sol', 'src/pkgs/v4-core/src/interfaces/IExtsload.sol', 'src/pkgs/v4-core/src/interfaces/IExttload.sol', 'src/pkgs/universal-router/lib/v4-periphery/lib/v4-core/lib/openzeppelin-contracts/contracts/token/ERC20/IERC20.sol', 'src/pkgs/permit2/src/interfaces/ISignatureTransfer.sol', 'src/pkgs/permit2/src/libraries/SafeCast160.sol', 'src/pkgs/v4-core/src/libraries/TickMath.sol', 'src/pkgs/v4-core/src/libraries/SafeCast.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/libraries/PathKey.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/base/BaseActionsRouter.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/base/DeltaResolver.sol', 'src/pkgs/v4-core/src/interfaces/external/IERC20Minimal.sol', 'src/pkgs/v4-core/src/libraries/CustomRevert.sol', 'lib/oz-v4.7.0/contracts/token/ERC721/extensions/IERC721Metadata.sol', 'lib/oz-v4.7.0/contracts/token/ERC721/extensions/IERC721Enumerable.sol', 'src/pkgs/universal-router/lib/v3-periphery/contracts/interfaces/IPoolInitializer.sol', 'src/pkgs/universal-router/lib/v3-periphery/contracts/interfaces/IPeripheryPayments.sol', 'src/pkgs/universal-router/lib/v3-periphery/contracts/interfaces/IPeripheryImmutableState.sol', 'src/pkgs/universal-router/lib/v3-periphery/contracts/libraries/PoolAddress.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/libraries/PositionInfoLibrary.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/INotifier.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IImmutableState.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IERC721Permit_v4.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IEIP712_v4.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IMulticall_v4.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IPoolInitializer_v4.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IUnorderedNonce.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IPermit2Forwarder.sol', 'src/pkgs/v3-core/contracts/interfaces/pool/IUniswapV3PoolImmutables.sol', 'src/pkgs/v3-core/contracts/interfaces/pool/IUniswapV3PoolState.sol', 'src/pkgs/v3-core/contracts/interfaces/pool/IUniswapV3PoolDerivedState.sol', 'src/pkgs/v3-core/contracts/interfaces/pool/IUniswapV3PoolActions.sol', 'src/pkgs/v3-core/contracts/interfaces/pool/IUniswapV3PoolOwnerActions.sol', 'src/pkgs/v3-core/contracts/interfaces/pool/IUniswapV3PoolEvents.sol', 'lib/oz-v4.7.0/contracts/token/ERC721/IERC721.sol', 'src/pkgs/v4-core/src/types/BeforeSwapDelta.sol', 'src/pkgs/v4-core/src/libraries/BitMath.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/base/SafeCallback.sol', 'src/pkgs/v4-core/src/libraries/TransientStateLibrary.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/base/ImmutableState.sol', 'src/pkgs/universal-router/lib/v4-periphery/src/interfaces/ISubscriber.sol', 'lib/oz-v4.7.0/contracts/utils/introspection/IERC165.sol', 'src/pkgs/v4-core/src/interfaces/callback/IUnlockCallback.sol', 'src/pkgs/v4-core/src/libraries/CurrencyReserves.sol', 'src/pkgs/v4-core/src/libraries/NonzeroDeltaCount.sol', 'src/pkgs/v4-core/src/libraries/Lock.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646140` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 150 |
| 🟢 LOW | 62 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 614 行
- **函数**: `_v2Swap()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    611 |             uint256 penultimatePairIndex = finalPairIndex - 1;
    612 |             for (uint256 i; i < finalPairIndex; i++) {
    613 |                 (address input, address output) = (path[i], path[i + 1]);
>>  614 |                 (uint256 reserve0, uint256 reserve1,) = IUniswapV2Pair(pair).getReserves();
    615 |                 (uint256 reserveInput, uint256 reserveOutput) =
    616 |                     input == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
    617 |                 uint256 amountInput = ERC20(input).balanceOf(pair) - reserveInput;
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2936 行
- **函数**: `getReserves()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   2933 |     function factory() external view returns (address);
   2934 |     function token0() external view returns (address);
   2935 |     function token1() external view returns (address);
>> 2936 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2937 |     function price0CumulativeLast() external view returns (uint);
   2938 |     function price1CumulativeLast() external view returns (uint);
   2939 |     function kLast() external view returns (uint);
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3033 行
- **函数**: `pairAndReservesFor()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   3030 |     {
   3031 |         address token0;
   3032 |         (pair, token0) = pairAndToken0For(factory, initCodeHash, tokenA, tokenB);
>> 3033 |         (uint256 reserve0, uint256 reserve1,) = IUniswapV2Pair(pair).getReserves();
   3034 |         (reserveA, reserveB) = tokenA == token0 ? (reserve0, reserve1) : (reserve1, reserve0);
   3035 |     }
   3036 | 
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 182 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    179 |                             permitBatch := add(inputs.offset, calldataload(inputs.offset))
    180 |                         }
    181 |                         bytes calldata data = inputs.toBytes(1);
>>  182 |                         (success, output) = address(PERMIT2).call(
    183 |                             abi.encodeWithSignature(
    184 |                                 'permit(address,((address,uint160,uint48,uint48)[],address,uint256),bytes)',
    185 |                                 msgSender(),
```

---

### 5. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 268 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    265 |                             permitSingle := inputs.offset
    266 |                         }
    267 |                         bytes calldata data = inputs.toBytes(6); // PermitSingle takes first 6 slots (0..5)
>>  268 |                         (success, output) = address(PERMIT2).call(
    269 |                             abi.encodeWithSignature(
    270 |                                 'permit(address,((address,uint160,uint48,uint48),address,uint256),bytes)',
    271 |                                 msgSender(),
```

---

### 6. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 327 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    324 |                     // This contract MUST be approved to spend the token since its going to be doing the call on the position manager
    325 |                 } else if (command == Commands.V3_POSITION_MANAGER_PERMIT) {
    326 |                     _checkV3PermitCall(inputs);
>>  327 |                     (success, output) = address(V3_POSITION_MANAGER).call(inputs);
    328 |                 } else if (command == Commands.V3_POSITION_MANAGER_CALL) {
    329 |                     _checkV3PositionManagerCall(inputs, msgSender());
    330 |                     (success, output) = address(V3_POSITION_MANAGER).call(inputs);
```

---

### 7. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 330 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    327 |                     (success, output) = address(V3_POSITION_MANAGER).call(inputs);
    328 |                 } else if (command == Commands.V3_POSITION_MANAGER_CALL) {
    329 |                     _checkV3PositionManagerCall(inputs, msgSender());
>>  330 |                     (success, output) = address(V3_POSITION_MANAGER).call(inputs);
    331 |                 } else if (command == Commands.V4_INITIALIZE_POOL) {
    332 |                     PoolKey calldata poolKey;
    333 |                     uint160 sqrtPriceX96;
```

---

### 8. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 339 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    336 |                         sqrtPriceX96 := calldataload(add(inputs.offset, 0xa0))
    337 |                     }
    338 |                     (success, output) =
>>  339 |                         address(poolManager).call(abi.encodeCall(IPoolManager.initialize, (poolKey, sqrtPriceX96)));
    340 |                 } else if (command == Commands.V4_POSITION_MANAGER_CALL) {
    341 |                     // should only call modifyLiquidities() to mint
    342 |                     _checkV4PositionManagerCall(inputs);
```

---

### 9. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 343 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    340 |                 } else if (command == Commands.V4_POSITION_MANAGER_CALL) {
    341 |                     // should only call modifyLiquidities() to mint
    342 |                     _checkV4PositionManagerCall(inputs);
>>  343 |                     (success, output) = address(V4_POSITION_MANAGER).call{value: address(this).balance}(inputs);
    344 |                 } else {
    345 |                     // placeholder area for commands 0x15-0x20
    346 |                     revert InvalidCommandType(command);
```

---

### 10. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 353 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    350 |             // 0x21 <= command
    351 |             if (command == Commands.EXECUTE_SUB_PLAN) {
    352 |                 (bytes calldata _commands, bytes[] calldata _inputs) = inputs.decodeCommandsAndInputs();
>>  353 |                 (success, output) = (address(this)).call(abi.encodeCall(Dispatcher.execute, (_commands, _inputs)));
    354 |             } else {
    355 |                 // placeholder area for commands 0x22-0x3f
    356 |                 revert InvalidCommandType(command);
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 46 行
- **函数**: `execute()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     43 |     }
     44 | 
     45 |     /// @inheritdoc Dispatcher
>>   46 |     function execute(bytes calldata commands, bytes[] calldata inputs) public payable override isNotLocked {
     47 |         bool success;
     48 |         bytes memory output;
     49 |         uint256 numCommands = commands.length;
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 105 行
- **函数**: `execute()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    102 |     /// @notice Executes encoded commands along with provided inputs.
    103 |     /// @param commands A set of concatenated commands, each 1 byte in length
    104 |     /// @param inputs An array of byte strings containing abi encoded inputs for each command
>>  105 |     function execute(bytes calldata commands, bytes[] calldata inputs) external payable virtual;
    106 | 
    107 |     /// @notice Public view function to be used instead of msg.sender, as the contract performs self-reentrancy and at
    108 |     /// times msg.sender == address(this). Instead msgSender() returns the initiator of the lock
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 110 行
- **函数**: `msgSender()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    107 |     /// @notice Public view function to be used instead of msg.sender, as the contract performs self-reentrancy and at
    108 |     /// times msg.sender == address(this). Instead msgSender() returns the initiator of the lock
    109 |     /// @dev overrides BaseActionsRouter.msgSender in V4Router
>>  110 |     function msgSender() public view override returns (address) {
    111 |         return _getLocker();
    112 |     }
    113 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 553 行
- **函数**: `execute()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    550 |     /// @param commands A set of concatenated commands, each 1 byte in length
    551 |     /// @param inputs An array of byte strings containing abi encoded inputs for each command
    552 |     /// @param deadline The deadline by which the transaction must be executed
>>  553 |     function execute(bytes calldata commands, bytes[] calldata inputs, uint256 deadline) external payable;
    554 | }
    555 | 
    556 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 722 行
- **函数**: `uniswapV3SwapCallback()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    719 |     /// @dev The maximum value that can be returned from #getSqrtRatioAtTick. Equivalent to getSqrtRatioAtTick(MAX_TICK)
    720 |     uint160 internal constant MAX_SQRT_RATIO = 1461446703485210103287273052203988822378723970342;
    721 | 
>>  722 |     function uniswapV3SwapCallback(int256 amount0Delta, int256 amount1Delta, bytes calldata data) external {
    723 |         if (amount0Delta <= 0 && amount1Delta <= 0) revert V3InvalidSwap(); // swaps entirely within 0-liquidity regions are not supported
    724 |         (, address payer) = abi.decode(data, (bytes, address));
    725 |         bytes calldata path = data.toBytes(0);
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1264 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1261 |                                ERC20 LOGIC
   1262 |     //////////////////////////////////////////////////////////////*/
   1263 | 
>> 1264 |     function approve(address spender, uint256 amount) public virtual returns (bool) {
   1265 |         allowance[msg.sender][spender] = amount;
   1266 | 
   1267 |         emit Approval(msg.sender, spender, amount);
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1272 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1269 |         return true;
   1270 |     }
   1271 | 
>> 1272 |     function transfer(address to, uint256 amount) public virtual returns (bool) {
   1273 |         balanceOf[msg.sender] -= amount;
   1274 | 
   1275 |         // Cannot overflow because the sum of all user
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1358 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1355 |         emit Approval(owner, spender, value);
   1356 |     }
   1357 | 
>> 1358 |     function DOMAIN_SEPARATOR() public view virtual returns (bytes32) {
   1359 |         return block.chainid == INITIAL_CHAIN_ID ? INITIAL_DOMAIN_SEPARATOR : computeDomainSeparator();
   1360 |     }
   1361 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2133 行
- **函数**: `unlock()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2130 |     /// @dev The only functions callable without an unlocking are `initialize` and `updateDynamicLPFee`
   2131 |     /// @param data Any data to pass to the callback, via `IUnlockCallback(msg.sender).unlockCallback(data)`
   2132 |     /// @return The data returned by the call to `IUnlockCallback(msg.sender).unlockCallback(data)`
>> 2133 |     function unlock(bytes calldata data) external returns (bytes memory);
   2134 | 
   2135 |     /// @notice Initialize the state for a given pool ID
   2136 |     /// @dev A swap fee totaling MAX_SWAP_FEE (100%) makes exact output swaps impossible since the input is entirely consumed by the fee
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2140 行
- **函数**: `initialize()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2137 |     /// @param key The pool key for the pool to initialize
   2138 |     /// @param sqrtPriceX96 The initial square root price
   2139 |     /// @return tick The initial tick of the pool
>> 2140 |     function initialize(PoolKey memory key, uint160 sqrtPriceX96) external returns (int24 tick);
   2141 | 
   2142 |     struct ModifyLiquidityParams {
   2143 |         // the lower and upper tick of the position
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2221 行
- **函数**: `settle()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2218 | 
   2219 |     /// @notice Called by the user to pay what is owed
   2220 |     /// @return paid The amount of currency settled
>> 2221 |     function settle() external payable returns (uint256 paid);
   2222 | 
   2223 |     /// @notice Called by the user to pay on behalf of another address
   2224 |     /// @param recipient The address to credit for the payment
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2226 行
- **函数**: `settleFor()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2223 |     /// @notice Called by the user to pay on behalf of another address
   2224 |     /// @param recipient The address to credit for the payment
   2225 |     /// @return paid The amount of currency settled
>> 2226 |     function settleFor(address recipient) external payable returns (uint256 paid);
   2227 | 
   2228 |     /// @notice WARNING - Any currency that is cleared, will be non-retrievable, and locked in the contract permanently.
   2229 |     /// A call to clear will zero out a positive balance WITHOUT a corresponding transfer.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2268 行
- **函数**: `deposit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2265 | /// @title IWETH9
   2266 | interface IWETH9 is IERC20 {
   2267 |     /// @notice Deposit ether to get wrapped ether
>> 2268 |     function deposit() external payable;
   2269 | 
   2270 |     /// @notice Withdraw wrapped ether to get ether
   2271 |     function withdraw(uint256) external;
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2814 行
- **函数**: `collect()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2811 |     /// amount1Max The maximum amount of token1 to collect
   2812 |     /// @return amount0 The amount of fees collected in token0
   2813 |     /// @return amount1 The amount of fees collected in token1
>> 2814 |     function collect(CollectParams calldata params) external payable returns (uint256 amount0, uint256 amount1);
   2815 | 
   2816 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   2817 |     /// must be collected first.
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2819 行
- **函数**: `burn()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2816 |     /// @notice Burns a token ID, which deletes it from the NFT contract. The token must have 0 liquidity and all tokens
   2817 |     /// must be collected first.
   2818 |     /// @param tokenId The ID of the token that is being burned
>> 2819 |     function burn(uint256 tokenId) external payable;
   2820 | }
   2821 | 
   2822 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2864 行
- **函数**: `modifyLiquidities()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2861 |     /// @dev This is the standard entrypoint for the PositionManager
   2862 |     /// @param unlockData is an encoding of actions, and parameters for those actions
   2863 |     /// @param deadline is the deadline for the batched actions to be executed
>> 2864 |     function modifyLiquidities(bytes calldata unlockData, uint256 deadline) external payable;
   2865 | 
   2866 |     /// @notice Batches actions for modifying liquidity without unlocking v4 PoolManager
   2867 |     /// @dev This must be called by a contract that has already unlocked the v4 PoolManager
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2870 行
- **函数**: `modifyLiquiditiesWithoutUnlock()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2867 |     /// @dev This must be called by a contract that has already unlocked the v4 PoolManager
   2868 |     /// @param actions the actions to perform
   2869 |     /// @param params the parameters to provide for the actions
>> 2870 |     function modifyLiquiditiesWithoutUnlock(bytes calldata actions, bytes[] calldata params) external payable;
   2871 | 
   2872 |     /// @notice Used to get the ID that will be used for the next minted liquidity position
   2873 |     /// @return uint256 The next token ID
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2874 行
- **函数**: `nextTokenId()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2871 | 
   2872 |     /// @notice Used to get the ID that will be used for the next minted liquidity position
   2873 |     /// @return uint256 The next token ID
>> 2874 |     function nextTokenId() external view returns (uint256);
   2875 | 
   2876 |     /// @notice Returns the liquidity of a position
   2877 |     /// @param tokenId the ERC721 tokenId
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2880 行
- **函数**: `getPositionLiquidity()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2877 |     /// @param tokenId the ERC721 tokenId
   2878 |     /// @return liquidity the position's liquidity, as a liquidityAmount
   2879 |     /// @dev this value can be processed as an amount0 and amount1 by using the LiquidityAmounts library
>> 2880 |     function getPositionLiquidity(uint256 tokenId) external view returns (uint128 liquidity);
   2881 | 
   2882 |     /// @notice Returns the pool key and position info of a position
   2883 |     /// @param tokenId the ERC721 tokenId
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2886 行
- **函数**: `getPoolAndPositionInfo()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2883 |     /// @param tokenId the ERC721 tokenId
   2884 |     /// @return poolKey the pool key of the position
   2885 |     /// @return PositionInfo a uint256 packed value holding information about the position including the range (tickLower, tickUpper)
>> 2886 |     function getPoolAndPositionInfo(uint256 tokenId) external view returns (PoolKey memory, PositionInfo);
   2887 | 
   2888 |     /// @notice Returns the position info of a position
   2889 |     /// @param tokenId the ERC721 tokenId
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2891 行
- **函数**: `positionInfo()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2888 |     /// @notice Returns the position info of a position
   2889 |     /// @param tokenId the ERC721 tokenId
   2890 |     /// @return a uint256 packed value holding information about the position including the range (tickLower, tickUpper)
>> 2891 |     function positionInfo(uint256 tokenId) external view returns (PositionInfo);
   2892 | }
   2893 | 
   2894 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2903 行
- **函数**: `name()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2900 |     event Approval(address indexed owner, address indexed spender, uint value);
   2901 |     event Transfer(address indexed from, address indexed to, uint value);
   2902 | 
>> 2903 |     function name() external pure returns (string memory);
   2904 |     function symbol() external pure returns (string memory);
   2905 |     function decimals() external pure returns (uint8);
   2906 |     function totalSupply() external view returns (uint);
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2904 行
- **函数**: `symbol()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2901 |     event Transfer(address indexed from, address indexed to, uint value);
   2902 | 
   2903 |     function name() external pure returns (string memory);
>> 2904 |     function symbol() external pure returns (string memory);
   2905 |     function decimals() external pure returns (uint8);
   2906 |     function totalSupply() external view returns (uint);
   2907 |     function balanceOf(address owner) external view returns (uint);
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2905 行
- **函数**: `decimals()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2902 | 
   2903 |     function name() external pure returns (string memory);
   2904 |     function symbol() external pure returns (string memory);
>> 2905 |     function decimals() external pure returns (uint8);
   2906 |     function totalSupply() external view returns (uint);
   2907 |     function balanceOf(address owner) external view returns (uint);
   2908 |     function allowance(address owner, address spender) external view returns (uint);
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2906 行
- **函数**: `totalSupply()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2903 |     function name() external pure returns (string memory);
   2904 |     function symbol() external pure returns (string memory);
   2905 |     function decimals() external pure returns (uint8);
>> 2906 |     function totalSupply() external view returns (uint);
   2907 |     function balanceOf(address owner) external view returns (uint);
   2908 |     function allowance(address owner, address spender) external view returns (uint);
   2909 | 
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2907 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2904 |     function symbol() external pure returns (string memory);
   2905 |     function decimals() external pure returns (uint8);
   2906 |     function totalSupply() external view returns (uint);
>> 2907 |     function balanceOf(address owner) external view returns (uint);
   2908 |     function allowance(address owner, address spender) external view returns (uint);
   2909 | 
   2910 |     function approve(address spender, uint value) external returns (bool);
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2908 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2905 |     function decimals() external pure returns (uint8);
   2906 |     function totalSupply() external view returns (uint);
   2907 |     function balanceOf(address owner) external view returns (uint);
>> 2908 |     function allowance(address owner, address spender) external view returns (uint);
   2909 | 
   2910 |     function approve(address spender, uint value) external returns (bool);
   2911 |     function transfer(address to, uint value) external returns (bool);
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2910 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2907 |     function balanceOf(address owner) external view returns (uint);
   2908 |     function allowance(address owner, address spender) external view returns (uint);
   2909 | 
>> 2910 |     function approve(address spender, uint value) external returns (bool);
   2911 |     function transfer(address to, uint value) external returns (bool);
   2912 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2913 | 
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2911 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2908 |     function allowance(address owner, address spender) external view returns (uint);
   2909 | 
   2910 |     function approve(address spender, uint value) external returns (bool);
>> 2911 |     function transfer(address to, uint value) external returns (bool);
   2912 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2913 | 
   2914 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2912 行
- **函数**: `transferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2909 | 
   2910 |     function approve(address spender, uint value) external returns (bool);
   2911 |     function transfer(address to, uint value) external returns (bool);
>> 2912 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2913 | 
   2914 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2915 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2914 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2911 |     function transfer(address to, uint value) external returns (bool);
   2912 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2913 | 
>> 2914 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2915 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   2916 |     function nonces(address owner) external view returns (uint);
   2917 | 
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2915 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2912 |     function transferFrom(address from, address to, uint value) external returns (bool);
   2913 | 
   2914 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
>> 2915 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   2916 |     function nonces(address owner) external view returns (uint);
   2917 | 
   2918 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2916 行
- **函数**: `nonces()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2913 | 
   2914 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   2915 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
>> 2916 |     function nonces(address owner) external view returns (uint);
   2917 | 
   2918 |     function permit(address owner, address spender, uint value, uint deadline, uint8 v, bytes32 r, bytes32 s) external;
   2919 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2932 行
- **函数**: `MINIMUM_LIQUIDITY()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2929 |     );
   2930 |     event Sync(uint112 reserve0, uint112 reserve1);
   2931 | 
>> 2932 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   2933 |     function factory() external view returns (address);
   2934 |     function token0() external view returns (address);
   2935 |     function token1() external view returns (address);
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2933 行
- **函数**: `factory()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2930 |     event Sync(uint112 reserve0, uint112 reserve1);
   2931 | 
   2932 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
>> 2933 |     function factory() external view returns (address);
   2934 |     function token0() external view returns (address);
   2935 |     function token1() external view returns (address);
   2936 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2934 行
- **函数**: `token0()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2931 | 
   2932 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   2933 |     function factory() external view returns (address);
>> 2934 |     function token0() external view returns (address);
   2935 |     function token1() external view returns (address);
   2936 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2937 |     function price0CumulativeLast() external view returns (uint);
```

---

### 47. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2935 行
- **函数**: `token1()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2932 |     function MINIMUM_LIQUIDITY() external pure returns (uint);
   2933 |     function factory() external view returns (address);
   2934 |     function token0() external view returns (address);
>> 2935 |     function token1() external view returns (address);
   2936 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2937 |     function price0CumulativeLast() external view returns (uint);
   2938 |     function price1CumulativeLast() external view returns (uint);
```

---

### 48. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2936 行
- **函数**: `getReserves()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2933 |     function factory() external view returns (address);
   2934 |     function token0() external view returns (address);
   2935 |     function token1() external view returns (address);
>> 2936 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2937 |     function price0CumulativeLast() external view returns (uint);
   2938 |     function price1CumulativeLast() external view returns (uint);
   2939 |     function kLast() external view returns (uint);
```

---

### 49. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2937 行
- **函数**: `price0CumulativeLast()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2934 |     function token0() external view returns (address);
   2935 |     function token1() external view returns (address);
   2936 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>> 2937 |     function price0CumulativeLast() external view returns (uint);
   2938 |     function price1CumulativeLast() external view returns (uint);
   2939 |     function kLast() external view returns (uint);
   2940 | 
```

---

### 50. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2938 行
- **函数**: `price1CumulativeLast()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2935 |     function token1() external view returns (address);
   2936 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2937 |     function price0CumulativeLast() external view returns (uint);
>> 2938 |     function price1CumulativeLast() external view returns (uint);
   2939 |     function kLast() external view returns (uint);
   2940 | 
   2941 |     function mint(address to) external returns (uint liquidity);
```

---

### 51. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2939 行
- **函数**: `kLast()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2936 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
   2937 |     function price0CumulativeLast() external view returns (uint);
   2938 |     function price1CumulativeLast() external view returns (uint);
>> 2939 |     function kLast() external view returns (uint);
   2940 | 
   2941 |     function mint(address to) external returns (uint liquidity);
   2942 |     function burn(address to) external returns (uint amount0, uint amount1);
```

---

### 52. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2941 行
- **函数**: `mint()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2938 |     function price1CumulativeLast() external view returns (uint);
   2939 |     function kLast() external view returns (uint);
   2940 | 
>> 2941 |     function mint(address to) external returns (uint liquidity);
   2942 |     function burn(address to) external returns (uint amount0, uint amount1);
   2943 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
   2944 |     function skim(address to) external;
```

---

### 53. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2942 行
- **函数**: `burn()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2939 |     function kLast() external view returns (uint);
   2940 | 
   2941 |     function mint(address to) external returns (uint liquidity);
>> 2942 |     function burn(address to) external returns (uint amount0, uint amount1);
   2943 |     function swap(uint amount0Out, uint amount1Out, address to, bytes calldata data) external;
   2944 |     function skim(address to) external;
   2945 |     function sync() external;
```

---

### 54. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3510 行
- **函数**: `PERMIT_TYPEHASH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3507 | interface IERC721Permit is IERC721 {
   3508 |     /// @notice The permit typehash used in the permit signature
   3509 |     /// @return The typehash for the permit
>> 3510 |     function PERMIT_TYPEHASH() external pure returns (bytes32);
   3511 | 
   3512 |     /// @notice The domain separator used in the permit signature
   3513 |     /// @return The domain seperator used in encoding of permit signature
```

---

### 55. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3514 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3511 | 
   3512 |     /// @notice The domain separator used in the permit signature
   3513 |     /// @return The domain seperator used in encoding of permit signature
>> 3514 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   3515 | 
   3516 |     /// @notice Approve of a specific token ID for spending by spender via signature
   3517 |     /// @param spender The account that is being approved
```

---

### 56. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3571 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3568 | pragma solidity ^0.8.0;
   3569 | 
   3570 | interface IEIP712 {
>> 3571 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   3572 | }
   3573 | 
   3574 | 
```

---

### 57. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3651 行
- **函数**: `beforeInitialize()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3648 |     /// @param key The key for the pool being initialized
   3649 |     /// @param sqrtPriceX96 The sqrt(price) of the pool as a Q64.96
   3650 |     /// @return bytes4 The function selector for the hook
>> 3651 |     function beforeInitialize(address sender, PoolKey calldata key, uint160 sqrtPriceX96) external returns (bytes4);
   3652 | 
   3653 |     /// @notice The hook called after the state of a pool is initialized
   3654 |     /// @param sender The initial msg.sender for the initialize call
```

---

### 58. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3834 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3831 |     /// @param owner The address of the owner.
   3832 |     /// @param id The id of the token.
   3833 |     /// @return amount The balance of the token.
>> 3834 |     function balanceOf(address owner, uint256 id) external view returns (uint256 amount);
   3835 | 
   3836 |     /// @notice Spender allowance of an id.
   3837 |     /// @param owner The address of the owner.
```

---

### 59. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3841 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3838 |     /// @param spender The address of the spender.
   3839 |     /// @param id The id of the token.
   3840 |     /// @return amount The allowance of the token.
>> 3841 |     function allowance(address owner, address spender, uint256 id) external view returns (uint256 amount);
   3842 | 
   3843 |     /// @notice Checks if a spender is approved by an owner as an operator
   3844 |     /// @param owner The address of the owner.
```

---

### 60. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3847 行
- **函数**: `isOperator()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3844 |     /// @param owner The address of the owner.
   3845 |     /// @param spender The address of the spender.
   3846 |     /// @return approved The approval status.
>> 3847 |     function isOperator(address owner, address spender) external view returns (bool approved);
   3848 | 
   3849 |     /// @notice Transfers an amount of an id from the caller to a receiver.
   3850 |     /// @param receiver The address of the receiver.
```

---

### 61. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3854 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3851 |     /// @param id The id of the token.
   3852 |     /// @param amount The amount of the token.
   3853 |     /// @return bool True, always, unless the function reverts
>> 3854 |     function transfer(address receiver, uint256 id, uint256 amount) external returns (bool);
   3855 | 
   3856 |     /// @notice Transfers an amount of an id from a sender to a receiver.
   3857 |     /// @param sender The address of the sender.
```

---

### 62. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3862 行
- **函数**: `transferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3859 |     /// @param id The id of the token.
   3860 |     /// @param amount The amount of the token.
   3861 |     /// @return bool True, always, unless the function reverts
>> 3862 |     function transferFrom(address sender, address receiver, uint256 id, uint256 amount) external returns (bool);
   3863 | 
   3864 |     /// @notice Approves an amount of an id to a spender.
   3865 |     /// @param spender The address of the spender.
```

---

### 63. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3869 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3866 |     /// @param id The id of the token.
   3867 |     /// @param amount The amount of the token.
   3868 |     /// @return bool True, always
>> 3869 |     function approve(address spender, uint256 id, uint256 amount) external returns (bool);
   3870 | 
   3871 |     /// @notice Sets or removes an operator for the caller.
   3872 |     /// @param operator The address of the operator.
```

---

### 64. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3875 行
- **函数**: `setOperator()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3872 |     /// @param operator The address of the operator.
   3873 |     /// @param approved The approval status.
   3874 |     /// @return bool True, always
>> 3875 |     function setOperator(address operator, bool approved) external returns (bool);
   3876 | }
   3877 | 
   3878 | 
```

---

### 65. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3908 行
- **函数**: `protocolFeesAccrued()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3905 |     /// @notice Given a currency address, returns the protocol fees accrued in that currency
   3906 |     /// @param currency The currency to check
   3907 |     /// @return amount The amount of protocol fees accrued in the currency
>> 3908 |     function protocolFeesAccrued(Currency currency) external view returns (uint256 amount);
   3909 | 
   3910 |     /// @notice Sets the protocol fee for the given pool
   3911 |     /// @param key The key of the pool to set a protocol fee for
```

---

### 66. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3931 行
- **函数**: `protocolFeeController()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   3928 | 
   3929 |     /// @notice Returns the current protocol fee controller address
   3930 |     /// @return address The current protocol fee controller address
>> 3931 |     function protocolFeeController() external view returns (address);
   3932 | }
   3933 | 
   3934 | 
```

---

### 67. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4021 行
- **函数**: `extsload()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4018 |     /// @notice Called by external contracts to access granular pool state
   4019 |     /// @param slot Key of slot to sload
   4020 |     /// @return value The value of the slot as bytes32
>> 4021 |     function extsload(bytes32 slot) external view returns (bytes32 value);
   4022 | 
   4023 |     /// @notice Called by external contracts to access granular pool state
   4024 |     /// @param startSlot Key of slot to start sloading from
```

---

### 68. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4027 行
- **函数**: `extsload()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4024 |     /// @param startSlot Key of slot to start sloading from
   4025 |     /// @param nSlots Number of slots to load into return value
   4026 |     /// @return values List of loaded values.
>> 4027 |     function extsload(bytes32 startSlot, uint256 nSlots) external view returns (bytes32[] memory values);
   4028 | 
   4029 |     /// @notice Called by external contracts to access sparse pool state
   4030 |     /// @param slots List of slots to SLOAD from.
```

---

### 69. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4032 行
- **函数**: `extsload()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4029 |     /// @notice Called by external contracts to access sparse pool state
   4030 |     /// @param slots List of slots to SLOAD from.
   4031 |     /// @return values List of loaded values.
>> 4032 |     function extsload(bytes32[] calldata slots) external view returns (bytes32[] memory values);
   4033 | }
   4034 | 
   4035 | 
```

---

### 70. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4046 行
- **函数**: `exttload()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4043 |     /// @notice Called by external contracts to access transient storage of the contract
   4044 |     /// @param slot Key of slot to tload
   4045 |     /// @return value The value of the slot as bytes32
>> 4046 |     function exttload(bytes32 slot) external view returns (bytes32 value);
   4047 | 
   4048 |     /// @notice Called by external contracts to access sparse transient pool state
   4049 |     /// @param slots List of slots to tload
```

---

### 71. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4051 行
- **函数**: `exttload()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4048 |     /// @notice Called by external contracts to access sparse transient pool state
   4049 |     /// @param slots List of slots to tload
   4050 |     /// @return values List of loaded values
>> 4051 |     function exttload(bytes32[] calldata slots) external view returns (bytes32[] memory values);
   4052 | }
   4053 | 
   4054 | 
```

---

### 72. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4083 行
- **函数**: `totalSupply()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4080 |     /**
   4081 |      * @dev Returns the value of tokens in existence.
   4082 |      */
>> 4083 |     function totalSupply() external view returns (uint256);
   4084 | 
   4085 |     /**
   4086 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 73. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4088 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4085 |     /**
   4086 |      * @dev Returns the value of tokens owned by `account`.
   4087 |      */
>> 4088 |     function balanceOf(address account) external view returns (uint256);
   4089 | 
   4090 |     /**
   4091 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 74. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4097 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4094 |      *
   4095 |      * Emits a {Transfer} event.
   4096 |      */
>> 4097 |     function transfer(address to, uint256 value) external returns (bool);
   4098 | 
   4099 |     /**
   4100 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 75. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4106 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4103 |      *
   4104 |      * This value changes when {approve} or {transferFrom} are called.
   4105 |      */
>> 4106 |     function allowance(address owner, address spender) external view returns (uint256);
   4107 | 
   4108 |     /**
   4109 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 76. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4123 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4120 |      *
   4121 |      * Emits an {Approval} event.
   4122 |      */
>> 4123 |     function approve(address spender, uint256 value) external returns (bool);
   4124 | 
   4125 |     /**
   4126 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 77. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4134 行
- **函数**: `transferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4131 |      *
   4132 |      * Emits a {Transfer} event.
   4133 |      */
>> 4134 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
   4135 | }
   4136 | 
   4137 | 
```

---

### 78. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4204 行
- **函数**: `nonceBitmap()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4201 |     /// @dev The mapping is indexed first by the token owner, then by an index specified in the nonce
   4202 |     /// @dev It returns a uint256 bitmap
   4203 |     /// @dev The index, or wordPosition is capped at type(uint248).max
>> 4204 |     function nonceBitmap(address, uint256) external view returns (uint256);
   4205 | 
   4206 |     /// @notice Transfers a token using a signed permit message
   4207 |     /// @dev Reverts if the requested amount is greater than the permitted signed amount
```

---

### 79. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4700 行
- **函数**: `msgSender()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4697 |     /// In many contracts this will be the address that calls the initial entry point that calls `_executeActions`
   4698 |     /// `msg.sender` shouldn't be used, as this will be the v4 pool manager contract that calls `unlockCallback`
   4699 |     /// If using ReentrancyLock.sol, this function can return _getLocker()
>> 4700 |     function msgSender() public view virtual returns (address);
   4701 | 
   4702 |     /// @notice Calculates the address for a action
   4703 |     function _mapRecipient(address recipient) internal view returns (address) {
```

---

### 80. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4858 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4855 |     /// @notice Returns an account's balance in the token
   4856 |     /// @param account The account for which to look up the number of tokens it has, i.e. its balance
   4857 |     /// @return The number of tokens held by the account
>> 4858 |     function balanceOf(address account) external view returns (uint256);
   4859 | 
   4860 |     /// @notice Transfers the amount of token from the `msg.sender` to the recipient
   4861 |     /// @param recipient The account that will receive the amount transferred
```

---

### 81. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4864 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4861 |     /// @param recipient The account that will receive the amount transferred
   4862 |     /// @param amount The number of tokens to send from the sender to the recipient
   4863 |     /// @return Returns true for a successful transfer, false for an unsuccessful transfer
>> 4864 |     function transfer(address recipient, uint256 amount) external returns (bool);
   4865 | 
   4866 |     /// @notice Returns the current allowance given to a spender by an owner
   4867 |     /// @param owner The account of the token owner
```

---

### 82. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4870 行
- **函数**: `allowance()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4867 |     /// @param owner The account of the token owner
   4868 |     /// @param spender The account of the token spender
   4869 |     /// @return The current allowance granted by `owner` to `spender`
>> 4870 |     function allowance(address owner, address spender) external view returns (uint256);
   4871 | 
   4872 |     /// @notice Sets the allowance of a spender from the `msg.sender` to the value `amount`
   4873 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
```

---

### 83. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4876 行
- **函数**: `approve()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4873 |     /// @param spender The account which will be allowed to spend a given amount of the owners tokens
   4874 |     /// @param amount The amount of tokens allowed to be used by `spender`
   4875 |     /// @return Returns true for a successful approval, false for unsuccessful
>> 4876 |     function approve(address spender, uint256 amount) external returns (bool);
   4877 | 
   4878 |     /// @notice Transfers `amount` tokens from `sender` to `recipient` up to the allowance given to the `msg.sender`
   4879 |     /// @param sender The account from which the transfer will be initiated
```

---

### 84. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4883 行
- **函数**: `transferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4880 |     /// @param recipient The recipient of the transfer
   4881 |     /// @param amount The amount of the transfer
   4882 |     /// @return Returns true for a successful transfer, false for unsuccessful
>> 4883 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
   4884 | 
   4885 |     /// @notice Event emitted when tokens are transferred from one address to another, either via `#transfer` or `#transferFrom`.
   4886 |     /// @param from The account from which the tokens were sent, i.e. the balance decreased
```

---

### 85. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5040 行
- **函数**: `name()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5037 |     /**
   5038 |      * @dev Returns the token collection name.
   5039 |      */
>> 5040 |     function name() external view returns (string memory);
   5041 | 
   5042 |     /**
   5043 |      * @dev Returns the token collection symbol.
```

---

### 86. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5045 行
- **函数**: `symbol()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5042 |     /**
   5043 |      * @dev Returns the token collection symbol.
   5044 |      */
>> 5045 |     function symbol() external view returns (string memory);
   5046 | 
   5047 |     /**
   5048 |      * @dev Returns the Uniform Resource Identifier (URI) for `tokenId` token.
```

---

### 87. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5050 行
- **函数**: `tokenURI()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5047 |     /**
   5048 |      * @dev Returns the Uniform Resource Identifier (URI) for `tokenId` token.
   5049 |      */
>> 5050 |     function tokenURI(uint256 tokenId) external view returns (string memory);
   5051 | }
   5052 | 
   5053 | 
```

---

### 88. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5071 行
- **函数**: `totalSupply()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5068 |     /**
   5069 |      * @dev Returns the total amount of tokens stored by the contract.
   5070 |      */
>> 5071 |     function totalSupply() external view returns (uint256);
   5072 | 
   5073 |     /**
   5074 |      * @dev Returns a token ID owned by `owner` at a given `index` of its token list.
```

---

### 89. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5077 行
- **函数**: `tokenOfOwnerByIndex()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5074 |      * @dev Returns a token ID owned by `owner` at a given `index` of its token list.
   5075 |      * Use along with {balanceOf} to enumerate all of ``owner``'s tokens.
   5076 |      */
>> 5077 |     function tokenOfOwnerByIndex(address owner, uint256 index) external view returns (uint256);
   5078 | 
   5079 |     /**
   5080 |      * @dev Returns a token ID at a given `index` of all the tokens stored by the contract.
```

---

### 90. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5083 行
- **函数**: `tokenByIndex()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5080 |      * @dev Returns a token ID at a given `index` of all the tokens stored by the contract.
   5081 |      * Use along with {totalSupply} to enumerate all tokens.
   5082 |      */
>> 5083 |     function tokenByIndex(uint256 index) external view returns (uint256);
   5084 | }
   5085 | 
   5086 | 
```

---

### 91. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5125 行
- **函数**: `unwrapWETH9()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5122 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing WETH9 from users.
   5123 |     /// @param amountMinimum The minimum amount of WETH9 to unwrap
   5124 |     /// @param recipient The address receiving ETH
>> 5125 |     function unwrapWETH9(uint256 amountMinimum, address recipient) external payable;
   5126 | 
   5127 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   5128 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
```

---

### 92. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5130 行
- **函数**: `refundETH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5127 |     /// @notice Refunds any ETH balance held by this contract to the `msg.sender`
   5128 |     /// @dev Useful for bundling with mint or increase liquidity that uses ether, or exact output swaps
   5129 |     /// that use ether for the input amount
>> 5130 |     function refundETH() external payable;
   5131 | 
   5132 |     /// @notice Transfers the full amount of a token held by this contract to recipient
   5133 |     /// @dev The amountMinimum parameter prevents malicious contracts from stealing the token from users
```

---

### 93. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5154 行
- **函数**: `factory()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5151 | /// @notice Functions that return immutable state of the router
   5152 | interface IPeripheryImmutableState {
   5153 |     /// @return Returns the address of the Uniswap V3 factory
>> 5154 |     function factory() external view returns (address);
   5155 | 
   5156 |     /// @return Returns the address of WETH9
   5157 |     function WETH9() external view returns (address);
```

---

### 94. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5157 行
- **函数**: `WETH9()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5154 |     function factory() external view returns (address);
   5155 | 
   5156 |     /// @return Returns the address of WETH9
>> 5157 |     function WETH9() external view returns (address);
   5158 | }
   5159 | 
   5160 | 
```

---

### 95. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5357 行
- **函数**: `subscriber()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5354 |     /// @notice Returns the subscriber for a respective position
   5355 |     /// @param tokenId the ERC721 tokenId
   5356 |     /// @return subscriber the subscriber contract
>> 5357 |     function subscriber(uint256 tokenId) external view returns (ISubscriber subscriber);
   5358 | 
   5359 |     /// @notice Enables the subscriber to receive notifications for a respective position
   5360 |     /// @param tokenId the ERC721 tokenId
```

---

### 96. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5366 行
- **函数**: `subscribe()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5363 |     /// @dev Calling subscribe when a position is already subscribed will revert
   5364 |     /// @dev payable so it can be multicalled with NATIVE related actions
   5365 |     /// @dev will revert if pool manager is locked
>> 5366 |     function subscribe(uint256 tokenId, address newSubscriber, bytes calldata data) external payable;
   5367 | 
   5368 |     /// @notice Removes the subscriber from receiving notifications for a respective position
   5369 |     /// @param tokenId the ERC721 tokenId
```

---

### 97. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5374 行
- **函数**: `unsubscribe()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5371 |     /// @dev payable so it can be multicalled with NATIVE related actions
   5372 |     /// @dev Must always allow a user to unsubscribe. In the case of a malicious subscriber, a user can always unsubscribe safely, ensuring liquidity is always modifiable.
   5373 |     /// @dev will revert if pool manager is locked
>> 5374 |     function unsubscribe(uint256 tokenId) external payable;
   5375 | 
   5376 |     /// @notice Returns and determines the maximum allowable gas-used for notifying unsubscribe
   5377 |     /// @return uint256 the maximum gas limit when notifying a subscriber's `notifyUnsubscribe` function
```

---

### 98. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5378 行
- **函数**: `unsubscribeGasLimit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5375 | 
   5376 |     /// @notice Returns and determines the maximum allowable gas-used for notifying unsubscribe
   5377 |     /// @return uint256 the maximum gas limit when notifying a subscriber's `notifyUnsubscribe` function
>> 5378 |     function unsubscribeGasLimit() external view returns (uint256);
   5379 | }
   5380 | 
   5381 | 
```

---

### 99. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5393 行
- **函数**: `poolManager()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5390 | /// @notice Interface for the ImmutableState contract
   5391 | interface IImmutableState {
   5392 |     /// @notice The Uniswap v4 PoolManager contract
>> 5393 |     function poolManager() external view returns (IPoolManager);
   5394 | }
   5395 | 
   5396 | 
```

---

### 100. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5449 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5446 | interface IEIP712_v4 {
   5447 |     /// @notice Returns the domain separator for the current chain.
   5448 |     /// @return bytes32 The domain separator
>> 5449 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   5450 | }
   5451 | 
   5452 | 
```

---

### 101. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5466 行
- **函数**: `multicall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5463 |     /// Subcalls can instead use `address(this).value` to see the available ETH, and consume it using {value: x}.
   5464 |     /// @param data The encoded function data for each of the calls to make to this contract
   5465 |     /// @return results The results from each of the calls passed in via data
>> 5466 |     function multicall(bytes[] calldata data) external payable returns (bytes[] memory results);
   5467 | }
   5468 | 
   5469 | 
```

---

### 102. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5485 行
- **函数**: `initializePool()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5482 |     /// @param key The PoolKey of the pool to initialize
   5483 |     /// @param sqrtPriceX96 The initial starting price of the pool, expressed as a sqrtPriceX96
   5484 |     /// @return The current tick of the pool, or type(int24).max if the pool creation failed, or the pool already existed
>> 5485 |     function initializePool(PoolKey calldata key, uint160 sqrtPriceX96) external payable returns (int24);
   5486 | }
   5487 | 
   5488 | 
```

---

### 103. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5501 行
- **函数**: `nonces()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5498 | 
   5499 |     /// @notice mapping of nonces consumed by each address, where a nonce is a single bit on the 256-bit bitmap
   5500 |     /// @dev word is at most type(uint248).max
>> 5501 |     function nonces(address owner, uint256 word) external view returns (uint256);
   5502 | 
   5503 |     /// @notice Revoke a nonce by spending it, preventing it from being used again
   5504 |     /// @dev Used in cases where a valid nonce has not been broadcasted onchain, and the owner wants to revoke the validity of the nonce
```

---

### 104. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5506 行
- **函数**: `revokeNonce()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5503 |     /// @notice Revoke a nonce by spending it, preventing it from being used again
   5504 |     /// @dev Used in cases where a valid nonce has not been broadcasted onchain, and the owner wants to revoke the validity of the nonce
   5505 |     /// @dev payable so it can be multicalled with native-token related actions
>> 5506 |     function revokeNonce(uint256 nonce) external payable;
   5507 | }
   5508 | 
   5509 | 
```

---

### 105. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5554 行
- **函数**: `factory()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5551 | interface IUniswapV3PoolImmutables {
   5552 |     /// @notice The contract that deployed the pool, which must adhere to the IUniswapV3Factory interface
   5553 |     /// @return The contract address
>> 5554 |     function factory() external view returns (address);
   5555 | 
   5556 |     /// @notice The first of the two tokens of the pool, sorted by address
   5557 |     /// @return The token contract address
```

---

### 106. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5558 行
- **函数**: `token0()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5555 | 
   5556 |     /// @notice The first of the two tokens of the pool, sorted by address
   5557 |     /// @return The token contract address
>> 5558 |     function token0() external view returns (address);
   5559 | 
   5560 |     /// @notice The second of the two tokens of the pool, sorted by address
   5561 |     /// @return The token contract address
```

---

### 107. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5562 行
- **函数**: `token1()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5559 | 
   5560 |     /// @notice The second of the two tokens of the pool, sorted by address
   5561 |     /// @return The token contract address
>> 5562 |     function token1() external view returns (address);
   5563 | 
   5564 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   5565 |     /// @return The fee
```

---

### 108. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5566 行
- **函数**: `fee()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5563 | 
   5564 |     /// @notice The pool's fee in hundredths of a bip, i.e. 1e-6
   5565 |     /// @return The fee
>> 5566 |     function fee() external view returns (uint24);
   5567 | 
   5568 |     /// @notice The pool tick spacing
   5569 |     /// @dev Ticks can only be used at multiples of this value, minimum of 1 and always positive
```

---

### 109. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5573 行
- **函数**: `tickSpacing()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5570 |     /// e.g.: a tickSpacing of 3 means ticks can be initialized every 3rd tick, i.e., ..., -6, -3, 0, 3, 6, ...
   5571 |     /// This value is an int24 to avoid casting even though it is always positive.
   5572 |     /// @return The tick spacing
>> 5573 |     function tickSpacing() external view returns (int24);
   5574 | 
   5575 |     /// @notice The maximum amount of position liquidity that can use any tick in the range
   5576 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
```

---

### 110. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5579 行
- **函数**: `maxLiquidityPerTick()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5576 |     /// @dev This parameter is enforced per tick to prevent liquidity from overflowing a uint128 at any point, and
   5577 |     /// also prevents out-of-range liquidity from being used to prevent adding in-range liquidity to a pool
   5578 |     /// @return The max amount of liquidity per tick
>> 5579 |     function maxLiquidityPerTick() external view returns (uint128);
   5580 | }
   5581 | 
   5582 | 
```

---

### 111. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5620 行
- **函数**: `feeGrowthGlobal0X128()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5617 | 
   5618 |     /// @notice The fee growth as a Q128.128 fees of token0 collected per unit of liquidity for the entire life of the pool
   5619 |     /// @dev This value can overflow the uint256
>> 5620 |     function feeGrowthGlobal0X128() external view returns (uint256);
   5621 | 
   5622 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   5623 |     /// @dev This value can overflow the uint256
```

---

### 112. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5624 行
- **函数**: `feeGrowthGlobal1X128()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5621 | 
   5622 |     /// @notice The fee growth as a Q128.128 fees of token1 collected per unit of liquidity for the entire life of the pool
   5623 |     /// @dev This value can overflow the uint256
>> 5624 |     function feeGrowthGlobal1X128() external view returns (uint256);
   5625 | 
   5626 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   5627 |     /// @dev Protocol fees will never exceed uint128 max in either token
```

---

### 113. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5628 行
- **函数**: `protocolFees()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5625 | 
   5626 |     /// @notice The amounts of token0 and token1 that are owed to the protocol
   5627 |     /// @dev Protocol fees will never exceed uint128 max in either token
>> 5628 |     function protocolFees() external view returns (uint128 token0, uint128 token1);
   5629 | 
   5630 |     /// @notice The currently in range liquidity available to the pool
   5631 |     /// @dev This value has no relationship to the total liquidity across all ticks
```

---

### 114. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5632 行
- **函数**: `liquidity()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5629 | 
   5630 |     /// @notice The currently in range liquidity available to the pool
   5631 |     /// @dev This value has no relationship to the total liquidity across all ticks
>> 5632 |     function liquidity() external view returns (uint128);
   5633 | 
   5634 |     /// @notice Look up information about a specific tick in the pool
   5635 |     /// @param tick The tick to look up
```

---

### 115. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5663 行
- **函数**: `tickBitmap()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5660 |         );
   5661 | 
   5662 |     /// @notice Returns 256 packed tick initialized boolean values. See TickBitmap for more information
>> 5663 |     function tickBitmap(int16 wordPosition) external view returns (uint256);
   5664 | 
   5665 |     /// @notice Returns the information about a position by the position's key
   5666 |     /// @param key The position's key is a hash of a preimage composed by the owner, tickLower and tickUpper
```

---

### 116. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6037 行
- **函数**: `balanceOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6034 |     /**
   6035 |      * @dev Returns the number of tokens in ``owner``'s account.
   6036 |      */
>> 6037 |     function balanceOf(address owner) external view returns (uint256 balance);
   6038 | 
   6039 |     /**
   6040 |      * @dev Returns the owner of the `tokenId` token.
```

---

### 117. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6046 行
- **函数**: `ownerOf()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6043 |      *
   6044 |      * - `tokenId` must exist.
   6045 |      */
>> 6046 |     function ownerOf(uint256 tokenId) external view returns (address owner);
   6047 | 
   6048 |     /**
   6049 |      * @dev Safely transfers `tokenId` token from `from` to `to`.
```

---

### 118. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6142 行
- **函数**: `getApproved()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6139 |      *
   6140 |      * - `tokenId` must exist.
   6141 |      */
>> 6142 |     function getApproved(uint256 tokenId) external view returns (address operator);
   6143 | 
   6144 |     /**
   6145 |      * @dev Returns if the `operator` is allowed to manage all of the assets of `owner`.
```

---

### 119. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6149 行
- **函数**: `isApprovedForAll()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6146 |      *
   6147 |      * See {setApprovalForAll}
   6148 |      */
>> 6149 |     function isApprovedForAll(address owner, address operator) external view returns (bool);
   6150 | }
   6151 | 
   6152 | 
```

---

### 120. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6273 行
- **函数**: `unlockCallback()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6270 | 
   6271 |     /// @inheritdoc IUnlockCallback
   6272 |     /// @dev We force the onlyPoolManager modifier by exposing a virtual function after the onlyPoolManager check.
>> 6273 |     function unlockCallback(bytes calldata data) external onlyPoolManager returns (bytes memory) {
   6274 |         return _unlockCallback(data);
   6275 |     }
   6276 | 
```

---

### 121. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6422 行
- **函数**: `supportsInterface()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6419 |      *
   6420 |      * This function call must use less than 30 000 gas.
   6421 |      */
>> 6422 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   6423 | }
   6424 | 
   6425 | 
```

---

### 122. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6436 行
- **函数**: `unlockCallback()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   6433 |     /// @notice Called by the pool manager on `msg.sender` when the manager is unlocked
   6434 |     /// @param data The data that was passed to the call to unlock
   6435 |     /// @return Any data that you want to be returned from the unlock call
>> 6436 |     function unlockCallback(bytes calldata data) external returns (bytes memory);
   6437 | }
   6438 | 
   6439 | 
```

---

### 123. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 94 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     89 | import {CalldataDecoder} from '@uniswap/v4-periphery/src/libraries/CalldataDecoder.sol';
     90 | import {PoolKey} from '@uniswap/v4-core/src/types/PoolKey.sol';
     91 | import {IPoolManager} from '@uniswap/v4-core/src/interfaces/IPoolManager.sol';
     92 | 
     93 | /// @title Decodes and Executes Commands
>>   94 | /// @notice Called by the UniversalRouter contract to efficiently decode and execute a singular command
     95 | abstract contract Dispatcher is Payments, V2SwapRouter, V3SwapRouter, V4SwapRouter, V3ToV4Migrator, Lock {
     96 |     using BytesLib for bytes;
     97 |     using CalldataDecoder for bytes;
     98 | 
     99 |     error InvalidCommandType(uint256 commandType);
```

---

### 124. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 410 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    405 | struct PaymentsParameters {
    406 |     address permit2;
    407 |     address weth9;
    408 | }
    409 | 
>>  410 | contract PaymentsImmutables {
    411 |     /// @notice WETH9 address
    412 |     IWETH9 internal immutable WETH9;
    413 | 
    414 |     /// @notice Permit2 address
    415 |     IPermit2 internal immutable PERMIT2;
```

---

### 125. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 436 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    431 |     address v3Factory;
    432 |     bytes32 pairInitCodeHash;
    433 |     bytes32 poolInitCodeHash;
    434 | }
    435 | 
>>  436 | contract UniswapImmutables {
    437 |     /// @notice The address of UniswapV2Factory
    438 |     address internal immutable UNISWAP_V2_FACTORY;
    439 | 
    440 |     /// @notice The UniswapV2Pair initcodehash
    441 |     bytes32 internal immutable UNISWAP_V2_PAIR_INIT_CODE_HASH;
```

---

### 126. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 470 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    465 | import {V4Router} from '@uniswap/v4-periphery/src/V4Router.sol';
    466 | import {IPoolManager} from '@uniswap/v4-core/src/interfaces/IPoolManager.sol';
    467 | import {Currency} from '@uniswap/v4-core/src/types/Currency.sol';
    468 | 
    469 | /// @title Router for Uniswap v4 Trades
>>  470 | abstract contract V4SwapRouter is V4Router, Permit2Payments {
    471 |     constructor(address _poolManager) V4Router(IPoolManager(_poolManager)) {}
    472 | 
    473 |     function _pay(Currency token, address payer, uint256 amount) internal override {
    474 |         payOrPermit2Transfer(Currency.unwrap(token), payer, address(poolManager), amount);
    475 |     }
```

---

### 127. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 573 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    568 |     address v4PositionManager;
    569 | }
    570 | 
    571 | /// @title Migrator Immutables
    572 | /// @notice Immutable state for liquidity-migration contracts
>>  573 | contract MigratorImmutables {
    574 |     /// @notice v3 PositionManager address
    575 |     INonfungiblePositionManager public immutable V3_POSITION_MANAGER;
    576 |     /// @notice v4 PositionManager address
    577 |     IPositionManager public immutable V4_POSITION_MANAGER;
    578 | 
```

---

### 128. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 599 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    594 | import {Permit2Payments} from '../../Permit2Payments.sol';
    595 | import {Constants} from '../../../libraries/Constants.sol';
    596 | import {ERC20} from 'solmate/src/tokens/ERC20.sol';
    597 | 
    598 | /// @title Router for Uniswap v2 Trades
>>  599 | abstract contract V2SwapRouter is UniswapImmutables, Permit2Payments {
    600 |     error V2TooLittleReceived();
    601 |     error V2TooMuchRequested();
    602 |     error V2InvalidPath();
    603 | 
    604 |     function _v2Swap(address[] calldata path, address recipient, address pair) private {
```

---

### 129. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 704 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    699 | import {UniswapImmutables} from '../UniswapImmutables.sol';
    700 | import {MaxInputAmount} from '../../../libraries/MaxInputAmount.sol';
    701 | import {ERC20} from 'solmate/src/tokens/ERC20.sol';
    702 | 
    703 | /// @title Router for Uniswap v3 Trades
>>  704 | abstract contract V3SwapRouter is UniswapImmutables, Permit2Payments, IUniswapV3SwapCallback {
    705 |     using V3Path for bytes;
    706 |     using BytesLib for bytes;
    707 |     using CalldataDecoder for bytes;
    708 |     using SafeCast for uint256;
    709 | 
```

---

### 130. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 765 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    760 |         uint256 amountIn,
    761 |         uint256 amountOutMinimum,
    762 |         bytes calldata path,
    763 |         address payer
    764 |     ) internal {
>>  765 |         // use amountIn == ActionConstants.CONTRACT_BALANCE as a flag to swap the entire balance of the contract
    766 |         if (amountIn == ActionConstants.CONTRACT_BALANCE) {
    767 |             address tokenIn = path.decodeFirstToken();
    768 |             amountIn = ERC20(tokenIn).balanceOf(address(this));
    769 |         }
    770 | 
```

---

### 131. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 961 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    956 | import {SafeTransferLib} from 'solmate/src/utils/SafeTransferLib.sol';
    957 | import {ERC20} from 'solmate/src/tokens/ERC20.sol';
    958 | 
    959 | /// @title Payments contract
    960 | /// @notice Performs various operations around the payment of ETH and tokens
>>  961 | abstract contract Payments is PaymentsImmutables {
    962 |     using SafeTransferLib for ERC20;
    963 |     using SafeTransferLib for address;
    964 |     using BipsLibrary for uint256;
    965 | 
    966 |     error InsufficientToken();
```

---

### 132. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1204 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1199 | 
   1200 | /// @notice Modern and gas efficient ERC20 + EIP-2612 implementation.
   1201 | /// @author Solmate (https://github.com/transmissions11/solmate/blob/main/src/tokens/ERC20.sol)
   1202 | /// @author Modified from Uniswap (https://github.com/Uniswap/uniswap-v2-core/blob/master/contracts/UniswapV2ERC20.sol)
   1203 | /// @dev Do not manually set balances without updating totalSupply, as the sum of all user balances must not exceed it.
>> 1204 | abstract contract ERC20 {
   1205 |     /*//////////////////////////////////////////////////////////////
   1206 |                                  EVENTS
   1207 |     //////////////////////////////////////////////////////////////*/
   1208 | 
   1209 |     event Transfer(address indexed from, address indexed to, uint256 amount);
```

---

### 133. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1414 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1409 | 
   1410 | import {IEIP712} from "./IEIP712.sol";
   1411 | 
   1412 | /// @title AllowanceTransfer
   1413 | /// @notice Handles ERC20 token permissions through signature based allowance setting and ERC20 token transfers by checking allowed amounts
>> 1414 | /// @dev Requires user's token approval on the Permit2 contract
   1415 | interface IAllowanceTransfer is IEIP712 {
   1416 |     /// @notice Thrown when an allowance on a token has expired.
   1417 |     /// @param deadline The timestamp at which the allowed amount is no longer valid
   1418 |     error AllowanceExpired(uint256 deadline);
   1419 | 
```

---

### 134. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2301 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2296 | import {SafeCast160} from 'permit2/src/libraries/SafeCast160.sol';
   2297 | import {Payments} from './Payments.sol';
   2298 | 
   2299 | /// @title Payments through Permit2
   2300 | /// @notice Performs interactions with Permit2 to transfer tokens
>> 2301 | abstract contract Permit2Payments is Payments {
   2302 |     using SafeCast160 for uint256;
   2303 | 
   2304 |     error FromAddressIsNotOwner();
   2305 | 
   2306 |     /// @notice Performs a transferFrom on Permit2
```

---

### 135. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2841 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2836 | import {IPoolInitializer_v4} from "./IPoolInitializer_v4.sol";
   2837 | import {IUnorderedNonce} from "./IUnorderedNonce.sol";
   2838 | import {IPermit2Forwarder} from "./IPermit2Forwarder.sol";
   2839 | 
   2840 | /// @title IPositionManager
>> 2841 | /// @notice Interface for the PositionManager contract
   2842 | interface IPositionManager is
   2843 |     INotifier,
   2844 |     IImmutableState,
   2845 |     IERC721Permit_v4,
   2846 |     IEIP712_v4,
```

---

### 136. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3249 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3244 | 
   3245 | // SPDX-License-Identifier: GPL-2.0-or-later
   3246 | pragma solidity >=0.5.0;
   3247 | 
   3248 | /// @title Callback for IUniswapV3PoolActions#swap
>> 3249 | /// @notice Any contract that calls IUniswapV3PoolActions#swap must implement this interface
   3250 | interface IUniswapV3SwapCallback {
   3251 |     /// @notice Called to `msg.sender` after executing a swap via IUniswapV3Pool#swap.
   3252 |     /// @dev In the implementation you must pay the pool tokens owed for the swap.
   3253 |     /// The caller of this method must be checked to be a UniswapV3Pool deployed by the canonical UniswapV3Factory.
   3254 |     /// amount0Delta and amount1Delta can both be 0 if no tokens were swapped.
```

---

### 137. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3540 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3535 | 
   3536 | // SPDX-License-Identifier: GPL-3.0-or-later
   3537 | pragma solidity ^0.8.24;
   3538 | 
   3539 | /// @notice A library to implement a reentrancy lock in transient storage.
>> 3540 | /// @dev Instead of storing a boolean, the locker's address is stored to allow the contract to know who locked the contract
   3541 | /// TODO: This library can be deleted when we have the transient keyword support in solidity.
   3542 | library Locker {
   3543 |     // The slot holding the locker state, transiently. bytes32(uint256(keccak256("Locker")) - 1)
   3544 |     bytes32 constant LOCKER_SLOT = 0x0e87e1788ebd9ed6a7e63c70a374cd3283e41cad601d21fbe27863899ed4a708;
   3545 | 
```

---

### 138. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3586 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3581 | import {Currency} from "@uniswap/v4-core/src/types/Currency.sol";
   3582 | import {PathKey} from "../libraries/PathKey.sol";
   3583 | import {IImmutableState} from "./IImmutableState.sol";
   3584 | 
   3585 | /// @title IV4Router
>> 3586 | /// @notice Interface for the V4Router contract
   3587 | interface IV4Router is IImmutableState {
   3588 |     /// @notice Emitted when an exactInput swap does not receive its minAmountOut
   3589 |     error V4TooLittleReceived(uint256 minAmountOutReceived, uint256 amountReceived);
   3590 |     /// @notice Emitted when an exactOutput is asked for more than its maxAmountIn
   3591 |     error V4TooMuchRequested(uint256 maxAmountInRequested, uint256 amountRequested);
```

---

### 139. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3640 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3635 | import {BalanceDelta} from "../types/BalanceDelta.sol";
   3636 | import {IPoolManager} from "./IPoolManager.sol";
   3637 | import {BeforeSwapDelta} from "../types/BeforeSwapDelta.sol";
   3638 | 
   3639 | /// @notice V4 decides whether to invoke specific hooks by inspecting the least significant bits
>> 3640 | /// of the address that the hooks contract is deployed to.
   3641 | /// For example, a hooks contract deployed to address: 0x0000000000000000000000000000000000002400
   3642 | /// has the lowest bits '10 0100 0000 0000' which would cause the 'before initialize' and 'after add liquidity' hooks to be used.
   3643 | /// See the Hooks library for the full spec.
   3644 | /// @dev Should only be callable by the v4 PoolManager.
   3645 | interface IHooks {
```

---

### 140. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3814 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3809 | // ── src/pkgs/v4-core/src/interfaces/external/IERC6909Claims.sol ──────────────────────────────
   3810 | 
   3811 | // SPDX-License-Identifier: MIT
   3812 | pragma solidity ^0.8.0;
   3813 | 
>> 3814 | /// @notice Interface for claims over a contract balance, wrapped as a ERC6909
   3815 | interface IERC6909Claims {
   3816 |     /*//////////////////////////////////////////////////////////////
   3817 |                                  EVENTS
   3818 |     //////////////////////////////////////////////////////////////*/
   3819 | 
```

---

### 141. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4147 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4142 | 
   4143 | import {IEIP712} from "./IEIP712.sol";
   4144 | 
   4145 | /// @title SignatureTransfer
   4146 | /// @notice Handles ERC20 token transfers through signature based actions
>> 4147 | /// @dev Requires user's token approval on the Permit2 contract
   4148 | interface ISignatureTransfer is IEIP712 {
   4149 |     /// @notice Thrown when the requested amount for a transfer is larger than the permissioned amount
   4150 |     /// @param maxAmount The maximum amount a spender can request to transfer
   4151 |     error InvalidAmount(uint256 maxAmount);
   4152 | 
```

---

### 142. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4731 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4726 | import {TransientStateLibrary} from "@uniswap/v4-core/src/libraries/TransientStateLibrary.sol";
   4727 | import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
   4728 | import {ImmutableState} from "./ImmutableState.sol";
   4729 | import {ActionConstants} from "../libraries/ActionConstants.sol";
   4730 | 
>> 4731 | /// @notice Abstract contract used to sync, send, and settle funds to the pool manager
   4732 | /// @dev Note that sync() is called before any erc-20 transfer in `settle`.
   4733 | abstract contract DeltaResolver is ImmutableState {
   4734 |     using TransientStateLibrary for IPoolManager;
   4735 | 
   4736 |     /// @notice Emitted trying to settle a positive delta.
```

---

### 143. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5099 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5094 | /// @notice Provides a method for creating and initializing a pool, if necessary, for bundling with other methods that
   5095 | /// require the pool to exist.
   5096 | interface IPoolInitializer {
   5097 |     /// @notice Creates a new pool if it does not exist, then initializes if not initialized
   5098 |     /// @dev This method can be bundled with others via IMulticall for the first action (e.g. mint) performed against a pool
>> 5099 |     /// @param token0 The contract address of token0 of the pool
   5100 |     /// @param token1 The contract address of token1 of the pool
   5101 |     /// @param fee The fee amount of the v3 pool for the specified token pair
   5102 |     /// @param sqrtPriceX96 The initial square root price of the pool as a Q64.96 value
   5103 |     /// @return pool Returns the pool address based on the pair of tokens and fee, will return the newly created pool address if necessary
   5104 |     function createAndInitializePoolIfNecessary(
```

---

### 144. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5332 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5327 | pragma solidity ^0.8.0;
   5328 | 
   5329 | import {ISubscriber} from "./ISubscriber.sol";
   5330 | 
   5331 | /// @title INotifier
>> 5332 | /// @notice Interface for the Notifier contract
   5333 | interface INotifier {
   5334 |     /// @notice Thrown when unsubscribing without a subscriber
   5335 |     error NotSubscribed();
   5336 |     /// @notice Thrown when a subscriber does not have code
   5337 |     error NoCodeSubscriber();
```

---

### 145. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5392 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5387 | import {IPoolManager} from "@uniswap/v4-core/src/interfaces/IPoolManager.sol";
   5388 | 
   5389 | /// @title IImmutableState
   5390 | /// @notice Interface for the ImmutableState contract
   5391 | interface IImmutableState {
>> 5392 |     /// @notice The Uniswap v4 PoolManager contract
   5393 |     function poolManager() external view returns (IPoolManager);
   5394 | }
   5395 | 
   5396 | 
   5397 | // ── src/pkgs/universal-router/lib/v4-periphery/src/interfaces/IERC721Permit_v4.sol ──────────────────────────────
```

---

### 146. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5495 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5490 | 
   5491 | // SPDX-License-Identifier: MIT
   5492 | pragma solidity ^0.8.0;
   5493 | 
   5494 | /// @title IUnorderedNonce
>> 5495 | /// @notice Interface for the UnorderedNonce contract
   5496 | interface IUnorderedNonce {
   5497 |     error NonceAlreadyUsed();
   5498 | 
   5499 |     /// @notice mapping of nonces consumed by each address, where a nonce is a single bit on the 256-bit bitmap
   5500 |     /// @dev word is at most type(uint248).max
```

---

### 147. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5518 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5513 | pragma solidity ^0.8.0;
   5514 | 
   5515 | import {IAllowanceTransfer} from "permit2/src/interfaces/IAllowanceTransfer.sol";
   5516 | 
   5517 | /// @title IPermit2Forwarder
>> 5518 | /// @notice Interface for the Permit2Forwarder contract
   5519 | interface IPermit2Forwarder {
   5520 |     /// @notice allows forwarding a single permit to permit2
   5521 |     /// @dev this function is payable to allow multicall with NATIVE based actions
   5522 |     /// @param owner the owner of the tokens
   5523 |     /// @param permitSingle the permit data
```

---

### 148. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5552 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5547 | pragma solidity >=0.5.0;
   5548 | 
   5549 | /// @title Pool state that never changes
   5550 | /// @notice These parameters are fixed for a pool forever, i.e., the methods will always return the same values
   5551 | interface IUniswapV3PoolImmutables {
>> 5552 |     /// @notice The contract that deployed the pool, which must adhere to the IUniswapV3Factory interface
   5553 |     /// @return The contract address
   5554 |     function factory() external view returns (address);
   5555 | 
   5556 |     /// @notice The first of the two tokens of the pool, sorted by address
   5557 |     /// @return The token contract address
```

---

### 149. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6364 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   6359 | 
   6360 | import {BalanceDelta} from "@uniswap/v4-core/src/types/BalanceDelta.sol";
   6361 | import {PositionInfo} from "../libraries/PositionInfoLibrary.sol";
   6362 | 
   6363 | /// @title ISubscriber
>> 6364 | /// @notice Interface that a Subscriber contract should implement to receive updates from the v4 position manager
   6365 | interface ISubscriber {
   6366 |     /// @notice Called when a position subscribes to this subscriber contract
   6367 |     /// @param tokenId the token ID of the position
   6368 |     /// @param data additional data passed in by the caller
   6369 |     function notifySubscribe(uint256 tokenId, bytes memory data) external;
```

---

### 150. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6415 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   6410 |  *
   6411 |  * For an implementation, see {ERC165}.
   6412 |  */
   6413 | interface IERC165 {
   6414 |     /**
>> 6415 |      * @dev Returns true if this contract implements the interface defined by
   6416 |      * `interfaceId`. See the corresponding
   6417 |      * https://eips.ethereum.org/EIPS/eip-165#how-interfaces-are-identified[EIP section]
   6418 |      * to learn more about how these ids are created.
   6419 |      *
   6420 |      * This function call must use less than 30 000 gas.
```

---

### 151. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 27 行
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
     24 |     {}
     25 | 
     26 |     modifier checkDeadline(uint256 deadline) {
>>   27 |         if (block.timestamp > deadline) revert TransactionDeadlinePassed();
     28 |         _;
     29 |     }
     30 | 
```

---

### 152. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1321 行
- **函数**: `permit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1318 |         bytes32 r,
   1319 |         bytes32 s
   1320 |     ) public virtual {
>> 1321 |         require(deadline >= block.timestamp, "PERMIT_DEADLINE_EXPIRED");
   1322 | 
   1323 |         // Unchecked because the only math done is incrementing
   1324 |         // the owner's nonce which cannot realistically overflow.
```

---

### 153. 🟢 [LOW] transfer-risk

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1030 行
- **函数**: `wrapETH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.355

**工具描述**: .transfer() 有 2300 gas 限制，在接收方为合约时可能失败。

**代码片段**:
```solidity
   1027 |         if (amount > 0) {
   1028 |             WETH9.deposit{value: amount}();
   1029 |             if (recipient != address(this)) {
>> 1030 |                 WETH9.transfer(recipient, amount);
   1031 |             }
   1032 |         }
   1033 |     }
```

---

### 154. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1588 行
- **函数**: `invalidateNonces()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1585 |     uint128 internal constant OPEN_DELTA = 0;
   1586 |     /// @notice used to signal that an action should use the contract's entire balance of a currency
   1587 |     /// This value is equivalent to 1<<255, i.e. a singular 1 in the most significant bit.
>> 1588 |     uint256 internal constant CONTRACT_BALANCE = 0x8000000000000000000000000000000000000000000000000000000000000000;
   1589 | 
   1590 |     /// @notice used to signal that the recipient of an action should be the msgSender
   1591 |     address internal constant MSG_SENDER = address(1);
```

---

### 155. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2577 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2574 |                 let fmp := mload(0x40)
   2575 | 
   2576 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 2577 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   2578 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   2579 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   2580 | 
```

---

### 156. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 2578 行
- **函数**: `transfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   2575 | 
   2576 |                 // Write the abi-encoded calldata into memory, beginning with the function selector.
   2577 |                 mstore(fmp, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
>> 2578 |                 mstore(add(fmp, 4), and(to, 0xffffffffffffffffffffffffffffffffffffffff)) // Append and mask the "to" argument.
   2579 |                 mstore(add(fmp, 36), amount) // Append the "amount" argument. Masking not required as it's a full 32 byte type.
   2580 | 
   2581 |                 success :=
```

---

### 157. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3276 行
- **函数**: `uniswapV3SwapCallback()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3273 | /// @notice A library used to store the maximum desired amount of input tokens for exact output swaps; used for checking slippage
   3274 | library MaxInputAmount {
   3275 |     // The slot holding the the maximum desired amount of input tokens, transiently. bytes32(uint256(keccak256("MaxAmountIn")) - 1)
>> 3276 |     bytes32 constant MAX_AMOUNT_IN_SLOT = 0xaf28d9864a81dfdf71cab65f4e5d79a0cf9b083905fb8971425e6cb581b3f692;
   3277 | 
   3278 |     function set(uint256 maxAmountIn) internal {
   3279 |         assembly ("memory-safe") {
```

---

### 158. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3359 行
- **函数**: `safeTransferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3356 |             let freeMemoryPointer := mload(0x40)
   3357 | 
   3358 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3359 |             mstore(freeMemoryPointer, 0x23b872dd00000000000000000000000000000000000000000000000000000000)
   3360 |             mstore(add(freeMemoryPointer, 4), from) // Append the "from" argument.
   3361 |             mstore(add(freeMemoryPointer, 36), to) // Append the "to" argument.
   3362 |             mstore(add(freeMemoryPointer, 68), amount) // Append the "amount" argument.
```

---

### 159. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3392 行
- **函数**: `safeTransfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3389 |             let freeMemoryPointer := mload(0x40)
   3390 | 
   3391 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3392 |             mstore(freeMemoryPointer, 0xa9059cbb00000000000000000000000000000000000000000000000000000000)
   3393 |             mstore(add(freeMemoryPointer, 4), to) // Append the "to" argument.
   3394 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument.
   3395 | 
```

---

### 160. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3424 行
- **函数**: `safeApprove()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3421 |             let freeMemoryPointer := mload(0x40)
   3422 | 
   3423 |             // Write the abi-encoded calldata into memory, beginning with the function selector.
>> 3424 |             mstore(freeMemoryPointer, 0x095ea7b300000000000000000000000000000000000000000000000000000000)
   3425 |             mstore(add(freeMemoryPointer, 4), to) // Append the "to" argument.
   3426 |             mstore(add(freeMemoryPointer, 36), amount) // Append the "amount" argument.
   3427 | 
```

---

### 161. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3544 行
- **函数**: `permit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3541 | /// TODO: This library can be deleted when we have the transient keyword support in solidity.
   3542 | library Locker {
   3543 |     // The slot holding the locker state, transiently. bytes32(uint256(keccak256("Locker")) - 1)
>> 3544 |     bytes32 constant LOCKER_SLOT = 0x0e87e1788ebd9ed6a7e63c70a374cd3283e41cad601d21fbe27863899ed4a708;
   3545 | 
   3546 |     function set(address locker) internal {
   3547 |         // The locker is always msg.sender or address(0) so does not need to be cleaned
```

---

### 162. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4925 行
- **函数**: `revertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4922 |     function revertWith(bytes4 selector, address addr) internal pure {
   4923 |         assembly ("memory-safe") {
   4924 |             mstore(0, selector)
>> 4925 |             mstore(0x04, and(addr, 0xffffffffffffffffffffffffffffffffffffffff))
   4926 |             revert(0, 0x24)
   4927 |         }
   4928 |     }
```

---

### 163. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4943 行
- **函数**: `revertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4940 |     function revertWith(bytes4 selector, uint160 value) internal pure {
   4941 |         assembly ("memory-safe") {
   4942 |             mstore(0, selector)
>> 4943 |             mstore(0x04, and(value, 0xffffffffffffffffffffffffffffffffffffffff))
   4944 |             revert(0, 0x24)
   4945 |         }
   4946 |     }
```

---

### 164. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4964 行
- **函数**: `revertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4961 |         assembly ("memory-safe") {
   4962 |             let fmp := mload(0x40)
   4963 |             mstore(fmp, selector)
>> 4964 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
   4965 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   4966 |             revert(fmp, 0x44)
   4967 |         }
```

---

### 165. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4965 行
- **函数**: `revertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4962 |             let fmp := mload(0x40)
   4963 |             mstore(fmp, selector)
   4964 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
>> 4965 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   4966 |             revert(fmp, 0x44)
   4967 |         }
   4968 |     }
```

---

### 166. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4975 行
- **函数**: `revertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4972 |         assembly ("memory-safe") {
   4973 |             let fmp := mload(0x40)
   4974 |             mstore(fmp, selector)
>> 4975 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
   4976 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   4977 |             revert(fmp, 0x44)
   4978 |         }
```

---

### 167. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4976 行
- **函数**: `revertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4973 |             let fmp := mload(0x40)
   4974 |             mstore(fmp, selector)
   4975 |             mstore(add(fmp, 0x04), and(value1, 0xffffffffffffffffffffffffffffffffffffffff))
>> 4976 |             mstore(add(fmp, 0x24), and(value2, 0xffffffffffffffffffffffffffffffffffffffff))
   4977 |             revert(fmp, 0x44)
   4978 |         }
   4979 |     }
```

---

### 168. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 4997 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4994 | 
   4995 |             // Encode wrapped error selector, address, function selector, offset, additional context, size, revert reason
   4996 |             mstore(fmp, wrappedErrorSelector)
>> 4997 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   4998 |             mstore(
   4999 |                 add(fmp, 0x24),
   5000 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
```

---

### 169. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5000 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   4997 |             mstore(add(fmp, 0x04), and(revertingContract, 0xffffffffffffffffffffffffffffffffffffffff))
   4998 |             mstore(
   4999 |                 add(fmp, 0x24),
>> 5000 |                 and(revertingFunctionSelector, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   5001 |             )
   5002 |             // offset revert reason
   5003 |             mstore(add(fmp, 0x44), 0x80)
```

---

### 170. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5015 行
- **函数**: `bubbleUpAndRevertWith()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5012 |             // additional context
   5013 |             mstore(
   5014 |                 add(fmp, add(0xc4, encodedDataSize)),
>> 5015 |                 and(additionalContext, 0xffffffff00000000000000000000000000000000000000000000000000000000)
   5016 |             )
   5017 |             revert(fmp, add(0xe4, encodedDataSize))
   5018 |         }
```

---

### 171. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5168 行
- **函数**: `WETH9()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5165 | 
   5166 | /// @title Provides functions for deriving a pool address from the factory, tokens, and the fee
   5167 | library PoolAddress {
>> 5168 |     bytes32 internal constant POOL_INIT_CODE_HASH = 0xa598dd2fba360510c5a8f02f44423a4468e902df5857dbce3ca162a43a3a31ff;
   5169 | 
   5170 |     /// @notice The identifying key of the pool
   5171 |     struct PoolKey {
```

---

### 172. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5254 行
- **函数**: `computeAddress()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5251 | library PositionInfoLibrary {
   5252 |     PositionInfo internal constant EMPTY_POSITION_INFO = PositionInfo.wrap(0);
   5253 | 
>> 5254 |     uint256 internal constant MASK_UPPER_200_BITS = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000000000;
   5255 |     uint256 internal constant MASK_8_BITS = 0xFF;
   5256 |     uint24 internal constant MASK_24_BITS = 0xFFFFFF;
   5257 |     uint256 internal constant SET_UNSUBSCRIBE = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00;
```

---

### 173. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5257 行
- **函数**: `computeAddress()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5254 |     uint256 internal constant MASK_UPPER_200_BITS = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00000000000000;
   5255 |     uint256 internal constant MASK_8_BITS = 0xFF;
   5256 |     uint24 internal constant MASK_24_BITS = 0xFFFFFF;
>> 5257 |     uint256 internal constant SET_UNSUBSCRIBE = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00;
   5258 |     uint256 internal constant SET_SUBSCRIBE = 0x01;
   5259 |     uint8 internal constant TICK_LOWER_OFFSET = 8;
   5260 |     uint8 internal constant TICK_UPPER_OFFSET = 32;
```

---

### 174. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6219 行
- **函数**: `mostSignificantBit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6216 |             r := or(r, shl(3, lt(0xff, shr(r, x))))
   6217 |             // forgefmt: disable-next-item
   6218 |             r := or(r, byte(and(0x1f, shr(shr(r, x), 0x8421084210842108cc6318c6db6d54be)),
>> 6219 |                 0x0706060506020500060203020504000106050205030304010505030400000000))
   6220 |         }
   6221 |     }
   6222 | 
```

---

### 175. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6237 行
- **函数**: `leastSignificantBit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6234 |             // Credit to adhusson: https://blog.adhusson.com/cheap-find-first-set-evm/
   6235 |             // forgefmt: disable-next-item
   6236 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
>> 6237 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
   6238 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   6239 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   6240 |             // forgefmt: disable-next-item
```

---

### 176. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6238 行
- **函数**: `leastSignificantBit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6235 |             // forgefmt: disable-next-item
   6236 |             r := shl(5, shr(252, shl(shl(2, shr(250, mul(x,
   6237 |                 0xb6db6db6ddddddddd34d34d349249249210842108c6318c639ce739cffffffff))),
>> 6238 |                 0x8040405543005266443200005020610674053026020000107506200176117077)))
   6239 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   6240 |             // forgefmt: disable-next-item
   6241 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
```

---

### 177. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6242 行
- **函数**: `leastSignificantBit()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6239 |             // For the lower 5 bits of the result, use a De Bruijn lookup.
   6240 |             // forgefmt: disable-next-item
   6241 |             r := or(r, byte(and(div(0xd76453e0, shr(r, x)), 0x1f),
>> 6242 |                 0x001f0d1e100c1d070f090b19131c1706010e11080a1a141802121b1503160405))
   6243 |         }
   6244 |     }
   6245 | }
```

---

### 178. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6321 行
- **函数**: `currencyDelta()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6318 |     function currencyDelta(IPoolManager manager, address target, Currency currency) internal view returns (int256) {
   6319 |         bytes32 key;
   6320 |         assembly ("memory-safe") {
>> 6321 |             mstore(0, and(target, 0xffffffffffffffffffffffffffffffffffffffff))
   6322 |             mstore(32, and(currency, 0xffffffffffffffffffffffffffffffffffffffff))
   6323 |             key := keccak256(0, 64)
   6324 |         }
```

---

### 179. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6322 行
- **函数**: `currencyDelta()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6319 |         bytes32 key;
   6320 |         assembly ("memory-safe") {
   6321 |             mstore(0, and(target, 0xffffffffffffffffffffffffffffffffffffffff))
>> 6322 |             mstore(32, and(currency, 0xffffffffffffffffffffffffffffffffffffffff))
   6323 |             key := keccak256(0, 64)
   6324 |         }
   6325 |         return int256(uint256(manager.exttload(key)));
```

---

### 180. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6452 行
- **函数**: `unlockCallback()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6449 |     using CustomRevert for bytes4;
   6450 | 
   6451 |     /// bytes32(uint256(keccak256("ReservesOf")) - 1)
>> 6452 |     bytes32 constant RESERVES_OF_SLOT = 0x1e0745a7db1623981f0b2a5d4232364c00787266eb75ad546f190e6cebe9bd95;
   6453 |     /// bytes32(uint256(keccak256("Currency")) - 1)
   6454 |     bytes32 constant CURRENCY_SLOT = 0x27e098c505d44ec3574004bca052aabf76bd35004c182099d8c575fb238593b9;
   6455 | 
```

---

### 181. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6454 行
- **函数**: `unlockCallback()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6451 |     /// bytes32(uint256(keccak256("ReservesOf")) - 1)
   6452 |     bytes32 constant RESERVES_OF_SLOT = 0x1e0745a7db1623981f0b2a5d4232364c00787266eb75ad546f190e6cebe9bd95;
   6453 |     /// bytes32(uint256(keccak256("Currency")) - 1)
>> 6454 |     bytes32 constant CURRENCY_SLOT = 0x27e098c505d44ec3574004bca052aabf76bd35004c182099d8c575fb238593b9;
   6455 | 
   6456 |     function getSyncedCurrency() internal view returns (Currency currency) {
   6457 |         assembly ("memory-safe") {
```

---

### 182. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6470 行
- **函数**: `syncCurrencyAndReserves()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6467 | 
   6468 |     function syncCurrencyAndReserves(Currency currency, uint256 value) internal {
   6469 |         assembly ("memory-safe") {
>> 6470 |             tstore(CURRENCY_SLOT, and(currency, 0xffffffffffffffffffffffffffffffffffffffff))
   6471 |             tstore(RESERVES_OF_SLOT, value)
   6472 |         }
   6473 |     }
```

---

### 183. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6494 行
- **函数**: `getSyncedReserves()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6491 | library NonzeroDeltaCount {
   6492 |     // The slot holding the number of nonzero deltas. bytes32(uint256(keccak256("NonzeroDeltaCount")) - 1)
   6493 |     bytes32 internal constant NONZERO_DELTA_COUNT_SLOT =
>> 6494 |         0x7d4b3164c6e45b97e7d87b7125a44c5828d005af88f9d751cfd78729c5d99a0b;
   6495 | 
   6496 |     function read() internal view returns (uint256 count) {
   6497 |         assembly ("memory-safe") {
```

---

### 184. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 6531 行
- **函数**: `decrement()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   6528 | /// TODO: This library can be deleted when we have the transient keyword support in solidity.
   6529 | library Lock {
   6530 |     // The slot holding the unlocked state, transiently. bytes32(uint256(keccak256("Unlocked")) - 1)
>> 6531 |     bytes32 internal constant IS_UNLOCKED_SLOT = 0xc090fc4683624cfc3884e9d8de5eca132f2d0ec062aff75d43c0465d5ceeab23;
   6532 | 
   6533 |     function unlock() internal {
   6534 |         assembly ("memory-safe") {
```

---

### 185. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 137 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    134 |                         uint256 amountIn;
    135 |                         uint256 amountOutMin;
    136 |                         bool payerIsUser;
>>  137 |                         assembly {
    138 |                             recipient := calldataload(inputs.offset)
    139 |                             amountIn := calldataload(add(inputs.offset, 0x20))
    140 |                             amountOutMin := calldataload(add(inputs.offset, 0x40))
```

---

### 186. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 153 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    150 |                         uint256 amountOut;
    151 |                         uint256 amountInMax;
    152 |                         bool payerIsUser;
>>  153 |                         assembly {
    154 |                             recipient := calldataload(inputs.offset)
    155 |                             amountOut := calldataload(add(inputs.offset, 0x20))
    156 |                             amountInMax := calldataload(add(inputs.offset, 0x40))
```

---

### 187. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 168 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    165 |                         address token;
    166 |                         address recipient;
    167 |                         uint160 amount;
>>  168 |                         assembly {
    169 |                             token := calldataload(inputs.offset)
    170 |                             recipient := calldataload(add(inputs.offset, 0x20))
    171 |                             amount := calldataload(add(inputs.offset, 0x40))
```

---

### 188. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 176 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    173 |                         permit2TransferFrom(token, msgSender(), map(recipient), amount);
    174 |                     } else if (command == Commands.PERMIT2_PERMIT_BATCH) {
    175 |                         IAllowanceTransfer.PermitBatch calldata permitBatch;
>>  176 |                         assembly {
    177 |                             // this is a variable length struct, so calldataload(inputs.offset) contains the
    178 |                             // offset from inputs.offset at which the struct begins
    179 |                             permitBatch := add(inputs.offset, calldataload(inputs.offset))
```

---

### 189. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 195 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    192 |                         address token;
    193 |                         address recipient;
    194 |                         uint160 amountMin;
>>  195 |                         assembly {
    196 |                             token := calldataload(inputs.offset)
    197 |                             recipient := calldataload(add(inputs.offset, 0x20))
    198 |                             amountMin := calldataload(add(inputs.offset, 0x40))
```

---

### 190. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 206 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    203 |                         address token;
    204 |                         address recipient;
    205 |                         uint256 value;
>>  206 |                         assembly {
    207 |                             token := calldataload(inputs.offset)
    208 |                             recipient := calldataload(add(inputs.offset, 0x20))
    209 |                             value := calldataload(add(inputs.offset, 0x40))
```

---

### 191. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 217 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    214 |                         address token;
    215 |                         address recipient;
    216 |                         uint256 bips;
>>  217 |                         assembly {
    218 |                             token := calldataload(inputs.offset)
    219 |                             recipient := calldataload(add(inputs.offset, 0x20))
    220 |                             bips := calldataload(add(inputs.offset, 0x40))
```

---

### 192. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 235 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    232 |                         uint256 amountIn;
    233 |                         uint256 amountOutMin;
    234 |                         bool payerIsUser;
>>  235 |                         assembly {
    236 |                             recipient := calldataload(inputs.offset)
    237 |                             amountIn := calldataload(add(inputs.offset, 0x20))
    238 |                             amountOutMin := calldataload(add(inputs.offset, 0x40))
```

---

### 193. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 251 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    248 |                         uint256 amountOut;
    249 |                         uint256 amountInMax;
    250 |                         bool payerIsUser;
>>  251 |                         assembly {
    252 |                             recipient := calldataload(inputs.offset)
    253 |                             amountOut := calldataload(add(inputs.offset, 0x20))
    254 |                             amountInMax := calldataload(add(inputs.offset, 0x40))
```

---

### 194. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 264 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    261 |                     } else if (command == Commands.PERMIT2_PERMIT) {
    262 |                         // equivalent: abi.decode(inputs, (IAllowanceTransfer.PermitSingle, bytes))
    263 |                         IAllowanceTransfer.PermitSingle calldata permitSingle;
>>  264 |                         assembly {
    265 |                             permitSingle := inputs.offset
    266 |                         }
    267 |                         bytes calldata data = inputs.toBytes(6); // PermitSingle takes first 6 slots (0..5)
```

---

### 195. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 280 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    277 |                         // equivalent: abi.decode(inputs, (address, uint256))
    278 |                         address recipient;
    279 |                         uint256 amount;
>>  280 |                         assembly {
    281 |                             recipient := calldataload(inputs.offset)
    282 |                             amount := calldataload(add(inputs.offset, 0x20))
    283 |                         }
```

---

### 196. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 289 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    286 |                         // equivalent: abi.decode(inputs, (address, uint256))
    287 |                         address recipient;
    288 |                         uint256 amountMin;
>>  289 |                         assembly {
    290 |                             recipient := calldataload(inputs.offset)
    291 |                             amountMin := calldataload(add(inputs.offset, 0x20))
    292 |                         }
```

---

### 197. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 297 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    294 |                     } else if (command == Commands.PERMIT2_TRANSFER_FROM_BATCH) {
    295 |                         IAllowanceTransfer.AllowanceTransferDetails[] calldata batchDetails;
    296 |                         (uint256 length, uint256 offset) = inputs.toLengthOffset(0);
>>  297 |                         assembly {
    298 |                             batchDetails.length := length
    299 |                             batchDetails.offset := offset
    300 |                         }
```

---

### 198. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 307 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    304 |                         address owner;
    305 |                         address token;
    306 |                         uint256 minBalance;
>>  307 |                         assembly {
    308 |                             owner := calldataload(inputs.offset)
    309 |                             token := calldataload(add(inputs.offset, 0x20))
    310 |                             minBalance := calldataload(add(inputs.offset, 0x40))
```

---

### 199. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 334 行
- **函数**: `dispatch()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    331 |                 } else if (command == Commands.V4_INITIALIZE_POOL) {
    332 |                     PoolKey calldata poolKey;
    333 |                     uint160 sqrtPriceX96;
>>  334 |                     assembly {
    335 |                         poolKey := inputs.offset
    336 |                         sqrtPriceX96 := calldataload(add(inputs.offset, 0xa0))
    337 |                     }
```

---

### 200. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 883 行
- **函数**: `toAddress()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    880 |     /// @return _address The address starting at byte 0
    881 |     function toAddress(bytes calldata _bytes) internal pure returns (address _address) {
    882 |         if (_bytes.length < Constants.ADDR_SIZE) revert SliceOutOfBounds();
>>  883 |         assembly {
    884 |             _address := shr(96, calldataload(_bytes.offset))
    885 |         }
    886 |     }
```

---

### 201. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 896 行
- **函数**: `toPool()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    893 |     /// @return token1 The address at byte 23
    894 |     function toPool(bytes calldata _bytes) internal pure returns (address token0, uint24 fee, address token1) {
    895 |         if (_bytes.length < Constants.V3_POP_OFFSET) revert SliceOutOfBounds();
>>  896 |         assembly {
    897 |             let firstWord := calldataload(_bytes.offset)
    898 |             token0 := shr(96, firstWord)
    899 |             fee := and(shr(72, firstWord), 0xffffff)
```

---

### 202. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 917 行
- **函数**: `toLengthOffset()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    914 |         returns (uint256 length, uint256 offset)
    915 |     {
    916 |         uint256 relativeOffset;
>>  917 |         assembly {
    918 |             // The offset of the `_arg`-th element is `32 * arg`, which stores the offset of the length pointer.
    919 |             // shl(5, x) is equivalent to mul(32, x)
    920 |             let lengthPtr := add(_bytes.offset, calldataload(add(_bytes.offset, shl(5, _arg))))
```

---

### 203. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 933 行
- **函数**: `toAddressArray()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    930 |     /// @param _arg The index of the argument to extract
    931 |     function toAddressArray(bytes calldata _bytes, uint256 _arg) internal pure returns (address[] calldata res) {
    932 |         (uint256 length, uint256 offset) = toLengthOffset(_bytes, _arg);
>>  933 |         assembly {
    934 |             res.length := length
    935 |             res.offset := offset
    936 |         }
```

---

### 204. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1090 行
- **函数**: `_checkV3PermitCall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1087 |     /// @dev check that a call is to the ERC721 permit function
   1088 |     function _checkV3PermitCall(bytes calldata inputs) internal pure {
   1089 |         bytes4 selector;
>> 1090 |         assembly {
   1091 |             selector := calldataload(inputs.offset)
   1092 |         }
   1093 | 
```

---

### 205. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1102 行
- **函数**: `_checkV3PositionManagerCall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1099 |     /// @dev check that the v3 position manager call is a safe call
   1100 |     function _checkV3PositionManagerCall(bytes calldata inputs, address caller) internal view {
   1101 |         bytes4 selector;
>> 1102 |         assembly {
   1103 |             selector := calldataload(inputs.offset)
   1104 |         }
   1105 | 
```

---

### 206. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1111 行
- **函数**: `_checkV3PositionManagerCall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1108 |         }
   1109 | 
   1110 |         uint256 tokenId;
>> 1111 |         assembly {
   1112 |             // tokenId is always the first parameter in the valid actions
   1113 |             tokenId := calldataload(add(inputs.offset, 0x04))
   1114 |         }
```

---

### 207. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 1130 行
- **函数**: `_checkV4PositionManagerCall()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1127 |     /// their position, an attacker could take their fees, or drain their entire position
   1128 |     function _checkV4PositionManagerCall(bytes calldata inputs) internal view {
   1129 |         bytes4 selector;
>> 1130 |         assembly {
   1131 |             selector := calldataload(inputs.offset)
   1132 |         }
   1133 |         if (selector != V4_POSITION_MANAGER.modifyLiquidities.selector) {
```

---

### 208. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3333 行
- **函数**: `safeTransferETH()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3330 |         bool success;
   3331 | 
   3332 |         /// @solidity memory-safe-assembly
>> 3333 |         assembly {
   3334 |             // Transfer the ETH and store if it succeeded or not.
   3335 |             success := call(gas(), to, amount, 0, 0, 0, 0)
   3336 |         }
```

---

### 209. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3354 行
- **函数**: `safeTransferFrom()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3351 |         bool success;
   3352 | 
   3353 |         /// @solidity memory-safe-assembly
>> 3354 |         assembly {
   3355 |             // Get a pointer to some free memory.
   3356 |             let freeMemoryPointer := mload(0x40)
   3357 | 
```

---

### 210. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3387 行
- **函数**: `safeTransfer()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3384 |         bool success;
   3385 | 
   3386 |         /// @solidity memory-safe-assembly
>> 3387 |         assembly {
   3388 |             // Get a pointer to some free memory.
   3389 |             let freeMemoryPointer := mload(0x40)
   3390 | 
```

---

### 211. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 3419 行
- **函数**: `safeApprove()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   3416 |         bool success;
   3417 | 
   3418 |         /// @solidity memory-safe-assembly
>> 3419 |         assembly {
   3420 |             // Get a pointer to some free memory.
   3421 |             let freeMemoryPointer := mload(0x40)
   3422 | 
```

---

### 212. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x1906c1d672b88cD1B9aC7593301cA990F94Eae07` 第 5313 行
- **函数**: `initialize()`
- **合约**: `UniversalRouter`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   5310 |         returns (PositionInfo info)
   5311 |     {
   5312 |         bytes25 _poolId = bytes25(PoolId.unwrap(_poolKey.toId()));
>> 5313 |         assembly {
   5314 |             info :=
   5315 |                 or(
   5316 |                     or(and(MASK_UPPER_200_BITS, _poolId), shl(TICK_UPPER_OFFSET, and(MASK_24_BITS, _tickUpper))),
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*