# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:56:33
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` |
| contract_name | `GMTokenManager` |
| compiler_version | `v0.8.16+commit.07a7930e` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `london` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/globalMarkets/tokenManager/GMTokenManager.sol', 'contracts/globalMarkets/tokenManager/issuanceHours/IIssuanceHours.sol', 'contracts/xManager/interfaces/IOndoIDRegistry.sol', 'contracts/xManager/interfaces/IOndoRateLimiter.sol', 'contracts/interfaces/IRWALike.sol', 'contracts/globalMarkets/tokenManager/IGMTokenManagerErrors.sol', 'contracts/globalMarkets/tokenManager/IGMTokenManagerEvents.sol', 'contracts/external/openzeppelin/contracts/access/AccessControlEnumerable.sol', 'contracts/external/openzeppelin/contracts/security/ReentrancyGuard.sol', 'contracts/external/openzeppelin/contracts/token/SafeERC20.sol', 'contracts/external/openzeppelin/contracts/utils/cryptography/EIP712.sol', 'contracts/external/openzeppelin/contracts/utils/cryptography/ECDSA.sol', 'contracts/globalMarkets/tokenManager/IGMTokenManager.sol', 'contracts/globalMarkets/tokenManager/sanityCheckOracle/IOndoSanityCheckOracle.sol', 'contracts/globalMarkets/USDonManager/IUSDonManager.sol', 'contracts/external/openzeppelin/contracts/token/IERC20.sol', 'contracts/external/openzeppelin/contracts/access/IAccessControlEnumerable.sol', 'contracts/external/openzeppelin/contracts/access/AccessControl.sol', 'contracts/external/openzeppelin/contracts/utils/EnumerableSet.sol', 'contracts/external/openzeppelin/contracts/utils/Strings.sol', 'contracts/external/openzeppelin/contracts/access/IAccessControl.sol', 'contracts/external/openzeppelin/contracts/utils/Context.sol', 'contracts/external/openzeppelin/contracts/utils/ERC165.sol', 'contracts/external/openzeppelin/contracts/utils/IERC165.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646141` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 18 |
| 🟢 LOW | 6 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 540 行
- **函数**: `getDomainSeparator()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    537 |    * @notice Returns the domain separator for EIP712
    538 |    * @return The domain separator
    539 |    */
>>  540 |   function getDomainSeparator() public view returns (bytes32) {
    541 |     return _domainSeparatorV4();
    542 |   }
    543 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1766 行
- **函数**: `validatePrice()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1763 |  * @notice Interface for validating prices with the sanity check oracle
   1764 |  */
   1765 | interface IOndoSanityCheckOracle {
>> 1766 |   function validatePrice(address token, uint256 price) external view;
   1767 | }
   1768 | 
   1769 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1822 行
- **函数**: `totalSupply()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1819 |   /**
   1820 |    * @dev Returns the amount of tokens in existence.
   1821 |    */
>> 1822 |   function totalSupply() external view returns (uint256);
   1823 | 
   1824 |   /**
   1825 |    * @dev Returns the amount of tokens owned by `account`.
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1827 行
- **函数**: `balanceOf()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1824 |   /**
   1825 |    * @dev Returns the amount of tokens owned by `account`.
   1826 |    */
>> 1827 |   function balanceOf(address account) external view returns (uint256);
   1828 | 
   1829 |   /**
   1830 |    * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1836 行
- **函数**: `transfer()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1833 |    *
   1834 |    * Emits a {Transfer} event.
   1835 |    */
>> 1836 |   function transfer(address to, uint256 amount) external returns (bool);
   1837 | 
   1838 |   /**
   1839 |    * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1864 行
- **函数**: `approve()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1861 |    *
   1862 |    * Emits an {Approval} event.
   1863 |    */
>> 1864 |   function approve(address spender, uint256 amount) external returns (bool);
   1865 | 
   1866 |   /**
   1867 |    * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1931 行
- **函数**: `getRoleMemberCount()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1928 |    * @dev Returns the number of accounts that have `role`. Can be used
   1929 |    * together with {getRoleMember} to enumerate all bearers of a role.
   1930 |    */
>> 1931 |   function getRoleMemberCount(bytes32 role) external view returns (uint256);
   1932 | }
   1933 | 
   1934 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 2127 行
- **函数**: `renounceRole()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2124 |    *
   2125 |    * - the caller must be `account`.
   2126 |    */
>> 2127 |   function renounceRole(bytes32 role, address account) public virtual override {
   2128 |     require(
   2129 |       account == _msgSender(),
   2130 |       "AccessControl: can only renounce roles for self"
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 2730 行
- **函数**: `hasRole()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2727 |   /**
   2728 |    * @dev Returns `true` if `account` has been granted `role`.
   2729 |    */
>> 2730 |   function hasRole(bytes32 role, address account) external view returns (bool);
   2731 | 
   2732 |   /**
   2733 |    * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 2738 行
- **函数**: `getRoleAdmin()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2735 |    *
   2736 |    * To change a role's admin, use {AccessControl-_setRoleAdmin}.
   2737 |    */
>> 2738 |   function getRoleAdmin(bytes32 role) external view returns (bytes32);
   2739 | 
   2740 |   /**
   2741 |    * @dev Grants `role` to `account`.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 2873 行
- **函数**: `supportsInterface()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2870 |    *
   2871 |    * This function call must use less than 30 000 gas.
   2872 |    */
>> 2873 |   function supportsInterface(bytes4 interfaceId) external view returns (bool);
   2874 | }
   2875 | 
```

---

### 12. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 40 行
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     35 | 
     36 | /**
     37 |  * @title  GMTokenManager
     38 |  * @author Ondo Finance
     39 |  * @notice Contract for managing tokenized equity assets
>>   40 |  * @notice The GMTokenManager contract contains the core logic for processing minting
     41 |  *         and redemptions of GM tokens.
     42 |  *         The responsibilities of this contract are:
     43 |  *          - Verifying attestation signatures
     44 |  *          - Calculating the amount of GM tokens and USDon to mint and burn
     45 |  *            based on the quote attestation that was received
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 786 行
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    781 | pragma solidity 0.8.16;
    782 | 
    783 | /**
    784 |  * @title  IGMTokenManagerErrors
    785 |  * @author Ondo Finance
>>  786 |  * @notice Isolated contract for all errors emitted by the GMTokenManager contract
    787 |  */
    788 | interface IGMTokenManagerErrors {
    789 |   /// Error emitted when the token address is zero
    790 |   error TokenAddressCantBeZero();
    791 | 
```

---

### 14. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 875 行
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    870 | pragma solidity 0.8.16;
    871 | 
    872 | /**
    873 |  * @title  IGMTokenManagerEvents
    874 |  * @author Ondo Finance
>>  875 |  * @notice Isolated contract for all events emitted by the GMTokenManager contract
    876 |  */
    877 | interface IGMTokenManagerEvents {
    878 |   /**
    879 |    * @notice Event emitted when an admin completes a mint for a recipient
    880 |    * @param  recipient    The address of the recipient that receives the RWA tokens
```

---

### 15. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1149 行
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1144 |   constructor() {
   1145 |     _status = _NOT_ENTERED;
   1146 |   }
   1147 | 
   1148 |   /**
>> 1149 |    * @dev Prevents a contract from calling itself, directly or indirectly.
   1150 |    * Calling a `nonReentrant` function from another `nonReentrant`
   1151 |    * function is not supported. It is possible to prevent this from happening
   1152 |    * by making the `nonReentrant` function external, and making it call a
   1153 |    * `private` function that does the actual work.
   1154 |    */
```

---

### 16. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1183 行
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1178 | import "contracts/external/openzeppelin/contracts/token/IERC20.sol";
   1179 | 
   1180 | /**
   1181 |  * @title SafeERC20
   1182 |  * @dev Wrappers around ERC-20 operations that throw on failure (when the token
>> 1183 |  * contract returns false). Tokens that return no value (and instead revert or
   1184 |  * throw on failure) are also supported, non-reverting calls are assumed to be
   1185 |  * successful.
   1186 |  * To use this library you can add a `using SafeERC20 for IERC20;` statement to your contract,
   1187 |  * which allows you to call the safe operations as `token.safeTransfer(...)`, etc.
   1188 |  */
```

---

### 17. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1339 行
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1334 |  * ({_hashTypedDataV4}).
   1335 |  *
   1336 |  * The implementation of the domain separator was designed to be as efficient as possible while still properly updating
   1337 |  * the chain id to protect against replay attacks on an eventual fork of the chain.
   1338 |  *
>> 1339 |  * NOTE: This contract implements the version of the encoding known as "v4", as implemented by the JSON RPC method
   1340 |  * https://docs.metamask.io/guide/signing-data.html[`eth_signTypedDataV4` in MetaMask].
   1341 |  *
   1342 |  * _Available since v3.4._
   1343 |  */
   1344 | abstract contract EIP712 {
```

---

### 18. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1791 行
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1786 | pragma solidity 0.8.16;
   1787 | 
   1788 | /**
   1789 |  * @title  IUSDonManager
   1790 |  * @author Ondo Finance
>> 1791 |  * @notice This contract provides an interface for conducting instant USDon swaps.
   1792 |  */
   1793 | interface IUSDonManager {
   1794 |   function subscribe(
   1795 |     address depositToken,
   1796 |     uint256 depositAmount,
```

---

### 19. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 336 行
- **函数**: `_verifyQuote()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    333 |     if (executedAttestationIds[quote.attestationId])
    334 |       revert AttestationAlreadyExecuted();
    335 | 
>>  336 |     if (block.timestamp > quote.expiration) revert AttestationExpired();
    337 | 
    338 |     if (userId != quote.userId) revert UserIdMismatch(userId, quote.userId);
    339 | 
```

---

### 20. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1531 行
- **函数**: `tryRecover()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1528 |         bytes32 r,
   1529 |         bytes32 vs
   1530 |     ) internal pure returns (address, RecoverError) {
>> 1531 |         bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
   1532 |         uint8 v = uint8((uint256(vs) >> 255) + 27);
   1533 |         return tryRecover(hash, v, r, s);
   1534 |     }
```

---

### 21. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1572 行
- **函数**: `tryRecover()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1569 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
   1570 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
   1571 |         // these malleable signatures as well.
>> 1572 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
   1573 |             return (address(0), RecoverError.InvalidSignatureS);
   1574 |         }
   1575 | 
```

---

### 22. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 1488 行
- **函数**: `tryRecover()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1485 |             // ecrecover takes the signature parameters, and the only way to get them
   1486 |             // currently is to use assembly.
   1487 |             /// @solidity memory-safe-assembly
>> 1488 |             assembly {
   1489 |                 r := mload(add(signature, 0x20))
   1490 |                 s := mload(add(signature, 0x40))
   1491 |                 v := byte(0, mload(add(signature, 0x60)))
```

---

### 23. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 2508 行
- **函数**: `values()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2505 |     bytes32[] memory store = _values(set._inner);
   2506 |     address[] memory result;
   2507 | 
>> 2508 |     assembly {
   2509 |       result := store
   2510 |     }
   2511 | 
```

---

### 24. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0x91f8Aff3738825e8eB16FC6f6b1A7A4647bDB299` 第 2593 行
- **函数**: `values()`
- **合约**: `contains`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2590 |     bytes32[] memory store = _values(set._inner);
   2591 |     uint256[] memory result;
   2592 | 
>> 2593 |     assembly {
   2594 |       result := store
   2595 |     }
   2596 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*