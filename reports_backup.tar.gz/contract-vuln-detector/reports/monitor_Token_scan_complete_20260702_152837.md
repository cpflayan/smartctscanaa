# 智能合约安全审计报告

> 生成时间: 2026-07-02 15:28:37
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x9993799f771f02de08db70197972e84831Fec586` |
| contract_name | `Token` |
| compiler_version | `v0.8.33+commit.64118f21` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `shanghai` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['Token.sol', '@openzeppelin/contracts/token/ERC20/ERC20.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol', '@openzeppelin/contracts/access/Ownable.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/interfaces/draft-IERC6093.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655011` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 23 |
| 🟢 LOW | 0 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 77 行
- **函数**: `name()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     74 |     /**
     75 |      * @dev Returns the name of the token.
     76 |      */
>>   77 |     function name() public view virtual returns (string memory) {
     78 |         return _name;
     79 |     }
     80 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 85 行
- **函数**: `symbol()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     82 |      * @dev Returns the symbol of the token, usually a shorter version of the
     83 |      * name.
     84 |      */
>>   85 |     function symbol() public view virtual returns (string memory) {
     86 |         return _symbol;
     87 |     }
     88 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 102 行
- **函数**: `decimals()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     99 |      * no way affects any of the arithmetic of the contract, including
    100 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    101 |      */
>>  102 |     function decimals() public view virtual returns (uint8) {
    103 |         return 18;
    104 |     }
    105 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 107 行
- **函数**: `totalSupply()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    104 |     }
    105 | 
    106 |     /// @inheritdoc IERC20
>>  107 |     function totalSupply() public view virtual returns (uint256) {
    108 |         return _totalSupply;
    109 |     }
    110 | 
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 112 行
- **函数**: `balanceOf()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    109 |     }
    110 | 
    111 |     /// @inheritdoc IERC20
>>  112 |     function balanceOf(address account) public view virtual returns (uint256) {
    113 |         return _balances[account];
    114 |     }
    115 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 124 行
- **函数**: `transfer()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    121 |      * - `to` cannot be the zero address.
    122 |      * - the caller must have a balance of at least `value`.
    123 |      */
>>  124 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    125 |         address owner = _msgSender();
    126 |         _transfer(owner, to, value);
    127 |         return true;
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 131 行
- **函数**: `allowance()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    128 |     }
    129 | 
    130 |     /// @inheritdoc IERC20
>>  131 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    132 |         return _allowances[owner][spender];
    133 |     }
    134 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 145 行
- **函数**: `approve()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    142 |      *
    143 |      * - `spender` cannot be the zero address.
    144 |      */
>>  145 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    146 |         address owner = _msgSender();
    147 |         _approve(owner, spender, value);
    148 |         return true;
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 167 行
- **函数**: `transferFrom()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    164 |      * - the caller must have allowance for ``from``'s tokens of at least
    165 |      * `value`.
    166 |      */
>>  167 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    168 |         address spender = _msgSender();
    169 |         _spendAllowance(from, spender, value);
    170 |         _transfer(from, to, value);
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 360 行
- **函数**: `totalSupply()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    357 |     /**
    358 |      * @dev Returns the value of tokens in existence.
    359 |      */
>>  360 |     function totalSupply() external view returns (uint256);
    361 | 
    362 |     /**
    363 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 365 行
- **函数**: `balanceOf()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    362 |     /**
    363 |      * @dev Returns the value of tokens owned by `account`.
    364 |      */
>>  365 |     function balanceOf(address account) external view returns (uint256);
    366 | 
    367 |     /**
    368 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 374 行
- **函数**: `transfer()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    371 |      *
    372 |      * Emits a {Transfer} event.
    373 |      */
>>  374 |     function transfer(address to, uint256 value) external returns (bool);
    375 | 
    376 |     /**
    377 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 383 行
- **函数**: `allowance()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    380 |      *
    381 |      * This value changes when {approve} or {transferFrom} are called.
    382 |      */
>>  383 |     function allowance(address owner, address spender) external view returns (uint256);
    384 | 
    385 |     /**
    386 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 400 行
- **函数**: `approve()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    397 |      *
    398 |      * Emits an {Approval} event.
    399 |      */
>>  400 |     function approve(address spender, uint256 value) external returns (bool);
    401 | 
    402 |     /**
    403 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 411 行
- **函数**: `transferFrom()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    408 |      *
    409 |      * Emits a {Transfer} event.
    410 |      */
>>  411 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    412 | }
    413 | 
    414 | // ── @openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol ──────────────────────────────
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 430 行
- **函数**: `name()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    427 |     /**
    428 |      * @dev Returns the name of the token.
    429 |      */
>>  430 |     function name() external view returns (string memory);
    431 | 
    432 |     /**
    433 |      * @dev Returns the symbol of the token.
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 435 行
- **函数**: `symbol()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    432 |     /**
    433 |      * @dev Returns the symbol of the token.
    434 |      */
>>  435 |     function symbol() external view returns (string memory);
    436 | 
    437 |     /**
    438 |      * @dev Returns the decimals places of the token.
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 440 行
- **函数**: `decimals()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    437 |     /**
    438 |      * @dev Returns the decimals places of the token.
    439 |      */
>>  440 |     function decimals() external view returns (uint8);
    441 | }
    442 | 
    443 | // ── @openzeppelin/contracts/access/Ownable.sol ──────────────────────────────
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 500 行
- **函数**: `owner()`
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    497 |     /**
    498 |      * @dev Returns the address of the current owner.
    499 |      */
>>  500 |     function owner() public view virtual returns (address) {
    501 |         return _owner;
    502 |     }
    503 | 
```

---

### 20. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 9 行
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
      4 | pragma solidity ^0.8.33;
      5 | 
      6 | import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
      7 | import "@openzeppelin/contracts/access/Ownable.sol";
      8 | 
>>    9 | contract Token is ERC20, Ownable {
     10 | 
     11 |     constructor(
     12 |         string memory name_,
     13 |         string memory symbol_,
     14 |         uint256 number,
```

---

### 21. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 54 行
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     49 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
     50 |  * instead returning `false` on failure. This behavior is nonetheless
     51 |  * conventional and does not conflict with the expectations of ERC-20
     52 |  * applications.
     53 |  */
>>   54 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
     55 |     mapping(address account => uint256) private _balances;
     56 | 
     57 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
     58 | 
     59 |     uint256 private _totalSupply;
```

---

### 22. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 464 行
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    459 |  *
    460 |  * This module is used through inheritance. It will make available the modifier
    461 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    462 |  * the owner.
    463 |  */
>>  464 | abstract contract Ownable is Context {
    465 |     address private _owner;
    466 | 
    467 |     /**
    468 |      * @dev The caller account is not authorized to perform an operation.
    469 |      */
```

---

### 23. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x9993799f771f02de08db70197972e84831Fec586` 第 536 行
- **合约**: `Token`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    531 |         }
    532 |         _transferOwnership(newOwner);
    533 |     }
    534 | 
    535 |     /**
>>  536 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    537 |      * Internal function without access restriction.
    538 |      */
    539 |     function _transferOwnership(address newOwner) internal virtual {
    540 |         address oldOwner = _owner;
    541 |         _owner = newOwner;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*