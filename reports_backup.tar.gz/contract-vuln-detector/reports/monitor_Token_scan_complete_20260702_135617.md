# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:56:17
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xC73241A545Ec9461e084606d81719FB0dC490267` |
| contract_name | `Token` |
| compiler_version | `v0.8.20+commit.a1b79de6` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `shanghai` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646140` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 36 |
| 🟢 LOW | 1 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 57 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     54 |     /**
     55 |      * @dev Returns the value of tokens in existence.
     56 |      */
>>   57 |     function totalSupply() external view returns (uint256);
     58 | 
     59 |     /**
     60 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 62 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     59 |     /**
     60 |      * @dev Returns the value of tokens owned by `account`.
     61 |      */
>>   62 |     function balanceOf(address account) external view returns (uint256);
     63 | 
     64 |     /**
     65 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 71 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     68 |      *
     69 |      * Emits a {Transfer} event.
     70 |      */
>>   71 |     function transfer(address to, uint256 value) external returns (bool);
     72 | 
     73 |     /**
     74 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 80 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     77 |      *
     78 |      * This value changes when {approve} or {transferFrom} are called.
     79 |      */
>>   80 |     function allowance(address owner, address spender) external view returns (uint256);
     81 | 
     82 |     /**
     83 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 97 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     94 |      *
     95 |      * Emits an {Approval} event.
     96 |      */
>>   97 |     function approve(address spender, uint256 value) external returns (bool);
     98 | 
     99 |     /**
    100 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 108 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    105 |      *
    106 |      * Emits a {Transfer} event.
    107 |      */
>>  108 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    109 | }
    110 | 
    111 | // src/interfaces/IPancakeFactory.sol
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 116 行
- **函数**: `feeTo()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    113 | interface IPancakeFactory {
    114 |     event PairCreated(address indexed token0, address indexed token1, address pair, uint);
    115 | 
>>  116 |     function feeTo() external view returns (address);
    117 |     function feeToSetter() external view returns (address);
    118 | 
    119 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 117 行
- **函数**: `feeToSetter()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    114 |     event PairCreated(address indexed token0, address indexed token1, address pair, uint);
    115 | 
    116 |     function feeTo() external view returns (address);
>>  117 |     function feeToSetter() external view returns (address);
    118 | 
    119 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    120 |     function allPairs(uint) external view returns (address pair);
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 119 行
- **函数**: `getPair()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    116 |     function feeTo() external view returns (address);
    117 |     function feeToSetter() external view returns (address);
    118 | 
>>  119 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    120 |     function allPairs(uint) external view returns (address pair);
    121 |     function allPairsLength() external view returns (uint);
    122 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 120 行
- **函数**: `allPairs()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    117 |     function feeToSetter() external view returns (address);
    118 | 
    119 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
>>  120 |     function allPairs(uint) external view returns (address pair);
    121 |     function allPairsLength() external view returns (uint);
    122 | 
    123 |     function createPair(address tokenA, address tokenB) external returns (address pair);
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 121 行
- **函数**: `allPairsLength()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    118 | 
    119 |     function getPair(address tokenA, address tokenB) external view returns (address pair);
    120 |     function allPairs(uint) external view returns (address pair);
>>  121 |     function allPairsLength() external view returns (uint);
    122 | 
    123 |     function createPair(address tokenA, address tokenB) external returns (address pair);
    124 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 123 行
- **函数**: `createPair()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    120 |     function allPairs(uint) external view returns (address pair);
    121 |     function allPairsLength() external view returns (uint);
    122 | 
>>  123 |     function createPair(address tokenA, address tokenB) external returns (address pair);
    124 | 
    125 |     function setFeeTo(address) external;
    126 |     function setFeeToSetter(address) external;
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 132 行
- **函数**: `factory()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    129 | // src/interfaces/IPancakeRouter02.sol
    130 | 
    131 | interface IPancakeRouter01 {
>>  132 |     function factory() external pure returns (address);
    133 |     function WETH() external pure returns (address);
    134 | 
    135 |     function addLiquidity(
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 133 行
- **函数**: `WETH()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    130 | 
    131 | interface IPancakeRouter01 {
    132 |     function factory() external pure returns (address);
>>  133 |     function WETH() external pure returns (address);
    134 | 
    135 |     function addLiquidity(
    136 |         address tokenA,
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 208 行
- **函数**: `quote()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    205 |         payable
    206 |         returns (uint[] memory amounts);
    207 | 
>>  208 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    209 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    210 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    211 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 209 行
- **函数**: `getAmountOut()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    206 |         returns (uint[] memory amounts);
    207 | 
    208 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
>>  209 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    210 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    211 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    212 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 210 行
- **函数**: `getAmountIn()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    207 | 
    208 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    209 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
>>  210 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    211 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    212 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
    213 | }
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 211 行
- **函数**: `getAmountsOut()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    208 |     function quote(uint amountA, uint reserveA, uint reserveB) external pure returns (uint amountB);
    209 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    210 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
>>  211 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
    212 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
    213 | }
    214 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 212 行
- **函数**: `getAmountsIn()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    209 |     function getAmountOut(uint amountIn, uint reserveIn, uint reserveOut) external pure returns (uint amountOut);
    210 |     function getAmountIn(uint amountOut, uint reserveIn, uint reserveOut) external pure returns (uint amountIn);
    211 |     function getAmountsOut(uint amountIn, address[] calldata path) external view returns (uint[] memory amounts);
>>  212 |     function getAmountsIn(uint amountOut, address[] calldata path) external view returns (uint[] memory amounts);
    213 | }
    214 | 
    215 | interface IPancakeRouter02 is IPancakeRouter01 {
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 413 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    410 |     /**
    411 |      * @dev Returns the name of the token.
    412 |      */
>>  413 |     function name() external view returns (string memory);
    414 | 
    415 |     /**
    416 |      * @dev Returns the symbol of the token.
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 418 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    415 |     /**
    416 |      * @dev Returns the symbol of the token.
    417 |      */
>>  418 |     function symbol() external view returns (string memory);
    419 | 
    420 |     /**
    421 |      * @dev Returns the decimals places of the token.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 423 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    420 |     /**
    421 |      * @dev Returns the decimals places of the token.
    422 |      */
>>  423 |     function decimals() external view returns (uint8);
    424 | }
    425 | 
    426 | // lib/openzeppelin-contracts/contracts/access/Ownable.sol
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 478 行
- **函数**: `owner()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    475 |     /**
    476 |      * @dev Returns the address of the current owner.
    477 |      */
>>  478 |     function owner() public view virtual returns (address) {
    479 |         return _owner;
    480 |     }
    481 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 569 行
- **函数**: `name()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    566 |     /**
    567 |      * @dev Returns the name of the token.
    568 |      */
>>  569 |     function name() public view virtual returns (string memory) {
    570 |         return _name;
    571 |     }
    572 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 577 行
- **函数**: `symbol()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    574 |      * @dev Returns the symbol of the token, usually a shorter version of the
    575 |      * name.
    576 |      */
>>  577 |     function symbol() public view virtual returns (string memory) {
    578 |         return _symbol;
    579 |     }
    580 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 594 行
- **函数**: `decimals()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    591 |      * no way affects any of the arithmetic of the contract, including
    592 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    593 |      */
>>  594 |     function decimals() public view virtual returns (uint8) {
    595 |         return 18;
    596 |     }
    597 | 
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 599 行
- **函数**: `totalSupply()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    596 |     }
    597 | 
    598 |     /// @inheritdoc IERC20
>>  599 |     function totalSupply() public view virtual returns (uint256) {
    600 |         return _totalSupply;
    601 |     }
    602 | 
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 604 行
- **函数**: `balanceOf()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    601 |     }
    602 | 
    603 |     /// @inheritdoc IERC20
>>  604 |     function balanceOf(address account) public view virtual returns (uint256) {
    605 |         return _balances[account];
    606 |     }
    607 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 616 行
- **函数**: `transfer()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    613 |      * - `to` cannot be the zero address.
    614 |      * - the caller must have a balance of at least `value`.
    615 |      */
>>  616 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    617 |         address owner = _msgSender();
    618 |         _transfer(owner, to, value);
    619 |         return true;
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 623 行
- **函数**: `allowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    620 |     }
    621 | 
    622 |     /// @inheritdoc IERC20
>>  623 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    624 |         return _allowances[owner][spender];
    625 |     }
    626 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 637 行
- **函数**: `approve()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    634 |      *
    635 |      * - `spender` cannot be the zero address.
    636 |      */
>>  637 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    638 |         address owner = _msgSender();
    639 |         _approve(owner, spender, value);
    640 |         return true;
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 659 行
- **函数**: `transferFrom()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    656 |      * - the caller must have allowance for ``from``'s tokens of at least
    657 |      * `value`.
    658 |      */
>>  659 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    660 |         address spender = _msgSender();
    661 |         _spendAllowance(from, spender, value);
    662 |         _transfer(from, to, value);
```

---

### 33. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 442 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    437 |  *
    438 |  * This module is used through inheritance. It will make available the modifier
    439 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
    440 |  * the owner.
    441 |  */
>>  442 | abstract contract Ownable is Context {
    443 |     address private _owner;
    444 | 
    445 |     /**
    446 |      * @dev The caller account is not authorized to perform an operation.
    447 |      */
```

---

### 34. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 514 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    509 |         }
    510 |         _transferOwnership(newOwner);
    511 |     }
    512 | 
    513 |     /**
>>  514 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
    515 |      * Internal function without access restriction.
    516 |      */
    517 |     function _transferOwnership(address newOwner) internal virtual {
    518 |         address oldOwner = _owner;
    519 |         _owner = newOwner;
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 546 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    541 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    542 |  * instead returning `false` on failure. This behavior is nonetheless
    543 |  * conventional and does not conflict with the expectations of ERC-20
    544 |  * applications.
    545 |  */
>>  546 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    547 |     mapping(address account => uint256) private _balances;
    548 | 
    549 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    550 | 
    551 |     uint256 private _totalSupply;
```

---

### 36. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 816 行
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    811 |             }
    812 |         }
    813 |     }
    814 | }
    815 | 
>>  816 | contract Token is ERC20, Ownable {
    817 |     // ============ Constants ============
    818 |     uint256 public constant TOTAL_SUPPLY = 100_000_000 * 1e18; 
    819 |     uint256 public constant LP_POOL_AMOUNT = 50_000_000 * 1e18; 
    820 |     uint256 public constant MINING_POOL_AMOUNT = 50_000_000 * 1e18; 
    821 |     address public constant DEAD_ADDRESS =
```

---

### 37. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xC73241A545Ec9461e084606d81719FB0dC490267` 第 822 行
- **函数**: `_spendAllowance()`
- **合约**: `is`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    819 |     uint256 public constant LP_POOL_AMOUNT = 50_000_000 * 1e18; 
    820 |     uint256 public constant MINING_POOL_AMOUNT = 50_000_000 * 1e18; 
    821 |     address public constant DEAD_ADDRESS =
>>  822 |         0x000000000000000000000000000000000000dEaD;
    823 |     uint256 public constant SELL_TAX_RATE = 300; // 3% = 300/10000
    824 |     uint256 public constant TAX_DENOMINATOR = 10000;
    825 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*