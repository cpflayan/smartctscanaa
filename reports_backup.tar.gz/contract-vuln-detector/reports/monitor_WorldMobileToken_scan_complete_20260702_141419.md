# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:14:19
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` |
| contract_name | `WorldMobileToken` |
| compiler_version | `v0.8.19+commit.7dd6d404` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['@openzeppelin/contracts/access/AccessControl.sol', '@openzeppelin/contracts/access/IAccessControl.sol', '@openzeppelin/contracts/interfaces/IERC5267.sol', '@openzeppelin/contracts/token/ERC20/ERC20.sol', '@openzeppelin/contracts/token/ERC20/extensions/ERC20Capped.sol', '@openzeppelin/contracts/token/ERC20/extensions/ERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol', '@openzeppelin/contracts/token/ERC20/extensions/IERC20Permit.sol', '@openzeppelin/contracts/token/ERC20/IERC20.sol', '@openzeppelin/contracts/utils/Context.sol', '@openzeppelin/contracts/utils/Counters.sol', '@openzeppelin/contracts/utils/cryptography/ECDSA.sol', '@openzeppelin/contracts/utils/cryptography/EIP712.sol', '@openzeppelin/contracts/utils/introspection/ERC165.sol', '@openzeppelin/contracts/utils/introspection/IERC165.sol', '@openzeppelin/contracts/utils/math/Math.sol', '@openzeppelin/contracts/utils/math/SignedMath.sol', '@openzeppelin/contracts/utils/ShortStrings.sol', '@openzeppelin/contracts/utils/StorageSlot.sol', '@openzeppelin/contracts/utils/Strings.sol', 'contracts/WorldMobileToken.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646142` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 38 |
| 🟢 LOW | 20 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 80 行
- **函数**: `supportsInterface()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     77 |     /**
     78 |      * @dev See {IERC165-supportsInterface}.
     79 |      */
>>   80 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
     81 |         return interfaceId == type(IAccessControl).interfaceId || super.supportsInterface(interfaceId);
     82 |     }
     83 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 87 行
- **函数**: `hasRole()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     84 |     /**
     85 |      * @dev Returns `true` if `account` has been granted `role`.
     86 |      */
>>   87 |     function hasRole(bytes32 role, address account) public view virtual override returns (bool) {
     88 |         return _roles[role].members[account];
     89 |     }
     90 | 
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 131 行
- **函数**: `getRoleAdmin()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    128 |      *
    129 |      * To change a role's admin, use {_setRoleAdmin}.
    130 |      */
>>  131 |     function getRoleAdmin(bytes32 role) public view virtual override returns (bytes32) {
    132 |         return _roles[role].adminRole;
    133 |     }
    134 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 182 行
- **函数**: `renounceRole()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    179 |      *
    180 |      * May emit a {RoleRevoked} event.
    181 |      */
>>  182 |     function renounceRole(bytes32 role, address account) public virtual override {
    183 |         require(account == _msgSender(), "AccessControl: can only renounce roles for self");
    184 | 
    185 |         _revokeRole(role, account);
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 294 行
- **函数**: `hasRole()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    291 |     /**
    292 |      * @dev Returns `true` if `account` has been granted `role`.
    293 |      */
>>  294 |     function hasRole(bytes32 role, address account) external view returns (bool);
    295 | 
    296 |     /**
    297 |      * @dev Returns the admin role that controls `role`. See {grantRole} and
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 302 行
- **函数**: `getRoleAdmin()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    299 |      *
    300 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
    301 |      */
>>  302 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
    303 | 
    304 |     /**
    305 |      * @dev Grants `role` to `account`.
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 440 行
- **函数**: `name()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    437 |     /**
    438 |      * @dev Returns the name of the token.
    439 |      */
>>  440 |     function name() public view virtual override returns (string memory) {
    441 |         return _name;
    442 |     }
    443 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 448 行
- **函数**: `symbol()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    445 |      * @dev Returns the symbol of the token, usually a shorter version of the
    446 |      * name.
    447 |      */
>>  448 |     function symbol() public view virtual override returns (string memory) {
    449 |         return _symbol;
    450 |     }
    451 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 465 行
- **函数**: `decimals()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    462 |      * no way affects any of the arithmetic of the contract, including
    463 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    464 |      */
>>  465 |     function decimals() public view virtual override returns (uint8) {
    466 |         return 18;
    467 |     }
    468 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 472 行
- **函数**: `totalSupply()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    469 |     /**
    470 |      * @dev See {IERC20-totalSupply}.
    471 |      */
>>  472 |     function totalSupply() public view virtual override returns (uint256) {
    473 |         return _totalSupply;
    474 |     }
    475 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 479 行
- **函数**: `balanceOf()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    476 |     /**
    477 |      * @dev See {IERC20-balanceOf}.
    478 |      */
>>  479 |     function balanceOf(address account) public view virtual override returns (uint256) {
    480 |         return _balances[account];
    481 |     }
    482 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 491 行
- **函数**: `transfer()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    488 |      * - `to` cannot be the zero address.
    489 |      * - the caller must have a balance of at least `amount`.
    490 |      */
>>  491 |     function transfer(address to, uint256 amount) public virtual override returns (bool) {
    492 |         address owner = _msgSender();
    493 |         _transfer(owner, to, amount);
    494 |         return true;
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 500 行
- **函数**: `allowance()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    497 |     /**
    498 |      * @dev See {IERC20-allowance}.
    499 |      */
>>  500 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    501 |         return _allowances[owner][spender];
    502 |     }
    503 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 514 行
- **函数**: `approve()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    511 |      *
    512 |      * - `spender` cannot be the zero address.
    513 |      */
>>  514 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    515 |         address owner = _msgSender();
    516 |         _approve(owner, spender, amount);
    517 |         return true;
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 536 行
- **函数**: `transferFrom()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    533 |      * - the caller must have allowance for ``from``'s tokens of at least
    534 |      * `amount`.
    535 |      */
>>  536 |     function transferFrom(address from, address to, uint256 amount) public virtual override returns (bool) {
    537 |         address spender = _msgSender();
    538 |         _spendAllowance(from, spender, amount);
    539 |         _transfer(from, to, amount);
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 555 行
- **函数**: `increaseAllowance()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    552 |      *
    553 |      * - `spender` cannot be the zero address.
    554 |      */
>>  555 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    556 |         address owner = _msgSender();
    557 |         _approve(owner, spender, allowance(owner, spender) + addedValue);
    558 |         return true;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 575 行
- **函数**: `decreaseAllowance()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    572 |      * - `spender` must have allowance for the caller of at least
    573 |      * `subtractedValue`.
    574 |      */
>>  575 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    576 |         address owner = _msgSender();
    577 |         uint256 currentAllowance = allowance(owner, spender);
    578 |         require(currentAllowance >= subtractedValue, "ERC20: decreased allowance below zero");
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 773 行
- **函数**: `cap()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    770 |     /**
    771 |      * @dev Returns the cap on the token's total supply.
    772 |      */
>>  773 |     function cap() public view virtual returns (uint256) {
    774 |         return _cap;
    775 |     }
    776 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 861 行
- **函数**: `nonces()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    858 |     /**
    859 |      * @inheritdoc IERC20Permit
    860 |      */
>>  861 |     function nonces(address owner) public view virtual override returns (uint256) {
    862 |         return _nonces[owner].current();
    863 |     }
    864 | 
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 869 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    866 |      * @inheritdoc IERC20Permit
    867 |      */
    868 |     // solhint-disable-next-line func-name-mixedcase
>>  869 |     function DOMAIN_SEPARATOR() external view override returns (bytes32) {
    870 |         return _domainSeparatorV4();
    871 |     }
    872 | 
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 904 行
- **函数**: `name()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    901 |     /**
    902 |      * @dev Returns the name of the token.
    903 |      */
>>  904 |     function name() external view returns (string memory);
    905 | 
    906 |     /**
    907 |      * @dev Returns the symbol of the token.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 909 行
- **函数**: `symbol()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    906 |     /**
    907 |      * @dev Returns the symbol of the token.
    908 |      */
>>  909 |     function symbol() external view returns (string memory);
    910 | 
    911 |     /**
    912 |      * @dev Returns the decimals places of the token.
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 914 行
- **函数**: `decimals()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    911 |     /**
    912 |      * @dev Returns the decimals places of the token.
    913 |      */
>>  914 |     function decimals() external view returns (uint8);
    915 | }
    916 | 
    917 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1002 行
- **函数**: `nonces()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    999 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   1000 |      * prevents a signature from being used multiple times.
   1001 |      */
>> 1002 |     function nonces(address owner) external view returns (uint256);
   1003 | 
   1004 |     /**
   1005 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1008 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1005 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
   1006 |      */
   1007 |     // solhint-disable-next-line func-name-mixedcase
>> 1008 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1009 | }
   1010 | 
   1011 | 
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1040 行
- **函数**: `totalSupply()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1037 |     /**
   1038 |      * @dev Returns the amount of tokens in existence.
   1039 |      */
>> 1040 |     function totalSupply() external view returns (uint256);
   1041 | 
   1042 |     /**
   1043 |      * @dev Returns the amount of tokens owned by `account`.
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1045 行
- **函数**: `balanceOf()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1042 |     /**
   1043 |      * @dev Returns the amount of tokens owned by `account`.
   1044 |      */
>> 1045 |     function balanceOf(address account) external view returns (uint256);
   1046 | 
   1047 |     /**
   1048 |      * @dev Moves `amount` tokens from the caller's account to `to`.
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1054 行
- **函数**: `transfer()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1051 |      *
   1052 |      * Emits a {Transfer} event.
   1053 |      */
>> 1054 |     function transfer(address to, uint256 amount) external returns (bool);
   1055 | 
   1056 |     /**
   1057 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1063 行
- **函数**: `allowance()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1060 |      *
   1061 |      * This value changes when {approve} or {transferFrom} are called.
   1062 |      */
>> 1063 |     function allowance(address owner, address spender) external view returns (uint256);
   1064 | 
   1065 |     /**
   1066 |      * @dev Sets `amount` as the allowance of `spender` over the caller's tokens.
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1079 行
- **函数**: `approve()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1076 |      *
   1077 |      * Emits an {Approval} event.
   1078 |      */
>> 1079 |     function approve(address spender, uint256 amount) external returns (bool);
   1080 | 
   1081 |     /**
   1082 |      * @dev Moves `amount` tokens from `from` to `to` using the
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1090 行
- **函数**: `transferFrom()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1087 |      *
   1088 |      * Emits a {Transfer} event.
   1089 |      */
>> 1090 |     function transferFrom(address from, address to, uint256 amount) external returns (bool);
   1091 | }
   1092 | 
   1093 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1567 行
- **函数**: `supportsInterface()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1564 |     /**
   1565 |      * @dev See {IERC165-supportsInterface}.
   1566 |      */
>> 1567 |     function supportsInterface(bytes4 interfaceId) public view virtual override returns (bool) {
   1568 |         return interfaceId == type(IERC165).interfaceId;
   1569 |     }
   1570 | }
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1598 行
- **函数**: `supportsInterface()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1595 |      *
   1596 |      * This function call must use less than 30 000 gas.
   1597 |      */
>> 1598 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
   1599 | }
   1600 | 
   1601 | 
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2378 行
- **函数**: `decimals()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   2375 | 
   2376 |     /// @notice Returns the number of decimals used to get its user representation.
   2377 |     /// @return The number of decimals used to get its user representation.
>> 2378 |     function decimals() public view virtual override returns (uint8) {
   2379 |         return 6;
   2380 |     }
   2381 | 
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 416 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    411 |  *
    412 |  * Finally, the non-standard {decreaseAllowance} and {increaseAllowance}
    413 |  * functions have been added to mitigate the well-known issues around setting
    414 |  * allowances. See {IERC20-approve}.
    415 |  */
>>  416 | contract ERC20 is Context, IERC20, IERC20Metadata {
    417 |     mapping(address => uint256) private _balances;
    418 | 
    419 |     mapping(address => mapping(address => uint256)) private _allowances;
    420 | 
    421 |     uint256 private _totalSupply;
```

---

### 36. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 810 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    805 |  * presenting a message signed by the account. By not relying on `{IERC20-approve}`, the token holder account doesn't
    806 |  * need to send a transaction, and thus is not required to hold Ether at all.
    807 |  *
    808 |  * _Available since v3.4._
    809 |  */
>>  810 | abstract contract ERC20Permit is ERC20, IERC20Permit, EIP712 {
    811 |     using Counters for Counters.Counter;
    812 | 
    813 |     mapping(address => Counters.Counter) private _nonces;
    814 | 
    815 |     // solhint-disable-next-line var-name-mixedcase
```

---

### 37. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1419 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1414 |  * ({_hashTypedDataV4}).
   1415 |  *
   1416 |  * The implementation of the domain separator was designed to be as efficient as possible while still properly updating
   1417 |  * the chain id to protect against replay attacks on an eventual fork of the chain.
   1418 |  *
>> 1419 |  * NOTE: This contract implements the version of the encoding known as "v4", as implemented by the JSON RPC method
   1420 |  * https://docs.metamask.io/guide/signing-data.html[`eth_signTypedDataV4` in MetaMask].
   1421 |  *
   1422 |  * NOTE: In the upgradeable version of this contract, the cached values will correspond to the address, and the domain
   1423 |  * separator of the implementation contract. This will cause the `_domainSeparatorV4` function to always rebuild the
   1424 |  * separator from the immutable values, which is cheaper than accessing a cached version in cold storage.
```

---

### 38. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2017 行
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   2012 |  * fallback mechanism can be used for every other case.
   2013 |  *
   2014 |  * Usage example:
   2015 |  *
   2016 |  * ```solidity
>> 2017 |  * contract Named {
   2018 |  *     using ShortStrings for *;
   2019 |  *
   2020 |  *     ShortString private immutable _name;
   2021 |  *     string private _nameFallback;
   2022 |  *
```

---

### 39. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 846 行
- **函数**: `permit()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    843 |         bytes32 r,
    844 |         bytes32 s
    845 |     ) public virtual override {
>>  846 |         require(block.timestamp <= deadline, "ERC20Permit: expired deadline");
    847 | 
    848 |         bytes32 structHash = keccak256(abi.encode(_PERMIT_TYPEHASH, owner, spender, value, _useNonce(owner), deadline));
    849 | 
```

---

### 40. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1276 行
- **函数**: `tryRecover()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1273 |      * _Available since v4.3._
   1274 |      */
   1275 |     function tryRecover(bytes32 hash, bytes32 r, bytes32 vs) internal pure returns (address, RecoverError) {
>> 1276 |         bytes32 s = vs & bytes32(0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
   1277 |         uint8 v = uint8((uint256(vs) >> 255) + 27);
   1278 |         return tryRecover(hash, v, r, s);
   1279 |     }
```

---

### 41. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1308 行
- **函数**: `tryRecover()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1305 |         // with 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141 - s1 and flip v from 27 to 28 or
   1306 |         // vice versa. If your library also generates signatures with 0/1 for v instead 27/28, add 27 to v to accept
   1307 |         // these malleable signatures as well.
>> 1308 |         if (uint256(s) > 0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0) {
   1309 |             return (address(0), RecoverError.InvalidSignatureS);
   1310 |         }
   1311 | 
```

---

### 42. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1237 行
- **函数**: `tryRecover()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1234 |             // ecrecover takes the signature parameters, and the only way to get them
   1235 |             // currently is to use assembly.
   1236 |             /// @solidity memory-safe-assembly
>> 1237 |             assembly {
   1238 |                 r := mload(add(signature, 0x20))
   1239 |                 s := mload(add(signature, 0x40))
   1240 |                 v := byte(0, mload(add(signature, 0x60)))
```

---

### 43. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1343 行
- **函数**: `toEthSignedMessageHash()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1340 |         // 32 is the length in bytes of hash,
   1341 |         // enforced by the type signature above
   1342 |         /// @solidity memory-safe-assembly
>> 1343 |         assembly {
   1344 |             mstore(0x00, "\x19Ethereum Signed Message:\n32")
   1345 |             mstore(0x1c, hash)
   1346 |             message := keccak256(0x00, 0x3c)
```

---

### 44. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1373 行
- **函数**: `toTypedDataHash()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1370 |      */
   1371 |     function toTypedDataHash(bytes32 domainSeparator, bytes32 structHash) internal pure returns (bytes32 data) {
   1372 |         /// @solidity memory-safe-assembly
>> 1373 |         assembly {
   1374 |             let ptr := mload(0x40)
   1375 |             mstore(ptr, "\x19\x01")
   1376 |             mstore(add(ptr, 0x02), domainSeparator)
```

---

### 45. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1665 行
- **函数**: `mulDiv()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1662 |             // variables such that product = prod1 * 2^256 + prod0.
   1663 |             uint256 prod0; // Least significant 256 bits of the product
   1664 |             uint256 prod1; // Most significant 256 bits of the product
>> 1665 |             assembly {
   1666 |                 let mm := mulmod(x, y, not(0))
   1667 |                 prod0 := mul(x, y)
   1668 |                 prod1 := sub(sub(mm, prod0), lt(mm, prod0))
```

---

### 46. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1688 行
- **函数**: `mulDiv()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1685 | 
   1686 |             // Make division exact by subtracting the remainder from [prod1 prod0].
   1687 |             uint256 remainder;
>> 1688 |             assembly {
   1689 |                 // Compute remainder using mulmod.
   1690 |                 remainder := mulmod(x, y, denominator)
   1691 | 
```

---

### 47. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 1702 行
- **函数**: `mulDiv()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1699 | 
   1700 |             // Does not overflow because the denominator cannot be zero at this stage in the function.
   1701 |             uint256 twos = denominator & (~denominator + 1);
>> 1702 |             assembly {
   1703 |                 // Divide denominator by twos.
   1704 |                 denominator := div(denominator, twos)
   1705 | 
```

---

### 48. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2061 行
- **函数**: `toString()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2058 |         // using `new string(len)` would work locally but is not memory safe.
   2059 |         string memory str = new string(32);
   2060 |         /// @solidity memory-safe-assembly
>> 2061 |         assembly {
   2062 |             mstore(str, len)
   2063 |             mstore(add(str, 0x20), sstr)
   2064 |         }
```

---

### 49. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2183 行
- **函数**: `getAddressSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2180 |      */
   2181 |     function getAddressSlot(bytes32 slot) internal pure returns (AddressSlot storage r) {
   2182 |         /// @solidity memory-safe-assembly
>> 2183 |         assembly {
   2184 |             r.slot := slot
   2185 |         }
   2186 |     }
```

---

### 50. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2193 行
- **函数**: `getBooleanSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2190 |      */
   2191 |     function getBooleanSlot(bytes32 slot) internal pure returns (BooleanSlot storage r) {
   2192 |         /// @solidity memory-safe-assembly
>> 2193 |         assembly {
   2194 |             r.slot := slot
   2195 |         }
   2196 |     }
```

---

### 51. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2203 行
- **函数**: `getBytes32Slot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2200 |      */
   2201 |     function getBytes32Slot(bytes32 slot) internal pure returns (Bytes32Slot storage r) {
   2202 |         /// @solidity memory-safe-assembly
>> 2203 |         assembly {
   2204 |             r.slot := slot
   2205 |         }
   2206 |     }
```

---

### 52. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2213 行
- **函数**: `getUint256Slot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2210 |      */
   2211 |     function getUint256Slot(bytes32 slot) internal pure returns (Uint256Slot storage r) {
   2212 |         /// @solidity memory-safe-assembly
>> 2213 |         assembly {
   2214 |             r.slot := slot
   2215 |         }
   2216 |     }
```

---

### 53. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2223 行
- **函数**: `getStringSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2220 |      */
   2221 |     function getStringSlot(bytes32 slot) internal pure returns (StringSlot storage r) {
   2222 |         /// @solidity memory-safe-assembly
>> 2223 |         assembly {
   2224 |             r.slot := slot
   2225 |         }
   2226 |     }
```

---

### 54. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2233 行
- **函数**: `getStringSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2230 |      */
   2231 |     function getStringSlot(string storage store) internal pure returns (StringSlot storage r) {
   2232 |         /// @solidity memory-safe-assembly
>> 2233 |         assembly {
   2234 |             r.slot := store.slot
   2235 |         }
   2236 |     }
```

---

### 55. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2243 行
- **函数**: `getBytesSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2240 |      */
   2241 |     function getBytesSlot(bytes32 slot) internal pure returns (BytesSlot storage r) {
   2242 |         /// @solidity memory-safe-assembly
>> 2243 |         assembly {
   2244 |             r.slot := slot
   2245 |         }
   2246 |     }
```

---

### 56. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2253 行
- **函数**: `getBytesSlot()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2250 |      */
   2251 |     function getBytesSlot(bytes storage store) internal pure returns (BytesSlot storage r) {
   2252 |         /// @solidity memory-safe-assembly
>> 2253 |         assembly {
   2254 |             r.slot := store.slot
   2255 |         }
   2256 |     }
```

---

### 57. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2286 行
- **函数**: `toString()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2283 |             string memory buffer = new string(length);
   2284 |             uint256 ptr;
   2285 |             /// @solidity memory-safe-assembly
>> 2286 |             assembly {
   2287 |                 ptr := add(buffer, add(32, length))
   2288 |             }
   2289 |             while (true) {
```

---

### 58. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xDBB5Cf12408a3Ac17d668037Ce289f9eA75439D7` 第 2292 行
- **函数**: `toString()`
- **合约**: `event`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   2289 |             while (true) {
   2290 |                 ptr--;
   2291 |                 /// @solidity memory-safe-assembly
>> 2292 |                 assembly {
   2293 |                     mstore8(ptr, byte(mod(value, 10), _SYMBOLS))
   2294 |                 }
   2295 |                 value /= 10;
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*