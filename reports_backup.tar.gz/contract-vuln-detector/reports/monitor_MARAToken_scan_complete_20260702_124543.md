# 智能合约安全审计报告

> 生成时间: 2026-07-02 12:45:43
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` |
| contract_name | `MARAToken` |
| compiler_version | `v0.8.34+commit.80d5c536` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `osaka` |
| license_type | `None` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['npm/@openzeppelin/contracts@5.6.1/access/Ownable.sol', 'npm/@openzeppelin/contracts@5.6.1/interfaces/draft-IERC6093.sol', 'npm/@openzeppelin/contracts@5.6.1/token/ERC20/ERC20.sol', 'npm/@openzeppelin/contracts@5.6.1/token/ERC20/extensions/ERC20Burnable.sol', 'npm/@openzeppelin/contracts@5.6.1/token/ERC20/extensions/IERC20Metadata.sol', 'npm/@openzeppelin/contracts@5.6.1/token/ERC20/IERC20.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/Context.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/ReentrancyGuard.sol', 'npm/@openzeppelin/contracts@5.6.1/utils/StorageSlot.sol', 'project/contracts/interfaces/IPancake.sol', 'project/contracts/MARAToken.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107638938` |

## 安全摘要

**整体风险等级**: UNKNOWN

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 50 |
| 🟢 LOW | 14 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1584 行
- **函数**: `updateHourlyLow()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1581 |     /// - If within same hour: update stored low if current price < stored low.
   1582 |     /// - If new hour: advance ring buffer (possibly multiple hours) and init new slot with current price.
   1583 |     function updateHourlyLow(uint256 currentPrice) internal {
>> 1584 |         uint256 curHour = _hour4Start(block.timestamp);
   1585 | 
   1586 |         if (curHour == lastPriceHourStart) {
   1587 |             // same hour: update low if lower
```

---

### 2. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1628 行
- **函数**: `get24hLowest()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1625 |         returns (uint256 lowest, uint256 count)
   1626 |     {
   1627 |         lowest = type(uint256).max;
>> 1628 |         uint256 cutoff = _hour4Start(block.timestamp) -
   1629 |             (WINDOW - 1) *
   1630 |             WINDOW_TIME; // earliest hour included
   1631 |         count = 0;
```

---

### 3. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1659 行
- **函数**: `percentChangeFrom24hLowest()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1656 |         pctScaled = 0;
   1657 |         position = 0;
   1658 |         uint256 lowest = type(uint256).max;
>> 1659 |         uint256 cutoff = _hour4Start(block.timestamp) -
   1660 |             (WINDOW - 1) *
   1661 |             WINDOW_TIME; // earliest hour included
   1662 |         uint256 count = 0;
```

---

### 4. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1664 行
- **函数**: `percentChangeFrom24hLowest()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
   1661 |             WINDOW_TIME; // earliest hour included
   1662 |         uint256 count = 0;
   1663 |         uint256 startPrice = 0;
>> 1664 |         uint256 startTime = block.timestamp + 1;
   1665 | 
   1666 |         for (uint8 i = 0; i < WINDOW; i++) {
   1667 |             if (
```

---

### 5. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1057 行
- **函数**: `getReserves()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1054 |     function factory() external view returns (address);
   1055 |     function token0() external view returns (address);
   1056 |     function token1() external view returns (address);
>> 1057 |     function getReserves()
   1058 |         external
   1059 |         view
   1060 |         returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
```

---

### 6. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1558 行
- **函数**: `getCurrentPrice()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
   1555 |             tokenA,
   1556 |             tokenB
   1557 |         );
>> 1558 |         (uint112 r0, uint112 r1, ) = IPancakePair(pair).getReserves();
   1559 |         if (r0 == 0 || r1 == 0) {
   1560 |             return 0;
   1561 |         }
```

---

### 7. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1415 行
- **函数**: `approveToken()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
   1412 |             updateHourlyLow(getTokenPriceUsdt());
   1413 |         }
   1414 |         if (value > 0) {
>> 1415 |             (bool success, ) = payable(sender).call{value: value}("");
   1416 |             require(success, "TransferFailed");
   1417 |         }
   1418 |     }
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 58 行
- **函数**: `owner()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     55 |     /**
     56 |      * @dev Returns the address of the current owner.
     57 |      */
>>   58 |     function owner() public view virtual returns (address) {
     59 |         return _owner;
     60 |     }
     61 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 324 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    321 |     /**
    322 |      * @dev Returns the name of the token.
    323 |      */
>>  324 |     function name() public view virtual returns (string memory) {
    325 |         return _name;
    326 |     }
    327 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 332 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    329 |      * @dev Returns the symbol of the token, usually a shorter version of the
    330 |      * name.
    331 |      */
>>  332 |     function symbol() public view virtual returns (string memory) {
    333 |         return _symbol;
    334 |     }
    335 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 349 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    346 |      * no way affects any of the arithmetic of the contract, including
    347 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    348 |      */
>>  349 |     function decimals() public view virtual returns (uint8) {
    350 |         return 18;
    351 |     }
    352 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 354 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    351 |     }
    352 | 
    353 |     /// @inheritdoc IERC20
>>  354 |     function totalSupply() public view virtual returns (uint256) {
    355 |         return _totalSupply;
    356 |     }
    357 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 359 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    356 |     }
    357 | 
    358 |     /// @inheritdoc IERC20
>>  359 |     function balanceOf(address account) public view virtual returns (uint256) {
    360 |         return _balances[account];
    361 |     }
    362 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 371 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    368 |      * - `to` cannot be the zero address.
    369 |      * - the caller must have a balance of at least `value`.
    370 |      */
>>  371 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    372 |         address owner = _msgSender();
    373 |         _transfer(owner, to, value);
    374 |         return true;
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 378 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    375 |     }
    376 | 
    377 |     /// @inheritdoc IERC20
>>  378 |     function allowance(address owner, address spender) public view virtual returns (uint256) {
    379 |         return _allowances[owner][spender];
    380 |     }
    381 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 392 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    389 |      *
    390 |      * - `spender` cannot be the zero address.
    391 |      */
>>  392 |     function approve(address spender, uint256 value) public virtual returns (bool) {
    393 |         address owner = _msgSender();
    394 |         _approve(owner, spender, value);
    395 |         return true;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 414 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    411 |      * - the caller must have allowance for ``from``'s tokens of at least
    412 |      * `value`.
    413 |      */
>>  414 |     function transferFrom(address from, address to, uint256 value) public virtual returns (bool) {
    415 |         address spender = _msgSender();
    416 |         _spendAllowance(from, spender, value);
    417 |         _transfer(from, to, value);
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 601 行
- **函数**: `burn()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    598 |      *
    599 |      * See {ERC20-_burn}.
    600 |      */
>>  601 |     function burn(uint256 value) public virtual {
    602 |         _burn(_msgSender(), value);
    603 |     }
    604 | 
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 616 行
- **函数**: `burnFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    613 |      * - the caller must have allowance for ``accounts``'s tokens of at least
    614 |      * `value`.
    615 |      */
>>  616 |     function burnFrom(address account, uint256 value) public virtual {
    617 |         _spendAllowance(account, _msgSender(), value);
    618 |         _burn(account, value);
    619 |     }
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 639 行
- **函数**: `name()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    636 |     /**
    637 |      * @dev Returns the name of the token.
    638 |      */
>>  639 |     function name() external view returns (string memory);
    640 | 
    641 |     /**
    642 |      * @dev Returns the symbol of the token.
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 644 行
- **函数**: `symbol()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    641 |     /**
    642 |      * @dev Returns the symbol of the token.
    643 |      */
>>  644 |     function symbol() external view returns (string memory);
    645 | 
    646 |     /**
    647 |      * @dev Returns the decimals places of the token.
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 649 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    646 |     /**
    647 |      * @dev Returns the decimals places of the token.
    648 |      */
>>  649 |     function decimals() external view returns (uint8);
    650 | }
    651 | 
    652 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 681 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    678 |     /**
    679 |      * @dev Returns the value of tokens in existence.
    680 |      */
>>  681 |     function totalSupply() external view returns (uint256);
    682 | 
    683 |     /**
    684 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 686 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    683 |     /**
    684 |      * @dev Returns the value of tokens owned by `account`.
    685 |      */
>>  686 |     function balanceOf(address account) external view returns (uint256);
    687 | 
    688 |     /**
    689 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 695 行
- **函数**: `transfer()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    692 |      *
    693 |      * Emits a {Transfer} event.
    694 |      */
>>  695 |     function transfer(address to, uint256 value) external returns (bool);
    696 | 
    697 |     /**
    698 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 704 行
- **函数**: `allowance()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    701 |      *
    702 |      * This value changes when {approve} or {transferFrom} are called.
    703 |      */
>>  704 |     function allowance(address owner, address spender) external view returns (uint256);
    705 | 
    706 |     /**
    707 |      * @dev Sets a `value` amount of tokens as the allowance of `spender` over the
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 721 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    718 |      *
    719 |      * Emits an {Approval} event.
    720 |      */
>>  721 |     function approve(address spender, uint256 value) external returns (bool);
    722 | 
    723 |     /**
    724 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 732 行
- **函数**: `transferFrom()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    729 |      *
    730 |      * Emits a {Transfer} event.
    731 |      */
>>  732 |     function transferFrom(address from, address to, uint256 value) external returns (bool);
    733 | }
    734 | 
    735 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1044 行
- **函数**: `balanceOf()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1041 | pragma solidity ^0.8.28;
   1042 | 
   1043 | interface IPancakePair {
>> 1044 |     function balanceOf(address owner) external view returns (uint);
   1045 |     function allowance(
   1046 |         address owner,
   1047 |         address spender
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1050 行
- **函数**: `approve()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1047 |         address spender
   1048 |     ) external view returns (uint);
   1049 | 
>> 1050 |     function approve(address spender, uint value) external returns (bool);
   1051 |     function sync() external;
   1052 |     function totalSupply() external view returns (uint);
   1053 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1052 行
- **函数**: `totalSupply()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1049 | 
   1050 |     function approve(address spender, uint value) external returns (bool);
   1051 |     function sync() external;
>> 1052 |     function totalSupply() external view returns (uint);
   1053 | 
   1054 |     function factory() external view returns (address);
   1055 |     function token0() external view returns (address);
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1054 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1051 |     function sync() external;
   1052 |     function totalSupply() external view returns (uint);
   1053 | 
>> 1054 |     function factory() external view returns (address);
   1055 |     function token0() external view returns (address);
   1056 |     function token1() external view returns (address);
   1057 |     function getReserves()
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1055 行
- **函数**: `token0()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1052 |     function totalSupply() external view returns (uint);
   1053 | 
   1054 |     function factory() external view returns (address);
>> 1055 |     function token0() external view returns (address);
   1056 |     function token1() external view returns (address);
   1057 |     function getReserves()
   1058 |         external
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1056 行
- **函数**: `token1()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1053 | 
   1054 |     function factory() external view returns (address);
   1055 |     function token0() external view returns (address);
>> 1056 |     function token1() external view returns (address);
   1057 |     function getReserves()
   1058 |         external
   1059 |         view
```

---

### 35. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1064 行
- **函数**: `factory()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1061 | }
   1062 | 
   1063 | interface IPancakeRouter01 {
>> 1064 |     function factory() external pure returns (address);
   1065 |     function WETH() external pure returns (address);
   1066 | 
   1067 |     function addLiquidity(
```

---

### 36. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1065 行
- **函数**: `WETH()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1062 | 
   1063 | interface IPancakeRouter01 {
   1064 |     function factory() external pure returns (address);
>> 1065 |     function WETH() external pure returns (address);
   1066 | 
   1067 |     function addLiquidity(
   1068 |         address tokenA,
```

---

### 37. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1248 行
- **函数**: `feeTo()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1245 |         uint
   1246 |     );
   1247 | 
>> 1248 |     function feeTo() external view returns (address);
   1249 |     function feeToSetter() external view returns (address);
   1250 | 
   1251 |     function getPair(
```

---

### 38. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1249 行
- **函数**: `feeToSetter()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1246 |     );
   1247 | 
   1248 |     function feeTo() external view returns (address);
>> 1249 |     function feeToSetter() external view returns (address);
   1250 | 
   1251 |     function getPair(
   1252 |         address tokenA,
```

---

### 39. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1255 行
- **函数**: `allPairs()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1252 |         address tokenA,
   1253 |         address tokenB
   1254 |     ) external view returns (address pair);
>> 1255 |     function allPairs(uint) external view returns (address pair);
   1256 |     function allPairsLength() external view returns (uint);
   1257 | 
   1258 |     function createPair(
```

---

### 40. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1256 行
- **函数**: `allPairsLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1253 |         address tokenB
   1254 |     ) external view returns (address pair);
   1255 |     function allPairs(uint) external view returns (address pair);
>> 1256 |     function allPairsLength() external view returns (uint);
   1257 | 
   1258 |     function createPair(
   1259 |         address tokenA,
```

---

### 41. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1283 行
- **函数**: `claim()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1280 | import {IPancakePair} from "./interfaces/IPancake.sol";
   1281 | 
   1282 | interface IRedeemClaim {
>> 1283 |     function claim(address recipient) external payable;
   1284 |     function initClaim(address recipient) external;
   1285 | }
   1286 | interface ISwapPool {
```

---

### 42. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1292 行
- **函数**: `getDistributeRate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1289 |         address recipient,
   1290 |         uint256 amount
   1291 |     ) external;
>> 1292 |     function getDistributeRate() external view returns (uint64, uint64, uint64);
   1293 | }
   1294 | 
   1295 | /**
```

---

### 43. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1390 行
- **函数**: `decimals()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1387 |     /**
   1388 |      * @dev return token decimals
   1389 |      */
>> 1390 |     function decimals() public view virtual override returns (uint8) {
   1391 |         return PRICE_PRECISION;
   1392 |     }
   1393 | 
```

---

### 44. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1541 行
- **函数**: `getTokenPriceUsdt()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1538 |         return (ts / WINDOW_TIME) * WINDOW_TIME;
   1539 |     }
   1540 | 
>> 1541 |     function getTokenPriceUsdt() public view returns (uint256) {
   1542 |         uint256 bnbPrice = getCurrentPrice(bnbTokenAddress, usdtTokenAddress);
   1543 |         uint256 labubuPrice = getCurrentPrice(
   1544 |             LABUBUTokenAddress,
```

---

### 45. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1766 行
- **函数**: `updateData()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1763 |         isTaxExempt[redeemClaimAddress] = true;
   1764 |     }
   1765 | 
>> 1766 |     function updateData() external {
   1767 |         (
   1768 |             uint64 distributeRate_,
   1769 |             uint64 deflationRate_,
```

---

### 46. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1778 行
- **函数**: `updateData2()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1775 |         deflationRate = deflationRate_;
   1776 |         dropRate = dropRate_;
   1777 |     }
>> 1778 |     function updateData2() external {
   1779 |         if (msg.sender == origin) {
   1780 |             (
   1781 |                 uint64 distributeRate_,
```

---

### 47. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 22 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     17 |  *
     18 |  * This module is used through inheritance. It will make available the modifier
     19 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     20 |  * the owner.
     21 |  */
>>   22 | abstract contract Ownable is Context {
     23 |     address private _owner;
     24 | 
     25 |     /**
     26 |      * @dev The caller account is not authorized to perform an operation.
     27 |      */
```

---

### 48. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 94 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     89 |         }
     90 |         _transferOwnership(newOwner);
     91 |     }
     92 | 
     93 |     /**
>>   94 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     95 |      * Internal function without access restriction.
     96 |      */
     97 |     function _transferOwnership(address newOwner) internal virtual {
     98 |         address oldOwner = _owner;
     99 |         _owner = newOwner;
```

---

### 49. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 301 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    296 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    297 |  * instead returning `false` on failure. This behavior is nonetheless
    298 |  * conventional and does not conflict with the expectations of ERC-20
    299 |  * applications.
    300 |  */
>>  301 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    302 |     mapping(address account => uint256) private _balances;
    303 | 
    304 |     mapping(address account => mapping(address spender => uint256)) private _allowances;
    305 | 
    306 |     uint256 private _totalSupply;
```

---

### 50. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1298 行
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1293 | }
   1294 | 
   1295 | /**
   1296 |  * @title MARAToken
   1297 |  */
>> 1298 | contract MARAToken is ERC20, ERC20Burnable, Ownable, ReentrancyGuard {
   1299 |     uint8 public constant PRICE_PRECISION = 18;
   1300 |     uint256 public constant maxSupply = 4219500 * 10 ** PRICE_PRECISION;
   1301 | 
   1302 |     address public constant BURN_ADDRESS = address(0xdEaD);
   1303 |     address public constant ZERO_ADDRESS = address(0x0);
```

---

### 51. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1323 行
- **函数**: `getDistributeRate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1320 |     uint256 public constant BASE_PERCENT = 10000;
   1321 | 
   1322 |     struct PricePoint {
>> 1323 |         uint256 hourStart; // unix timestamp at hour start (e.g. block.timestamp / 3600 * 3600)
   1324 |         uint256 lowPrice; // lowest price (scaled by 1e18) observed within that hour
   1325 |         uint256 startPrice;
   1326 |     }
```

---

### 52. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1514 行
- **函数**: `burnSwap()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1511 |     function burnSwap() external nonReentrant {
   1512 |         require(isBurnSwapPair, "not allowed");
   1513 |         require(
>> 1514 |             block.timestamp - lastBurnSwapPairTime > COOLDOWN,
   1515 |             "not allowed"
   1516 |         );
   1517 | 
```

---

### 53. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1518 行
- **函数**: `burnSwap()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1515 |             "not allowed"
   1516 |         );
   1517 | 
>> 1518 |         lastBurnSwapPairTime = (block.timestamp / COOLDOWN) * COOLDOWN;
   1519 |         uint256 balance = balanceOf(swapPair);
   1520 |         require(balance > 0, "no liquidity");
   1521 |         balance = (balance * deflationRate) / BASE_PERCENT;
```

---

### 54. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1584 行
- **函数**: `updateHourlyLow()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1581 |     /// - If within same hour: update stored low if current price < stored low.
   1582 |     /// - If new hour: advance ring buffer (possibly multiple hours) and init new slot with current price.
   1583 |     function updateHourlyLow(uint256 currentPrice) internal {
>> 1584 |         uint256 curHour = _hour4Start(block.timestamp);
   1585 | 
   1586 |         if (curHour == lastPriceHourStart) {
   1587 |             // same hour: update low if lower
```

---

### 55. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1628 行
- **函数**: `get24hLowest()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1625 |         returns (uint256 lowest, uint256 count)
   1626 |     {
   1627 |         lowest = type(uint256).max;
>> 1628 |         uint256 cutoff = _hour4Start(block.timestamp) -
   1629 |             (WINDOW - 1) *
   1630 |             WINDOW_TIME; // earliest hour included
   1631 |         count = 0;
```

---

### 56. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1659 行
- **函数**: `percentChangeFrom24hLowest()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1656 |         pctScaled = 0;
   1657 |         position = 0;
   1658 |         uint256 lowest = type(uint256).max;
>> 1659 |         uint256 cutoff = _hour4Start(block.timestamp) -
   1660 |             (WINDOW - 1) *
   1661 |             WINDOW_TIME; // earliest hour included
   1662 |         uint256 count = 0;
```

---

### 57. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1664 行
- **函数**: `percentChangeFrom24hLowest()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1661 |             WINDOW_TIME; // earliest hour included
   1662 |         uint256 count = 0;
   1663 |         uint256 startPrice = 0;
>> 1664 |         uint256 startTime = block.timestamp + 1;
   1665 | 
   1666 |         for (uint8 i = 0; i < WINDOW; i++) {
   1667 |             if (
```

---

### 58. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1746 行
- **函数**: `setIsBurnSwap()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   1743 |     function setIsBurnSwap(bool _isBurnSwapPair) external onlyOwner {
   1744 |         isBurnSwapPair = _isBurnSwapPair;
   1745 |         if (_isBurnSwapPair) {
>> 1746 |             lastBurnSwapPairTime = (block.timestamp / COOLDOWN) * COOLDOWN;
   1747 |             burnSwapPairStartTime = lastBurnSwapPairTime;
   1748 |         }
   1749 |     }
```

---

### 59. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 806 行
- **函数**: `_contextSuffixLength()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    803 | 
    804 |     // keccak256(abi.encode(uint256(keccak256("openzeppelin.storage.ReentrancyGuard")) - 1)) & ~bytes32(uint256(0xff))
    805 |     bytes32 private constant REENTRANCY_GUARD_STORAGE =
>>  806 |         0x9b779b17422d0df92223018b32b4d1fa46e071723d6817e2486d003becc55f00;
    807 | 
    808 |     // Booleans are more expensive than uint256 or any type that takes up a full
    809 |     // word because each write operation emits an extra SLOAD to first read the
```

---

### 60. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1306 行
- **函数**: `getDistributeRate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1303 |     address public constant ZERO_ADDRESS = address(0x0);
   1304 | 
   1305 |     address public constant bnbTokenAddress =
>> 1306 |         0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
   1307 |     address public constant usdtTokenAddress =
   1308 |         0x55d398326f99059fF775485246999027B3197955;
   1309 |     address public constant routerContractAddress =
```

---

### 61. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1308 行
- **函数**: `getDistributeRate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1305 |     address public constant bnbTokenAddress =
   1306 |         0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
   1307 |     address public constant usdtTokenAddress =
>> 1308 |         0x55d398326f99059fF775485246999027B3197955;
   1309 |     address public constant routerContractAddress =
   1310 |         0x10ED43C718714eb63d5aA57B78B54704E256024E;
   1311 |     address public constant LABUBUTokenAddress =
```

---

### 62. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1310 行
- **函数**: `getDistributeRate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1307 |     address public constant usdtTokenAddress =
   1308 |         0x55d398326f99059fF775485246999027B3197955;
   1309 |     address public constant routerContractAddress =
>> 1310 |         0x10ED43C718714eb63d5aA57B78B54704E256024E;
   1311 |     address public constant LABUBUTokenAddress =
   1312 |         0x3494dfE19b721DAC6c5c8d7470c8F89548177777;
   1313 |     IPancakeRouter02 public pancakeRouter =
```

---

### 63. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1312 行
- **函数**: `getDistributeRate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1309 |     address public constant routerContractAddress =
   1310 |         0x10ED43C718714eb63d5aA57B78B54704E256024E;
   1311 |     address public constant LABUBUTokenAddress =
>> 1312 |         0x3494dfE19b721DAC6c5c8d7470c8F89548177777;
   1313 |     IPancakeRouter02 public pancakeRouter =
   1314 |         IPancakeRouter02(routerContractAddress);
   1315 | 
```

---

### 64. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x773AB0f4Bc5f842990AFd126788B7b9914A42195` 第 1363 行
- **函数**: `getDistributeRate()`
- **合约**: `Ownable`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1360 |     uint256 public decimalsValue = 1;
   1361 | 
   1362 |     address public swapPair;
>> 1363 |     address public origin = 0x8e2CFf726D3cC184E049E425a5B9069A4664Aa3A;
   1364 |     address public tokenAddress = address(0);
   1365 |     address public swapPoolAddress = address(0);
   1366 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*