# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:51:37
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` |
| contract_name | `AuthorizedForwarder` |
| compiler_version | `v0.8.19+commit.7dd6d404` |
| optimization_used | `True` |
| runs | `1000000` |
| evm_version | `paris` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['node_modules/@openzeppelin/contracts/utils/Address.sol', 'src/v0.8/operatorforwarder/AuthorizedForwarder.sol', 'src/v0.8/operatorforwarder/AuthorizedReceiver.sol', 'src/v0.8/operatorforwarder/interfaces/IAuthorizedReceiver.sol', 'src/v0.8/shared/access/ConfirmedOwnerWithProposal.sol', 'src/v0.8/shared/interfaces/IOwnable.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655005` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 17 |
| 🟢 LOW | 2 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 187 行
- **函数**: `functionDelegateCall()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
    184 |         bytes memory data,
    185 |         string memory errorMessage
    186 |     ) internal returns (bytes memory) {
>>  187 |         (bool success, bytes memory returndata) = target.delegatecall(data);
    188 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    189 |     }
    190 | 
```

---

### 2. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 69 行
- **函数**: `sendValue()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
     66 |     function sendValue(address payable recipient, uint256 amount) internal {
     67 |         require(address(this).balance >= amount, "Address: insufficient balance");
     68 | 
>>   69 |         (bool success, ) = recipient.call{value: amount}("");
     70 |         require(success, "Address: unable to send value, recipient may have reverted");
     71 |     }
     72 | 
```

---

### 3. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 137 行
- **函数**: `functionCallWithValue()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    134 |         string memory errorMessage
    135 |     ) internal returns (bytes memory) {
    136 |         require(address(this).balance >= value, "Address: insufficient balance for call");
>>  137 |         (bool success, bytes memory returndata) = target.call{value: value}(data);
    138 |         return verifyCallResultFromTarget(target, success, returndata, errorMessage);
    139 |     }
    140 | 
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 333 行
- **函数**: `_forward()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    330 |   function _forward(address to, bytes calldata data) private {
    331 |     require(to.isContract(), "Must forward to a contract");
    332 |     // solhint-disable-next-line avoid-low-level-calls
>>  333 |     (bool success, bytes memory result) = to.call(data);
    334 |     if (!success) {
    335 |       if (result.length == 0) revert("Forwarded call reverted without reason");
    336 |       assembly {
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 286 行
- **函数**: `forward()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    283 |   // @dev Only callable by an authorized sender
    284 |   // @param to address
    285 |   // @param data to forward
>>  286 |   function forward(address to, bytes calldata data) external validateAuthorizedSender {
    287 |     require(to != linkToken, "Cannot forward to Link token");
    288 |     _forward(to, data);
    289 |   }
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 295 行
- **函数**: `multiForward()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    292 |   //  @dev Only callable by an authorized sender
    293 |   //  @param tos An array of addresses to forward the calls to
    294 |   //  @param datas An array of data to forward to each corresponding address
>>  295 |   function multiForward(address[] calldata tos, bytes[] calldata datas) external validateAuthorizedSender {
    296 |     require(tos.length == datas.length, "Arrays must have the same length");
    297 | 
    298 |     for (uint256 i = 0; i < tos.length; ++i) {
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 318 行
- **函数**: `transferOwnershipWithMessage()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    315 |   // @notice Transfer ownership with instructions for recipient
    316 |   // @param to address proposed recipient of ownership
    317 |   // @param message instructions for recipient upon accepting ownership
>>  318 |   function transferOwnershipWithMessage(address to, bytes calldata message) external {
    319 |     transferOwnership(to);
    320 |     emit OwnershipTransferRequestedWithMessage(msg.sender, to, message);
    321 |   }
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 360 行
- **函数**: `setAuthorizedSenders()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    357 | 
    358 |   // @notice Sets the fulfillment permission for a given node. Use `true` to allow, `false` to disallow.
    359 |   // @param senders The addresses of the authorized Chainlink node
>>  360 |   function setAuthorizedSenders(address[] calldata senders) external override validateAuthorizedSenderSetter {
    361 |     require(senders.length > 0, "Must have at least 1 sender");
    362 |     // Set previous authorized senders to false
    363 |     uint256 authorizedSendersLength = s_authorizedSenderList.length;
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 379 行
- **函数**: `getAuthorizedSenders()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    376 | 
    377 |   // @notice Retrieve a list of authorized senders
    378 |   // @return array of addresses
>>  379 |   function getAuthorizedSenders() external view override returns (address[] memory) {
    380 |     return s_authorizedSenderList;
    381 |   }
    382 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 386 行
- **函数**: `isAuthorizedSender()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    383 |   // @notice Use this to check if a node is authorized for fulfilling requests
    384 |   // @param sender The address of the Chainlink node
    385 |   // @return The authorization status of the node
>>  386 |   function isAuthorizedSender(address sender) public view override returns (bool) {
    387 |     return s_authorizedSenders[sender];
    388 |   }
    389 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 419 行
- **函数**: `isAuthorizedSender()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    416 | pragma solidity ^0.8.0;
    417 | 
    418 | interface IAuthorizedReceiver {
>>  419 |   function isAuthorizedSender(address sender) external view returns (bool);
    420 | 
    421 |   function getAuthorizedSenders() external returns (address[] memory);
    422 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 421 行
- **函数**: `getAuthorizedSenders()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    418 | interface IAuthorizedReceiver {
    419 |   function isAuthorizedSender(address sender) external view returns (bool);
    420 | 
>>  421 |   function getAuthorizedSenders() external returns (address[] memory);
    422 | 
    423 |   function setAuthorizedSenders(address[] calldata senders) external;
    424 | }
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 459 行
- **函数**: `acceptOwnership()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    456 |   }
    457 | 
    458 |   /// @notice Allows an ownership transfer to be completed by the recipient.
>>  459 |   function acceptOwnership() external override {
    460 |     // solhint-disable-next-line gas-custom-errors
    461 |     require(msg.sender == s_pendingOwner, "Must be proposed owner");
    462 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 471 行
- **函数**: `owner()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    468 |   }
    469 | 
    470 |   /// @notice Get the current owner
>>  471 |   function owner() public view override returns (address) {
    472 |     return s_owner;
    473 |   }
    474 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 505 行
- **函数**: `owner()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    502 | pragma solidity ^0.8.0;
    503 | 
    504 | interface IOwnable {
>>  505 |   function owner() external returns (address);
    506 | 
    507 |   function transferOwnership(address recipient) external;
    508 | 
```

---

### 16. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 259 行
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    254 | import {ConfirmedOwnerWithProposal} from "../shared/access/ConfirmedOwnerWithProposal.sol";
    255 | import {AuthorizedReceiver} from "./AuthorizedReceiver.sol";
    256 | import {Address} from "@openzeppelin/contracts/utils/Address.sol";
    257 | 
    258 | // solhint-disable gas-custom-errors
>>  259 | contract AuthorizedForwarder is ConfirmedOwnerWithProposal, AuthorizedReceiver {
    260 |   using Address for address;
    261 | 
    262 |   // solhint-disable-next-line chainlink-solidity/prefix-immutable-variables-with-i
    263 |   address public immutable linkToken;
    264 | 
```

---

### 17. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 352 行
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    347 | pragma solidity 0.8.19;
    348 | 
    349 | import {IAuthorizedReceiver} from "./interfaces/IAuthorizedReceiver.sol";
    350 | 
    351 | // solhint-disable gas-custom-errors
>>  352 | abstract contract AuthorizedReceiver is IAuthorizedReceiver {
    353 |   mapping(address sender => bool authorized) private s_authorizedSenders;
    354 |   address[] private s_authorizedSenderList;
    355 | 
    356 |   event AuthorizedSendersChanged(address[] senders, address changedBy);
    357 | 
```

---

### 18. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 435 行
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    430 | pragma solidity ^0.8.0;
    431 | 
    432 | import {IOwnable} from "../interfaces/IOwnable.sol";
    433 | 
    434 | /// @title The ConfirmedOwner contract
>>  435 | /// @notice A contract with helpers for basic contract ownership.
    436 | contract ConfirmedOwnerWithProposal is IOwnable {
    437 |   address private s_owner;
    438 |   address private s_pendingOwner;
    439 | 
    440 |   event OwnershipTransferRequested(address indexed from, address indexed to);
```

---

### 19. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 238 行
- **函数**: `_revert()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    235 |         if (returndata.length > 0) {
    236 |             // The easiest way to bubble the revert reason is using memory via assembly
    237 |             /// @solidity memory-safe-assembly
>>  238 |             assembly {
    239 |                 let returndata_size := mload(returndata)
    240 |                 revert(add(32, returndata), returndata_size)
    241 |             }
```

---

### 20. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xc7F79eA9c7FF17968eEC60b4CC9880905cFdb2f4` 第 336 行
- **函数**: `_forward()`
- **合约**: `in`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    333 |     (bool success, bytes memory result) = to.call(data);
    334 |     if (!success) {
    335 |       if (result.length == 0) revert("Forwarded call reverted without reason");
>>  336 |       assembly {
    337 |         revert(add(32, result), mload(result))
    338 |       }
    339 |     }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*