# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:51:57
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` |
| contract_name | `ARK` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `cancun` |
| license_type | `MIT` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107655005` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 31 |
| 🟢 LOW | 8 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 79 行
- **函数**: `getRoleAdmin()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     76 |      *
     77 |      * To change a role's admin, use {AccessControl-_setRoleAdmin}.
     78 |      */
>>   79 |     function getRoleAdmin(bytes32 role) external view returns (bytes32);
     80 | 
     81 |     /**
     82 |      * @dev Grants `role` to `account`.
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 177 行
- **函数**: `supportsInterface()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    174 |      *
    175 |      * This function call must use less than 30 000 gas.
    176 |      */
>>  177 |     function supportsInterface(bytes4 interfaceId) external view returns (bool);
    178 | }
    179 | 
    180 | // File @openzeppelin/contracts/utils/introspection/ERC165.sol@v5.3.0
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 329 行
- **函数**: `getRoleAdmin()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    326 |      *
    327 |      * To change a role's admin, use {_setRoleAdmin}.
    328 |      */
>>  329 |     function getRoleAdmin(bytes32 role) public view virtual returns (bytes32) {
    330 |         return _roles[role].adminRole;
    331 |     }
    332 | 
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 662 行
- **函数**: `totalSupply()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    659 |     /**
    660 |      * @dev Returns the value of tokens in existence.
    661 |      */
>>  662 |     function totalSupply() external view returns (uint256);
    663 | 
    664 |     /**
    665 |      * @dev Returns the value of tokens owned by `account`.
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 667 行
- **函数**: `balanceOf()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    664 |     /**
    665 |      * @dev Returns the value of tokens owned by `account`.
    666 |      */
>>  667 |     function balanceOf(address account) external view returns (uint256);
    668 | 
    669 |     /**
    670 |      * @dev Moves a `value` amount of tokens from the caller's account to `to`.
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 676 行
- **函数**: `transfer()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    673 |      *
    674 |      * Emits a {Transfer} event.
    675 |      */
>>  676 |     function transfer(address to, uint256 value) external returns (bool);
    677 | 
    678 |     /**
    679 |      * @dev Returns the remaining number of tokens that `spender` will be
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 705 行
- **函数**: `approve()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    702 |      *
    703 |      * Emits an {Approval} event.
    704 |      */
>>  705 |     function approve(address spender, uint256 value) external returns (bool);
    706 | 
    707 |     /**
    708 |      * @dev Moves a `value` amount of tokens from `from` to `to` using the
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 737 行
- **函数**: `name()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    734 |     /**
    735 |      * @dev Returns the name of the token.
    736 |      */
>>  737 |     function name() external view returns (string memory);
    738 | 
    739 |     /**
    740 |      * @dev Returns the symbol of the token.
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 742 行
- **函数**: `symbol()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    739 |     /**
    740 |      * @dev Returns the symbol of the token.
    741 |      */
>>  742 |     function symbol() external view returns (string memory);
    743 | 
    744 |     /**
    745 |      * @dev Returns the decimals places of the token.
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 747 行
- **函数**: `decimals()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    744 |     /**
    745 |      * @dev Returns the decimals places of the token.
    746 |      */
>>  747 |     function decimals() external view returns (uint8);
    748 | }
    749 | 
    750 | // File @openzeppelin/contracts/token/ERC20/ERC20.sol@v5.3.0
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 798 行
- **函数**: `name()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    795 |     /**
    796 |      * @dev Returns the name of the token.
    797 |      */
>>  798 |     function name() public view virtual returns (string memory) {
    799 |         return _name;
    800 |     }
    801 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 806 行
- **函数**: `symbol()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    803 |      * @dev Returns the symbol of the token, usually a shorter version of the
    804 |      * name.
    805 |      */
>>  806 |     function symbol() public view virtual returns (string memory) {
    807 |         return _symbol;
    808 |     }
    809 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 823 行
- **函数**: `decimals()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    820 |      * no way affects any of the arithmetic of the contract, including
    821 |      * {IERC20-balanceOf} and {IERC20-transfer}.
    822 |      */
>>  823 |     function decimals() public view virtual returns (uint8) {
    824 |         return 18;
    825 |     }
    826 | 
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 830 行
- **函数**: `totalSupply()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    827 |     /**
    828 |      * @dev See {IERC20-totalSupply}.
    829 |      */
>>  830 |     function totalSupply() public view virtual returns (uint256) {
    831 |         return _totalSupply;
    832 |     }
    833 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 837 行
- **函数**: `balanceOf()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    834 |     /**
    835 |      * @dev See {IERC20-balanceOf}.
    836 |      */
>>  837 |     function balanceOf(address account) public view virtual returns (uint256) {
    838 |         return _balances[account];
    839 |     }
    840 | 
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 849 行
- **函数**: `transfer()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    846 |      * - `to` cannot be the zero address.
    847 |      * - the caller must have a balance of at least `value`.
    848 |      */
>>  849 |     function transfer(address to, uint256 value) public virtual returns (bool) {
    850 |         address owner = _msgSender();
    851 |         _transfer(owner, to, value);
    852 |         return true;
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 1115 行
- **函数**: `burn()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1112 |      *
   1113 |      * See {ERC20-_burn}.
   1114 |      */
>> 1115 |     function burn(uint256 value) public virtual {
   1116 |         _burn(_msgSender(), value);
   1117 |     }
   1118 | 
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 1130 行
- **函数**: `burnFrom()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1127 |      * - the caller must have allowance for ``accounts``'s tokens of at least
   1128 |      * `value`.
   1129 |      */
>> 1130 |     function burnFrom(address account, uint256 value) public virtual {
   1131 |         _spendAllowance(account, _msgSender(), value);
   1132 |         _burn(account, value);
   1133 |     }
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 1220 行
- **函数**: `nonces()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1217 |      * Every successful call to {permit} increases ``owner``'s nonce by one. This
   1218 |      * prevents a signature from being used multiple times.
   1219 |      */
>> 1220 |     function nonces(address owner) external view returns (uint256);
   1221 | 
   1222 |     /**
   1223 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 1226 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   1223 |      * @dev Returns the domain separator used in the encoding of the signature for {permit}, as defined by {EIP712}.
   1224 |      */
   1225 |     // solhint-disable-next-line func-name-mixedcase
>> 1226 |     function DOMAIN_SEPARATOR() external view returns (bytes32);
   1227 | }
   1228 | 
   1229 | // File @openzeppelin/contracts/utils/cryptography/ECDSA.sol@v5.3.0
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 4883 行
- **函数**: `nonces()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   4880 |     /**
   4881 |      * @dev Returns the next unused nonce for an address.
   4882 |      */
>> 4883 |     function nonces(address owner) public view virtual returns (uint256) {
   4884 |         return _nonces[owner];
   4885 |     }
   4886 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 5004 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5001 |      * @inheritdoc IERC20Permit
   5002 |      */
   5003 |     // solhint-disable-next-line func-name-mixedcase
>> 5004 |     function DOMAIN_SEPARATOR() external view virtual returns (bytes32) {
   5005 |         return _domainSeparatorV4();
   5006 |     }
   5007 | }
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 5142 行
- **函数**: `mint()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
   5139 |         return true;
   5140 |     }
   5141 | 
>> 5142 |     function mint(address to, uint256 amount) public {
   5143 |         require(
   5144 |             msg.sender == oracle || msg.sender == rbs,
   5145 |             "unauthorized access"
```

---

### 24. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 775 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    770 |  * We have followed general OpenZeppelin Contracts guidelines: functions revert
    771 |  * instead returning `false` on failure. This behavior is nonetheless
    772 |  * conventional and does not conflict with the expectations of ERC-20
    773 |  * applications.
    774 |  */
>>  775 | abstract contract ERC20 is Context, IERC20, IERC20Metadata, IERC20Errors {
    776 |     mapping(address => uint256) private _balances;
    777 | 
    778 |     mapping(address => mapping(address => uint256)) private _allowances;
    779 | 
    780 |     uint256 private _totalSupply;
```

---

### 25. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 1482 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1477 |      * @dev MAY be emitted to signal that the domain could have changed.
   1478 |      */
   1479 |     event EIP712DomainChanged();
   1480 | 
   1481 |     /**
>> 1482 |      * @dev returns the fields and values that describe the domain separator used by this contract for EIP-712
   1483 |      * signature.
   1484 |      */
   1485 |     function eip712Domain()
   1486 |         external
   1487 |         view
```

---

### 26. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 3184 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   3179 |      * Requirements:
   3180 |      * - modulus can't be zero
   3181 |      * - underlying staticcall to precompile must succeed
   3182 |      *
   3183 |      * IMPORTANT: The result is only valid if the underlying call succeeds. When using this function, make
>> 3184 |      * sure the chain you're using it on supports the precompiled contract for modular exponentiation
   3185 |      * at address 0x05 as specified in https://eips.ethereum.org/EIPS/eip-198[EIP-198]. Otherwise,
   3186 |      * the underlying function will succeed given the lack of a revert, but the result may be incorrectly
   3187 |      * interpreted as 0.
   3188 |      */
   3189 |     function modExp(
```

---

### 27. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 4569 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4564 |  * fallback mechanism can be used for every other case.
   4565 |  *
   4566 |  * Usage example:
   4567 |  *
   4568 |  * ```solidity
>> 4569 |  * contract Named {
   4570 |  *     using ShortStrings for *;
   4571 |  *
   4572 |  *     ShortString private immutable _name;
   4573 |  *     string private _nameFallback;
   4574 |  *
```

---

### 28. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 4716 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4711 |  * separator of the implementation contract. This will cause the {_domainSeparatorV4} function to always rebuild the
   4712 |  * separator from the immutable values, which is cheaper than accessing a cached version in cold storage.
   4713 |  *
   4714 |  * @custom:oz-upgrades-unsafe-allow state-variable-immutable
   4715 |  */
>> 4716 | abstract contract EIP712 is IERC5267 {
   4717 |     using ShortStrings for *;
   4718 | 
   4719 |     bytes32 private constant TYPE_HASH =
   4720 |         keccak256(
   4721 |             "EIP712Domain(string name,string version,uint256 chainId,address verifyingContract)"
```

---

### 29. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 4872 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4867 | pragma solidity ^0.8.20;
   4868 | 
   4869 | /**
   4870 |  * @dev Provides tracking nonces for addresses. Nonces will only increment.
   4871 |  */
>> 4872 | abstract contract Nonces {
   4873 |     /**
   4874 |      * @dev The nonce used for an `account` is not the expected current nonce.
   4875 |      */
   4876 |     error InvalidAccountNonce(address account, uint256 currentNonce);
   4877 | 
```

---

### 30. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 4927 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   4922 |  *
   4923 |  * Adds the {permit} method, which can be used to change an account's ERC-20 allowance (see {IERC20-allowance}) by
   4924 |  * presenting a message signed by the account. By not relying on `{IERC20-approve}`, the token holder account doesn't
   4925 |  * need to send a transaction, and thus is not required to hold Ether at all.
   4926 |  */
>> 4927 | abstract contract ERC20Permit is ERC20, IERC20Permit, EIP712, Nonces {
   4928 |     bytes32 private constant PERMIT_TYPEHASH =
   4929 |         keccak256(
   4930 |             "Permit(address owner,address spender,uint256 value,uint256 nonce,uint256 deadline)"
   4931 |         );
   4932 | 
```

---

### 31. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 5014 行
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   5009 | // File contracts/pERC20.sol
   5010 | 
   5011 | // Original license: SPDX_License_Identifier: MIT
   5012 | pragma solidity ^0.8.22;
   5013 | 
>> 5014 | contract ARK is ERC20Burnable, ERC20Permit {
   5015 |     mapping(address => bool) public longGovernanceList;
   5016 |     mapping(address => bool) public shortGovernanceList;
   5017 |     mapping(address => bool) public whitelist;
   5018 |     address public governance;
   5019 |     address public oracle;
```

---

### 32. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 4962 行
- **函数**: `permit()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
   4959 |         bytes32 r,
   4960 |         bytes32 s
   4961 |     ) public virtual {
>> 4962 |         if (block.timestamp > deadline) {
   4963 |             revert ERC2612ExpiredSignature(deadline);
   4964 |         }
   4965 | 
```

---

### 33. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 1364 行
- **函数**: `tryRecover()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1361 |         unchecked {
   1362 |             bytes32 s = vs &
   1363 |                 bytes32(
>> 1364 |                     0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff
   1365 |                 );
   1366 |             // We do not check for an overflow here since the shift operation results in 0 or 1.
   1367 |             uint8 v = uint8((uint256(vs) >> 255) + 27);
```

---

### 34. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 1418 行
- **函数**: `tryRecover()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   1415 |         // these malleable signatures as well.
   1416 |         if (
   1417 |             uint256(s) >
>> 1418 |             0x7FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF5D576E7357A4501DDFE92F46681B20A0
   1419 |         ) {
   1420 |             return (address(0), RecoverError.InvalidSignatureS, s);
   1421 |         }
```

---

### 35. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 3478 行
- **函数**: `log2()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   3475 |                 r,
   3476 |                 byte(
   3477 |                     shr(r, x),
>> 3478 |                     0x0000010102020202030303030303030300000000000000000000000000000000
   3479 |                 )
   3480 |             )
   3481 |         }
```

---

### 36. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 5028 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5025 | 
   5026 |     constructor() ERC20("ARK", "ARK") ERC20Permit("ARK") {
   5027 |         governance = msg.sender;
>> 5028 |         oracle = 0x615a2a799c49AF74E91b4C3Ca5eaD68897c07A81;
   5029 |         rbs = 0x23876D9F06F8290F119Fb39B7FDCf93A08e2D616;
   5030 | 
   5031 |         treasury = 0xd9D1c7dCf7CB6181A61ed0E70F64fe7Ddd4B9495;
```

---

### 37. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 5029 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5026 |     constructor() ERC20("ARK", "ARK") ERC20Permit("ARK") {
   5027 |         governance = msg.sender;
   5028 |         oracle = 0x615a2a799c49AF74E91b4C3Ca5eaD68897c07A81;
>> 5029 |         rbs = 0x23876D9F06F8290F119Fb39B7FDCf93A08e2D616;
   5030 | 
   5031 |         treasury = 0xd9D1c7dCf7CB6181A61ed0E70F64fe7Ddd4B9495;
   5032 |         longGovernanceRatio = 9999;
```

---

### 38. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 5031 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5028 |         oracle = 0x615a2a799c49AF74E91b4C3Ca5eaD68897c07A81;
   5029 |         rbs = 0x23876D9F06F8290F119Fb39B7FDCf93A08e2D616;
   5030 | 
>> 5031 |         treasury = 0xd9D1c7dCf7CB6181A61ed0E70F64fe7Ddd4B9495;
   5032 |         longGovernanceRatio = 9999;
   5033 | 
   5034 |         // mint initial supply to treasury
```

---

### 39. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xCae117ca6Bc8A341D2E7207F30E180f0e5618B9D` 第 5035 行
- **函数**: `DOMAIN_SEPARATOR()`
- **合约**: `call`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
   5032 |         longGovernanceRatio = 9999;
   5033 | 
   5034 |         // mint initial supply to treasury
>> 5035 |         _mint(0xf7B2f3Fc7d5107c2bF3776B5C02a818F33F9453e, 1_150_000 ether);
   5036 |     }
   5037 | 
   5038 |     modifier onlyGovernance() {
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*