# 智能合约安全审计报告

> 生成时间: 2026-07-02 13:45:31
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` |
| contract_name | `FortuneSign` |
| compiler_version | `v0.8.24+commit.e11b9ed9` |
| optimization_used | `False` |
| runs | `200` |
| evm_version | `Default` |
| license_type | `None` |
| proxy | `False` |
| implementation | `` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646140` |

## 安全摘要

**整体风险等级**: MEDIUM

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 0 |
| 🟡 MEDIUM | 14 |
| 🟢 LOW | 5 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟡 [MEDIUM] predictable-random

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 169 行
- **函数**: `sign()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.537

**工具描述**: 使用区块属性生成随机数，可被预测，不适合用于抽奖/赌博等场景。

**代码片段**:
```solidity
    166 | 
    167 | 
    168 |     function sign() external payable nonReentrant {
>>  169 |         uint256 curDay = (block.timestamp - startTime) / secondsPerDay + 1;
    170 |         require(lastSignDay[_msgSender()] == 0 || lastSignDay[_msgSender()] < curDay, "Exists");
    171 | 
    172 |         lastSignDay[_msgSender()] = curDay;
```

---

### 2. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 92 行
- **函数**: `getReserves()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
     89 | }
     90 | 
     91 | interface IPancakePair {
>>   92 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     93 |     function token0() external view returns (address);
     94 |     function token1() external view returns (address);
     95 | }
```

---

### 3. 🟡 [MEDIUM] uniswap-reserve-oracle

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 203 行
- **函数**: `getRequiredBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.522

**工具描述**: 直接使用 Uniswap getReserves() 作为价格源，存在闪电贷操纵风险。应使用 TWAP 或 Chainlink。

**代码片段**:
```solidity
    200 |             return 0;
    201 |         }
    202 |         IPancakePair pair = IPancakePair(PANCAKE_USDT_BNB_PAIR);
>>  203 |         (uint112 reserve0, uint112 reserve1, ) = pair.getReserves();
    204 | 
    205 |         address token0 = pair.token0();
    206 |         uint256 reserveBNB = (token0 == WBNB) ? uint256(reserve0) : uint256(reserve1);
```

---

### 4. 🟡 [MEDIUM] unchecked-call

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 104 行
- **函数**: `safeTransfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 低级别 .call() 返回值未被 require/assert 检查。

**代码片段**:
```solidity
    101 |         uint256 value
    102 |     ) internal {
    103 |         // bytes4(keccak256(bytes('transfer(address,uint256)')));
>>  104 |         (bool success, bytes memory data) = token.call(abi.encodeWithSelector(0xa9059cbb, to, value));
    105 |         require(
    106 |             success && (data.length == 0 || abi.decode(data, (bool))),
    107 |             'TransferHelper::safeTransfer: transfer failed'
```

---

### 5. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 184 行
- **函数**: `sign()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    181 |         uint256 fee = requiredBNB;
    182 |         uint256 refund = msg.value - fee;
    183 | 
>>  184 |         (bool sent, ) = feeRecipient.call{value: fee}("");
    185 |         require(sent, "Fee transfer failed");
    186 | 
    187 |         if (refund > 0) {
```

---

### 6. 🟡 [MEDIUM] reentrancy-risk

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 188 行
- **函数**: `sign()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.515

**工具描述**: 外部 .call{value: ...} 调用，如状态更新在调用之后则存在重入风险。

**代码片段**:
```solidity
    185 |         require(sent, "Fee transfer failed");
    186 | 
    187 |         if (refund > 0) {
>>  188 |             (bool refunded, ) = msg.sender.call{value: refund}("");
    189 |             require(refunded, "Refund failed");
    190 |         }
    191 |     }
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 49 行
- **函数**: `owner()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     46 |     /**
     47 |      * @dev Returns the address of the current owner.
     48 |      */
>>   49 |     function owner() public view virtual returns (address) {
     50 |         return _owner;
     51 |     }
     52 | 
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 92 行
- **函数**: `getReserves()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     89 | }
     90 | 
     91 | interface IPancakePair {
>>   92 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     93 |     function token0() external view returns (address);
     94 |     function token1() external view returns (address);
     95 | }
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 93 行
- **函数**: `token0()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     90 | 
     91 | interface IPancakePair {
     92 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
>>   93 |     function token0() external view returns (address);
     94 |     function token1() external view returns (address);
     95 | }
     96 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 94 行
- **函数**: `token1()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     91 | interface IPancakePair {
     92 |     function getReserves() external view returns (uint112 reserve0, uint112 reserve1, uint32 blockTimestampLast);
     93 |     function token0() external view returns (address);
>>   94 |     function token1() external view returns (address);
     95 | }
     96 | 
     97 | library TransferHelper {
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 198 行
- **函数**: `getRequiredBNB()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    195 |         return true;
    196 |     }
    197 | 
>>  198 |     function getRequiredBNB() public view returns (uint256) {
    199 |         if (feeUsdtValue == 0) {
    200 |             return 0;
    201 |         }
```

---

### 12. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 26 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     21 |  *
     22 |  * This module is used through inheritance. It will make available the modifier
     23 |  * `onlyOwner`, which can be applied to your functions to restrict their use to
     24 |  * the owner.
     25 |  */
>>   26 | abstract contract Ownable is Context {
     27 |     address private _owner;
     28 | 
     29 |     event OwnershipTransferred(address indexed previousOwner, address indexed newOwner);
     30 | 
     31 |     /**
```

---

### 13. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 81 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     76 |         require(newOwner != address(0), "Ownable: new owner is the zero address");
     77 |         _transferOwnership(newOwner);
     78 |     }
     79 | 
     80 |     /**
>>   81 |      * @dev Transfers ownership of the contract to a new account (`newOwner`).
     82 |      * Internal function without access restriction.
     83 |      */
     84 |     function _transferOwnership(address newOwner) internal virtual {
     85 |         address oldOwner = _owner;
     86 |         _owner = newOwner;
```

---

### 14. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 132 行
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    127 | 
    128 |         _status = _NOT_ENTERED;
    129 |     }
    130 | }
    131 | 
>>  132 | contract FortuneSign is Ownable, ReentrancyGuard {    
    133 |     uint256 constant public startTime = 1775174400;
    134 |     uint256 constant public secondsPerDay = 1 days;
    135 |     uint256 private id = 1000000;
    136 | 
    137 |     mapping (address => uint256) public lastSignDay;
```

---

### 15. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 169 行
- **函数**: `sign()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    166 | 
    167 | 
    168 |     function sign() external payable nonReentrant {
>>  169 |         uint256 curDay = (block.timestamp - startTime) / secondsPerDay + 1;
    170 |         require(lastSignDay[_msgSender()] == 0 || lastSignDay[_msgSender()] < curDay, "Exists");
    171 | 
    172 |         lastSignDay[_msgSender()] = curDay;
```

---

### 16. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 174 行
- **函数**: `sign()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    171 | 
    172 |         lastSignDay[_msgSender()] = curDay;
    173 | 
>>  174 |         emit Signed(id, _msgSender(), block.timestamp);
    175 | 
    176 |         id ++;
    177 | 
```

---

### 17. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 145 行
- **函数**: `safeTransfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    142 |     uint256 public feeUsdtValue = 10_000_000_000_000_000; // 0.01 USDT
    143 | 
    144 |     // Pancake V2 USDT-BNB Pair 
>>  145 |     address public constant PANCAKE_USDT_BNB_PAIR = 0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE;
    146 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
    147 |     address public feeRecipient = 0x641DF1b144cd58a19D69253958AE60c1916F27d2;
    148 | 
```

---

### 18. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 146 行
- **函数**: `safeTransfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    143 | 
    144 |     // Pancake V2 USDT-BNB Pair 
    145 |     address public constant PANCAKE_USDT_BNB_PAIR = 0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE;
>>  146 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
    147 |     address public feeRecipient = 0x641DF1b144cd58a19D69253958AE60c1916F27d2;
    148 | 
    149 |     constructor() {
```

---

### 19. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0x634813DD921ed175Ddaa93fCa1F3AA4E3f0F1bD7` 第 147 行
- **函数**: `safeTransfer()`
- **合约**: `Context`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    144 |     // Pancake V2 USDT-BNB Pair 
    145 |     address public constant PANCAKE_USDT_BNB_PAIR = 0x16b9a82891338f9bA80E2D6970FddA79D1eb0daE;
    146 |     address public constant WBNB = 0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c;
>>  147 |     address public feeRecipient = 0x641DF1b144cd58a19D69253958AE60c1916F27d2;
    148 | 
    149 |     constructor() {
    150 | 
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*