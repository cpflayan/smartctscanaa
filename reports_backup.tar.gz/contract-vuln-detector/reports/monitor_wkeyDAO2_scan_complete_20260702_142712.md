# 智能合约安全审计报告

> 生成时间: 2026-07-02 14:27:12
> 生成工具: contract-vuln-detector

## 合约信息

| 项目 | 值 |
|------|-----|
| address | `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` |
| contract_name | `wkeyDAO2` |
| compiler_version | `v0.7.5+commit.eb77ed08` |
| optimization_used | `True` |
| runs | `200` |
| evm_version | `istanbul` |
| license_type | `` |
| proxy | `False` |
| implementation | `` |
| multi_file | `True` |
| source_files | `['contracts/2.0/wkeyDAO2.sol', 'node_modules/@openzeppelin/contracts/access/AccessControl.sol', 'node_modules/@openzeppelin/contracts/utils/EnumerableSet.sol', 'node_modules/@openzeppelin/contracts/utils/Address.sol', 'node_modules/@openzeppelin/contracts/utils/Context.sol']` |
| chain | `bsc` |
| chain_id | `56` |
| block_number | `107646144` |

## 安全摘要

**整体风险等级**: HIGH

> Monitor-triggered scan (scan_complete)

### 漏洞分布

| 严重程度 | 数量 |
|----------|------|
| 🔴 CRITICAL | 0 |
| 🟠 HIGH | 1 |
| 🟡 MEDIUM | 36 |
| 🟢 LOW | 6 |
| 🔵 INFO | 0 |

## 详细分析

### 1. 🟠 [HIGH] controlled-delegatecall

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 1100 行
- **函数**: `functionDelegateCall()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.710

**工具描述**: 使用了 delegatecall，如果目标地址可控则存在代码注入风险。

**代码片段**:
```solidity
   1097 |         require(isContract(target), "Address: delegate call to non-contract");
   1098 | 
   1099 |         // solhint-disable-next-line avoid-low-level-calls
>> 1100 |         (bool success, bytes memory returndata) = target.delegatecall(data);
   1101 |         return _verifyCallResult(success, returndata, errorMessage);
   1102 |     }
   1103 | 
```

---

### 2. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 9 行
- **函数**: `totalSupply()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      6 | import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
      7 | 
      8 | interface IERC20 {
>>    9 |     function totalSupply() external view returns (uint256);
     10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
```

---

### 3. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 10 行
- **函数**: `balanceOf()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      7 | 
      8 | interface IERC20 {
      9 |     function totalSupply() external view returns (uint256);
>>   10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
```

---

### 4. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 11 行
- **函数**: `transfer()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      8 | interface IERC20 {
      9 |     function totalSupply() external view returns (uint256);
     10 |     function balanceOf(address account) external view returns (uint256);
>>   11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
     14 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
```

---

### 5. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 12 行
- **函数**: `allowance()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
      9 |     function totalSupply() external view returns (uint256);
     10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
>>   12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
     14 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     15 | 
```

---

### 6. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 13 行
- **函数**: `approve()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     10 |     function balanceOf(address account) external view returns (uint256);
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
>>   13 |     function approve(address spender, uint256 amount) external returns (bool);
     14 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     15 | 
     16 |     event Transfer(address indexed from, address indexed to, uint256 value);
```

---

### 7. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 14 行
- **函数**: `transferFrom()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     11 |     function transfer(address recipient, uint256 amount) external returns (bool);
     12 |     function allowance(address owner, address spender) external view returns (uint256);
     13 |     function approve(address spender, uint256 amount) external returns (bool);
>>   14 |     function transferFrom(address sender, address recipient, uint256 amount) external returns (bool);
     15 | 
     16 |     event Transfer(address indexed from, address indexed to, uint256 value);
     17 |     event Approval(address indexed owner, address indexed spender, uint256 value);
```

---

### 8. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 85 行
- **函数**: `name()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     82 |         _decimals = decimals_;
     83 |     }
     84 | 
>>   85 |     function name() public view returns (string memory) {
     86 |         return _name;
     87 |     }
     88 | 
```

---

### 9. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 89 行
- **函数**: `symbol()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     86 |         return _name;
     87 |     }
     88 | 
>>   89 |     function symbol() public view returns (string memory) {
     90 |         return _symbol;
     91 |     }
     92 | 
```

---

### 10. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 93 行
- **函数**: `decimals()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     90 |         return _symbol;
     91 |     }
     92 | 
>>   93 |     function decimals() public view returns (uint8) {
     94 |         return _decimals;
     95 |     }
     96 | 
```

---

### 11. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 97 行
- **函数**: `totalSupply()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     94 |         return _decimals;
     95 |     }
     96 | 
>>   97 |     function totalSupply() public view override returns (uint256) {
     98 |         return _totalSupply;
     99 |     }
    100 | 
```

---

### 12. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 101 行
- **函数**: `balanceOf()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
     98 |         return _totalSupply;
     99 |     }
    100 | 
>>  101 |     function balanceOf(address account) public view virtual override returns (uint256) {
    102 |         return _balances[account];
    103 |     }
    104 | 
```

---

### 13. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 105 行
- **函数**: `transfer()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    102 |         return _balances[account];
    103 |     }
    104 | 
>>  105 |     function transfer(address recipient, uint256 amount) public virtual override returns (bool) {
    106 |         _transfer(msg.sender, recipient, amount);
    107 |         return true;
    108 |     }
```

---

### 14. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 110 行
- **函数**: `allowance()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    107 |         return true;
    108 |     }
    109 | 
>>  110 |     function allowance(address owner, address spender) public view virtual override returns (uint256) {
    111 |         return _allowances[owner][spender];
    112 |     }
    113 | 
```

---

### 15. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 114 行
- **函数**: `approve()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    111 |         return _allowances[owner][spender];
    112 |     }
    113 | 
>>  114 |     function approve(address spender, uint256 amount) public virtual override returns (bool) {
    115 |         _approve(msg.sender, spender, amount);
    116 |         return true;
    117 |     }
```

---

### 16. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 119 行
- **函数**: `transferFrom()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    116 |         return true;
    117 |     }
    118 | 
>>  119 |     function transferFrom(address sender, address recipient, uint256 amount) public virtual override returns (bool) {
    120 |         _transfer(sender, recipient, amount);
    121 |         _approve(
    122 |             sender, msg.sender, _allowances[sender][msg.sender].sub(amount, "ERC20: transfer amount exceeds allowance")
```

---

### 17. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 127 行
- **函数**: `increaseAllowance()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    124 |         return true;
    125 |     }
    126 | 
>>  127 |     function increaseAllowance(address spender, uint256 addedValue) public virtual returns (bool) {
    128 |         _approve(msg.sender, spender, _allowances[msg.sender][spender].add(addedValue));
    129 |         return true;
    130 |     }
```

---

### 18. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 132 行
- **函数**: `decreaseAllowance()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    129 |         return true;
    130 |     }
    131 | 
>>  132 |     function decreaseAllowance(address spender, uint256 subtractedValue) public virtual returns (bool) {
    133 |         _approve(
    134 |             msg.sender,
    135 |             spender,
```

---

### 19. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 205 行
- **函数**: `nonces()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    202 |     function permit(address owner, address spender, uint256 amount, uint256 deadline, uint8 v, bytes32 r, bytes32 s)
    203 |         external;
    204 | 
>>  205 |     function nonces(address owner) external view returns (uint256);
    206 | }
    207 | 
    208 | abstract contract ERC20Permit is ERC20, IERC2612Permit {
```

---

### 20. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 253 行
- **函数**: `nonces()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    250 |         _approve(owner, spender, amount);
    251 |     }
    252 | 
>>  253 |     function nonces(address owner) public view override returns (uint256) {
    254 |         return _nonces[owner].current();
    255 |     }
    256 | }
```

---

### 21. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 280 行
- **函数**: `mint()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    277 | 
    278 |     constructor() ERC20("WebKey DAO 2.0", "wkeyDAO2", 9) {}
    279 | 
>>  280 |     function mint(address account_, uint256 amount_) external onlyVault {
    281 |         _mint(account_, amount_);
    282 |     }
    283 | 
```

---

### 22. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 284 行
- **函数**: `burn()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    281 |         _mint(account_, amount_);
    282 |     }
    283 | 
>>  284 |     function burn(uint256 amount) public virtual {
    285 |         _burn(msg.sender, amount);
    286 |     }
    287 | 
```

---

### 23. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 288 行
- **函数**: `burnFrom()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    285 |         _burn(msg.sender, amount);
    286 |     }
    287 | 
>>  288 |     function burnFrom(address account_, uint256 amount_) public virtual {
    289 |         _burnFrom(account_, amount_);
    290 |     }
    291 | 
```

---

### 24. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 338 行
- **函数**: `setMainPair()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    335 |         _setupRole(INTERN_SYSTEM, _feeReceiver);
    336 |     }
    337 | 
>>  338 |     function setMainPair(address pair) external onlyDefaultAdmin {
    339 |         mainPair = pair;
    340 |     }
    341 | 
```

---

### 25. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 342 行
- **函数**: `setFeeReceiver()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    339 |         mainPair = pair;
    340 |     }
    341 | 
>>  342 |     function setFeeReceiver(address _feeReceiver) external onlyDefaultAdmin {
    343 |         require(_feeReceiver != address(0), "Zero address");
    344 |         emit FeeReceiverChanged(feeReceiver, _feeReceiver);
    345 |         feeReceiver = _feeReceiver;
```

---

### 26. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 348 行
- **函数**: `setBuyFeeReceiver()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    345 |         feeReceiver = _feeReceiver;
    346 |     }
    347 | 
>>  348 |     function setBuyFeeReceiver(address _buyFeeReceiver) external onlyDefaultAdmin {
    349 |         require(_buyFeeReceiver != address(0), "Zero address");
    350 |         emit BuyFeeReceiverChanged(buyFeeReceiver, _buyFeeReceiver);
    351 |         buyFeeReceiver = _buyFeeReceiver;
```

---

### 27. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 354 行
- **函数**: `setRatio()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    351 |         buyFeeReceiver = _buyFeeReceiver;
    352 |     }
    353 | 
>>  354 |     function setRatio(uint8 ratioType, uint256 ratio) external onlyDefaultAdmin {
    355 |         require(ratio <= PRECISION, "Exceeds precision");
    356 |         if (ratioType == 0) {
    357 |             buyFeeRatio = ratio;
```

---

### 28. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 498 行
- **函数**: `hasRole()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    495 |     /**
    496 |      * @dev Returns `true` if `account` has been granted `role`.
    497 |      */
>>  498 |     function hasRole(bytes32 role, address account) public view returns (bool) {
    499 |         return _roles[role].members.contains(account);
    500 |     }
    501 | 
```

---

### 29. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 506 行
- **函数**: `getRoleMemberCount()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    503 |      * @dev Returns the number of accounts that have `role`. Can be used
    504 |      * together with {getRoleMember} to enumerate all bearers of a role.
    505 |      */
>>  506 |     function getRoleMemberCount(bytes32 role) public view returns (uint256) {
    507 |         return _roles[role].members.length();
    508 |     }
    509 | 
```

---

### 30. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 522 行
- **函数**: `getRoleMember()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    519 |      * https://forum.openzeppelin.com/t/iterating-over-elements-on-enumerableset-in-openzeppelin-contracts/2296[forum post]
    520 |      * for more information.
    521 |      */
>>  522 |     function getRoleMember(bytes32 role, uint256 index) public view returns (address) {
    523 |         return _roles[role].members.at(index);
    524 |     }
    525 | 
```

---

### 31. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 532 行
- **函数**: `getRoleAdmin()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    529 |      *
    530 |      * To change a role's admin, use {_setRoleAdmin}.
    531 |      */
>>  532 |     function getRoleAdmin(bytes32 role) public view returns (bytes32) {
    533 |         return _roles[role].adminRole;
    534 |     }
    535 | 
```

---

### 32. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 546 行
- **函数**: `grantRole()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    543 |      *
    544 |      * - the caller must have ``role``'s admin role.
    545 |      */
>>  546 |     function grantRole(bytes32 role, address account) public virtual {
    547 |         require(hasRole(_roles[role].adminRole, _msgSender()), "AccessControl: sender must be an admin to grant");
    548 | 
    549 |         _grantRole(role, account);
```

---

### 33. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 561 行
- **函数**: `revokeRole()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    558 |      *
    559 |      * - the caller must have ``role``'s admin role.
    560 |      */
>>  561 |     function revokeRole(bytes32 role, address account) public virtual {
    562 |         require(hasRole(_roles[role].adminRole, _msgSender()), "AccessControl: sender must be an admin to revoke");
    563 | 
    564 |         _revokeRole(role, account);
```

---

### 34. 🟡 [MEDIUM] missing-access-control

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 581 行
- **函数**: `renounceRole()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.507

**工具描述**: external/public 函数缺少常见访问控制修饰符，需人工确认权限管理是否完善。

**代码片段**:
```solidity
    578 |      *
    579 |      * - the caller must be `account`.
    580 |      */
>>  581 |     function renounceRole(bytes32 role, address account) public virtual {
    582 |         require(account == _msgSender(), "AccessControl: can only renounce roles for self");
    583 | 
    584 |         _revokeRole(role, account);
```

---

### 35. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 66 行
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
     61 |         require(b != 0, errorMessage);
     62 |         return a % b;
     63 |     }
     64 | }
     65 | 
>>   66 | abstract contract ERC20 is IERC20 {
     67 |     using SafeMath for uint256;
     68 | 
     69 |     bytes32 private constant ERC20TOKEN_ERC1820_INTERFACE_ID = keccak256("ERC20Token");
     70 | 
     71 |     mapping(address => uint256) internal _balances;
```

---

### 36. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 301 行
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
    296 |         _approve(account_, msg.sender, decreasedAllowance_);
    297 |         _burn(account_, amount_);
    298 |     }
    299 | }
    300 | 
>>  301 | contract wkeyDAO2 is WebKeyDAO2ERC20Token {
    302 |     using SafeMath for uint256;
    303 | 
    304 |     address public mainPair;
    305 |     address public feeReceiver;
    306 |     address public buyFeeReceiver;
```

---

### 37. 🟡 [MEDIUM] state-shadowing

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 1139 行
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.500

**工具描述**: 可能存在状态变量影子问题，局部变量与状态变量同名可能导致逻辑错误。

**代码片段**:
```solidity
   1134 |  * via msg.sender and msg.data, they should not be accessed in such a direct
   1135 |  * manner, since when dealing with GSN meta-transactions the account sending and
   1136 |  * paying for execution may not be the actual sender (as far as an application
   1137 |  * is concerned).
   1138 |  *
>> 1139 |  * This contract is only required for intermediate, library-like contracts.
   1140 |  */
   1141 | abstract contract Context {
   1142 |     function _msgSender() internal view virtual returns (address payable) {
   1143 |         return msg.sender;
   1144 |     }
```

---

### 38. 🟢 [LOW] old-solidity-version

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 4 行
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.378

**工具描述**: 使用 Solidity 0.8.0 之前版本，整数运算未内置溢出检查。

**代码片段**:
```solidity
      1 | // ── contracts/2.0/wkeyDAO2.sol ──────────────────────────────
      2 | 
      3 | // SPDX-License-Identifier: AGPL-3.0-or-later
>>    4 | pragma solidity 0.7.5;
      5 | 
      6 | import {AccessControl} from "@openzeppelin/contracts/access/AccessControl.sol";
      7 | 
```

---

### 39. 🟢 [LOW] timestamp-dependence

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 239 行
- **函数**: `permit()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.362

**工具描述**: 依赖 block.timestamp，矿工可在一定范围内操纵时间戳。

**代码片段**:
```solidity
    236 |         virtual
    237 |         override
    238 |     {
>>  239 |         require(block.timestamp <= deadline, "Permit: expired deadline");
    240 | 
    241 |         bytes32 hashStruct =
    242 |             keccak256(abi.encode(PERMIT_TYPEHASH, owner, spender, amount, _nonces[owner].current(), deadline));
```

---

### 40. 🟢 [LOW] hardcoded-address

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 213 行
- **函数**: `nonces()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.310

**工具描述**: 发现硬编码地址，建议使用常量或构造函数参数，便于部署到不同网络。

**代码片段**:
```solidity
    210 | 
    211 |     mapping(address => Counters.Counter) private _nonces;
    212 | 
>>  213 |     bytes32 public constant PERMIT_TYPEHASH = 0x6e71edae12b1b97f4d1f60370fef10105fa2faae0126114a169c64845d6126c9;
    214 | 
    215 |     bytes32 public DOMAIN_SEPARATOR;
    216 | 
```

---

### 41. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 219 行
- **函数**: `nonces()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    216 | 
    217 |     constructor() {
    218 |         uint256 chainID;
>>  219 |         assembly {
    220 |             chainID := chainid()
    221 |         }
    222 | 
```

---

### 42. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 966 行
- **函数**: `isContract()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
    963 | 
    964 |         uint256 size;
    965 |         // solhint-disable-next-line no-inline-assembly
>>  966 |         assembly { size := extcodesize(account) }
    967 |         return size > 0;
    968 |     }
    969 | 
```

---

### 43. 🟢 [LOW] inline-assembly

- **状态**: ❓ 待确认
- **位置**: `0xe0A281deFf5c9d8d67aF09D39340E134Ac81b82E` 第 1113 行
- **函数**: `_verifyCallResult()`
- **合约**: `ERC20`
- **扫描工具**: pattern
- **综合评分**: 0.280

**工具描述**: 使用了内联汇编，增加了代码复杂度和潜在风险，需仔细审计。

**代码片段**:
```solidity
   1110 |                 // The easiest way to bubble the revert reason is using memory via assembly
   1111 | 
   1112 |                 // solhint-disable-next-line no-inline-assembly
>> 1113 |                 assembly {
   1114 |                     let returndata_size := mload(returndata)
   1115 |                     revert(add(32, returndata), returndata_size)
   1116 |                 }
```

---

---
*报告由 contract-vuln-detector AI 自动生成，仅供参考。建议进行专业人工审计。*